import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EmptyStackException;
import java.util.List;






























public class method_1_traj_gpt {

    
    
    
    
    
    static class Trajectory {
        static class Pt { double x, y, z; Pt(double x, double y, double z) { this.x = x; this.y = y; this.z = z; } }
        private final List<Pt> points = new ArrayList<>();
        private final int dimension;
        Trajectory(int dimension) { this.dimension = dimension; }
        int size() { return points.size(); }
        Pt get(int i) { return points.get(i); }
        void add(double x, double y, double z) { points.add(new Pt(x, y, z)); }
        int getDimension() { return dimension; }
    }

    
    
    
    
    static class Array2DRowRealMatrix {
        final double[][] data;
        Array2DRowRealMatrix(double[][] data) { this.data = data; }
        double getEntry(int r, int c) { return data[r][c]; }
    }

    
    
    
    
    
    static class EigenDecomposition {
        private final double[] eigenvalues = new double[2];
        private final double[][] eigenvectors = new double[2][2];

        EigenDecomposition(Array2DRowRealMatrix m) {
            double a = m.getEntry(0, 0), b = m.getEntry(0, 1), d = m.getEntry(1, 1);
            double trace = a + d;
            double det = a * d - b * b;
            double disc = Math.sqrt(Math.max(0, trace * trace / 4 - det));
            double l1 = trace / 2 + disc;
            double l2 = trace / 2 - disc;
            eigenvalues[0] = l1;
            eigenvalues[1] = l2;
            eigenvectors[0] = eigenvectorFor(a, b, d, l1);
            eigenvectors[1] = eigenvectorFor(a, b, d, l2);
        }

        private double[] eigenvectorFor(double a, double b, double d, double lambda) {
            if (Math.abs(b) > 1e-12) {
                double vx = lambda - d, vy = b;
                double norm = Math.sqrt(vx * vx + vy * vy);
                return norm > 1e-12 ? new double[]{vx / norm, vy / norm} : new double[]{1, 0};
            }
            
            return (Math.abs(lambda - a) < Math.abs(lambda - d)) ? new double[]{1, 0} : new double[]{0, 1};
        }

        RealVector getEigenvector(int i) { return new RealVector(eigenvectors[i]); }
    }

    static class RealVector {
        private final double[] v;
        RealVector(double[] v) { this.v = v; }
        double getEntry(int i) { return v[i]; }
    }

    
    
    
    
    static class RadiusGyrationTensor2D {
        static Array2DRowRealMatrix getRadiusOfGyrationTensor(Trajectory t) {
            int n = t.size();
            double meanX = 0, meanY = 0;
            for (int i = 0; i < n; i++) { meanX += t.get(i).x; meanY += t.get(i).y; }
            meanX /= n; meanY /= n;
            double sxx = 0, sxy = 0, syy = 0;
            for (int i = 0; i < n; i++) {
                double dx = t.get(i).x - meanX, dy = t.get(i).y - meanY;
                sxx += dx * dx; sxy += dx * dy; syy += dy * dy;
            }
            sxx /= n; sxy /= n; syy /= n;
            return new Array2DRowRealMatrix(new double[][]{{sxx, sxy}, {sxy, syy}});
        }
    }

    
    
    
    
    static class CenterOfGravityFeature {
        private final Trajectory t;
        CenterOfGravityFeature(Trajectory t) { this.t = t; }
        double[] evaluate() {
            double sx = 0, sy = 0;
            int n = t.size();
            for (int i = 0; i < n; i++) { sx += t.get(i).x; sy += t.get(i).y; }
            return new double[]{sx / n, sy / n};
        }
    }

    
    
    
    
    static class StandardDeviation {
        private double[] data;
        void setData(double[] data) { this.data = data; }
        double evaluate() {
            int n = data.length;
            if (n < 2) return 0;
            double mean = 0;
            for (double v : data) mean += v;
            mean /= n;
            double ss = 0;
            for (double v : data) ss += (v - mean) * (v - mean);
            return Math.sqrt(ss / (n - 1));
        }
    }

    
    
    
    static class Vector2d {
        double x, y;
        Vector2d(double x, double y) { this.x = x; this.y = y; }
        void normalize() {
            double len = Math.sqrt(x * x + y * y);
            if (len > 1e-12) { x /= len; y /= len; }
        }
        void scale(double s) { x *= s; y *= s; }
    }

    
    
    
    
    static class KeySizeException extends Exception { private static final long serialVersionUID = 1L; }
    static class KeyDuplicateException extends Exception { private static final long serialVersionUID = 1L; }

    
    
    
    
    
    
    
    
    static class KDTree<T> {
        private final int dims;
        private final List<double[]> keys = new ArrayList<>();
        private final List<T> values = new ArrayList<>();

        KDTree(int dims) { this.dims = dims; }

        void insert(double[] key, T value) throws KeySizeException, KeyDuplicateException {
            if (key.length != dims) throw new KeySizeException();
            for (double[] k : keys) {
                if (k[0] == key[0] && k[1] == key[1]) throw new KeyDuplicateException();
            }
            keys.add(key);
            values.add(value);
        }

        List<T> nearestEuclidean(double[] target, double radius) throws KeySizeException {
            if (target.length != dims) throw new KeySizeException();
            List<T> result = new ArrayList<>();
            for (int i = 0; i < keys.size(); i++) {
                double[] k = keys.get(i);
                double dx = k[0] - target[0], dy = k[1] - target[1];
                if (Math.sqrt(dx * dx + dy * dy) <= radius) result.add(values.get(i));
            }
            return result;
        }
    }

    
    
    
    
    
    static class PolynomialSplineFunction {
        private final double[] knots;
        private final double[][] coeffs; 

        PolynomialSplineFunction(double[] knots, double[][] coeffs) {
            this.knots = knots;
            this.coeffs = coeffs;
        }

        int getN() { return coeffs.length; }
        double[] getKnots() { return knots; }

        double value(double x) {
            int seg = knots.length - 2;
            for (int i = 0; i < knots.length - 1; i++) {
                if (x <= knots[i + 1]) { seg = i; break; }
            }
            double dx = x - knots[seg];
            double[] c = coeffs[seg];
            return c[0] + c[1] * dx + c[2] * dx * dx + c[3] * dx * dx * dx;
        }
    }

    
    
    
    
    
    static class SplineInterpolator {
        PolynomialSplineFunction interpolate(double[] x, double[] y) {
            int n = x.length;
            if (n < 3) {
                
                double[][] coeffs = new double[][]{{y[0], (y[1] - y[0]) / (x[1] - x[0]), 0, 0}};
                return new PolynomialSplineFunction(x, coeffs);
            }
            double[] h = new double[n - 1];
            for (int i = 0; i < n - 1; i++) h[i] = x[i + 1] - x[i];

            double[] alpha = new double[n];
            for (int i = 1; i < n - 1; i++) {
                alpha[i] = (3.0 / h[i]) * (y[i + 1] - y[i]) - (3.0 / h[i - 1]) * (y[i] - y[i - 1]);
            }
            double[] l = new double[n], mu = new double[n], z = new double[n];
            l[0] = 1;
            for (int i = 1; i < n - 1; i++) {
                l[i] = 2 * (x[i + 1] - x[i - 1]) - h[i - 1] * mu[i - 1];
                mu[i] = h[i] / l[i];
                z[i] = (alpha[i] - h[i - 1] * z[i - 1]) / l[i];
            }
            l[n - 1] = 1;
            double[] c = new double[n], b = new double[n - 1], d = new double[n - 1];
            for (int j = n - 2; j >= 0; j--) {
                c[j] = z[j] - mu[j] * c[j + 1];
                b[j] = (y[j + 1] - y[j]) / h[j] - h[j] * (c[j + 1] + 2 * c[j]) / 3.0;
                d[j] = (c[j + 1] - c[j]) / (3.0 * h[j]);
            }
            double[][] coeffs = new double[n - 1][4];
            for (int j = 0; j < n - 1; j++) {
                coeffs[j][0] = y[j]; coeffs[j][1] = b[j]; coeffs[j][2] = c[j]; coeffs[j][3] = d[j];
            }
            return new PolynomialSplineFunction(x, coeffs);
        }
    }

    
    
    
    
    
    
    static class TrajectorySplineFit {
        Trajectory t;
        int nSegments;
        boolean successfull;
        double angleRotated;
        Trajectory rotatedTrajectory;
        List<Point2D.Double> splineSupportPoints;
        PolynomialSplineFunction spline;

        TrajectorySplineFit(Trajectory t, int nSegments) {
            this.t = t;
            this.nSegments = nSegments;
            this.rotatedTrajectory = new Trajectory(t.getDimension());
        }

        
        
        
        
        private boolean isLeft(Point2D.Double a, Point2D.Double b, Point2D.Double c) {
            return ((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)) > 0;
        }

        private double distancePointLine(Point2D.Double a, Point2D.Double b, Point2D.Double p) {
            double num = Math.abs((b.y - a.y) * p.x - (b.x - a.x) * p.y + b.x * a.y - b.y * a.x);
            double den = Math.sqrt((b.y - a.y) * (b.y - a.y) + (b.x - a.x) * (b.x - a.x));
            return den > 1e-12 ? num / den : 0;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public PolynomialSplineFunction calculateSpline(){
		
		successfull= false;
		


		ArrayList<Point2D.Double> points = new ArrayList<Point2D.Double>();
		for(int i = 0; i < t.size(); i++){
			Point2D.Double p = new Point2D.Double();
			p.setLocation(t.get(i).x, t.get(i).y);
			points.add(p);
		}
		
		


		
		Array2DRowRealMatrix gyr = RadiusGyrationTensor2D.getRadiusOfGyrationTensor(t);
		EigenDecomposition eigdec = new EigenDecomposition(gyr);
		
		double inRad = -1*Math.atan2(eigdec.getEigenvector(0).getEntry(1), eigdec.getEigenvector(0).getEntry(0));
		boolean doTransform = (Math.abs(Math.abs(inRad)-Math.PI)>0.001);
		
		if(doTransform)
		{
			angleRotated = inRad;
			for(int i = 0; i < t.size(); i++){
				double x = t.get(i).x;
				double y = t.get(i).y;
				double newX = x*Math.cos(inRad)-y*Math.sin(inRad);
				double newY = x*Math.sin(inRad)+y*Math.cos(inRad);
				rotatedTrajectory.add(newX, newY, 0);
				points.get(i).setLocation(newX, newY);
			}
			
			
			
		}
		else{
			angleRotated = 0;
			rotatedTrajectory = t;
		}
		
		
		






		List<List<Point2D.Double>> pointsInSegments =null;
		boolean allSegmentsContainingAtLeastTwoPoints = true;
		int indexSmallestX = 0;
		
		double segmentWidth = 0;
		do{
			double smallestX = Double.MAX_VALUE;
			double largestX = Double.MIN_VALUE;
			
			for(int i = 0; i < points.size(); i++){
				if(points.get(i).x< smallestX){
					smallestX = points.get(i).x;
					indexSmallestX = i;
				}
				if(points.get(i).x>largestX){
					largestX = points.get(i).x;
				}
			}
			
			allSegmentsContainingAtLeastTwoPoints = true;
			segmentWidth = (largestX-smallestX)/nSegments;
			pointsInSegments = new ArrayList<List<Point2D.Double>>(nSegments);
			for(int i = 0; i < nSegments; i++){
				pointsInSegments.add(new ArrayList<Point2D.Double>());
			}
			for(int i = 0; i < points.size(); i++){
	
				int index = (int)Math.abs((points.get(i).x/segmentWidth));
				
				if(index>(nSegments-1)){
					index = (nSegments-1);
				}
				pointsInSegments.get(index).add(points.get(i));
			}
			
			for(int i = 0; i < pointsInSegments.size(); i++){
				if(pointsInSegments.get(i).size()<2){
					if(nSegments>2){
						nSegments--;
						i = pointsInSegments.size();
						allSegmentsContainingAtLeastTwoPoints = false;
				
					}
				}
			}
			
		}while(allSegmentsContainingAtLeastTwoPoints==false);
		
		
		


		
	
		double sumSDOrthogonal=0;
		int Nsum = 0;
		CenterOfGravityFeature cogf = new CenterOfGravityFeature(rotatedTrajectory);
		Point2D.Double cog = new  Point2D.Double(cogf.evaluate()[0], cogf.evaluate()[1]) ;
		Point2D.Double eMajorP1 = cog;
		Point2D.Double eMajorP2 = new Point2D.Double(cog.getX()+1, cog.getY());
		for(int i = 0; i < nSegments; i++){
			StandardDeviation sd = new StandardDeviation();
			double[] distances = new double[pointsInSegments.get(i).size()];
			for(int j = 0; j < pointsInSegments.get(i).size(); j++){
				int factor = 1;
				if(isLeft(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j))){
					factor = -1;
				}
				distances[j] = factor*distancePointLine(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j));
			}
			if(distances.length >0){
				sd.setData(distances);
	
				sumSDOrthogonal += sd.evaluate();
				Nsum++;
			}
		}
		double s = sumSDOrthogonal/Nsum;
		if(segmentWidth<Math.pow(10, -15)){
			return null;
		}
		if(s<Math.pow(10, -15)){
			
		
			s=segmentWidth/2;
		}
		
		


		KDTree<Point2D.Double> kdtree = new KDTree<Point2D.Double>(2);
		
		for(int i = 0; i< points.size(); i++){
			try {
				

				kdtree.insert(new double[]{points.get(i).x,points.get(i).y}, points.get(i));
			} catch (KeySizeException e) {
				e.printStackTrace();
			} catch (KeyDuplicateException e) {
				
			}
			
		}
		
		



		List<Point2D.Double> near = null;
		
		Point2D.Double first = points.get(indexSmallestX);
		double r1 = 3*s;
		try {
			
			near = kdtree.nearestEuclidean(new double[]{first.x ,first.y}, r1);
			
		} catch (KeySizeException e) {
			e.printStackTrace();
		} 

		double cx = 0;
		double cy = 0;
		for(int i = 0; i < near.size(); i++){
			cx += near.get(i).x;
			cy += near.get(i).y;
		}
		cx /= near.size();
		cy /= near.size();

		splineSupportPoints = new ArrayList<Point2D.Double>();
		splineSupportPoints.add(new Point2D.Double(cx, cy));
		
		





		
		


		
		
		



		int nCircleSegments = 100;
		double deltaRad = 2*Math.PI/nCircleSegments;
		boolean stop = false;
		int minN = 7;
		double tempr1 = r1;
		double allowedDeltaDirection = 0.5*Math.PI;
				
		while(stop==false){
			List<Point2D.Double> nearestr1 = null;
			List<Point2D.Double> nearest2xr1 = null;
			try {
				nearestr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},tempr1);
				nearest2xr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},2*tempr1);
			} catch (KeySizeException e) {
				
				e.printStackTrace();
			}
			nearest2xr1.removeAll(nearestr1);
			
			double lThreshRad = 0;
			double hThreshRad = Math.PI/2;
			double stopThresh = 2*Math.PI;
			if(splineSupportPoints.size()>1){
				double directionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				lThreshRad = directionInRad - allowedDeltaDirection/2 - Math.PI/4; 
				if(lThreshRad<0){
					lThreshRad = 2*Math.PI+lThreshRad;
				}
				if(lThreshRad>2*Math.PI){
					lThreshRad = lThreshRad - 2*Math.PI;
				}
				hThreshRad = directionInRad + allowedDeltaDirection/2 + Math.PI/4; 
				if(hThreshRad<0){
					hThreshRad = 2*Math.PI+hThreshRad;
				}
				if(hThreshRad>2*Math.PI){
					hThreshRad = hThreshRad - 2*Math.PI;
				}
				stopThresh = directionInRad + allowedDeltaDirection/2 - Math.PI/4; 
				if(stopThresh>2*Math.PI){
					stopThresh = stopThresh - 2*Math.PI;
				}
				
			}
			
			double newCx=0;
			double newCy=0;
			int newCN = 0;
			int candN = 0;
			
			
			double lastDist = 0;
			double newDist = 0;
			do{ 
				lastDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));

				candN=0;
				double candCx =0;
				double candCy =0;
			
				for(int i = 0; i < nearest2xr1.size(); i++){
					Point2D.Double centerOfCircle = splineSupportPoints.get(splineSupportPoints.size()-1);
					Vector2d relativeToCircle = new Vector2d(nearest2xr1.get(i).x-centerOfCircle.x,nearest2xr1.get(i).y-centerOfCircle.y);
					relativeToCircle.normalize();
					double angleInRadians = Math.atan2(relativeToCircle.y, relativeToCircle.x)+Math.PI;

					if(lThreshRad<hThreshRad){
						if(angleInRadians>lThreshRad && angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}	
					}
					else{
						if(angleInRadians>lThreshRad || angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}
					}
					
								
				}
				
				if(candN>0 && candN > newCN ){
					candCx /= candN;
					candCy /= candN;
					newCx = candCx;
					newCy = candCy;
					newCN = candN;
				}
				lThreshRad += deltaRad;
				hThreshRad += deltaRad;
				if(lThreshRad>2*Math.PI){
					lThreshRad = lThreshRad - 2*Math.PI;
				}
				if(hThreshRad>2*Math.PI){
					hThreshRad = hThreshRad - 2*Math.PI;
				}
				newDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));
			
			}while((newDist-lastDist)>0);
			
			
			
			if(splineSupportPoints.size()>1){
				double currentDirectionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				double candDirectionInRad = Math.atan2(newCy-splineSupportPoints.get(splineSupportPoints.size()-1).y,
						newCx-splineSupportPoints.get(splineSupportPoints.size()-1).x)+Math.PI;
				double dDir = Math.max(currentDirectionInRad, candDirectionInRad)-Math.min(currentDirectionInRad, candDirectionInRad);
				if(dDir>2*Math.PI){
					dDir = 2*Math.PI-dDir;
				}
				if(dDir>allowedDeltaDirection){

					stop = true;
				}
			}
			boolean enoughPoints = (newCN<minN);
			boolean isNormalRadius = Math.abs(tempr1-r1)<Math.pow(10, -18);
			boolean isExtendedRadius = Math.abs(tempr1-3*r1)<Math.pow(10, -18);
			
			if(enoughPoints&& isNormalRadius){
				
				tempr1 = 3*r1;
			}
			else if(enoughPoints && isExtendedRadius){
				
				stop = true;
			}
			else if(stop==false){
				splineSupportPoints.add(new Point2D.Double(newCx,newCy));
				tempr1 = r1;
			}
			
		}

		
				Collections.sort(splineSupportPoints, new Comparator<Point2D.Double>() {

					public int compare(Point2D.Double o1, Point2D.Double o2) {
						if(o1.x<o2.x){
							return -1;
						}
						if(o1.x>o2.x){
							return 1;
						}
						return 0;
					}
				});
				
	
		
		
		if(splineSupportPoints.size()>1){
			Vector2d start = new Vector2d(splineSupportPoints.get(0).x-splineSupportPoints.get(1).x, splineSupportPoints.get(0).y-splineSupportPoints.get(1).y);
			start.normalize();
			start.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+start.x, splineSupportPoints.get(0).y+start.y));
			
			Vector2d end = new Vector2d(splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x, 
					splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y);
			end.normalize();
			end.scale(r1*6);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+end.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+end.y));
		}
		else{
			Vector2d majordir = new Vector2d(-1, 0);
			majordir.normalize();
			majordir.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+majordir.x, splineSupportPoints.get(0).y+majordir.y));
			majordir.scale(-1);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+majordir.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+majordir.y));
		

		}
		
		
		
		
		
		double[] supX = new double[splineSupportPoints.size()];
		double[] supY = new double[splineSupportPoints.size()];
		for(int i = 0; i < splineSupportPoints.size(); i++){
			supX[i] = splineSupportPoints.get(i).x;
			supY[i] = splineSupportPoints.get(i).y;
		}
		
		SplineInterpolator sIinter = new SplineInterpolator();
		spline = sIinter.interpolate(supX, supY);
		successfull = true;
		return spline;
	}
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    public static void main(String[] args) {
        System.out.println("=== method_1_traj_gpt : TrajectorySplineFit.calculateSpline ===");

        
        
        
        
        
        
        Trajectory traj = new Trajectory(2);
        java.util.Random rnd = new java.util.Random(42);
        for (int i = 0; i < 40; i++) {
            double t = i / 39.0;
            double x = t * 100;
            double y = 20 * Math.sin(t * Math.PI) + (rnd.nextDouble() - 0.5) * 2.0;
            traj.add(x, y, 0);
        }

        TrajectorySplineFit fit = new TrajectorySplineFit(traj, 8);
        PolynomialSplineFunction spline = fit.calculateSpline();

        System.out.println("successfull flag: " + fit.successfull);
        System.out.println("angleRotated (radians): " + fit.angleRotated);
        System.out.println("Number of spline support points: " + fit.splineSupportPoints.size());
        for (Point2D.Double p : fit.splineSupportPoints) {
            System.out.printf("   support point: (%.3f, %.3f)%n", p.x, p.y);
        }
        if (spline != null) {
            System.out.println("Spline segment count (getN()): " + spline.getN());
            double[] knots = spline.getKnots();
            System.out.printf("Spline domain: [%.3f, %.3f]%n", knots[0], knots[knots.length - 1]);
            
            for (int i = 0; i <= 4; i++) {
                double x = knots[0] + i * (knots[knots.length - 1] - knots[0]) / 4.0;
                System.out.printf("   spline(%.2f) = %.4f%n", x, spline.value(x));
            }
        } else {
            System.out.println("Spline returned null (degenerate segment width).");
        }

        
        
        
        
        
        Trajectory straight = new Trajectory(2);
        for (int i = 0; i < 20; i++) {
            straight.add(i * 5.0, i * 5.0, 0); 
        }
        TrajectorySplineFit fitStraight = new TrajectorySplineFit(straight, 5);
        PolynomialSplineFunction splineStraight = fitStraight.calculateSpline();
        System.out.println();
        System.out.println("Scenario 2 (near-straight trajectory): successfull=" + fitStraight.successfull
                + " supportPoints=" + (fitStraight.splineSupportPoints != null ? fitStraight.splineSupportPoints.size() : "null")
                + " splineIsNull=" + (splineStraight == null));

        System.out.println("=== Done ===");
    }
}
