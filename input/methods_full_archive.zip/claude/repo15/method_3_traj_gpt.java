import java.util.ArrayList;
import java.util.List;
























public class method_3_traj_gpt {

    
    
    
    
    
    static class Trajectory {
        static class Pt { double x, y; Pt(double x, double y) { this.x = x; this.y = y; } }
        private final List<Pt> points = new ArrayList<>();
        private final int dimension;
        Trajectory(int dimension) { this.dimension = dimension; }
        void add(double x, double y) { points.add(new Pt(x, y)); }
        int size() { return points.size(); }
        Pt get(int i) { return points.get(i); }
        int getDimension() { return dimension; }
    }

    
    
    
    enum SeriesLineStyle { SOLID, DASH_DASH, NONE }
    enum SeriesMarker { NONE, CIRCLE, DIAMOND }

    
    
    
    
    enum SeriesType { Line, Scatter, Area }

    
    
    
    
    static class Series {
        final String name;
        final double[] xData, yData;
        SeriesLineStyle lineStyle = SeriesLineStyle.SOLID;
        SeriesMarker marker = SeriesMarker.CIRCLE;
        SeriesType seriesType = SeriesType.Line;

        Series(String name, double[] xData, double[] yData) {
            this.name = name; this.xData = xData; this.yData = yData;
        }
        void setLineStyle(SeriesLineStyle s) { this.lineStyle = s; }
        void setMarker(SeriesMarker m) { this.marker = m; }
        void setSeriesType(SeriesType t) { this.seriesType = t; }

        @Override
        public String toString() {
            return "Series{" + name + ", n=" + xData.length + ", lineStyle=" + lineStyle
                    + ", marker=" + marker + ", type=" + seriesType + "}";
        }
    }

    
    
    
    
    static class Chart {
        final String title, xTitle, yTitle;
        final List<Series> series = new ArrayList<>();
        Chart(String title, String xTitle, String yTitle) {
            this.title = title; this.xTitle = xTitle; this.yTitle = yTitle;
        }
        Series addSeries(String name, double[] xData, double[] yData) {
            Series s = new Series(name, xData, yData);
            series.add(s);
            return s;
        }
    }

    
    
    
    
    static class QuickChart {
        static Chart getChart(String chartTitle, String xTitle, String yTitle, String seriesName, double[] xData, double[] yData) {
            Chart c = new Chart(chartTitle, xTitle, yTitle);
            c.addSeries(seriesName, xData, yData);
            return c;
        }
    }

    
    
    
    
    
    
    static class SwingWrapper {
        private final Chart chart;
        SwingWrapper(Chart chart) { this.chart = chart; }
        void displayChart() {
            System.out.println("[SwingWrapper] Would display chart \"" + chart.title + "\" (x=" + chart.xTitle
                    + ", y=" + chart.yTitle + ") with " + chart.series.size() + " series:");
            for (Series s : chart.series) {
                System.out.println("   " + s);
            }
        }
    }

    
    
    
    
    
    static class PolynomialSplineFunction {
        private final double[] knots;
        private final double[][] coeffs;
        PolynomialSplineFunction(double[] knots, double[][] coeffs) { this.knots = knots; this.coeffs = coeffs; }
        int getN() { return coeffs.length; }
        double[] getKnots() { return knots; }
        double value(double x) {
            int seg = knots.length - 2;
            for (int i = 0; i < knots.length - 1; i++) {
                if (x <= knots[i + 1]) { seg = i; break; }
            }
            double dx = x - knots[seg];
            double[] c = coeffs[seg];
            return c[0] + c[1] * dx + c[2] * dx * dx + c[3] * dx * dx * dx;
        }
    }

    
    
    static class Pt { double x, y; Pt(double x, double y) { this.x = x; this.y = y; } }

    
    
    
    
    static class TrajectorySplineFit {
        Trajectory t;
        Trajectory rotatedTrajectory;
        List<Pt> splineSupportPoints;
        PolynomialSplineFunction spline;

        TrajectorySplineFit(Trajectory t, Trajectory rotatedTrajectory, List<Pt> splineSupportPoints, PolynomialSplineFunction spline) {
            this.t = t;
            this.rotatedTrajectory = rotatedTrajectory;
            this.splineSupportPoints = splineSupportPoints;
            this.spline = spline;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public void showTrajectoryAndSpline(){
		
		if(t.getDimension()==2){
		 	double[] xData = new double[rotatedTrajectory.size()];
		    double[] yData = new double[rotatedTrajectory.size()];
		    for(int i = 0; i < rotatedTrajectory.size(); i++){
		    	xData[i] = rotatedTrajectory.get(i).x;
		    	yData[i] = rotatedTrajectory.get(i).y;		    	
		    }
		    
		    Chart chart = QuickChart.getChart("Spline+Track", "X", "Y", "y(x)", xData, yData);
		    
		    
		    double[] subxData  = new double[splineSupportPoints.size()];
		    double[] subyData  = new double[splineSupportPoints.size()];
		    
		    for(int i = 0; i < splineSupportPoints.size(); i++){
		    	subxData[i] = splineSupportPoints.get(i).x;
		    	subyData[i] = splineSupportPoints.get(i).y;
		    }
		    Series s = chart.addSeries("Spline Support Points", subxData, subyData);
		    s.setLineStyle(SeriesLineStyle.NONE);
		    s.setSeriesType(SeriesType.Line);
		    
		    
		    int numberInterpolatedPointsPerSegment = 20;
		    int numberOfSplines = spline.getN();
		    double[] sxData = new double[numberInterpolatedPointsPerSegment*numberOfSplines];
		    
		    double[] syData = new double[numberInterpolatedPointsPerSegment*numberOfSplines];
		    double[] knots = spline.getKnots();
		    for(int i = 0; i < numberOfSplines; i++){
		    	double x = knots[i];
		   
		    	double stopx = knots[i+1];
		    	double dx = (stopx-x)/numberInterpolatedPointsPerSegment;
		    	
		    	for(int j = 0; j < numberInterpolatedPointsPerSegment; j++){

		    		sxData[i*numberInterpolatedPointsPerSegment+j] = x;
		    		syData[i*numberInterpolatedPointsPerSegment+j] = spline.value(x);
		    		x += dx;
		    	}
		    	
		    }
		    s = chart.addSeries("Spline", sxData, syData);
		    s.setLineStyle(SeriesLineStyle.DASH_DASH);
		    s.setMarker(SeriesMarker.NONE);
		    s.setSeriesType(SeriesType.Line);
		 
		    
		    
		    new SwingWrapper(chart).displayChart();
		} 
	}
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    public static void main(String[] args) {
        System.out.println("=== method_3_traj_gpt : TrajectorySplineFit.showTrajectoryAndSpline ===");

        
        
        
        
        
        Trajectory raw = new Trajectory(2);
        for (int i = 0; i < 10; i++) raw.add(i * 2.0, Math.sin(i) * 3.0);

        List<Pt> supportPoints = new ArrayList<>();
        supportPoints.add(new Pt(0, 0));
        supportPoints.add(new Pt(6, 3));
        supportPoints.add(new Pt(12, -1));
        supportPoints.add(new Pt(18, 2));

        double[] knots = {0, 6, 12, 18};
        double[][] coeffs = {
                {0, 0.6, 0, -0.01},
                {3, 0.1, -0.2, 0.02},
                {-1, 0.4, 0.1, -0.005}
        };
        PolynomialSplineFunction spline = new PolynomialSplineFunction(knots, coeffs);

        TrajectorySplineFit fit = new TrajectorySplineFit(raw, raw, supportPoints, spline);
        fit.showTrajectoryAndSpline();

        
        
        
        
        Trajectory nonPlanar = new Trajectory(3);
        TrajectorySplineFit fitNonPlanar = new TrajectorySplineFit(nonPlanar, nonPlanar, new ArrayList<>(), null);
        System.out.println();
        System.out.println("Scenario 2 (dimension=3, guard should skip everything):");
        fitNonPlanar.showTrajectoryAndSpline();
        System.out.println("(no chart output above confirms the dimension guard correctly short-circuited)");

        System.out.println("=== Done ===");
    }
}
