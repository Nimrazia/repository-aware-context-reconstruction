

























import java.text.ParseException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;







interface Parser<T> {
    List<T> parse(String text) throws ParseException;
}






public class method_1_pbs_java_api_claude implements Parser<Job> {

    private static final Logger LOGGER = Logger.getLogger(method_1_pbs_java_api_claude.class.getName());

    




    private static final Pattern PATTERN_JOB = Pattern.compile("Job Id:\\s*(\\S+)");

    
    private static final char CHAR_EQUALS = '=';

    
    @Override
    public List<Job> parse(String text) throws ParseException {
        final List<Job> jobs;
        if (StringUtils.isNotBlank(text)) {
            text = StringUtils.replace(text, "\n\t", "");
            jobs = new LinkedList<Job>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Job job = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_JOB.matcher(line);
                if (matcher.matches()) {
                    if (job != null) {
                        jobs.add(job);
                    }
                    job = new Job();
                    final String id = matcher.group(1).trim();
                    job.setId(id);
                } else if (StringUtils.isNotBlank(line)) {
                    String[] temp = Utils.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("job_name".equalsIgnoreCase(key)) {
                            job.setName(value);
                        } else if ("job_owner".equalsIgnoreCase(key)) {
                            job.setOwner(value);
                        } else if (key.startsWith("resources_used.")) {
                            job.getResourcesUsed().put(key, value);
                        } else if ("job_state".equalsIgnoreCase(key)) {
                            job.setState(value);
                        } else if ("queue".equalsIgnoreCase(key)) {
                            job.setQueue(value);
                        } else if ("server".equalsIgnoreCase(key)) {
                            job.setServer(value);
                        } else if ("checkpoint".equalsIgnoreCase(key)) {
                            job.setCheckpoint(value);
                        } else if ("ctime".equalsIgnoreCase(key)) {
                            job.setCtime(value);
                        } else if ("error_path".equalsIgnoreCase(key)) {
                            job.setErrorPath(value);
                        } else if ("exec_host".equalsIgnoreCase(key)) {
                            job.setExecHost(value);
                        } else if ("exec_port".equalsIgnoreCase(key)) {
                            job.setExecPort(value);
                        } else if ("hold_types".equalsIgnoreCase(key)) {
                            job.setHoldTypes(value);
                        } else if ("join_path".equalsIgnoreCase(key)) {
                            job.setJoinPath(value);
                        } else if ("keep_files".equalsIgnoreCase(key)) {
                            job.setKeepFiles(value);
                        } else if ("mail_points".equalsIgnoreCase(key)) {
                            job.setMailPoints(value);
                        } else if ("mail_users".equalsIgnoreCase(key)) {
                            job.setMailUsers(value);
                        } else if ("mtime".equalsIgnoreCase(key)) {
                            job.setMtime(value);
                        } else if ("output_path".equalsIgnoreCase(key)) {
                            job.setOutputPath(value);
                        } else if ("priority".equalsIgnoreCase(key)) {
                            try {
                                job.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job priority: " + nfe.getMessage(), nfe);
                                job.setPriority(-1);
                            }
                        } else if ("qtime".equalsIgnoreCase(key)) {
                            job.setQtime(value);
                        } else if ("rerunable".equalsIgnoreCase(key)) {
                            job.setRerunable(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resource_list.")) {
                            job.getResourceList().put(key, value);
                        } else if ("session_id".equalsIgnoreCase(key)) {
                            try {
                                job.setSessionId(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job session id: " + nfe.getMessage(), nfe);
                                job.setSessionId(-1);
                            }
                        } else if ("substate".equalsIgnoreCase(key)) {
                            try {
                                job.setSubstate(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job substate: " + nfe.getMessage(), nfe);
                                job.setSubstate(-1);
                            }
                        } else if (key.startsWith("variable_list")) {
                            job.getVariableList().put(key, value);
                        } else if ("etime".equalsIgnoreCase(key)) {
                            job.setEtime(value);
                        } else if ("euser".equalsIgnoreCase(key)) {
                            job.setEuser(value);
                        } else if ("egroup".equalsIgnoreCase(key)) {
                            job.setEgroup(value);
                        } else if ("hashname".equalsIgnoreCase(key)) {
                            job.setHashName(value);
                        } else if ("queue_rank".equalsIgnoreCase(key)) {
                            try {
                                job.setQueueRank(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job queue rank: " + nfe.getMessage(), nfe);
                                job.setQueueRank(-1);
                            }
                        } else if ("queue_type".equalsIgnoreCase(key)) {
                            job.setQueueType(value);
                        } else if ("comment".equalsIgnoreCase(key)) {
                            job.setComment(value);
                        } else if ("submit_args".equalsIgnoreCase(key)) {
                            job.setSubmitArgs(value);
                        } else if ("submit_host".equalsIgnoreCase(key)) {
                            job.setSubmitHost(value);
                        } else if ("start_time".equalsIgnoreCase(key)) {
                            job.setStartTime(value);
                        } else if ("start_count".equalsIgnoreCase(key)) {
                            try {
                                job.setStartCount(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job start count: " + nfe.getMessage(), nfe);
                                job.setStartCount(-1);
                            }
                        } else if ("fault_tolerant".equalsIgnoreCase(key)) {
                            job.setFaultTolerant(Boolean.parseBoolean(value));
                        } else if ("job_array_id".equalsIgnoreCase(key)) {
                            job.setJobArrayId(Integer.parseInt(value));
                        } else if ("job_radix".equalsIgnoreCase(key)) {
                            try {
                                job.setRadix(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job radix: " + nfe.getMessage(), nfe);
                                job.setRadix(-1);
                            }
                        } else if ("walltime.remaining".equalsIgnoreCase(key)) {
                            try {
                                job.setWalltimeRemaining(Long.parseLong(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job walltime remaining: " + nfe.getMessage(),
                                        nfe);
                                job.setWalltimeRemaining(-1L);
                            }
                        }
                    }
                }
            }
            if (job != null) {
                jobs.add(job);
            }
            return jobs;
        } else {
            return Collections.emptyList();
        }
    }
    

    
    
    

    





    static final class Utils {
        private Utils() {
        }

        static String[] splitFirst(String line, char separator) {
            int idx = line.indexOf(separator);
            if (idx < 0) {
                return new String[] { line };
            }
            return new String[] { line.substring(0, idx), line.substring(idx + 1) };
        }
    }

    






    static final class StringUtils {
        private StringUtils() {
        }

        static boolean isNotBlank(String s) {
            return s != null && !s.trim().isEmpty();
        }

        static String replace(String text, String searchString, String replacement) {
            if (text == null || searchString == null || searchString.isEmpty()) {
                return text;
            }
            return text.replace(searchString, replacement);
        }
    }

    
    
    

    





    public static void main(String[] args) throws Exception {
        method_1_pbs_java_api_claude parser = new method_1_pbs_java_api_claude();

        String fixture =
                "Job Id: 101.server\n"
              + "    Job_Name = my_job_1\n"
              + "    Job_Owner = alice@server\n"
              + "    resources_used.walltime = 00:10:00\n"
              + "    job_state = R\n"
              + "    queue = batch\n"
              + "    server = head.cluster\n"
              + "    priority = 5\n"
              + "    resource_list.nodes = 1:ppn=4\n"
              + "    variable_list.PATH = /usr/bin\n"
              + "    session_id = 12345\n"
              + "    substate = 42\n"
              + "    rerunable = True\n"
              + "    walltime.remaining = 3600\n"
              + "Job Id: 102.server\n"
              + "    Job_Name = my_job_2\n"
              + "    Job_Owner = bob@server\n"
              + "    job_state = Q\n"
              + "    queue = batch\n"
              + "    priority = not_a_number\n"
              + "    fault_tolerant = true\n";

        System.out.println("=== Scenario 1: multi-job `qstat -f` fixture ===");
        List<Job> jobs = parser.parse(fixture);
        System.out.println("  parsed job count: " + jobs.size());
        for (Job job : jobs) {
            System.out.println("  ----------------------------------------");
            System.out.println("  id             : " + job.getId());
            System.out.println("  name           : " + job.getName());
            System.out.println("  owner          : " + job.getOwner());
            System.out.println("  state          : " + job.getState());
            System.out.println("  queue          : " + job.getQueue());
            System.out.println("  server         : " + job.getServer());
            System.out.println("  priority       : " + job.getPriority());
            System.out.println("  sessionId      : " + job.getSessionId());
            System.out.println("  substate       : " + job.getSubstate());
            System.out.println("  rerunable      : " + job.isRerunable());
            System.out.println("  faultTolerant  : " + job.isFaultTolerant());
            System.out.println("  walltimeRemain : " + job.getWalltimeRemaining());
            System.out.println("  resourcesUsed  : " + job.getResourcesUsed());
            System.out.println("  resourceList   : " + job.getResourceList());
            System.out.println("  variableList   : " + job.getVariableList());
        }
        System.out.println();
        System.out.println("  NOTE: job 102's priority was the literal text 'not_a_number', so the");
        System.out.println("        NumberFormatException branch fired and set priority to "
                + jobs.get(1).getPriority() + " (see WARNING logged above).");

        System.out.println();
        System.out.println("=== Scenario 2: blank input (Collections.emptyList branch) ===");
        List<Job> emptyJobs = parser.parse("   ");
        System.out.println("  jobs.isEmpty() = " + emptyJobs.isEmpty() + ", jobs = " + emptyJobs);
    }
}









class Job {
    private String id;
    private String name;
    private String owner;
    private final Map<String, String> resourcesUsed = new HashMap<String, String>();
    private String state;
    private String queue;
    private String server;
    private String checkpoint;
    private String ctime;
    private String errorPath;
    private String execHost;
    private String execPort;
    private String holdTypes;
    private String joinPath;
    private String keepFiles;
    private String mailPoints;
    private String mailUsers;
    private String mtime;
    private String outputPath;
    private int priority;
    private String qtime;
    private boolean rerunable;
    private final Map<String, String> resourceList = new HashMap<String, String>();
    private int sessionId;
    private int substate;
    private final Map<String, String> variableList = new HashMap<String, String>();
    private String etime;
    private String euser;
    private String egroup;
    private String hashName;
    private int queueRank;
    private String queueType;
    private String comment;
    private String submitArgs;
    private String submitHost;
    private String startTime;
    private int startCount;
    private boolean faultTolerant;
    private int jobArrayId;
    private int radix;
    private long walltimeRemaining;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }
    public Map<String, String> getResourcesUsed() { return resourcesUsed; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
    public String getQueue() { return queue; }
    public void setQueue(String queue) { this.queue = queue; }
    public String getServer() { return server; }
    public void setServer(String server) { this.server = server; }
    public String getCheckpoint() { return checkpoint; }
    public void setCheckpoint(String checkpoint) { this.checkpoint = checkpoint; }
    public String getCtime() { return ctime; }
    public void setCtime(String ctime) { this.ctime = ctime; }
    public String getErrorPath() { return errorPath; }
    public void setErrorPath(String errorPath) { this.errorPath = errorPath; }
    public String getExecHost() { return execHost; }
    public void setExecHost(String execHost) { this.execHost = execHost; }
    public String getExecPort() { return execPort; }
    public void setExecPort(String execPort) { this.execPort = execPort; }
    public String getHoldTypes() { return holdTypes; }
    public void setHoldTypes(String holdTypes) { this.holdTypes = holdTypes; }
    public String getJoinPath() { return joinPath; }
    public void setJoinPath(String joinPath) { this.joinPath = joinPath; }
    public String getKeepFiles() { return keepFiles; }
    public void setKeepFiles(String keepFiles) { this.keepFiles = keepFiles; }
    public String getMailPoints() { return mailPoints; }
    public void setMailPoints(String mailPoints) { this.mailPoints = mailPoints; }
    public String getMailUsers() { return mailUsers; }
    public void setMailUsers(String mailUsers) { this.mailUsers = mailUsers; }
    public String getMtime() { return mtime; }
    public void setMtime(String mtime) { this.mtime = mtime; }
    public String getOutputPath() { return outputPath; }
    public void setOutputPath(String outputPath) { this.outputPath = outputPath; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public String getQtime() { return qtime; }
    public void setQtime(String qtime) { this.qtime = qtime; }
    public boolean isRerunable() { return rerunable; }
    public void setRerunable(boolean rerunable) { this.rerunable = rerunable; }
    public Map<String, String> getResourceList() { return resourceList; }
    public int getSessionId() { return sessionId; }
    public void setSessionId(int sessionId) { this.sessionId = sessionId; }
    public int getSubstate() { return substate; }
    public void setSubstate(int substate) { this.substate = substate; }
    public Map<String, String> getVariableList() { return variableList; }
    public String getEtime() { return etime; }
    public void setEtime(String etime) { this.etime = etime; }
    public String getEuser() { return euser; }
    public void setEuser(String euser) { this.euser = euser; }
    public String getEgroup() { return egroup; }
    public void setEgroup(String egroup) { this.egroup = egroup; }
    public String getHashName() { return hashName; }
    public void setHashName(String hashName) { this.hashName = hashName; }
    public int getQueueRank() { return queueRank; }
    public void setQueueRank(int queueRank) { this.queueRank = queueRank; }
    public String getQueueType() { return queueType; }
    public void setQueueType(String queueType) { this.queueType = queueType; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    public String getSubmitArgs() { return submitArgs; }
    public void setSubmitArgs(String submitArgs) { this.submitArgs = submitArgs; }
    public String getSubmitHost() { return submitHost; }
    public void setSubmitHost(String submitHost) { this.submitHost = submitHost; }
    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public int getStartCount() { return startCount; }
    public void setStartCount(int startCount) { this.startCount = startCount; }
    public boolean isFaultTolerant() { return faultTolerant; }
    public void setFaultTolerant(boolean faultTolerant) { this.faultTolerant = faultTolerant; }
    public int getJobArrayId() { return jobArrayId; }
    public void setJobArrayId(int jobArrayId) { this.jobArrayId = jobArrayId; }
    public int getRadix() { return radix; }
    public void setRadix(int radix) { this.radix = radix; }
    public long getWalltimeRemaining() { return walltimeRemaining; }
    public void setWalltimeRemaining(long w) { this.walltimeRemaining = w; }
}
