





















import java.text.ParseException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;







interface Parser<T> {
    List<T> parse(String text) throws ParseException;
}





public class method_2_pbs_java_api_claude implements Parser<Queue> {

    private static final Logger LOGGER = Logger.getLogger(method_2_pbs_java_api_claude.class.getName());

    



    private static final Pattern PATTERN_QUEUE = Pattern.compile("Queue:\\s*(\\S+)");

    
    private static final char CHAR_EQUALS = '=';

    
    @Override
    public List<Queue> parse(String text) throws ParseException {
        final List<Queue> queues;
        if (StringUtils.isNotBlank(text)) {
            queues = new LinkedList<Queue>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Queue queue = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_QUEUE.matcher(line);
                if (matcher.matches()) {
                    if (queue != null) {
                        queues.add(queue);
                    }
                    queue = new Queue();
                    final String name = matcher.group(1);
                    queue.setName(name);
                } else if (StringUtils.isNotBlank(line)) {
                    String[] temp = Utils.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("queue_type".equals(key)) {
                            queue.setQueueType(value);
                        } else if ("priority".equals(key)) {
                            try {
                                queue.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue priority: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("total_jobs".equals(key)) {
                            try {
                                queue.setTotalJobs(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue total jobs: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("state_count".equals(key)) {
                            queue.setStateCount(value);
                        } else if ("mtime".equals(key)) {
                            queue.setMtime(value);
                        } else if ("max_user_run".equals(key)) {
                            try {
                                queue.setMaxUserRun(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue max user run: " + nfe.getMessage(),
                                        nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("enabled".equals(key)) {
                            queue.setEnabled(Boolean.parseBoolean(value));
                        } else if ("started".equals(key)) {
                            queue.setStarted(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resources_max.")) {
                            queue.getResourcesMax().put(key, value);
                        } else if (key.startsWith("resources_min.")) {
                            queue.getResourcesMin().put(key, value);
                        } else if (key.startsWith("resources_assigned.")) {
                            queue.getResourcesAssigned().put(key, value);
                        } else if (key.startsWith("resources_default.")) {
                            queue.getResourcesDefault().put(key, value);
                        } else {
                            LOGGER.info("Unmmaped key, value: " + key + ", " + value);
                        }
                    }
                }
            }
            if (queue != null) {
                queues.add(queue);
            }
            return queues;
        } else {
            return Collections.emptyList();
        }
    }
    

    



    static final class Utils {
        private Utils() {
        }

        static String[] splitFirst(String line, char separator) {
            int idx = line.indexOf(separator);
            if (idx < 0) {
                return new String[] { line };
            }
            return new String[] { line.substring(0, idx), line.substring(idx + 1) };
        }
    }

    




    static final class StringUtils {
        private StringUtils() {
        }

        static boolean isNotBlank(String s) {
            return s != null && !s.trim().isEmpty();
        }
    }

    





    public static void main(String[] args) throws Exception {
        method_2_pbs_java_api_claude parser = new method_2_pbs_java_api_claude();

        String fixture =
                "Queue: batch\n"
              + "    queue_type = Execution\n"
              + "    priority = 10\n"
              + "    total_jobs = 3\n"
              + "    state_count = Transit:0 Queued:1 Running:2\n"
              + "    mtime = 1590000000\n"
              + "    max_user_run = 4\n"
              + "    resources_max.walltime = 24:00:00\n"
              + "    resources_min.ncpus = 1\n"
              + "    resources_assigned.nodect = 2\n"
              + "    resources_default.walltime = 01:00:00\n"
              + "    enabled = True\n"
              + "    started = True\n"
              + "    some_future_field = surprise\n"
              + "Queue: gpu\n"
              + "    queue_type = Execution\n"
              + "    priority = not_a_number\n"
              + "    enabled = False\n"
              + "    started = False\n";

        System.out.println("=== Scenario 1: multi-queue `qstat -Qf` fixture ===");
        List<Queue> queues = parser.parse(fixture);
        System.out.println("  parsed queue count: " + queues.size());
        for (Queue q : queues) {
            System.out.println("  ----------------------------------------");
            System.out.println("  name              : " + q.getName());
            System.out.println("  queueType         : " + q.getQueueType());
            System.out.println("  priority          : " + q.getPriority());
            System.out.println("  totalJobs         : " + q.getTotalJobs());
            System.out.println("  stateCount        : " + q.getStateCount());
            System.out.println("  mtime             : " + q.getMtime());
            System.out.println("  maxUserRun        : " + q.getMaxUserRun());
            System.out.println("  enabled           : " + q.isEnabled());
            System.out.println("  started           : " + q.isStarted());
            System.out.println("  resourcesMax      : " + q.getResourcesMax());
            System.out.println("  resourcesMin      : " + q.getResourcesMin());
            System.out.println("  resourcesAssigned : " + q.getResourcesAssigned());
            System.out.println("  resourcesDefault  : " + q.getResourcesDefault());
        }
        System.out.println();
        System.out.println("  NOTE: 'some_future_field' hit the else-branch and was logged as an");
        System.out.println("        unmapped key; queue 'gpu' had a non-numeric priority, so the");
        System.out.println("        NumberFormatException branch set priority to " + queues.get(1).getPriority() + ".");

        System.out.println();
        System.out.println("=== Scenario 2: blank input (Collections.emptyList branch) ===");
        List<Queue> empty = parser.parse("");
        System.out.println("  queues.isEmpty() = " + empty.isEmpty() + ", queues = " + empty);
    }
}








class Queue {
    private String name;
    private String queueType;
    private int priority;
    private int totalJobs;
    private String stateCount;
    private String mtime;
    private int maxUserRun;
    private boolean enabled;
    private boolean started;
    private final Map<String, String> resourcesMax = new HashMap<String, String>();
    private final Map<String, String> resourcesMin = new HashMap<String, String>();
    private final Map<String, String> resourcesAssigned = new HashMap<String, String>();
    private final Map<String, String> resourcesDefault = new HashMap<String, String>();

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getQueueType() { return queueType; }
    public void setQueueType(String queueType) { this.queueType = queueType; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public int getTotalJobs() { return totalJobs; }
    public void setTotalJobs(int totalJobs) { this.totalJobs = totalJobs; }
    public String getStateCount() { return stateCount; }
    public void setStateCount(String stateCount) { this.stateCount = stateCount; }
    public String getMtime() { return mtime; }
    public void setMtime(String mtime) { this.mtime = mtime; }
    public int getMaxUserRun() { return maxUserRun; }
    public void setMaxUserRun(int maxUserRun) { this.maxUserRun = maxUserRun; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public boolean isStarted() { return started; }
    public void setStarted(boolean started) { this.started = started; }
    public Map<String, String> getResourcesMax() { return resourcesMax; }
    public Map<String, String> getResourcesMin() { return resourcesMin; }
    public Map<String, String> getResourcesAssigned() { return resourcesAssigned; }
    public Map<String, String> getResourcesDefault() { return resourcesDefault; }
}
