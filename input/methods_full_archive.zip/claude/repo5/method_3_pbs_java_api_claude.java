



































import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;






public class method_3_pbs_java_api_claude {

    private static final Logger LOGGER = Logger.getLogger(method_3_pbs_java_api_claude.class.getName());

    
    private static final String COMMAND_QSUB = "qsub";

    
    private static final long DEFAULT_TIMEOUT = 60000L;

    private method_3_pbs_java_api_claude() {
    }

    
    public static String qsub(String input) {
        final CommandLine cmdLine = new CommandLine(COMMAND_QSUB);
        cmdLine.addArgument(input);

        final OutputStream out = new ByteArrayOutputStream();
        final OutputStream err = new ByteArrayOutputStream();

        DefaultExecuteResultHandler resultHandler;
        try {
            resultHandler = execute(cmdLine, null, out, err);
            resultHandler.waitFor(DEFAULT_TIMEOUT);
        } catch (ExecuteException e) {
            throw new PBSException("Failed to execute qsub command: " + e.getMessage(), e);
        } catch (IOException e) {
            throw new PBSException("Failed to execute qsub command: " + e.getMessage(), e);
        } catch (InterruptedException e) {
            throw new PBSException("Failed to execute qsub command: " + e.getMessage(), e);
        }

        final int exitValue = resultHandler.getExitValue();
        LOGGER.info("qsub exit value: " + exitValue);
        LOGGER.fine("qsub output: " + out.toString());

        if (exitValue != 0)
            throw new PBSException("Failed to submit job script " + input + ". Error output: " + err.toString());

        String jobId = out.toString();
        return jobId.trim();
    }
    

    









    private static DefaultExecuteResultHandler execute(CommandLine cmdLine,
            Map<String, String> environment, OutputStream out, OutputStream err) throws IOException {

        String script = cmdLine.getArguments().length > 0 ? cmdLine.getArguments()[0] : null;
        int exitValue;
        if (script == null || script.trim().isEmpty()) {
            err.write("qsub: no job script specified\n".getBytes());
            exitValue = 1;
        } else if (!script.endsWith(".sh") && !script.endsWith(".pbs")) {
            err.write(("qsub: " + script + ": No such file or directory\n").getBytes());
            exitValue = 1;
        } else {
            String jobId = Integer.toHexString(script.hashCode() & 0xFFFFFF) + ".server\n";
            out.write(jobId.getBytes());
            exitValue = 0;
        }
        return new DefaultExecuteResultHandler(exitValue);
    }

    
    
    

    





    static final class CommandLine {
        private final String executable;
        private final List<String> arguments = new ArrayList<String>();

        CommandLine(String executable) {
            this.executable = executable;
        }

        CommandLine addArgument(String argument) {
            arguments.add(argument);
            return this;
        }

        String getExecutable() {
            return executable;
        }

        String[] getArguments() {
            return arguments.toArray(new String[0]);
        }
    }

    




    static final class DefaultExecuteResultHandler {
        private final int exitValue;

        DefaultExecuteResultHandler(int exitValue) {
            this.exitValue = exitValue;
        }

        





        void waitFor(long timeoutMillis) throws InterruptedException {
        }

        int getExitValue() {
            return exitValue;
        }
    }

    





    static class ExecuteException extends IOException {
        private static final long serialVersionUID = 1L;
        private final int exitValue;

        ExecuteException(String message, int exitValue) {
            super(message);
            this.exitValue = exitValue;
        }

        int getExitValue() {
            return exitValue;
        }
    }

    



    static class PBSException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        PBSException(String message) {
            super(message);
        }

        PBSException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    




    public static void main(String[] args) {
        System.out.println("=== Scenario 1: successful submission (exit value 0) ===");
        String jobId = qsub("/home/user/jobs/my_job.sh");
        System.out.println("  returned job id: '" + jobId + "'");
        System.out.println("  (note the trailing newline written by the simulated qsub was trimmed");
        System.out.println("   by the target method's final jobId.trim() call)");

        System.out.println();
        System.out.println("=== Scenario 2: invalid script path (non-zero exit -> PBSException) ===");
        try {
            qsub("/home/user/jobs/does_not_exist.txt");
            System.out.println("  ERROR: expected PBSException was not thrown");
        } catch (PBSException e) {
            System.out.println("  caught expected PBSException:");
            System.out.println("    " + e.getMessage());
        }

        System.out.println();
        System.out.println("=== Scenario 3: empty script argument (non-zero exit -> PBSException) ===");
        try {
            qsub("   ");
            System.out.println("  ERROR: expected PBSException was not thrown");
        } catch (PBSException e) {
            System.out.println("  caught expected PBSException:");
            System.out.println("    " + e.getMessage());
        }
    }
}
