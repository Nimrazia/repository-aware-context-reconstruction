





























import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


class ServletException extends Exception {
    private static final long serialVersionUID = 1L;

    ServletException(String message) { super(message); }

    ServletException(String message, Throwable cause) { super(message, cause); }
}






interface ServletContext {
    String getMimeType(String fileName);
}





interface HttpServletRequest {
    String getPathInfo();

    String getServletPath();

    String getContextPath();

    String getScheme();

    String getServerName();

    int getServerPort();
}







interface HttpServletResponse {
    void setContentType(String type);

    void setContentLength(int len);

    PrintWriter getWriter() throws IOException;

    OutputStream getOutputStream() throws IOException;

    void sendRedirect(String location) throws IOException;

    void sendError(int code) throws IOException;
}








abstract class HttpServlet {
    private final ServletContext servletContext;

    protected HttpServlet(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    protected ServletContext getServletContext() {
        return servletContext;
    }
}


interface Entry {
    String getName();

    long getLastModified() throws IOException;
}


interface DirectoryEntry extends Entry {
    DirectoryEntry getParent();
}


interface FileEntry extends Entry {
    long getSize() throws IOException;

    InputStream getInputStream() throws IOException;
}





interface FileSystem {
    Entry get(String path);

    Entry[] listEntries(DirectoryEntry directory);
}






class Utils {
    static String urlEncodePathSegment(String segment) {
        try {
            return URLEncoder.encode(segment, "UTF-8").replace("+", "%20");
        } catch (IOException e) {
            return segment;
        }
    }
}






class StringUtils {
    static String repeat(String str, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(str);
        }
        return sb.toString();
    }

    static String leftPad(String str, int size) {
        if (str.length() >= size) {
            return str;
        }
        return repeat(" ", size - str.length()) + str;
    }
}





class IOUtils {
    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
    }

    static void closeQuietly(InputStream in) {
        if (in != null) {
            try {
                in.close();
            } catch (IOException ignored) {
                
            }
        }
    }

    static void closeQuietly(OutputStream out) {
        if (out != null) {
            try {
                out.close();
            } catch (IOException ignored) {
                
            }
        }
    }
}







class IOUtil {
    static void copy(Reader in, PrintWriter out) throws IOException {
        char[] buf = new char[4096];
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
        out.flush();
    }

    static void close(Reader in) {
        if (in != null) {
            try {
                in.close();
            } catch (IOException ignored) {
                
            }
        }
    }
}









class InterpolationFilterReader extends Reader {
    private final String filtered;
    private int pos;

    InterpolationFilterReader(Reader in, Map<String, Object> replacements, String startToken, String endToken)
            throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            sb.append((char) c);
        }
        String text = sb.toString();
        for (Map.Entry<String, Object> e : replacements.entrySet()) {
            text = text.replace(startToken + e.getKey() + endToken, String.valueOf(e.getValue()));
        }
        this.filtered = text;
    }

    @Override
    public int read(char[] cbuf, int off, int len) {
        if (pos >= filtered.length()) {
            return -1;
        }
        int n = Math.min(len, filtered.length() - pos);
        filtered.getChars(pos, pos + n, cbuf, off);
        pos += n;
        return n;
    }

    @Override
    public void close() {
        
    }
}







public class method_2_mrm_claude extends HttpServlet {

    
    private static final int NAME_COL_WIDTH = 40;

    
    private static final int SIZE_COL_WIDTH = 12;

    
    private final FileSystem fileSystem;

    
    private final String settingsServletPath;

    public method_2_mrm_claude(ServletContext servletContext, FileSystem fileSystem, String settingsServletPath) {
        super(servletContext);
        this.fileSystem = fileSystem;
        this.settingsServletPath = settingsServletPath;
    }

    





    private String formatName(String name) {
        if (name.length() <= NAME_COL_WIDTH - 1) {
            return name;
        }
        return name.substring(0, NAME_COL_WIDTH - 4) + "..";
    }

    
    protected void doGet( HttpServletRequest req, HttpServletResponse resp )
        throws ServletException, IOException
    {
        String path = req.getPathInfo();
        String context;
        if ( path == null )
        {
            path = req.getServletPath();
            context = req.getContextPath();
        }
        else
        {
            context = req.getContextPath() + req.getServletPath();
        }
        
        if ( path.equals( "/" + settingsServletPath ) )
        {
            resp.setContentType( "text/xml" );
            PrintWriter w = resp.getWriter();
            
            Reader settingsReader = null;
            try 
            {
                String hostAddress;
                try
                {
                    hostAddress = InetAddress.getLocalHost().getHostAddress();
                }
                catch ( UnknownHostException e )
                {
                    hostAddress = req.getServerName();
                }

                String repositoryProxyUrl = req.getScheme() + "://" + hostAddress + ":" + req.getServerPort(); 
                Reader in = new InputStreamReader( method_2_mrm_claude.class.getResourceAsStream( "/settings-mrm.xml" ) );
                settingsReader = new InterpolationFilterReader( in, Collections.<String, Object>singletonMap( "repository.proxy.url", repositoryProxyUrl ), "@", "@" );
                IOUtil.copy( settingsReader, w );
            }
            finally
            {
                IOUtil.close( settingsReader );
            }
            return;
        }
        
        Entry entry = fileSystem.get( path );
        if ( entry instanceof FileEntry )
        {
            FileEntry fileEntry = (FileEntry) entry;
            long size = fileEntry.getSize();
            if ( size >= 0 && size < Integer.MAX_VALUE )
            {
                resp.setContentLength( (int) size );
            }
            resp.setContentType( getServletContext().getMimeType( fileEntry.getName() ) );
            InputStream source = null;
            OutputStream destination = null;
            try
            {
                source = fileEntry.getInputStream();
                destination = resp.getOutputStream();
                IOUtils.copy( source, destination );
            }
            finally
            {
                IOUtils.closeQuietly( source );
                IOUtils.closeQuietly( destination );
            }
            return;
        }
        else if ( entry instanceof DirectoryEntry )
        {
            if ( !path.endsWith( "/" ) )
            {
                resp.sendRedirect( entry.getName() + "/" );
                return;
            }
            DirectoryEntry dirEntry = (DirectoryEntry) entry;
            Entry[] entries = fileSystem.listEntries( dirEntry );
            resp.setContentType( "text/html" );
            PrintWriter w = resp.getWriter();
            w.println( "<html>" );
            w.println( "  <head>" );
            w.println( "    <title>Index of " + context + path + "</title>" );
            w.println( "    <meta http-equiv=\"Content-Type\" repository=\"text/html; charset=utf-8\"/>" );
            w.println( "</head>" );
            w.println( "<body>" );
            w.println( "<h1>Index of " + context + path + "</h1>" );
            w.println( "  <hr/>" );
            w.write( "<pre>" );

            if ( dirEntry.getParent() != null )
            {
                w.println( "<a href='../'>../</a>" );
            }
            SimpleDateFormat format = new SimpleDateFormat( "dd-MMM-yyyy hh:mm" );
            if ( entries != null )
            {
                for ( int i = 0; i < entries.length; i++ )
                {
                    final String childName = entries[i].getName();
                    boolean directory = entries[i] instanceof DirectoryEntry;
                    if ( directory )
                    {
                        String dirName = childName + "/";
                        w.write(
                            "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "/\">" + formatName( dirName )
                                + "</a>" + StringUtils.repeat( " ",
                                                               Math.max( 0, NAME_COL_WIDTH - dirName.length() ) ) );
                    }
                    else
                    {
                        w.write(
                            "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "\">" + formatName( childName )
                                + "</a>" + StringUtils.repeat( " ",
                                                               Math.max( 0, NAME_COL_WIDTH - childName.length() ) ) );
                    }

                    long timestamp = 0;
                    try
                    {
                        timestamp = entries[i].getLastModified();
                    }
                    catch ( IOException e )
                    {
                        
                    }

                    w.write( " " );
                    w.write( format.format( timestamp != -1 ? new Date( timestamp ) : new Date() ) );
                    if ( directory )
                    {
                        w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                    }
                    else if ( entries[i] instanceof FileEntry )
                    {
                        FileEntry fileEntry = (FileEntry) entries[i];
                        try
                        {
                            long size = fileEntry.getSize();
                            if ( size >= 0 )
                            {
                                w.println( StringUtils.leftPad( Long.toString( size ), SIZE_COL_WIDTH ) );
                            }
                            else
                            {
                                w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                            }
                        }
                        catch ( IOException e )
                        {
                            w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                        }
                    }
                    else
                    {
                        w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                    }
                }
            }
            w.write( "</pre>" );
            w.println( "  <hr/>" );
            w.println( "</body>" );
            w.println( "</html>" );
            return;
        }

        resp.sendError( HttpURLConnection.HTTP_NOT_FOUND );
    }
    

    
    
    

    




    static class InMemoryFileSystem implements FileSystem {

        static class Dir implements DirectoryEntry {
            private final String name;
            private final Dir parent;
            final List<Entry> children = new ArrayList<Entry>();

            Dir(Dir parent, String name) {
                this.parent = parent;
                this.name = name;
            }

            public String getName() { return name; }

            public long getLastModified() { return 1590000000000L; }

            public DirectoryEntry getParent() { return parent; }
        }

        static class File implements FileEntry {
            private final String name;
            private final byte[] bytes;
            private final long lastModified;

            File(String name, byte[] bytes, long lastModified) {
                this.name = name;
                this.bytes = bytes;
                this.lastModified = lastModified;
            }

            public String getName() { return name; }

            public long getLastModified() { return lastModified; }

            public long getSize() { return bytes.length; }

            public InputStream getInputStream() { return new ByteArrayInputStream(bytes); }
        }

        private final Map<String, Entry> byPath = new HashMap<String, Entry>();

        Dir mkdir(Dir parent, String name, String path) {
            Dir d = new Dir(parent, name);
            byPath.put(path, d);
            
            
            
            if (path.endsWith("/") && path.length() > 1) {
                byPath.put(path.substring(0, path.length() - 1), d);
            }
            if (parent != null) {
                parent.children.add(d);
            }
            return d;
        }

        File putFile(Dir parent, String name, String content, long lastModified, String path) {
            File f = new File(name, content.getBytes(), lastModified);
            byPath.put(path, f);
            parent.children.add(f);
            return f;
        }

        public Entry get(String path) { return byPath.get(path); }

        public Entry[] listEntries(DirectoryEntry directory) {
            return ((Dir) directory).children.toArray(new Entry[0]);
        }
    }

    
    static class SimpleServletContext implements ServletContext {
        public String getMimeType(String fileName) {
            if (fileName.endsWith(".txt")) {
                return "text/plain";
            }
            if (fileName.endsWith(".pom") || fileName.endsWith(".xml")) {
                return "application/xml";
            }
            if (fileName.endsWith(".jar")) {
                return "application/java-archive";
            }
            return "application/octet-stream";
        }
    }

    
    static class SimpleRequest implements HttpServletRequest {
        private final String pathInfo;
        private final String servletPath;
        private final String contextPath;

        SimpleRequest(String pathInfo, String servletPath, String contextPath) {
            this.pathInfo = pathInfo;
            this.servletPath = servletPath;
            this.contextPath = contextPath;
        }

        public String getPathInfo() { return pathInfo; }

        public String getServletPath() { return servletPath; }

        public String getContextPath() { return contextPath; }

        public String getScheme() { return "http"; }

        public String getServerName() { return "localhost"; }

        public int getServerPort() { return 8080; }
    }

    
    static class CapturingResponse implements HttpServletResponse {
        String contentType;
        int contentLength = -1;
        int errorCode = -1;
        String redirect;
        final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        final StringBuilder text = new StringBuilder();

        public void setContentType(String type) { this.contentType = type; }

        public void setContentLength(int len) { this.contentLength = len; }

        public PrintWriter getWriter() {
            return new PrintWriter(new Writer() {
                public void write(char[] cbuf, int off, int len) { text.append(cbuf, off, len); }

                public void flush() { }

                public void close() { }
            }, true);
        }

        public OutputStream getOutputStream() { return bytes; }

        public void sendRedirect(String location) { this.redirect = location; }

        public void sendError(int code) { this.errorCode = code; }
    }

    






    public static void main(String[] args) throws Exception {
        InMemoryFileSystem fs = new InMemoryFileSystem();
        InMemoryFileSystem.Dir root = fs.mkdir(null, "", "/");
        InMemoryFileSystem.Dir sub = fs.mkdir(root, "com", "/com/");
        fs.putFile(root, "readme.txt", "hello from the mrm virtual repository", 1590000000000L, "/readme.txt");
        fs.putFile(root, "my-lib-1.0.pom",
                "<project><artifactId>my-lib</artifactId></project>", 1591000000000L, "/my-lib-1.0.pom");

        method_2_mrm_claude servlet =
                new method_2_mrm_claude(new SimpleServletContext(), fs, "settings.xml");

        System.out.println("=== Scenario 1: file download (/readme.txt) ===");
        CapturingResponse r1 = new CapturingResponse();
        servlet.doGet(new SimpleRequest("/readme.txt", "", "/mrm"), r1);
        System.out.println("  Content-Type   : " + r1.contentType);
        System.out.println("  Content-Length : " + r1.contentLength);
        System.out.println("  body bytes     : " + r1.bytes.size());
        System.out.println("  body           : " + new String(r1.bytes.toByteArray()));

        System.out.println();
        System.out.println("=== Scenario 2: file download of a .pom (different MIME type) ===");
        CapturingResponse r2 = new CapturingResponse();
        servlet.doGet(new SimpleRequest("/my-lib-1.0.pom", "", "/mrm"), r2);
        System.out.println("  Content-Type   : " + r2.contentType);
        System.out.println("  Content-Length : " + r2.contentLength);
        System.out.println("  body           : " + new String(r2.bytes.toByteArray()));

        System.out.println();
        System.out.println("=== Scenario 3: directory listing (/) ===");
        CapturingResponse r3 = new CapturingResponse();
        servlet.doGet(new SimpleRequest("/", "", "/mrm"), r3);
        System.out.println("  Content-Type   : " + r3.contentType);
        System.out.println("  generated HTML :");
        System.out.println(r3.text.toString());
        System.out.println("  note: 'com/' is rendered as a directory (size column '-'), while");
        System.out.println("        readme.txt and my-lib-1.0.pom show their real byte sizes.");

        System.out.println();
        System.out.println("=== Scenario 4: directory without trailing slash (redirect) ===");
        CapturingResponse r4 = new CapturingResponse();
        servlet.doGet(new SimpleRequest("/com", "", "/mrm"), r4);
        System.out.println("  entry resolved was a DirectoryEntry but path had no trailing '/'");
        System.out.println("  sendRedirect location : " + r4.redirect);

        System.out.println();
        System.out.println("=== Scenario 5: unknown path (404) ===");
        CapturingResponse r5 = new CapturingResponse();
        servlet.doGet(new SimpleRequest("/nope/missing.jar", "", "/mrm"), r5);
        System.out.println("  sendError code : " + r5.errorCode
                + "   (HttpURLConnection.HTTP_NOT_FOUND)");
    }
}
