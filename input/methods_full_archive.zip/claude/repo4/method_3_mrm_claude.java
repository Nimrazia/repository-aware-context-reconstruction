
































import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeSet;







abstract class ArtifactStore {
    public abstract Set<String> getArtifactIds(String groupId);

    public abstract Set<String> getVersions(String groupId, String artifactId);

    public abstract InputStream get(Artifact artifact) throws IOException, ArtifactNotFoundException;

    public abstract long getLastModified(Artifact artifact) throws IOException, ArtifactNotFoundException;

    public abstract Metadata getMetadata(String path) throws IOException, MetadataNotFoundException;
}


class Artifact {
    private final String groupId;
    private final String artifactId;
    private final String version;
    private final String type;

    Artifact(String groupId, String artifactId, String version, String type) {
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.type = type;
    }

    String getGroupId() { return groupId; }
    String getArtifactId() { return artifactId; }
    String getVersion() { return version; }
    String getType() { return type; }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Artifact)) {
            return false;
        }
        Artifact a = (Artifact) o;
        return groupId.equals(a.groupId) && artifactId.equals(a.artifactId)
                && version.equals(a.version) && type.equals(a.type);
    }

    @Override
    public int hashCode() {
        return (groupId + ":" + artifactId + ":" + version + ":" + type).hashCode();
    }

    @Override
    public String toString() {
        return groupId + ":" + artifactId + ":" + version + ":" + type;
    }
}


class ArtifactNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;

    ArtifactNotFoundException(Artifact artifact) {
        super("Artifact not found: " + artifact);
    }
}


class MetadataNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;

    MetadataNotFoundException(String path) {
        super("Metadata not found: " + path);
    }
}


class Metadata {
    private String groupId;
    private String artifactId;
    private String version;
    private Versioning versioning;
    private List<Plugin> plugins;

    String getGroupId() { return groupId; }
    void setGroupId(String groupId) { this.groupId = groupId; }
    String getArtifactId() { return artifactId; }
    void setArtifactId(String artifactId) { this.artifactId = artifactId; }
    String getVersion() { return version; }
    void setVersion(String version) { this.version = version; }
    Versioning getVersioning() { return versioning; }
    void setVersioning(Versioning versioning) { this.versioning = versioning; }

    List<Plugin> getPlugins() {
        return plugins == null ? new ArrayList<Plugin>() : plugins;
    }

    void setPlugins(List<Plugin> plugins) { this.plugins = plugins; }

    void addPlugin(Plugin plugin) {
        if (plugins == null) {
            plugins = new ArrayList<Plugin>();
        }
        plugins.add(plugin);
    }
}


class Plugin {
    private String artifactId;
    private String name;
    private String prefix;

    String getArtifactId() { return artifactId; }
    void setArtifactId(String artifactId) { this.artifactId = artifactId; }
    String getName() { return name; }
    void setName(String name) { this.name = name; }
    String getPrefix() { return prefix; }
    void setPrefix(String prefix) { this.prefix = prefix; }
}








class Versioning {
    private String latest;
    private String release;
    private final List<String> versions = new ArrayList<String>();
    private String lastUpdated;
    private Snapshot snapshot;
    private List<SnapshotVersion> snapshotVersions;

    String getLatest() { return latest; }
    void setLatest(String latest) { this.latest = latest; }
    String getRelease() { return release; }
    void setRelease(String release) { this.release = release; }
    List<String> getVersions() { return versions; }
    void addVersion(String version) { versions.add(version); }
    String getLastUpdated() { return lastUpdated; }
    void setLastUpdated(String lastUpdated) { this.lastUpdated = lastUpdated; }

    void setLastUpdatedTimestamp(Date d) {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMddHHmmss");
        fmt.setTimeZone(TimeZone.getTimeZone("GMT"));
        this.lastUpdated = fmt.format(d);
    }

    Snapshot getSnapshot() { return snapshot; }
    void setSnapshot(Snapshot snapshot) { this.snapshot = snapshot; }

    List<SnapshotVersion> getSnapshotVersions() {
        return snapshotVersions == null ? new ArrayList<SnapshotVersion>() : snapshotVersions;
    }

    void addSnapshotVersion(SnapshotVersion sv) {
        if (snapshotVersions == null) {
            snapshotVersions = new ArrayList<SnapshotVersion>();
        }
        snapshotVersions.add(sv);
    }
}


class Snapshot {
    private int buildNumber;
    private String timestamp;

    int getBuildNumber() { return buildNumber; }
    void setBuildNumber(int buildNumber) { this.buildNumber = buildNumber; }
    String getTimestamp() { return timestamp; }
    void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}


class SnapshotVersion {
    private String classifier = "";
    private String extension = "pom";
    private String version;
    private String updated;

    String getClassifier() { return classifier; }
    void setClassifier(String classifier) { this.classifier = classifier; }
    String getExtension() { return extension; }
    void setExtension(String extension) { this.extension = extension; }
    String getVersion() { return version; }
    void setVersion(String version) { this.version = version; }
    String getUpdated() { return updated; }
    void setUpdated(String updated) { this.updated = updated; }

    @Override
    public String toString() {
        return version + "-" + classifier + "." + extension + "@" + updated;
    }
}






class StringUtils {
    static boolean isEmpty(String str) {
        return str == null || str.length() == 0;
    }
}








class MockArtifactStore extends ArtifactStore {
    private final String label;
    private final Map<String, Metadata> byPath = new HashMap<String, Metadata>();
    private final Map<Artifact, byte[]> files = new HashMap<Artifact, byte[]>();

    MockArtifactStore(String label) {
        this.label = label;
    }

    String getLabel() {
        return label;
    }

    void put(String path, Metadata metadata) {
        byPath.put(path, metadata);
    }

    void putFile(Artifact artifact, byte[] bytes) {
        files.put(artifact, bytes);
    }

    @Override
    public Set<String> getArtifactIds(String groupId) {
        Set<String> ids = new HashSet<String>();
        for (Artifact a : files.keySet()) {
            if (a.getGroupId().equals(groupId)) {
                ids.add(a.getArtifactId());
            }
        }
        return ids.isEmpty() ? null : ids;
    }

    @Override
    public Set<String> getVersions(String groupId, String artifactId) {
        Set<String> versions = new HashSet<String>();
        for (Artifact a : files.keySet()) {
            if (a.getGroupId().equals(groupId) && a.getArtifactId().equals(artifactId)) {
                versions.add(a.getVersion());
            }
        }
        return versions.isEmpty() ? null : versions;
    }

    @Override
    public InputStream get(Artifact artifact) throws IOException, ArtifactNotFoundException {
        byte[] bytes = files.get(artifact);
        if (bytes == null) {
            throw new ArtifactNotFoundException(artifact);
        }
        return new ByteArrayInputStream(bytes);
    }

    @Override
    public long getLastModified(Artifact artifact) throws IOException, ArtifactNotFoundException {
        if (!files.containsKey(artifact)) {
            throw new ArtifactNotFoundException(artifact);
        }
        return 0L;
    }

    @Override
    public Metadata getMetadata(String path) throws IOException, MetadataNotFoundException {
        Metadata m = byPath.get(path);
        if (m == null) {
            throw new MetadataNotFoundException(path);
        }
        return m;
    }
}







public class method_3_mrm_claude extends ArtifactStore {

    
    private final ArtifactStore[] stores;

    public method_3_mrm_claude(ArtifactStore[] stores) {
        this.stores = stores;
    }

    @Override
    public Set<String> getArtifactIds(String groupId) {
        Set<String> result = null;
        for (int i = 0; i < stores.length; i++) {
            Set<String> ids = stores[i].getArtifactIds(groupId);
            if (ids != null) {
                if (result == null) {
                    result = new HashSet<String>();
                }
                result.addAll(ids);
            }
        }
        return result;
    }

    @Override
    public Set<String> getVersions(String groupId, String artifactId) {
        Set<String> result = null;
        for (int i = 0; i < stores.length; i++) {
            Set<String> versions = stores[i].getVersions(groupId, artifactId);
            if (versions != null) {
                if (result == null) {
                    result = new HashSet<String>();
                }
                result.addAll(versions);
            }
        }
        return result;
    }

    @Override
    public InputStream get(Artifact artifact) throws IOException, ArtifactNotFoundException {
        for (int i = 0; i < stores.length; i++) {
            try {
                return stores[i].get(artifact);
            } catch (ArtifactNotFoundException e) {
                
            }
        }
        throw new ArtifactNotFoundException(artifact);
    }

    @Override
    public long getLastModified(Artifact artifact) throws IOException, ArtifactNotFoundException {
        for (int i = 0; i < stores.length; i++) {
            try {
                return stores[i].getLastModified(artifact);
            } catch (ArtifactNotFoundException e) {
                
            }
        }
        throw new ArtifactNotFoundException(artifact);
    }

    
    public Metadata getMetadata( String path )
        throws IOException, MetadataNotFoundException
    {
        boolean found = false;
        Metadata result = new Metadata();
        Set<String> pluginArtifactIds = new HashSet<String>();
        Set<String> snapshotVersions = new HashSet<String>();
        for ( int i = 0; i < stores.length; i++ )
        {
            try
            {
                Metadata partial = stores[i].getMetadata( path );
                if ( StringUtils.isEmpty( result.getArtifactId() ) && !StringUtils.isEmpty( partial.getArtifactId() ) )
                {
                    result.setArtifactId( partial.getArtifactId() );
                    found = true;
                }
                if ( StringUtils.isEmpty( result.getGroupId() ) && !StringUtils.isEmpty( partial.getGroupId() ) )
                {
                    result.setGroupId( partial.getGroupId() );
                    found = true;
                }
                if ( StringUtils.isEmpty( result.getVersion() ) && !StringUtils.isEmpty( partial.getVersion() ) )
                {
                    result.setVersion( partial.getVersion() );
                    found = true;
                }
                if ( partial.getPlugins() != null && !partial.getPlugins().isEmpty() )
                {
                    for ( Plugin plugin : partial.getPlugins() )
                    {
                        if ( !pluginArtifactIds.contains( plugin.getArtifactId() ) )
                        {
                            result.addPlugin( plugin );
                            pluginArtifactIds.add( plugin.getArtifactId() );
                        }
                    }
                    found = true;
                }
                if ( partial.getVersioning() != null )
                {
                    Versioning rVers = result.getVersioning();
                    if ( rVers == null )
                    {
                        rVers = new Versioning();
                    }
                    Versioning pVers = partial.getVersioning();
                    String rLU = found ? rVers.getLastUpdated() : null;
                    String pLU = pVers.getLastUpdated();
                    if ( pLU != null && ( rLU == null || rLU.compareTo( pLU ) < 0 ) )
                    {
                        
                        if ( !StringUtils.isEmpty( pVers.getLatest() ) )
                        {
                            rVers.setLatest( pVers.getLatest() );
                        }

                        if ( !StringUtils.isEmpty( pVers.getRelease() ) )
                        {
                            rVers.setLatest( pVers.getRelease() );
                        }
                        rVers.setLastUpdated( pVers.getLastUpdated() );
                    }
                    for ( String version : pVers.getVersions() )
                    {
                        if ( !rVers.getVersions().contains( version ) )
                        {
                            rVers.addVersion( version );
                        }
                    }
                    if ( pVers.getSnapshot() != null )
                    {
                        if ( rVers.getSnapshot() == null
                            || pVers.getSnapshot().getBuildNumber() > rVers.getSnapshot().getBuildNumber() )
                        {
                            Snapshot snapshot = new Snapshot();
                            snapshot.setBuildNumber( pVers.getSnapshot().getBuildNumber() );
                            snapshot.setTimestamp( pVers.getSnapshot().getTimestamp() );
                            rVers.setSnapshot( snapshot );
                        }
                    }
                    try
                    {
                        if ( pVers.getSnapshotVersions() != null && !pVers.getSnapshotVersions().isEmpty() )
                        {
                            for ( SnapshotVersion snapshotVersion : pVers.getSnapshotVersions() )
                            {
                                String key = snapshotVersion.getVersion() + "-" + snapshotVersion.getClassifier() + "."
                                    + snapshotVersion.getExtension();
                                if ( !snapshotVersions.contains( key ) )
                                {
                                    rVers.addSnapshotVersion( snapshotVersion );
                                    snapshotVersions.add( key );
                                }
                            }
                        }
                    }
                    catch ( NoSuchMethodError e )
                    {
                        
                    }

                    result.setVersioning( rVers );
                    found = true;
                }
            }
            catch ( MetadataNotFoundException e )
            {
                
            }
        }
        if ( !found )
        {
            throw new MetadataNotFoundException( path );
        }
        return result;
    }
    

    
    private static Versioning versioning(String lastUpdated, String latest, String release,
            String[] versions, int snapBuildNumber, String snapTimestamp, String[] snapVersions) {
        Versioning v = new Versioning();
        v.setLastUpdated(lastUpdated);
        v.setLatest(latest);
        v.setRelease(release);
        for (int i = 0; i < versions.length; i++) {
            v.addVersion(versions[i]);
        }
        if (snapBuildNumber > 0) {
            Snapshot s = new Snapshot();
            s.setBuildNumber(snapBuildNumber);
            s.setTimestamp(snapTimestamp);
            v.setSnapshot(s);
        }
        for (int i = 0; i < snapVersions.length; i++) {
            SnapshotVersion sv = new SnapshotVersion();
            sv.setVersion(snapVersions[i]);
            sv.setUpdated(lastUpdated);
            v.addSnapshotVersion(sv);
        }
        return v;
    }

    








    public static void main(String[] args) throws Exception {
        final String path = "com/example/my-lib";

        
        MockArtifactStore storeA = new MockArtifactStore("A");
        Metadata mA = new Metadata();
        mA.setGroupId("com.example");
        mA.setArtifactId("my-lib");
        Plugin pluginA = new Plugin();
        pluginA.setArtifactId("widget-maven-plugin");
        pluginA.setName("Widget Plugin");
        pluginA.setPrefix("widget");
        mA.addPlugin(pluginA);
        mA.setVersioning(versioning("20200101000000", "2.0", "2.0",
                new String[] { "1.0", "2.0" }, 3, "20200101.000000",
                new String[] { "2.0" }));
        storeA.put(path, mA);

        
        
        MockArtifactStore storeB = new MockArtifactStore("B");
        Metadata mB = new Metadata();
        mB.setGroupId("com.example");
        mB.setArtifactId("my-lib");
        mB.setVersion("3.0-SNAPSHOT");
        Plugin pluginDup = new Plugin();
        pluginDup.setArtifactId("widget-maven-plugin");
        pluginDup.setName("Widget Plugin (duplicate entry)");
        pluginDup.setPrefix("widget");
        mB.addPlugin(pluginDup);
        Plugin pluginB = new Plugin();
        pluginB.setArtifactId("gizmo-maven-plugin");
        pluginB.setName("Gizmo Plugin");
        pluginB.setPrefix("gizmo");
        mB.addPlugin(pluginB);
        mB.setVersioning(versioning("20200601000000", "3.0", "3.0",
                new String[] { "2.0", "3.0" }, 9, "20200601.120000",
                new String[] { "2.0", "3.0" }));
        storeB.put(path, mB);

        
        
        MockArtifactStore storeC = new MockArtifactStore("C");

        method_3_mrm_claude composite =
                new method_3_mrm_claude(new ArtifactStore[] { storeA, storeB, storeC });

        System.out.println("=== Scenario 1: merge three backing stores (A older, B newer, C empty) ===");
        Metadata merged = composite.getMetadata(path);
        System.out.println("  groupId     = " + merged.getGroupId());
        System.out.println("  artifactId  = " + merged.getArtifactId());
        System.out.println("  version     = " + merged.getVersion()
                + "   (only store B supplied a version)");
        System.out.println("  versions    = " + merged.getVersioning().getVersions()
                + "   (union of A and B, 2.0 not duplicated)");
        System.out.println("  lastUpdated = " + merged.getVersioning().getLastUpdated()
                + "   (store B was newer, so it won)");
        System.out.println("  latest      = " + merged.getVersioning().getLatest());
        System.out.println("  snapshot buildNumber = " + merged.getVersioning().getSnapshot().getBuildNumber()
                + "   (B's 9 beat A's 3)");
        System.out.println("  snapshot timestamp   = " + merged.getVersioning().getSnapshot().getTimestamp());

        System.out.println("  plugins (" + merged.getPlugins().size() + " after de-duplication):");
        for (Plugin p : merged.getPlugins()) {
            System.out.println("    artifactId=" + p.getArtifactId()
                    + "  name=" + p.getName() + "  prefix=" + p.getPrefix());
        }
        System.out.println("    note: store B's second widget-maven-plugin entry was dropped because");
        System.out.println("          its artifactId was already in pluginArtifactIds");

        System.out.println("  snapshotVersions (" + merged.getVersioning().getSnapshotVersions().size()
                + " after de-duplication by version-classifier.extension):");
        Set<String> shown = new TreeSet<String>();
        for (SnapshotVersion sv : merged.getVersioning().getSnapshotVersions()) {
            shown.add(sv.getVersion() + "-" + sv.getClassifier() + "." + sv.getExtension());
        }
        System.out.println("    keys = " + shown);
        System.out.println("    note: '2.0' arrived from both A and B but was added only once");

        System.out.println();
        System.out.println("=== Scenario 2: single store contributes everything ===");
        method_3_mrm_claude soloComposite =
                new method_3_mrm_claude(new ArtifactStore[] { storeB });
        Metadata solo = soloComposite.getMetadata(path);
        System.out.println("  artifactId  = " + solo.getArtifactId());
        System.out.println("  versions    = " + solo.getVersioning().getVersions());
        System.out.println("  lastUpdated = " + solo.getVersioning().getLastUpdated());

        System.out.println();
        System.out.println("=== Scenario 3: no store has the path (MetadataNotFoundException) ===");
        method_3_mrm_claude emptyComposite =
                new method_3_mrm_claude(new ArtifactStore[] { storeC });
        try {
            emptyComposite.getMetadata("does/not/exist");
            System.out.println("  ERROR: expected MetadataNotFoundException was not thrown");
        } catch (MetadataNotFoundException e) {
            System.out.println("  caught expected MetadataNotFoundException: " + e.getMessage());
        }
    }
}
