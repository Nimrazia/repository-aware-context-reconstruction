





























import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;






abstract class ArtifactStore {
    public abstract Set<String> getArtifactIds(String groupId);

    public abstract Set<String> getVersions(String groupId, String artifactId);

    public abstract InputStream get(Artifact artifact) throws IOException, ArtifactNotFoundException;

    public abstract long getLastModified(Artifact artifact) throws IOException, ArtifactNotFoundException;

    public abstract Metadata getMetadata(String path) throws IOException, MetadataNotFoundException;
}







class Artifact {
    private final String groupId;
    private final String artifactId;
    private final String version;
    private final String type;
    private Integer buildNumber;
    private String timestampString;

    Artifact(String groupId, String artifactId, String version, String type) {
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.type = type;
    }

    String getGroupId() { return groupId; }
    String getArtifactId() { return artifactId; }
    String getVersion() { return version; }
    String getType() { return type; }
    Integer getBuildNumber() { return buildNumber; }
    void setBuildNumber(Integer buildNumber) { this.buildNumber = buildNumber; }
    String getTimestampString() { return timestampString; }
    void setTimestampString(String s) { this.timestampString = s; }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Artifact)) {
            return false;
        }
        Artifact a = (Artifact) o;
        return groupId.equals(a.groupId) && artifactId.equals(a.artifactId)
                && version.equals(a.version) && type.equals(a.type);
    }

    @Override
    public int hashCode() {
        return (groupId + ":" + artifactId + ":" + version + ":" + type).hashCode();
    }

    @Override
    public String toString() {
        return groupId + ":" + artifactId + ":" + version + ":" + type;
    }
}






class Content {
    private final byte[] bytes;
    private final long lastModified;

    Content(byte[] bytes, long lastModified) {
        this.bytes = bytes;
        this.lastModified = lastModified;
    }

    byte[] getBytes() { return bytes; }
    long getLastModified() { return lastModified; }
}


class ArtifactNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;

    ArtifactNotFoundException(Artifact artifact) {
        super("Artifact not found: " + artifact);
    }
}


class MetadataNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;

    MetadataNotFoundException(String path) {
        super("Metadata not found: " + path);
    }
}






class Metadata {
    private String groupId;
    private String artifactId;
    private String version;
    private Versioning versioning;
    private List<Plugin> plugins;

    String getGroupId() { return groupId; }
    void setGroupId(String groupId) { this.groupId = groupId; }
    String getArtifactId() { return artifactId; }
    void setArtifactId(String artifactId) { this.artifactId = artifactId; }
    String getVersion() { return version; }
    void setVersion(String version) { this.version = version; }
    Versioning getVersioning() { return versioning; }
    void setVersioning(Versioning versioning) { this.versioning = versioning; }

    List<Plugin> getPlugins() {
        return plugins == null ? new ArrayList<Plugin>() : plugins;
    }

    void setPlugins(List<Plugin> plugins) { this.plugins = plugins; }

    void addPlugin(Plugin plugin) {
        if (plugins == null) {
            plugins = new ArrayList<Plugin>();
        }
        plugins.add(plugin);
    }
}


class Plugin {
    private String artifactId;
    private String name;
    private String prefix;

    String getArtifactId() { return artifactId; }
    void setArtifactId(String artifactId) { this.artifactId = artifactId; }
    String getName() { return name; }
    void setName(String name) { this.name = name; }
    String getPrefix() { return prefix; }
    void setPrefix(String prefix) { this.prefix = prefix; }
}








class Versioning {
    private String latest;
    private String release;
    private final List<String> versions = new ArrayList<String>();
    private Date lastUpdatedTimestamp;
    private String lastUpdated;
    private Snapshot snapshot;
    private List<SnapshotVersion> snapshotVersions;

    String getLatest() { return latest; }
    void setLatest(String latest) { this.latest = latest; }
    String getRelease() { return release; }
    void setRelease(String release) { this.release = release; }
    List<String> getVersions() { return versions; }
    void addVersion(String version) { versions.add(version); }

    void setLastUpdatedTimestamp(Date d) {
        this.lastUpdatedTimestamp = d;
        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMddHHmmss");
        fmt.setTimeZone(TimeZone.getTimeZone("GMT"));
        this.lastUpdated = fmt.format(d);
    }

    Date getLastUpdatedTimestamp() { return lastUpdatedTimestamp; }
    String getLastUpdated() { return lastUpdated; }
    void setLastUpdated(String lastUpdated) { this.lastUpdated = lastUpdated; }
    Snapshot getSnapshot() { return snapshot; }
    void setSnapshot(Snapshot snapshot) { this.snapshot = snapshot; }

    List<SnapshotVersion> getSnapshotVersions() {
        return snapshotVersions == null ? new ArrayList<SnapshotVersion>() : snapshotVersions;
    }

    void addSnapshotVersion(SnapshotVersion sv) {
        if (snapshotVersions == null) {
            snapshotVersions = new ArrayList<SnapshotVersion>();
        }
        snapshotVersions.add(sv);
    }
}


class Snapshot {
    private int buildNumber;
    private String timestamp;

    int getBuildNumber() { return buildNumber; }
    void setBuildNumber(int buildNumber) { this.buildNumber = buildNumber; }
    String getTimestamp() { return timestamp; }
    void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}


class SnapshotVersion {
    private String classifier = "";
    private String extension = "pom";
    private String version;
    private String updated;

    String getClassifier() { return classifier; }
    void setClassifier(String classifier) { this.classifier = classifier; }
    String getExtension() { return extension; }
    void setExtension(String extension) { this.extension = extension; }
    String getVersion() { return version; }
    void setVersion(String version) { this.version = version; }
    String getUpdated() { return updated; }
    void setUpdated(String updated) { this.updated = updated; }
}







class BuildPlugin {
    private String artifactId;
    private String goalPrefix;

    BuildPlugin(String artifactId, String goalPrefix) {
        this.artifactId = artifactId;
        this.goalPrefix = goalPrefix;
    }

    String getArtifactId() { return artifactId; }
    String getGoalPrefix() { return goalPrefix; }
}


class PluginManagement {
    private List<BuildPlugin> plugins;

    PluginManagement(List<BuildPlugin> plugins) { this.plugins = plugins; }

    List<BuildPlugin> getPlugins() { return plugins; }
}


class Build {
    private List<BuildPlugin> plugins;
    private PluginManagement pluginManagement;

    List<BuildPlugin> getPlugins() { return plugins; }
    void setPlugins(List<BuildPlugin> plugins) { this.plugins = plugins; }
    PluginManagement getPluginManagement() { return pluginManagement; }
    void setPluginManagement(PluginManagement pm) { this.pluginManagement = pm; }
}


class Model {
    private String name;
    private String packaging = "jar";
    private Build build;

    String getName() { return name; }
    void setName(String name) { this.name = name; }
    String getPackaging() { return packaging; }
    void setPackaging(String packaging) { this.packaging = packaging; }
    Build getBuild() { return build; }
    void setBuild(Build build) { this.build = build; }
}


class XmlPullParserException extends Exception {
    private static final long serialVersionUID = 1L;

    XmlPullParserException(String message) { super(message); }
}










class MavenXpp3Reader {
    Model read(Reader reader) throws IOException, XmlPullParserException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = reader.read()) != -1) {
            sb.append((char) c);
        }
        String xml = sb.toString();
        if (xml.indexOf("<project") < 0) {
            throw new XmlPullParserException("not a POM: missing <project> root element");
        }
        Model model = new Model();
        model.setName(tag(xml, "name"));
        String packaging = tag(xml, "packaging");
        if (packaging != null) {
            model.setPackaging(packaging);
        }
        String goalPrefix = tag(xml, "goalPrefix");
        String pluginArtifactId = tag(xml, "pluginArtifactId");
        if (goalPrefix != null && pluginArtifactId != null) {
            Build build = new Build();
            List<BuildPlugin> plugins = new ArrayList<BuildPlugin>();
            plugins.add(new BuildPlugin(pluginArtifactId, goalPrefix));
            build.setPlugins(plugins);
            model.setBuild(build);
        }
        return model;
    }

    private String tag(String xml, String name) {
        String open = "<" + name + ">";
        String close = "</" + name + ">";
        int s = xml.indexOf(open);
        if (s < 0) {
            return null;
        }
        s += open.length();
        int e = xml.indexOf(close, s);
        return e < 0 ? null : xml.substring(s, e);
    }
}







class XmlStreamReader extends InputStreamReader {
    XmlStreamReader(InputStream in) throws IOException {
        super(in, "UTF-8");
    }
}


class IOUtils {
    static void closeQuietly(InputStream in) {
        if (in != null) {
            try {
                in.close();
            } catch (IOException ignored) {
                
            }
        }
    }
}






class StringUtils {
    static String stripStart(String str, String stripChars) {
        if (str == null) {
            return null;
        }
        int start = 0;
        while (start < str.length() && stripChars.indexOf(str.charAt(start)) >= 0) {
            start++;
        }
        return str.substring(start);
    }

    static String stripEnd(String str, String stripChars) {
        if (str == null) {
            return null;
        }
        int end = str.length();
        while (end > 0 && stripChars.indexOf(str.charAt(end - 1)) >= 0) {
            end--;
        }
        return str.substring(0, end);
    }

    static String removeStart(String str, String remove) {
        if (str == null || remove == null) {
            return str;
        }
        return str.startsWith(remove) ? str.substring(remove.length()) : str;
    }

    static String removeEnd(String str, String remove) {
        if (str == null || remove == null) {
            return str;
        }
        return str.endsWith(remove) ? str.substring(0, str.length() - remove.length()) : str;
    }
}








class VersionComparator implements Comparator<String> {
    @Override
    public int compare(String v1, String v2) {
        String[] a = v1.replace("-SNAPSHOT", "").split("\\.");
        String[] b = v2.replace("-SNAPSHOT", "").split("\\.");
        int len = Math.max(a.length, b.length);
        for (int i = 0; i < len; i++) {
            int ai = i < a.length ? toInt(a[i]) : 0;
            int bi = i < b.length ? toInt(b[i]) : 0;
            if (ai != bi) {
                return ai < bi ? -1 : 1;
            }
        }
        boolean aSnap = v1.endsWith("-SNAPSHOT");
        boolean bSnap = v2.endsWith("-SNAPSHOT");
        if (aSnap == bSnap) {
            return 0;
        }
        return aSnap ? -1 : 1;
    }

    private int toInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}









class Maven3 {
    static void addSnapshotVersion(List<SnapshotVersion> snapshotVersions, Artifact artifact, String updated) {
        SnapshotVersion sv = new SnapshotVersion();
        sv.setClassifier("");
        sv.setExtension(artifact.getType());
        sv.setVersion(artifact.getVersion());
        sv.setUpdated(updated);
        snapshotVersions.add(sv);
    }

    static void addSnapshotVersions(Versioning versioning, List<SnapshotVersion> snapshotVersions) {
        for (SnapshotVersion sv : snapshotVersions) {
            versioning.addSnapshotVersion(sv);
        }
    }
}








public class method_1_mrm_claude extends ArtifactStore {

    
    private final Map<String, Map<String, Map<String, Map<Artifact, Content>>>> contents =
            new HashMap<String, Map<String, Map<String, Map<Artifact, Content>>>>();

    




    public void set(Artifact artifact, byte[] bytes, long lastModified) {
        Map<String, Map<String, Map<Artifact, Content>>> byArtifact = contents.get(artifact.getGroupId());
        if (byArtifact == null) {
            byArtifact = new HashMap<String, Map<String, Map<Artifact, Content>>>();
            contents.put(artifact.getGroupId(), byArtifact);
        }
        Map<String, Map<Artifact, Content>> byVersion = byArtifact.get(artifact.getArtifactId());
        if (byVersion == null) {
            byVersion = new HashMap<String, Map<Artifact, Content>>();
            byArtifact.put(artifact.getArtifactId(), byVersion);
        }
        Map<Artifact, Content> files = byVersion.get(artifact.getVersion());
        if (files == null) {
            files = new HashMap<Artifact, Content>();
            byVersion.put(artifact.getVersion(), files);
        }
        files.put(artifact, new Content(bytes, lastModified));
    }

    @Override
    public Set<String> getArtifactIds(String groupId) {
        Map<String, Map<String, Map<Artifact, Content>>> byArtifact = contents.get(groupId);
        return byArtifact == null ? null : byArtifact.keySet();
    }

    @Override
    public Set<String> getVersions(String groupId, String artifactId) {
        Map<String, Map<String, Map<Artifact, Content>>> byArtifact = contents.get(groupId);
        if (byArtifact == null) {
            return null;
        }
        Map<String, Map<Artifact, Content>> byVersion = byArtifact.get(artifactId);
        return byVersion == null ? null : byVersion.keySet();
    }

    @Override
    public InputStream get(Artifact artifact) throws IOException, ArtifactNotFoundException {
        Content content = find(artifact);
        if (content == null) {
            throw new ArtifactNotFoundException(artifact);
        }
        return new ByteArrayInputStream(content.getBytes());
    }

    @Override
    public long getLastModified(Artifact artifact) throws IOException, ArtifactNotFoundException {
        Content content = find(artifact);
        if (content == null) {
            throw new ArtifactNotFoundException(artifact);
        }
        return content.getLastModified();
    }

    private Content find(Artifact artifact) {
        Map<String, Map<String, Map<Artifact, Content>>> byArtifact = contents.get(artifact.getGroupId());
        if (byArtifact == null) {
            return null;
        }
        Map<String, Map<Artifact, Content>> byVersion = byArtifact.get(artifact.getArtifactId());
        if (byVersion == null) {
            return null;
        }
        Map<Artifact, Content> files = byVersion.get(artifact.getVersion());
        return files == null ? null : files.get(artifact);
    }

    





    private boolean setPluginGoalPrefixFromConfiguration(Plugin plugin, List<BuildPlugin> buildPlugins) {
        for (BuildPlugin bp : buildPlugins) {
            if (bp.getArtifactId() != null && bp.getArtifactId().equals(plugin.getArtifactId())
                    && bp.getGoalPrefix() != null) {
                plugin.setPrefix(bp.getGoalPrefix());
                return true;
            }
        }
        return false;
    }

    
    public synchronized Metadata getMetadata( String path )
        throws IOException, MetadataNotFoundException
    {
        Metadata metadata = new Metadata();
        boolean foundMetadata = false;
        path = StringUtils.stripEnd( StringUtils.stripStart( path, "/" ), "/" );
        String groupId = path.replace( '/', '.' );
        Set<String> pluginArtifactIds = getArtifactIds( groupId );
        if ( pluginArtifactIds != null )
        {
            List<Plugin> plugins = new ArrayList<Plugin>();
            for ( String artifactId : pluginArtifactIds )
            {
                Set<String> pluginVersions = getVersions( groupId, artifactId );
                if ( pluginVersions == null || pluginVersions.isEmpty() )
                {
                    continue;
                }
                String[] versions = pluginVersions.toArray( new String[pluginVersions.size()] );
                Arrays.sort( versions, new VersionComparator() );
                MavenXpp3Reader reader = new MavenXpp3Reader();
                for ( int j = versions.length - 1; j >= 0; j-- )
                {
                    InputStream inputStream = null;
                    try
                    {
                        inputStream = get( new Artifact( groupId, artifactId, versions[j], "pom" ) );
                        Model model = reader.read( new XmlStreamReader( inputStream ) );
                        if ( model == null || !"maven-plugin".equals( model.getPackaging() ) )
                        {
                            continue;
                        }
                        Plugin plugin = new Plugin();
                        plugin.setArtifactId( artifactId );
                        plugin.setName( model.getName() );
                        
                        
                        
                        boolean havePrefix = false;
                        final Build build = model.getBuild();
                        if ( build != null && build.getPlugins() != null )
                        {
                            havePrefix = setPluginGoalPrefixFromConfiguration( plugin, build.getPlugins() );
                        }
                        if ( !havePrefix && build != null && build.getPluginManagement() != null
                            && build.getPluginManagement().getPlugins() != null )
                        {
                            havePrefix = setPluginGoalPrefixFromConfiguration( plugin,
                                                                               build.getPluginManagement().getPlugins() );
                        }
                        if ( !havePrefix && artifactId.startsWith( "maven-" ) && artifactId.endsWith( "-plugin" ) )
                        {
                            plugin.setPrefix(
                                StringUtils.removeStart( StringUtils.removeEnd( artifactId, "-plugin" ), "maven-" ) );
                            havePrefix = true;
                        }
                        if ( !havePrefix && artifactId.endsWith( "-maven-plugin" ) )
                        {
                            plugin.setPrefix( StringUtils.removeEnd( artifactId, "-maven-plugin" ) );
                            havePrefix = true;
                        }
                        if ( !havePrefix )
                        {
                            plugin.setPrefix( artifactId );
                        }
                        plugins.add( plugin );
                        foundMetadata = true;
                        break;
                    }
                    catch ( ArtifactNotFoundException e )
                    {
                        
                    }
                    catch ( XmlPullParserException e )
                    {
                        
                    }
                    finally
                    {
                        IOUtils.closeQuietly( inputStream );
                    }
                }
            }
            if ( !plugins.isEmpty() )
            {
                metadata.setPlugins( plugins );
            }
        }
        int index = path.lastIndexOf( '/' );
        groupId = ( index == -1 ? groupId : groupId.substring( 0, index ) ).replace( '/', '.' );
        String artifactId = ( index == -1 ? null : path.substring( index + 1 ) );
        if ( artifactId != null )
        {
            Set<String> artifactVersions = getVersions( groupId, artifactId );
            if ( artifactVersions != null && !artifactVersions.isEmpty() )
            {
                metadata.setGroupId( groupId );
                metadata.setArtifactId( artifactId );
                Versioning versioning = new Versioning();
                List<String> versions = new ArrayList<String>( artifactVersions );
                Collections.sort( versions, new VersionComparator() ); 
                long lastUpdated = 0;
                for ( String version : versions )
                {
                    try
                    {
                        long lastModified = getLastModified( new Artifact( groupId, artifactId, version, "pom" ) );
                        versioning.addVersion( version );
                        if ( lastModified >= lastUpdated )
                        {
                            lastUpdated = lastModified;
                            versioning.setLastUpdatedTimestamp( new Date( lastModified ) );
                            versioning.setLatest( version );
                            if ( !version.endsWith( "-SNAPSHOT" ) )
                            {
                                versioning.setRelease( version );
                            }
                        }
                    }
                    catch ( ArtifactNotFoundException e )
                    {
                        
                    }
                }
                metadata.setVersioning( versioning );
                foundMetadata = true;
            }
        }

        int index2 = index == -1 ? -1 : path.lastIndexOf( '/', index - 1 );
        groupId = index2 == -1 ? groupId : groupId.substring( 0, index2 ).replace( '/', '.' );
        artifactId = index2 == -1 ? artifactId : path.substring( index2 + 1, index );
        String version = index2 == -1 ? null : path.substring( index + 1 );
        if ( version != null && version.endsWith( "-SNAPSHOT" ) )
        {
            Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get( groupId );
            Map<String, Map<Artifact, Content>> versionMap = ( artifactMap == null ? null : artifactMap.get( artifactId ) );
            Map<Artifact, Content> filesMap = ( versionMap == null ? null : versionMap.get( version ) );
            if ( filesMap != null )
            {
                List<SnapshotVersion> snapshotVersions = new ArrayList<SnapshotVersion>();
                int maxBuildNumber = 0;
                long lastUpdated = 0;
                String timestamp = null;
                boolean found = false;
                for ( final Map.Entry<Artifact, Content> entry : filesMap.entrySet() )
                {
                    final Artifact artifact = entry.getKey();
                    final Content content = entry.getValue();
                    SimpleDateFormat fmt = new SimpleDateFormat( "yyyyMMddHHmmss" );
                    fmt.setTimeZone( TimeZone.getTimeZone( "GMT" ) );
                    String lastUpdatedTime = fmt.format( new Date( content.getLastModified() ) );
                    try
                    {
                        Maven3.addSnapshotVersion( snapshotVersions, artifact, lastUpdatedTime );
                    }
                    catch ( LinkageError e )
                    {
                        
                    }
                    if ( "pom".equals( artifact.getType() ) )
                    {
                        if ( artifact.getBuildNumber() != null
                            && maxBuildNumber < artifact.getBuildNumber().intValue() )
                        {
                            maxBuildNumber = artifact.getBuildNumber().intValue();
                            timestamp = artifact.getTimestampString();
                        }
                        else
                        {
                            maxBuildNumber = Math.max( 1, maxBuildNumber );
                        }
                        lastUpdated = Math.max( lastUpdated, content.getLastModified() );
                        found = true;
                    }
                }

                if ( !snapshotVersions.isEmpty() || found )
                {
                    Versioning versioning = metadata.getVersioning();
                    if ( versioning == null )
                    {
                        versioning = new Versioning();
                    }
                    metadata.setGroupId( groupId );
                    metadata.setArtifactId( artifactId );
                    metadata.setVersion( version );
                    try
                    {
                        Maven3.addSnapshotVersions( versioning, snapshotVersions );
                    }
                    catch ( LinkageError e )
                    {
                        
                    }
                    if ( maxBuildNumber > 0 )
                    {
                        Snapshot snapshot = new Snapshot();
                        snapshot.setBuildNumber( maxBuildNumber );
                        snapshot.setTimestamp( timestamp );
                        versioning.setSnapshot( snapshot );
                    }
                    versioning.setLastUpdatedTimestamp( new Date( lastUpdated ) );
                    metadata.setVersioning( versioning );
                    foundMetadata = true;
                }
            }

        }
        if ( !foundMetadata )
        {
            throw new MetadataNotFoundException( path );
        }
        return metadata;
    }
    

    







    public static void main(String[] args) throws Exception {
        method_1_mrm_claude store = new method_1_mrm_claude();

        
        String configuredPluginPom =
                "<project><name>Widget Plugin</name><packaging>maven-plugin</packaging>"
              + "<pluginArtifactId>widget-maven-plugin</pluginArtifactId>"
              + "<goalPrefix>widget</goalPrefix></project>";
        store.set(new Artifact("com.example.plugins", "widget-maven-plugin", "1.0", "pom"),
                configuredPluginPom.getBytes("UTF-8"), 1000L);

        
        
        String conventionPluginPom =
                "<project><name>Gizmo Plugin</name><packaging>maven-plugin</packaging></project>";
        store.set(new Artifact("com.example.plugins", "maven-gizmo-plugin", "2.0", "pom"),
                conventionPluginPom.getBytes("UTF-8"), 2000L);

        
        String libPom = "<project><name>My Library</name><packaging>jar</packaging></project>";
        store.set(new Artifact("com.example", "my-lib", "1.0", "pom"), libPom.getBytes("UTF-8"), 500L);
        store.set(new Artifact("com.example", "my-lib", "2.0", "pom"), libPom.getBytes("UTF-8"), 1500L);

        Artifact snapPom = new Artifact("com.example", "my-lib", "3.0-SNAPSHOT", "pom");
        snapPom.setBuildNumber(Integer.valueOf(7));
        snapPom.setTimestampString("20200601.120000");
        store.set(snapPom, libPom.getBytes("UTF-8"), 3000L);

        System.out.println("=== Scenario 1: group-level metadata, plugin prefix discovery ===");
        Metadata pluginsMeta = store.getMetadata("com/example/plugins");
        System.out.println("  plugins discovered: " + pluginsMeta.getPlugins().size());
        for (Plugin p : pluginsMeta.getPlugins()) {
            System.out.println("    artifactId=" + p.getArtifactId()
                    + "  name=" + p.getName()
                    + "  prefix=" + p.getPrefix());
        }
        System.out.println("  (widget-maven-plugin took its prefix from the POM goalPrefix;");
        System.out.println("   maven-gizmo-plugin took its prefix from the maven-*-plugin fallback)");

        System.out.println();
        System.out.println("=== Scenario 2: artifact-level metadata, version listing ===");
        Metadata libMeta = store.getMetadata("com/example/my-lib");
        System.out.println("  groupId    = " + libMeta.getGroupId());
        System.out.println("  artifactId = " + libMeta.getArtifactId());
        System.out.println("  versions   = " + libMeta.getVersioning().getVersions());
        System.out.println("  latest     = " + libMeta.getVersioning().getLatest());
        System.out.println("  release    = " + libMeta.getVersioning().getRelease()
                + "   (the -SNAPSHOT was correctly skipped for release)");
        System.out.println("  lastUpdated= " + libMeta.getVersioning().getLastUpdated());

        System.out.println();
        System.out.println("=== Scenario 3: SNAPSHOT metadata ===");
        Metadata snapMeta = store.getMetadata("com/example/my-lib/3.0-SNAPSHOT");
        System.out.println("  groupId    = " + snapMeta.getGroupId());
        System.out.println("  artifactId = " + snapMeta.getArtifactId());
        System.out.println("  version    = " + snapMeta.getVersion());
        System.out.println("  snapshot buildNumber = " + snapMeta.getVersioning().getSnapshot().getBuildNumber());
        System.out.println("  snapshot timestamp   = " + snapMeta.getVersioning().getSnapshot().getTimestamp());
        System.out.println("  snapshotVersions     = " + snapMeta.getVersioning().getSnapshotVersions().size());
        for (SnapshotVersion sv : snapMeta.getVersioning().getSnapshotVersions()) {
            System.out.println("    version=" + sv.getVersion()
                    + " extension=" + sv.getExtension()
                    + " updated=" + sv.getUpdated());
        }

        System.out.println();
        System.out.println("=== Scenario 4: unknown path (MetadataNotFoundException) ===");
        try {
            store.getMetadata("does/not/exist");
            System.out.println("  ERROR: expected MetadataNotFoundException was not thrown");
        } catch (MetadataNotFoundException e) {
            System.out.println("  caught expected MetadataNotFoundException: " + e.getMessage());
        }
    }
}
