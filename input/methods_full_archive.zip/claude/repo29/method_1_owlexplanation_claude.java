

































import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_1_owlexplanation_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== BlackBoxExplanationGenerator2.computeExplanation(E) - repository-aware reconstruction ===");
      System.out.println("Repository : matthewhorridge/owlexplanation @ 439c5ca67835f5e421adde725e4e8a3bcd760ac8");
      System.out.println("OWL API / telemetry : lightweight adaptations (both artifacts unavailable offline)");
      System.out.println();

      OWLDataFactory df = new OWLDataFactoryImpl();
      OWLClass person = df.getOWLClass(IRI.create("http://example.org/onto#Person"));
      OWLClass agent = df.getOWLClass(IRI.create("http://example.org/onto#Agent"));
      OWLClass mortal = df.getOWLClass(IRI.create("http://example.org/onto#Mortal"));

      OWLAxiom personSubAgent = df.getOWLSubClassOfAxiom(person, agent);
      OWLAxiom agentSubMortal = df.getOWLSubClassOfAxiom(agent, mortal);
      OWLAxiom personSubMortal = df.getOWLSubClassOfAxiom(person, mortal); 

      Set<OWLAxiom> ontologyAxioms = new HashSet<OWLAxiom>();
      ontologyAxioms.add(personSubAgent);
      ontologyAxioms.add(agentSubMortal);

      
      
      
      
      
      
      System.out.println("--- Scenario 1: entailment already present in workingAxioms (quick exit) ---");
      Set<OWLAxiom> withDirectAssertion = new HashSet<OWLAxiom>(ontologyAxioms);
      withDirectAssertion.add(personSubMortal);
      RecordingStrategies strategies1 = new RecordingStrategies();
      BlackBoxExplanationGenerator2<OWLAxiom> gen1 = new BlackBoxExplanationGenerator2<OWLAxiom>(
            withDirectAssertion, new SubsumptionCheckerFactory(), strategies1, strategies1, null);
      gen1.setModuleForTesting(withDirectAssertion);
      Explanation<OWLAxiom> result1 = gen1.computeExplanationForTesting(personSubMortal);
      System.out.println("result             : " + result1.toString().replace("\n", " | "));
      System.out.println("justification      : " + result1.getAxioms());
      System.out.println("expansion invoked  : " + strategies1.expansionCalls);
      System.out.println("contraction invoked: " + strategies1.contractionCalls);
      System.out.println("telemetry 'entailed' recorded true : "
            + TelemetryTransmitter.getTransmitter().lastBooleanMeasurement("entailed"));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 2: entailment derived through expansion + contraction ---");
      RecordingStrategies strategies2 = new RecordingStrategies();
      BlackBoxExplanationGenerator2<OWLAxiom> gen2 = new BlackBoxExplanationGenerator2<OWLAxiom>(
            ontologyAxioms, new SubsumptionCheckerFactory(), strategies2, strategies2, null);
      gen2.setModuleForTesting(ontologyAxioms);
      Explanation<OWLAxiom> result2 = gen2.computeExplanationForTesting(personSubMortal);
      System.out.println("result             : " + result2.toString().replace("\n", " | "));
      System.out.println("justification      : " + result2.getAxioms());
      System.out.println("expansion invoked  : " + strategies2.expansionCalls);
      System.out.println("contraction invoked: " + strategies2.contractionCalls);
      System.out.println("justification == expected {personSubAgent, agentSubMortal} : "
            + result2.getAxioms().equals(ontologyAxioms));
      System.out.println("telemetry 'justification size' recorded : "
            + TelemetryTransmitter.getTransmitter().lastIntMeasurement("justification size"));
      System.out.println("telemetry timing 'time' recorded        : "
            + TelemetryTransmitter.getTransmitter().hasTiming("time"));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: entailment does not hold (expansion finds nothing) ---");
      OWLClass unrelated = df.getOWLClass(IRI.create("http://example.org/onto#Unrelated"));
      OWLAxiom notEntailed = df.getOWLSubClassOfAxiom(unrelated, mortal);
      RecordingStrategies strategies3 = new RecordingStrategies();
      BlackBoxExplanationGenerator2<OWLAxiom> gen3 = new BlackBoxExplanationGenerator2<OWLAxiom>(
            ontologyAxioms, new SubsumptionCheckerFactory(), strategies3, strategies3, null);
      gen3.setModuleForTesting(ontologyAxioms);
      Explanation<OWLAxiom> result3 = gen3.computeExplanationForTesting(notEntailed);
      System.out.println("result is empty    : " + result3.isEmpty());
      System.out.println("expansion invoked  : " + strategies3.expansionCalls);
      System.out.println("contraction invoked (must be 0, expansion was empty) : " + strategies3.contractionCalls);
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 4: cancelled progress monitor ---");
      RecordingStrategies strategies4 = new RecordingStrategies();
      CancellingProgressMonitor<OWLAxiom> cancelling = new CancellingProgressMonitor<OWLAxiom>();
      BlackBoxExplanationGenerator2<OWLAxiom> gen4 = new BlackBoxExplanationGenerator2<OWLAxiom>(
            ontologyAxioms, new SubsumptionCheckerFactory(), strategies4, strategies4, cancelling);
      gen4.setModuleForTesting(ontologyAxioms);
      try
      {
         gen4.computeExplanationForTesting(personSubMortal);
         System.out.println("!! expected ExplanationGeneratorInterruptedException");
      }
      catch (ExplanationGeneratorInterruptedException e)
      {
         System.out.println("ExplanationGeneratorInterruptedException correctly thrown");
         System.out.println("telemetry 'interrupted' recorded true : "
               + TelemetryTransmitter.getTransmitter().lastBooleanMeasurement("interrupted"));
      }
      System.out.println();

      System.out.println("=== done ===");
   }
}














class BlackBoxExplanationGenerator2<E>
{
   private ExpansionStrategy expansionStrategy;

   private ContractionStrategy contractionStrategy;

   private EntailmentCheckerFactory<E> checkerFactory;

   private Set<OWLAxiom> workingAxioms;

   private Set<OWLAxiom> module;

   private ExplanationProgressMonitor<E> progressMonitor;

   








   public BlackBoxExplanationGenerator2(Set<? extends OWLAxiom> axioms, EntailmentCheckerFactory<E> checkerFactory, ExpansionStrategy expansionStrategy, ContractionStrategy contractionStrategy, ExplanationProgressMonitor<E> progressMonitor)
   {
      workingAxioms = new HashSet<OWLAxiom>(axioms);
      this.checkerFactory = checkerFactory;
      this.expansionStrategy = expansionStrategy;
      this.contractionStrategy = contractionStrategy;
      if (progressMonitor != null)
      {
         this.progressMonitor = progressMonitor;
      }
      else
      {
         this.progressMonitor = new NullExplanationProgressMonitor<E>();
      }
   }

   


   void setModuleForTesting(Set<OWLAxiom> module)
   {
      this.module = module;
   }

   

   Explanation<E> computeExplanationForTesting(E entailment)
   {
      return computeExplanation(entailment);
   }


// ORIGINAL CODESEARCHNET METHOD — START

    




    protected Explanation<E> computeExplanation(E entailment) {

        TelemetryTimer justificationTimer = new TelemetryTimer();

        TelemetryInfo findOneInfo = new DefaultTelemetryInfo("findone", justificationTimer);
        final TelemetryTransmitter transmitter = TelemetryTransmitter.getTransmitter();
        transmitter.beginTransmission(findOneInfo);

        Explanation<E> result = Explanation.getEmptyExplanation(entailment);

        boolean entailed = false;

        try {
            justificationTimer.start();

            
            if (entailment instanceof OWLAxiom && workingAxioms.contains((OWLAxiom) entailment)) {
                entailed = true;
                result = new Explanation<E>(entailment, Collections.singleton((OWLAxiom) entailment));
            }
            else {
                if (progressMonitor.isCancelled()) {
                    throw new ExplanationGeneratorInterruptedException();
                }
                EntailmentChecker<E> checker = checkerFactory.createEntailementChecker(entailment);
                
                Set<OWLAxiom> expandedAxioms = doExpansion(checker);

                if (!expandedAxioms.isEmpty()) {
                    
                    Set<OWLAxiom> justificationAxioms = doContraction(checker, expandedAxioms);

                    result = new Explanation<E>(entailment, justificationAxioms);
                }

            }
            justificationTimer.stop();

        }
        catch (TimeOutException e) {
            transmitter.recordMeasurement(findOneInfo, "reasoner time out", true);
            throw e;
        }
        catch (ExplanationGeneratorInterruptedException e) {
            transmitter.recordMeasurement(findOneInfo, "interrupted", true);
            throw e;
        }
        catch (RuntimeException e) {
            transmitter.recordException(findOneInfo, e);
            throw e;
        }
        finally {
            transmitter.recordMeasurement(findOneInfo, "input size", module.size());
            transmitter.recordMeasurement(findOneInfo, "entailed", entailed);
            transmitter.recordMeasurement(findOneInfo, "self justification", result.isJustificationEntailment());
            transmitter.recordMeasurement(findOneInfo, "justification size", result.getSize());
            transmitter.recordTiming(findOneInfo, "time", justificationTimer);
            recordJustification(entailment, findOneInfo, result);
            transmitter.endTransmission(findOneInfo);
        }


        return result;
    }

// ORIGINAL CODESEARCHNET METHOD — END


   private void recordJustification(E entailment, TelemetryInfo findOneInfo, Explanation<E> result)
   {
      TelemetryTransmitter transmitter = TelemetryTransmitter.getTransmitter();
      if (!result.isEmpty())
      {
         if (entailment instanceof OWLAxiom)
         {
            ExplanationTelemetryWrapper telemetryObject = new ExplanationTelemetryWrapper((Explanation<OWLAxiom>) (Explanation<?>) result);
            transmitter.recordObject(findOneInfo, "justification", ".owl.xml", telemetryObject);
         }
      }
   }

   private Set<OWLAxiom> doContraction(EntailmentChecker<E> checker, Set<OWLAxiom> expandedAxioms)
   {
      TelemetryTransmitter transmitter = TelemetryTransmitter.getTransmitter();
      TelemetryTimer contractionTimer = new TelemetryTimer();
      TelemetryInfo contractionInfo = new DefaultTelemetryInfo("contraction", contractionTimer);
      Set<OWLAxiom> justificationAxioms;
      try
      {
         contractionTimer.start();
         transmitter.beginTransmission(contractionInfo);
         justificationAxioms = contractionStrategy.doPruning(expandedAxioms, checker, progressMonitor);
         contractionTimer.stop();
         transmitter.recordMeasurement(contractionInfo, "contraction strategy", contractionStrategy.getClass().getName());
         transmitter.recordMeasurement(contractionInfo, "contraction size", justificationAxioms.size());
         transmitter.recordTiming(contractionInfo, "contraction time", contractionTimer);
         transmitter.recordMeasurement(contractionInfo, "contraction entailment check count", contractionStrategy.getNumberOfSteps());

      }
      finally
      {
         transmitter.endTransmission(contractionInfo);
      }
      return justificationAxioms;
   }

   private Set<OWLAxiom> doExpansion(EntailmentChecker<E> checker)
   {
      TelemetryTransmitter transmitter = TelemetryTransmitter.getTransmitter();
      TelemetryTimer expansionTimer = new TelemetryTimer();
      TelemetryInfo expansionInfo = new DefaultTelemetryInfo("expansion", expansionTimer);
      Set<OWLAxiom> expandedAxioms;
      try
      {
         transmitter.beginTransmission(expansionInfo);
         expansionTimer.start();
         expandedAxioms = expansionStrategy.doExpansion(module, checker, progressMonitor);
         expansionTimer.stop();
         transmitter.recordMeasurement(expansionInfo, "expansion strategy", expansionStrategy.getClass().getName());
         transmitter.recordMeasurement(expansionInfo, "expansion size", expandedAxioms.size());
         transmitter.recordTiming(expansionInfo, "expansion time", expansionTimer);
         transmitter.recordMeasurement(expansionInfo, "expansion entailment check count", expansionStrategy.getNumberOfSteps());
      }
      finally
      {
         transmitter.endTransmission(expansionInfo);
      }
      return expandedAxioms;
   }

   protected Set<OWLAxiom> extractModule(Set<OWLAxiom> axioms, EntailmentChecker<E> checker)
   {
      return checker.getModule(axioms);
   }
}








interface EntailmentChecker<E>
{
   boolean isEntailed(Set<OWLAxiom> axioms);

   Set<OWLAxiom> getModule(Set<OWLAxiom> axioms);

   String getModularisationTypeDescription();
}


interface EntailmentCheckerFactory<E>
{
   EntailmentChecker<E> createEntailementChecker(E entailment);
}


interface ExpansionStrategy
{
   <E> Set<OWLAxiom> doExpansion(Set<OWLAxiom> module, EntailmentChecker<E> checker, ExplanationProgressMonitor<E> progressMonitor);

   int getNumberOfSteps();
}


interface ContractionStrategy
{
   <E> Set<OWLAxiom> doPruning(Set<OWLAxiom> expandedAxioms, EntailmentChecker<E> checker, ExplanationProgressMonitor<E> progressMonitor);

   int getNumberOfSteps();
}


interface ExplanationProgressMonitor<E>
{
   void foundExplanation(Object explanationGenerator, Explanation<E> explanation, Set<Explanation<E>> allFoundExplanations);

   boolean isCancelled();
}


class NullExplanationProgressMonitor<E> implements ExplanationProgressMonitor<E>
{
   public void foundExplanation(Object explanationGenerator, Explanation<E> explanation, Set<Explanation<E>> allFoundExplanations)
   {
      
   }

   public boolean isCancelled()
   {
      return false;
   }
}


class CancellingProgressMonitor<E> implements ExplanationProgressMonitor<E>
{
   public void foundExplanation(Object explanationGenerator, Explanation<E> explanation, Set<Explanation<E>> allFoundExplanations)
   {
   }

   public boolean isCancelled()
   {
      return true;
   }
}


class ExplanationGeneratorInterruptedException extends RuntimeException
{
}


class ExplanationException extends Exception
{
   ExplanationException(String message)
   {
      super(message);
   }

   ExplanationException(Throwable cause)
   {
      super(cause);
   }
}











class RecordingStrategies implements ExpansionStrategy, ContractionStrategy
{
   int expansionCalls = 0;
   int contractionCalls = 0;
   private int expansionSteps = 0;
   private int contractionSteps = 0;

   public <E> Set<OWLAxiom> doExpansion(Set<OWLAxiom> module, EntailmentChecker<E> checker, ExplanationProgressMonitor<E> progressMonitor)
   {
      expansionCalls++;
      expansionSteps++;
      if (checker.isEntailed(module))
      {
         return new HashSet<OWLAxiom>(module);
      }
      return Collections.emptySet();
   }

   public <E> Set<OWLAxiom> doPruning(Set<OWLAxiom> expandedAxioms, EntailmentChecker<E> checker, ExplanationProgressMonitor<E> progressMonitor)
   {
      contractionCalls++;
      contractionSteps++;
      
      
      Set<OWLAxiom> current = new HashSet<OWLAxiom>(expandedAxioms);
      for (OWLAxiom ax : new HashSet<OWLAxiom>(expandedAxioms))
      {
         Set<OWLAxiom> without = new HashSet<OWLAxiom>(current);
         without.remove(ax);
         if (checker.isEntailed(without))
         {
            current = without;
         }
      }
      return current;
   }

   public int getNumberOfSteps()
   {
      return expansionSteps + contractionSteps;
   }
}







class SubsumptionCheckerFactory implements EntailmentCheckerFactory<OWLAxiom>
{
   public EntailmentChecker<OWLAxiom> createEntailementChecker(final OWLAxiom entailment)
   {
      return new EntailmentChecker<OWLAxiom>()
      {
         public boolean isEntailed(Set<OWLAxiom> axioms)
         {
            Map<OWLClass, Set<OWLClass>> direct = new HashMap<OWLClass, Set<OWLClass>>();
            for (OWLAxiom ax : axioms)
            {
               OWLClass sub = ax.getSubClass();
               OWLClass sup = ax.getSuperClass();
               Set<OWLClass> supers = direct.get(sub);
               if (supers == null)
               {
                  supers = new HashSet<OWLClass>();
                  direct.put(sub, supers);
               }
               supers.add(sup);
            }
            OWLClass start = entailment.getSubClass();
            OWLClass target = entailment.getSuperClass();
            Set<OWLClass> visited = new HashSet<OWLClass>();
            List<OWLClass> frontier = new ArrayList<OWLClass>();
            frontier.add(start);
            visited.add(start);
            while (!frontier.isEmpty())
            {
               OWLClass current = frontier.remove(frontier.size() - 1);
               if (current.equals(target))
               {
                  return true;
               }
               Set<OWLClass> supers = direct.get(current);
               if (supers != null)
               {
                  for (OWLClass s : supers)
                  {
                     if (visited.add(s))
                     {
                        frontier.add(s);
                     }
                  }
               }
            }
            return start.equals(target);
         }

         public Set<OWLAxiom> getModule(Set<OWLAxiom> axioms)
         {
            return new HashSet<OWLAxiom>(axioms);
         }

         public String getModularisationTypeDescription()
         {
            return "driver-subsumption-checker";
         }
      };
   }
}











class TelemetryTimer
{
   private long start;
   private long elapsed;
   private boolean running;

   public void reset()
   {
      start = 0;
      elapsed = 0;
      running = false;
   }

   public void start()
   {
      start = System.nanoTime();
      running = true;
   }

   public void stop()
   {
      if (running)
      {
         elapsed += System.nanoTime() - start;
         running = false;
      }
   }

   public long getElapsedMillis()
   {
      return elapsed / 1_000_000L;
   }
}


interface TelemetryInfo
{
   String getName();

   TelemetryTimer getTimer();
}


class DefaultTelemetryInfo implements TelemetryInfo
{
   private final String name;
   private final TelemetryTimer timer;

   public DefaultTelemetryInfo(String name)
   {
      this(name, null);
   }

   public DefaultTelemetryInfo(String name, TelemetryTimer timer)
   {
      this.name = name;
      this.timer = timer;
   }

   public String getName()
   {
      return name;
   }

   public TelemetryTimer getTimer()
   {
      return timer;
   }
}


interface TelemetryObject
{
   String getPreferredSerialisedName();

   boolean isSerialisedAsXML();

   void serialise(java.io.OutputStream outputStream) throws java.io.IOException;
}








class TelemetryTransmitter
{
   private static final TelemetryTransmitter INSTANCE = new TelemetryTransmitter();

   private final Map<String, Object> lastMeasurements = new HashMap<String, Object>();
   private final Map<String, Boolean> timingsRecorded = new HashMap<String, Boolean>();
   private final List<String> transmissionLog = new ArrayList<String>();

   public static TelemetryTransmitter getTransmitter()
   {
      return INSTANCE;
   }

   public void beginTransmission(TelemetryInfo info)
   {
      transmissionLog.add("BEGIN " + info.getName());
   }

   public void endTransmission(TelemetryInfo info)
   {
      transmissionLog.add("END " + info.getName());
   }

   public void recordMeasurement(TelemetryInfo info, String key, String value)
   {
      lastMeasurements.put(key, value);
   }

   public void recordMeasurement(TelemetryInfo info, String key, int value)
   {
      lastMeasurements.put(key, value);
   }

   public void recordMeasurement(TelemetryInfo info, String key, boolean value)
   {
      lastMeasurements.put(key, value);
   }

   public void recordException(TelemetryInfo info, Throwable t)
   {
      lastMeasurements.put("exception", t.getClass().getName());
   }

   public void recordTiming(TelemetryInfo info, String key, TelemetryTimer timer)
   {
      timingsRecorded.put(key, true);
   }

   public void recordObject(TelemetryInfo info, String key, String preferredExtension, TelemetryObject object)
   {
      lastMeasurements.put(key + preferredExtension, object.getPreferredSerialisedName());
   }

   boolean lastBooleanMeasurement(String key)
   {
      Object v = lastMeasurements.get(key);
      return v instanceof Boolean && (Boolean) v;
   }

   int lastIntMeasurement(String key)
   {
      Object v = lastMeasurements.get(key);
      return v instanceof Integer ? (Integer) v : -1;
   }

   boolean hasTiming(String key)
   {
      return Boolean.TRUE.equals(timingsRecorded.get(key));
   }
}


class ExplanationTelemetryWrapper implements TelemetryObject
{
   private Explanation<OWLAxiom> explanation;

   public ExplanationTelemetryWrapper(Explanation<OWLAxiom> explanation)
   {
      this.explanation = explanation;
   }

   public String getPreferredSerialisedName()
   {
      return "justification.owl.xml";
   }

   public boolean isSerialisedAsXML()
   {
      return true;
   }

   public void serialise(java.io.OutputStream outputStream) throws java.io.IOException
   {
      java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
      Explanation.store(explanation, bos);
      String rendering = new String(bos.toByteArray());
      rendering = rendering.replace("<?xml version=\"1.0\"?>\n", "");
      java.io.PrintWriter pw = new java.io.PrintWriter(outputStream);
      pw.println(rendering);
      pw.flush();
   }
}










final class IRI implements Comparable<IRI>
{
   private final String value;

   private IRI(String value)
   {
      this.value = value;
   }

   public static IRI create(String value)
   {
      return new IRI(value);
   }

   @Override
   public String toString()
   {
      return value;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof IRI) && ((IRI) o).value.equals(value);
   }

   @Override
   public int hashCode()
   {
      return value.hashCode();
   }

   @Override
   public int compareTo(IRI o)
   {
      return value.compareTo(o.value);
   }
}

interface OWLClassExpression
{
}

final class OWLClass implements OWLClassExpression, Comparable<OWLClass>
{
   private final IRI iri;

   OWLClass(IRI iri)
   {
      this.iri = iri;
   }

   public IRI getIRI()
   {
      return iri;
   }

   @Override
   public String toString()
   {
      return "<" + iri + ">";
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLClass) && ((OWLClass) o).iri.equals(iri);
   }

   @Override
   public int hashCode()
   {
      return iri.hashCode();
   }

   @Override
   public int compareTo(OWLClass o)
   {
      return iri.compareTo(o.iri);
   }
}

final class OWLAnnotationProperty
{
   private final IRI iri;

   OWLAnnotationProperty(IRI iri)
   {
      this.iri = iri;
   }

   public IRI getIRI()
   {
      return iri;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLAnnotationProperty) && ((OWLAnnotationProperty) o).iri.equals(iri);
   }

   @Override
   public int hashCode()
   {
      return iri.hashCode();
   }
}

final class OWLLiteral
{
   private final String lexicalForm;

   OWLLiteral(String lexicalForm)
   {
      this.lexicalForm = lexicalForm;
   }

   public String getLiteral()
   {
      return lexicalForm;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLLiteral) && ((OWLLiteral) o).lexicalForm.equals(lexicalForm);
   }

   @Override
   public int hashCode()
   {
      return lexicalForm.hashCode();
   }
}

final class OWLAnnotation
{
   private final OWLAnnotationProperty property;
   private final OWLLiteral value;

   OWLAnnotation(OWLAnnotationProperty property, OWLLiteral value)
   {
      this.property = property;
      this.value = value;
   }

   public OWLAnnotationProperty getProperty()
   {
      return property;
   }

   public OWLLiteral getValue()
   {
      return value;
   }
}

final class OWLAxiom implements Comparable<OWLAxiom>
{
   private final OWLClass subClass;
   private final OWLClass superClass;
   private final Set<OWLAnnotation> annotations;

   OWLAxiom(OWLClass subClass, OWLClass superClass, Set<OWLAnnotation> annotations)
   {
      this.subClass = subClass;
      this.superClass = superClass;
      this.annotations = Collections.unmodifiableSet(new HashSet<OWLAnnotation>(annotations));
   }

   public OWLClass getSubClass()
   {
      return subClass;
   }

   public OWLClass getSuperClass()
   {
      return superClass;
   }

   public Set<OWLAnnotation> getAnnotationsSet()
   {
      return annotations;
   }

   public Set<OWLAnnotation> getAnnotations(OWLAnnotationProperty property)
   {
      Set<OWLAnnotation> result = new HashSet<OWLAnnotation>();
      for (OWLAnnotation a : annotations)
      {
         if (a.getProperty().equals(property))
         {
            result.add(a);
         }
      }
      return result;
   }

   public OWLAxiom getAnnotatedAxiom(Set<OWLAnnotation> newAnnotations)
   {
      Set<OWLAnnotation> merged = new HashSet<OWLAnnotation>(annotations);
      merged.addAll(newAnnotations);
      return new OWLAxiom(subClass, superClass, merged);
   }

   public OWLAxiom getAxiomWithoutAnnotations()
   {
      return new OWLAxiom(subClass, superClass, Collections.<OWLAnnotation>emptySet());
   }

   public Set<OWLClassExpression> getNestedClassExpressions()
   {
      Set<OWLClassExpression> result = new HashSet<OWLClassExpression>();
      result.add(subClass);
      result.add(superClass);
      return result;
   }

   @Override
   public String toString()
   {
      return "SubClassOf(" + subClass + " " + superClass + ")";
   }

   @Override
   public boolean equals(Object o)
   {
      if (!(o instanceof OWLAxiom))
      {
         return false;
      }
      OWLAxiom other = (OWLAxiom) o;
      return other.subClass.equals(subClass) && other.superClass.equals(superClass);
   }

   @Override
   public int hashCode()
   {
      return subClass.hashCode() * 31 + superClass.hashCode();
   }

   @Override
   public int compareTo(OWLAxiom o)
   {
      int c = subClass.compareTo(o.subClass);
      if (c != 0)
      {
         return c;
      }
      return superClass.compareTo(o.superClass);
   }
}

interface OWLDataFactory
{
   OWLClass getOWLClass(IRI iri);

   OWLAxiom getOWLSubClassOfAxiom(OWLClass subClass, OWLClass superClass);

   OWLAnnotationProperty getOWLAnnotationProperty(IRI iri);

   OWLAnnotation getOWLAnnotation(OWLAnnotationProperty property, OWLLiteral value);

   OWLLiteral getOWLLiteral(boolean value);
}

final class OWLDataFactoryImpl implements OWLDataFactory
{
   public OWLClass getOWLClass(IRI iri)
   {
      return new OWLClass(iri);
   }

   public OWLAxiom getOWLSubClassOfAxiom(OWLClass subClass, OWLClass superClass)
   {
      return new OWLAxiom(subClass, superClass, Collections.<OWLAnnotation>emptySet());
   }

   public OWLAnnotationProperty getOWLAnnotationProperty(IRI iri)
   {
      return new OWLAnnotationProperty(iri);
   }

   public OWLAnnotation getOWLAnnotation(OWLAnnotationProperty property, OWLLiteral value)
   {
      return new OWLAnnotation(property, value);
   }

   public OWLLiteral getOWLLiteral(boolean value)
   {
      return new OWLLiteral(Boolean.toString(value));
   }
}

final class OWLOntology
{
   final List<OWLAxiom> axioms = new ArrayList<OWLAxiom>();

   public Set<OWLAxiom> getAxioms()
   {
      return new HashSet<OWLAxiom>(axioms);
   }
}

final class OWLXMLDocumentFormat
{
}

class OWLOntologyCreationException extends Exception
{
   OWLOntologyCreationException(String message)
   {
      super(message);
   }

   OWLOntologyCreationException(Throwable cause)
   {
      super(cause);
   }
}

class OWLOntologyStorageException extends Exception
{
   OWLOntologyStorageException(String message)
   {
      super(message);
   }

   OWLOntologyStorageException(Throwable cause)
   {
      super(cause);
   }
}

final class OWLOntologyManager
{
   private final OWLDataFactory dataFactory = new OWLDataFactoryImpl();

   public OWLDataFactory getOWLDataFactory()
   {
      return dataFactory;
   }

   public OWLOntology createOntology(Set<OWLAxiom> axioms) throws OWLOntologyCreationException
   {
      OWLOntology ontology = new OWLOntology();
      ontology.axioms.addAll(axioms);
      return ontology;
   }

   public void addAxiom(OWLOntology ontology, OWLAxiom axiom)
   {
      ontology.axioms.add(axiom);
   }

   public void saveOntology(OWLOntology ontology, OWLXMLDocumentFormat format, java.io.OutputStream os)
         throws OWLOntologyStorageException
   {
      try
      {
         java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.OutputStreamWriter(os, "UTF-8"));
         pw.println("<Ontology xmlns=\"http://www.w3.org/2002/07/owl#\">");
         for (OWLAxiom ax : ontology.axioms)
         {
            pw.print("  <SubClassOf");
            for (OWLAnnotation ann : ax.getAnnotationsSet())
            {
               pw.print(" ann=\"" + ann.getProperty().getIRI() + "=" + ann.getValue().getLiteral() + "\"");
            }
            pw.println(">");
            pw.println("    <Sub>" + ax.getSubClass().getIRI() + "</Sub>");
            pw.println("    <Sup>" + ax.getSuperClass().getIRI() + "</Sup>");
            pw.println("  </SubClassOf>");
         }
         pw.println("</Ontology>");
         pw.flush();
      }
      catch (java.io.IOException e)
      {
         throw new OWLOntologyStorageException(e);
      }
   }
}

final class OWLManager
{
   public static OWLOntologyManager createOWLOntologyManager()
   {
      return new OWLOntologyManager();
   }
}


class TimeOutException extends RuntimeException
{
}





class Explanation<E>
{
   public static final IRI ENTAILMENT_MARKER_IRI = IRI.create("http://owl.cs.manchester.ac.uk/explanation/vocabulary#entailment");

   private E entailment;

   private Set<OWLAxiom> justification;

   public E getEntailment()
   {
      return entailment;
   }

   public Set<OWLAxiom> getAxioms()
   {
      return justification;
   }

   public int getSize()
   {
      return justification.size();
   }

   public boolean isEmpty()
   {
      return justification.isEmpty();
   }

   public boolean contains(OWLAxiom axiom)
   {
      return justification.contains(axiom);
   }

   public boolean isJustificationEntailment()
   {
      return Collections.singleton(entailment).equals(justification);
   }

   public Set<OWLClassExpression> getNestedClassExpressions()
   {
      Set<OWLClassExpression> subConcepts = new HashSet<OWLClassExpression>();
      for (OWLAxiom ax : justification)
      {
         subConcepts.addAll(ax.getNestedClassExpressions());
      }
      return subConcepts;
   }

   public Explanation(E entailment, Set<OWLAxiom> justification)
   {
      this.entailment = entailment;
      this.justification = Collections.unmodifiableSet(new HashSet<OWLAxiom>(justification));
   }

   public static <E> Explanation<E> getEmptyExplanation(E entailment)
   {
      Set<OWLAxiom> emptySet = Collections.emptySet();
      return new Explanation<E>(entailment, emptySet);
   }

   public String toString()
   {
      StringBuilder sb = new StringBuilder();
      if (justification.isEmpty())
      {
         return "Explanation: <Empty>\n";
      }
      sb.append("Explanation <");
      sb.append(entailment);
      sb.append(">\n");
      java.util.Collection<OWLAxiom> orderedAxioms = new java.util.TreeSet<OWLAxiom>(justification);
      for (OWLAxiom ax : orderedAxioms)
      {
         sb.append("\t");
         sb.append(ax);
         sb.append("\n");
      }
      return sb.toString();
   }

   public boolean equals(Object obj)
   {
      if (obj == this)
      {
         return true;
      }
      if (!(obj instanceof Explanation))
      {
         return false;
      }
      Explanation other = (Explanation) obj;
      return other.getEntailment().equals(entailment) && other.getAxioms().equals(justification);
   }

   public int hashCode()
   {
      return (entailment != null ? entailment.hashCode() : 0) + justification.hashCode();
   }

   public static void store(Explanation<OWLAxiom> explanation, java.io.OutputStream os) throws java.io.IOException
   {
      try
      {
         OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
         OWLOntology ontology = manager.createOntology(explanation.getAxioms());
         OWLDataFactory df = manager.getOWLDataFactory();
         OWLAnnotationProperty entailmentMarkerAnnotationProperty = df.getOWLAnnotationProperty(ENTAILMENT_MARKER_IRI);
         OWLAnnotation entailmentAnnotation = df.getOWLAnnotation(entailmentMarkerAnnotationProperty, df.getOWLLiteral(true));
         OWLAxiom annotatedEntailment = explanation.getEntailment().getAnnotatedAxiom(Collections.singleton(entailmentAnnotation));
         manager.addAxiom(ontology, annotatedEntailment);
         java.io.BufferedOutputStream bufferedOutputStream = new java.io.BufferedOutputStream(os);
         OWLXMLDocumentFormat justificationOntologyFormat = new OWLXMLDocumentFormat();
         manager.saveOntology(ontology, justificationOntologyFormat, bufferedOutputStream);
      }
      catch (OWLOntologyStorageException | OWLOntologyCreationException e)
      {
         throw new RuntimeException(e);
      }
   }
}
