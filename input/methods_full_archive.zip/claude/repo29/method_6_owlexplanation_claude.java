


































import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_6_owlexplanation_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== LaconicExplanationGenerator.computePreciseJustsOptimised(E,int) - repository-aware reconstruction ===");
      System.out.println("Repository : matthewhorridge/owlexplanation @ 439c5ca67835f5e421adde725e4e8a3bcd760ac8");
      System.out.println("OWL API    : lightweight adaptation (owlapi-osgidistribution:4.5.10 unavailable offline)");
      System.out.println();

      OWLDataFactory df = new OWLDataFactoryImpl();
      OWLClass person = df.getOWLClass(IRI.create("http://example.org/onto#Person"));
      OWLClass agent = df.getOWLClass(IRI.create("http://example.org/onto#Agent"));
      OWLClass mortal = df.getOWLClass(IRI.create("http://example.org/onto#Mortal"));
      OWLClass livingThing = df.getOWLClass(IRI.create("http://example.org/onto#LivingThing"));

      
      
      
      
      
      OWLAxiom nonLaconicSource = df.getOWLSubClassOfAxiom(person, df.getOWLObjectIntersectionOf(setOf(agent, mortal)));
      
      OWLAxiom pathViaLiving1 = df.getOWLSubClassOfAxiom(person, livingThing);
      OWLAxiom pathViaLiving2 = df.getOWLSubClassOfAxiom(livingThing, mortal);

      Set<OWLAxiom> ontologyAxioms = new HashSet<OWLAxiom>();
      ontologyAxioms.add(nonLaconicSource);
      ontologyAxioms.add(pathViaLiving1);
      ontologyAxioms.add(pathViaLiving2);

      OWLAxiom entailment = df.getOWLSubClassOfAxiom(person, mortal);

      System.out.println("--- ontology ---");
      for (OWLAxiom ax : ontologyAxioms)
      {
         System.out.println("  " + ax);
      }
      System.out.println("entailment : " + entailment);
      System.out.println();

      
      
      
      
      
      
      System.out.println("--- Scenario 1: computePreciseJustsOptimised(entailment, unlimited) ---");
      LaconicExplanationGenerator<OWLAxiom> gen = new LaconicExplanationGenerator<OWLAxiom>(
            ontologyAxioms, new PathFindingExplanationGeneratorFactory(), null);
      Set<Explanation<OWLAxiom>> result = gen.computePreciseJustsOptimised(entailment, Integer.MAX_VALUE);
      System.out.println("justifications returned : " + result.size());
      for (Explanation<OWLAxiom> exp : result)
      {
         System.out.println("  " + exp.getAxioms());
      }
      boolean foundLaconicViaIntersection = false;
      boolean foundViaLiving = false;
      for (Explanation<OWLAxiom> exp : result)
      {
         if (exp.getAxioms().size() == 1 && exp.getAxioms().iterator().next().equals(entailment))
         {
            foundLaconicViaIntersection = true;
         }
         if (exp.getAxioms().contains(pathViaLiving1) && exp.getAxioms().contains(pathViaLiving2))
         {
            foundViaLiving = true;
         }
      }
      System.out.println("laconic weakening of the intersection axiom found : " + foundLaconicViaIntersection);
      System.out.println("independent LivingThing-path justification found  : " + foundViaLiving);
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 2: computePreciseJustsOptimised(entailment, limit=1) ---");
      LaconicExplanationGenerator<OWLAxiom> gen2 = new LaconicExplanationGenerator<OWLAxiom>(
            ontologyAxioms, new PathFindingExplanationGeneratorFactory(), null);
      Set<Explanation<OWLAxiom>> limited = gen2.computePreciseJustsOptimised(entailment, 1);
      System.out.println("justifications returned (limit=1) : " + limited.size());
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: entailment does not hold ---");
      OWLClass unrelated = df.getOWLClass(IRI.create("http://example.org/onto#Unrelated"));
      OWLAxiom notEntailed = df.getOWLSubClassOfAxiom(unrelated, mortal);
      LaconicExplanationGenerator<OWLAxiom> gen3 = new LaconicExplanationGenerator<OWLAxiom>(
            ontologyAxioms, new PathFindingExplanationGeneratorFactory(), null);
      Set<Explanation<OWLAxiom>> none = gen3.computePreciseJustsOptimised(notEntailed, Integer.MAX_VALUE);
      System.out.println("justifications returned : " + none.size());

      System.out.println();
      System.out.println("=== done ===");
   }

   private static Set<OWLClassExpression> setOf(OWLClassExpression... items)
   {
      Set<OWLClassExpression> s = new HashSet<OWLClassExpression>();
      for (OWLClassExpression i : items)
      {
         s.add(i);
      }
      return s;
   }
}




class LaconicExplanationGenerator<E> implements ExplanationGenerator<E>, ExplanationProgressMonitor<E>
{
   private ExplanationGeneratorFactory<E> explanationGeneratorFactory;

   private OWLOntologyManager man;

   private OWLOntology ont;

   private Set<Explanation<E>> lastRegularJusts;

   private Set<Explanation<E>> allPreviouslyFoundJustifications;

   private Set<Explanation<E>> foundLaconicJustifications;

   private ExplanationProgressMonitor<E> progressMonitor;

   private int limit;

   private Set<? extends OWLAxiom> axioms;

   public LaconicExplanationGenerator(Set<? extends OWLAxiom> axioms, ExplanationGeneratorFactory<E> explanationGeneratorFactory, ExplanationProgressMonitor<E> progressMonitor)
   {
      this.man = OWLManager.createOWLOntologyManager();
      this.progressMonitor = progressMonitor;
      this.explanationGeneratorFactory = explanationGeneratorFactory;
      this.limit = Integer.MAX_VALUE;
      this.axioms = axioms;
      if (progressMonitor != null)
      {
         this.progressMonitor = progressMonitor;
      }
      else
      {
         this.progressMonitor = new NullExplanationProgressMonitor<E>();
      }
      this.foundLaconicJustifications = new HashSet<Explanation<E>>();
      this.ont = man.createOntology(Collections.<OWLAxiom>unmodifiableSet((Set<OWLAxiom>) axioms));
      lastRegularJusts = new HashSet<Explanation<E>>();
   }

   




   public Set<OWLAxiom> computeOPlus(Set<OWLAxiom> axioms)
   {
      OPlusGenerator oPlusGenerator = new OPlusGenerator(man.getOWLDataFactory(), OPlusSplitting.TOP_LEVEL);
      Set<OWLAxiom> oPlus = new HashSet<OWLAxiom>();
      for (OWLAxiom ax : axioms)
      {
         Set<? extends OWLAxiom> weakenedAxioms = ax.accept(oPlusGenerator);
         oPlus.addAll(weakenedAxioms);
      }
      for (OWLAxiom ax : oPlus)
      {
         if (ax instanceof OWLEquivalentClassesAxiom)
         {
            OWLEquivalentClassesAxiom eca = (OWLEquivalentClassesAxiom) ax;
            if (oPlus.containsAll(eca.asOWLSubClassOfAxioms()))
            {
               System.out.println("POTENTIAL OPT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!****************");
            }
         }
      }
      return oPlus;
   }

   public List<Integer> getPruningDifferences()
   {
      return null;
   }

   public Set<Explanation<E>> computePreciseJusts(E entailment, int limit) throws OWLException
   {
      return computePreciseJustsOptimised(entailment, limit);
   }

   public Set<Explanation<E>> getLastRegularJustifications()
   {
      return lastRegularJusts;
   }

   public void foundExplanation(ExplanationGenerator<E> explanationGenerator, Explanation<E> explanation, Set<Explanation<E>> allFoundExplanations)
   {
      notifyLaconicExplanationGeneratorProgressMonitor(explanation);
   }

   public boolean isCancelled()
   {
      return isAtFoundLaconicJustificationsLimit() || progressMonitor.isCancelled();
   }

   private boolean isAtFoundLaconicJustificationsLimit()
   {
      return limit == foundLaconicJustifications.size();
   }

   private void notifyLaconicExplanationGeneratorProgressMonitor(Explanation<E> explanation)
   {
      try
      {
         if (isLaconic(explanation))
         {
            if (!foundLaconicJustifications.contains(explanation))
            {
               foundLaconicJustifications.add(explanation);
               progressMonitor.foundExplanation(this, explanation, foundLaconicJustifications);
            }
         }
      }
      catch (ExplanationException e)
      {
         throw new OWLRuntimeException(e);
      }
   }

   public boolean isLaconic(Explanation<E> justification) throws ExplanationException
   {
      Set<OWLAxiom> justificationSigmaClosure = computeOPlus(justification.getAxioms());
      ExplanationGenerator<E> gen2 = explanationGeneratorFactory.createExplanationGenerator(justificationSigmaClosure);
      Set<Explanation<E>> exps = gen2.getExplanations(justification.getEntailment(), 2);
      return Collections.singleton(justification).equals(exps);
   }

   
   private Set<Explanation<E>> getReconstitutedLaconicJustifications()
   {
      Map<OWLAxiom, Set<OWLAxiom>> sourceAxioms2OPlus = new HashMap<OWLAxiom, Set<OWLAxiom>>();

      for (Explanation<E> exp : allPreviouslyFoundJustifications)
      {
         for (OWLAxiom ax : exp.getAxioms())
         {
            if (ont.containsAxiom(ax))
            {
               sourceAxioms2OPlus.put(ax, computeOPlus(Collections.singleton(ax)));
            }
         }
      }

      Set<Explanation<E>> reconstituedExplanations = new HashSet<Explanation<E>>();
      for (Explanation<E> laconicExp : foundLaconicJustifications)
      {
         Map<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>> lhs2SubClassAxiom = new HashMap<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>>();

         Set<OWLAxiom> reconstituedAxioms = new HashSet<OWLAxiom>();
         for (OWLAxiom laconicAx : laconicExp.getAxioms())
         {
            if (laconicAx instanceof OWLSubClassOfAxiom)
            {
               OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) laconicAx;
               if (sca.getSubClass().isAnonymous())
               {
                  reconstituedAxioms.add(sca);
                  continue;
               }
               Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2AxiomMap = lhs2SubClassAxiom.get(sca.getSubClass().asOWLClass());
               if (source2AxiomMap == null)
               {
                  source2AxiomMap = new HashMap<OWLAxiom, Set<OWLSubClassOfAxiom>>();
                  lhs2SubClassAxiom.put(sca.getSubClass().asOWLClass(), source2AxiomMap);
               }
               for (OWLAxiom sourceAx : sourceAxioms2OPlus.keySet())
               {
                  if (sourceAxioms2OPlus.get(sourceAx).contains(sca))
                  {
                     Set<OWLSubClassOfAxiom> subClassAxioms = source2AxiomMap.get(sourceAx);
                     if (subClassAxioms == null)
                     {
                        subClassAxioms = new HashSet<OWLSubClassOfAxiom>();
                        source2AxiomMap.put(sourceAx, subClassAxioms);
                     }
                     subClassAxioms.add(sca);
                  }
               }
            }
            else
            {
               reconstituedAxioms.add(laconicAx);
            }
         }
         Set<OWLSubClassOfAxiom> consumedAxioms = new HashSet<OWLSubClassOfAxiom>();
         for (OWLClass lhs : lhs2SubClassAxiom.keySet())
         {
            Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2SubClassAxiom = lhs2SubClassAxiom.get(lhs);
            for (OWLAxiom source : source2SubClassAxiom.keySet())
            {
               Set<OWLClassExpression> rightHandSides = new HashSet<OWLClassExpression>();
               for (OWLSubClassOfAxiom subClassAx : source2SubClassAxiom.get(source))
               {
                  if (!consumedAxioms.contains(subClassAx))
                  {
                     rightHandSides.add(subClassAx.getSuperClass());
                     consumedAxioms.add(subClassAx);
                  }
               }
               if (rightHandSides.size() == 1)
               {
                  reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, rightHandSides.iterator().next()));
               }
               else if (rightHandSides.size() > 1)
               {
                  OWLObjectIntersectionOf conjunction = man.getOWLDataFactory().getOWLObjectIntersectionOf(rightHandSides);
                  reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, conjunction));
               }
            }
         }
         Explanation<E> explanation = new Explanation<E>(laconicExp.getEntailment(), reconstituedAxioms);
         reconstituedExplanations.add(explanation);
      }
      return reconstituedExplanations;
   }


// ORIGINAL CODESEARCHNET METHOD — START

public Set<Explanation<E>> computePreciseJustsOptimised(E entailment, int limit) throws OWLException {
        this.limit = limit;
        foundLaconicJustifications.clear();
        ExplanationGenerator<E> gen = explanationGeneratorFactory.createExplanationGenerator(axioms, this);
        Set<Explanation<E>> regularJusts = null;
        try {
            regularJusts = gen.getExplanations(entailment);
        }
        catch (ExplanationGeneratorInterruptedException e) {
            
            return foundLaconicJustifications;
        }
        if (isCancelled()) {
            return foundLaconicJustifications;
        }
        lastRegularJusts.clear();

        
        allPreviouslyFoundJustifications = new HashSet<Explanation<E>>();
        allPreviouslyFoundJustifications.addAll(regularJusts);




        Set<OWLAxiom> axiomsInPreviousOntology = new HashSet<OWLAxiom>();

        
        while (true) {

            if (isCancelled()) {
                return getReconstitutedLaconicJustifications();
            }
            
            

            Set<OWLAxiom> unionOfAllJustifications = new HashSet<OWLAxiom>();
            for (Explanation<E> exp : allPreviouslyFoundJustifications) {
                unionOfAllJustifications.addAll(exp.getAxioms());
            }
            Set<OWLAxiom> oPlus = computeOPlus(unionOfAllJustifications);

            
            Set<OWLAxiom> augmentedAxioms = new HashSet<OWLAxiom>(oPlus);

            
            
            

            
            
            
            
            
            
            
            
            for (OWLAxiom ax : ont.getLogicalAxioms()) {
                
                
                if (unionOfAllJustifications.contains(ax) && !oPlus.contains(ax)) {
                    continue;
                }
                augmentedAxioms.add(ax);
            }

            
            

            


            if (augmentedAxioms.equals(axiomsInPreviousOntology)) {
                break;
            }

            ExplanationGenerator<E> gen2 = explanationGeneratorFactory.createExplanationGenerator(augmentedAxioms, this);

            axiomsInPreviousOntology.clear();
            axiomsInPreviousOntology.addAll(augmentedAxioms);

            Set<Explanation> allPrevJustsCopy = new HashSet<Explanation>(allPreviouslyFoundJustifications);

            
            Set<Explanation<E>> currentJustifications = null;
            try {
                currentJustifications = gen2.getExplanations(entailment);
            }
            catch (ExplanationGeneratorInterruptedException e) {
                return getReconstitutedLaconicJustifications();
            }
            if (isCancelled()) {
                return getReconstitutedLaconicJustifications();
            }
            allPreviouslyFoundJustifications.addAll(currentJustifications);
            if (allPreviouslyFoundJustifications.equals(allPrevJustsCopy)) {
                break;
            }
            
            

















        }


















        return getReconstitutedLaconicJustifications();
    }

// ORIGINAL CODESEARCHNET METHOD — END


   
   
   
   
   public Set<Explanation<E>> getExplanations(E entailment) throws ExplanationException
   {
      try
      {
         return computePreciseJusts(entailment, Integer.MAX_VALUE);
      }
      catch (OWLException e)
      {
         throw new ExplanationException(e);
      }
   }

   public Set<Explanation<E>> getExplanations(E entailment, int limit) throws ExplanationException
   {
      try
      {
         return computePreciseJusts(entailment, limit);
      }
      catch (OWLException e)
      {
         throw new ExplanationException(e);
      }
   }
}





interface EntailmentChecker<E>
{
   boolean isEntailed(Set<OWLAxiom> axioms);
}

interface ExplanationProgressMonitor<E>
{
   void foundExplanation(ExplanationGenerator<E> explanationGenerator, Explanation<E> explanation, Set<Explanation<E>> allFoundExplanations);

   boolean isCancelled();
}

class NullExplanationProgressMonitor<E> implements ExplanationProgressMonitor<E>
{
   public void foundExplanation(ExplanationGenerator<E> explanationGenerator, Explanation<E> explanation, Set<Explanation<E>> allFoundExplanations)
   {
   }

   public boolean isCancelled()
   {
      return false;
   }
}




class ExplanationException extends OWLRuntimeException
{
   ExplanationException(String message)
   {
      super(message);
   }

   ExplanationException(Throwable cause)
   {
      super(cause);
   }
}

class ExplanationGeneratorInterruptedException extends RuntimeException
{
}

interface ExplanationGenerator<E>
{
   Set<Explanation<E>> getExplanations(E entailment) throws ExplanationException;

   Set<Explanation<E>> getExplanations(E entailment, int limit) throws ExplanationException;
}

interface ExplanationGeneratorFactory<E>
{
   ExplanationGenerator<E> createExplanationGenerator(Set<? extends OWLAxiom> axioms);

   ExplanationGenerator<E> createExplanationGenerator(Set<? extends OWLAxiom> axioms, ExplanationProgressMonitor<E> progressMonitor);
}


class OWLException extends Exception
{
   OWLException(String message)
   {
      super(message);
   }

   OWLException(Throwable cause)
   {
      super(cause);
   }
}


class OWLRuntimeException extends RuntimeException
{
   OWLRuntimeException(String message)
   {
      super(message);
   }

   OWLRuntimeException(Throwable cause)
   {
      super(cause);
   }
}









class PathFindingExplanationGeneratorFactory implements ExplanationGeneratorFactory<OWLAxiom>
{
   public ExplanationGenerator<OWLAxiom> createExplanationGenerator(Set<? extends OWLAxiom> axioms)
   {
      return createExplanationGenerator(axioms, null);
   }

   public ExplanationGenerator<OWLAxiom> createExplanationGenerator(final Set<? extends OWLAxiom> axioms, final ExplanationProgressMonitor<OWLAxiom> progressMonitor)
   {
      return new ExplanationGenerator<OWLAxiom>()
      {
         public Set<Explanation<OWLAxiom>> getExplanations(OWLAxiom entailment)
         {
            return getExplanations(entailment, Integer.MAX_VALUE);
         }

         public Set<Explanation<OWLAxiom>> getExplanations(OWLAxiom entailment, int limit)
         {
            Set<Explanation<OWLAxiom>> results = new HashSet<Explanation<OWLAxiom>>();
            if (!(entailment instanceof OWLSubClassOfAxiom))
            {
               return results;
            }
            OWLSubClassOfAxiom target = (OWLSubClassOfAxiom) entailment;
            Map<OWLClass, List<OWLSubClassOfAxiom>> outgoing = new HashMap<OWLClass, List<OWLSubClassOfAxiom>>();
            for (OWLAxiom ax : axioms)
            {
               if (ax instanceof OWLSubClassOfAxiom)
               {
                  OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) ax;
                  if (sca.getSubClass().isAnonymous())
                  {
                     continue;
                  }
                  List<OWLSubClassOfAxiom> list = outgoing.get(sca.getSubClass().asOWLClass());
                  if (list == null)
                  {
                     list = new ArrayList<OWLSubClassOfAxiom>();
                     outgoing.put(sca.getSubClass().asOWLClass(), list);
                  }
                  list.add(sca);
               }
            }
            if (target.getSubClass().isAnonymous())
            {
               return results;
            }
            findPaths(target.getSubClass().asOWLClass(), target.getSuperClass(), outgoing,
                  new ArrayList<OWLSubClassOfAxiom>(), new HashSet<OWLClass>(), results, target, progressMonitor, limit);
            return results;
         }

         private void findPaths(OWLClass current, OWLClassExpression goal, Map<OWLClass, List<OWLSubClassOfAxiom>> outgoing,
               List<OWLSubClassOfAxiom> pathSoFar, Set<OWLClass> onPath, Set<Explanation<OWLAxiom>> results,
               OWLSubClassOfAxiom entailment, ExplanationProgressMonitor<OWLAxiom> progressMonitor, int limit)
         {
            if (progressMonitor != null && progressMonitor.isCancelled())
            {
               return;
            }
            if (results.size() >= limit)
            {
               return;
            }
            if (!current.isAnonymous() && current.equals(goal) && !pathSoFar.isEmpty())
            {
               Explanation<OWLAxiom> exp = new Explanation<OWLAxiom>(entailment, new HashSet<OWLAxiom>(pathSoFar));
               if (results.add(exp) && progressMonitor != null)
               {
                  progressMonitor.foundExplanation(null, exp, results);
               }
               return;
            }
            List<OWLSubClassOfAxiom> edges = outgoing.get(current);
            if (edges == null || onPath.contains(current))
            {
               return;
            }
            onPath.add(current);
            for (OWLSubClassOfAxiom edge : edges)
            {
               if (progressMonitor != null && progressMonitor.isCancelled())
               {
                  break;
               }
               pathSoFar.add(edge);
               OWLClassExpression edgeSuper = edge.getSuperClass();
               
               
               
               
               
               
               if (!goal.isAnonymous() && edgeSuper.asConjunctSet().contains(goal))
               {
                  Explanation<OWLAxiom> exp = new Explanation<OWLAxiom>(entailment, new HashSet<OWLAxiom>(pathSoFar));
                  if (results.add(exp) && progressMonitor != null)
                  {
                     progressMonitor.foundExplanation(null, exp, results);
                  }
               }
               else if (!edgeSuper.isAnonymous())
               {
                  findPaths(edgeSuper.asOWLClass(), goal, outgoing, pathSoFar, onPath, results, entailment, progressMonitor, limit);
               }
               pathSoFar.remove(pathSoFar.size() - 1);
            }
            onPath.remove(current);
         }
      };
   }
}








final class IRI implements Comparable<IRI>
{
   private final String value;

   private IRI(String value)
   {
      this.value = value;
   }

   public static IRI create(String value)
   {
      return new IRI(value);
   }

   @Override
   public String toString()
   {
      return value;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof IRI) && ((IRI) o).value.equals(value);
   }

   @Override
   public int hashCode()
   {
      return value.hashCode();
   }

   @Override
   public int compareTo(IRI o)
   {
      return value.compareTo(o.value);
   }
}

interface OWLClassExpression
{
   boolean isAnonymous();

   OWLClass asOWLClass();

   Set<OWLClassExpression> asConjunctSet();
}

final class OWLClass implements OWLClassExpression, Comparable<OWLClass>
{
   private final IRI iri;

   OWLClass(IRI iri)
   {
      this.iri = iri;
   }

   public boolean isAnonymous()
   {
      return false;
   }

   public OWLClass asOWLClass()
   {
      return this;
   }

   public Set<OWLClassExpression> asConjunctSet()
   {
      return Collections.<OWLClassExpression>singleton(this);
   }

   @Override
   public String toString()
   {
      return "<" + iri + ">";
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLClass) && ((OWLClass) o).iri.equals(iri);
   }

   @Override
   public int hashCode()
   {
      return iri.hashCode();
   }

   @Override
   public int compareTo(OWLClass o)
   {
      return iri.compareTo(o.iri);
   }
}

final class OWLObjectIntersectionOf implements OWLClassExpression
{
   private final Set<OWLClassExpression> operands;

   OWLObjectIntersectionOf(Set<OWLClassExpression> operands)
   {
      this.operands = Collections.unmodifiableSet(new HashSet<OWLClassExpression>(operands));
   }

   public boolean isAnonymous()
   {
      return true;
   }

   public OWLClass asOWLClass()
   {
      throw new UnsupportedOperationException("not a named class");
   }

   public Set<OWLClassExpression> asConjunctSet()
   {
      return operands;
   }

   @Override
   public String toString()
   {
      List<OWLClassExpression> sorted = new ArrayList<OWLClassExpression>(operands);
      Collections.sort(sorted, (a, b) -> a.toString().compareTo(b.toString()));
      StringBuilder sb = new StringBuilder("ObjectIntersectionOf(");
      for (int i = 0; i < sorted.size(); i++)
      {
         if (i > 0)
         {
            sb.append(" ");
         }
         sb.append(sorted.get(i));
      }
      return sb.append(")").toString();
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLObjectIntersectionOf) && ((OWLObjectIntersectionOf) o).operands.equals(operands);
   }

   @Override
   public int hashCode()
   {
      return operands.hashCode();
   }
}

interface OWLAxiom
{
   Set<? extends OWLAxiom> accept(OPlusGenerator visitor);
}

interface OWLSubClassOfAxiom extends OWLAxiom
{
   OWLClassExpression getSubClass();

   OWLClassExpression getSuperClass();
}

final class OWLSubClassOfAxiomImpl implements OWLSubClassOfAxiom, Comparable<OWLSubClassOfAxiomImpl>
{
   private final OWLClassExpression subClass;
   private final OWLClassExpression superClass;

   OWLSubClassOfAxiomImpl(OWLClassExpression subClass, OWLClassExpression superClass)
   {
      this.subClass = subClass;
      this.superClass = superClass;
   }

   public OWLClassExpression getSubClass()
   {
      return subClass;
   }

   public OWLClassExpression getSuperClass()
   {
      return superClass;
   }

   public Set<? extends OWLAxiom> accept(OPlusGenerator visitor)
   {
      return visitor.visit(this);
   }

   @Override
   public String toString()
   {
      return "SubClassOf(" + subClass + " " + superClass + ")";
   }

   @Override
   public boolean equals(Object o)
   {
      if (!(o instanceof OWLSubClassOfAxiomImpl))
      {
         return false;
      }
      OWLSubClassOfAxiomImpl other = (OWLSubClassOfAxiomImpl) o;
      return other.subClass.equals(subClass) && other.superClass.equals(superClass);
   }

   @Override
   public int hashCode()
   {
      return subClass.hashCode() * 31 + superClass.hashCode();
   }

   @Override
   public int compareTo(OWLSubClassOfAxiomImpl o)
   {
      return toString().compareTo(o.toString());
   }
}


interface OWLEquivalentClassesAxiom extends OWLAxiom
{
   Set<OWLSubClassOfAxiom> asOWLSubClassOfAxioms();
}

interface OWLDataFactory
{
   OWLClass getOWLClass(IRI iri);

   OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClassExpression subClass, OWLClassExpression superClass);

   OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression> operands);
}

final class OWLDataFactoryImpl implements OWLDataFactory
{
   public OWLClass getOWLClass(IRI iri)
   {
      return new OWLClass(iri);
   }

   public OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClassExpression subClass, OWLClassExpression superClass)
   {
      return new OWLSubClassOfAxiomImpl(subClass, superClass);
   }

   public OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression> operands)
   {
      return new OWLObjectIntersectionOf(operands);
   }
}

final class OWLOntology
{
   private final Set<OWLAxiom> axioms;

   OWLOntology(Set<OWLAxiom> axioms)
   {
      this.axioms = new HashSet<OWLAxiom>(axioms);
   }

   public Set<OWLAxiom> getLogicalAxioms()
   {
      return axioms;
   }

   public boolean containsAxiom(OWLAxiom axiom)
   {
      return axioms.contains(axiom);
   }
}

final class OWLOntologyManager
{
   private final OWLDataFactory dataFactory = new OWLDataFactoryImpl();

   public OWLDataFactory getOWLDataFactory()
   {
      return dataFactory;
   }

   public OWLOntology createOntology(Set<OWLAxiom> axioms)
   {
      return new OWLOntology(axioms);
   }
}

final class OWLManager
{
   public static OWLOntologyManager createOWLOntologyManager()
   {
      return new OWLOntologyManager();
   }
}










final class OPlusGenerator
{
   private final OWLDataFactory dataFactory;
   private final OPlusSplitting splitting;

   OPlusGenerator(OWLDataFactory dataFactory, OPlusSplitting splitting)
   {
      this.dataFactory = dataFactory;
      this.splitting = splitting;
   }

   public Set<OWLAxiom> visit(OWLSubClassOfAxiom axiom)
   {
      Set<OWLAxiom> result = new HashSet<OWLAxiom>();
      Set<OWLClassExpression> tau = axiom.getSuperClass().asConjunctSet();
      Set<OWLClassExpression> beta = axiom.getSubClass().asConjunctSet(); 
      for (OWLClassExpression b : beta)
      {
         for (OWLClassExpression t : tau)
         {
            result.add(dataFactory.getOWLSubClassOfAxiom(b, t));
         }
      }
      return result;
   }
}

enum OPlusSplitting
{
   TOP_LEVEL
}

class Explanation<E>
{
   private final E entailment;
   private final Set<OWLAxiom> justification;

   Explanation(E entailment, Set<OWLAxiom> justification)
   {
      this.entailment = entailment;
      this.justification = Collections.unmodifiableSet(new HashSet<OWLAxiom>(justification));
   }

   public E getEntailment()
   {
      return entailment;
   }

   public Set<OWLAxiom> getAxioms()
   {
      return justification;
   }

   @Override
   public boolean equals(Object obj)
   {
      if (obj == this)
      {
         return true;
      }
      if (!(obj instanceof Explanation))
      {
         return false;
      }
      Explanation other = (Explanation) obj;
      return other.getEntailment().equals(entailment) && other.getAxioms().equals(justification);
   }

   @Override
   public int hashCode()
   {
      return (entailment != null ? entailment.hashCode() : 0) + justification.hashCode();
   }
}
