
































import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_2_owlexplanation_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== LaconicExplanationGenerator.getReconstitutedLaconicJustifications() - repository-aware reconstruction ===");
      System.out.println("Repository : matthewhorridge/owlexplanation @ 439c5ca67835f5e421adde725e4e8a3bcd760ac8");
      System.out.println("OWL API    : lightweight adaptation (owlapi-osgidistribution:4.5.10 unavailable offline)");
      System.out.println();

      OWLDataFactory df = new OWLDataFactoryImpl();

      OWLClass person = df.getOWLClass(IRI.create("http://example.org/onto#Person"));
      OWLClass agent = df.getOWLClass(IRI.create("http://example.org/onto#Agent"));
      OWLClass mortal = df.getOWLClass(IRI.create("http://example.org/onto#Mortal"));
      OWLClass namedThing = df.getOWLClass(IRI.create("http://example.org/onto#NamedThing"));
      OWLClass entailedTarget = df.getOWLClass(IRI.create("http://example.org/onto#Target"));

      
      
      OWLAxiom sourceA = df.getOWLSubClassOfAxiom(person, df.getOWLObjectIntersectionOf(setOf(agent, mortal)));
      
      
      OWLAxiom sourceB = df.getOWLSubClassOfAxiom(namedThing, entailedTarget);

      Set<OWLAxiom> ontologyAxioms = new HashSet<OWLAxiom>();
      ontologyAxioms.add(sourceA);
      ontologyAxioms.add(sourceB);

      OWLOntologyManager man = OWLManager.createOWLOntologyManager();
      OWLOntology ont = man.createOntology(ontologyAxioms);

      LaconicExplanationGenerator<OWLAxiom> gen = new LaconicExplanationGenerator<OWLAxiom>(man, ont);

      
      
      
      
      
      
      
      System.out.println("--- Scenario 1: two laconic axioms with common LHS + common source get merged ---");
      OWLAxiom laconicPersonAgent = df.getOWLSubClassOfAxiom(person, agent);
      OWLAxiom laconicPersonMortal = df.getOWLSubClassOfAxiom(person, mortal);
      Set<OWLAxiom> laconicJustification1Axioms = new HashSet<OWLAxiom>();
      laconicJustification1Axioms.add(laconicPersonAgent);
      laconicJustification1Axioms.add(laconicPersonMortal);
      Explanation<OWLAxiom> laconicJustification1 =
            new Explanation<OWLAxiom>(df.getOWLSubClassOfAxiom(person, mortal), laconicJustification1Axioms);

      
      Explanation<OWLAxiom> laconicJustification2 =
            new Explanation<OWLAxiom>(sourceB, Collections.singleton(sourceB));

      gen.seedAllPreviouslyFoundJustifications(ontologyAxioms, sourceA, sourceB);
      gen.seedFoundLaconicJustifications(laconicJustification1, laconicJustification2);

      Set<Explanation<OWLAxiom>> reconstituted = gen.getReconstitutedLaconicJustificationsForTesting();

      System.out.println("reconstituted justification count : " + reconstituted.size());
      for (Explanation<OWLAxiom> exp : reconstituted)
      {
         System.out.println("  entailment = " + exp.getEntailment());
         for (OWLAxiom ax : exp.getAxioms())
         {
            System.out.println("    axiom = " + ax);
         }
      }
      boolean mergedFound = false;
      for (Explanation<OWLAxiom> exp : reconstituted)
      {
         for (OWLAxiom ax : exp.getAxioms())
         {
            if (ax.toString().contains("ObjectIntersectionOf"))
            {
               mergedFound = true;
            }
         }
      }
      System.out.println("merged intersection axiom present : " + mergedFound);
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 2: anonymous-subclass axiom passes through unmerged ---");
      OWLClassExpression anonSub = df.getOWLObjectIntersectionOf(setOf(agent, mortal));
      OWLAxiom anonymousLaconicAxiom = df.getOWLSubClassOfAxiom(anonSub, namedThing);
      Explanation<OWLAxiom> laconicJustification3 =
            new Explanation<OWLAxiom>(df.getOWLSubClassOfAxiom(anonSub, namedThing), Collections.singleton(anonymousLaconicAxiom));

      LaconicExplanationGenerator<OWLAxiom> gen2 = new LaconicExplanationGenerator<OWLAxiom>(man, ont);
      gen2.seedAllPreviouslyFoundJustifications(ontologyAxioms, sourceA, sourceB);
      gen2.seedFoundLaconicJustifications(laconicJustification3);
      Set<Explanation<OWLAxiom>> reconstituted2 = gen2.getReconstitutedLaconicJustificationsForTesting();
      System.out.println("reconstituted count : " + reconstituted2.size());
      Explanation<OWLAxiom> only = reconstituted2.iterator().next();
      System.out.println("axiom unchanged (still anonymous LHS) : " + only.getAxioms().contains(anonymousLaconicAxiom));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 3: a laconic justification containing zero SubClassOf axioms is untouched ---");
      OWLAxiom nonSubClassLikeAxiom = new OpaqueAxiom("SomeOtherAxiomKind(NamedThing)");
      Explanation<OWLAxiom> laconicJustification4 =
            new Explanation<OWLAxiom>(sourceB, Collections.singleton(nonSubClassLikeAxiom));
      LaconicExplanationGenerator<OWLAxiom> gen3 = new LaconicExplanationGenerator<OWLAxiom>(man, ont);
      gen3.seedAllPreviouslyFoundJustifications(ontologyAxioms, sourceA, sourceB);
      gen3.seedFoundLaconicJustifications(laconicJustification4);
      Set<Explanation<OWLAxiom>> reconstituted3 = gen3.getReconstitutedLaconicJustificationsForTesting();
      Explanation<OWLAxiom> onlyOne = reconstituted3.iterator().next();
      System.out.println("axiom passed through unchanged : " + onlyOne.getAxioms().contains(nonSubClassLikeAxiom));
      System.out.println();

      System.out.println("=== done ===");
   }

   private static Set<OWLClassExpression> setOf(OWLClassExpression... items)
   {
      Set<OWLClassExpression> s = new HashSet<OWLClassExpression>();
      for (OWLClassExpression i : items)
      {
         s.add(i);
      }
      return s;
   }
}







class LaconicExplanationGenerator<E>
{
   private OWLOntologyManager man;

   private OWLOntology ont;

   private Set<Explanation<E>> allPreviouslyFoundJustifications;

   private Set<Explanation<E>> foundLaconicJustifications = new HashSet<Explanation<E>>();

   LaconicExplanationGenerator(OWLOntologyManager man, OWLOntology ont)
   {
      this.man = man;
      this.ont = ont;
   }

   


   @SafeVarargs
   final void seedAllPreviouslyFoundJustifications(Set<OWLAxiom> ontologyAxioms, OWLAxiom... sourceAxioms)
   {
      allPreviouslyFoundJustifications = new HashSet<Explanation<E>>();
      for (OWLAxiom source : sourceAxioms)
      {
         allPreviouslyFoundJustifications.add((Explanation<E>) (Explanation<?>) new Explanation<OWLAxiom>(source, Collections.singleton(source)));
      }
   }

   @SafeVarargs
   final void seedFoundLaconicJustifications(Explanation<OWLAxiom>... justifications)
   {
      foundLaconicJustifications = new HashSet<Explanation<E>>();
      for (Explanation<OWLAxiom> j : justifications)
      {
         foundLaconicJustifications.add((Explanation<E>) (Explanation<?>) j);
      }
   }

   
   Set<Explanation<E>> getReconstitutedLaconicJustificationsForTesting()
   {
      return getReconstitutedLaconicJustifications();
   }

   









   public Set<OWLAxiom> computeOPlus(Set<OWLAxiom> axioms)
   {
      Set<OWLAxiom> oPlus = new HashSet<OWLAxiom>();
      for (OWLAxiom ax : axioms)
      {
         if (ax instanceof OWLSubClassOfAxiom)
         {
            OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) ax;
            for (OWLClassExpression conjunct : sca.getSuperClass().asConjunctSet())
            {
               oPlus.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(sca.getSubClass(), conjunct));
            }
         }
         else
         {
            oPlus.add(ax);
         }
      }
      return oPlus;
   }


// ORIGINAL CODESEARCHNET METHOD — START

    



    private Set<Explanation<E>> getReconstitutedLaconicJustifications() {
        

        
        
        
        
        Map<OWLAxiom, Set<OWLAxiom>> sourceAxioms2OPlus = new HashMap<OWLAxiom, Set<OWLAxiom>>();

        for (Explanation<E> exp : allPreviouslyFoundJustifications) {
            for (OWLAxiom ax : exp.getAxioms()) {
                if (ont.containsAxiom(ax)) {
                    sourceAxioms2OPlus.put(ax, computeOPlus(Collections.singleton(ax)));
                }
            }
        }

        Set<Explanation<E>> reconstituedExplanations = new HashSet<Explanation<E>>();
        for (Explanation<E> laconicExp : foundLaconicJustifications) {
            
            Map<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>> lhs2SubClassAxiom = new HashMap<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>>();

            Set<OWLAxiom> reconstituedAxioms = new HashSet<OWLAxiom>();
            for (OWLAxiom laconicAx : laconicExp.getAxioms()) {
                if (laconicAx instanceof OWLSubClassOfAxiom) {
                    OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) laconicAx;
                    if (sca.getSubClass().isAnonymous()) {
                        
                        reconstituedAxioms.add(sca);
                        continue;
                    }
                    Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2AxiomMap = lhs2SubClassAxiom.get(sca.getSubClass().asOWLClass());
                    if (source2AxiomMap == null) {
                        source2AxiomMap = new HashMap<OWLAxiom, Set<OWLSubClassOfAxiom>>();
                        lhs2SubClassAxiom.put(sca.getSubClass().asOWLClass(), source2AxiomMap);
                    }
                    for (OWLAxiom sourceAx : sourceAxioms2OPlus.keySet()) {
                        if (sourceAxioms2OPlus.get(sourceAx).contains(sca)) {
                            Set<OWLSubClassOfAxiom> subClassAxioms = source2AxiomMap.get(sourceAx);
                            if (subClassAxioms == null) {
                                subClassAxioms = new HashSet<OWLSubClassOfAxiom>();
                                source2AxiomMap.put(sourceAx, subClassAxioms);
                            }
                            subClassAxioms.add(sca);
                        }
                    }
                }
                else {
                    reconstituedAxioms.add(laconicAx);
                }
            }
            
            Set<OWLSubClassOfAxiom> consumedAxioms = new HashSet<OWLSubClassOfAxiom>();
            for (OWLClass lhs : lhs2SubClassAxiom.keySet()) {
                Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2SubClassAxiom = lhs2SubClassAxiom.get(lhs);
                for (OWLAxiom source : source2SubClassAxiom.keySet()) {
                    Set<OWLClassExpression> rightHandSides = new HashSet<OWLClassExpression>();
                    for (OWLSubClassOfAxiom subClassAx : source2SubClassAxiom.get(source)) {
                        if (!consumedAxioms.contains(subClassAx)) {
                            rightHandSides.add(subClassAx.getSuperClass());
                            consumedAxioms.add(subClassAx);
                        }
                    }
                    if (rightHandSides.size() == 1) {
                        reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, rightHandSides.iterator().next()));
                    }
                    else if (rightHandSides.size() > 1) {
                        OWLObjectIntersectionOf conjunction = man.getOWLDataFactory().getOWLObjectIntersectionOf(rightHandSides);
                        reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, conjunction));
                    }
                }
            }
            Explanation<E> explanation = new Explanation<E>(laconicExp.getEntailment(), reconstituedAxioms);
            reconstituedExplanations.add(explanation);

        }
        return reconstituedExplanations;
    }

// ORIGINAL CODESEARCHNET METHOD — END

}








final class IRI implements Comparable<IRI>
{
   private final String value;

   private IRI(String value)
   {
      this.value = value;
   }

   public static IRI create(String value)
   {
      return new IRI(value);
   }

   @Override
   public String toString()
   {
      return value;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof IRI) && ((IRI) o).value.equals(value);
   }

   @Override
   public int hashCode()
   {
      return value.hashCode();
   }

   @Override
   public int compareTo(IRI o)
   {
      return value.compareTo(o.value);
   }
}


interface OWLClassExpression
{
   boolean isAnonymous();

   OWLClass asOWLClass();

   
   Set<OWLClassExpression> asConjunctSet();
}


final class OWLClass implements OWLClassExpression, Comparable<OWLClass>
{
   private final IRI iri;

   OWLClass(IRI iri)
   {
      this.iri = iri;
   }

   public IRI getIRI()
   {
      return iri;
   }

   public boolean isAnonymous()
   {
      return false;
   }

   public OWLClass asOWLClass()
   {
      return this;
   }

   public Set<OWLClassExpression> asConjunctSet()
   {
      return Collections.<OWLClassExpression>singleton(this);
   }

   @Override
   public String toString()
   {
      return "<" + iri + ">";
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLClass) && ((OWLClass) o).iri.equals(iri);
   }

   @Override
   public int hashCode()
   {
      return iri.hashCode();
   }

   @Override
   public int compareTo(OWLClass o)
   {
      return iri.compareTo(o.iri);
   }
}


final class OWLObjectIntersectionOf implements OWLClassExpression
{
   private final Set<OWLClassExpression> operands;

   OWLObjectIntersectionOf(Set<OWLClassExpression> operands)
   {
      this.operands = Collections.unmodifiableSet(new HashSet<OWLClassExpression>(operands));
   }

   public Set<OWLClassExpression> getOperands()
   {
      return operands;
   }

   public boolean isAnonymous()
   {
      return true;
   }

   public OWLClass asOWLClass()
   {
      throw new UnsupportedOperationException("not a named class");
   }

   public Set<OWLClassExpression> asConjunctSet()
   {
      return operands;
   }

   @Override
   public String toString()
   {
      StringBuilder sb = new StringBuilder("ObjectIntersectionOf(");
      List<OWLClassExpression> sorted = new ArrayList<OWLClassExpression>(operands);
      Collections.sort(sorted, (a, b) -> a.toString().compareTo(b.toString()));
      for (int i = 0; i < sorted.size(); i++)
      {
         if (i > 0)
         {
            sb.append(" ");
         }
         sb.append(sorted.get(i));
      }
      sb.append(")");
      return sb.toString();
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLObjectIntersectionOf) && ((OWLObjectIntersectionOf) o).operands.equals(operands);
   }

   @Override
   public int hashCode()
   {
      return operands.hashCode();
   }
}


interface OWLAxiom
{
}


interface OWLSubClassOfAxiom extends OWLAxiom
{
   OWLClassExpression getSubClass();

   OWLClassExpression getSuperClass();
}

final class OWLSubClassOfAxiomImpl implements OWLSubClassOfAxiom, Comparable<OWLSubClassOfAxiomImpl>
{
   private final OWLClassExpression subClass;
   private final OWLClassExpression superClass;

   OWLSubClassOfAxiomImpl(OWLClassExpression subClass, OWLClassExpression superClass)
   {
      this.subClass = subClass;
      this.superClass = superClass;
   }

   public OWLClassExpression getSubClass()
   {
      return subClass;
   }

   public OWLClassExpression getSuperClass()
   {
      return superClass;
   }

   @Override
   public String toString()
   {
      return "SubClassOf(" + subClass + " " + superClass + ")";
   }

   @Override
   public boolean equals(Object o)
   {
      if (!(o instanceof OWLSubClassOfAxiomImpl))
      {
         return false;
      }
      OWLSubClassOfAxiomImpl other = (OWLSubClassOfAxiomImpl) o;
      return other.subClass.equals(subClass) && other.superClass.equals(superClass);
   }

   @Override
   public int hashCode()
   {
      return subClass.hashCode() * 31 + superClass.hashCode();
   }

   @Override
   public int compareTo(OWLSubClassOfAxiomImpl o)
   {
      return toString().compareTo(o.toString());
   }
}



final class OpaqueAxiom implements OWLAxiom
{
   private final String label;

   OpaqueAxiom(String label)
   {
      this.label = label;
   }

   @Override
   public String toString()
   {
      return label;
   }
}


interface OWLDataFactory
{
   OWLClass getOWLClass(IRI iri);

   OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClassExpression subClass, OWLClassExpression superClass);

   OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression> operands);
}

final class OWLDataFactoryImpl implements OWLDataFactory
{
   public OWLClass getOWLClass(IRI iri)
   {
      return new OWLClass(iri);
   }

   public OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClassExpression subClass, OWLClassExpression superClass)
   {
      return new OWLSubClassOfAxiomImpl(subClass, superClass);
   }

   public OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression> operands)
   {
      return new OWLObjectIntersectionOf(operands);
   }
}


final class OWLOntology
{
   final Set<OWLAxiom> axioms;

   OWLOntology(Set<OWLAxiom> axioms)
   {
      this.axioms = new HashSet<OWLAxiom>(axioms);
   }

   public boolean containsAxiom(OWLAxiom axiom)
   {
      return axioms.contains(axiom);
   }
}


final class OWLOntologyManager
{
   private final OWLDataFactory dataFactory = new OWLDataFactoryImpl();

   public OWLDataFactory getOWLDataFactory()
   {
      return dataFactory;
   }

   public OWLOntology createOntology(Set<OWLAxiom> axioms)
   {
      return new OWLOntology(axioms);
   }
}


final class OWLManager
{
   public static OWLOntologyManager createOWLOntologyManager()
   {
      return new OWLOntologyManager();
   }
}





class Explanation<E>
{
   private final E entailment;
   private final Set<OWLAxiom> justification;

   Explanation(E entailment, Set<OWLAxiom> justification)
   {
      this.entailment = entailment;
      this.justification = Collections.unmodifiableSet(new HashSet<OWLAxiom>(justification));
   }

   public E getEntailment()
   {
      return entailment;
   }

   public Set<OWLAxiom> getAxioms()
   {
      return justification;
   }
}
