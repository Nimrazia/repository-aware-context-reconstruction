





























import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class method_4_owlexplanation_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== Explanation.store(Explanation<OWLAxiom>, OutputStream) - repository-aware reconstruction ===");
      System.out.println("Repository : matthewhorridge/owlexplanation @ 439c5ca67835f5e421adde725e4e8a3bcd760ac8");
      System.out.println("OWL API    : lightweight adaptation (owlapi-osgidistribution:4.5.10 unavailable offline)");
      System.out.println();

      OWLDataFactory df = new OWLDataFactoryImpl();

      OWLClass person = df.getOWLClass(IRI.create("http://example.org/onto#Person"));
      OWLClass agent = df.getOWLClass(IRI.create("http://example.org/onto#Agent"));
      OWLClass mortal = df.getOWLClass(IRI.create("http://example.org/onto#Mortal"));

      OWLAxiom personSubAgent = df.getOWLSubClassOfAxiom(person, agent);
      OWLAxiom agentSubMortal = df.getOWLSubClassOfAxiom(agent, mortal);
      OWLAxiom entailment = df.getOWLSubClassOfAxiom(person, mortal);

      Set<OWLAxiom> justification = new HashSet<OWLAxiom>();
      justification.add(personSubAgent);
      justification.add(agentSubMortal);

      Explanation<OWLAxiom> explanation = new Explanation<OWLAxiom>(entailment, justification);

      System.out.println("--- explanation to be stored ---");
      System.out.print(explanation);
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 1: Explanation.store(explanation, OutputStream) ---");
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      Explanation.store(explanation, baos);
      byte[] serialised = baos.toByteArray();
      String text = new String(serialised, "UTF-8");
      System.out.println("bytes written : " + serialised.length);
      System.out.println(indent(text));
      System.out.println("entailment-marker IRI present : "
            + text.contains(Explanation.ENTAILMENT_MARKER_IRI.toString()));
      System.out.println("justification axiom count in stream : "
            + countOccurrences(text, "<SubClassOf") + " - 1 (entailment itself also SubClassOf)");
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 2: round-trip through Explanation.load(InputStream) ---");
      Explanation<OWLAxiom> reloaded = Explanation.load(new ByteArrayInputStream(serialised));
      System.out.println("reloaded entailment equals original     : " + reloaded.getEntailment().equals(entailment));
      System.out.println("reloaded justification equals original  : " + reloaded.getAxioms().equals(justification));
      System.out.println("reloaded explanation equals original     : " + reloaded.equals(explanation));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 3: storing an empty explanation ---");
      Explanation<OWLAxiom> empty = Explanation.getEmptyExplanation(entailment);
      ByteArrayOutputStream baosEmpty = new ByteArrayOutputStream();
      Explanation.store(empty, baosEmpty);
      Explanation<OWLAxiom> reloadedEmpty = Explanation.load(new ByteArrayInputStream(baosEmpty.toByteArray()));
      System.out.println("stored/reloaded empty explanation is empty : " + reloadedEmpty.isEmpty());
      System.out.println("stored/reloaded entailment matches         : "
            + reloadedEmpty.getEntailment().equals(entailment));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 4: store() wraps ontology creation failure ---");
      Explanation<OWLAxiom> conflicting = new Explanation<OWLAxiom>(entailment, justification);
      FailingOntologyManagerInstaller.installFailingManagerForNextCreateOntology();
      try
      {
         Explanation.store(conflicting, new ByteArrayOutputStream());
         System.out.println("!! expected a RuntimeException");
      }
      catch (RuntimeException e)
      {
         System.out.println("RuntimeException correctly thrown, cause : "
               + (e.getCause() == null ? "<none>" : e.getCause().getClass().getSimpleName()));
      }
      finally
      {
         FailingOntologyManagerInstaller.restore();
      }

      System.out.println();
      System.out.println("=== done ===");
   }

   private static String indent(String s)
   {
      StringBuilder sb = new StringBuilder();
      for (String line : s.split("\n"))
      {
         sb.append("    | ").append(line).append('\n');
      }
      return sb.toString();
   }

   private static int countOccurrences(String haystack, String needle)
   {
      int count = 0;
      int idx = haystack.indexOf(needle);
      while (idx >= 0)
      {
         count++;
         idx = haystack.indexOf(needle, idx + needle.length());
      }
      return count;
   }
}










class Explanation<E>
{
   public static final IRI ENTAILMENT_MARKER_IRI = IRI.create("http://owl.cs.manchester.ac.uk/explanation/vocabulary#entailment");

   private E entailment;

   private Set<OWLAxiom> justification;

   



   public E getEntailment()
   {
      return entailment;
   }


   



   public Set<OWLAxiom> getAxioms()
   {
      return justification;
   }

   




   public int getSize()
   {
      return justification.size();
   }

   





   public boolean isEmpty()
   {
      return justification.isEmpty();
   }

   





   public boolean contains(OWLAxiom axiom)
   {
      return justification.contains(axiom);
   }


   




   public boolean isJustificationEntailment()
   {
      return Collections.singleton(entailment).equals(justification);
   }


   



   public Set<OWLClassExpression> getNestedClassExpressions()
   {
      Set<OWLClassExpression> subConcepts = new HashSet<OWLClassExpression>();
      for (OWLAxiom ax : justification)
      {
         subConcepts.addAll(ax.getNestedClassExpressions());
      }
      return subConcepts;
   }


   public Explanation(E entailment, Set<OWLAxiom> justification)
   {
      this.entailment = entailment;
      this.justification = Collections.unmodifiableSet(new HashSet<OWLAxiom>(justification));
   }

   public static <E> Explanation<E> getEmptyExplanation(E entailment)
   {
      Set<OWLAxiom> emptySet = Collections.emptySet();
      return new Explanation<E>(entailment, emptySet);
   }


   public String toString()
   {
      StringBuilder sb = new StringBuilder();
      if (justification.isEmpty())
      {
         return "Explanation: <Empty>\n";
      }
      sb.append("Explanation <");
      sb.append(entailment);
      sb.append(">\n");
      Collection<OWLAxiom> orderedAxioms = new TreeSet<OWLAxiom>(justification);
      for (OWLAxiom ax : orderedAxioms)
      {
         sb.append("\t");
         sb.append(ax);
         sb.append("\n");
      }
      return sb.toString();
   }


   public boolean equals(Object obj)
   {
      if (obj == this)
      {
         return true;
      }
      if (!(obj instanceof Explanation))
      {
         return false;
      }
      Explanation other = (Explanation) obj;
      return other.getEntailment().equals(entailment) && other.getAxioms().equals(justification);
   }


   public int hashCode()
   {
      return (entailment != null ? entailment.hashCode() : 0) + justification.hashCode();
   }


// ORIGINAL CODESEARCHNET METHOD — START

public static void store(Explanation<OWLAxiom> explanation, OutputStream os) throws IOException {
        try {
            OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
            OWLOntology ontology = manager.createOntology(explanation.getAxioms());
            OWLDataFactory df = manager.getOWLDataFactory();
            OWLAnnotationProperty entailmentMarkerAnnotationProperty = df.getOWLAnnotationProperty(ENTAILMENT_MARKER_IRI);
            OWLAnnotation entailmentAnnotation = df.getOWLAnnotation(entailmentMarkerAnnotationProperty, df.getOWLLiteral(true));
            OWLAxiom annotatedEntailment = explanation.getEntailment().getAnnotatedAxiom(Collections.singleton(entailmentAnnotation));
            manager.addAxiom(ontology, annotatedEntailment);
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(os);
            OWLXMLDocumentFormat justificationOntologyFormat = new OWLXMLDocumentFormat();
            manager.saveOntology(ontology, justificationOntologyFormat, bufferedOutputStream);
        }
        catch (OWLOntologyStorageException | OWLOntologyCreationException e) {
            throw new RuntimeException(e);
        }

    }

// ORIGINAL CODESEARCHNET METHOD — END


   






   public static Explanation<OWLAxiom> load(InputStream is) throws IOException
   {
      try
      {
         OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
         OWLOntology ontology = manager.loadOntologyFromOntologyDocument(new BufferedInputStream(is));
         OWLDataFactory df = manager.getOWLDataFactory();
         OWLAnnotationProperty entailmentMarkerAnnotationProperty = df.getOWLAnnotationProperty(ENTAILMENT_MARKER_IRI);
         Set<OWLAxiom> justificationAxioms = new HashSet<OWLAxiom>();
         OWLAxiom entailment = null;
         for (OWLAxiom ax : ontology.getAxioms())
         {
            boolean isEntailmentAxiom = !ax.getAnnotations(entailmentMarkerAnnotationProperty).isEmpty();
            if (!isEntailmentAxiom)
            {
               justificationAxioms.add(ax);
            }
            else
            {
               entailment = ax.getAxiomWithoutAnnotations();
            }
         }
         if (entailment == null)
         {
            throw new IllegalStateException("Not a serialisation of an Explanation");
         }
         return new Explanation<OWLAxiom>(entailment, justificationAxioms);
      }
      catch (OWLOntologyCreationException e)
      {
         throw new RuntimeException(e);
      }
   }
}










final class IRI implements Comparable<IRI>
{
   private final String value;

   private IRI(String value)
   {
      this.value = value;
   }

   public static IRI create(String value)
   {
      return new IRI(value);
   }

   @Override
   public String toString()
   {
      return value;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof IRI) && ((IRI) o).value.equals(value);
   }

   @Override
   public int hashCode()
   {
      return value.hashCode();
   }

   @Override
   public int compareTo(IRI o)
   {
      return value.compareTo(o.value);
   }
}


interface OWLClassExpression
{
}


final class OWLClass implements OWLClassExpression, Comparable<OWLClass>
{
   private final IRI iri;

   OWLClass(IRI iri)
   {
      this.iri = iri;
   }

   public IRI getIRI()
   {
      return iri;
   }

   @Override
   public String toString()
   {
      return "<" + iri + ">";
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLClass) && ((OWLClass) o).iri.equals(iri);
   }

   @Override
   public int hashCode()
   {
      return iri.hashCode();
   }

   @Override
   public int compareTo(OWLClass o)
   {
      return iri.compareTo(o.iri);
   }
}


final class OWLAnnotationProperty
{
   private final IRI iri;

   OWLAnnotationProperty(IRI iri)
   {
      this.iri = iri;
   }

   public IRI getIRI()
   {
      return iri;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLAnnotationProperty) && ((OWLAnnotationProperty) o).iri.equals(iri);
   }

   @Override
   public int hashCode()
   {
      return iri.hashCode();
   }
}


final class OWLLiteral
{
   private final String lexicalForm;

   OWLLiteral(String lexicalForm)
   {
      this.lexicalForm = lexicalForm;
   }

   public String getLiteral()
   {
      return lexicalForm;
   }

   @Override
   public String toString()
   {
      return "\"" + lexicalForm + "\"";
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLLiteral) && ((OWLLiteral) o).lexicalForm.equals(lexicalForm);
   }

   @Override
   public int hashCode()
   {
      return lexicalForm.hashCode();
   }
}


final class OWLAnnotation
{
   private final OWLAnnotationProperty property;
   private final OWLLiteral value;

   OWLAnnotation(OWLAnnotationProperty property, OWLLiteral value)
   {
      this.property = property;
      this.value = value;
   }

   public OWLAnnotationProperty getProperty()
   {
      return property;
   }

   public OWLLiteral getValue()
   {
      return value;
   }
}







final class OWLAxiom implements Comparable<OWLAxiom>
{
   private final OWLClass subClass;
   private final OWLClass superClass;
   private final Set<OWLAnnotation> annotations;

   OWLAxiom(OWLClass subClass, OWLClass superClass, Set<OWLAnnotation> annotations)
   {
      this.subClass = subClass;
      this.superClass = superClass;
      this.annotations = Collections.unmodifiableSet(new HashSet<OWLAnnotation>(annotations));
   }

   public OWLClass getSubClass()
   {
      return subClass;
   }

   public OWLClass getSuperClass()
   {
      return superClass;
   }

   public Set<OWLAnnotation> getAnnotationsSet()
   {
      return annotations;
   }

   public Set<OWLAnnotation> getAnnotations(OWLAnnotationProperty property)
   {
      Set<OWLAnnotation> result = new HashSet<OWLAnnotation>();
      for (OWLAnnotation a : annotations)
      {
         if (a.getProperty().equals(property))
         {
            result.add(a);
         }
      }
      return result;
   }

   public OWLAxiom getAnnotatedAxiom(Set<OWLAnnotation> newAnnotations)
   {
      Set<OWLAnnotation> merged = new HashSet<OWLAnnotation>(annotations);
      merged.addAll(newAnnotations);
      return new OWLAxiom(subClass, superClass, merged);
   }

   public OWLAxiom getAxiomWithoutAnnotations()
   {
      return new OWLAxiom(subClass, superClass, Collections.<OWLAnnotation>emptySet());
   }

   public Set<OWLClassExpression> getNestedClassExpressions()
   {
      Set<OWLClassExpression> result = new HashSet<OWLClassExpression>();
      result.add(subClass);
      result.add(superClass);
      return result;
   }

   @Override
   public String toString()
   {
      return "SubClassOf(" + subClass + " " + superClass + ")";
   }

   @Override
   public boolean equals(Object o)
   {
      if (!(o instanceof OWLAxiom))
      {
         return false;
      }
      OWLAxiom other = (OWLAxiom) o;
      
      
      
      return other.subClass.equals(subClass) && other.superClass.equals(superClass);
   }

   @Override
   public int hashCode()
   {
      return subClass.hashCode() * 31 + superClass.hashCode();
   }

   @Override
   public int compareTo(OWLAxiom o)
   {
      int c = subClass.compareTo(o.subClass);
      if (c != 0)
      {
         return c;
      }
      return superClass.compareTo(o.superClass);
   }
}


interface OWLDataFactory
{
   OWLClass getOWLClass(IRI iri);

   OWLAxiom getOWLSubClassOfAxiom(OWLClass subClass, OWLClass superClass);

   OWLAnnotationProperty getOWLAnnotationProperty(IRI iri);

   OWLAnnotation getOWLAnnotation(OWLAnnotationProperty property, OWLLiteral value);

   OWLLiteral getOWLLiteral(boolean value);
}

final class OWLDataFactoryImpl implements OWLDataFactory
{
   public OWLClass getOWLClass(IRI iri)
   {
      return new OWLClass(iri);
   }

   public OWLAxiom getOWLSubClassOfAxiom(OWLClass subClass, OWLClass superClass)
   {
      return new OWLAxiom(subClass, superClass, Collections.<OWLAnnotation>emptySet());
   }

   public OWLAnnotationProperty getOWLAnnotationProperty(IRI iri)
   {
      return new OWLAnnotationProperty(iri);
   }

   public OWLAnnotation getOWLAnnotation(OWLAnnotationProperty property, OWLLiteral value)
   {
      return new OWLAnnotation(property, value);
   }

   public OWLLiteral getOWLLiteral(boolean value)
   {
      return new OWLLiteral(Boolean.toString(value));
   }
}


final class OWLOntology
{
   final List<OWLAxiom> axioms = new ArrayList<OWLAxiom>();

   public Set<OWLAxiom> getAxioms()
   {
      return new HashSet<OWLAxiom>(axioms);
   }
}


final class OWLXMLDocumentFormat
{
}


class OWLOntologyCreationException extends Exception
{
   OWLOntologyCreationException(String message)
   {
      super(message);
   }

   OWLOntologyCreationException(Throwable cause)
   {
      super(cause);
   }
}


class OWLOntologyStorageException extends Exception
{
   OWLOntologyStorageException(String message)
   {
      super(message);
   }

   OWLOntologyStorageException(Throwable cause)
   {
      super(cause);
   }
}








final class OWLOntologyManager
{
   private final OWLDataFactory dataFactory = new OWLDataFactoryImpl();
   private boolean failNextCreateOntology = false;

   public OWLDataFactory getOWLDataFactory()
   {
      return dataFactory;
   }

   void setFailNextCreateOntology(boolean fail)
   {
      this.failNextCreateOntology = fail;
   }

   public OWLOntology createOntology(Set<OWLAxiom> axioms) throws OWLOntologyCreationException
   {
      if (failNextCreateOntology)
      {
         failNextCreateOntology = false;
         throw new OWLOntologyCreationException("Injected failure for scenario 4");
      }
      OWLOntology ontology = new OWLOntology();
      ontology.axioms.addAll(axioms);
      return ontology;
   }

   public void addAxiom(OWLOntology ontology, OWLAxiom axiom)
   {
      ontology.axioms.add(axiom);
   }

   public void saveOntology(OWLOntology ontology, OWLXMLDocumentFormat format, OutputStream os)
         throws OWLOntologyStorageException
   {
      try
      {
         PrintWriter pw = new PrintWriter(new OutputStreamWriter(os, "UTF-8"));
         pw.println("<Ontology xmlns=\"http://www.w3.org/2002/07/owl#\">");
         for (OWLAxiom ax : ontology.axioms)
         {
            pw.print("  <SubClassOf");
            for (OWLAnnotation ann : ax.getAnnotationsSet())
            {
               pw.print(" ann=\"" + ann.getProperty().getIRI() + "=" + ann.getValue().getLiteral() + "\"");
            }
            pw.println(">");
            pw.println("    <Sub>" + ax.getSubClass().getIRI() + "</Sub>");
            pw.println("    <Sup>" + ax.getSuperClass().getIRI() + "</Sup>");
            pw.println("  </SubClassOf>");
         }
         pw.println("</Ontology>");
         pw.flush();
      }
      catch (IOException e)
      {
         throw new OWLOntologyStorageException(e);
      }
   }

   public OWLOntology loadOntologyFromOntologyDocument(InputStream is) throws OWLOntologyCreationException
   {
      try
      {
         OWLOntology ontology = new OWLOntology();
         BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
         String line;
         String pendingAnnAttr = null;
         OWLClass sub = null;
         OWLClass sup = null;
         while ((line = reader.readLine()) != null)
         {
            line = line.trim();
            if (line.startsWith("<SubClassOf"))
            {
               pendingAnnAttr = extractAttr(line, "ann");
               sub = null;
               sup = null;
            }
            else if (line.startsWith("<Sub>"))
            {
               sub = new OWLClass(IRI.create(between(line, "<Sub>", "</Sub>")));
            }
            else if (line.startsWith("<Sup>"))
            {
               sup = new OWLClass(IRI.create(between(line, "<Sup>", "</Sup>")));
            }
            else if (line.startsWith("</SubClassOf>"))
            {
               Set<OWLAnnotation> anns = new HashSet<OWLAnnotation>();
               if (pendingAnnAttr != null)
               {
                  int eq = pendingAnnAttr.indexOf('=');
                  OWLAnnotationProperty prop = new OWLAnnotationProperty(IRI.create(pendingAnnAttr.substring(0, eq)));
                  OWLLiteral lit = new OWLLiteral(pendingAnnAttr.substring(eq + 1));
                  anns.add(new OWLAnnotation(prop, lit));
               }
               ontology.axioms.add(new OWLAxiom(sub, sup, anns));
            }
         }
         return ontology;
      }
      catch (IOException e)
      {
         throw new OWLOntologyCreationException(e);
      }
   }

   private static String between(String s, String startTag, String endTag)
   {
      int start = s.indexOf(startTag) + startTag.length();
      int end = s.indexOf(endTag, start);
      return s.substring(start, end);
   }

   private static String extractAttr(String s, String attrName)
   {
      String marker = attrName + "=\"";
      int idx = s.indexOf(marker);
      if (idx < 0)
      {
         return null;
      }
      int start = idx + marker.length();
      int end = s.indexOf('"', start);
      return s.substring(start, end);
   }
}


final class OWLManager
{
   public static OWLOntologyManager createOWLOntologyManager()
   {
      OWLOntologyManager manager = FailingOntologyManagerInstaller.nextManager;
      if (manager != null)
      {
         FailingOntologyManagerInstaller.nextManager = null;
         return manager;
      }
      return new OWLOntologyManager();
   }
}







final class FailingOntologyManagerInstaller
{
   static OWLOntologyManager nextManager;

   static void installFailingManagerForNextCreateOntology()
   {
      OWLOntologyManager manager = new OWLOntologyManager();
      manager.setFailNextCreateOntology(true);
      nextManager = manager;
   }

   static void restore()
   {
      nextManager = null;
   }
}
