










































import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_3_owlexplanation_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== CompleteRootDerivedReasoner.getRootUnsatisfiableClasses() - repository-aware reconstruction ===");
      System.out.println("Repository : matthewhorridge/owlexplanation @ 439c5ca67835f5e421adde725e4e8a3bcd760ac8");
      System.out.println("OWL API    : lightweight adaptation (owlapi-osgidistribution:4.5.10 unavailable offline)");
      System.out.println();

      
      
      
      
      
      
      
      
      
      
      
      
      OWLDataFactory df = new OWLDataFactoryImpl();
      OWLClass root = df.getOWLClass(IRI.create("http://example.org/onto#Root"));
      OWLClass child = df.getOWLClass(IRI.create("http://example.org/onto#Child"));
      OWLClass independent = df.getOWLClass(IRI.create("http://example.org/onto#Independent"));
      OWLClass satisfiableThing = df.getOWLClass(IRI.create("http://example.org/onto#Fine"));

      Set<OWLAxiom> axioms = new HashSet<OWLAxiom>();
      axioms.add(df.getOWLSubClassOfAxiom(root, df.getOWLNothing()));
      axioms.add(df.getOWLSubClassOfAxiom(child, root));
      axioms.add(df.getOWLSubClassOfAxiom(independent, df.getOWLNothing()));

      OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
      OWLOntology ontology = manager.createOntology(axioms);

      OWLReasonerFactory reasonerFactory = new SubsumptionReasonerFactory();
      OWLReasoner baseReasoner = reasonerFactory.createReasoner(ontology);

      System.out.println("--- ontology ---");
      for (OWLAxiom ax : ontology.getLogicalAxioms())
      {
         System.out.println("  " + ax);
      }
      System.out.println("unsatisfiable classes (reasoner) : " + baseReasoner.getUnsatisfiableClasses());
      System.out.println();

      
      
      
      System.out.println("--- Scenario 1: getRootUnsatisfiableClasses() over root/child/independent ---");
      CompleteRootDerivedReasoner rdr = new CompleteRootDerivedReasoner(manager, baseReasoner, reasonerFactory);
      Set<OWLClass> roots = rdr.getRootUnsatisfiableClasses();
      System.out.println();
      System.out.println("roots returned            : " + roots);
      System.out.println("Root is a root             : " + roots.contains(root));
      System.out.println("Independent is a root      : " + roots.contains(independent));
      System.out.println("Child (dependent) excluded : " + !roots.contains(child));
      System.out.println("Fine (satisfiable) excluded: " + !roots.contains(satisfiableThing));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 2: interface methods that are always null in this implementation ---");
      System.out.println("getDependentChildClasses(root)      : " + rdr.getDependentChildClasses(root));
      System.out.println("getDependentDescendantClasses(root) : " + rdr.getDependentDescendantClasses(root));

      System.out.println();
      System.out.println("=== done ===");
   }
}





interface RootDerivedReasoner
{
   Set<OWLClass> getRootUnsatisfiableClasses() throws ExplanationException;

   Set<OWLClass> getDependentChildClasses(OWLClass cls);

   Set<OWLClass> getDependentDescendantClasses(OWLClass cls);
}





class CompleteRootDerivedReasoner implements RootDerivedReasoner
{
   private OWLOntologyManager manager;

   private OWLReasoner baseReasoner;

   private OWLReasonerFactory reasonerFactory;

   private Map<OWLClass, Set<Explanation<OWLAxiom>>> cls2JustificationMap;

   private Set<OWLClass> roots = new HashSet<OWLClass>();


   public CompleteRootDerivedReasoner(OWLOntologyManager manager, OWLReasoner baseReasoner, OWLReasonerFactory reasonerFactory)
   {
      this.manager = manager;
      this.baseReasoner = baseReasoner;
      this.reasonerFactory = reasonerFactory;
   }


// ORIGINAL CODESEARCHNET METHOD — START

    



    public Set<OWLClass> getRootUnsatisfiableClasses() throws ExplanationException {
        StructuralRootDerivedReasoner srd = new StructuralRootDerivedReasoner(manager, baseReasoner, reasonerFactory);
        Set<OWLClass> estimatedRoots = srd.getRootUnsatisfiableClasses();
        cls2JustificationMap = new HashMap<OWLClass, Set<Explanation<OWLAxiom>>>();
        Set<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
        for (OWLOntology ont : baseReasoner.getRootOntology().getImportsClosure()) {
            allAxioms.addAll(ont.getLogicalAxioms());
        }

        for (OWLClass cls : estimatedRoots) {
            cls2JustificationMap.put(cls, new HashSet<Explanation<OWLAxiom>>());
            System.out.println("POTENTIAL ROOT: " + cls);
        }
        System.out.println("Finding real roots from " + estimatedRoots.size() + " estimated roots");

        int done = 0;
        roots.addAll(estimatedRoots);
        for (final OWLClass estimatedRoot : estimatedRoots) {
            ExplanationGeneratorFactory<OWLAxiom> genFac = ExplanationManager.createExplanationGeneratorFactory(reasonerFactory);
            ExplanationGenerator<OWLAxiom> gen = genFac.createExplanationGenerator(allAxioms);
            OWLDataFactory df = manager.getOWLDataFactory();
            Set<Explanation<OWLAxiom>> expls = gen.getExplanations(df.getOWLSubClassOfAxiom(estimatedRoot, df.getOWLNothing()));
            cls2JustificationMap.get(estimatedRoot).addAll(expls);
            done++;
            System.out.println("Done " + done);
        }
        for(OWLClass clsA : estimatedRoots) {
            for(OWLClass clsB : estimatedRoots) {
                if (!clsA.equals(clsB)) {
                    Set<Explanation<OWLAxiom>> clsAExpls = cls2JustificationMap.get(clsA);
                    Set<Explanation<OWLAxiom>> clsBExpls = cls2JustificationMap.get(clsB);
                    boolean clsARootForClsB = false;
                    boolean clsBRootForClsA = false;
                    
                    for(Explanation<OWLAxiom> clsAExpl : clsAExpls) {
                        for(Explanation<OWLAxiom> clsBExpl : clsBExpls) {
                            if(isRootFor(clsAExpl, clsBExpl)) {
                                
                                clsARootForClsB = true;

                            }
                            else if(isRootFor(clsBExpl, clsAExpl)) {
                                
                                clsBRootForClsA = true;

                            }
                        }
                    }
                    if (!clsARootForClsB || !clsBRootForClsA) {
                        if(clsARootForClsB) {
                            roots.remove(clsB);
                        }
                        else if(clsBRootForClsA) {
                            roots.remove(clsA);
                        }
                    }
                }
            }
        }
        return roots;
    }

// ORIGINAL CODESEARCHNET METHOD — END


   private static boolean isRootFor(Explanation<OWLAxiom> explA, Explanation<OWLAxiom> explB)
   {
      return explB.getAxioms().containsAll(explA.getAxioms()) && !explA.getAxioms().equals(explB.getAxioms());
   }

   public Set<OWLClass> getDependentChildClasses(OWLClass cls)
   {
      return null;
   }

   public Set<OWLClass> getDependentDescendantClasses(OWLClass cls)
   {
      return null;
   }
}











class StructuralRootDerivedReasoner implements RootDerivedReasoner
{
   private final OWLOntologyManager man;
   private final OWLReasoner reasoner;
   private final OWLReasonerFactory reasonerFactory;

   public StructuralRootDerivedReasoner(OWLOntologyManager man, OWLReasoner reasoner, OWLReasonerFactory reasonerFactory)
   {
      this.man = man;
      this.reasoner = reasoner;
      this.reasonerFactory = reasonerFactory;
   }

   public Set<OWLClass> getRootUnsatisfiableClasses()
   {
      Set<OWLClass> unsatisfiable = reasoner.getUnsatisfiableClasses();
      
      
      
      
      Map<OWLClass, Set<OWLClass>> structuralSuperClasses = new HashMap<OWLClass, Set<OWLClass>>();
      for (OWLOntology ont : reasoner.getRootOntology().getImportsClosure())
      {
         for (OWLAxiom ax : ont.getLogicalAxioms())
         {
            if (ax instanceof OWLSubClassOfAxiom)
            {
               OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) ax;
               if (sca.getSuperClass().isOWLNothing())
               {
                  continue;
               }
               Set<OWLClass> supers = structuralSuperClasses.get(sca.getSubClass());
               if (supers == null)
               {
                  supers = new HashSet<OWLClass>();
                  structuralSuperClasses.put(sca.getSubClass(), supers);
               }
               supers.add(sca.getSuperClass());
            }
         }
      }
      Set<OWLClass> estimatedRoots = new HashSet<OWLClass>();
      for (OWLClass cls : unsatisfiable)
      {
         boolean inheritsFromUnsatisfiableSuperClass = false;
         Set<OWLClass> supers = structuralSuperClasses.get(cls);
         if (supers != null)
         {
            for (OWLClass superCls : supers)
            {
               if (unsatisfiable.contains(superCls))
               {
                  inheritsFromUnsatisfiableSuperClass = true;
                  break;
               }
            }
         }
         if (!inheritsFromUnsatisfiableSuperClass)
         {
            estimatedRoots.add(cls);
         }
      }
      return estimatedRoots;
   }

   public Set<OWLClass> getDependentChildClasses(OWLClass cls)
   {
      return null;
   }

   public Set<OWLClass> getDependentDescendantClasses(OWLClass cls)
   {
      return null;
   }
}







final class IRI implements Comparable<IRI>
{
   private final String value;

   private IRI(String value)
   {
      this.value = value;
   }

   public static IRI create(String value)
   {
      return new IRI(value);
   }

   @Override
   public String toString()
   {
      return value;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof IRI) && ((IRI) o).value.equals(value);
   }

   @Override
   public int hashCode()
   {
      return value.hashCode();
   }

   @Override
   public int compareTo(IRI o)
   {
      return value.compareTo(o.value);
   }
}

final class OWLClass implements Comparable<OWLClass>
{
   private final IRI iri;
   private final boolean isNothing;

   OWLClass(IRI iri)
   {
      this(iri, false);
   }

   OWLClass(IRI iri, boolean isNothing)
   {
      this.iri = iri;
      this.isNothing = isNothing;
   }

   public IRI getIRI()
   {
      return iri;
   }

   public boolean isOWLNothing()
   {
      return isNothing;
   }

   @Override
   public String toString()
   {
      return isNothing ? "owl:Nothing" : "<" + iri + ">";
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLClass) && ((OWLClass) o).iri.equals(iri);
   }

   @Override
   public int hashCode()
   {
      return iri.hashCode();
   }

   @Override
   public int compareTo(OWLClass o)
   {
      return iri.compareTo(o.iri);
   }
}

interface OWLAxiom
{
}

interface OWLSubClassOfAxiom extends OWLAxiom
{
   OWLClass getSubClass();

   OWLClass getSuperClass();
}

final class OWLSubClassOfAxiomImpl implements OWLSubClassOfAxiom, Comparable<OWLSubClassOfAxiomImpl>
{
   private final OWLClass subClass;
   private final OWLClass superClass;

   OWLSubClassOfAxiomImpl(OWLClass subClass, OWLClass superClass)
   {
      this.subClass = subClass;
      this.superClass = superClass;
   }

   public OWLClass getSubClass()
   {
      return subClass;
   }

   public OWLClass getSuperClass()
   {
      return superClass;
   }

   @Override
   public String toString()
   {
      return "SubClassOf(" + subClass + " " + superClass + ")";
   }

   @Override
   public boolean equals(Object o)
   {
      if (!(o instanceof OWLSubClassOfAxiomImpl))
      {
         return false;
      }
      OWLSubClassOfAxiomImpl other = (OWLSubClassOfAxiomImpl) o;
      return other.subClass.equals(subClass) && other.superClass.equals(superClass);
   }

   @Override
   public int hashCode()
   {
      return subClass.hashCode() * 31 + superClass.hashCode();
   }

   @Override
   public int compareTo(OWLSubClassOfAxiomImpl o)
   {
      return toString().compareTo(o.toString());
   }
}

interface OWLDataFactory
{
   OWLClass getOWLClass(IRI iri);

   OWLClass getOWLNothing();

   OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClass subClass, OWLClass superClass);
}

final class OWLDataFactoryImpl implements OWLDataFactory
{
   private static final OWLClass NOTHING = new OWLClass(IRI.create("http://www.w3.org/2002/07/owl#Nothing"), true);

   public OWLClass getOWLClass(IRI iri)
   {
      return new OWLClass(iri);
   }

   public OWLClass getOWLNothing()
   {
      return NOTHING;
   }

   public OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClass subClass, OWLClass superClass)
   {
      return new OWLSubClassOfAxiomImpl(subClass, superClass);
   }
}

final class OWLOntology
{
   private final Set<OWLAxiom> axioms;

   OWLOntology(Set<OWLAxiom> axioms)
   {
      this.axioms = new HashSet<OWLAxiom>(axioms);
   }

   public Set<OWLAxiom> getLogicalAxioms()
   {
      return axioms;
   }

   


   public Set<OWLOntology> getImportsClosure()
   {
      return Collections.singleton(this);
   }
}

final class OWLOntologyManager
{
   private final OWLDataFactory dataFactory = new OWLDataFactoryImpl();

   public OWLDataFactory getOWLDataFactory()
   {
      return dataFactory;
   }

   public OWLOntology createOntology(Set<OWLAxiom> axioms)
   {
      return new OWLOntology(axioms);
   }
}

final class OWLManager
{
   public static OWLOntologyManager createOWLOntologyManager()
   {
      return new OWLOntologyManager();
   }
}





interface OWLReasoner
{
   OWLOntology getRootOntology();

   Set<OWLClass> getUnsatisfiableClasses();

   boolean isSatisfiable(OWLClass cls);
}


interface OWLReasonerFactory
{
   OWLReasoner createReasoner(OWLOntology ontology);
}







final class SubsumptionReasoner implements OWLReasoner
{
   private final OWLOntology ontology;
   private final Map<OWLClass, Set<OWLClass>> subClassToSuperClasses = new HashMap<OWLClass, Set<OWLClass>>();

   SubsumptionReasoner(OWLOntology ontology)
   {
      this.ontology = ontology;
      for (OWLAxiom ax : ontology.getLogicalAxioms())
      {
         if (ax instanceof OWLSubClassOfAxiom)
         {
            OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) ax;
            Set<OWLClass> supers = subClassToSuperClasses.get(sca.getSubClass());
            if (supers == null)
            {
               supers = new HashSet<OWLClass>();
               subClassToSuperClasses.put(sca.getSubClass(), supers);
            }
            supers.add(sca.getSuperClass());
         }
      }
   }

   public OWLOntology getRootOntology()
   {
      return ontology;
   }

   public boolean isSatisfiable(OWLClass cls)
   {
      Set<OWLClass> visited = new HashSet<OWLClass>();
      List<OWLClass> frontier = new ArrayList<OWLClass>();
      frontier.add(cls);
      visited.add(cls);
      while (!frontier.isEmpty())
      {
         OWLClass current = frontier.remove(frontier.size() - 1);
         if (current.isOWLNothing())
         {
            return false;
         }
         Set<OWLClass> supers = subClassToSuperClasses.get(current);
         if (supers != null)
         {
            for (OWLClass s : supers)
            {
               if (visited.add(s))
               {
                  frontier.add(s);
               }
            }
         }
      }
      return true;
   }

   public Set<OWLClass> getUnsatisfiableClasses()
   {
      Set<OWLClass> result = new HashSet<OWLClass>();
      for (OWLClass cls : subClassToSuperClasses.keySet())
      {
         if (!isSatisfiable(cls))
         {
            result.add(cls);
         }
      }
      return result;
   }
}

final class SubsumptionReasonerFactory implements OWLReasonerFactory
{
   public OWLReasoner createReasoner(OWLOntology ontology)
   {
      return new SubsumptionReasoner(ontology);
   }
}


class ExplanationException extends Exception
{
   ExplanationException(String message)
   {
      super(message);
   }

   ExplanationException(Throwable cause)
   {
      super(cause);
   }
}


class Explanation<E>
{
   private final E entailment;
   private final Set<OWLAxiom> justification;

   Explanation(E entailment, Set<OWLAxiom> justification)
   {
      this.entailment = entailment;
      this.justification = Collections.unmodifiableSet(new HashSet<OWLAxiom>(justification));
   }

   public E getEntailment()
   {
      return entailment;
   }

   public Set<OWLAxiom> getAxioms()
   {
      return justification;
   }

   @Override
   public String toString()
   {
      return "Explanation<" + entailment + ", " + justification + ">";
   }
}


interface ExplanationGenerator<E>
{
   Set<Explanation<E>> getExplanations(E entailment);
}


interface ExplanationGeneratorFactory<E>
{
   ExplanationGenerator<E> createExplanationGenerator(Set<? extends OWLAxiom> axioms);
}








final class ExplanationManager
{
   public static ExplanationGeneratorFactory<OWLAxiom> createExplanationGeneratorFactory(OWLReasonerFactory reasonerFactory)
   {
      return new ExplanationGeneratorFactory<OWLAxiom>()
      {
         public ExplanationGenerator<OWLAxiom> createExplanationGenerator(final Set<? extends OWLAxiom> axioms)
         {
            return new ExplanationGenerator<OWLAxiom>()
            {
               public Set<Explanation<OWLAxiom>> getExplanations(OWLAxiom entailment)
               {
                  if (!(entailment instanceof OWLSubClassOfAxiom))
                  {
                     return Collections.emptySet();
                  }
                  OWLSubClassOfAxiom target = (OWLSubClassOfAxiom) entailment;
                  Set<OWLAxiom> pool = new HashSet<OWLAxiom>(axioms);
                  Set<Explanation<OWLAxiom>> results = new HashSet<Explanation<OWLAxiom>>();
                  
                  
                  Map<OWLClass, List<OWLSubClassOfAxiom>> outgoing = new HashMap<OWLClass, List<OWLSubClassOfAxiom>>();
                  for (OWLAxiom ax : pool)
                  {
                     if (ax instanceof OWLSubClassOfAxiom)
                     {
                        OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) ax;
                        List<OWLSubClassOfAxiom> list = outgoing.get(sca.getSubClass());
                        if (list == null)
                        {
                           list = new ArrayList<OWLSubClassOfAxiom>();
                           outgoing.put(sca.getSubClass(), list);
                        }
                        list.add(sca);
                     }
                  }
                  findPaths(target.getSubClass(), target.getSuperClass(), outgoing,
                        new ArrayList<OWLSubClassOfAxiom>(), new HashSet<OWLClass>(), results);
                  return results;
               }

               private void findPaths(OWLClass current, OWLClass goal, Map<OWLClass, List<OWLSubClassOfAxiom>> outgoing,
                     List<OWLSubClassOfAxiom> pathSoFar, Set<OWLClass> onPath, Set<Explanation<OWLAxiom>> results)
               {
                  if (current.equals(goal) && !pathSoFar.isEmpty())
                  {
                     results.add(new Explanation<OWLAxiom>(new OWLSubClassOfAxiomImpl(pathSoFar.get(0).getSubClass(), goal),
                           new HashSet<OWLAxiom>(pathSoFar)));
                     return;
                  }
                  List<OWLSubClassOfAxiom> edges = outgoing.get(current);
                  if (edges == null || onPath.contains(current))
                  {
                     return;
                  }
                  onPath.add(current);
                  for (OWLSubClassOfAxiom edge : edges)
                  {
                     pathSoFar.add(edge);
                     findPaths(edge.getSuperClass(), goal, outgoing, pathSoFar, onPath, results);
                     pathSoFar.remove(pathSoFar.size() - 1);
                  }
                  onPath.remove(current);
               }
            };
         }
      };
   }
}
