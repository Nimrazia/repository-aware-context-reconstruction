






























import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_5_owlexplanation_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== BlackBoxExplanationGenerator.constructHittingSetTree(...) - repository-aware reconstruction ===");
      System.out.println("Repository : matthewhorridge/owlexplanation @ 439c5ca67835f5e421adde725e4e8a3bcd760ac8");
      System.out.println("OWL API / ordering lib : lightweight adaptations (both unavailable offline)");
      System.out.println();

      
      
      
      
      
      
      
      
      
      
      OWLDataFactory df = new OWLDataFactoryImpl();
      OWLClass person = df.getOWLClass(IRI.create("http://example.org/onto#Person"));
      OWLClass agent = df.getOWLClass(IRI.create("http://example.org/onto#Agent"));
      OWLClass livingThing = df.getOWLClass(IRI.create("http://example.org/onto#LivingThing"));
      OWLClass mortal = df.getOWLClass(IRI.create("http://example.org/onto#Mortal"));

      OWLAxiom a1 = df.getOWLSubClassOfAxiom(person, mortal);                 
      OWLAxiom a2 = df.getOWLSubClassOfAxiom(person, agent);                  
      OWLAxiom a3 = df.getOWLSubClassOfAxiom(agent, mortal);                  
      OWLAxiom a4 = df.getOWLSubClassOfAxiom(person, livingThing);            
      OWLAxiom a5 = df.getOWLSubClassOfAxiom(livingThing, mortal);            

      Set<OWLAxiom> ontologyAxioms = new HashSet<OWLAxiom>();
      Collections.addAll(ontologyAxioms, a1, a2, a3, a4, a5);

      OWLAxiom entailment = df.getOWLSubClassOfAxiom(person, mortal);

      System.out.println("--- ontology (3 independent justifications for Person subClassOf Mortal) ---");
      for (OWLAxiom ax : ontologyAxioms)
      {
         System.out.println("  " + ax);
      }
      System.out.println();

      RecordingStrategies strategies = new RecordingStrategies();
      BlackBoxExplanationGenerator<OWLAxiom> gen = new BlackBoxExplanationGenerator<OWLAxiom>(
            ontologyAxioms, new SubsumptionCheckerFactory(), strategies, strategies, null);

      
      
      
      
      
      System.out.println("--- Scenario 1: getExplanations(entailment) - unlimited ---");
      Set<Explanation<OWLAxiom>> allExplanations = gen.getExplanations(entailment);
      System.out.println("justifications found : " + allExplanations.size());
      for (Explanation<OWLAxiom> exp : allExplanations)
      {
         System.out.println("  " + exp.getAxioms());
      }
      System.out.println("J1={a1} found            : " + containsExactly(allExplanations, a1));
      System.out.println("J2={a2,a3} found          : " + containsExactly(allExplanations, a2, a3));
      System.out.println("J3={a4,a5} found          : " + containsExactly(allExplanations, a4, a5));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 2: getExplanations(entailment, 1) - limited to 1 ---");
      RecordingStrategies strategies2 = new RecordingStrategies();
      BlackBoxExplanationGenerator<OWLAxiom> gen2 = new BlackBoxExplanationGenerator<OWLAxiom>(
            ontologyAxioms, new SubsumptionCheckerFactory(), strategies2, strategies2, null);
      Set<Explanation<OWLAxiom>> limited = gen2.getExplanations(entailment, 1);
      System.out.println("justifications found (limit=1) : " + limited.size());
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: entailment that does not hold ---");
      OWLClass unrelated = df.getOWLClass(IRI.create("http://example.org/onto#Unrelated"));
      OWLAxiom notEntailed = df.getOWLSubClassOfAxiom(unrelated, mortal);
      RecordingStrategies strategies3 = new RecordingStrategies();
      BlackBoxExplanationGenerator<OWLAxiom> gen3 = new BlackBoxExplanationGenerator<OWLAxiom>(
            ontologyAxioms, new SubsumptionCheckerFactory(), strategies3, strategies3, null);
      Set<Explanation<OWLAxiom>> noneFound = gen3.getExplanations(notEntailed);
      System.out.println("justifications found : " + noneFound.size());
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 4: getExplanations(entailment, 2) - capped mid-search ---");
      RecordingStrategies strategies4 = new RecordingStrategies();
      BlackBoxExplanationGenerator<OWLAxiom> gen4 = new BlackBoxExplanationGenerator<OWLAxiom>(
            ontologyAxioms, new SubsumptionCheckerFactory(), strategies4, strategies4, null);
      Set<Explanation<OWLAxiom>> cappedAt2 = gen4.getExplanations(entailment, 2);
      System.out.println("justifications found (limit=2) : " + cappedAt2.size());
      System.out.println("cap respected (<=2)             : " + (cappedAt2.size() <= 2));

      System.out.println();
      System.out.println("=== done ===");
   }

   @SafeVarargs
   private static boolean containsExactly(Set<Explanation<OWLAxiom>> explanations, OWLAxiom... axioms)
   {
      Set<OWLAxiom> target = new HashSet<OWLAxiom>();
      Collections.addAll(target, axioms);
      for (Explanation<OWLAxiom> exp : explanations)
      {
         if (exp.getAxioms().equals(target))
         {
            return true;
         }
      }
      return false;
   }
}









class BlackBoxExplanationGenerator<E> implements ExplanationGenerator<E>
{
   private ExpansionStrategy expansionStrategy;

   private ContractionStrategy contractionStrategy;

   private EntailmentCheckerFactory<E> checkerFactory;

   private Set<OWLAxiom> workingAxioms;

   private Set<OWLAxiom> module = null;

   private MutableTree<Explanation> hst;

   private ExplanationProgressMonitor<E> progressMonitor;

   private List<Integer> prunningDifferences = new ArrayList<Integer>();

   private int hittingSetTreeOperationsCount = 0;

   public BlackBoxExplanationGenerator(Set<? extends OWLAxiom> axioms, EntailmentCheckerFactory<E> checkerFactory, ExpansionStrategy expansionStrategy, ContractionStrategy contractionStrategy, ExplanationProgressMonitor<E> progressMonitor)
   {
      workingAxioms = new HashSet<OWLAxiom>(axioms);
      this.checkerFactory = checkerFactory;
      this.expansionStrategy = expansionStrategy;
      this.contractionStrategy = contractionStrategy;
      if (progressMonitor != null)
      {
         this.progressMonitor = progressMonitor;
      }
      else
      {
         this.progressMonitor = new NullExplanationProgressMonitor<E>();
      }
   }

   protected void addPruningDifference(int diff)
   {
      prunningDifferences.add(diff);
   }

   public List<Integer> getPruningDifferences()
   {
      return Collections.unmodifiableList(prunningDifferences);
   }

   public Set<Explanation<E>> getExplanations(E entailment) throws ExplanationException
   {
      return getExplanations(entailment, Integer.MAX_VALUE);
   }

   public Set<Explanation<E>> getExplanations(E entailment, int limit) throws ExplanationException
   {
      try
      {
         module = extractModule(workingAxioms, checkerFactory.createEntailementChecker(entailment));
         hittingSetTreeOperationsCount = 0;
         prunningDifferences.clear();
         Set<Explanation<E>> explanations = new HashSet<Explanation<E>>();
         Explanation<E> expl = computeExplanation(entailment);
         explanations.add(expl);
         progressMonitor.foundExplanation(this, expl, Collections.unmodifiableSet(explanations));
         if (progressMonitor.isCancelled())
         {
            return Collections.singleton(expl);
         }
         hst = new MutableTree<Explanation>(expl);
         if (expl.isEmpty())
         {
            return Collections.emptySet();
         }
         if (limit > 1)
         {
            constructHittingSetTree(entailment, expl, explanations, new HashSet<Set<OWLAxiom>>(), new HashSet<OWLAxiom>(), limit);
         }

         if (explanations.isEmpty())
         {
            throw new NotEntailedException(entailment);
         }

         return explanations;
      }
      catch (OWLException e)
      {
         throw new ExplanationException(e);
      }
   }

   public Set<OWLAxiom> getWorkingAxioms()
   {
      return workingAxioms;
   }

   private int counter = 0;

   protected Explanation<E> computeExplanation(E entailment) throws OWLException
   {
      if (isLoggable())
      {
         log("Computing explanation");
      }
      counter++;

      EntailmentChecker<E> checker = checkerFactory.createEntailementChecker(entailment);

      if (!checker.isEntailed(module))
      {
         return Explanation.getEmptyExplanation(entailment);
      }

      if (progressMonitor.isCancelled())
      {
         return Explanation.getEmptyExplanation(entailment);
      }

      Set<OWLAxiom> expandedAxioms = expansionStrategy.doExpansion(module, checker, progressMonitor);

      if (progressMonitor.isCancelled())
      {
         return Explanation.getEmptyExplanation(entailment);
      }

      handlePostExpansion();

      Set<OWLAxiom> expandedAxiomsModule = extractModule(expandedAxioms, checker);
      int expandedSize = expandedAxioms.size();
      final Set<OWLAxiom> justification = contractionStrategy.doPruning(expandedAxiomsModule, checker, progressMonitor);
      int contractionSize = justification.size();
      int prunningDifference = expandedSize - contractionSize;
      prunningDifferences.add(prunningDifference);

      Explanation<E> expl = new Explanation<E>(entailment, justification);

      handlePostContraction(checker, expandedAxioms, justification);

      return expl;
   }

   protected Set<OWLAxiom> extractModule(Set<OWLAxiom> axioms, EntailmentChecker<E> checker)
   {
      return checker.getModule(axioms);
   }


// ORIGINAL CODESEARCHNET METHOD — START

    












    private void constructHittingSetTree(E entailment, Explanation<E> justification, Set<Explanation<E>> allJustifications,
                                         Set<Set<OWLAxiom>> satPaths, Set<OWLAxiom> currentPathContents,
                                         int maxExplanations) throws OWLException {


        
        
        List<OWLAxiom> orderedJustification = getOrderedJustifications(new ArrayList<OWLAxiom>(justification.getAxioms()), allJustifications);

        while (!orderedJustification.isEmpty()) {
            OWLAxiom axiom = orderedJustification.get(0);
            orderedJustification.remove(0);
            if (allJustifications.size() == maxExplanations) {
                return;
            }

            
            

            module.remove(axiom);
            currentPathContents.add(axiom);

            boolean earlyTermination = false;
            
            
            for (Set<OWLAxiom> satPath : satPaths) {
                if (currentPathContents.containsAll(satPath)) {
                    earlyTermination = true;
                    break;
                }
            }

            if (!earlyTermination) {
                Explanation<E> newJustification = null;
                for (Explanation<E> foundJustification : allJustifications) {
                    Set<OWLAxiom> foundMUPSCopy = new HashSet<OWLAxiom>(foundJustification.getAxioms());
                    foundMUPSCopy.retainAll(currentPathContents);
                    if (foundMUPSCopy.isEmpty()) {
                        
                        newJustification = foundJustification;
                        break;
                    }
                }
                if (newJustification == null) {
                    newJustification = computeExplanation(entailment);
                }
                
                if (axiom.isLogicalAxiom() && newJustification.contains(axiom)) {
                    
                    throw new OWLRuntimeException("Explanation contains removed axiom: " + axiom + " (Working axioms contains axiom: " + module.contains(axiom) + ")");
                }

                if (!newJustification.isEmpty()) {
                    
                    
                    
                    
                    boolean added = allJustifications.add(newJustification);
                    if (added) {
                        progressMonitor.foundExplanation(this, newJustification, allJustifications);
                    }
                    if (progressMonitor.isCancelled()) {
                        return;
                    }

                    


                    constructHittingSetTree(entailment,
                            newJustification,
                            allJustifications,
                            satPaths,
                            currentPathContents,
                            maxExplanations);
                    
                    
                    orderedJustification = getOrderedJustifications(orderedJustification, allJustifications);
                } else {
                    
                    satPaths.add(new HashSet<OWLAxiom>(currentPathContents));
                    Explanation exp = new Explanation<E>(entailment, new HashSet<OWLAxiom>(0));
                    MutableTree<Explanation> node = new MutableTree<Explanation>(exp);


                }
            }

            
            currentPathContents.remove(axiom);

            
            module.add(axiom);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


   private static <E> List<OWLAxiom> getOrderedJustifications(List<OWLAxiom> mups, final Set<Explanation<E>> allJustifications)
   {
      Comparator<OWLAxiom> mupsComparator = new Comparator<OWLAxiom>()
      {
         public int compare(OWLAxiom o1, OWLAxiom o2)
         {
            int occ1 = getOccurrences(o1, allJustifications);
            int occ2 = getOccurrences(o2, allJustifications);
            return -occ1 + occ2;
         }
      };
      Collections.sort(mups, mupsComparator);
      return mups;
   }

   private static <E> int getOccurrences(OWLAxiom ax, Set<Explanation<E>> axiomSets)
   {
      int count = 0;
      for (Explanation<E> explanation : axiomSets)
      {
         if (explanation.getAxioms().contains(ax))
         {
            count++;
         }
      }
      return count;
   }

   private static boolean isLoggable()
   {
      return false;
   }

   private static void log(String s)
   {
      System.out.println("[log] " + s);
   }

   private void handlePostExpansion()
   {
      if (isLoggable())
      {
         log("Post expansion");
      }
   }

   private void handlePostContraction(EntailmentChecker<E> checker, Set<OWLAxiom> expandedAxioms, final Set<OWLAxiom> justification)
   {
      if (isLoggable())
      {
         log("Post contraction");
      }
   }
}





interface EntailmentChecker<E>
{
   boolean isEntailed(Set<OWLAxiom> axioms);

   Set<OWLAxiom> getModule(Set<OWLAxiom> axioms);
}

interface EntailmentCheckerFactory<E>
{
   EntailmentChecker<E> createEntailementChecker(E entailment);
}

interface ExpansionStrategy
{
   <E> Set<OWLAxiom> doExpansion(Set<OWLAxiom> module, EntailmentChecker<E> checker, ExplanationProgressMonitor<E> progressMonitor);
}

interface ContractionStrategy
{
   <E> Set<OWLAxiom> doPruning(Set<OWLAxiom> expandedAxioms, EntailmentChecker<E> checker, ExplanationProgressMonitor<E> progressMonitor);
}

interface ExplanationProgressMonitor<E>
{
   void foundExplanation(Object explanationGenerator, Explanation<E> explanation, Set<Explanation<E>> allFoundExplanations);

   boolean isCancelled();
}

class NullExplanationProgressMonitor<E> implements ExplanationProgressMonitor<E>
{
   public void foundExplanation(Object explanationGenerator, Explanation<E> explanation, Set<Explanation<E>> allFoundExplanations)
   {
   }

   public boolean isCancelled()
   {
      return false;
   }
}

class ExplanationException extends Exception
{
   ExplanationException(String message)
   {
      super(message);
   }

   ExplanationException(Throwable cause)
   {
      super(cause);
   }
}

class NotEntailedException extends ExplanationException
{
   private Object entailment;

   public NotEntailedException(Object entailment)
   {
      super("Not entailed: " + entailment);
      this.entailment = entailment;
   }

   public Object getEntailment()
   {
      return entailment;
   }
}

interface ExplanationGenerator<E>
{
   Set<Explanation<E>> getExplanations(E entailment) throws ExplanationException;

   Set<Explanation<E>> getExplanations(E entailment, int limit) throws ExplanationException;
}






class MutableTree<T>
{
   private final T userObject;

   MutableTree(T userObject)
   {
      this.userObject = userObject;
   }

   public T getUserObject()
   {
      return userObject;
   }
}








class RecordingStrategies implements ExpansionStrategy, ContractionStrategy
{
   public <E> Set<OWLAxiom> doExpansion(Set<OWLAxiom> module, EntailmentChecker<E> checker, ExplanationProgressMonitor<E> progressMonitor)
   {
      if (checker.isEntailed(module))
      {
         return new HashSet<OWLAxiom>(module);
      }
      return Collections.emptySet();
   }

   public <E> Set<OWLAxiom> doPruning(Set<OWLAxiom> expandedAxioms, EntailmentChecker<E> checker, ExplanationProgressMonitor<E> progressMonitor)
   {
      Set<OWLAxiom> current = new HashSet<OWLAxiom>(expandedAxioms);
      for (OWLAxiom ax : new HashSet<OWLAxiom>(expandedAxioms))
      {
         Set<OWLAxiom> without = new HashSet<OWLAxiom>(current);
         without.remove(ax);
         if (checker.isEntailed(without))
         {
            current = without;
         }
      }
      return current;
   }
}

class SubsumptionCheckerFactory implements EntailmentCheckerFactory<OWLAxiom>
{
   public EntailmentChecker<OWLAxiom> createEntailementChecker(final OWLAxiom entailment)
   {
      return new EntailmentChecker<OWLAxiom>()
      {
         public boolean isEntailed(Set<OWLAxiom> axioms)
         {
            if (!(entailment instanceof OWLSubClassOfAxiom))
            {
               return false;
            }
            OWLSubClassOfAxiom target = (OWLSubClassOfAxiom) entailment;
            Map<OWLClass, Set<OWLClass>> direct = new HashMap<OWLClass, Set<OWLClass>>();
            for (OWLAxiom ax : axioms)
            {
               if (!(ax instanceof OWLSubClassOfAxiom))
               {
                  continue;
               }
               OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) ax;
               Set<OWLClass> supers = direct.get(sca.getSubClass());
               if (supers == null)
               {
                  supers = new HashSet<OWLClass>();
                  direct.put(sca.getSubClass(), supers);
               }
               supers.add(sca.getSuperClass());
            }
            OWLClass start = target.getSubClass();
            OWLClass goal = target.getSuperClass();
            Set<OWLClass> visited = new HashSet<OWLClass>();
            List<OWLClass> frontier = new ArrayList<OWLClass>();
            frontier.add(start);
            visited.add(start);
            while (!frontier.isEmpty())
            {
               OWLClass current = frontier.remove(frontier.size() - 1);
               if (current.equals(goal))
               {
                  return true;
               }
               Set<OWLClass> supers = direct.get(current);
               if (supers != null)
               {
                  for (OWLClass s : supers)
                  {
                     if (visited.add(s))
                     {
                        frontier.add(s);
                     }
                  }
               }
            }
            return start.equals(goal);
         }

         public Set<OWLAxiom> getModule(Set<OWLAxiom> axioms)
         {
            return new HashSet<OWLAxiom>(axioms);
         }
      };
   }
}









final class IRI implements Comparable<IRI>
{
   private final String value;

   private IRI(String value)
   {
      this.value = value;
   }

   public static IRI create(String value)
   {
      return new IRI(value);
   }

   @Override
   public String toString()
   {
      return value;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof IRI) && ((IRI) o).value.equals(value);
   }

   @Override
   public int hashCode()
   {
      return value.hashCode();
   }

   @Override
   public int compareTo(IRI o)
   {
      return value.compareTo(o.value);
   }
}

final class OWLClass implements Comparable<OWLClass>
{
   private final IRI iri;

   OWLClass(IRI iri)
   {
      this.iri = iri;
   }

   @Override
   public String toString()
   {
      return "<" + iri + ">";
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OWLClass) && ((OWLClass) o).iri.equals(iri);
   }

   @Override
   public int hashCode()
   {
      return iri.hashCode();
   }

   @Override
   public int compareTo(OWLClass o)
   {
      return iri.compareTo(o.iri);
   }
}


interface OWLAxiom
{
   

   boolean isLogicalAxiom();
}

interface OWLSubClassOfAxiom extends OWLAxiom
{
   OWLClass getSubClass();

   OWLClass getSuperClass();
}

final class OWLSubClassOfAxiomImpl implements OWLSubClassOfAxiom, Comparable<OWLSubClassOfAxiomImpl>
{
   private final OWLClass subClass;
   private final OWLClass superClass;

   OWLSubClassOfAxiomImpl(OWLClass subClass, OWLClass superClass)
   {
      this.subClass = subClass;
      this.superClass = superClass;
   }

   public OWLClass getSubClass()
   {
      return subClass;
   }

   public OWLClass getSuperClass()
   {
      return superClass;
   }

   public boolean isLogicalAxiom()
   {
      return true;
   }

   @Override
   public String toString()
   {
      return "SubClassOf(" + subClass + " " + superClass + ")";
   }

   @Override
   public boolean equals(Object o)
   {
      if (!(o instanceof OWLSubClassOfAxiomImpl))
      {
         return false;
      }
      OWLSubClassOfAxiomImpl other = (OWLSubClassOfAxiomImpl) o;
      return other.subClass.equals(subClass) && other.superClass.equals(superClass);
   }

   @Override
   public int hashCode()
   {
      return subClass.hashCode() * 31 + superClass.hashCode();
   }

   @Override
   public int compareTo(OWLSubClassOfAxiomImpl o)
   {
      return toString().compareTo(o.toString());
   }
}

interface OWLDataFactory
{
   OWLClass getOWLClass(IRI iri);

   OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClass subClass, OWLClass superClass);
}

final class OWLDataFactoryImpl implements OWLDataFactory
{
   public OWLClass getOWLClass(IRI iri)
   {
      return new OWLClass(iri);
   }

   public OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClass subClass, OWLClass superClass)
   {
      return new OWLSubClassOfAxiomImpl(subClass, superClass);
   }
}


class OWLException extends Exception
{
   OWLException(String message)
   {
      super(message);
   }

   OWLException(Throwable cause)
   {
      super(cause);
   }
}


class OWLRuntimeException extends RuntimeException
{
   OWLRuntimeException(String message)
   {
      super(message);
   }
}


class Explanation<E>
{
   private final E entailment;
   private final Set<OWLAxiom> justification;

   Explanation(E entailment, Set<OWLAxiom> justification)
   {
      this.entailment = entailment;
      this.justification = Collections.unmodifiableSet(new HashSet<OWLAxiom>(justification));
   }

   public E getEntailment()
   {
      return entailment;
   }

   public Set<OWLAxiom> getAxioms()
   {
      return justification;
   }

   public int getSize()
   {
      return justification.size();
   }

   public boolean isEmpty()
   {
      return justification.isEmpty();
   }

   public boolean contains(OWLAxiom axiom)
   {
      return justification.contains(axiom);
   }

   public static <E> Explanation<E> getEmptyExplanation(E entailment)
   {
      return new Explanation<E>(entailment, Collections.<OWLAxiom>emptySet());
   }

   @Override
   public boolean equals(Object obj)
   {
      if (obj == this)
      {
         return true;
      }
      if (!(obj instanceof Explanation))
      {
         return false;
      }
      Explanation other = (Explanation) obj;
      return other.getEntailment().equals(entailment) && other.getAxioms().equals(justification);
   }

   @Override
   public int hashCode()
   {
      return (entailment != null ? entailment.hashCode() : 0) + justification.hashCode();
   }
}
