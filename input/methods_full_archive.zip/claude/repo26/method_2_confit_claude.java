

































import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class method_2_confit_claude {

  
  
  
  
  static class KeyValue {
    final byte[] row;
    final String column;
    final byte[] value;

    KeyValue(byte[] row, String column, byte[] value) {
      this.row = row;
      this.column = column;
      this.value = value;
    }
  }

  interface Row {
    byte[] getRow();
  }

  static class Get implements Row {
    private final byte[] row;

    Get(byte[] row) {
      this.row = row;
    }

    @Override
    public byte[] getRow() {
      return row;
    }
  }

  static class Result {
    private final KeyValue[] kvs;

    Result(KeyValue[] kvs) {
      this.kvs = kvs;
    }

    KeyValue[] raw() {
      return kvs;
    }
  }

  static class ByteArrayKey implements Comparable<ByteArrayKey> {
    final byte[] bytes;

    ByteArrayKey(byte[] bytes) {
      this.bytes = bytes;
    }

    @Override
    public int compareTo(ByteArrayKey o) {
      int len = Math.min(bytes.length, o.bytes.length);
      for (int i = 0; i < len; i++) {
        int cmp = (bytes[i] & 0xFF) - (o.bytes[i] & 0xFF);
        if (cmp != 0) {
          return cmp;
        }
      }
      return bytes.length - o.bytes.length;
    }

    @Override
    public boolean equals(Object o) {
      return o instanceof ByteArrayKey && java.util.Arrays.equals(bytes, ((ByteArrayKey) o).bytes);
    }

    @Override
    public int hashCode() {
      return java.util.Arrays.hashCode(bytes);
    }
  }

  interface Table {
    void batch(List<Row> actions, Object[] results) throws IOException, InterruptedException;

    void flushCommits() throws IOException;
  }

  
  
  
  static class InMemoryHTable implements Table {
    final TreeMap<ByteArrayKey, KeyValue[]> rows = new TreeMap<>();

    void put(byte[] rowKey, String column, byte[] value) {
      rows.put(new ByteArrayKey(rowKey), new KeyValue[] { new KeyValue(rowKey, column, value) });
    }

    @Override
    public void batch(List<Row> actions, Object[] results) throws IOException, InterruptedException {
      for (int i = 0; i < actions.size(); i++) {
        KeyValue[] kvs = rows.get(new ByteArrayKey(actions.get(i).getRow()));
        results[i] = new Result(kvs == null ? new KeyValue[0] : kvs);
      }
    }

    @Override
    public void flushCommits() {
      
      
    }
  }

  
  
  
  
  enum FetchType {
    ALL, LAZY
  }

  static class BeanId {
    final String schemaName;
    final String instanceId;

    BeanId(String schemaName, String instanceId) {
      this.schemaName = schemaName;
      this.instanceId = instanceId;
    }

    @Override
    public String toString() {
      return schemaName + "@" + instanceId;
    }

    @Override
    public boolean equals(Object o) {
      if (!(o instanceof BeanId)) {
        return false;
      }
      BeanId b = (BeanId) o;
      return schemaName.equals(b.schemaName) && instanceId.equals(b.instanceId);
    }

    @Override
    public int hashCode() {
      return schemaName.hashCode() * 31 + instanceId.hashCode();
    }
  }

  interface Uids {
    
    
  }

  static class HBeanRow {
    private final byte[] rowKey;
    private final BeanId beanId;
    private final Map<String, byte[]> columns = new HashMap<>();

    
    HBeanRow(byte[] rowKey, Uids uids) {
      this.rowKey = rowKey;
      this.beanId = decodeBeanId(rowKey);
    }

    
    HBeanRow(KeyValue[] kvs, Uids uids) {
      this.rowKey = kvs.length > 0 ? kvs[0].row : new byte[0];
      this.beanId = decodeBeanId(rowKey);
      for (KeyValue kv : kvs) {
        columns.put(kv.column, kv.value);
      }
    }

    
    
    
    private static BeanId decodeBeanId(byte[] rowKey) {
      String text = new String(rowKey, StandardCharsets.UTF_8);
      int idx = text.indexOf(':');
      if (idx < 0) {
        return new BeanId(text, "");
      }
      return new BeanId(text.substring(0, idx), text.substring(idx + 1));
    }

    BeanId getBeanId() {
      return beanId;
    }

    Object getValue(String column) {
      byte[] v = columns.get(column);
      return v == null ? null : new String(v, StandardCharsets.UTF_8);
    }

    byte[] getRowKey() {
      return rowKey;
    }

    static void setColumnFilter(Get get, FetchType... fetchType) {
      
      
      
      
    }

    @Override
    public String toString() {
      return "HBeanRow{beanId=" + beanId + ", columns=" + columns + "}";
    }

    @Override
    public boolean equals(Object o) {
      return o instanceof HBeanRow && beanId.equals(((HBeanRow) o).beanId);
    }

    @Override
    public int hashCode() {
      return beanId.hashCode();
    }
  }

  static class HBeanNotFoundException extends Exception {
    final Set<BeanId> notFound;
    final Set<HBeanRow> found;

    HBeanNotFoundException(Set<BeanId> notFound, Set<HBeanRow> found) {
      super("beans not found: " + notFound);
      this.notFound = notFound;
      this.found = found;
    }
  }

  
  
  
  Table table;
  Uids uids = new Uids() {
  };

  static byte[] rowKeyFor(String schemaName, String instanceId) {
    return (schemaName + ":" + instanceId).getBytes(StandardCharsets.UTF_8);
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public Set<HBeanRow> getLazy(Set<HBeanRow> rows, FetchType... fetchType)
            throws HBeanNotFoundException {
        final List<Row> gets = new ArrayList<>(rows.size());
        for (HBeanRow row : rows) {
            final Get get = new Get(row.getRowKey());
            HBeanRow.setColumnFilter(get, fetchType);
            gets.add(get);
        }
        Set<HBeanRow> result = new HashSet<>();
        Set<BeanId> notFound = new HashSet<>();
        try {
            final Result[] r = new Result[gets.size()];
            table.batch(gets, r);
            table.flushCommits();
            for (int i = 0; i < r.length; i++) {
                KeyValue[] kvs = r[i].raw();
                if (kvs.length == 0) {
                    notFound.add(new HBeanRow(gets.get(i).getRow(), uids).getBeanId());
                } else {
                    HBeanRow row = new HBeanRow(kvs, uids);
                    result.add(row);
                }
            }
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
        if (notFound.size() > 0) {
            throw new HBeanNotFoundException(notFound, result);
        }
        return result;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: HBeanTable.getLazy ===");

    InMemoryHTable htable = new InMemoryHTable();
    htable.put(rowKeyFor("server", "web1"), "cf:port", "8080".getBytes(StandardCharsets.UTF_8));
    htable.put(rowKeyFor("server", "web2"), "cf:port", "8081".getBytes(StandardCharsets.UTF_8));

    method_2_confit_claude beanTable = new method_2_confit_claude();
    beanTable.table = htable;

    
    Set<HBeanRow> requestA = new HashSet<>();
    requestA.add(new HBeanRow(rowKeyFor("server", "web1"), beanTable.uids));
    requestA.add(new HBeanRow(rowKeyFor("server", "web2"), beanTable.uids));

    Set<HBeanRow> resultA = beanTable.getLazy(requestA, FetchType.ALL);
    System.out.println("\n-- Scenario A (all rows exist) --");
    for (HBeanRow row : resultA) {
      System.out.println("  " + row);
    }

    
    Set<HBeanRow> requestB = new HashSet<>();
    requestB.add(new HBeanRow(rowKeyFor("server", "web1"), beanTable.uids));
    requestB.add(new HBeanRow(rowKeyFor("server", "missing"), beanTable.uids));

    System.out.println("\n-- Scenario B (one row missing) --");
    try {
      beanTable.getLazy(requestB, FetchType.ALL);
      System.out.println("  (unexpectedly did not throw)");
    } catch (HBeanNotFoundException e) {
      System.out.println("  caught expected HBeanNotFoundException: " + e.getMessage());
      System.out.println("  partial results found: " + e.found);
    }

    System.out.println("\n=== Demo complete: method exercised the all-found batch-get branch and "
        + "the partial-not-found branch (which still surfaces the successfully found rows "
        + "alongside the missing BeanIds via HBeanNotFoundException). ===");
  }
}
