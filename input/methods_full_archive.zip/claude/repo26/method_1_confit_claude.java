





































import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_1_confit_claude {

  
  
  
  
  static class ByteBuf {
    private final byte[] data;
    private int readerIndex = 0;

    ByteBuf(byte[] data) {
      this.data = data;
    }

    boolean isReadable() {
      return readerIndex < data.length;
    }

    byte readByteRaw() {
      return data[readerIndex++];
    }

    short readShortRaw() {
      short v = (short) (((data[readerIndex] & 0xFF) << 8) | (data[readerIndex + 1] & 0xFF));
      readerIndex += 2;
      return v;
    }

    int readIntRaw() {
      int v = ((data[readerIndex] & 0xFF) << 24) | ((data[readerIndex + 1] & 0xFF) << 16)
          | ((data[readerIndex + 2] & 0xFF) << 8) | (data[readerIndex + 3] & 0xFF);
      readerIndex += 4;
      return v;
    }

    long readLongRaw() {
      long v = 0;
      for (int i = 0; i < 8; i++) {
        v = (v << 8) | (data[readerIndex++] & 0xFFL);
      }
      return v;
    }

    byte[] readBytesRaw(int length) {
      byte[] b = new byte[length];
      System.arraycopy(data, readerIndex, b, 0, length);
      readerIndex += length;
      return b;
    }
  }

  
  
  
  
  
  
  static class ByteArrayReader {
    private final ByteBuf buf;

    ByteArrayReader(ByteBuf buf) {
      this.buf = buf;
    }

    boolean available() {
      return buf.isReadable();
    }

    int readByte() {
      return buf.readByteRaw();
    }

    int readShort() {
      return buf.readShortRaw();
    }

    int readInt() {
      return buf.readIntRaw();
    }

    long readLong() {
      return buf.readLongRaw();
    }

    float readFloat() {
      return Float.intBitsToFloat(buf.readIntRaw());
    }

    double readDouble() {
      return Double.longBitsToDouble(buf.readLongRaw());
    }

    boolean readBoolean() {
      return buf.readByteRaw() != 0;
    }

    String readString(int length) {
      return new String(buf.readBytesRaw(length), StandardCharsets.UTF_8);
    }
  }

  
  
  
  
  
  
  
  
  
  enum OpType {
    SCHEMA_ID, BYTE, SHORT, INTEGER, LONG, FLOAT, DOUBLE, STRING, BOOLEAN, OBJECT,
    BYTE_LIST, SHORT_LIST, INTEGER_LIST, LONG_LIST, FLOAT_LIST, DOUBLE_LIST, STRING_LIST,
    BOOLEAN_LIST, OBJECT_LIST,
    BYTE_SET, SHORT_SET, INTEGER_SET, LONG_SET, FLOAT_SET, DOUBLE_SET, STRING_SET, BOOLEAN_SET,
    OBJECT_SET,
    REFERENCE_HOLDER
  }

  static class UnsafeSetOp {
    private final OpType type;
    private final Field field;
    private final Class<?> objectClass;

    UnsafeSetOp(OpType type, Field field, Class<?> objectClass) {
      this.type = type;
      this.field = field;
      this.objectClass = objectClass;
      if (field != null) {
        field.setAccessible(true);
      }
    }

    OpType getType() {
      return type;
    }

    Class<?> getObjectClass() {
      return objectClass;
    }

    void set(Object target, Object value) {
      try {
        field.set(target, value);
      } catch (IllegalAccessException e) {
        throw new RuntimeException("unable to set field " + field, e);
      }
    }
  }

  static class UniqueId {
    private final Map<Integer, UnsafeSetOp> opsById = new HashMap<>();

    void register(int id, UnsafeSetOp op) {
      opsById.put(id, op);
    }

    UnsafeSetOp getUnsafeSetOp(int id) {
      return opsById.get(id);
    }
  }

  
  
  
  
  
  static class ConfigReferenceHolder {
    final Map<String, List<String>> references;

    ConfigReferenceHolder(Map<String, List<String>> references) {
      this.references = references;
    }

    @Override
    public String toString() {
      return "ConfigReferenceHolder" + references;
    }
  }

  interface Conversion {
    Object convert(String value, Class<?> targetClass);
  }

  static class SimpleConversion implements Conversion {
    @Override
    public Object convert(String value, Class<?> targetClass) {
      if (targetClass == java.math.BigDecimal.class) {
        return new java.math.BigDecimal(value);
      }
      return value;
    }
  }

  
  
  
  
  Conversion conversion = new SimpleConversion();

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  private void setProperties(Object object, UniqueId uniqueId, ByteBuf byteBuf) {
        ByteArrayReader reader = new ByteArrayReader(byteBuf);

        while(reader.available()) {
            int id = reader.readInt();
            UnsafeSetOp op = uniqueId.getUnsafeSetOp(id);
            Object value;
            int size;
            ArrayList<Object> list = new ArrayList<>();
            HashSet<Object> set = new HashSet<>();
            switch (op.getType()) {
                case SCHEMA_ID:
                    int length = reader.readInt();
                    value = reader.readString(length);
                    op.set(object, value);
                    break;
                case BYTE:
                    byte byteValue = (byte) reader.readByte();
                    op.set(object, byteValue);
                    break;
                case SHORT:
                    short shortVvalue = (short) reader.readShort();
                    op.set(object, shortVvalue);
                    break;
                case INTEGER:
                    int intValue = reader.readInt();
                    op.set(object, intValue);
                    break;
                case LONG:
                    long longValue = reader.readLong();
                    op.set(object, longValue);
                    break;
                case FLOAT:
                    float floatValue = reader.readFloat();
                    op.set(object, floatValue);
                    break;
                case DOUBLE:
                    double doubleValue = reader.readDouble();
                    op.set(object, doubleValue);
                    break;
                case STRING:
                    length = reader.readInt();
                    value = reader.readString(length);
                    op.set(object, value);
                    break;
                case BOOLEAN:
                    value = reader.readBoolean();
                    op.set(object, value);
                    break;
                case OBJECT:
                    length = reader.readInt();
                    value = conversion.convert(reader.readString(length), op.getObjectClass());
                    op.set(object, value);
                    break;
                case BYTE_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readByte());
                    }
                    op.set(object, list);
                    break;
                case SHORT_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readShort());
                    }
                    op.set(object, list);
                    break;
                case INTEGER_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readInt());
                    }
                    op.set(object, list);
                    break;
                case LONG_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readLong());
                    }
                    op.set(object, list);
                    break;
                case FLOAT_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readFloat());
                    }
                    op.set(object, list);
                    break;
                case DOUBLE_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readDouble());
                    }
                    op.set(object, list);
                    break;
                case STRING_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        length = reader.readInt();
                        list.add(reader.readString(length));
                    }
                    op.set(object, list);
                    break;
                case BOOLEAN_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readBoolean());
                    }
                    op.set(object, list);
                    break;
                case OBJECT_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        length = reader.readInt();
                        String stringValue = reader.readString(length);
                        value = conversion.convert(stringValue, op.getObjectClass());
                        list.add(value);
                    }
                    op.set(object, list);
                    break;
                case BYTE_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readByte());
                    }
                    op.set(object, set);
                    break;
                case SHORT_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readShort());
                    }
                    op.set(object, set);
                    break;
                case INTEGER_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readInt());
                    }
                    op.set(object, set);
                    break;
                case LONG_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readLong());
                    }
                    op.set(object, set);
                    break;
                case FLOAT_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readFloat());
                    }
                    op.set(object, set);
                    break;
                case DOUBLE_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readDouble());
                    }
                    op.set(object, set);
                    break;
                case STRING_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        length = reader.readInt();
                        set.add(reader.readString(length));
                    }
                    op.set(object, set);
                    break;
                case BOOLEAN_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readBoolean());
                    }
                    op.set(object, set);
                    break;
                case OBJECT_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        length = reader.readInt();
                        String stringValue = reader.readString(length);
                        value = conversion.convert(stringValue, op.getObjectClass());
                        set.add(value);
                    }
                    op.set(object, set);
                    break;
                case REFERENCE_HOLDER:
                    Map<String, List<String>> references = new HashMap<>();
                    ConfigReferenceHolder holder = new ConfigReferenceHolder(references);
                    int numProperties = reader.readInt();
                    for (int i = 0; i < numProperties; i++) {
                        length = reader.readInt();
                        String property = reader.readString(length);
                        int numInstances = reader.readInt();
                        ArrayList<String> instances = new ArrayList<>();
                        for (int j = 0; j < numInstances; j++) {
                            length = reader.readInt();
                            instances.add(reader.readString(length));
                        }
                        references.put(property, instances);
                    }
                    op.set(object, holder);
                    break;
            }
        }
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  static class Person {
    String schemaId;
    byte age;
    int score;
    String name;
    boolean active;
    List<Integer> luckyNumbers;
    Set<String> tags;

    @Override
    public String toString() {
      return "Person{schemaId=" + schemaId + ", age=" + age + ", score=" + score + ", name=" + name + ", active="
          + active + ", luckyNumbers=" + luckyNumbers + ", tags=" + tags + "}";
    }
  }

  
  
  private static ByteBuf buildDemoBuffer() throws Exception {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    DataOutputStream out = new DataOutputStream(bos);

    
    writeStringProperty(out, 0, "person-v1");
    
    out.writeInt(1);
    out.writeByte(30);
    
    out.writeInt(2);
    out.writeInt(88);
    
    writeStringProperty(out, 3, "Alice");
    
    out.writeInt(4);
    out.writeByte(1);
    
    out.writeInt(5);
    out.writeInt(3);
    out.writeInt(10);
    out.writeInt(20);
    out.writeInt(30);
    
    out.writeInt(6);
    out.writeInt(2);
    writeLengthPrefixedString(out, "vip");
    writeLengthPrefixedString(out, "new");

    return new ByteBuf(bos.toByteArray());
  }

  private static void writeStringProperty(DataOutputStream out, int id, String value) throws Exception {
    out.writeInt(id);
    writeLengthPrefixedString(out, value);
  }

  private static void writeLengthPrefixedString(DataOutputStream out, String value) throws Exception {
    byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
    out.writeInt(bytes.length);
    out.write(bytes);
  }

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: DefaultCacheValueSerializer.setProperties ===");

    UniqueId uniqueId = new UniqueId();
    uniqueId.register(0, new UnsafeSetOp(OpType.SCHEMA_ID, Person.class.getDeclaredField("schemaId"), String.class));
    uniqueId.register(1, new UnsafeSetOp(OpType.BYTE, Person.class.getDeclaredField("age"), byte.class));
    uniqueId.register(2, new UnsafeSetOp(OpType.INTEGER, Person.class.getDeclaredField("score"), int.class));
    uniqueId.register(3, new UnsafeSetOp(OpType.STRING, Person.class.getDeclaredField("name"), String.class));
    uniqueId.register(4, new UnsafeSetOp(OpType.BOOLEAN, Person.class.getDeclaredField("active"), boolean.class));
    uniqueId.register(5,
        new UnsafeSetOp(OpType.INTEGER_LIST, Person.class.getDeclaredField("luckyNumbers"), Integer.class));
    uniqueId.register(6, new UnsafeSetOp(OpType.STRING_SET, Person.class.getDeclaredField("tags"), String.class));

    ByteBuf buf = buildDemoBuffer();
    Person person = new Person();

    method_1_confit_claude serializer = new method_1_confit_claude();
    serializer.setProperties(person, uniqueId, buf);

    System.out.println("\n-- Decoded object --");
    System.out.println("  " + person);

    System.out.println("\n=== Demo complete: method exercised the SCHEMA_ID, BYTE, INTEGER, STRING, "
        + "BOOLEAN, INTEGER_LIST, and STRING_SET branches of the wire-format switch, each writing "
        + "into the target bean via reflective UnsafeSetOp.set(...). ===");
  }
}
