

































import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

public class method_4_confit_claude {

  
  
  
  
  
  static class KeyValue {
    final byte[] row;
    final String column;
    final byte[] value;

    KeyValue(byte[] row, String column, byte[] value) {
      this.row = row;
      this.column = column;
      this.value = value;
    }
  }

  static class Result {
    private final KeyValue[] kvs;

    Result(KeyValue[] kvs) {
      this.kvs = kvs;
    }

    KeyValue[] raw() {
      return kvs;
    }
  }

  interface Filter {
    boolean accept(byte[] rowKey);
  }

  static class FilterList implements Filter {
    private final List<Filter> filters = new ArrayList<>();

    void addFilter(Filter filter) {
      filters.add(filter);
    }

    @Override
    public boolean accept(byte[] rowKey) {
      for (Filter f : filters) {
        if (!f.accept(rowKey)) {
          return false;
        }
      }
      return true;
    }
  }

  static class PrefixFilter implements Filter {
    private final byte[] prefix;

    PrefixFilter(byte[] prefix) {
      this.prefix = prefix;
    }

    @Override
    public boolean accept(byte[] rowKey) {
      if (rowKey.length < prefix.length) {
        return false;
      }
      for (int i = 0; i < prefix.length; i++) {
        if (rowKey[i] != prefix[i]) {
          return false;
        }
      }
      return true;
    }
  }

  static class Scan {
    Filter filter;

    void setFilter(Filter filter) {
      this.filter = filter;
    }

    Filter getFilter() {
      return filter;
    }
  }

  interface ResultScanner extends Iterable<Result> {
    void close();
  }

  interface Table {
    ResultScanner getScanner(Scan scan) throws IOException;
  }

  static class ByteArrayKey implements Comparable<ByteArrayKey> {
    final byte[] bytes;

    ByteArrayKey(byte[] bytes) {
      this.bytes = bytes;
    }

    @Override
    public int compareTo(ByteArrayKey o) {
      int len = Math.min(bytes.length, o.bytes.length);
      for (int i = 0; i < len; i++) {
        int cmp = (bytes[i] & 0xFF) - (o.bytes[i] & 0xFF);
        if (cmp != 0) {
          return cmp;
        }
      }
      return bytes.length - o.bytes.length;
    }
  }

  
  
  
  static class InMemoryHTable implements Table {
    final TreeMap<ByteArrayKey, KeyValue[]> rows = new TreeMap<>();

    void put(byte[] rowKey, String column, byte[] value) {
      rows.put(new ByteArrayKey(rowKey), new KeyValue[] { new KeyValue(rowKey, column, value) });
    }

    @Override
    public ResultScanner getScanner(Scan scan) {
      ArrayList<Result> results = new ArrayList<>();
      for (java.util.Map.Entry<ByteArrayKey, KeyValue[]> entry : rows.entrySet()) {
        if (scan.filter == null || scan.filter.accept(entry.getKey().bytes)) {
          results.add(new Result(entry.getValue()));
        }
      }
      return new ResultScanner() {
        @Override
        public void close() {
        }

        @Override
        public Iterator<Result> iterator() {
          return results.iterator();
        }
      };
    }
  }

  
  
  
  
  enum FetchType {
    ALL, LAZY
  }

  static class HBeanRow {
    final byte[] rowKey;
    final String rowText;

    HBeanRow(KeyValue[] kvs, Object uids) {
      this.rowKey = kvs.length > 0 ? kvs[0].row : new byte[0];
      this.rowText = kvs.length > 0 ? new String(kvs[0].value, StandardCharsets.UTF_8) : "";
    }

    static void setColumnFilter(Scan scan, FetchType... fetchType) {
      
      
      
      
    }

    @Override
    public String toString() {
      return "HBeanRow{rowKey=" + new String(rowKey, StandardCharsets.UTF_8) + ", value=" + rowText + "}";
    }
  }

  
  
  
  
  Table table;
  Object uids;

  
  
  
  
  byte[] extractSidPrefix(String schemaName) {
    return (schemaName + ":").getBytes(StandardCharsets.UTF_8);
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public Set<HBeanRow> listLazy(String schemaName, FetchType... fetchType) {
        byte[] sid = extractSidPrefix(schemaName);
        Scan scan = new Scan();
        HBeanRow.setColumnFilter(scan, fetchType);
        FilterList list = new FilterList();
        if (scan.getFilter() != null) {
            list.addFilter(scan.getFilter());

        }
        list.addFilter(new PrefixFilter(sid));
        scan.setFilter(list);

        Set<HBeanRow> rows = new HashSet<>();
        ResultScanner scanner = null;
        try {
            scanner = table.getScanner(scan);
            for (Result r : scanner) {
                HBeanRow row = new HBeanRow(r.raw(), uids);
                rows.add(row);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }
        return rows;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: HBeanTable.listLazy ===");

    method_4_confit_claude beanTable = new method_4_confit_claude();
    InMemoryHTable htable = new InMemoryHTable();
    beanTable.table = htable;

    
    
    htable.put("server:web1".getBytes(StandardCharsets.UTF_8), "cf:name", "web1".getBytes(StandardCharsets.UTF_8));
    htable.put("server:web2".getBytes(StandardCharsets.UTF_8), "cf:name", "web2".getBytes(StandardCharsets.UTF_8));
    htable.put("database:db1".getBytes(StandardCharsets.UTF_8), "cf:name", "db1".getBytes(StandardCharsets.UTF_8));

    Set<HBeanRow> resultServer = beanTable.listLazy("server", FetchType.ALL);
    System.out.println("\n-- Scenario A (listLazy(\"server\")) --");
    for (HBeanRow row : resultServer) {
      System.out.println("  " + row);
    }
    System.out.println("  count: " + resultServer.size() + " (expected 2, database:db1 excluded)");

    Set<HBeanRow> resultDatabase = beanTable.listLazy("database", FetchType.ALL);
    System.out.println("\n-- Scenario B (listLazy(\"database\")) --");
    for (HBeanRow row : resultDatabase) {
      System.out.println("  " + row);
    }
    System.out.println("  count: " + resultDatabase.size() + " (expected 1)");

    Set<HBeanRow> resultEmpty = beanTable.listLazy("nonexistent", FetchType.ALL);
    System.out.println("\n-- Scenario C (listLazy(\"nonexistent\")) --");
    System.out.println("  count: " + resultEmpty.size() + " (expected 0)");

    System.out.println("\n=== Demo complete: method exercised the FilterList composition (schema-id "
        + "PrefixFilter applied via the underlying table scan), correctly isolating rows per "
        + "schema, including the zero-match case. ===");
  }
}
