






























































import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_3_fuchsia_claude {

    private static final int MULTI_CHANNEL_CAPABILITY_REPORT = 0x0a;

    public static void main(String[] args) {
        title("METHOD 3  |  ZWaveMultiInstanceCommandClass.handleMultiChannelCapabilityReportResponse(SerialMessage, int)");

        section("1. endpoints share a device class - every endpoint is configured at once");
        Fixture f1 = new Fixture(2, true, true);
        f1.deliver(1, false, ZWaveDeviceClass.Generic.BINARY_SWITCH.getKey(), 0x01,
                new int[] { 0x25, 0x80 });
        f1.report();
        System.out.println("      both endpoints were configured from one report, because");
        System.out.println("      endpointsAreTheSameDeviceClass is true (startId=1, endId=" + 2 + ")");

        section("2. endpoints differ - only the reported endpoint is configured");
        Fixture f2 = new Fixture(3, false, true);
        f2.deliver(2, false, ZWaveDeviceClass.Generic.MULTILEVEL_SENSOR.getKey(), 0x01,
                new int[] { 0x31 });
        f2.report();
        System.out.println("      endpoints 1 and 3 are still NOT_KNOWN, so the method returned early");
        System.out.println("      instead of advancing the node stage");

        section("3. the remaining endpoints report too - now the node stage is advanced");
        f2.deliver(1, false, ZWaveDeviceClass.Generic.BINARY_SENSOR.getKey(), 0x01, new int[] { 0x30 });
        f2.deliver(3, false, ZWaveDeviceClass.Generic.METER.getKey(), 0x01, new int[] { 0x32 });
        f2.report();
        System.out.println("      every endpoint now has a known basic device class, so the loop over");
        System.out.println("      this.endpoints.values() completed and advanceNodeStage() was called");

        section("4. the dynamic flag - bit 7 of the first payload byte");
        Fixture f4 = new Fixture(1, true, true);
        f4.deliver(1, true, ZWaveDeviceClass.Generic.BINARY_SWITCH.getKey(), 0x01, new int[] { 0x25 });
        System.out.println("      the endpoint id was masked with 0x7F and the dynamic bit was reported");
        System.out.println("      in the debug line above");

        section("5. the node does not support BASIC - no ZWaveBasicCommandClass is added");
        Fixture f5 = new Fixture(1, true, false);
        f5.deliver(1, false, ZWaveDeviceClass.Generic.BINARY_SWITCH.getKey(), 0x01, new int[] { 0x25 });
        f5.report();
        System.out.println("      compare with scenario 1, where the parent node supported BASIC and the");
        System.out.println("      target method therefore added a BASIC command class to every endpoint");

        section("6. an invalid generic device class - a latent repository bug is reached");
        Fixture f6 = new Fixture(1, true, true);
        try {
            f6.deliver(1, false, 0xEE, 0x01, new int[] { 0x25 });
            System.out.println("      !! the expected exception was not thrown");
        } catch (final java.util.IllegalFormatConversionException e) {
            System.out.println("      IllegalFormatConversionException: " + e.getMessage());
        }
        System.out.println();
        System.out.println("      This is NOT a reconstruction defect - it is a genuine latent bug in the");
        System.out.println("      repository revision. Generic.getGeneric(0xEE) correctly returns null, and");
        System.out.println("      the method then builds its error message with");
        System.out.println("          String.format(\"Endpoint %d has invalid device class. ...\", endpoint, ...)");
        System.out.println("      but `endpoint` is a ZWaveEndpoint, not a number, so %d raises");
        System.out.println("      IllegalFormatConversionException before the continue statement is reached.");
        System.out.println("      The line is inside the markers and was left exactly as the repository has it.");
        System.out.println("      A real device only sends device classes the controller advertises, which is");
        System.out.println("      why the bug was never hit in production.");

        section("7. an invalid specific device class - the same latent bug on the second guard");
        Fixture f7 = new Fixture(1, true, true);
        try {
            f7.deliver(1, false, ZWaveDeviceClass.Generic.BINARY_SWITCH.getKey(), 0x7E, new int[] { 0x25 });
            System.out.println("      !! the expected exception was not thrown");
        } catch (final java.util.IllegalFormatConversionException e) {
            System.out.println("      IllegalFormatConversionException: " + e.getMessage());
        }
        System.out.println("      Specific.getSpecific(BINARY_SWITCH, 0x7E) returned null, so the second");
        System.out.println("      guard was entered - and it formats its message the same faulty way.");

        section("8. an endpoint id that is not in the map - the 'endpoint == null' branch");
        Fixture f8 = new Fixture(1, false, true);
        f8.deliver(9, false, ZWaveDeviceClass.Generic.BINARY_SWITCH.getKey(), 0x01, new int[] { 0x25 });
        System.out.println("      the error line above came from the target method; note that it prints the");
        System.out.println("      null endpoint itself, which is the repository's own behaviour");

        section("9. the 0xEF control marker stops the command class scan");
        Fixture f9 = new Fixture(1, true, true);
        f9.deliver(1, false, ZWaveDeviceClass.Generic.BINARY_SWITCH.getKey(), 0x01,
                new int[] { 0x25, 0xEF, 0x80 });
        f9.report();
        System.out.println("      SWITCH_BINARY was added, then 0xEF broke the loop, so BATTERY after it");
        System.out.println("      was never reached");

        section("10. an unsupported command class code - getInstance returns null and it is skipped");
        Fixture f10 = new Fixture(1, true, true);
        f10.deliver(1, false, ZWaveDeviceClass.Generic.BINARY_SWITCH.getKey(), 0x01,
                new int[] { 0x25, 0x21, 0x80 });
        f10.report();
        System.out.println("      0x21 is CONTROLLER_REPLICATION, which has no implementation class, so");
        System.out.println("      ZWaveCommandClass.getInstance returned null and the continue branch ran");

        section("11. version information is copied from the parent node's command class");
        Fixture f11 = new Fixture(1, true, true);
        ZWaveVersionCommandClass parentVersion = new ZWaveVersionCommandClass(f11.node, f11.controller, null);
        parentVersion.setVersion(2);
        f11.node.addCommandClass(parentVersion);
        f11.deliver(1, false, ZWaveDeviceClass.Generic.BINARY_SWITCH.getKey(), 0x01,
                new int[] { 0x25, 0x86 });
        ZWaveEndpoint ep11 = f11.multiInstance.getEndpoint(1);
        ZWaveCommandClass copied = ep11.getCommandClass(ZWaveCommandClass.CommandClass.VERSION);
        System.out.println("      parent VERSION class version   : " + parentVersion.getVersion());
        System.out.println("      endpoint VERSION class version : " + (copied == null ? "n/a"
                : String.valueOf(copied.getVersion())) + "   (copied by the target method)");
        ZWaveCommandClass notCopied = ep11.getCommandClass(ZWaveCommandClass.CommandClass.SWITCH_BINARY);
        System.out.println("      SWITCH_BINARY is not on the parent node, so its version stayed "
                + (notCopied == null ? "n/a" : String.valueOf(notCopied.getVersion())));

        section("12. branch coverage summary");
        System.out.println("      endpointsAreTheSameDeviceClass true / false     -> scenarios 1, 2");
        System.out.println("      every endpoint known -> advanceNodeStage()      -> scenarios 1, 3");
        System.out.println("      an endpoint still NOT_KNOWN -> early return     -> scenario 2");
        System.out.println("      the dynamic bit of the first payload byte       -> scenario 4");
        System.out.println("      supportsCommandClass(BASIC) true / false        -> scenarios 1, 5");
        System.out.println("      Generic.getGeneric(...) == null                 -> scenario 6 (latent bug)");
        System.out.println("      Specific.getSpecific(...) == null               -> scenario 7 (latent bug)");
        System.out.println("      endpoint == null                                -> scenario 8");
        System.out.println("      the 0xEF control command class marker           -> scenario 9");
        System.out.println("      getInstance(...) == null                        -> scenario 10");
        System.out.println("      parentClass != null -> setVersion(...)          -> scenario 11");
        System.out.println("      parentClass == null                             -> scenario 11");

        title("END OF METHOD 3 SCENARIOS");
    }

    
    static final class Fixture {

        final ZWaveController controller = new ZWaveController(1);
        final ZWaveNode node;
        final ZWaveMultiInstanceCommandClass multiInstance;

        Fixture(int endpointCount, boolean sameDeviceClass, boolean supportsBasic) {
            node = new ZWaveNode(0xAABBCC, 21, controller);
            node.getDeviceClass().setBasicDeviceClass(ZWaveDeviceClass.Basic.ROUTING_SLAVE);
            node.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_INSTANCES);
            multiInstance = new ZWaveMultiInstanceCommandClass(node, controller, null);
            multiInstance.setVersion(2);
            multiInstance.seedEndpoints(endpointCount, sameDeviceClass);
            node.addCommandClass(multiInstance);
            if (supportsBasic) {
                node.addCommandClass(new ZWaveBasicCommandClass(node, controller, null));
            }
        }

        




        void deliver(int endpointId, boolean dynamic, int generic, int specific, int[] commandClasses) {
            final byte[] payload = new byte[4 + commandClasses.length];
            payload[0] = (byte) MULTI_CHANNEL_CAPABILITY_REPORT;
            payload[1] = (byte) (endpointId | (dynamic ? 0x80 : 0x00));
            payload[2] = (byte) generic;
            payload[3] = (byte) specific;
            for (int i = 0; i < commandClasses.length; i++) {
                payload[4 + i] = (byte) commandClasses[i];
            }
            final SerialMessage message = new SerialMessage(node.getNodeId(),
                    SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                    SerialMessage.SerialMessageType.Request,
                    SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                    SerialMessage.SerialMessagePriority.Low);
            message.setMessagePayload(payload);
            multiInstance.handleApplicationCommandRequest(message, 0, 0);
        }

        void report() {
            System.out.println("      node stage after the report : " + node.getNodeStage());
            for (ZWaveEndpoint endpoint : multiInstance.getEndpoints()) {
                final StringBuilder classes = new StringBuilder();
                for (ZWaveCommandClass cc : endpoint.getCommandClasses()) {
                    classes.append(classes.length() == 0 ? "" : ", ").append(cc.getCommandClass().getLabel());
                }
                System.out.println("        endpoint " + endpoint.getEndpointId() + " : "
                        + endpoint.getDeviceClass() + "  commandClasses=[" + classes + "]");
            }
            controller.drainTransactions();
        }
    }

    static void title(String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}









interface Logger {

    void trace(String format, Object... arguments);

    void debug(String format, Object... arguments);

    void info(String format, Object... arguments);

    void warn(String format, Object... arguments);

    void error(String format, Object... arguments);
}

final class LoggerFactory {

    private LoggerFactory() {
    }

    static Logger getLogger(final Class<?> clazz) {
        final String name = clazz.getSimpleName();
        return new Logger() {
            private void print(final String level, final String format, final Object[] args) {
                System.out.println("      [" + level + "] " + name + " - " + expand(format, args));
            }

            private String expand(final String format, final Object[] args) {
                if (format == null || args == null || args.length == 0) {
                    return String.valueOf(format);
                }
                final StringBuilder sb = new StringBuilder();
                int from = 0;
                int arg = 0;
                while (arg < args.length) {
                    final int at = format.indexOf("{}", from);
                    if (at < 0) {
                        break;
                    }
                    sb.append(format, from, at).append(args[arg++]);
                    from = at + 2;
                }
                return sb.append(format.substring(from)).toString();
            }

            public void trace(String format, Object... arguments) {
                print("TRACE", format, arguments);
            }

            public void debug(String format, Object... arguments) {
                print("DEBUG", format, arguments);
            }

            public void info(String format, Object... arguments) {
                print("INFO ", format, arguments);
            }

            public void warn(String format, Object... arguments) {
                print("WARN ", format, arguments);
            }

            public void error(String format, Object... arguments) {
                print("ERROR", format, arguments);
            }
        };
    }
}





class SerialInterfaceException extends Exception {

    private static final long serialVersionUID = 1L;

    public SerialInterfaceException() {
        super();
    }

    public SerialInterfaceException(String message) {
        super(message);
    }

    public SerialInterfaceException(String message, Throwable cause) {
        super(message, cause);
    }

    public SerialInterfaceException(Throwable cause) {
        super(cause);
    }
}








class SerialMessage {

    private static final Logger logger = LoggerFactory.getLogger(SerialMessage.class);

    private byte[] messagePayload = new byte[0];
    private int messageNode = 255;
    private SerialMessageType messageType;
    private SerialMessageClass messageClass;
    private SerialMessageClass expectedReply;
    private SerialMessagePriority priority;
    private int callbackId;
    private boolean transmitted;

    public SerialMessage() {
    }

    public SerialMessage(SerialMessageClass messageClass, SerialMessageType messageType,
            SerialMessageClass expectedReply, SerialMessagePriority priority) {
        this(255, messageClass, messageType, expectedReply, priority);
    }

    public SerialMessage(int nodeId, SerialMessageClass messageClass, SerialMessageType messageType,
            SerialMessageClass expectedReply, SerialMessagePriority priority) {
        this.messageNode = nodeId;
        this.messageClass = messageClass;
        this.messageType = messageType;
        this.expectedReply = expectedReply;
        this.priority = priority;
    }

    public byte[] getMessagePayload() {
        return messagePayload;
    }

    public void setMessagePayload(byte[] messagePayload) {
        this.messagePayload = messagePayload;
    }

    
    public int getMessagePayloadByte(int index) {
        if (index >= this.messagePayload.length) {
            throw new ArrayIndexOutOfBoundsException("Attempt to read message payload byte " + index
                    + " but the payload is only " + this.messagePayload.length + " bytes long");
        }
        return this.messagePayload[index] & 0xFF;
    }

    public int getMessageNode() {
        return messageNode;
    }

    public SerialMessageType getMessageType() {
        return messageType;
    }

    public SerialMessageClass getMessageClass() {
        return messageClass;
    }

    public SerialMessageClass getExpectedReply() {
        return expectedReply;
    }

    public SerialMessagePriority getPriority() {
        return priority;
    }

    public int getCallbackId() {
        return callbackId;
    }

    public void setCallbackId(int callbackId) {
        this.callbackId = callbackId;
    }

    public boolean isTransmitted() {
        return transmitted;
    }

    public void setTransmitted(boolean transmitted) {
        this.transmitted = transmitted;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        for (byte b : messagePayload) {
            sb.append(String.format("%02X ", b & 0xFF));
        }
        return String.format("%s[node=%d, class=%s, type=%s, priority=%s, payload=%s]",
                getClass().getSimpleName(), messageNode, messageClass, messageType, priority, sb.toString().trim());
    }

    public enum SerialMessageType {
        Request,
        Response
    }

    public enum SerialMessagePriority {
        High,
        Get,
        Low
    }

    public enum SerialMessageClass {
        SerialApiGetInitData(0x02, "SerialApiGetInitData"),
        SerialApiApplicationNodeInfo(0x03, "SerialApiApplicationNodeInfo"),
        ApplicationCommandHandler(0x04, "ApplicationCommandHandler"),
        GetControllerCapabilities(0x05, "GetControllerCapabilities"),
        SerialApiSetTimeouts(0x06, "SerialApiSetTimeouts"),
        SerialApiGetCapabilities(0x07, "SerialApiGetCapabilities"),
        SendData(0x13, "SendData"),
        GetVersion(0x15, "GetVersion"),
        MemoryGetId(0x20, "MemoryGetId"),
        IdentifyNode(0x41, "IdentifyNode"),
        RequestNodeInfo(0x60, "RequestNodeInfo"),
        GetRoutingInfo(0x80, "GetRoutingInfo"),
        ApplicationUpdate(0x49, "ApplicationUpdate"),
        AddNodeToNetwork(0x4A, "AddNodeToNetwork");

        private int key;
        private String label;

        private SerialMessageClass(int key, String label) {
            this.key = key;
            this.label = label;
        }

        public int getKey() {
            return key;
        }

        public String getLabel() {
            return label;
        }
    }
}






class ZWaveEvent {

    private final int nodeId;
    private final int endpoint;
    private final String description;

    public ZWaveEvent(int nodeId, int endpoint, String description) {
        this.nodeId = nodeId;
        this.endpoint = endpoint;
        this.description = description;
    }

    public int getNodeId() {
        return nodeId;
    }

    public int getEndpoint() {
        return endpoint;
    }

    @Override
    public String toString() {
        return "ZWaveEvent[node=" + nodeId + ", endpoint=" + endpoint + ", " + description + "]";
    }
}

interface ZWaveEventListener {

    void ZWaveIncomingEvent(ZWaveEvent event);
}







class ZWaveDeviceClass {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveDeviceClass.class);

    private Basic basicDeviceClass;
    private Generic genericDeviceClass;
    private Specific specificDeviceClass;

    public ZWaveDeviceClass(Basic basicDeviceClass, Generic genericDeviceClass, Specific specificDeviceClass) {
        this.basicDeviceClass = basicDeviceClass;
        this.genericDeviceClass = genericDeviceClass;
        this.specificDeviceClass = specificDeviceClass;
    }

    public Basic getBasicDeviceClass() {
        return basicDeviceClass;
    }

    public void setBasicDeviceClass(Basic basicDeviceClass) {
        this.basicDeviceClass = basicDeviceClass;
    }

    public Generic getGenericDeviceClass() {
        return genericDeviceClass;
    }

    public void setGenericDeviceClass(Generic genericDeviceClass) {
        this.genericDeviceClass = genericDeviceClass;
    }

    public Specific getSpecificDeviceClass() {
        return specificDeviceClass;
    }

    public void setSpecificDeviceClass(Specific specificDeviceClass) {
        this.specificDeviceClass = specificDeviceClass;
    }

    @Override
    public String toString() {
        return "DeviceClass[basic=" + basicDeviceClass + ", generic=" + genericDeviceClass
                + ", specific=" + specificDeviceClass + "]";
    }

    public enum Basic {
        NOT_KNOWN(0, "Not Known"),
        CONTROLLER(0x01, "Controller"),
        STATIC_CONTROLLER(0x02, "Static Controller"),
        SLAVE(0x03, "Slave"),
        ROUTING_SLAVE(0x04, "Routing Slave");

        private static Map<Integer, Basic> codeToBasicMapping;

        private int key;
        private String label;

        private Basic(int key, String label) {
            this.key = key;
            this.label = label;
        }

        private static void initMapping() {
            codeToBasicMapping = new HashMap<Integer, Basic>();
            for (Basic s : values()) {
                codeToBasicMapping.put(s.key, s);
            }
        }

        public static Basic getBasic(int i) {
            if (codeToBasicMapping == null) {
                initMapping();
            }
            return codeToBasicMapping.get(i);
        }

        public int getKey() {
            return key;
        }

        public String getLabel() {
            return label;
        }
    }

    public enum Generic {
        NOT_KNOWN(0, "Not Known"),
        REMOTE_CONTROLLER(0x01, "Remote Controller"),
        STATIC_CONTROLLER(0x02, "Static Controller"),
        AV_CONTROL_POINT(0x03, "A/V Control Point"),
        DISPLAY(0x06, "Display"),
        GARAGE_DOOR(0x07, "Garage Door"),
        THERMOSTAT(0x08, "Thermostat"),
        WINDOW_COVERING(0x09, "Window Covering"),
        REPEATER_SLAVE(0x0F, "Repeater Slave"),
        BINARY_SWITCH(0x10, "Binary Switch"),
        MULTILEVEL_SWITCH(0x11, "Multi-Level Switch"),
        REMOTE_SWITCH(0x12, "Remote Switch"),
        TOGGLE_SWITCH(0x13, "Toggle Switch"),
        Z_IP_GATEWAY(0x14, "Z/IP Gateway"),
        Z_IP_NODE(0x15, "Z/IP Node"),
        VENTILATION(0x16, "Ventilation"),
        BINARY_SENSOR(0x20, "Binary Sensor"),
        MULTILEVEL_SENSOR(0x21, "Multi-Level Sensor"),
        PULSE_METER(0x30, "Pulse Meter"),
        METER(0x31, "Meter"),
        ENTRY_CONTROL(0x40, "Entry Control"),
        SEMI_INTEROPERABLE(0x50, "Semi Interoperable"),
        ALARM_SENSOR(0xa1, "Alarm Sensor"),
        NON_INTEROPERABLE(0xFF, "Non Interoperable");

        private static Map<Integer, Generic> codeToGenericMapping;

        private int key;
        private String label;

        private Generic(int key, String label) {
            this.key = key;
            this.label = label;
        }

        private static void initMapping() {
            codeToGenericMapping = new HashMap<Integer, Generic>();
            for (Generic s : values()) {
                codeToGenericMapping.put(s.key, s);
            }
        }

        public static Generic getGeneric(int i) {
            if (codeToGenericMapping == null) {
                initMapping();
            }
            return codeToGenericMapping.get(i);
        }

        public int getKey() {
            return key;
        }

        public String getLabel() {
            return label;
        }
    }

    public enum Specific {
        NOT_USED(0, Generic.NOT_KNOWN, "Not Known"),
        PORTABLE_REMOTE_CONTROLLER(0x01, Generic.REMOTE_CONTROLLER, "Portable Remote Controller"),
        PORTABLE_SCENE_CONTROLLER(0x02, Generic.REMOTE_CONTROLLER, "Portable Scene Controller"),
        PC_CONTROLLER(0x01, Generic.STATIC_CONTROLLER, "PC Controller"),
        SCENE_CONTROLLER(0x02, Generic.STATIC_CONTROLLER, "Scene Controller"),
        POWER_SWITCH_BINARY(0x01, Generic.BINARY_SWITCH, "Binary Power Switch"),
        SCENE_SWITCH_BINARY(0x03, Generic.BINARY_SWITCH, "Binary Scene Switch"),
        POWER_SWITCH_MULTILEVEL(0x01, Generic.MULTILEVEL_SWITCH, "Multilevel Power Switch"),
        SCENE_SWITCH_MULTILEVEL(0x04, Generic.MULTILEVEL_SWITCH, "Multilevel Scene Switch"),
        MOTOR_MULTIPOSITION(0x03, Generic.MULTILEVEL_SWITCH, "Multiposition Motor"),
        ROUTING_SENSOR_BINARY(0x01, Generic.BINARY_SENSOR, "Routing Binary Sensor"),
        ROUTING_SENSOR_MULTILEVEL(0x01, Generic.MULTILEVEL_SENSOR, "Routing Multilevel Sensor"),
        SIMPLE_METER(0x01, Generic.METER, "Simple Meter"),
        DOOR_LOCK(0x01, Generic.ENTRY_CONTROL, "Door Lock"),
        ADV_ZENSOR_NET_ALARM_SENSOR(0x05, Generic.ALARM_SENSOR, "Advanced Zensor Net Alarm Sensor"),
        BASIC_ROUTING_ALARM_SENSOR(0x01, Generic.ALARM_SENSOR, "Basic Routing Alarm Sensor");

        private static Map<Generic, Map<Integer, Specific>> codeToSpecificMapping;

        private int key;
        private Generic genericDeviceClass;
        private String label;

        private Specific(int key, Generic genericDeviceClass, String label) {
            this.key = key;
            this.genericDeviceClass = genericDeviceClass;
            this.label = label;
        }

        private static void initMapping() {
            codeToSpecificMapping = new HashMap<Generic, Map<Integer, Specific>>();
            for (Specific s : values()) {
                if (!codeToSpecificMapping.containsKey(s.genericDeviceClass)) {
                    codeToSpecificMapping.put(s.genericDeviceClass, new HashMap<Integer, Specific>());
                }
                codeToSpecificMapping.get(s.genericDeviceClass).put(s.key, s);
            }
        }

        public static Specific getSpecific(Generic genericDeviceClass, int i) {
            if (codeToSpecificMapping == null) {
                initMapping();
            }
            
            if (i == 0) {
                return NOT_USED;
            }
            Map<Integer, Specific> map = codeToSpecificMapping.get(genericDeviceClass);
            if (map == null) {
                return null;
            }
            return map.get(i);
        }

        public int getKey() {
            return key;
        }

        public String getLabel() {
            return label;
        }

        public Generic getGenericDeviceClass() {
            return genericDeviceClass;
        }
    }
}





class ZWaveEndpoint {

    private final ZWaveDeviceClass deviceClass;
    private final int endpointId;

    private Map<ZWaveCommandClass.CommandClass, ZWaveCommandClass> supportedCommandClasses =
            new HashMap<ZWaveCommandClass.CommandClass, ZWaveCommandClass>();

    public ZWaveEndpoint(ZWaveDeviceClass deviceClass, int endpointId) {
        this.deviceClass = deviceClass;
        this.endpointId = endpointId;
    }

    public ZWaveDeviceClass getDeviceClass() {
        return deviceClass;
    }

    public int getEndpointId() {
        return endpointId;
    }

    public Collection<ZWaveCommandClass> getCommandClasses() {
        return supportedCommandClasses.values();
    }

    public ZWaveCommandClass getCommandClass(ZWaveCommandClass.CommandClass commandClass) {
        return supportedCommandClasses.get(commandClass);
    }

    public void addCommandClass(ZWaveCommandClass commandClass) {
        ZWaveCommandClass.CommandClass key = commandClass.getCommandClass();
        if (!supportedCommandClasses.containsKey(key)) {
            supportedCommandClasses.put(key, commandClass);
        }
    }

    @Override
    public String toString() {
        return "endpoint " + endpointId;
    }
}







abstract class ZWaveCommandClass {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveCommandClass.class);

    private final ZWaveNode node;
    private final ZWaveController controller;
    private final ZWaveEndpoint endpoint;

    private int version = 0;
    private int instances = 0;

    protected ZWaveCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        this.node = node;
        this.controller = controller;
        this.endpoint = endpoint;
    }

    protected ZWaveNode getNode() {
        return node;
    }

    protected ZWaveController getController() {
        return controller;
    }

    public ZWaveEndpoint getEndpoint() {
        return endpoint;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getMaxVersion() {
        return 1;
    }

    public int getInstances() {
        return instances;
    }

    public void setInstances(int instances) {
        this.instances = instances;
    }

    public abstract CommandClass getCommandClass();

    public abstract void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint);

    public static ZWaveCommandClass getInstance(int i, ZWaveNode node, ZWaveController controller) {
        return ZWaveCommandClass.getInstance(i, node, controller, null);
    }

    public static ZWaveCommandClass getInstance(int i, ZWaveNode node, ZWaveController controller,
            ZWaveEndpoint endpoint) {
        logger.debug(String.format("Creating new instance of command class 0x%02X", i));
        try {
            CommandClass commandClass = CommandClass.getCommandClass(i);
            if (commandClass == null) {
                logger.warn(String.format("Unsupported command class 0x%02x", i));
                return null;
            }
            Class<? extends ZWaveCommandClass> commandClassClass = commandClass.getCommandClassClass();

            if (commandClassClass == null) {
                logger.warn(String.format("Unsupported command class %s (0x%02x)", commandClass.getLabel(), i));
                return null;
            }

            Constructor<? extends ZWaveCommandClass> constructor =
                    commandClassClass.getConstructor(ZWaveNode.class, ZWaveController.class, ZWaveEndpoint.class);
            return constructor.newInstance(new Object[] { node, controller, endpoint });
        } catch (InstantiationException e) {
        } catch (IllegalAccessException e) {
        } catch (IllegalArgumentException e) {
        } catch (InvocationTargetException e) {
        } catch (NoSuchMethodException e) {
        } catch (SecurityException e) {
        }
        logger.error(String.format("Error instantiating command class 0x%02x", i));
        return null;
    }

    public enum CommandClass {
        NO_OPERATION(0x00, "NO_OPERATION", ZWaveNoOperationCommandClass.class),
        BASIC(0x20, "BASIC", ZWaveBasicCommandClass.class),
        CONTROLLER_REPLICATION(0x21, "CONTROLLER_REPLICATION", null),
        APPLICATION_STATUS(0x22, "APPLICATION_STATUS", null),
        SWITCH_BINARY(0x25, "SWITCH_BINARY", ZWaveBinarySwitchCommandClass.class),
        SWITCH_MULTILEVEL(0x26, "SWITCH_MULTILEVEL", null),
        SWITCH_ALL(0x27, "SWITCH_ALL", null),
        SENSOR_BINARY(0x30, "SENSOR_BINARY", null),
        SENSOR_MULTILEVEL(0x31, "SENSOR_MULTILEVEL", null),
        METER(0x32, "METER", null),
        MULTI_INSTANCE(0x60, "MULTI_INSTANCE", ZWaveMultiInstanceCommandClass.class),
        CONFIGURATION(0x70, "CONFIGURATION", null),
        ALARM(0x71, "ALARM", null),
        MANUFACTURER_SPECIFIC(0x72, "MANUFACTURER_SPECIFIC", ZWaveManufacturerSpecificCommandClass.class),
        POWERLEVEL(0x73, "POWERLEVEL", null),
        NODE_NAMING(0x77, "NODE_NAMING", null),
        BATTERY(0x80, "BATTERY", ZWaveBatteryCommandClass.class),
        CLOCK(0x81, "CLOCK", null),
        HAIL(0x82, "HAIL", null),
        WAKE_UP(0x84, "WAKE_UP", ZWaveWakeUpCommandClass.class),
        ASSOCIATION(0x85, "ASSOCIATION", null),
        VERSION(0x86, "VERSION", ZWaveVersionCommandClass.class),
        INDICATOR(0x87, "INDICATOR", null),
        MANUFACTURER_PROPRIETARY(0x91, "MANUFACTURER_PROPRIETARY", null),
        SENSOR_ALARM(0x9C, "SENSOR_ALARM", null),
        SILENCE_ALARM(0x9D, "SILENCE_ALARM", null);

        private static Map<Integer, CommandClass> codeToCommandClassMapping;

        private int key;
        private String label;
        private Class<? extends ZWaveCommandClass> commandClassClass;

        private CommandClass(int key, String label, Class<? extends ZWaveCommandClass> commandClassClass) {
            this.key = key;
            this.label = label;
            this.commandClassClass = commandClassClass;
        }

        private static void initMapping() {
            codeToCommandClassMapping = new HashMap<Integer, CommandClass>();
            for (CommandClass s : values()) {
                codeToCommandClassMapping.put(s.key, s);
            }
        }

        public static CommandClass getCommandClass(int i) {
            if (codeToCommandClassMapping == null) {
                initMapping();
            }
            return codeToCommandClassMapping.get(i);
        }

        public int getKey() {
            return key;
        }

        public String getLabel() {
            return label;
        }

        public Class<? extends ZWaveCommandClass> getCommandClassClass() {
            return commandClassClass;
        }
    }
}





interface ZWaveCommandClassInitialization {

    Collection<SerialMessage> initialize();
}







class ZWaveNoOperationCommandClass extends ZWaveCommandClass {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveNoOperationCommandClass.class);

    public ZWaveNoOperationCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
    }

    @Override
    public CommandClass getCommandClass() {
        return CommandClass.NO_OPERATION;
    }

    @Override
    public void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint) {
        logger.warn("Received No Operation command, ignoring.");
    }

    public SerialMessage getNoOperationMessage() {
        logger.debug("Creating new message for application command No Operation for node {}",
                this.getNode().getNodeId());
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessagePriority.Low);
        byte[] newPayload = { (byte) this.getNode().getNodeId(), 1, (byte) getCommandClass().getKey() };
        result.setMessagePayload(newPayload);
        return result;
    }
}

class ZWaveBasicCommandClass extends ZWaveCommandClass {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveBasicCommandClass.class);

    private static final int BASIC_GET = 0x02;

    public ZWaveBasicCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
    }

    @Override
    public CommandClass getCommandClass() {
        return CommandClass.BASIC;
    }

    @Override
    public void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint) {
        logger.debug("Received Basic command for node {}", this.getNode().getNodeId());
    }

    public SerialMessage getValueMessage() {
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(), 2, (byte) getCommandClass().getKey(),
                (byte) BASIC_GET };
        result.setMessagePayload(newPayload);
        return result;
    }
}

class ZWaveBinarySwitchCommandClass extends ZWaveCommandClass implements ZWaveCommandClassInitialization {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveBinarySwitchCommandClass.class);

    private static final int SWITCH_BINARY_GET = 0x02;

    public ZWaveBinarySwitchCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
    }

    @Override
    public CommandClass getCommandClass() {
        return CommandClass.SWITCH_BINARY;
    }

    @Override
    public void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint) {
        logger.debug("Received Binary Switch report for node {}", this.getNode().getNodeId());
    }

    public SerialMessage getValueMessage() {
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(), 2, (byte) getCommandClass().getKey(),
                (byte) SWITCH_BINARY_GET };
        result.setMessagePayload(newPayload);
        return result;
    }

    @Override
    public Collection<SerialMessage> initialize() {
        ArrayList<SerialMessage> result = new ArrayList<SerialMessage>();
        result.add(getValueMessage());
        return result;
    }
}

class ZWaveBatteryCommandClass extends ZWaveCommandClass implements ZWaveCommandClassInitialization {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveBatteryCommandClass.class);

    private static final int BATTERY_GET = 0x02;

    public ZWaveBatteryCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
    }

    @Override
    public CommandClass getCommandClass() {
        return CommandClass.BATTERY;
    }

    @Override
    public void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint) {
        logger.debug("Received Battery report for node {}", this.getNode().getNodeId());
    }

    public SerialMessage getValueMessage() {
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(), 2, (byte) getCommandClass().getKey(),
                (byte) BATTERY_GET };
        result.setMessagePayload(newPayload);
        return result;
    }

    @Override
    public Collection<SerialMessage> initialize() {
        ArrayList<SerialMessage> result = new ArrayList<SerialMessage>();
        result.add(getValueMessage());
        return result;
    }
}

class ZWaveManufacturerSpecificCommandClass extends ZWaveCommandClass {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveManufacturerSpecificCommandClass.class);

    private static final int MANUFACTURER_SPECIFIC_GET = 0x04;

    public ZWaveManufacturerSpecificCommandClass(ZWaveNode node, ZWaveController controller,
            ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
    }

    @Override
    public CommandClass getCommandClass() {
        return CommandClass.MANUFACTURER_SPECIFIC;
    }

    @Override
    public void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint) {
        logger.debug("Received Manufacturer Specific report for node {}", this.getNode().getNodeId());
    }

    public SerialMessage getManufacturerSpecificMessage() {
        logger.debug("Creating new message for application command MANUFACTURER_SPECIFIC_GET for node {}",
                this.getNode().getNodeId());
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(), 2, (byte) getCommandClass().getKey(),
                (byte) MANUFACTURER_SPECIFIC_GET };
        result.setMessagePayload(newPayload);
        return result;
    }
}

class ZWaveVersionCommandClass extends ZWaveCommandClass {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveVersionCommandClass.class);

    private static final int VERSION_COMMAND_CLASS_GET = 0x13;

    public ZWaveVersionCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
    }

    @Override
    public CommandClass getCommandClass() {
        return CommandClass.VERSION;
    }

    @Override
    public int getMaxVersion() {
        return 2;
    }

    @Override
    public void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint) {
        logger.debug("Received Version report for node {}", this.getNode().getNodeId());
    }

    public SerialMessage getCommandClassVersionMessage(CommandClass commandClass) {
        logger.debug("Creating new message for application command VERSION_COMMAND_CLASS_GET for node {}",
                this.getNode().getNodeId());
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(), 3, (byte) getCommandClass().getKey(),
                (byte) VERSION_COMMAND_CLASS_GET, (byte) commandClass.getKey() };
        result.setMessagePayload(newPayload);
        return result;
    }

    public void checkVersion(ZWaveCommandClass commandClass) {
        ZWaveVersionCommandClass versionCommandClass =
                (ZWaveVersionCommandClass) this.getNode().getCommandClass(CommandClass.VERSION);

        if (versionCommandClass == null) {
            logger.error(String.format("Version command class not supported on node %d,"
                    + "reverting to version 1 for command class %s (0x%02x)",
                    this.getNode().getNodeId(),
                    commandClass.getCommandClass().getLabel(),
                    commandClass.getCommandClass().getKey()));
            return;
        }

        this.getController().sendData(
                versionCommandClass.getCommandClassVersionMessage(commandClass.getCommandClass()));
    }
}

class ZWaveWakeUpCommandClass extends ZWaveCommandClass implements ZWaveCommandClassInitialization {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveWakeUpCommandClass.class);

    private static final int WAKE_UP_INTERVAL_GET = 0x05;
    private static final int WAKE_UP_NO_MORE_INFORMATION = 0x08;

    private final ArrayList<SerialMessage> wakeUpQueue = new ArrayList<SerialMessage>();

    public ZWaveWakeUpCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
    }

    @Override
    public CommandClass getCommandClass() {
        return CommandClass.WAKE_UP;
    }

    @Override
    public int getMaxVersion() {
        return 2;
    }

    @Override
    public void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint) {
        logger.debug("Received Wake Up report for node {}", this.getNode().getNodeId());
    }

    public SerialMessage getNoMoreInformationMessage() {
        logger.debug("Creating new message for application command WAKE_UP_NO_MORE_INFORMATION for node {}",
                this.getNode().getNodeId());
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessagePriority.Low);
        byte[] newPayload = { (byte) this.getNode().getNodeId(), 2, (byte) getCommandClass().getKey(),
                (byte) WAKE_UP_NO_MORE_INFORMATION };
        result.setMessagePayload(newPayload);
        return result;
    }

    public SerialMessage getIntervalMessage() {
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(), 2, (byte) getCommandClass().getKey(),
                (byte) WAKE_UP_INTERVAL_GET };
        result.setMessagePayload(newPayload);
        return result;
    }

    public void putInWakeUpQueue(SerialMessage serialMessage) {
        if (this.wakeUpQueue.contains(serialMessage)) {
            logger.debug("Message already on the wake-up queue for node {}. Discarding.",
                    this.getNode().getNodeId());
            return;
        }
        this.wakeUpQueue.add(serialMessage);
    }

    @Override
    public Collection<SerialMessage> initialize() {
        ArrayList<SerialMessage> result = new ArrayList<SerialMessage>();
        result.add(getIntervalMessage());
        return result;
    }
}






class ZWaveMultiInstanceCommandClass extends ZWaveCommandClass {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveMultiInstanceCommandClass.class);

    
    private static final int MULTI_INSTANCE_GET = 0x04;
    private static final int MULTI_INSTANCE_REPORT = 0x05;
    private static final int MULTI_INSTANCE_ENCAP = 0x06;

    
    private static final int MULTI_CHANNEL_ENDPOINT_GET = 0x07;
    private static final int MULTI_CHANNEL_ENDPOINT_REPORT = 0x08;
    private static final int MULTI_CHANNEL_CAPABILITY_GET = 0x09;
    private static final int MULTI_CHANNEL_CAPABILITY_REPORT = 0x0a;
    private static final int MULTI_CHANNEL_ENDPOINT_FIND = 0x0b;
    private static final int MULTI_CHANNEL_ENDPOINT_FIND_REPORT = 0x0c;
    private static final int MULTI_CHANNEL_ENCAP = 0x0d;

    private final Map<Integer, ZWaveEndpoint> endpoints = new HashMap<Integer, ZWaveEndpoint>();

    private boolean endpointsAreTheSameDeviceClass;

    public ZWaveMultiInstanceCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
    }

    @Override
    public CommandClass getCommandClass() {
        return CommandClass.MULTI_INSTANCE;
    }

    @Override
    public int getMaxVersion() {
        return 2;
    }

    public ZWaveEndpoint getEndpoint(int endpointId) {
        return this.endpoints.get(endpointId);
    }

    public Collection<ZWaveEndpoint> getEndpoints() {
        return this.endpoints.values();
    }

    






    void seedEndpoints(int count, boolean sameDeviceClass) {
        this.endpoints.clear();
        for (int i = 1; i <= count; i++) {
            this.endpoints.put(i, new ZWaveEndpoint(new ZWaveDeviceClass(
                    ZWaveDeviceClass.Basic.NOT_KNOWN, ZWaveDeviceClass.Generic.NOT_KNOWN,
                    ZWaveDeviceClass.Specific.NOT_USED), i));
        }
        this.endpointsAreTheSameDeviceClass = sameDeviceClass;
    }

    boolean isEndpointsAreTheSameDeviceClass() {
        return endpointsAreTheSameDeviceClass;
    }

    @Override
    public void handleApplicationCommandRequest(SerialMessage serialMessage, int offset, int endpoint) {
        logger.debug("Received Multi-instance/Multi-channel request for node {}", this.getNode().getNodeId());
        int command = serialMessage.getMessagePayloadByte(offset);
        switch (command) {
            case MULTI_CHANNEL_CAPABILITY_REPORT:
                handleMultiChannelCapabilityReportResponse(serialMessage, offset + 1);
                break;
            default:
                logger.warn(String.format("Unsupported Command 0x%02X for command class %s (0x%02X).",
                        command, this.getCommandClass().getLabel(), this.getCommandClass().getKey()));
        }
    }

	
	private void handleMultiChannelCapabilityReportResponse(SerialMessage serialMessage, int offset) {
		logger.debug("Process Multi-channel capability Report");
		int receivedEndpointId = serialMessage.getMessagePayloadByte(offset) & 0x7F;
		boolean dynamic = ((serialMessage.getMessagePayloadByte(offset) & 0x80) != 0);
		int genericDeviceClass = serialMessage.getMessagePayloadByte(offset + 1);
		int specificDeviceClass = serialMessage.getMessagePayloadByte(offset + 2);
		
		logger.debug("Endpoints are the same device class = {}", endpointsAreTheSameDeviceClass ? "true" : false);

		
		
		int startId = this.endpointsAreTheSameDeviceClass ? 1 : receivedEndpointId;
		int endId = this.endpointsAreTheSameDeviceClass ? this.endpoints.size() : receivedEndpointId;
		
		boolean supportsBasicCommandClass = this.getNode().supportsCommandClass(CommandClass.BASIC);
		
		for (int endpointId = startId; endpointId <= endId; endpointId++) {
			ZWaveEndpoint endpoint = this.endpoints.get(endpointId);
			
			if (endpoint == null){
				logger.error("Endpoint {} not found on node {}. Cannot set command classes.", endpoint, this.getNode().getNodeId());
				continue;
			}
	
			ZWaveDeviceClass.Basic basic = this.getNode().getDeviceClass().getBasicDeviceClass();
			ZWaveDeviceClass.Generic generic = ZWaveDeviceClass.Generic.getGeneric(genericDeviceClass);
			if (generic == null) {
				logger.error(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.", 
						endpoint, genericDeviceClass, specificDeviceClass));
				continue;
			}
			ZWaveDeviceClass.Specific specific = ZWaveDeviceClass.Specific.getSpecific(generic, specificDeviceClass);
			if (specific == null) {
				logger.error(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.", 
						endpoint, genericDeviceClass, specificDeviceClass));
				continue;
			}
			
			logger.debug("Endpoint Id = {}", endpointId);
			logger.debug("Endpoints is dynamic = {}", dynamic ? "true" : false);
			logger.debug(String.format("Basic = %s 0x%02x", basic.getLabel(), basic.getKey()));
			logger.debug(String.format("Generic = %s 0x%02x", generic.getLabel(), generic.getKey()));
			logger.debug(String.format("Specific = %s 0x%02x", specific.getLabel(), specific.getKey()));
			
			ZWaveDeviceClass deviceClass = endpoint.getDeviceClass();
			deviceClass.setBasicDeviceClass(basic);
			deviceClass.setGenericDeviceClass(generic);
			deviceClass.setSpecificDeviceClass(specific);
			
			
			if (supportsBasicCommandClass) {
				ZWaveCommandClass commandClass = new ZWaveBasicCommandClass(this.getNode(), this.getController(), endpoint);
				endpoint.addCommandClass(commandClass);
			}
			
			for (int i = 0; i < serialMessage.getMessagePayload().length - offset - 3; i++) {
				int data = serialMessage.getMessagePayloadByte(offset + 3 + i);
				if(data == 0xef )  {
					
					break;
				}
				logger.debug(String.format("Adding command class 0x%02X to the list of supported command classes.", data));
				ZWaveCommandClass commandClass = ZWaveCommandClass.getInstance(data, this.getNode(), this.getController(), endpoint);
				if (commandClass == null) {
					continue;
				}

				endpoint.addCommandClass(commandClass);
				ZWaveCommandClass parentClass = this.getNode().getCommandClass(commandClass.getCommandClass());

				
				if (parentClass != null) {
					commandClass.setVersion(parentClass.getVersion());
				}
			}
		}
		
		if (this.endpointsAreTheSameDeviceClass)
			
			this.getNode().advanceNodeStage();
		else {
			for (ZWaveEndpoint ep : this.endpoints.values())
			{
				if (ep.getDeviceClass().getBasicDeviceClass() == ZWaveDeviceClass.Basic.NOT_KNOWN) 
					return;
			}
			
			this.getNode().advanceNodeStage();
		}
	}
	

    public SerialMessage getMultiInstanceGetMessage(CommandClass commandClass) {
        logger.debug("Creating new message for application command MULTI_INSTANCE_GET for node {} and command class {}",
                this.getNode().getNodeId(), commandClass.getLabel());
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(),
                3,
                (byte) getCommandClass().getKey(),
                (byte) MULTI_INSTANCE_GET,
                (byte) commandClass.getKey()
                };
        result.setMessagePayload(newPayload);
        return result;
    }

    public SerialMessage getMultiInstanceEncapMessage(SerialMessage serialMessage, int instance) {
        logger.debug("Creating new message for application command MULTI_INSTANCE_ENCAP for node {} and instance {}",
                this.getNode().getNodeId(), instance);

        byte[] payload = serialMessage.getMessagePayload();
        byte[] newPayload = new byte[payload.length + 3];
        System.arraycopy(payload, 0, newPayload, 0, 2);
        System.arraycopy(payload, 0, newPayload, 3, payload.length);
        newPayload[1] += 3;
        newPayload[2] = (byte) this.getCommandClass().getKey();
        newPayload[3] = MULTI_INSTANCE_ENCAP;
        newPayload[4] = (byte) (instance);

        serialMessage.setMessagePayload(newPayload);
        return serialMessage;
    }

    public SerialMessage getMultiChannelEndpointGetMessage() {
        logger.debug("Creating new message for application command MULTI_CHANNEL_ENDPOINT_GET for node {}",
                this.getNode().getNodeId());
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(),
                2,
                (byte) getCommandClass().getKey(),
                (byte) MULTI_CHANNEL_ENDPOINT_GET };
        result.setMessagePayload(newPayload);
        return result;
    }

    public SerialMessage getMultiChannelCapabilityGetMessage(ZWaveEndpoint endpoint) {
        logger.debug("Creating new message for application command MULTI_CHANNEL_CAPABILITY_GET for node {} and endpoint {}",
                this.getNode().getNodeId(), endpoint.getEndpointId());
        SerialMessage result = new SerialMessage(this.getNode().getNodeId(),
                SerialMessage.SerialMessageClass.SendData, SerialMessage.SerialMessageType.Request,
                SerialMessage.SerialMessageClass.ApplicationCommandHandler,
                SerialMessage.SerialMessagePriority.Get);
        byte[] newPayload = { (byte) this.getNode().getNodeId(),
                3,
                (byte) getCommandClass().getKey(),
                (byte) MULTI_CHANNEL_CAPABILITY_GET,
                (byte) endpoint.getEndpointId() };
        result.setMessagePayload(newPayload);
        return result;
    }

    public SerialMessage getMultiChannelEncapMessage(SerialMessage serialMessage, ZWaveEndpoint endpoint) {
        logger.debug("Creating new message for application command MULTI_CHANNEL_ENCAP for node {} and endpoint {}",
                this.getNode().getNodeId(), endpoint.getEndpointId());

        byte[] payload = serialMessage.getMessagePayload();
        byte[] newPayload = new byte[payload.length + 4];
        System.arraycopy(payload, 0, newPayload, 0, 2);
        System.arraycopy(payload, 0, newPayload, 4, payload.length);
        newPayload[1] += 4;
        newPayload[2] = (byte) this.getCommandClass().getKey();
        newPayload[3] = MULTI_CHANNEL_ENCAP;
        newPayload[4] = 0x01;
        newPayload[5] = (byte) endpoint.getEndpointId();

        serialMessage.setMessagePayload(newPayload);
        return serialMessage;
    }

    public void initEndpoints() {
        switch (this.getVersion()) {
            case 1:
                
                for (ZWaveCommandClass commandClass : this.getNode().getCommandClasses()) {
                    if (commandClass.getCommandClass() == CommandClass.NO_OPERATION) {
                        continue;
                    }
                    this.getController().sendData(this.getMultiInstanceGetMessage(commandClass.getCommandClass()));
                }
                break;
            case 2:
                this.getController().sendData(this.getMultiChannelEndpointGetMessage());
                break;
            default:
                logger.warn(String.format("Unknown version %d for command class %s (0x%02x)",
                        this.getVersion(), this.getCommandClass().getLabel(), this.getCommandClass().getKey()));
        }
    }
}














class ZWaveController {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveController.class);

    private final int ownNodeId;
    private final List<SerialMessage> sentMessages = new ArrayList<SerialMessage>();
    private final List<String> transactions = new ArrayList<String>();
    private final List<ZWaveEventListener> zwaveEventListeners = new ArrayList<ZWaveEventListener>();

    
    private boolean serialInterfaceBroken;

    public ZWaveController(int ownNodeId) {
        this.ownNodeId = ownNodeId;
    }

    public int getOwnNodeId() {
        return ownNodeId;
    }

    public void identifyNode(int nodeId) throws SerialInterfaceException {
        if (serialInterfaceBroken) {
            throw new SerialInterfaceException("Error while sending IdentifyNode message to node " + nodeId);
        }
        transactions.add("identifyNode(" + nodeId + ")");
        SerialMessage message = new SerialMessage(nodeId, SerialMessage.SerialMessageClass.IdentifyNode,
                SerialMessage.SerialMessageType.Request, SerialMessage.SerialMessageClass.IdentifyNode,
                SerialMessage.SerialMessagePriority.High);
        message.setMessagePayload(new byte[] { (byte) nodeId });
        sentMessages.add(message);
    }

    public void requestNodeInfo(int nodeId) {
        transactions.add("requestNodeInfo(" + nodeId + ")");
        SerialMessage message = new SerialMessage(nodeId, SerialMessage.SerialMessageClass.RequestNodeInfo,
                SerialMessage.SerialMessageType.Request, SerialMessage.SerialMessageClass.ApplicationUpdate,
                SerialMessage.SerialMessagePriority.High);
        message.setMessagePayload(new byte[] { (byte) nodeId });
        sentMessages.add(message);
    }

    public void sendData(SerialMessage serialMessage) {
        if (serialMessage == null) {
            transactions.add("sendData(null)  - discarded, exactly like the real controller");
            return;
        }
        transactions.add("sendData(" + serialMessage + ")");
        sentMessages.add(serialMessage);
    }

    public void addEventListener(ZWaveEventListener eventListener) {
        zwaveEventListeners.add(eventListener);
    }

    public void removeEventListener(ZWaveEventListener eventListener) {
        zwaveEventListeners.remove(eventListener);
    }

    void setSerialInterfaceBroken(boolean broken) {
        this.serialInterfaceBroken = broken;
    }

    List<SerialMessage> getSentMessages() {
        return sentMessages;
    }

    List<String> drainTransactions() {
        final List<String> copy = new ArrayList<String>(transactions);
        transactions.clear();
        sentMessages.clear();
        return copy;
    }
}








class ZWaveNode {

    private static final Logger logger = LoggerFactory.getLogger(ZWaveNode.class);

    private final ZWaveDeviceClass deviceClass;
    private final ZWaveController controller;

    private int homeId;
    private int nodeId;
    private int version;

    private String name;
    private String location;

    private int manufacturer;
    private int deviceId;
    private int deviceType;

    private boolean listening; 
    private boolean routing;

    private Map<ZWaveCommandClass.CommandClass, ZWaveCommandClass> supportedCommandClasses =
            new HashMap<ZWaveCommandClass.CommandClass, ZWaveCommandClass>();
    private Date lastUpdated;
    private Date queryStageTimeStamp;
    private NodeStage nodeStage;

    private int resendCount = 0;
    private int queriesPending = -1;
    private boolean initializationComplete = false;

    public ZWaveNode(int homeId, int nodeId, ZWaveController controller) {
        this.homeId = homeId;
        this.nodeId = nodeId;
        this.controller = controller;
        this.nodeStage = NodeStage.NODEBUILDINFO_EMPTYNODE;
        this.deviceClass = new ZWaveDeviceClass(ZWaveDeviceClass.Basic.NOT_KNOWN,
                ZWaveDeviceClass.Generic.NOT_KNOWN, ZWaveDeviceClass.Specific.NOT_USED);
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public int getNodeId() {
        return nodeId;
    }

    public boolean isListening() {
        return listening;
    }

    public void setListening(boolean listening) {
        this.listening = listening;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public boolean isSleepingOrDead() {
        return !listening || nodeStage == NodeStage.NODEBUILDINFO_DEAD;
    }

    public Integer getHomeId() {
        return homeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(int tempMan) {
        this.manufacturer = tempMan;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public int getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(int tempDeviceId) {
        this.deviceId = tempDeviceId;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public int getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(int tempDeviceType) {
        this.deviceType = tempDeviceType;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public NodeStage getNodeStage() {
        return nodeStage;
    }

    public void setNodeStage(NodeStage nodeStage) {
        this.nodeStage = nodeStage;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public boolean isRouting() {
        return routing;
    }

    public void setRouting(boolean routing) {
        this.routing = routing;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public Date getQueryStageTimeStamp() {
        return queryStageTimeStamp;
    }

    public void setQueryStageTimeStamp(Date queryStageTimeStamp) {
        this.queryStageTimeStamp = queryStageTimeStamp;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public void incrementResendCount() {
        this.resendCount++;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public void resetResendCount() {
        this.resendCount = 0;
        this.lastUpdated = Calendar.getInstance().getTime();
    }

    public int getResendCount() {
        return resendCount;
    }

    public boolean isInitializationComplete() {
        return initializationComplete;
    }

    public int getQueriesPending() {
        return queriesPending;
    }

    public void setQueriesPending(int queriesPending) {
        this.queriesPending = queriesPending;
    }

    public ZWaveDeviceClass getDeviceClass() {
        return deviceClass;
    }

    public Collection<ZWaveCommandClass> getCommandClasses() {
        return supportedCommandClasses.values();
    }

    public ZWaveCommandClass getCommandClass(ZWaveCommandClass.CommandClass commandClass) {
        return supportedCommandClasses.get(commandClass);
    }

    public boolean supportsCommandClass(ZWaveCommandClass.CommandClass commandClass) {
        return supportedCommandClasses.containsKey(commandClass);
    }

    public void addCommandClass(ZWaveCommandClass commandClass) {
        ZWaveCommandClass.CommandClass key = commandClass.getCommandClass();

        if (!supportedCommandClasses.containsKey(key)) {
            supportedCommandClasses.put(key, commandClass);

            if (commandClass instanceof ZWaveEventListener) {
                this.controller.addEventListener((ZWaveEventListener) commandClass);
            }

            this.lastUpdated = Calendar.getInstance().getTime();
        }
    }

    public ZWaveCommandClass resolveCommandClass(ZWaveCommandClass.CommandClass commandClass, int endpointId) {
        if (commandClass == null) {
            return null;
        }

        ZWaveMultiInstanceCommandClass multiInstanceCommandClass =
                (ZWaveMultiInstanceCommandClass) supportedCommandClasses.get(
                        ZWaveCommandClass.CommandClass.MULTI_INSTANCE);

        if (multiInstanceCommandClass != null && multiInstanceCommandClass.getVersion() == 2) {
            ZWaveEndpoint endpoint = multiInstanceCommandClass.getEndpoint(endpointId);

            if (endpoint != null) {
                ZWaveCommandClass result = endpoint.getCommandClass(commandClass);
                if (result != null) {
                    return result;
                }
            }
        }

        ZWaveCommandClass result = getCommandClass(commandClass);

        if (result == null) {
            return result;
        }

        if (multiInstanceCommandClass != null && multiInstanceCommandClass.getVersion() == 1
                && result.getInstances() >= endpointId) {
            return result;
        }

        return endpointId == 1 ? result : null;
    }

	public void advanceNodeStage() {
		this.setQueryStageTimeStamp(Calendar.getInstance().getTime());
		switch (this.nodeStage) {
			case NODEBUILDINFO_EMPTYNODE:
				try {
					this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_PROTOINFO);
					this.controller.identifyNode(this.nodeId);
				} catch (SerialInterfaceException e) {
					logger.error("Got error: {}, while identifying node {}", e.getLocalizedMessage(), this.nodeId);
				}
				break;
			case NODEBUILDINFO_PROTOINFO:
				if (nodeId != this.controller.getOwnNodeId())
				{
					ZWaveNoOperationCommandClass zwaveCommandClass = (ZWaveNoOperationCommandClass)supportedCommandClasses.get(ZWaveCommandClass.CommandClass.NO_OPERATION);
					if (zwaveCommandClass == null)
						break;
					
					this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_PING);
					this.controller.sendData(zwaveCommandClass.getNoOperationMessage());
				} else
				{
					this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_DONE); 
				}
				break;
			case NODEBUILDINFO_PING:
			case NODEBUILDINFO_WAKEUP:
				this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_DETAILS);
				this.controller.requestNodeInfo(nodeId);
				break;
			case NODEBUILDINFO_DETAILS:
				
				ZWaveManufacturerSpecificCommandClass manufacturerSpecific = (ZWaveManufacturerSpecificCommandClass)this.getCommandClass(ZWaveCommandClass.CommandClass.MANUFACTURER_SPECIFIC);
				
				if (manufacturerSpecific != null) {
					
					this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_MANSPEC01);
					this.controller.sendData(manufacturerSpecific.getManufacturerSpecificMessage());
					break;
				}
				
				logger.warn("Node {} does not support MANUFACTURER_SPECIFIC, proceeding to version node stage.", this.getNodeId());
			case NODEBUILDINFO_MANSPEC01:
				this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_VERSION); 
				
				ZWaveVersionCommandClass version = (ZWaveVersionCommandClass)this.getCommandClass(ZWaveCommandClass.CommandClass.VERSION);
				
				boolean checkVersionCalled = false;
				for (ZWaveCommandClass zwaveCommandClass : this.getCommandClasses()) {
					if (version != null && zwaveCommandClass.getMaxVersion() > 1) {
						version.checkVersion(zwaveCommandClass); 
						checkVersionCalled = true;				
					} else
						zwaveCommandClass.setVersion(1);  
				}
				
				if (checkVersionCalled) 
					break;
			case NODEBUILDINFO_VERSION:
				this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_INSTANCES); 
				
				ZWaveMultiInstanceCommandClass multiInstance = (ZWaveMultiInstanceCommandClass)this.getCommandClass(ZWaveCommandClass.CommandClass.MULTI_INSTANCE);
				
				if (multiInstance != null) {
					multiInstance.initEndpoints();
					break;
				} 
					
				logger.trace("Node {} does not support MULTI_INSTANCE, proceeding to static node stage.", this.getNodeId());
			case NODEBUILDINFO_INSTANCES:
				this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_STATIC); 
				
				if (queriesPending == -1) {
					queriesPending = 0;
					for (ZWaveCommandClass zwaveCommandClass : this.getCommandClasses()) {
						logger.trace("Inspecting command class {}", zwaveCommandClass.getCommandClass().getLabel());
						if (zwaveCommandClass instanceof ZWaveCommandClassInitialization) {
							logger.debug("Found initializable command class {}", zwaveCommandClass.getCommandClass().getLabel());
							ZWaveCommandClassInitialization zcci = (ZWaveCommandClassInitialization)zwaveCommandClass;
							int instances = zwaveCommandClass.getInstances();
							if (instances == 0)
							{
								Collection<SerialMessage> initqueries = zcci.initialize();
								for (SerialMessage serialMessage : initqueries) {
									this.controller.sendData(serialMessage);
									queriesPending++;
								}
							} else {
								for (int i = 1; i <= instances; i++) {
									Collection<SerialMessage> initqueries = zcci.initialize();
									for (SerialMessage serialMessage : initqueries) {
										this.controller.sendData(this.encapsulate(serialMessage, zwaveCommandClass, i));
										queriesPending++;
									}
								}
							}
						} else if (zwaveCommandClass instanceof ZWaveMultiInstanceCommandClass) {
							ZWaveMultiInstanceCommandClass multiInstanceCommandClass = (ZWaveMultiInstanceCommandClass)zwaveCommandClass;
							for (ZWaveEndpoint endpoint : multiInstanceCommandClass.getEndpoints()) {
								for (ZWaveCommandClass endpointCommandClass : endpoint.getCommandClasses()) {
									logger.trace("Inspecting command class {} for endpoint {}", endpointCommandClass.getCommandClass().getLabel(), endpoint.getEndpointId());
									if (endpointCommandClass instanceof ZWaveCommandClassInitialization) {
										logger.debug("Found initializable command class {}", endpointCommandClass.getCommandClass().getLabel());
										ZWaveCommandClassInitialization zcci2 = (ZWaveCommandClassInitialization)endpointCommandClass;
										Collection<SerialMessage> initqueries = zcci2.initialize();
										for (SerialMessage serialMessage : initqueries) {
											this.controller.sendData(this.encapsulate(serialMessage, endpointCommandClass, endpoint.getEndpointId()));
											queriesPending++;
										}
									}
								}
							}
						}
					}
				}
				if (queriesPending-- > 0) 
					break;
				
				logger.trace("Done getting static values, proceeding to done node stage.", this.getNodeId());
			case NODEBUILDINFO_STATIC:
				this.setNodeStage(ZWaveNode.NodeStage.NODEBUILDINFO_DONE); 
				initializationComplete = true;
				
				if (this.isListening())
					return;
				
				ZWaveWakeUpCommandClass wakeup = (ZWaveWakeUpCommandClass)this.getCommandClass(ZWaveCommandClass.CommandClass.WAKE_UP);
				
				if (wakeup == null)
					return;

				logger.debug("Node {} is a battery operated device. Tell it to go to sleep.", this.getNodeId());
				this.controller.sendData(wakeup.getNoMoreInformationMessage());
				break;
			case NODEBUILDINFO_DONE:
			case NODEBUILDINFO_DEAD:
				break;
			default:
				logger.error("Unknown node state {} encountered on Node {}", this.nodeStage.getLabel(), this.getNodeId());
		}
	}

    public SerialMessage encapsulate(SerialMessage serialMessage,
            ZWaveCommandClass commandClass, int endpointId) {
        ZWaveMultiInstanceCommandClass multiInstanceCommandClass;

        if (serialMessage == null) {
            return null;
        }

        
        if (endpointId == 1 && commandClass.getInstances() == 1 && commandClass.getEndpoint() == null) {
            return serialMessage;
        }

        multiInstanceCommandClass = (ZWaveMultiInstanceCommandClass) this.getCommandClass(
                ZWaveCommandClass.CommandClass.MULTI_INSTANCE);

        if (multiInstanceCommandClass != null) {
            logger.debug("Encapsulating message for node {}, instance / endpoint {}", this.getNodeId(), endpointId);
            switch (multiInstanceCommandClass.getVersion()) {
                case 2:
                    if (commandClass.getEndpoint() != null) {
                        serialMessage = multiInstanceCommandClass.getMultiChannelEncapMessage(serialMessage,
                                commandClass.getEndpoint());
                        return serialMessage;
                    }
                    break;
                case 1:
                default:
                    if (commandClass.getInstances() >= endpointId) {
                        serialMessage = multiInstanceCommandClass.getMultiInstanceEncapMessage(serialMessage,
                                endpointId);
                        return serialMessage;
                    }
                    break;
            }
        }

        if (endpointId != 1) {
            logger.warn("Encapsulating message for node {}, instance / endpoint {} failed, will discard message.",
                    this.getNodeId(), endpointId);
            return null;
        }

        return serialMessage;
    }

    public enum NodeStage {
        NODEBUILDINFO_EMPTYNODE(0, "Empty New Node"),
        NODEBUILDINFO_PROTOINFO(1, "Protocol Information"),
        NODEBUILDINFO_PING(2, "Ping Node"),
        NODEBUILDINFO_WAKEUP(3, "Wake Up"),
        NODEBUILDINFO_DETAILS(4, "Node Information"),
        NODEBUILDINFO_MANSPEC01(5, "Manufacture Name and Product Identification"),
        NODEBUILDINFO_MANSPEC02(6, "Manufacture Name and Product Identification"),
        NODEBUILDINFO_VERSION(7, "Node Version"),
        NODEBUILDINFO_INSTANCES(8, "Command Class Instances"),
        NODEBUILDINFO_STATIC(9, "Static Information"),
        NODEBUILDINFO_PROBE01(10, "Ping Node"),
        NODEBUILDINFO_ASSOCIATIONS(11, "Association Information"),
        NODEBUILDINFO_NEIGHBORS(12, "Node Neighbor Information"),
        NODEBUILDINFO_SESSION(13, "Infrequently Changed Information"),
        NODEBUILDINFO_DYNAMIC(14, "Frequently Changed Information"),
        NODEBUILDINFO_CONFIG(15, "Parameter Information"),
        NODEBUILDINFO_DONE(16, "Node Complete"),
        NODEBUILDINFO_INIT(17, "Node Not Started"),
        NODEBUILDINFO_DEAD(18, "Node Dead or Sleeping");

        private int stage;
        private String label;

        private NodeStage(int s, String l) {
            stage = s;
            label = l;
        }

        public int getStage() {
            return this.stage;
        }

        public String getLabel() {
            return this.label;
        }
    }
}
