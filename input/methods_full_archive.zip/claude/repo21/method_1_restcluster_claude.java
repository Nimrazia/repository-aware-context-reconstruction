

















































import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_1_restcluster_claude {

    
    static class SessionFailOverListener implements FailOverListener {

        private final FqnWrapper baseFqn = FqnWrapper.fromStringWrapper("/sessions");
        private final List<String> wonOwnershipOf = new ArrayList<String>();
        private final List<Address> failedOverMembers = new ArrayList<Address>();

        public FqnWrapper getBaseFqn() {
            return baseFqn;
        }

        public ClientLocalListenerElector getElector() {
            return null; 
        }

        public byte getPriority() {
            return 5;
        }

        public void failOverClusterMember(final Address address) {
            failedOverMembers.add(address);
            System.out.println("        [listener] failOverClusterMember(" + address + ")");
        }

        public void wonOwnership(final ClusteredCacheData clusteredCacheData) {
            final String child = String.valueOf(clusteredCacheData.getNodeFqnLastElement());
            wonOwnershipOf.add(child);
            System.out.println("        [listener] wonOwnership(" + child + ")");
        }

        public void lostOwnership(final ClusteredCacheData clusteredCacheData) {
            System.out.println("        [listener] lostOwnership(" + clusteredCacheData.getNodeFqnLastElement() + ")");
        }
    }

    
    static class LocalElectorFailOverListener implements FailOverListener {

        private final FqnWrapper baseFqn = FqnWrapper.fromStringWrapper("/queues");
        final List<String> wonOwnershipOf = new ArrayList<String>();

        public FqnWrapper getBaseFqn() {
            return baseFqn;
        }

        public ClientLocalListenerElector getElector() {
            return new ClientLocalListenerElector() {
                public Address elect(final List<Address> nodes, final ClusteredCacheData cacheData) {
                    return nodes.isEmpty() ? null : nodes.get(0);
                }
            };
        }

        public byte getPriority() {
            return 3;
        }

        public void failOverClusterMember(final Address address) {
            System.out.println("        [local-elector listener] failOverClusterMember(" + address + ")");
        }

        public void wonOwnership(final ClusteredCacheData clusteredCacheData) {
            wonOwnershipOf.add(String.valueOf(clusteredCacheData.getNodeFqnLastElement()));
            System.out.println("        [local-elector listener] wonOwnership(" + clusteredCacheData.getNodeFqnLastElement() + ")");
        }

        public void lostOwnership(final ClusteredCacheData clusteredCacheData) {
        }
    }

    public static void main(final String[] args) throws Exception {
        title("METHOD 1  |  DefaultMobicentsCluster.onViewChangeEvent(ViewChangedEvent event)");

        section("1. a member leaves - cluster-wide election, this node wins the takeover");
        run(false, true);

        section("2. a member leaves - a listener with its own ClientLocalListenerElector");
        run(false, false);

        section("3. the very first view (oldView == null) - the precaution guard skips everything");
        final Address self = new Address("node-A:7800");
        final Configuration config = new Configuration(CacheMode.REPL_SYNC, new BuddyReplicationConfig(false), self);
        final Cache cache = new Cache(config, self);
        final MobicentsCache mobicentsCache = new MobicentsCache(cache);
        final DefaultMobicentsCluster cluster = new DefaultMobicentsCluster(mobicentsCache, new TransactionManager(),
                new ClusterElector() {
                    public Address elect(final List<Address> list) {
                        return list.isEmpty() ? null : list.get(0);
                    }
                });
        cluster.onViewChangeEvent(new ViewChangedEvent(false, cache, new View(Arrays.asList(self))));
        System.out.println("      no recovery thread was started - there was nothing to compare the new view against");

        title("END OF METHOD 1 SCENARIOS");
    }

    static void run(final boolean buddyReplication, final boolean useSessionListener) throws Exception {
        final Address self = new Address("node-A:7800");
        final Address peer = new Address("node-B:7800");

        final Configuration config = new Configuration(buddyReplication ? CacheMode.REPL_SYNC : CacheMode.REPL_SYNC,
                new BuddyReplicationConfig(buddyReplication), self);
        final Cache cache = new Cache(config, self);
        cache.create();
        final MobicentsCache mobicentsCache = new MobicentsCache(cache);

        final ClusterElector clusterElector = new ClusterElector() {
            public Address elect(final List<Address> list) {
                Address winner = null;
                for (final Address candidate : list) {
                    if (winner == null || candidate.compareTo(winner) < 0) {
                        winner = candidate;
                    }
                }
                return winner;
            }
        };
        final DefaultMobicentsCluster cluster = new DefaultMobicentsCluster(mobicentsCache, new TransactionManager(), clusterElector);

        final FailOverListener listener;
        final Object typed;
        if (useSessionListener) {
            final SessionFailOverListener sessionListener = new SessionFailOverListener();
            listener = sessionListener;
            typed = sessionListener;
        } else {
            final LocalElectorFailOverListener localListener = new LocalElectorFailOverListener();
            listener = localListener;
            typed = localListener;
        }
        cluster.addFailOverListener(listener);

        final ClusteredCacheData data = new ClusteredCacheData(
                FqnWrapper.fromRelativeElementsWrapper(listener.getBaseFqn(), "child-1"), cluster);
        data.create();
        data.setClusterNodeAddress(peer);

        cluster.onViewChangeEvent(new ViewChangedEvent(false, cache, new View(Arrays.asList(self, peer))));
        System.out.println("      view 1 (both members) delivered, currentView = " + cluster.getClusterMembers());

        cluster.onViewChangeEvent(new ViewChangedEvent(false, cache, new View(Arrays.asList(self))));
        System.out.println("      view 2 (peer left) delivered, currentView = " + cluster.getClusterMembers());

        Thread.sleep(300);

        System.out.println("      owner of child-1 after takeover : " + data.getClusterNodeAddress());
        if (typed instanceof SessionFailOverListener) {
            System.out.println("      listener.wonOwnershipOf : " + ((SessionFailOverListener) typed).wonOwnershipOf);
        } else {
            System.out.println("      listener.wonOwnershipOf : " + ((LocalElectorFailOverListener) typed).wonOwnershipOf);
        }
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}







class DefaultMobicentsCluster implements MobicentsCluster {

    private static final String BUDDY_BACKUP_FQN_ROOT = "/_BUDDY_BACKUP_/";

    private static final Logger logger = Logger.getLogger(DefaultMobicentsCluster.class);

    private static final String BUDDIES_STORE = "MC_BUDDIES";

    private final java.util.SortedSet<FailOverListener> failOverListeners;

    private final java.util.concurrent.ConcurrentHashMap<Fqn, DataRemovalListener> dataRemovalListeners;

    private final MobicentsCache mobicentsCache;
    private final TransactionManager txMgr;
    private final ClusterElector elector;
    private final DefaultClusteredCacheDataIndexingHandler clusteredCacheDataIndexingHandler;

    private List<Address> currentView;

    public DefaultMobicentsCluster(MobicentsCache watchedCache, TransactionManager txMgr, ClusterElector elector) {
        this.failOverListeners = java.util.Collections
                .synchronizedSortedSet(new java.util.TreeSet<FailOverListener>(new FailOverListenerPriorityComparator()));
        this.dataRemovalListeners = new java.util.concurrent.ConcurrentHashMap<Fqn, DataRemovalListener>();
        this.mobicentsCache = watchedCache;
        this.txMgr = txMgr;
        this.elector = elector;
        this.clusteredCacheDataIndexingHandler = new DefaultClusteredCacheDataIndexingHandler();
        watchedCache.getJBossCache().addCacheListener(this);
    }

    public Address getLocalAddress() {
        return mobicentsCache.getJBossCache().getLocalAddress();
    }

    public List<Address> getClusterMembers() {
        if (currentView != null) {
            return java.util.Collections.unmodifiableList(currentView);
        } else {
            final Address localAddress = getLocalAddress();
            if (localAddress == null) {
                return java.util.Collections.emptyList();
            } else {
                final List<Address> list = new ArrayList<Address>();
                list.add(localAddress);
                return java.util.Collections.unmodifiableList(list);
            }
        }
    }

    public boolean isHeadMember() {
        final Address localAddress = getLocalAddress();
        if (localAddress != null) {
            final List<Address> clusterMembers = getClusterMembers();
            return !clusterMembers.isEmpty() && clusterMembers.get(0).equals(localAddress);
        } else {
            return true;
        }
    }

    public boolean isSingleMember() {
        final Address localAddress = getLocalAddress();
        if (localAddress != null) {
            final List<Address> clusterMembers = getClusterMembers();
            return clusterMembers.size() == 1;
        } else {
            return true;
        }
    }

	
	@ViewChanged
	public synchronized void onViewChangeEvent(ViewChangedEvent event) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("onViewChangeEvent : pre[" + event.isPre() + "] : event local address[" + event.getCache().getLocalAddress() + "]");
		}
		
		final List<Address> oldView = currentView;
		currentView = new ArrayList<Address>(event.getNewView().getMembers());
		final Address localAddress = getLocalAddress();
		
		
		if (oldView != null) {
			final Cache jbossCache = mobicentsCache.getJBossCache();
			final Configuration config = jbossCache.getConfiguration();		

			final boolean isBuddyReplicationEnabled = config.getBuddyReplicationConfig() != null && config.getBuddyReplicationConfig().isEnabled();
			
			Runnable runnable = new Runnable() {
				public void run() {
					for (Address oldMember : oldView) {
						if (!currentView.contains(oldMember)) {
							if (logger.isDebugEnabled()) {
								logger.debug("onViewChangeEvent : processing lost member " + oldMember);
							}
							for (FailOverListener localListener : failOverListeners) {
								ClientLocalListenerElector localListenerElector = localListener.getElector();
								if (localListenerElector != null && !isBuddyReplicationEnabled) {
									
									performTakeOver(localListener,oldMember,localAddress, true, isBuddyReplicationEnabled);
								}
								else {
									
									List<Address> electionView = getElectionView(oldMember);
									if(electionView!=null && elector.elect(electionView).equals(localAddress))
									{
										performTakeOver(localListener, oldMember, localAddress, false, isBuddyReplicationEnabled);
									}
									
									cleanAfterTakeOver(localListener, oldMember);
								}
							}
						}
					}
				}
			};
			Thread t = new Thread(runnable);
			t.start();
		}
		
	}
	

    @BuddyGroupChanged
    public void onBuddyGroupChangedEvent(BuddyGroupChangedEvent event) {
        Node root = event.getCache().getRoot();
        root.put(BUDDIES_STORE, event.getBuddyGroup().getBuddies());
    }

    @SuppressWarnings("unchecked")
    private void performTakeOver(FailOverListener localListener, Address lostMember, Address localAddress, boolean useLocalListenerElector, boolean isBuddyReplicationEnabled) {
        if (logger.isDebugEnabled()) {
            logger.debug("onViewChangeEvent : " + localAddress + " failing over lost member " + lostMember + ", useLocalListenerElector=" + useLocalListenerElector + ", isBuddyReplicationEnabled=" + isBuddyReplicationEnabled);
        }
        final Cache jbossCache = mobicentsCache.getJBossCache();
        final Fqn rootFqnOfChanges = localListener.getBaseFqn().getFqn();

        boolean createdTx = false;
        boolean doRollback = true;

        try {
            if (txMgr != null && txMgr.getTransaction() == null) {
                txMgr.begin();
                createdTx = true;
            }

            if (isBuddyReplicationEnabled) {
                String fqn = getBuddyBackupFqn(lostMember) + localListener.getBaseFqn().getFqn();

                Node buddyGroupRootNode = jbossCache.getNode(Fqn.fromString(fqn));
                if (buddyGroupRootNode != null) {
                    Set<Node> children = buddyGroupRootNode.getChildren();
                    if (logger.isDebugEnabled()) {
                        logger.debug("Fqn : " + fqn + " : children " + children);
                    }

                    for (Node child : children) {
                        Fqn childFqn = Fqn.fromRelativeElements(localListener.getBaseFqn().getFqn(), child.getFqn().getLastElement());
                        if (logger.isDebugEnabled()) {
                            logger.debug("forcing data gravitation on following child fqn " + childFqn);
                        }
                        jbossCache.getInvocationContext().getOptionOverrides().setForceDataGravitation(true);
                        Node n = jbossCache.getNode(childFqn);
                    }
                } else {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Fqn : " + fqn + " : doesn't return any node, this node  " + localAddress
                                + "might not be a buddy group of the failed node " + lostMember);
                    }
                }
            }
            if (createdTx) {
                txMgr.commit();
                createdTx = false;
            }

            if (txMgr != null && txMgr.getTransaction() == null) {
                txMgr.begin();
                createdTx = true;
            }

            localListener.failOverClusterMember(lostMember);
            Set<Object> children = jbossCache.getChildrenNames(rootFqnOfChanges);
            for (Object childName : children) {
                final ClusteredCacheData clusteredCacheData = new ClusteredCacheData(FqnWrapper.fromRelativeElementsWrapper(new FqnWrapper(rootFqnOfChanges), childName), this);
                if (clusteredCacheData.exists()) {
                    Address address = clusteredCacheData.getClusterNodeAddress();
                    if (address != null && address.equals(lostMember)) {
                        if (!isBuddyReplicationEnabled && useLocalListenerElector) {
                            if (!localAddress.equals(localListener.getElector().elect(currentView, clusteredCacheData))) {
                                continue;
                            }
                        }
                        localListener.wonOwnership(clusteredCacheData);
                        clusteredCacheData.setClusterNodeAddress(localAddress);
                    }
                } else {
                    if (logger.isDebugEnabled()) {
                        logger.debug(" Attempt to index: " + Fqn.fromRelativeElements(rootFqnOfChanges, childName) + " failed, node does not exist.");
                    }
                }
            }
            doRollback = false;

        } catch (Exception e) {
            logger.error(e.getMessage(), e);

        } finally {
            if (createdTx) {
                try {
                    if (!doRollback) {
                        txMgr.commit();
                    } else {
                        txMgr.rollback();
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
    }

    @NodeRemoved
    public void onNodeRemovedEvent(NodeRemovedEvent event) {
        if (!event.isOriginLocal() && !event.isPre()) {
            final DataRemovalListener dataRemovalListener = dataRemovalListeners.get(event.getFqn().getParent());
            if (dataRemovalListener != null) {
                dataRemovalListener.dataRemoved(new FqnWrapper(event.getFqn()));
            }
        }
    }

    private List<Address> getElectionView(Address deadMember) {
        final Cache jbossCache = mobicentsCache.getJBossCache();
        final Configuration config = jbossCache.getConfiguration();
        final boolean isBuddyReplicationEnabled = config.getBuddyReplicationConfig() != null
                && config.getBuddyReplicationConfig().isEnabled();

        if (isBuddyReplicationEnabled) {
            boolean createdTx = false;
            boolean doRollback = true;

            try {
                if (txMgr != null && txMgr.getTransaction() == null) {
                    txMgr.begin();
                    createdTx = true;
                }
                String fqnBackupRoot = getBuddyBackupFqn(deadMember);
                Node backupRoot = jbossCache.getNode(fqnBackupRoot);
                if (backupRoot != null) {
                    @SuppressWarnings("unchecked")
                    List<Address> buddies = (List<Address>) backupRoot.get(BUDDIES_STORE);
                    if (buddies == null) {
                        buddies = new ArrayList<Address>();
                        buddies.add(config.getRuntimeConfig().getChannel().getLocalAddress());
                    }
                    return buddies;
                } else {
                    return null;
                }

            } catch (Exception e) {
                logger.error(e.getMessage(), e);

            } finally {
                if (createdTx) {
                    try {
                        if (!doRollback) {
                            txMgr.commit();
                        } else {
                            txMgr.rollback();
                        }
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                }
            }
            return null;
        } else {
            return currentView;
        }
    }

    private String getBuddyBackupFqn(Address owner) {
        String lostMemberFqnizied = owner.toString().replace(":", "_");
        String fqn = BUDDY_BACKUP_FQN_ROOT + lostMemberFqnizied;
        return fqn;
    }

    private void cleanAfterTakeOver(FailOverListener localListener, Address deadMember) {
        final Cache jbossCache = mobicentsCache.getJBossCache();
        final Configuration config = jbossCache.getConfiguration();
        final boolean isBuddyReplicationEnabled = config.getBuddyReplicationConfig() != null && config.getBuddyReplicationConfig().isEnabled();
        if (isBuddyReplicationEnabled) {
            String fqn = getBuddyBackupFqn(deadMember) + localListener.getBaseFqn().getFqn();
            jbossCache.getInvocationContext().getOptionOverrides().setCacheModeLocal(true);
            jbossCache.removeNode(Fqn.fromString(fqn));
            BuddyGroup bg = config.getRuntimeConfig().getBuddyGroup();
            if (bg != null) {
                bg.getBuddies().remove(deadMember);
            }
        }
    }

    public boolean addFailOverListener(FailOverListener localListener) {
        return failOverListeners.add(localListener);
    }

    public boolean removeFailOverListener(FailOverListener localListener) {
        return failOverListeners.remove(localListener);
    }

    public boolean addDataRemovalListener(DataRemovalListener listener) {
        dataRemovalListeners.put(listener.getBaseFqn().getFqn(), listener);
        return true;
    }

    public boolean removeDataRemovalListener(DataRemovalListener listener) {
        return dataRemovalListeners.remove(listener.getBaseFqn().getFqn()) != null;
    }

    public MobicentsCache getMobicentsCache() {
        return mobicentsCache;
    }

    public ClusteredCacheDataIndexingHandler getClusteredCacheDataIndexingHandler() {
        return clusteredCacheDataIndexingHandler;
    }

    public void startCluster() {
    }

    public boolean isStarted() {
        return true;
    }

    public void stopCluster() {
    }
}

















class Address implements Comparable<Address> {

    private final String name;

    Address(final String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(final Object o) {
        return o instanceof Address && ((Address) o).name.equals(name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    public int compareTo(final Address o) {
        return name.compareTo(o.name);
    }
}


class View {

    private final List<Address> members;

    View(final List<Address> members) {
        this.members = members;
    }

    public List<Address> getMembers() {
        return members;
    }
}


final class Fqn {

    public static final String SEPARATOR = "/";

    private final List<Object> elements;

    private Fqn(final List<Object> elements) {
        this.elements = elements;
    }

    public static Fqn fromElements(final Object... elements) {
        return new Fqn(new ArrayList<Object>(Arrays.asList(elements)));
    }

    public static Fqn fromString(final String stringRepresentation) {
        final List<Object> parts = new ArrayList<Object>();
        for (final String p : stringRepresentation.split(SEPARATOR)) {
            if (!p.isEmpty()) {
                parts.add(p);
            }
        }
        return new Fqn(parts);
    }

    public static Fqn fromRelativeElements(final Fqn base, final Object... relativeElements) {
        final List<Object> combined = new ArrayList<Object>(base.elements);
        combined.addAll(Arrays.asList(relativeElements));
        return new Fqn(combined);
    }

    public Object getLastElement() {
        return elements.isEmpty() ? null : elements.get(elements.size() - 1);
    }

    public Fqn getParent() {
        return elements.isEmpty() ? this : new Fqn(elements.subList(0, elements.size() - 1));
    }

    public boolean isRoot() {
        return elements.isEmpty();
    }

    List<Object> getElements() {
        return elements;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        for (final Object e : elements) {
            sb.append(SEPARATOR).append(e);
        }
        return sb.length() == 0 ? SEPARATOR : sb.toString();
    }

    @Override
    public boolean equals(final Object o) {
        return o instanceof Fqn && ((Fqn) o).elements.equals(elements);
    }

    @Override
    public int hashCode() {
        return elements.hashCode();
    }
}


final class Node {

    private final Fqn fqn;
    private final Node parent;
    private final Map<Object, Node> children = new LinkedHashMap<Object, Node>();
    private final Map<Object, Object> data = new LinkedHashMap<Object, Object>();

    Node(final Fqn fqn, final Node parent) {
        this.fqn = fqn;
        this.parent = parent;
    }

    public Fqn getFqn() {
        return fqn;
    }

    public Node getParent() {
        return parent;
    }

    public Object put(final Object key, final Object value) {
        return data.put(key, value);
    }

    public Object get(final Object key) {
        return data.get(key);
    }

    public Object remove(final Object key) {
        return data.remove(key);
    }

    public Map<String, Object> getData() {
        final Map<String, Object> out = new LinkedHashMap<String, Object>();
        for (final Map.Entry<Object, Object> e : data.entrySet()) {
            out.put(String.valueOf(e.getKey()), e.getValue());
        }
        return out;
    }

    public Set<Node> getChildren() {
        return new LinkedHashSet<Node>(children.values());
    }

    public Node addChild(final Fqn childFqn) {
        Node cursor = root();
        Node current = this;
        for (final Object element : relativeElements(childFqn)) {
            Node next = current.children.get(element);
            if (next == null) {
                next = new Node(Fqn.fromRelativeElements(current.fqn, element), current);
                current.children.put(element, next);
            }
            current = next;
        }
        return current;
    }

    public Node getChild(final Fqn childFqn) {
        Node current = this;
        for (final Object element : relativeElements(childFqn)) {
            current = current.children.get(element);
            if (current == null) {
                return null;
            }
        }
        return current;
    }

    public Node getChild(final String name) {
        return children.get(name);
    }

    public boolean removeChild(final Object name) {
        return children.remove(name) != null;
    }

    private Node root() {
        Node n = this;
        while (n.parent != null) {
            n = n.parent;
        }
        return n;
    }

    
    private List<Object> relativeElements(final Fqn childFqn) {
        final List<Object> all = childFqn.getElements();
        final int ownDepth = fqn.getElements().size();
        return all.size() > ownDepth ? all.subList(ownDepth, all.size()) : new ArrayList<Object>();
    }

    @Override
    public String toString() {
        return "Node" + fqn;
    }
}


enum CacheMode {
    LOCAL, REPL_SYNC, REPL_ASYNC, INVALIDATION_SYNC, INVALIDATION_ASYNC
}


class BuddyGroup {

    private final List<Address> buddies = new ArrayList<Address>();

    public List<Address> getBuddies() {
        return buddies;
    }

    void addBuddy(final Address address) {
        buddies.add(address);
    }
}


class BuddyReplicationConfig {

    private final boolean enabled;

    BuddyReplicationConfig(final boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }
}


class RuntimeConfig {

    private final BuddyGroup buddyGroup = new BuddyGroup();
    private final Address channelLocalAddress;

    RuntimeConfig(final Address channelLocalAddress) {
        this.channelLocalAddress = channelLocalAddress;
    }

    public BuddyGroup getBuddyGroup() {
        return buddyGroup;
    }

    public Channel getChannel() {
        return new Channel(channelLocalAddress);
    }
}


class Channel {

    private final Address localAddress;

    Channel(final Address localAddress) {
        this.localAddress = localAddress;
    }

    public Address getLocalAddress() {
        return localAddress;
    }
}


class Configuration {

    private final CacheMode cacheMode;
    private final BuddyReplicationConfig buddyReplicationConfig;
    private final RuntimeConfig runtimeConfig;

    Configuration(final CacheMode cacheMode, final BuddyReplicationConfig buddyReplicationConfig,
            final Address localAddress) {
        this.cacheMode = cacheMode;
        this.buddyReplicationConfig = buddyReplicationConfig;
        this.runtimeConfig = new RuntimeConfig(localAddress);
    }

    public CacheMode getCacheMode() {
        return cacheMode;
    }

    public BuddyReplicationConfig getBuddyReplicationConfig() {
        return buddyReplicationConfig;
    }

    public RuntimeConfig getRuntimeConfig() {
        return runtimeConfig;
    }
}


class OptionOverrides {

    private boolean forceDataGravitation;
    private boolean cacheModeLocal;

    public void setForceDataGravitation(final boolean value) {
        this.forceDataGravitation = value;
    }

    public boolean isForceDataGravitation() {
        return forceDataGravitation;
    }

    public void setCacheModeLocal(final boolean value) {
        this.cacheModeLocal = value;
    }

    public boolean isCacheModeLocal() {
        return cacheModeLocal;
    }
}


class InvocationContext {

    private final OptionOverrides optionOverrides = new OptionOverrides();

    public OptionOverrides getOptionOverrides() {
        return optionOverrides;
    }
}









class Cache {

    private final Configuration configuration;
    private final Node root = new Node(Fqn.fromElements(), null);
    private final InvocationContext invocationContext = new InvocationContext();
    private final List<Object> listeners = new ArrayList<Object>();
    private final Address localAddress;

    Cache(final Configuration configuration, final Address localAddress) {
        this.configuration = configuration;
        this.localAddress = localAddress;
    }

    public void create() {
    }

    public Address getLocalAddress() {
        return localAddress;
    }

    public Configuration getConfiguration() {
        return configuration;
    }

    public Node getRoot() {
        return root;
    }

    public Node getNode(final Fqn fqn) {
        return root.getChild(fqn);
    }

    public Node getNode(final String stringFqn) {
        return getNode(Fqn.fromString(stringFqn));
    }

    public Set<Object> getChildrenNames(final Fqn fqn) {
        final Node node = getNode(fqn);
        final Set<Object> names = new LinkedHashSet<Object>();
        if (node != null) {
            for (final Node child : node.getChildren()) {
                names.add(child.getFqn().getLastElement());
            }
        }
        return names;
    }

    public boolean removeNode(final Fqn fqn) {
        final Node node = getNode(fqn);
        if (node == null) {
            return false;
        }
        return node.getParent() != null && node.getParent().removeChild(fqn.getLastElement());
    }

    public InvocationContext getInvocationContext() {
        return invocationContext;
    }

    public void addCacheListener(final Object listener) {
        listeners.add(listener);
    }

    
    void fireViewChanged(final ViewChangedEvent event) {
        deliver(ViewChanged.class, event);
    }

    void fireBuddyGroupChanged(final BuddyGroupChangedEvent event) {
        deliver(BuddyGroupChanged.class, event);
    }

    void fireNodeRemoved(final NodeRemovedEvent event) {
        deliver(NodeRemoved.class, event);
    }

    private void deliver(final Class<? extends java.lang.annotation.Annotation> annotationType, final Object event) {
        for (final Object listener : listeners) {
            for (final java.lang.reflect.Method m : listener.getClass().getMethods()) {
                if (m.isAnnotationPresent(annotationType)) {
                    try {
                        m.invoke(listener, event);
                    } catch (final Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
    }
}






@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@interface CacheListener {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@interface ViewChanged {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@interface BuddyGroupChanged {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@interface NodeRemoved {
}

class ViewChangedEvent {

    private final boolean pre;
    private final Cache cache;
    private final View newView;

    ViewChangedEvent(final boolean pre, final Cache cache, final View newView) {
        this.pre = pre;
        this.cache = cache;
        this.newView = newView;
    }

    public boolean isPre() {
        return pre;
    }

    public Cache getCache() {
        return cache;
    }

    public View getNewView() {
        return newView;
    }
}

class BuddyGroupChangedEvent {

    private final Cache cache;
    private final BuddyGroup buddyGroup;

    BuddyGroupChangedEvent(final Cache cache, final BuddyGroup buddyGroup) {
        this.cache = cache;
        this.buddyGroup = buddyGroup;
    }

    public Cache getCache() {
        return cache;
    }

    public BuddyGroup getBuddyGroup() {
        return buddyGroup;
    }
}

class NodeRemovedEvent {

    private final Fqn fqn;
    private final boolean pre;
    private final boolean originLocal;

    NodeRemovedEvent(final Fqn fqn, final boolean pre, final boolean originLocal) {
        this.fqn = fqn;
        this.pre = pre;
        this.originLocal = originLocal;
    }

    public Fqn getFqn() {
        return fqn;
    }

    public boolean isPre() {
        return pre;
    }

    public boolean isOriginLocal() {
        return originLocal;
    }
}





final class Logger {

    private final String name;

    private Logger(final String name) {
        this.name = name;
    }

    public static Logger getLogger(final Class<?> clazz) {
        return new Logger(clazz.getSimpleName());
    }

    public boolean isDebugEnabled() {
        return true;
    }

    public boolean isTraceEnabled() {
        return false;
    }

    public void debug(final String msg) {
        System.out.println("        [DEBUG] " + name + " - " + msg);
    }

    public void trace(final String msg) {
        System.out.println("        [TRACE] " + name + " - " + msg);
    }

    public void error(final String msg, final Throwable t) {
        System.out.println("        [ERROR] " + name + " - " + msg
                + (t == null ? "" : " (" + t.getClass().getSimpleName() + ": " + t.getMessage() + ")"));
    }
}








class Transaction {

    boolean active = true;
}

class TransactionManager {

    private final ThreadLocal<Transaction> current = new ThreadLocal<Transaction>();

    public Transaction getTransaction() {
        return current.get();
    }

    public void begin() {
        current.set(new Transaction());
    }

    public void commit() {
        final Transaction tx = current.get();
        if (tx != null) {
            System.out.println("        [tx] commit");
        }
        current.remove();
    }

    public void rollback() {
        final Transaction tx = current.get();
        if (tx != null) {
            System.out.println("        [tx] rollback");
        }
        current.remove();
    }
}















interface FailOverListener {

	



	@SuppressWarnings("unchecked")
	public FqnWrapper getBaseFqn();
	
	





	public ClientLocalListenerElector getElector();
	
	



	public byte getPriority();

	



	public void failOverClusterMember(Address address);
	
	



	public void wonOwnership(ClusteredCacheData clusteredCacheData);

	



	public void lostOwnership(ClusteredCacheData clusteredCacheData);
}








class FailOverListenerPriorityComparator implements Comparator<FailOverListener> {

	


	public int compare(FailOverListener o1, FailOverListener o2) {
		if (o1.equals(o2)) {
			return 0;
		}
		else {
			if (o1.getPriority() > o2.getPriority()) {
				return -1;
			}
			else {
				return 1;
			}
		}
	}

}









interface DataRemovalListener {

	



	@SuppressWarnings("unchecked")
	public FqnWrapper getBaseFqn();
	
	



	@SuppressWarnings("unchecked")
	public void dataRemoved(FqnWrapper clusteredCacheDataFqnWrapper);
}











interface ClusterElector {

	
	public Address elect(List<Address> list);
	
	
}




interface ClientLocalListenerElector {

	





	public Address elect(List<Address> nodes, ClusteredCacheData cacheData);
}










interface ClusteredCacheDataIndexingHandler {

	



	public void setClusterNodeAddress(ClusteredCacheData cacheData, Address clusterNodeAddress);
	
	




	public Address getClusterNodeAddress(ClusteredCacheData cacheData);
	
}











class DefaultClusteredCacheDataIndexingHandler implements ClusteredCacheDataIndexingHandler {
	
	


	private static final String CLUSTER_NODE_ADDRESS_NODE_KEY = "cnaddress";
	
	



	@SuppressWarnings("unchecked")
	public void setClusterNodeAddress(ClusteredCacheData cacheData, Address clusterNodeAddress) {
		cacheData.getNode().put(CLUSTER_NODE_ADDRESS_NODE_KEY,clusterNodeAddress);
	}
	
	



	@SuppressWarnings("unchecked")
	public Address getClusterNodeAddress(ClusteredCacheData cacheData) {
		return (Address) cacheData.getNode().get(CLUSTER_NODE_ADDRESS_NODE_KEY);
	}
}











class ClusteredCacheData extends CacheData {
	
	private final ClusteredCacheDataIndexingHandler indexingHandler;
	
	



	public ClusteredCacheData(FqnWrapper nodeFqnWrapper, MobicentsCluster mobicentsCluster) {
		
		super(nodeFqnWrapper, mobicentsCluster.getMobicentsCache());
		indexingHandler = mobicentsCluster.getClusteredCacheDataIndexingHandler();
	}

	


	@Override
	public boolean create() {
		if (super.create()) {
			
			if (!getMobicentsCache().isLocalMode()) {
				setClusterNodeAddress(getMobicentsCache().getJBossCache().getLocalAddress());
			}
			return true;
		}
		else {
			return false;
		}
	}
	
	



	public void setClusterNodeAddress(Address clusterNodeAddress) {
		indexingHandler.setClusterNodeAddress(this,clusterNodeAddress);
	}
	
	




	public Address getClusterNodeAddress() {
		return indexingHandler.getClusterNodeAddress(this);
	}
	
	


	@Override
	protected Node getNode() {
		return super.getNode();
	}
}




class FqnWrapper {

    private Fqn fqn;

    public FqnWrapper(Fqn fqn) {
        this.fqn = fqn;
    }

    public Fqn getFqn() {
        return this.fqn;
    }

    public Object getLastElement() {
        return this.fqn.getLastElement();
    }

    public static FqnWrapper fromStringWrapper(String stringRepresentation) {
        return new FqnWrapper(Fqn.fromString(stringRepresentation));
    }

    public static FqnWrapper fromRelativeElementsWrapper(FqnWrapper base, Object... relativeElements) {
        return new FqnWrapper(Fqn.fromRelativeElements(base.getFqn(), relativeElements));
    }

    public static FqnWrapper fromElementsWrapper(Object... elements) {
        return new FqnWrapper(Fqn.fromElements(elements));
    }

}









class CacheData {

	private static final Logger logger = Logger.getLogger(CacheData.class);
	
	@SuppressWarnings("unchecked")
	private Node node;
	@SuppressWarnings("unchecked")
	private final Fqn nodeFqn;
	
	private boolean isRemoved;
	private final MobicentsCache mobicentsCache;
	
	private final static boolean doTraceLogs = logger.isTraceEnabled();  

	











	@SuppressWarnings("unchecked")
	public CacheData(FqnWrapper nodeFqnWrapper, MobicentsCache mobicentsCache) {
		this.nodeFqn = nodeFqnWrapper.getFqn();
		this.mobicentsCache = mobicentsCache;
		this.node = mobicentsCache.getJBossCache().getRoot().getChild(nodeFqn);
		if (doTraceLogs) {
			logger.trace("cache node "+nodeFqn+" retrieved, result = "+this.node);
		}
	}
	
	



	public boolean exists() {
		return node != null;
	}

	


	public boolean create() {
		if (!exists()) {
			node = mobicentsCache.getJBossCache().getRoot().addChild(nodeFqn);
			if (doTraceLogs) {
				logger.trace("created cache node "+nodeFqn);
			}
			return true;
		}
		else {
			return false;
		}
	}
	
	



	public boolean isRemoved() {
		return isRemoved;
	}
	
	


	public boolean remove() {
		if (exists() && !isRemoved()) {
			isRemoved = true;
			node.getParent().removeChild(nodeFqn.getLastElement());
			if (doTraceLogs) {
				logger.trace("removed cache node "+nodeFqn);
			}	
			return true;
		}
		else {
			return false;
		}
	}
	
	





	@SuppressWarnings("unchecked")
	protected Node getNode() {
		if (isRemoved()) {
			throw new IllegalStateException();
		}
		return node;
	}
	
	



	public MobicentsCache getMobicentsCache() {
		return mobicentsCache;
	}
	
	



	@SuppressWarnings("unchecked")
	public Fqn getNodeFqn() {
		return nodeFqn;
	}

	public FqnWrapper getNodeFqnWrapper() {
		return new FqnWrapper(nodeFqn);
	}

	public Object getNodeFqnLastElement() {
		return nodeFqn.getLastElement();
	}

	public Object putNodeValue(Object key, Object value) {
		return getNode().put(key, value);
	}

	public Object getNodeValue(Object key) {
		return getNode().get(key);
	}

	public Object removeNodeValue(Object key) {
		return getNode().remove(key);
	}

	public Object addChildNode(FqnWrapper fqnWrapper) {
		final Node childNode = getNode().addChild(fqnWrapper.getFqn());
		return (Object) childNode;
	}

	public Object putChildNodeValue(FqnWrapper fqnWrapper, Object key, Object value) {
		final Node childNode = getNode().getChild(fqnWrapper.getFqn());
		if (childNode != null) {
			return childNode.put(key, value);
		}
		return null;
	}

	public Object getChildNode(String child) {
		final Node childNode = getNode().getChild(child);
		return (Object) childNode;
	}

	public Map<String, Object> getChildNodeData(String child) {
		final Node childNode = getNode().getChild(child);
		return childNode.getData();
	}

	public Object getChildNodeValue(String child, Object key) {
		final Node childNode = getNode().getChild(child);
		return childNode.get(key);
	}

	public boolean removeChildNode(String child) {
		return getNode().removeChild(child);
	}

}









interface MobicentsCluster {

	



	public boolean addFailOverListener(FailOverListener listener);
	
	




	public boolean removeFailOverListener(FailOverListener listener);
	
	



	public boolean addDataRemovalListener(DataRemovalListener listener);
	
	




	public boolean removeDataRemovalListener(DataRemovalListener listener);
	
	



	public Address getLocalAddress();
	
	



	public List<Address> getClusterMembers();
	
	



	public boolean isHeadMember();
	
	









	public boolean isSingleMember();
	
	



	public MobicentsCache getMobicentsCache();
	
	



	public ClusteredCacheDataIndexingHandler getClusteredCacheDataIndexingHandler();

	




	public void startCluster();
	
	



	public boolean isStarted();
	
	


	public void stopCluster();
	
}










class MobicentsCache {

    private final Cache jBossCache;
    private boolean localMode;

    public MobicentsCache(final Cache cache) {
        this.jBossCache = cache;
        setLocalMode();
    }

    private void setLocalMode() {
        localMode = jBossCache.getConfiguration().getCacheMode() == CacheMode.LOCAL;
    }

    public Cache getJBossCache() {
        return jBossCache;
    }

    public boolean isLocalMode() {
        return localMode;
    }
}

