








































import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class method_3_restcluster_claude {

    static final class DemoTask extends TimerTask {

        DemoTask(final TimerTaskData data) {
            super(data);
        }

        public void runTask() {
            System.out.println("        [task " + getData().getTaskID() + "] fired");
        }
    }

    public static void main(final String[] args) throws Exception {
        title("METHOD 3  |  FaultTolerantScheduler.cancel(Serializable taskID)");

        section("1. cancel a locally running, still-pending periodic task - no transaction manager");
        final FaultTolerantScheduler scheduler1 = newScheduler(null);
        final TimerTaskData data1 = new TimerTaskData("task-1", System.currentTimeMillis() + 5000, 1000, PeriodicScheduleStrategy.atFixedRate);
        final TimerTask task1 = new DemoTask(data1);
        scheduler1.schedule(task1);
        System.out.println("      scheduled, locally running : " + scheduler1.getLocalRunningTasksMap().containsKey("task-1"));
        final TimerTask returned1 = scheduler1.cancel("task-1");
        System.out.println("      cancel() returned the same task instance : " + (returned1 == task1));
        System.out.println("      locally running after cancel : " + scheduler1.getLocalRunningTasksMap().containsKey("task-1"));
        System.out.println("      scheduledFuture cancelled : " + task1.getScheduledFuture().isCancelled());
        scheduler1.getExecutor().shutdownNow();

        section("2. cancel a task whose SET action is still pending in the same transaction");
        final FaultTolerantScheduler scheduler2 = newScheduler(new TransactionManager());
        final TransactionManager tx2 = schedulerTxManager(scheduler2);
        final TimerTaskData data2 = new TimerTaskData("task-2", System.currentTimeMillis() + 5000, -1, PeriodicScheduleStrategy.atFixedRate);
        final TimerTask task2 = new DemoTask(data2);
        tx2.begin();
        scheduler2.schedule(task2);
        System.out.println("      before commit, getSetTimerTransactionalAction() != null : "
                + (task2.getSetTimerTransactionalAction() != null));
        final TimerTask returned2 = scheduler2.cancel("task-2");
        System.out.println("      cancel() found the pending SET action and cancelled it directly (setAction.cancel())");
        tx2.commit();
        System.out.println("      after commit, the SET runnable ran but canceled==true, so nothing was scheduled");
        Thread.sleep(200);

        section("3. cancel a task that IS locally running, using the tx-registered CancelTimerAfterTxCommitRunnable path");
        final FaultTolerantScheduler scheduler3 = newScheduler(new TransactionManager());
        final TransactionManager tx3 = schedulerTxManager(scheduler3);
        final TimerTaskData data3 = new TimerTaskData("task-3", System.currentTimeMillis() + 5000, 1000, PeriodicScheduleStrategy.atFixedRate);
        final TimerTask task3 = new DemoTask(data3);
        scheduler3.schedule(task3);
        System.out.println("      scheduled outside any transaction, locally running : "
                + scheduler3.getLocalRunningTasksMap().containsKey("task-3"));
        tx3.begin();
        scheduler3.cancel("task-3");
        System.out.println("      cancel() ran inside an open transaction; localRunningTasks still holds it until commit : "
                + scheduler3.getLocalRunningTasksMap().containsKey("task-3"));
        tx3.commit();
        System.out.println("      after commit, locally running : " + scheduler3.getLocalRunningTasksMap().containsKey("task-3"));
        scheduler3.getExecutor().shutdownNow();

        section("4. cancel a task id that is not locally running and has no transaction manager - task == null branch");
        final FaultTolerantScheduler scheduler4 = newScheduler(null);
        final TimerTask returned4 = scheduler4.cancel("does-not-exist");
        System.out.println("      cancel() returned : " + returned4);

        section("5. cancel a task id that is not locally running, but has a pending SET action in the current tx");
        final FaultTolerantScheduler scheduler5 = newScheduler(new TransactionManager());
        final TransactionManager tx5 = schedulerTxManager(scheduler5);
        final TimerTaskData data5 = new TimerTaskData("task-5", System.currentTimeMillis() + 5000, -1, PeriodicScheduleStrategy.atFixedRate);
        final TimerTask task5 = new DemoTask(data5);
        tx5.begin();
        scheduler5.schedule(task5);
        
        
        final TimerTask returned5 = scheduler5.cancel("task-5");
        System.out.println("      cancel() recovered the task through the transaction context (r.task) : "
                + (returned5 == task5));
        tx5.rollback();

        section("6. branch coverage summary");
        System.out.println("      task != null, setAction != null            -> scenario 2");
        System.out.println("      task != null, setAction == null, txManager == null -> scenario 1");
        System.out.println("      task != null, setAction == null, txManager != null, tx != null -> scenario 3");
        System.out.println("      task == null, txManager == null              -> scenario 4");
        System.out.println("      task == null, txManager != null, tx context has a pending SET action -> scenario 5");

        title("END OF METHOD 3 SCENARIOS");
    }

    static FaultTolerantScheduler newScheduler(final TransactionManager txManager) {
        final Address self = new Address("node-A:7800");
        final Configuration config = new Configuration(CacheMode.LOCAL, new BuddyReplicationConfig(false), self);
        final Cache cache = new Cache(config, self);
        final MobicentsCache mobicentsCache = new MobicentsCache(cache);
        final DummyCluster cluster = new DummyCluster(mobicentsCache);
        return new FaultTolerantScheduler("demo-scheduler", 4, cluster, (byte) 5, txManager, new TimerTaskFactory() {
            public TimerTask newTimerTask(final TimerTaskData data) {
                return new DemoTask(data);
            }
        });
    }

    static TransactionManager schedulerTxManager(final FaultTolerantScheduler scheduler) throws Exception {
        final java.lang.reflect.Field f = FaultTolerantScheduler.class.getDeclaredField("txManager");
        f.setAccessible(true);
        return (TransactionManager) f.get(scheduler);
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}


class DummyCluster implements MobicentsCluster {

    private final MobicentsCache cache;
    private final ClusteredCacheDataIndexingHandler indexingHandler = new DefaultClusteredCacheDataIndexingHandler();

    DummyCluster(final MobicentsCache cache) {
        this.cache = cache;
    }

    public boolean addFailOverListener(final FailOverListener listener) {
        return true;
    }

    public boolean removeFailOverListener(final FailOverListener listener) {
        return true;
    }

    public boolean addDataRemovalListener(final DataRemovalListener listener) {
        return true;
    }

    public boolean removeDataRemovalListener(final DataRemovalListener listener) {
        return true;
    }

    public Address getLocalAddress() {
        return cache.getJBossCache().getLocalAddress();
    }

    public List<Address> getClusterMembers() {
        final List<Address> list = new ArrayList<Address>();
        list.add(getLocalAddress());
        return list;
    }

    public boolean isHeadMember() {
        return true;
    }

    public boolean isSingleMember() {
        return true;
    }

    public MobicentsCache getMobicentsCache() {
        return cache;
    }

    public ClusteredCacheDataIndexingHandler getClusteredCacheDataIndexingHandler() {
        return indexingHandler;
    }

    public void startCluster() {
    }

    public boolean isStarted() {
        return true;
    }

    public void stopCluster() {
    }
}






















class FaultTolerantScheduler {

    private static final Logger logger = Logger.getLogger(FaultTolerantScheduler.class);

    private final java.util.concurrent.ScheduledThreadPoolExecutor executor;

    private final TransactionManager txManager;

    private final java.util.concurrent.ConcurrentHashMap<java.io.Serializable, TimerTask> localRunningTasks =
            new java.util.concurrent.ConcurrentHashMap<java.io.Serializable, TimerTask>();

    private TimerTaskFactory timerTaskFactory;

    private final Fqn baseFqn;

    private final String name;

    private final MobicentsCluster cluster;

    public FaultTolerantScheduler(String name, int corePoolSize, MobicentsCluster cluster, byte priority,
            TransactionManager txManager, TimerTaskFactory timerTaskFactory) {
        this.name = name;
        this.executor = new java.util.concurrent.ScheduledThreadPoolExecutor(corePoolSize,
                java.util.concurrent.Executors.defaultThreadFactory());
        this.baseFqn = Fqn.fromElements(name);
        this.cluster = cluster;
        this.timerTaskFactory = timerTaskFactory;
        this.txManager = txManager;
    }

    public TimerTaskData getTimerTaskData(java.io.Serializable taskID) {
        TimerTaskCacheData timerTaskCacheData = new TimerTaskCacheData(taskID, baseFqn, cluster);
        if (timerTaskCacheData.exists()) {
            return timerTaskCacheData.getTaskData();
        } else {
            return null;
        }
    }

    java.util.concurrent.ScheduledThreadPoolExecutor getExecutor() {
        return executor;
    }

    java.util.concurrent.ConcurrentHashMap<java.io.Serializable, TimerTask> getLocalRunningTasksMap() {
        return localRunningTasks;
    }

    public Set<TimerTask> getLocalRunningTasks() {
        return new java.util.HashSet<TimerTask>(localRunningTasks.values());
    }

    public TimerTask getLocalRunningTask(java.io.Serializable taskId) {
        return localRunningTasks.get(taskId);
    }

    public TimerTaskFactory getTimerTaskFactory() {
        return timerTaskFactory;
    }

    public void schedule(TimerTask task) {
        schedule(task, true);
    }

    public void schedule(TimerTask task, boolean checkIfAlreadyPresent) {

        final TimerTaskData taskData = task.getData();
        final java.io.Serializable taskID = taskData.getTaskID();
        task.setScheduler(this);

        if (logger.isDebugEnabled()) {
            logger.debug("Scheduling task with id " + taskID);
        }

        final TimerTaskCacheData timerTaskCacheData = new TimerTaskCacheData(taskID, baseFqn, cluster);
        if (timerTaskCacheData.create()) {
            timerTaskCacheData.setTaskData(taskData);
        } else if (checkIfAlreadyPresent) {
            throw new IllegalStateException("timer task " + taskID + " already scheduled");
        }

        final SetTimerAfterTxCommitRunnable setTimerAction = new SetTimerAfterTxCommitRunnable(task, this);
        if (txManager != null) {
            try {
                Transaction tx = txManager.getTransaction();
                if (tx != null) {
                    TransactionContext txContext = TransactionContextThreadLocal.getTransactionContext();
                    if (txContext == null) {
                        txContext = new TransactionContext();
                        tx.registerSynchronization(new TransactionSynchronization(txContext));
                    }
                    txContext.put(taskID, setTimerAction);
                    task.setSetTimerTransactionalAction(setTimerAction);
                } else {
                    setTimerAction.run();
                }
            } catch (Throwable e) {
                remove(taskID, true);
                throw new RuntimeException("Unable to register tx synchronization object", e);
            }
        } else {
            setTimerAction.run();
        }
    }

	
    public TimerTask cancel(Serializable taskID) {

        if (logger.isDebugEnabled()) {
            logger.debug("Canceling task with timer id "+taskID);
        }

        TimerTask task = localRunningTasks.get(taskID);
        if (task != null) {
            
            new TimerTaskCacheData(taskID, baseFqn, cluster).remove();

            final SetTimerAfterTxCommitRunnable setAction = task.getSetTimerTransactionalAction();
            if (setAction != null) {
                
                setAction.cancel();
            }
            else {
                
                AfterTxCommitRunnable runnable = new CancelTimerAfterTxCommitRunnable(task,this);
                if (txManager != null) {
                    try {
                        Transaction tx = txManager.getTransaction();
                        if (tx != null) {
                            TransactionContext txContext = TransactionContextThreadLocal.getTransactionContext();
                            if (txContext == null) {
                                txContext = new TransactionContext();
                                tx.registerSynchronization(new TransactionSynchronization(txContext));
                            }
                            txContext.put(taskID, runnable);					
                        }
                        else {
                            runnable.run();
                        }
                    }
                    catch (Throwable e) {
                        throw new RuntimeException("Unable to register tx synchronization object",e);
                    }
                }
                else {
                    runnable.run();
                }			
            }		
        }
        else {
            
            
            if (txManager != null) {
                try {
                    Transaction tx = txManager.getTransaction();
                    if (tx != null) {
                        TransactionContext txContext = TransactionContextThreadLocal.getTransactionContext();
                        if (txContext != null) {
                            final AfterTxCommitRunnable r = txContext.remove(taskID);
                            if (r != null) {
                                task = r.task;
                                
                                new TimerTaskCacheData(taskID, baseFqn, cluster).remove();
                            }							
                        }											
                    }
                }
                catch (Throwable e) {
                    throw new RuntimeException("Failed to check tx context.",e);
                }
            }			
        }
        
        return task;
    }
	

    void remove(java.io.Serializable taskID, boolean removeFromCache) {
        if (logger.isDebugEnabled()) {
            logger.debug("remove() : " + taskID + " - " + removeFromCache);
        }

        localRunningTasks.remove(taskID);
        if (removeFromCache) {
            new TimerTaskCacheData(taskID, baseFqn, cluster).remove();
        }
    }
}
















class SetTimerAfterTxCommitRunnable extends AfterTxCommitRunnable {

	private static final Logger logger = Logger
			.getLogger(SetTimerAfterTxCommitRunnable.class);


	private boolean canceled = false;

	SetTimerAfterTxCommitRunnable(TimerTask task,
			FaultTolerantScheduler scheduler) {
		super(task,scheduler);
	}

	



	@Override
	public Type getType() {
		return AfterTxCommitRunnable.Type.SET;
	}
	
	



	public void run() {
		
		task.setSetTimerTransactionalAction(null);
		
		if (!canceled) {
			
			TimerTask previousTask = scheduler.getLocalRunningTasksMap().putIfAbsent(task.getData().getTaskID(), task);
			if(previousTask != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("A task with id " + task.getData().getTaskID() + " has already been added to the local tasks, not rescheduling");
				}
			}
			
			final TimerTaskData taskData = task.getData();
			
			long delay = taskData.getStartTime() - System.currentTimeMillis();
			if (delay < 0) {
				delay = 0;
			}
			
			try {
				
				if (taskData.getPeriod() < 0) {
					if (logger.isDebugEnabled()) {
						logger.debug("Scheduling one-shot timer with id "
								+ task.getData().getTaskID() + ", delay " + delay);
					}
					task.setScheduledFuture(scheduler.getExecutor().schedule(task, delay, TimeUnit.MILLISECONDS));
				} else {
					if (logger.isDebugEnabled()) {
						logger.debug("Scheduling periodic timer with id "
								+ task.getData().getTaskID() + ", scheduling strategy " + taskData.getPeriodicScheduleStrategy() + ", delay " + delay + ", period " + taskData.getPeriod());
					}
					if (taskData.getPeriodicScheduleStrategy() == PeriodicScheduleStrategy.withFixedDelay) {
						task.setScheduledFuture(scheduler.getExecutor().scheduleWithFixedDelay(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
					}
					else {
						
						task.setScheduledFuture(scheduler.getExecutor().scheduleAtFixedRate(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
					}					
				}		
			} catch (Throwable e) {
				logger.error(e.getMessage(), e);
				scheduler.remove(taskData.getTaskID(),true);
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("Canceled scheduling periodic timer with id "
						+ task.getData().getTaskID());
			}
		}
	}

	public void cancel() {
		if (logger.isDebugEnabled()) {
			logger.debug("Canceling set timer action for task with timer id "+task.getData().getTaskID());
		}
		canceled = true;
		scheduler.remove(task.getData().getTaskID(),true);
	}

}










abstract class AfterTxCommitRunnable implements Runnable {

	public enum Type { SET, CANCEL }
	
	protected final TimerTask task;
	protected final FaultTolerantScheduler scheduler;

	public AfterTxCommitRunnable(TimerTask task,
			FaultTolerantScheduler scheduler) {
		this.task = task;
		this.scheduler = scheduler;
	}

	public abstract Type getType();
	
}









class CancelTimerAfterTxCommitRunnable extends AfterTxCommitRunnable {

	private static final Logger logger = Logger.getLogger(CancelTimerAfterTxCommitRunnable.class);
	
	CancelTimerAfterTxCommitRunnable(TimerTask task,FaultTolerantScheduler scheduler) {
		super(task,scheduler);
	}

	



	public Type getType() {
		return AfterTxCommitRunnable.Type.CANCEL;
	}
	
	



	public void run() {
		
		final TimerTaskData taskData = task.getData();
		final Serializable taskID = taskData.getTaskID();
		
		if (logger.isDebugEnabled()) {
			logger.debug("Cancelling timer task for timer ID "+taskID);
		}
		
		scheduler.getLocalRunningTasksMap().remove(taskID);
		
		try {
			task.cancel();					
		}
		catch (Throwable e) {
			logger.error(e.getMessage(),e);
		}
	}
	
}









enum PeriodicScheduleStrategy {

	






	atFixedRate, 
	
	





	withFixedDelay
}










abstract class TimerTask implements Runnable {
	private static final Logger logger = Logger.getLogger(TimerTask.class);
	


	private final TimerTaskData data;
	
	


	private ScheduledFuture<?> scheduledFuture;
	
	


	private SetTimerAfterTxCommitRunnable action;
	
	


	private FaultTolerantScheduler scheduler;
	
	


	protected boolean autoRemoval = true;
	
	



	public TimerTask(TimerTaskData data) {
		this.data = data;
	}
	
	



	public TimerTaskData getData() {
		return data;
	}
	
	



	protected SetTimerAfterTxCommitRunnable getSetTimerTransactionalAction() {
		return action;
	}

	



	void setSetTimerTransactionalAction(
			SetTimerAfterTxCommitRunnable action) {
		this.action = action;
	}

	



	public ScheduledFuture<?> getScheduledFuture() {
		return scheduledFuture;
	}
	
	



	protected void setScheduledFuture(ScheduledFuture<?> scheduledFuture) {
		this.scheduledFuture = scheduledFuture;
		
		
		if (cancel) {
			this.scheduledFuture.cancel(false);
		}
	}

	private transient boolean cancel; 
	
	



	protected void cancel() {
		cancel = true;
		if (scheduledFuture != null) {
			scheduledFuture.cancel(false);
		}
	}
	
	public final void run() {		
		
		if(data.getPeriod() < 0 && autoRemoval) {
			if (logger.isDebugEnabled()) {
				logger.debug("Task with id "
						+ data.getTaskID() + " is not recurring, so removing it locally and in the cluster");
			}
			
			removeFromScheduler();
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("Task with id "
						+ data.getTaskID() + " is recurring, not removing it locally nor in the cluster");
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Firing Timer with id "
					+ data.getTaskID());
		}
		runTask();
	}
	
	


	protected void removeFromScheduler() {
		scheduler.remove(data.getTaskID(),true);
	}
	
	


	public abstract void runTask();
	
	


	public void beforeRecover() {
		if (data.getPeriod() > 0) {			
			final long now = System.currentTimeMillis();
			long startTime = data.getStartTime();
			while(startTime <= now) {
				startTime += data.getPeriod();
				data.setStartTime(startTime);				
			}			
			if (logger.isDebugEnabled()) {
				logger.debug("Task with id "
						+ data.getTaskID() + " start time reset to " + data.getStartTime());
			}
		}
	}

	


	public void setScheduler(FaultTolerantScheduler scheduler) {
		this.scheduler = scheduler;
	}

	


	public FaultTolerantScheduler getScheduler() {
		return scheduler;
	}
	
}











class TimerTaskData implements Serializable {

	


	private static final long serialVersionUID = 8905073681622353718L;

	


	private long startTime;
	
	


	private final long period;
	
	


	private final Serializable taskID;
	
	


	private final PeriodicScheduleStrategy periodicScheduleStrategy;
	
	





	public TimerTaskData(Serializable id, long startTime, long period, PeriodicScheduleStrategy periodicScheduleStrategy) {
		this.taskID = id;
		this.startTime = startTime;
		this.period = period;
		this.periodicScheduleStrategy = periodicScheduleStrategy;
	}
	
	



	public long getPeriod() {
		return period;
	}
	
	



	public long getStartTime() {
		return startTime;
	}
	
	



	public void setStartTime(long startTime) {
		this.startTime = startTime;		
	}
	
	



	public Serializable getTaskID() {
		return taskID;
	}
	
	



	public PeriodicScheduleStrategy getPeriodicScheduleStrategy() {
		return periodicScheduleStrategy;
	}
	
	@Override
	public int hashCode() {		
		return taskID.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj != null && obj.getClass() == this.getClass()) {
			return ((TimerTaskData)obj).taskID.equals(this.taskID);
		}
		else {
			return false;
		}
	}
}










interface TimerTaskFactory {
	
	





	public TimerTask newTimerTask(TimerTaskData data);
}




class TransactionContext implements Runnable {
	
	private Map<Serializable,AfterTxCommitRunnable> map = new HashMap<Serializable, AfterTxCommitRunnable>(); 
	
	public void put(Serializable taskId, AfterTxCommitRunnable r) {
		final AfterTxCommitRunnable q = map.put(taskId,r);
		if (q != null && q.getType() == AfterTxCommitRunnable.Type.SET) {
			
			map.remove(taskId);
		}
	}
	
	public AfterTxCommitRunnable remove(Serializable taskId) {
		return map.remove(taskId);
	}
	
	@Override
	public void run() {
		for(AfterTxCommitRunnable r : map.values()) {
			r.run();		
		}
		map = null;
	}
}











class TransactionContextThreadLocal {

	


	private static final ThreadLocal<TransactionContext> transactionContext = new ThreadLocal<TransactionContext>();

	



	public static void setTransactionContext(TransactionContext txContext) {
		transactionContext.set(txContext);
	}

	



	public static TransactionContext getTransactionContext() {
		return transactionContext.get();
	}

}








class TransactionSynchronization implements Synchronization {
	
	private final TransactionContext txContext;
	
	



	TransactionSynchronization(TransactionContext txContext) {
		this.txContext = txContext;
		TransactionContextThreadLocal.setTransactionContext(txContext);
	}

	



	public void afterCompletion(int status) {
		switch (status) {
			case Status.STATUS_COMMITTED:
				txContext.run();
				break;
			default:				
		}
		TransactionContextThreadLocal.setTransactionContext(null);
	}

	



	public void beforeCompletion() {}
	
}













class TimerTaskCacheData extends ClusteredCacheData {
	
	


	private static final String CACHE_NODE_MAP_KEY = "taskdata";
	
	


	@SuppressWarnings("unchecked")
	public TimerTaskCacheData(Serializable taskID, Fqn baseFqn, MobicentsCluster mobicentsCluster) {
		super(FqnWrapper.fromRelativeElementsWrapper(new FqnWrapper(baseFqn), taskID),mobicentsCluster);
	}

	


	@SuppressWarnings("unchecked")
	public TimerTaskCacheData(Fqn fqn, MobicentsCluster mobicentsCluster) {
		super(new FqnWrapper(fqn),mobicentsCluster);
	}
	
	




	@SuppressWarnings("unchecked")
	public void setTaskData(TimerTaskData taskData) {
		getNode().put(CACHE_NODE_MAP_KEY,taskData);
	}

	



	@SuppressWarnings("unchecked")
	public TimerTaskData getTaskData() {
		return (TimerTaskData) getNode().get(CACHE_NODE_MAP_KEY);		
	}

	






	public static Serializable getTaskID(ClusteredCacheData clusteredCacheData) throws IllegalArgumentException {
		return (Serializable) clusteredCacheData.getNodeFqn().getLastElement();
	}
	
}

















class Address implements Comparable<Address> {

    private final String name;

    Address(final String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(final Object o) {
        return o instanceof Address && ((Address) o).name.equals(name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    public int compareTo(final Address o) {
        return name.compareTo(o.name);
    }
}


class View {

    private final List<Address> members;

    View(final List<Address> members) {
        this.members = members;
    }

    public List<Address> getMembers() {
        return members;
    }
}


final class Fqn {

    public static final String SEPARATOR = "/";

    private final List<Object> elements;

    private Fqn(final List<Object> elements) {
        this.elements = elements;
    }

    public static Fqn fromElements(final Object... elements) {
        return new Fqn(new ArrayList<Object>(Arrays.asList(elements)));
    }

    public static Fqn fromString(final String stringRepresentation) {
        final List<Object> parts = new ArrayList<Object>();
        for (final String p : stringRepresentation.split(SEPARATOR)) {
            if (!p.isEmpty()) {
                parts.add(p);
            }
        }
        return new Fqn(parts);
    }

    public static Fqn fromRelativeElements(final Fqn base, final Object... relativeElements) {
        final List<Object> combined = new ArrayList<Object>(base.elements);
        combined.addAll(Arrays.asList(relativeElements));
        return new Fqn(combined);
    }

    public Object getLastElement() {
        return elements.isEmpty() ? null : elements.get(elements.size() - 1);
    }

    public Fqn getParent() {
        return elements.isEmpty() ? this : new Fqn(elements.subList(0, elements.size() - 1));
    }

    public boolean isRoot() {
        return elements.isEmpty();
    }

    List<Object> getElements() {
        return elements;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        for (final Object e : elements) {
            sb.append(SEPARATOR).append(e);
        }
        return sb.length() == 0 ? SEPARATOR : sb.toString();
    }

    @Override
    public boolean equals(final Object o) {
        return o instanceof Fqn && ((Fqn) o).elements.equals(elements);
    }

    @Override
    public int hashCode() {
        return elements.hashCode();
    }
}


final class Node {

    private final Fqn fqn;
    private final Node parent;
    private final Map<Object, Node> children = new LinkedHashMap<Object, Node>();
    private final Map<Object, Object> data = new LinkedHashMap<Object, Object>();

    Node(final Fqn fqn, final Node parent) {
        this.fqn = fqn;
        this.parent = parent;
    }

    public Fqn getFqn() {
        return fqn;
    }

    public Node getParent() {
        return parent;
    }

    public Object put(final Object key, final Object value) {
        return data.put(key, value);
    }

    public Object get(final Object key) {
        return data.get(key);
    }

    public Object remove(final Object key) {
        return data.remove(key);
    }

    public Map<String, Object> getData() {
        final Map<String, Object> out = new LinkedHashMap<String, Object>();
        for (final Map.Entry<Object, Object> e : data.entrySet()) {
            out.put(String.valueOf(e.getKey()), e.getValue());
        }
        return out;
    }

    public Set<Node> getChildren() {
        return new LinkedHashSet<Node>(children.values());
    }

    public boolean isLeaf() {
        return children.isEmpty();
    }

    public Set<Object> getChildrenNames() {
        return new LinkedHashSet<Object>(children.keySet());
    }

    public Node addChild(final Fqn childFqn) {
        Node cursor = root();
        Node current = this;
        for (final Object element : relativeElements(childFqn)) {
            Node next = current.children.get(element);
            if (next == null) {
                next = new Node(Fqn.fromRelativeElements(current.fqn, element), current);
                current.children.put(element, next);
            }
            current = next;
        }
        return current;
    }

    public Node getChild(final Fqn childFqn) {
        Node current = this;
        for (final Object element : relativeElements(childFqn)) {
            current = current.children.get(element);
            if (current == null) {
                return null;
            }
        }
        return current;
    }

    public Node getChild(final String name) {
        return children.get(name);
    }

    public boolean removeChild(final Object name) {
        return children.remove(name) != null;
    }

    private Node root() {
        Node n = this;
        while (n.parent != null) {
            n = n.parent;
        }
        return n;
    }

    
    private List<Object> relativeElements(final Fqn childFqn) {
        final List<Object> all = childFqn.getElements();
        final int ownDepth = fqn.getElements().size();
        return all.size() > ownDepth ? all.subList(ownDepth, all.size()) : new ArrayList<Object>();
    }

    @Override
    public String toString() {
        return "Node" + fqn;
    }
}


enum CacheMode {
    LOCAL, REPL_SYNC, REPL_ASYNC, INVALIDATION_SYNC, INVALIDATION_ASYNC
}


class BuddyGroup {

    private final List<Address> buddies = new ArrayList<Address>();

    public List<Address> getBuddies() {
        return buddies;
    }

    void addBuddy(final Address address) {
        buddies.add(address);
    }
}


class BuddyReplicationConfig {

    private final boolean enabled;

    BuddyReplicationConfig(final boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }
}


class RuntimeConfig {

    private final BuddyGroup buddyGroup = new BuddyGroup();
    private final Address channelLocalAddress;

    RuntimeConfig(final Address channelLocalAddress) {
        this.channelLocalAddress = channelLocalAddress;
    }

    public BuddyGroup getBuddyGroup() {
        return buddyGroup;
    }

    public Channel getChannel() {
        return new Channel(channelLocalAddress);
    }
}


class Channel {

    private final Address localAddress;

    Channel(final Address localAddress) {
        this.localAddress = localAddress;
    }

    public Address getLocalAddress() {
        return localAddress;
    }
}


class Configuration {

    private final CacheMode cacheMode;
    private final BuddyReplicationConfig buddyReplicationConfig;
    private final RuntimeConfig runtimeConfig;

    Configuration(final CacheMode cacheMode, final BuddyReplicationConfig buddyReplicationConfig,
            final Address localAddress) {
        this.cacheMode = cacheMode;
        this.buddyReplicationConfig = buddyReplicationConfig;
        this.runtimeConfig = new RuntimeConfig(localAddress);
    }

    public CacheMode getCacheMode() {
        return cacheMode;
    }

    public BuddyReplicationConfig getBuddyReplicationConfig() {
        return buddyReplicationConfig;
    }

    public RuntimeConfig getRuntimeConfig() {
        return runtimeConfig;
    }
}


class OptionOverrides {

    private boolean forceDataGravitation;
    private boolean cacheModeLocal;

    public void setForceDataGravitation(final boolean value) {
        this.forceDataGravitation = value;
    }

    public boolean isForceDataGravitation() {
        return forceDataGravitation;
    }

    public void setCacheModeLocal(final boolean value) {
        this.cacheModeLocal = value;
    }

    public boolean isCacheModeLocal() {
        return cacheModeLocal;
    }
}


class InvocationContext {

    private final OptionOverrides optionOverrides = new OptionOverrides();

    public OptionOverrides getOptionOverrides() {
        return optionOverrides;
    }
}









class Cache {

    private final Configuration configuration;
    private final Node root = new Node(Fqn.fromElements(), null);
    private final InvocationContext invocationContext = new InvocationContext();
    private final List<Object> listeners = new ArrayList<Object>();
    private final Address localAddress;

    Cache(final Configuration configuration, final Address localAddress) {
        this.configuration = configuration;
        this.localAddress = localAddress;
    }

    public void create() {
    }

    public Address getLocalAddress() {
        return localAddress;
    }

    public Configuration getConfiguration() {
        return configuration;
    }

    public Node getRoot() {
        return root;
    }

    public Node getNode(final Fqn fqn) {
        return root.getChild(fqn);
    }

    public Node getNode(final String stringFqn) {
        return getNode(Fqn.fromString(stringFqn));
    }

    public Set<Object> getChildrenNames(final Fqn fqn) {
        final Node node = getNode(fqn);
        final Set<Object> names = new LinkedHashSet<Object>();
        if (node != null) {
            for (final Node child : node.getChildren()) {
                names.add(child.getFqn().getLastElement());
            }
        }
        return names;
    }

    public boolean removeNode(final Fqn fqn) {
        final Node node = getNode(fqn);
        if (node == null) {
            return false;
        }
        return node.getParent() != null && node.getParent().removeChild(fqn.getLastElement());
    }

    public InvocationContext getInvocationContext() {
        return invocationContext;
    }

    public void addCacheListener(final Object listener) {
        listeners.add(listener);
    }

    
    void fireViewChanged(final ViewChangedEvent event) {
        deliver(ViewChanged.class, event);
    }

    void fireBuddyGroupChanged(final BuddyGroupChangedEvent event) {
        deliver(BuddyGroupChanged.class, event);
    }

    void fireNodeRemoved(final NodeRemovedEvent event) {
        deliver(NodeRemoved.class, event);
    }

    private void deliver(final Class<? extends java.lang.annotation.Annotation> annotationType, final Object event) {
        for (final Object listener : listeners) {
            for (final java.lang.reflect.Method m : listener.getClass().getMethods()) {
                if (m.isAnnotationPresent(annotationType)) {
                    try {
                        m.invoke(listener, event);
                    } catch (final Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
    }
}






@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@interface CacheListener {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@interface ViewChanged {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@interface BuddyGroupChanged {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@interface NodeRemoved {
}

class ViewChangedEvent {

    private final boolean pre;
    private final Cache cache;
    private final View newView;

    ViewChangedEvent(final boolean pre, final Cache cache, final View newView) {
        this.pre = pre;
        this.cache = cache;
        this.newView = newView;
    }

    public boolean isPre() {
        return pre;
    }

    public Cache getCache() {
        return cache;
    }

    public View getNewView() {
        return newView;
    }
}

class BuddyGroupChangedEvent {

    private final Cache cache;
    private final BuddyGroup buddyGroup;

    BuddyGroupChangedEvent(final Cache cache, final BuddyGroup buddyGroup) {
        this.cache = cache;
        this.buddyGroup = buddyGroup;
    }

    public Cache getCache() {
        return cache;
    }

    public BuddyGroup getBuddyGroup() {
        return buddyGroup;
    }
}

class NodeRemovedEvent {

    private final Fqn fqn;
    private final boolean pre;
    private final boolean originLocal;

    NodeRemovedEvent(final Fqn fqn, final boolean pre, final boolean originLocal) {
        this.fqn = fqn;
        this.pre = pre;
        this.originLocal = originLocal;
    }

    public Fqn getFqn() {
        return fqn;
    }

    public boolean isPre() {
        return pre;
    }

    public boolean isOriginLocal() {
        return originLocal;
    }
}





final class Logger {

    private final String name;

    private Logger(final String name) {
        this.name = name;
    }

    public static Logger getLogger(final Class<?> clazz) {
        return new Logger(clazz.getSimpleName());
    }

    public boolean isDebugEnabled() {
        return true;
    }

    public boolean isTraceEnabled() {
        return false;
    }

    public void debug(final String msg) {
        System.out.println("        [DEBUG] " + name + " - " + msg);
    }

    public void trace(final String msg) {
        System.out.println("        [TRACE] " + name + " - " + msg);
    }

    public void error(final String msg, final Throwable t) {
        System.out.println("        [ERROR] " + name + " - " + msg
                + (t == null ? "" : " (" + t.getClass().getSimpleName() + ": " + t.getMessage() + ")"));
    }
}








class Transaction {

    boolean active = true;
    private final List<Synchronization> synchronizations = new ArrayList<Synchronization>();

    public void registerSynchronization(final Synchronization sync) {
        synchronizations.add(sync);
    }

    void fireAfterCompletion(final int status) {
        for (final Synchronization s : synchronizations) {
            s.afterCompletion(status);
        }
    }
}


interface Synchronization {

    void beforeCompletion();

    void afterCompletion(int status);
}


final class Status {

    public static final int STATUS_COMMITTED = 3;

    private Status() {
    }
}

class TransactionManager {

    private final ThreadLocal<Transaction> current = new ThreadLocal<Transaction>();

    public Transaction getTransaction() {
        return current.get();
    }

    public void begin() {
        current.set(new Transaction());
    }

    public void commit() {
        final Transaction tx = current.get();
        if (tx != null) {
            System.out.println("        [tx] commit");
            current.remove();
            tx.fireAfterCompletion(Status.STATUS_COMMITTED);
        } else {
            current.remove();
        }
    }

    public void rollback() {
        final Transaction tx = current.get();
        if (tx != null) {
            System.out.println("        [tx] rollback");
        }
        current.remove();
    }
}















interface FailOverListener {

	



	@SuppressWarnings("unchecked")
	public FqnWrapper getBaseFqn();
	
	





	public ClientLocalListenerElector getElector();
	
	



	public byte getPriority();

	



	public void failOverClusterMember(Address address);
	
	



	public void wonOwnership(ClusteredCacheData clusteredCacheData);

	



	public void lostOwnership(ClusteredCacheData clusteredCacheData);
}








class FailOverListenerPriorityComparator implements Comparator<FailOverListener> {

	


	public int compare(FailOverListener o1, FailOverListener o2) {
		if (o1.equals(o2)) {
			return 0;
		}
		else {
			if (o1.getPriority() > o2.getPriority()) {
				return -1;
			}
			else {
				return 1;
			}
		}
	}

}









interface DataRemovalListener {

	



	@SuppressWarnings("unchecked")
	public FqnWrapper getBaseFqn();
	
	



	@SuppressWarnings("unchecked")
	public void dataRemoved(FqnWrapper clusteredCacheDataFqnWrapper);
}











interface ClusterElector {

	
	public Address elect(List<Address> list);
	
	
}




interface ClientLocalListenerElector {

	





	public Address elect(List<Address> nodes, ClusteredCacheData cacheData);
}










interface ClusteredCacheDataIndexingHandler {

	



	public void setClusterNodeAddress(ClusteredCacheData cacheData, Address clusterNodeAddress);
	
	




	public Address getClusterNodeAddress(ClusteredCacheData cacheData);
	
}











class DefaultClusteredCacheDataIndexingHandler implements ClusteredCacheDataIndexingHandler {
	
	


	private static final String CLUSTER_NODE_ADDRESS_NODE_KEY = "cnaddress";
	
	



	@SuppressWarnings("unchecked")
	public void setClusterNodeAddress(ClusteredCacheData cacheData, Address clusterNodeAddress) {
		cacheData.getNode().put(CLUSTER_NODE_ADDRESS_NODE_KEY,clusterNodeAddress);
	}
	
	



	@SuppressWarnings("unchecked")
	public Address getClusterNodeAddress(ClusteredCacheData cacheData) {
		return (Address) cacheData.getNode().get(CLUSTER_NODE_ADDRESS_NODE_KEY);
	}
}











class ClusteredCacheData extends CacheData {
	
	private final ClusteredCacheDataIndexingHandler indexingHandler;
	
	



	public ClusteredCacheData(FqnWrapper nodeFqnWrapper, MobicentsCluster mobicentsCluster) {
		
		super(nodeFqnWrapper, mobicentsCluster.getMobicentsCache());
		indexingHandler = mobicentsCluster.getClusteredCacheDataIndexingHandler();
	}

	


	@Override
	public boolean create() {
		if (super.create()) {
			
			if (!getMobicentsCache().isLocalMode()) {
				setClusterNodeAddress(getMobicentsCache().getJBossCache().getLocalAddress());
			}
			return true;
		}
		else {
			return false;
		}
	}
	
	



	public void setClusterNodeAddress(Address clusterNodeAddress) {
		indexingHandler.setClusterNodeAddress(this,clusterNodeAddress);
	}
	
	




	public Address getClusterNodeAddress() {
		return indexingHandler.getClusterNodeAddress(this);
	}
	
	


	@Override
	protected Node getNode() {
		return super.getNode();
	}
}




class FqnWrapper {

    private Fqn fqn;

    public FqnWrapper(Fqn fqn) {
        this.fqn = fqn;
    }

    public Fqn getFqn() {
        return this.fqn;
    }

    public Object getLastElement() {
        return this.fqn.getLastElement();
    }

    public static FqnWrapper fromStringWrapper(String stringRepresentation) {
        return new FqnWrapper(Fqn.fromString(stringRepresentation));
    }

    public static FqnWrapper fromRelativeElementsWrapper(FqnWrapper base, Object... relativeElements) {
        return new FqnWrapper(Fqn.fromRelativeElements(base.getFqn(), relativeElements));
    }

    public static FqnWrapper fromElementsWrapper(Object... elements) {
        return new FqnWrapper(Fqn.fromElements(elements));
    }

}









class CacheData {

	private static final Logger logger = Logger.getLogger(CacheData.class);
	
	@SuppressWarnings("unchecked")
	private Node node;
	@SuppressWarnings("unchecked")
	private final Fqn nodeFqn;
	
	private boolean isRemoved;
	private final MobicentsCache mobicentsCache;
	
	private final static boolean doTraceLogs = logger.isTraceEnabled();  

	











	@SuppressWarnings("unchecked")
	public CacheData(FqnWrapper nodeFqnWrapper, MobicentsCache mobicentsCache) {
		this.nodeFqn = nodeFqnWrapper.getFqn();
		this.mobicentsCache = mobicentsCache;
		this.node = mobicentsCache.getJBossCache().getRoot().getChild(nodeFqn);
		if (doTraceLogs) {
			logger.trace("cache node "+nodeFqn+" retrieved, result = "+this.node);
		}
	}
	
	



	public boolean exists() {
		return node != null;
	}

	


	public boolean create() {
		if (!exists()) {
			node = mobicentsCache.getJBossCache().getRoot().addChild(nodeFqn);
			if (doTraceLogs) {
				logger.trace("created cache node "+nodeFqn);
			}
			return true;
		}
		else {
			return false;
		}
	}
	
	



	public boolean isRemoved() {
		return isRemoved;
	}
	
	


	public boolean remove() {
		if (exists() && !isRemoved()) {
			isRemoved = true;
			node.getParent().removeChild(nodeFqn.getLastElement());
			if (doTraceLogs) {
				logger.trace("removed cache node "+nodeFqn);
			}	
			return true;
		}
		else {
			return false;
		}
	}
	
	





	@SuppressWarnings("unchecked")
	protected Node getNode() {
		if (isRemoved()) {
			throw new IllegalStateException();
		}
		return node;
	}
	
	



	public MobicentsCache getMobicentsCache() {
		return mobicentsCache;
	}
	
	



	@SuppressWarnings("unchecked")
	public Fqn getNodeFqn() {
		return nodeFqn;
	}

	public FqnWrapper getNodeFqnWrapper() {
		return new FqnWrapper(nodeFqn);
	}

	public Object getNodeFqnLastElement() {
		return nodeFqn.getLastElement();
	}

	public Object putNodeValue(Object key, Object value) {
		return getNode().put(key, value);
	}

	public Object getNodeValue(Object key) {
		return getNode().get(key);
	}

	public Object removeNodeValue(Object key) {
		return getNode().remove(key);
	}

	public Object addChildNode(FqnWrapper fqnWrapper) {
		final Node childNode = getNode().addChild(fqnWrapper.getFqn());
		return (Object) childNode;
	}

	public Object putChildNodeValue(FqnWrapper fqnWrapper, Object key, Object value) {
		final Node childNode = getNode().getChild(fqnWrapper.getFqn());
		if (childNode != null) {
			return childNode.put(key, value);
		}
		return null;
	}

	public Object getChildNode(String child) {
		final Node childNode = getNode().getChild(child);
		return (Object) childNode;
	}

	public Map<String, Object> getChildNodeData(String child) {
		final Node childNode = getNode().getChild(child);
		return childNode.getData();
	}

	public Object getChildNodeValue(String child, Object key) {
		final Node childNode = getNode().getChild(child);
		return childNode.get(key);
	}

	public boolean removeChildNode(String child) {
		return getNode().removeChild(child);
	}

}









interface MobicentsCluster {

	



	public boolean addFailOverListener(FailOverListener listener);
	
	




	public boolean removeFailOverListener(FailOverListener listener);
	
	



	public boolean addDataRemovalListener(DataRemovalListener listener);
	
	




	public boolean removeDataRemovalListener(DataRemovalListener listener);
	
	



	public Address getLocalAddress();
	
	



	public List<Address> getClusterMembers();
	
	



	public boolean isHeadMember();
	
	









	public boolean isSingleMember();
	
	



	public MobicentsCache getMobicentsCache();
	
	



	public ClusteredCacheDataIndexingHandler getClusteredCacheDataIndexingHandler();

	




	public void startCluster();
	
	



	public boolean isStarted();
	
	


	public void stopCluster();
	
}










class MobicentsCache {

    private final Cache jBossCache;
    private boolean localMode;

    public MobicentsCache(final Cache cache) {
        this.jBossCache = cache;
        setLocalMode();
    }

    private void setLocalMode() {
        localMode = jBossCache.getConfiguration().getCacheMode() == CacheMode.LOCAL;
    }

    public Cache getJBossCache() {
        return jBossCache;
    }

    public boolean isLocalMode() {
        return localMode;
    }
}

