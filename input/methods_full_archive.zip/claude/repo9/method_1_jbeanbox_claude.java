






































import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.lang.reflect.UndeclaredThrowableException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;










public class method_1_jbeanbox_claude {

	
	
	
	

	
	public static class TxInterceptor implements MethodInterceptor {
		public Object invoke(MethodInvocation invocation) throws Throwable {
			System.out.println("        [TxInterceptor] begin  -> " + invocation.getMethod().getName());
			Object result = invocation.proceed();
			System.out.println("        [TxInterceptor] commit <- " + invocation.getMethod().getName());
			return result;
		}
	}

	
	@AOP
	@Retention(RetentionPolicy.RUNTIME)
	@Target({ ElementType.TYPE, ElementType.METHOD })
	public @interface Tx {
		Class<?> value();

		String method() default "";
	}

	public static class UserDao {
		public String name = "userDao";

		public String toString() {
			return "UserDao(" + name + ")";
		}
	}

	public interface UserService {
		void saveUser(String user);

		String readUser();
	}

	
	public static class PlainService {
	}

	
	@PROTOTYPE
	public static class PrototypeService {
	}

	
	@Scope("prototype")
	public static class SpringPrototypeService {
	}

	
	@Scope("singleton")
	public static class SpringSingletonService {
	}

	
	@Scope("session")
	public static class BadScopeService {
	}

	
	@INJECT(value = UserDao.class, required = false)
	public static class ClassLevelInjectService {
	}

	
	@Tx(value = TxInterceptor.class, method = "save*")
	public static class TxAnnotatedService implements UserService {
		public void saveUser(String user) {
			System.out.println("        TxAnnotatedService.saveUser(" + user + ")");
		}

		public String readUser() {
			return "reader";
		}
	}

	public static class BaseBean {
		@INJECT
		protected UserDao inheritedDao;
	}

	
	public static class FieldInjectBean extends BaseBean {
		@INJECT
		public UserDao dao;
		@Autowired(required = false)
		public UserDao springDao;
		@Inject
		public UserDao jsrDao;
		@VALUE("8080")
		public int port;
		public String notInjected;

		public String toString() {
			return "FieldInjectBean[dao=" + dao + ", springDao=" + springDao + ", jsrDao=" + jsrDao
					+ ", inheritedDao=" + inheritedDao + ", port=" + port + ", notInjected=" + notInjected + "]";
		}
	}

	
	public static class MethodInjectBean {
		public UserDao oneParamDao;
		public String configured;

		@INJECT(UserDao.class)
		public void setDao(UserDao dao) {
			this.oneParamDao = dao;
		}

		@INJECT
		public void configure(UserDao dao, @VALUE("3306") String port) {
			this.configured = dao + "@" + port;
		}

		@POSTCONSTRUCT
		public void jbeanboxInit() {
			System.out.println("        MethodInjectBean.jbeanboxInit() called by container");
		}

		@PREDESTROY
		public void jbeanboxDestroy() {
		}

		@Tx(TxInterceptor.class)
		public void business() {
		}
	}

	
	public static class JsrLifecycleBean {
		@PostConstruct
		public void afterCreate() {
		}

		@PreDestroy
		public void beforeDestroy() {
		}
	}

	
	public static class SingleParamCtorBean {
		public final UserDao dao;

		@INJECT(UserDao.class)
		public SingleParamCtorBean(UserDao dao) {
			this.dao = dao;
		}
	}

	
	public static class MultiParamCtorBean {
		public final UserDao dao;
		public final String poolSize;

		@INJECT
		public MultiParamCtorBean(UserDao dao, @VALUE("42") String poolSize) {
			this.dao = dao;
			this.poolSize = poolSize;
		}
	}

	
	public static class BadPostConstructBean {
		@POSTCONSTRUCT
		public void init(String illegalParameter) {
		}
	}

	
	
	

	public static void main(String[] args) {
		title("METHOD 1  |  BeanBoxUtils.doCreateBeanBox(BeanBoxContext, Class<?>)");

		
		section("1. plain class, no annotation");
		describe("PlainService", BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), PlainService.class));

		
		section("2. ctx.isAllowAnnotation() == false  (early return branch)");
		BeanBoxContext noAnno = new BeanBoxContext().setAllowAnnotation(false);
		BeanBox b2 = BeanBoxUtils.getUniqueBeanBox(noAnno, PrototypeService.class);
		System.out.println("      @PROTOTYPE was NOT read, singleton stays " + b2.isSingleton()
				+ "  (method returned right after setSingleton(true))");

		
		section("3. singleton and prototype branches");
		describe("@PROTOTYPE PrototypeService",
				BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), PrototypeService.class));
		describe("@Scope(\"prototype\") SpringPrototypeService",
				BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), SpringPrototypeService.class));
		describe("@Scope(\"singleton\") SpringSingletonService",
				BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), SpringSingletonService.class));
		describe("@Scope(\"session\") BadScopeService",
				BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), BadScopeService.class));
		System.out.println("  NOTE: the three @Scope boxes above stay singleton=true. getAnnoAsMap() matches");
		System.out.println("        the annotation by the literal string");
		System.out.println("        \"org.springframework.context.annotation.Scope\", and a single .java file");
		System.out.println("        can not declare that package, so the Spring @Scope sub-branch evaluates its");
		System.out.println("        m == null path. The code is present and unchanged inside the markers.");
		BeanBoxContext noSpring = new BeanBoxContext().setAllowSpringJsrAnnotation(false);
		System.out.println("  Spring/JSR support disabled, allowSpringJsrAnno=false, singleton = "
				+ BeanBoxUtils.getUniqueBeanBox(noSpring, SpringPrototypeService.class).isSingleton());

		
		section("4. class level @INJECT");
		describe("ClassLevelInjectService",
				BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), ClassLevelInjectService.class));

		
		section("5. class level AOP annotation");
		describe("TxAnnotatedService", BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), TxAnnotatedService.class));

		
		section("6. constructor injection");
		describe("SingleParamCtorBean",
				BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), SingleParamCtorBean.class));
		describe("MultiParamCtorBean", BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), MultiParamCtorBean.class));

		
		section("7. field injection (own + super class fields)");
		describe("FieldInjectBean", BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), FieldInjectBean.class));

		
		section("8. method injection, @POSTCONSTRUCT/@PREDESTROY and method AOP");
		describe("MethodInjectBean", BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), MethodInjectBean.class));
		describe("JsrLifecycleBean (JSR-250)",
				BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), JsrLifecycleBean.class));
		try {
			BeanBoxUtils.getUniqueBeanBox(new BeanBoxContext(), BadPostConstructBean.class);
			System.out.println("  !! expected exception was not thrown");
		} catch (BeanBoxException e) {
			System.out.println("  @POSTCONSTRUCT with a parameter -> expected BeanBoxException: " + e.getMessage());
		}

		
		section("9. end to end proof - the BeanBox built by the original method is usable");
		BeanBoxContext ctx = new BeanBoxContext();
		FieldInjectBean built = ctx.getBean(FieldInjectBean.class);
		System.out.println("      ctx.getBean(FieldInjectBean.class) = " + built);
		MethodInjectBean mib = ctx.getBean(MethodInjectBean.class);
		System.out.println("      one-parameter method inject  : " + mib.oneParamDao);
		System.out.println("      multi-parameter method inject: " + mib.configured);

		title("END OF METHOD 1 SCENARIOS");
	}

	
	
	

	private static void title(String s) {
		System.out.println();
		System.out.println("################################################################################");
		System.out.println("# " + s);
		System.out.println("################################################################################");
	}

	private static void section(String s) {
		System.out.println();
		System.out.println("--- " + s + " ---");
	}

	private static String n(Class<?> c) {
		return c == null ? "null" : c.getSimpleName();
	}

	private static void describe(String label, BeanBox box) {
		System.out.println("  " + label);
		System.out.println("      beanClass       : " + n(box.getBeanClass()));
		System.out.println("      singleton       : " + box.isSingleton());
		System.out.println("      target          : " + box.getTarget() + "   pureValue=" + box.isPureValue()
				+ " required=" + box.isRequired());
		if (box.getConstructor() != null) {
			System.out.println("      constructor     : " + box.getConstructor());
		}
		if (box.getConstructorParams() != null) {
			BeanBox[] ps = box.getConstructorParams();
			for (int i = 0; i < ps.length; i++) {
				System.out.println("        ctor param[" + i + "] target=" + ps[i].getTarget() + " type="
						+ n(ps[i].getType()) + " pureValue=" + ps[i].isPureValue() + " required=" + ps[i].isRequired());
			}
		}
		if (box.getFieldInjects() != null) {
			List<String> rows = new ArrayList<String>();
			for (Entry<Field, BeanBox> e : box.getFieldInjects().entrySet()) {
				rows.add("        field inject  : " + e.getKey().getDeclaringClass().getSimpleName() + "."
						+ e.getKey().getName() + "  <- target=" + e.getValue().getTarget() + " type="
						+ n(e.getValue().getType()) + " required=" + e.getValue().isRequired());
			}
			Collections.sort(rows);
			for (String r : rows) {
				System.out.println(r);
			}
		}
		if (box.getMethodInjects() != null) {
			List<String> rows = new ArrayList<String>();
			for (Entry<Method, BeanBox[]> e : box.getMethodInjects().entrySet()) {
				StringBuilder sb = new StringBuilder("        method inject : " + e.getKey().getName() + "(");
				BeanBox[] ps = e.getValue();
				for (int i = 0; i < ps.length; i++) {
					sb.append(i > 0 ? ", " : "").append(ps[i].getTarget()).append(":").append(n(ps[i].getType()));
				}
				rows.add(sb.append(")").toString());
			}
			Collections.sort(rows);
			for (String r : rows) {
				System.out.println(r);
			}
		}
		if (box.getPostConstruct() != null) {
			System.out.println("      postConstruct   : " + box.getPostConstruct().getName() + "()");
		}
		if (box.getPreDestroy() != null) {
			System.out.println("      preDestroy      : " + box.getPreDestroy().getName() + "()");
		}
		if (box.getAopRules() != null) {
			for (Object[] r : box.getAopRules()) {
				System.out.println("        bean AOP rule : aop=" + r[0] + "  methodNameRule=" + r[1]);
			}
		}
		if (box.getMethodAops() != null) {
			for (Entry<Method, List<Object>> e : box.getMethodAops().entrySet()) {
				System.out.println("        method AOP    : " + e.getKey().getName() + " -> " + e.getValue());
			}
		}
	}
}














@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface PostConstruct {
}


@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface PreDestroy {
}




@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER })
@interface Inject {
}




@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER })
@interface Autowired {
    boolean required() default true;
}








@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE, ElementType.METHOD })
@interface Scope {
    String value() default "";
}




interface MethodInvocation {

    Method getMethod();

    Object[] getArguments();

    Object proceed() throws Throwable;

    Object getThis();

    AccessibleObject getStaticPart();
}


interface MethodInterceptor {

    Object invoke(MethodInvocation invocation) throws Throwable;
}



interface Callback {
}





interface CglibMethodInterceptor extends Callback {

    Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable;
}





class MethodProxy {

    private final Object target;
    private final Method method;

    protected MethodProxy(Object target, Method method) {
        this.target = target;
        this.method = method;
    }

    public Object invokeSuper(Object obj, Object[] args) throws Throwable {
        try {
            return method.invoke(target, args);
        } catch (InvocationTargetException e) {
            throw e.getCause();
        }
    }

    public Object invoke(Object obj, Object[] args) throws Throwable {
        return invokeSuper(obj, args);
    }

    public Method getMethod() {
        return method;
    }

    public Object getTarget() {
        return target;
    }
}











class Enhancer {

    private Class<?> superclass;
    private Callback callback;

    public void setSuperclass(Class<?> superclass) {
        this.superclass = superclass;
    }

    public void setCallback(Callback callback) {
        this.callback = callback;
    }

    public Object create() {
        return doCreate(new Class<?>[0], new Object[0]);
    }

    public Object create(Class<?>[] argumentTypes, Object[] arguments) {
        return doCreate(argumentTypes, arguments);
    }

    private Object doCreate(Class<?>[] argumentTypes, Object[] arguments) {
        final Object target;
        try {
            Constructor<?> c = superclass.getDeclaredConstructor(argumentTypes);
            c.setAccessible(true);
            target = c.newInstance(arguments);
        } catch (Exception e) {
            throw new IllegalStateException("Enhancer can not instantiate " + superclass, e);
        }
        Class<?>[] interfaces = collectInterfaces(superclass);
        if (interfaces.length == 0 || !(callback instanceof CglibMethodInterceptor)) {
            System.out.println("        [Enhancer adaptation] " + superclass.getSimpleName()
                    + " implements no interface, a non-advised instance is returned");
            return target;
        }
        final CglibMethodInterceptor interceptor = (CglibMethodInterceptor) callback;
        return Proxy.newProxyInstance(superclass.getClassLoader(), interfaces, new InvocationHandler() {
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                Method impl = superclass.getMethod(method.getName(), method.getParameterTypes());
                impl.setAccessible(true);
                Object[] realArgs = args == null ? new Object[0] : args;
                return interceptor.intercept(target, impl, realArgs, new MethodProxy(target, impl));
            }
        });
    }

    private static Class<?>[] collectInterfaces(Class<?> clazz) {
        Set<Class<?>> all = new LinkedHashSet<Class<?>>();
        for (Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Class<?> i : c.getInterfaces()) {
                all.add(i);
            }
        }
        return all.toArray(new Class<?>[all.size()]);
    }
}




































@Target(ElementType.ANNOTATION_TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface AOP {
}











@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD, ElementType.TYPE, ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.PARAMETER })
@interface INJECT {

	public Class<?> value() default EMPTY.class; 

	public boolean pureValue() default false; 

	public boolean required() default true; 

}











@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD, ElementType.TYPE, ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.PARAMETER })
@interface VALUE {

	public String value(); 

	public boolean pureValue() default true; 

	public boolean required() default true; 
}












@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE })
@interface PROTOTYPE {
}








@Documented
@Retention(RUNTIME)
@Target(METHOD)
@interface POSTCONSTRUCT {

}











@Documented
@Retention(RUNTIME)
@Target(METHOD)
@interface PREDESTROY {
}











final class EMPTY {
}










class BeanBoxException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public BeanBoxException() {
		
	}

	public BeanBoxException(String message) {
		super(message);
	}

	public BeanBoxException(Throwable cause) {
		super(cause);
	}

	public BeanBoxException(String message, Throwable cause) {
		super(message, cause);
	}

	public static <T> T throwEX(String errorMsg, Throwable e) {
		throw new BeanBoxException(errorMsg, e);
	}

	public static <T> T throwEX(Throwable cause) {
		throw new BeanBoxException(cause);
	}

	public static <T> T throwEX(String errorMsg) {
		throw new BeanBoxException(errorMsg);
	}

	public static boolean assureNotNull(Object obj, String... optionMessages) {
		if (obj == null)
			throw new BeanBoxException(
					optionMessages.length == 0 ? "Assert error, Object parameter can not be null" : optionMessages[0]);
		return true;
	}

	public static boolean assureNotEmpty(String str, String... optionMessages) {
		if (str == null || str.length() == 0)
			throw new BeanBoxException(
					optionMessages.length == 0 ? "Assert error, String parameter can not be empty" : optionMessages[0]);
		return true;
	}
	
	public static boolean assure(boolean condition, String... optionMessages) {
		if (!condition)
			throw new BeanBoxException(
					optionMessages.length == 0 ? "Assert expected true but got false" : optionMessages[0]);
		return true;
	}
}












interface ValueTranslator {

	public Object translate(String s, Class<?> type);

	public static class DefaultValueTranslator implements ValueTranslator {

		@Override
		public Object translate(String s, Class<?> type) {
			if (type == null)
				BeanBoxException.throwEX("ParamTranslator can not translate to 'null' type");
			if (Integer.class.equals(type) || int.class.equals(type))
				return Integer.parseInt(s);
			if (Long.class.equals(type) || long.class.equals(type))
				return Long.parseLong(s);
			if (Character.class.equals(type) || char.class.equals(type))
				return s.charAt(0);
			if (Byte.class.equals(type) || byte.class.equals(type))
				return Byte.parseByte(s);
			if (Boolean.class.equals(type) || boolean.class.equals(type))
				return Boolean.parseBoolean(s);
			if (Double.class.equals(type) || double.class.equals(type))
				return Double.parseDouble(s);
			if (Float.class.equals(type) || float.class.equals(type))
				return Float.parseFloat(s);
			if (Short.class.equals(type) || short.class.equals(type))
				return Short.parseShort(s);
			if (String.class.equals(type))
				return s;
			return BeanBoxException.throwEX("Unsupported @PARAM type:" + type);
		}
	}

}











class Caller {
	public BeanBoxContext ctx;
	public boolean required = true;
	public Set<Object> history;
	public Object result; 

	public Caller(BeanBoxContext ctx, boolean required, Set<Object> history, Object result) {
		this.result = result;
		this.ctx = ctx;
		this.required = required;
		this.history = history;
	}

	public <T> T getBean(Object target) {
		return ctx.getBean(target, required, history);
	}

	public <T> T get(Class<T> targetClass) {
		return ctx.getBean(targetClass, required, history);
	}

	public BeanBoxContext getCtx() {
		return ctx;
	}

	public void setCtx(BeanBoxContext ctx) {
		this.ctx = ctx;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	public Set<Object> getHistory() {
		return history;
	}

	public void setHistory(Set<Object> history) {
		this.history = history;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

}




 
















abstract class ReflectionUtils {

	




	private static final String CGLIB_RENAMED_METHOD_PREFIX = "CGLIB$";

	




	private static final Pattern CGLIB_RENAMED_METHOD_PATTERN = Pattern.compile("(.+)\\$\\d+");
 
	









	public static Field findField(Class<?> clazz, String name) {
		return findField(clazz, name, null);
	}

	











	public static Field findField(Class<?> clazz, String name, Class<?> type) {
		BeanBoxException.assureNotNull(clazz, "Inject field need BeanClass be set first, can not be null");
		BeanBoxException.assure(name != null || type != null, "Inject fields's name or type can not be null");
		Class<?> searchType = clazz;
		while (!Object.class.equals(searchType) && searchType != null) {
			Field[] fields = searchType.getDeclaredFields();
			for (Field field : fields) {
				if ((name == null || name.equals(field.getName())) && (type == null || type.equals(field.getType()))) {
					return field;
				}
			}
			searchType = searchType.getSuperclass();
		}
		return null;
	}

	













	public static void setField(Field field, Object target, Object value) {
		try {
			field.set(target, value);
		} catch (IllegalAccessException ex) {
			handleReflectionException(ex);
			throw new IllegalStateException(
					"Unexpected reflection exception - " + ex.getClass().getName() + ": " + ex.getMessage());
		}
	}

	












	public static Object getField(Field field, Object target) {
		try {
			return field.get(target);
		} catch (IllegalAccessException ex) {
			handleReflectionException(ex);
			throw new IllegalStateException(
					"Unexpected reflection exception - " + ex.getClass().getName() + ": " + ex.getMessage());
		}
	}

	











	public static Method findMethod(Class<?> clazz, String name) {
		return findMethod(clazz, name, new Class<?>[0]);
	}

	













	public static Method findMethod(Class<?> clazz, String name, Class<?>... paramTypes) {
		BeanBoxException.assureNotNull(clazz, "BeanClass must not be null");
		BeanBoxException.assureNotNull(name, "Method name must not be null");
		Class<?> searchType = clazz;
		while (searchType != null) {
			Method[] methods = (searchType.isInterface() ? searchType.getMethods() : searchType.getDeclaredMethods());
			for (Method method : methods) {
				if (name.equals(method.getName())
						&& (paramTypes == null || Arrays.equals(paramTypes, method.getParameterTypes()))) {
					return method;
				}
			}
			searchType = searchType.getSuperclass();
		}
		return null;
	}

	












	public static Object invokeMethod(Method method, Object target) {
		return invokeMethod(method, target, new Object[0]);
	}

	













	public static Object invokeMethod(Method method, Object target, Object... args) {
		try {
			return method.invoke(target, args);
		} catch (Exception ex) {
			handleReflectionException(ex);
		}
		throw new IllegalStateException("Should never get here");
	}

	











	public static Object invokeJdbcMethod(Method method, Object target) throws SQLException {
		return invokeJdbcMethod(method, target, new Object[0]);
	}

	













	public static Object invokeJdbcMethod(Method method, Object target, Object... args) throws SQLException {
		try {
			return method.invoke(target, args);
		} catch (IllegalAccessException ex) {
			handleReflectionException(ex);
		} catch (InvocationTargetException ex) {
			if (ex.getTargetException() instanceof SQLException) {
				throw (SQLException) ex.getTargetException();
			}
			handleInvocationTargetException(ex);
		}
		throw new IllegalStateException("Should never get here");
	}

	









	public static void handleReflectionException(Exception ex) {
		if (ex instanceof NoSuchMethodException) {
			throw new IllegalStateException("Method not found: " + ex.getMessage());
		}
		if (ex instanceof IllegalAccessException) {
			throw new IllegalStateException("Could not access method: " + ex.getMessage());
		}
		if (ex instanceof InvocationTargetException) {
			handleInvocationTargetException((InvocationTargetException) ex);
		}
		if (ex instanceof RuntimeException) {
			throw (RuntimeException) ex;
		}
		throw new UndeclaredThrowableException(ex);
	}

	









	public static void handleInvocationTargetException(InvocationTargetException ex) {
		rethrowRuntimeException(ex.getTargetException());
	}

	












	public static void rethrowRuntimeException(Throwable ex) {
		if (ex instanceof RuntimeException) {
			throw (RuntimeException) ex;
		}
		if (ex instanceof Error) {
			throw (Error) ex;
		}
		throw new UndeclaredThrowableException(ex);
	}

	












	public static void rethrowException(Throwable ex) throws Exception {
		if (ex instanceof Exception) {
			throw (Exception) ex;
		}
		if (ex instanceof Error) {
			throw (Error) ex;
		}
		throw new UndeclaredThrowableException(ex);
	}

	









	public static boolean declaresException(Method method, Class<?> exceptionType) {
		BeanBoxException.assureNotNull(method, "Method must not be null");
		Class<?>[] declaredExceptions = method.getExceptionTypes();
		for (Class<?> declaredException : declaredExceptions) {
			if (declaredException.isAssignableFrom(exceptionType)) {
				return true;
			}
		}
		return false;
	}

	





	public static boolean isPublicStaticFinal(Field field) {
		int modifiers = field.getModifiers();
		return (Modifier.isPublic(modifiers) && Modifier.isStatic(modifiers) && Modifier.isFinal(modifiers));
	}

	




	public static boolean isEqualsMethod(Method method) {
		if (method == null || !method.getName().equals("equals")) {
			return false;
		}
		Class<?>[] paramTypes = method.getParameterTypes();
		return (paramTypes.length == 1 && paramTypes[0] == Object.class);
	}

	




	public static boolean isHashCodeMethod(Method method) {
		return (method != null && method.getName().equals("hashCode") && method.getParameterTypes().length == 0);
	}

	




	public static boolean isToStringMethod(Method method) {
		return (method != null && method.getName().equals("toString") && method.getParameterTypes().length == 0);
	}

	


	public static boolean isObjectMethod(Method method) {
		if (method == null) {
			return false;
		}
		try {
			Object.class.getDeclaredMethod(method.getName(), method.getParameterTypes());
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	






	public static boolean isCglibRenamedMethod(Method renamedMethod) {
		String name = renamedMethod.getName();
		return (name.startsWith(CGLIB_RENAMED_METHOD_PREFIX) && CGLIB_RENAMED_METHOD_PATTERN
				.matcher(name.substring(CGLIB_RENAMED_METHOD_PREFIX.length())).matches());
	}

	








	public static void makeAccessible(Field field) {
		field.setAccessible(true);
	}

	








	public static void makeAccessible(Method method) {
		method.setAccessible(true);
	}

	








	public static void makeAccessible(Constructor<?> ctor) {
		ctor.setAccessible(true);
	}

	











	public static void doWithMethods(Class<?> clazz, MethodCallback mc) {
		doWithMethods(clazz, mc, null);
	}

	













	public static void doWithMethods(Class<?> clazz, MethodCallback mc, MethodFilter mf) {
		
		Method[] methods = clazz.getDeclaredMethods( );
		for (Method method : methods) {
			if (mf != null && !mf.matches(method)) {
				continue;
			}
			try {
				mc.doWith(method);
			} catch (IllegalAccessException ex) {
				throw new IllegalStateException("Not allowed to access method '" + method.getName() + "': " + ex);
			}
		}
		if (clazz.getSuperclass() != null) {
			doWithMethods(clazz.getSuperclass(), mc, mf);
		} else if (clazz.isInterface()) {
			for (Class<?> superIfc : clazz.getInterfaces()) {
				doWithMethods(superIfc, mc, mf);
			}
		}
	}

	





	public static Method[] getAllDeclaredMethods(Class<?> leafClass) {
		final List<Method> methods = new ArrayList<Method>(32);
		doWithMethods(leafClass, new MethodCallback() {
			public void doWith(Method method) {
				methods.add(method);
			}
		});
		return methods.toArray(new Method[methods.size()]);
	}

	







	public static Method[] getUniqueDeclaredMethods(Class<?> leafClass) {
		final List<Method> methods = new ArrayList<Method>(32);
		doWithMethods(leafClass, new MethodCallback() {
			public void doWith(Method method) {
				boolean knownSignature = false;
				Method methodBeingOverriddenWithCovariantReturnType = null;
				for (Method existingMethod : methods) {
					if (method.getName().equals(existingMethod.getName())
							&& Arrays.equals(method.getParameterTypes(), existingMethod.getParameterTypes())) {
						
						if (existingMethod.getReturnType() != method.getReturnType()
								&& existingMethod.getReturnType().isAssignableFrom(method.getReturnType())) {
							methodBeingOverriddenWithCovariantReturnType = existingMethod;
						} else {
							knownSignature = true;
						}
						break;
					}
				}
				if (methodBeingOverriddenWithCovariantReturnType != null) {
					methods.remove(methodBeingOverriddenWithCovariantReturnType);
				}
				if (!knownSignature && !isCglibRenamedMethod(method)) {
					methods.add(method);
				}
			}
		});
		return methods.toArray(new Method[methods.size()]);
	}

 

	








	public static void doWithFields(Class<?> clazz, FieldCallback fc) {
		doWithFields(clazz, fc, null);
	}

	










	public static void doWithFields(Class<?> clazz, FieldCallback fc, FieldFilter ff) {
		
		Class<?> targetClass = clazz;
		do {
			Field[] fields = targetClass.getDeclaredFields();
			for (Field field : fields) {
				if (ff != null && !ff.matches(field)) {
					continue;
				}
				try {
					fc.doWith(field);
				} catch (IllegalAccessException ex) {
					throw new IllegalStateException("Not allowed to access field '" + field.getName() + "': " + ex);
				}
			}
			targetClass = targetClass.getSuperclass();
		} while (targetClass != null && targetClass != Object.class);
	}

	



	public static void shallowCopyFieldState(final Object src, final Object dest) {
		if (src == null) {
			throw new IllegalArgumentException("Source for field copy cannot be null");
		}
		if (dest == null) {
			throw new IllegalArgumentException("Destination for field copy cannot be null");
		}
		if (!src.getClass().isAssignableFrom(dest.getClass())) {
			throw new IllegalArgumentException("Destination class [" + dest.getClass().getName()
					+ "] must be same or subclass as source class [" + src.getClass().getName() + "]");
		}
		doWithFields(src.getClass(), new FieldCallback() {
			public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {
				makeAccessible(field);
				Object srcValue = field.get(src);
				field.set(dest, srcValue);
			}
		}, COPYABLE_FIELDS);
	}

	


	public interface MethodCallback {

		





		void doWith(Method method) throws IllegalArgumentException, IllegalAccessException;
	}

	


	public interface MethodFilter {

		





		boolean matches(Method method);
	}

	


	public interface FieldCallback {

		





		void doWith(Field field) throws IllegalArgumentException, IllegalAccessException;
	}

	


	public interface FieldFilter {

		





		boolean matches(Field field);
	}

	


	public static FieldFilter COPYABLE_FIELDS = new FieldFilter() {

		public boolean matches(Field field) {
			return !(Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers()));
		}
	};

	


	public static MethodFilter NON_BRIDGED_METHODS = new MethodFilter() {

		public boolean matches(Method method) {
			return !method.isBridge();
		}
	};

	


	public static MethodFilter USER_DECLARED_METHODS = new MethodFilter() {

		public boolean matches(Method method) {
			return (!method.isBridge() && method.getDeclaringClass() != Object.class);
		}
	};

	
	public static List<Field> getSelfAndSuperClassFields(Class<?> clazz) {
		List<Field> fields = new ArrayList<Field>();
		for (Field field : clazz.getDeclaredFields())
			fields.add(field);

		Class<?> superclass = clazz.getSuperclass();
		while (superclass != null) {
			if (Object.class.equals(superclass)) {
				break;
			}
			for (Field field : superclass.getDeclaredFields())
				fields.add(field);
			superclass = superclass.getSuperclass();
		}
		return fields;
	} 
}











class BeanBox {

	
	protected Object target; 

	protected boolean pureValue = false; 

	protected Class<?> type; 

	protected boolean required = true;

	
	protected Class<?> beanClass; 

	protected Boolean singleton; 

	protected Constructor<?> constructor; 

	protected BeanBox[] constructorParams; 

	

	protected Method postConstruct; 

	protected Method preDestroy; 

	protected Map<Field, BeanBox> fieldInjects;

	protected Map<Method, BeanBox[]> methodInjects;

	protected Method createMethod; 

	protected Method configMethod; 

	
	protected Map<Method, List<Object>> methodAops;
	protected List<Object[]> aopRules;

	{
		if (!BeanBox.class.equals(this.getClass())) {
			Method m = ReflectionUtils.findMethod(this.getClass(), BeanBoxContext.CREATE_METHOD);
			if (m == null)
				m = ReflectionUtils.findMethod(this.getClass(), BeanBoxContext.CREATE_METHOD, Caller.class);
			if (m != null) {
				ReflectionUtils.makeAccessible(m);
				this.beanClass = m.getReturnType();
				this.createMethod = m;
			}

			m = ReflectionUtils.findMethod(this.getClass(), BeanBoxContext.CONFIG_METHOD, Object.class);
			if (m == null)
				m = ReflectionUtils.findMethod(this.getClass(), BeanBoxContext.CONFIG_METHOD, Object.class,
						Caller.class);
			if (m != null) {
				ReflectionUtils.makeAccessible(m);
				this.configMethod = m;
			}
		}
	}

	public BeanBox() { 
	}

	public BeanBox(Class<?> beanClass) { 
		this.beanClass = beanClass;
	}

	public Object getSingletonId() {
		if (singleton == null || !singleton || pureValue || target != null)
			return null;
		return this;
	}

	
	public <T> T getBean() {
		return BeanBoxContext.globalBeanBoxContext.getBean(this);
	}

	
	public static <T> T getBean(Object target) {
		return BeanBoxContext.globalBeanBoxContext.getBean(target);
	}

	
	public static <T> T getPrototypeBean(Class<?> beanClass) {
		return new BeanBox(beanClass).getBean();
	}

	
	public <T> T getBean(BeanBoxContext ctx) {
		return ctx.getBean(this);
	}

	
	public String getDebugInfo() {
		StringBuilder sb = new StringBuilder("\r\n========BeanBox Debug for " + this + "===========\r\n");
		sb.append("target=" + this.target).append("\r\n");
		sb.append("pureValue=" + this.pureValue).append("\r\n");
		sb.append("type=" + this.type).append("\r\n");
		sb.append("required=" + this.required).append("\r\n");
		sb.append("beanClass=" + this.beanClass).append("\r\n");
		sb.append("singleton=" + this.singleton).append("\r\n");
		sb.append("methodAops=" + this.methodAops).append("\r\n");
		sb.append("methodAopRules=" + this.aopRules).append("\r\n");
		sb.append("constructor=" + this.constructor).append("\r\n");
		sb.append("constructorParams=" + this.constructorParams).append("\r\n");
		sb.append("postConstructs=" + this.postConstruct).append("\r\n");
		sb.append("preDestorys=" + this.preDestroy).append("\r\n");
		sb.append("fieldInjects=" + this.fieldInjects).append("\r\n");
		sb.append("methodInjects=" + this.methodInjects).append("\r\n");
		sb.append("createMethod=" + this.createMethod).append("\r\n");
		sb.append("configMethod=" + this.configMethod).append("\r\n");
		sb.append("========BeanBox Debug Info End===========");
		return sb.toString();
	}

	protected void checkOrCreateFieldInjects() {
		if (fieldInjects == null)
			fieldInjects = new HashMap<Field, BeanBox>();
	}

	protected void checkOrCreateMethodInjects() {
		if (methodInjects == null)
			methodInjects = new HashMap<Method, BeanBox[]>();
	}

	protected void checkOrCreateMethodAops() {
		if (methodAops == null)
			methodAops = new HashMap<Method, List<Object>>();
	}

	protected void checkOrCreateMethodAopRules() { 
		if (aopRules == null)
			aopRules = new ArrayList<Object[]>();
	}

	protected void belowAreJavaConfigMethods_______________() {
	}

	
	public BeanBox setAsValue(Object value) {
		this.pureValue = true;
		this.target = value;
		return this;
	}

	
	public BeanBox setPrototype(boolean isPrototype) {
		this.singleton = !isPrototype;
		return this;
	}

	




	public BeanBox injectConstruct(Class<?> clazz, Object... configs) {
		this.beanClass = clazz;
		if (configs.length == 0) {
			this.constructor = BeanBoxUtils.getConstructor(clazz);
		} else {
			Class<?>[] paramTypes = new Class<?>[configs.length / 2];
			BeanBox[] params = new BeanBox[configs.length / 2];
			int mid = configs.length / 2;
			for (int i = 0; i < mid; i++)
				paramTypes[i] = (Class<?>) configs[i];
			for (int i = mid; i < configs.length; i++) {
				params[i - mid] = BeanBoxUtils.wrapParamToBox(configs[i]);
				params[i - mid].setType(paramTypes[i - mid]);
			}
			this.constructor = BeanBoxUtils.getConstructor(clazz, paramTypes);
			this.constructorParams = params;
		}
		return this;
	}

	



	public BeanBox injectMethod(String methodName, Object... configs) {
		checkOrCreateMethodInjects();
		Class<?>[] paramTypes = new Class<?>[configs.length / 2];
		BeanBox[] params = new BeanBox[configs.length / 2];
		int mid = configs.length / 2;
		for (int i = 0; i < mid; i++)
			paramTypes[i] = (Class<?>) configs[i];
		for (int i = mid; i < configs.length; i++) {
			params[i - mid] = BeanBoxUtils.wrapParamToBox(configs[i]);
			params[i - mid].setType(paramTypes[i - mid]);
		}
		Method m = ReflectionUtils.findMethod(beanClass, methodName, paramTypes);
		if (m != null)
			ReflectionUtils.makeAccessible(m);
		this.getMethodInjects().put(m, params);
		return this;
	}

	






	public synchronized BeanBox addMethodAop(Object aop, Method method) {
		checkOrCreateMethodAops();
		List<Object> aops = methodAops.get(method);
		if (aops == null) {
			aops = new ArrayList<Object>();
			methodAops.put(method, aops);
		}
		aops.add(BeanBoxUtils.checkAOP(aop));
		return this;
	}

	






	public synchronized BeanBox addMethodAop(Object aop, String methodName, Class<?>... paramTypes) {
		checkOrCreateMethodAops();
		Method m = ReflectionUtils.findMethod(beanClass, methodName, paramTypes);
		BeanBoxException.assureNotNull(m, "Not found method: '" + methodName + "'");
		addMethodAop(aop, m);
		return this;
	}

	







	public synchronized BeanBox addBeanAop(Object aop, String methodNameRegex) {
		checkOrCreateMethodAopRules();
		aopRules.add(new Object[] { BeanBoxUtils.checkAOP(aop), methodNameRegex });
		return this;
	}

	public BeanBox setPostConstruct(String methodName) {
		Method m = ReflectionUtils.findMethod(beanClass, methodName);
		this.setPostConstruct(m);
		return this;
	}

	public BeanBox setPreDestroy(String methodName) {
		Method m = ReflectionUtils.findMethod(beanClass, methodName);
		this.setPreDestroy(m);
		return this;
	}

	


	public BeanBox injectField(String fieldName, Object inject) {
		BeanBox box = BeanBoxUtils.wrapParamToBox(inject);
		checkOrCreateFieldInjects();
		Field f = ReflectionUtils.findField(beanClass, fieldName);
		box.setType(f.getType());
		ReflectionUtils.makeAccessible(f);
		this.getFieldInjects().put(f, box);
		return this;
	}

	
	public BeanBox setProperty(String fieldName, Object constValue) {
		return injectField(fieldName, constValue);
	}

	
	public BeanBox injectValue(String fieldName, Object constValue) {
		checkOrCreateFieldInjects();
		Field f = ReflectionUtils.findField(beanClass, fieldName);
		BeanBox inject = new BeanBox();
		inject.setTarget(constValue);
		inject.setType(f.getType());
		inject.setPureValue(true);
		ReflectionUtils.makeAccessible(f);
		this.getFieldInjects().put(f, inject);
		return this;
	}

	public boolean isSingleton() {
		return singleton != null && singleton;
	}

	protected void getterAndSetters_____________________() {
	}

	public Object getTarget() {
		return target;
	}

	public BeanBox setTarget(Object target) {
		this.target = target;
		return this;
	}

	public boolean isPureValue() {
		return pureValue;
	}

	public BeanBox setPureValue(boolean pureValue) {
		this.pureValue = pureValue;
		return this;
	}

	public Class<?> getType() {
		return type;
	}

	public BeanBox setType(Class<?> type) {
		this.type = type;
		return this;
	}

	public boolean isRequired() {
		return required;
	}

	public BeanBox setRequired(boolean required) {
		this.required = required;
		return this;
	}

	public Class<?> getBeanClass() {
		return beanClass;
	}

	public BeanBox setBeanClass(Class<?> beanClass) {
		this.beanClass = beanClass;
		return this;
	}

	public Boolean getSingleton() {
		return singleton;
	}

	public BeanBox setSingleton(Boolean singleton) {
		this.singleton = singleton;
		return this;
	}

	public Constructor<?> getConstructor() {
		return constructor;
	}

	public BeanBox setConstructor(Constructor<?> constructor) {
		this.constructor = constructor;
		return this;
	}

	public BeanBox[] getConstructorParams() {
		return constructorParams;
	}

	public BeanBox setConstructorParams(BeanBox[] constructorParams) {
		this.constructorParams = constructorParams;
		return this;
	}

	public Method getPostConstruct() {
		return postConstruct;
	}

	public BeanBox setPostConstruct(Method postConstruct) {
		this.postConstruct = postConstruct;
		return this;
	}

	public Method getPreDestroy() {
		return preDestroy;
	}

	public BeanBox setPreDestroy(Method preDestroy) {
		this.preDestroy = preDestroy;
		return this;
	}

	public Map<Field, BeanBox> getFieldInjects() {
		return fieldInjects;
	}

	public BeanBox setFieldInjects(Map<Field, BeanBox> fieldInjects) {
		this.fieldInjects = fieldInjects;
		return this;
	}

	public Map<Method, BeanBox[]> getMethodInjects() {
		return methodInjects;
	}

	public BeanBox setMethodInjects(Map<Method, BeanBox[]> methodInjects) {
		this.methodInjects = methodInjects;
		return this;
	}

	public Method getCreateMethod() {
		return createMethod;
	}

	public BeanBox setCreateMethod(Method createMethod) {
		this.createMethod = createMethod;
		return this;
	}

	public Method getConfigMethod() {
		return configMethod;
	}

	public BeanBox setConfigMethod(Method configMethod) {
		this.configMethod = configMethod;
		return this;
	}

	public Map<Method, List<Object>> getMethodAops() {
		return methodAops;
	}

	public BeanBox setMethodAops(Map<Method, List<Object>> methodAops) {
		this.methodAops = methodAops;
		return this;
	}

	public List<Object[]> getAopRules() {
		return aopRules;
	}

	public BeanBox setAopRules(List<Object[]> aopRules) {
		this.aopRules = aopRules;
		return this;
	}

}











@SuppressWarnings("all")
class ProxyBean implements CglibMethodInterceptor, Callback {
	protected Object[] box_ctx;

	protected ProxyBean(BeanBox box, BeanBoxContext ctx) {
		box_ctx = new Object[] { box, ctx };
	}

	@Override
	public Object intercept(Object obj, Method m, Object[] args, MethodProxy mprxy) throws Throwable {

		List<Object> allInters = new ArrayList<Object>();

		BeanBox box = (BeanBox) box_ctx[0];
		BeanBoxContext ctx = (BeanBoxContext) box_ctx[1];
		if (box.getMethodAops() != null) {
			List<Object> inters = box.getMethodAops().get(m);
			if (inters != null && !inters.isEmpty())
				allInters.addAll(inters);
		}

		if (box.getAopRules() != null) 
			for (Object[] entry : box.getAopRules()) {
				if (BeanBoxUtils.nameMatch((String) entry[1], m.getName()))
					allInters.add(entry[0]);
			}

		if (ctx.getAopRules() != null) {
			String thisClassName = obj.getClass().getName();

			for (Object[] aops : ctx.getAopRules()) {
				String classReg = (String) aops[1];
				if (BeanBoxUtils.nameMatch(classReg, thisClassName)) {
					String methodRegex = (String) aops[2];
					if (BeanBoxUtils.nameMatch(methodRegex, m.getName()))
						allInters.add(aops[0]);
				}
			}
		}

		if (allInters.isEmpty())
			return mprxy.invokeSuper(obj, args);
		
		MethodInterceptor inter = ctx.getBean(allInters.get(0));
		BeanBoxException.assureNotNull(inter);
		return inter.invoke(new MethodInvoc(obj, m, args, mprxy, allInters, ctx, 1));
	}

	
	public static class MethodInvoc implements MethodInvocation {
		private final Object obj;
		private final Method m;
		private final Object[] args;
		private final MethodProxy mprxy;
		private final List<Object> inters;
		private final BeanBoxContext ctx;
		private int count;

		protected MethodInvoc(Object obj, Method m, Object[] args, MethodProxy mprxy, List<Object> inters, BeanBoxContext ctx,
				int count) {
			this.obj = obj;	this.m = m;	this.args = args;	this.mprxy = mprxy;
			this.inters = inters;	this.ctx = ctx;	this.count = count;
		}
 
		public Object proceed() throws Throwable {
			if (count <= (inters.size() - 1)) { 
				MethodInterceptor inter = ctx.getBean(inters.get(count));
			    return inter.invoke(new MethodInvoc(obj, m, args, mprxy, inters, ctx, count + 1));
			}
			return mprxy.invokeSuper(obj, args);
		} 
		
		public final Object getThis() { return obj; }
 
		public final AccessibleObject getStaticPart() { return m; }
 
		public final Method getMethod() { return m; }
 
		public final Object[] getArguments() { return this.args != null ? this.args : new Object[0]; }
	}

}











class AopUtils {

	










	public static Object createProxyBean(Class<?> clazz, BeanBox box, BeanBoxContext ctx) {
		BeanBoxException.assureNotNull(clazz, "Try to create a proxy bean, but beanClass not found.");
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(clazz);
		if (box.getConstructorParams() != null && box.getConstructorParams().length > 0) {
			BeanBox[] boxes = box.getConstructorParams();
			Class<?>[] argsTypes = new Class<?>[boxes.length];
			Object[] realArgsValue = new Object[boxes.length];
			for (int i = 0; i < boxes.length; i++) {
				argsTypes[i] = boxes[i].getType();
				Object realValue = ctx.getBean(boxes[i]);
				if (realValue != null && realValue instanceof String)
					realValue = ctx.getValueTranslator().translate((String) realValue, boxes[i].getType());
				realArgsValue[i] = realValue;
			}
			enhancer.setCallback(new ProxyBean(box, ctx));
			return enhancer.create(argsTypes, realArgsValue);
		} else {
			enhancer.setCallback(new ProxyBean(box, ctx));
			return enhancer.create();
		}
	}

}











class BeanBoxContext {
	public static String CREATE_METHOD = "create"; 
	public static String CONFIG_METHOD = "config"; 

	protected static boolean globalNextAllowAnnotation = true; 
	protected static boolean globalNextAllowSpringJsrAnnotation = true; 
	protected static ValueTranslator globalNextValueTranslator = new ValueTranslator.DefaultValueTranslator(); 

	protected boolean allowAnnotation = globalNextAllowAnnotation;
	protected boolean allowSpringJsrAnnotation = globalNextAllowSpringJsrAnnotation;
	protected ValueTranslator valueTranslator = globalNextValueTranslator;

	protected Map<Object, Object> bindCache = new ConcurrentHashMap<Object, Object>();
	protected Map<Class<?>, BeanBox> beanBoxMetaCache = new ConcurrentHashMap<Class<?>, BeanBox>(); 
	protected Map<Object, Object> singletonCache = new ConcurrentHashMap<Object, Object>(); 

	protected static BeanBoxContext globalBeanBoxContext = new BeanBoxContext();

	
	protected List<Object[]> aopRules;

	public BeanBoxContext() {
		bind(Object.class, EMPTY.class);
		bind(String.class, EMPTY.class);
		bind(Integer.class, EMPTY.class);
		bind(Boolean.class, EMPTY.class);
		bind(Byte.class, EMPTY.class);
		bind(Long.class, EMPTY.class);
		bind(Short.class, EMPTY.class);
		bind(Float.class, EMPTY.class);
		bind(Double.class, EMPTY.class);
		bind(Character.class, EMPTY.class);
		bind(List.class, EMPTY.class);
		bind(Map.class, EMPTY.class);
		bind(Set.class, EMPTY.class);

		bind(int.class, EMPTY.class);
		bind(boolean.class, EMPTY.class);
		bind(byte.class, EMPTY.class);
		bind(long.class, EMPTY.class);
		bind(short.class, EMPTY.class);
		bind(float.class, EMPTY.class);
		bind(double.class, EMPTY.class);
		bind(char.class, EMPTY.class);
	}

	




	public static void reset() {
		globalBeanBoxContext.close();
		globalNextAllowAnnotation = true;
		globalNextAllowSpringJsrAnnotation = true;
		globalNextValueTranslator = new ValueTranslator.DefaultValueTranslator();
		CREATE_METHOD = "create";
		CONFIG_METHOD = "config";
		globalBeanBoxContext = new BeanBoxContext();

	}

	



	public void close() {
		for (Entry<Object, Object> singletons : singletonCache.entrySet()) {
			Object key = singletons.getKey();
			Object obj = singletons.getValue();
			if (key instanceof BeanBox) {
				BeanBox box = (BeanBox) key;
				if (box.getPreDestroy() != null)
					try {
						box.getPreDestroy().invoke(obj);
					} catch (Exception e) {
						
					}
			}
		}
		bindCache.clear();
		beanBoxMetaCache.clear();
		singletonCache.clear();
	}

	public <T> T getBean(Object obj) {
		return getBean(obj, true, null); 
	}

	public <T> T getInstance(Class<T> target) {
		return getBean(target, true, null);
	}

	public <T> T getBean(Object obj, boolean required) {
		return getBean(obj, required, null);
	}

	public <T> T getInstance(Class<T> target, boolean required) {
		return getBean(target, required, null);
	}

	@SuppressWarnings("unchecked")
	protected <T> T getBean(Object target, boolean required, Set<Object> history) {
		
		if (target != null && singletonCache.containsKey(target))
			return (T) singletonCache.get(target);

		if (target == null || EMPTY.class == target)
			return (T) notfoundOrException(target, required);

		if (target instanceof BeanBox) {
			BeanBox bx = (BeanBox) target;
			if (bx.isSingleton()) { 
				Object id = bx.getSingletonId();
				if (id != null) {
					Object existed = singletonCache.get(id);
					if (existed != null && EMPTY.class != existed)
						return (T) existed;
				}
			}
			if (history != null && history.contains(target)) {
				if (bx.getTarget() != null)
					BeanBoxException
							.throwEX("Fail to build bean, circular dependency found on target: " + bx.getTarget());
				if (bx.getBeanClass() != null)
					BeanBoxException.throwEX(
							"Fail to build bean, circular dependency found on beanClass: " + bx.getBeanClass());
				if (bx.getType() != null)
					BeanBoxException.throwEX("Fail to build bean, circular dependency found on type: " + bx.getType());
				if (bx.getCreateMethod() != null)
					BeanBoxException.throwEX(
							"Fail to build bean, circular dependency found on method: " + bx.getCreateMethod());
				BeanBoxException.throwEX("Fail to build bean, circular dependency found on: " + bx);
			}
		}

		Object result = null;
		if (history == null)
			history = new HashSet<Object>();
		history.add(target);
		if (bindCache.containsKey(target)) {
			result = getBean(bindCache.get(target), required, history);
		} else if (target instanceof BeanBox) { 
			result = getBeanFromBox((BeanBox) target, required, history);
		} else if (target instanceof Class) { 
			BeanBox box = BeanBoxUtils.getUniqueBeanBox(this, (Class<?>) target);
			result = getBean(box, required, history);
			if (EMPTY.class != result && box.isSingleton()) {
				singletonCache.put(target, result);
			}
		} else
			result = notfoundOrException(target, required);
		history.remove(target);
		return (T) result;
	}

	
	private Object getBeanFromBox(BeanBox box, boolean required, Set<Object> history) {
		
		BeanBoxException.assureNotNull(box, "Fail to build instance for a null beanBox");
		Object bean = null;
		if (box.isSingleton()) { 
			bean = singletonCache.get(box);
			if (bean != null)
				return bean;
		}

		if (box.isPureValue()) 
			return box.getTarget();
		if (box.getTarget() != null) {
			if (EMPTY.class != box.getTarget())
				return getBean(box.getTarget(), box.isRequired(), history);
			if (box.getType() != null)
				return getBean(box.getType(), box.isRequired(), history);
			else
				return notfoundOrException(box.getTarget(), box.isRequired());
		}

		boolean aopFound = false;
		if (box.getAopRules() != null || box.getMethodAops() != null)
			aopFound = true;
		else if (this.getAopRules() != null && box.getBeanClass() != null)
			for (Object[] aops : this.getAopRules()) 
				if (BeanBoxUtils.nameMatch((String) aops[1], box.getBeanClass().getName())) {
					aopFound = true;
					break;
				}
		if (aopFound)
			bean = AopUtils.createProxyBean(box.getBeanClass(), box, this);
		else if (box.getCreateMethod() != null) 
			try {
				Method m = box.getCreateMethod();
				if (m.getParameterTypes().length == 1) {
					bean = m.invoke(box, new Caller(this, required, history, null));
				} else if (m.getParameterTypes().length == 0)
					bean = m.invoke(box);
				else
					BeanBoxException.throwEX("Create method can only have 0 or 1 parameter");
				BeanBoxException.assureNotNull(bean, "Create method created a null object.");
			} catch (Exception e) {
				return BeanBoxException.throwEX(e);
			}
		else if (box.getConstructor() != null) { 
			if (box.getConstructorParams() != null && box.getConstructorParams().length > 0) {
				Object[] initargs = param2RealObjects(this, history, box.getConstructorParams());
				try {
					bean = box.getConstructor().newInstance(initargs);
				} catch (Exception e) {
					return BeanBoxException.throwEX(e);
				}
			} else 
				try {
					bean = box.getConstructor().newInstance();
				} catch (Exception e) {
					return BeanBoxException.throwEX(e);
				}
		} else if (box.getBeanClass() != null) { 
			if (EMPTY.class == box.getBeanClass())
				return notfoundOrException(EMPTY.class, required);
			try {
				bean = box.getBeanClass().newInstance();
			} catch (Exception e) {
				BeanBoxException.throwEX("Failed to call 0 parameter constructor of: " + box.getBeanClass(), e);
			}
		} else
			return notfoundOrException(null, required); 

		

		
		if (box.isSingleton()) {
			Object id = box.getSingletonId();
			if (id != null)
				singletonCache.put(box, bean);
		} 

		if (box.getConfigMethod() != null) {
			try {
				Method m = box.getConfigMethod();
				if (m.getParameterTypes().length == 2)
					m.invoke(box, bean, new Caller(this, required, history, bean));
				else if (m.getParameterTypes().length == 1)
					m.invoke(box, bean);
				else
					BeanBoxException.throwEX("Config method can only have 1 or 2 parameters");
			} catch (Exception e) {
				return BeanBoxException.throwEX(e);
			}
		}

		if (box.getPostConstruct() != null) 
			ReflectionUtils.invokeMethod(box.getPostConstruct(), bean);

		if (box.getFieldInjects() != null) 
			for (Entry<Field, BeanBox> entry : box.getFieldInjects().entrySet()) {
				Field f = entry.getKey();
				BeanBox b = entry.getValue();
				Object fieldValue = this.getBeanFromBox(b, false, history);
				if (EMPTY.class == fieldValue) {
					if (b.isRequired())
						BeanBoxException.throwEX("Not found required value for field: " + f.getName() + " in "
								+ f.getDeclaringClass().getName());
				} else {
					if (fieldValue != null && fieldValue instanceof String)
						fieldValue = this.valueTranslator.translate((String) fieldValue, b.getType());
					ReflectionUtils.setField(f, bean, fieldValue);
				}
			}

		if (box.getMethodInjects() != null) { 
			for (Entry<Method, BeanBox[]> methods : box.getMethodInjects().entrySet()) {
				Method m = methods.getKey();
				BeanBox[] paramBoxs = methods.getValue();
				if (paramBoxs != null && paramBoxs.length > 0) {
					Object[] methodParams = param2RealObjects(this, history, paramBoxs);
					ReflectionUtils.invokeMethod(m, bean, methodParams);
				} else 
					ReflectionUtils.invokeMethod(m, bean);
			}
		}
		return bean;
	}

	public BeanBoxContext bind(Object shortcut, Object target) {
		BeanBoxException.assureNotNull(shortcut, "bind shorcut can not be empty");
		bindCache.put(shortcut, target);
		return this;
	}

	public BeanBoxContext addContextAop(Object aop, String classNameRegex, String methodNameRegex) {
		if (aopRules == null)
			aopRules = new ArrayList<Object[]>();
		aopRules.add(new Object[] { BeanBoxUtils.checkAOP(aop), classNameRegex, methodNameRegex });
		return this;
	}

	public BeanBoxContext addContextAop(Object aop, Class<?> clazz, String methodNameRegex) {
		return addContextAop(aop, clazz.getName() + "*", methodNameRegex);
	}

	public BeanBox getBeanBox(Class<?> clazz) {
		return BeanBoxUtils.getUniqueBeanBox(this, clazz);
	}

	protected void staticMethods________________________() {
	}

	private static Object[] param2RealObjects(BeanBoxContext ctx, Set<Object> history, BeanBox[] boxes) {
		Object[] result = new Object[boxes.length];
		for (int i = 0; i < boxes.length; i++) {
			result[i] = ctx.getBeanFromBox(boxes[i], true, history);
			if (result[i] != null && result[i] instanceof String)
				result[i] = ctx.valueTranslator.translate((String) result[i], boxes[i].getType());
		}
		return result;
	}

	private static Object notfoundOrException(Object target, boolean required) {
		if (required)
			return BeanBoxException.throwEX("BeanBox target not found: " + target);
		else
			return EMPTY.class;
	}

	protected void notExistMethod() {

	}

	protected static Method NOT_EXIST_METHOD = null; 

	static {
		try {
			NOT_EXIST_METHOD = BeanBoxContext.class.getDeclaredMethod("notExistMethod");
		} catch (Exception e) {
		}
	}

	protected void staticGetterAndSetters________________________() {
	}

	public static BeanBoxContext getGlobalBeanBoxContext() {
		return globalBeanBoxContext;
	}

	public static void setGlobalBeanBoxContext(BeanBoxContext globalBeanBoxContext) {
		BeanBoxContext.globalBeanBoxContext = globalBeanBoxContext;
	}

	public static boolean isGlobalNextAllowAnnotation() {
		return globalNextAllowAnnotation;
	}

	public static void setGlobalNextAllowAnnotation(boolean globalNextAllowAnnotation) {
		BeanBoxContext.globalNextAllowAnnotation = globalNextAllowAnnotation;
	}

	public static boolean isGlobalNextAllowSpringJsrAnnotation() {
		return globalNextAllowSpringJsrAnnotation;
	}

	public static void setGlobalNextAllowSpringJsrAnnotation(boolean globalNextAllowSpringJsrAnnotation) {
		BeanBoxContext.globalNextAllowSpringJsrAnnotation = globalNextAllowSpringJsrAnnotation;
	}

	public static ValueTranslator getGlobalNextParamTranslator() {
		return globalNextValueTranslator;
	}

	public static void setGlobalNextParamTranslator(ValueTranslator globalNextParamTranslator) {
		BeanBoxContext.globalNextValueTranslator = globalNextParamTranslator;
	}

	public static Method getNotExistMethod() {
		return NOT_EXIST_METHOD;
	}

	public static void setNotExistMethod(Method notExistMethod) {
		BeanBoxContext.NOT_EXIST_METHOD = notExistMethod;
	}

	protected void getterAndSetters________________________() {
	}

	public boolean isAllowAnnotation() {
		return allowAnnotation;
	}

	public BeanBoxContext setAllowAnnotation(boolean allowAnnotation) {
		this.allowAnnotation = allowAnnotation;
		return this;
	}

	public boolean isAllowSpringJsrAnnotation() {
		return allowSpringJsrAnnotation;
	}

	public BeanBoxContext setAllowSpringJsrAnnotation(boolean allowSpringJsrAnnotation) {
		this.allowSpringJsrAnnotation = allowSpringJsrAnnotation;
		return this;
	}

	public ValueTranslator getValueTranslator() {
		return valueTranslator;
	}

	public BeanBoxContext setValueTranslator(ValueTranslator valueTranslator) {
		this.valueTranslator = valueTranslator;
		return this;
	}

	public Map<Object, Object> getBindCache() {
		return bindCache;
	}

	public BeanBoxContext setBindCache(Map<Object, Object> bindCache) {
		this.bindCache = bindCache;
		return this;
	}

	public Map<Class<?>, BeanBox> getBeanBoxMetaCache() {
		return beanBoxMetaCache;
	}

	public BeanBoxContext setBeanBoxMetaCache(Map<Class<?>, BeanBox> beanBoxMetaCache) {
		this.beanBoxMetaCache = beanBoxMetaCache;
		return this;
	}

	public Map<Object, Object> getSingletonCache() {
		return singletonCache;
	}

	public BeanBoxContext setSingletonCache(Map<Object, Object> singletonCache) {
		this.singletonCache = singletonCache;
		return this;
	}

	public List<Object[]> getAopRules() {
		return aopRules;
	}

	public BeanBoxContext setAopRules(List<Object[]> aopRules) {
		this.aopRules = aopRules;
		return this;
	}

}










class BeanBoxUtils {

	


	public static BeanBox getUniqueBeanBox(BeanBoxContext ctx, Class<?> clazz) {
		BeanBoxException.assureNotNull(clazz, "Target class can not be null");
		BeanBox box = ctx.beanBoxMetaCache.get(clazz);
		if (box != null)
			return box;
		if (BeanBox.class.isAssignableFrom(clazz))
			try {
				box = (BeanBox) clazz.newInstance();
				if (box.singleton == null)
					box.singleton = true;
			} catch (Exception e) {
				BeanBoxException.throwEX(e);
			}
		else
			box = doCreateBeanBox(ctx, clazz);
		ctx.beanBoxMetaCache.put(clazz, box);
		return box;
	}

	public static Constructor<?> getConstructor(Class<?> clazz, Class<?>... paramTypes) {
		try {
			return clazz.getConstructor(paramTypes);
		} catch (SecurityException e) {
			throw new IllegalStateException("Security exception found for Constructor: " + e.getMessage());
		} catch (NoSuchMethodException e) {
			throw new IllegalStateException("Constructor not found: " + e.getMessage());
		}
	}

	protected static void belowArePrivateStaticMethods__________________________() {
	}

	
	
	// ORIGINAL CODESEARCHNET METHOD — START
	
	private static BeanBox doCreateBeanBox(BeanBoxContext ctx, Class<?> clazz) {
		BeanBox box = new BeanBox();
		box.setBeanClass(clazz);
		box.setSingleton(true);

		if (!ctx.isAllowAnnotation())
			return box;
		boolean allowSpringJsrAnno = ctx.allowSpringJsrAnnotation;

		
		if (checkAnnoExist(clazz, PROTOTYPE.class))
			box.setSingleton(false);
		else if (allowSpringJsrAnno) {
			Map<String, Object> m = getAnnoAsMap(clazz, "org.springframework.context.annotation.Scope");
			if (m != null)
				for (Entry<String, Object> entry : m.entrySet())
					if ("value".equals(entry.getKey())) {
						if ("prototype".equalsIgnoreCase(String.valueOf(entry.getValue())))
							box.setSingleton(false);
						else if ("singleton".equalsIgnoreCase(String.valueOf(entry.getValue())))
							box.setSingleton(true);
						else
							BeanBoxException.throwEX("'prototype' or 'singleton' required in @Scope annotation");
					}
		}

		
		Object[] v = getInjectAnnotationAsArray(clazz, allowSpringJsrAnno);
		if (v != null) {
			box.setTarget(v[0]);
			box.setPureValue((Boolean) v[1]);
			box.setRequired((Boolean) v[2]);
		}

		
		Annotation[] annos = clazz.getAnnotations();
		for (Annotation anno : annos) {
			if (anno.annotationType().isAnnotationPresent(AOP.class)) {
				Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
				Object aop = annoMap.get("value");
				String methodNameRule = (String) annoMap.get("method");
				if (methodNameRule != null && methodNameRule.length() > 0 && aop != null)
					box.addBeanAop(aop, methodNameRule);
			}
		}

		
		Constructor<?>[] constrs = clazz.getConstructors();
		for (Constructor<?> constr : constrs) {
			v = getInjectAnnotationAsArray(constr, allowSpringJsrAnno);
			if (v != null) {
				box.setBeanClass(clazz);
				if (v[0] != null && EMPTY.class != v[0]) {
					BeanBox inject = new BeanBox();
					inject.setTarget(v[0]);
					inject.setPureValue((Boolean) v[1]);
					inject.setRequired((Boolean) v[2]);
					inject.setType(constr.getParameterTypes()[0]);
					box.setConstructor(constr);
					box.setConstructorParams(new BeanBox[] { inject });
				} else { 
					BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(constr, allowSpringJsrAnno);
					box.setConstructor(constr);
					box.setConstructorParams(paramInjects);
				}
			}
		}

		
		
		for (Field f : ReflectionUtils.getSelfAndSuperClassFields(clazz)) {
			v = getInjectAnnotationAsArray(f, allowSpringJsrAnno);
			if (v != null) {
				box.checkOrCreateFieldInjects();
				BeanBox inject = new BeanBox();
				inject.setTarget(v[0]);
				inject.setPureValue((Boolean) v[1]);
				inject.setRequired((Boolean) v[2]);
				inject.setType(f.getType());
				ReflectionUtils.makeAccessible(f);
				box.getFieldInjects().put(f, inject);
			}
		}

		
		Method[] methods = ReflectionUtils.getAllDeclaredMethods(clazz); 
		for (Method m : methods) { 
			
			if (m.getAnnotation(POSTCONSTRUCT.class) != null || m.getAnnotation(PostConstruct.class) != null) {
				if (m.getParameterTypes().length > 0)
					BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
				ReflectionUtils.makeAccessible(m);
				box.setPostConstruct(m);
			}
			if (m.getAnnotation(PREDESTROY.class) != null || m.getAnnotation(PreDestroy.class) != null) {
				if (m.getParameterTypes().length > 0)
					BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
				ReflectionUtils.makeAccessible(m);
				box.setPreDestroy(m);
			}

			
			Annotation[] mtdAnnos = m.getAnnotations();
			for (Annotation anno : mtdAnnos)
				if (anno.annotationType().isAnnotationPresent(AOP.class)) {
					Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
					Object aop = annoMap.get("value");
					if (aop != null)
						box.addMethodAop(aop, m);
				}

			
			v = getInjectAnnotationAsArray(m, allowSpringJsrAnno);
			if (v != null) {
				ReflectionUtils.makeAccessible(m);
				BeanBox oneParam = new BeanBox();
				oneParam.setTarget(v[0]);
				oneParam.setPureValue((Boolean) v[1]);
				oneParam.setRequired((Boolean) v[2]);
				boolean haveOneParameter = v[0] != null && EMPTY.class != v[0];
				if (haveOneParameter)
					oneParam.setType(m.getParameterTypes()[0]); 
				
				box.checkOrCreateMethodInjects();
				if (haveOneParameter) 
					box.getMethodInjects().put(m, new BeanBox[] { oneParam });
				else { 
					BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(m, allowSpringJsrAnno);
					box.getMethodInjects().put(m, paramInjects);
				}
			}
		}
		return box;

	}
	
	// ORIGINAL CODESEARCHNET METHOD — END
	

	



	private static Object[] getInjectAnnotationAsArray(Object target, boolean allowSpringJsrAnno) {
		Annotation[] anno = getAnnotations(target);
		return getInjectAsArray(anno, allowSpringJsrAnno);
	}

	



	private static Object[] getInjectAsArray(Annotation[] anno, boolean allowSpringJsrAnno) {
		for (Annotation a : anno) {
			Class<? extends Annotation> type = a.annotationType();
			if (INJECT.class.equals(type))
				return new Object[] { ((INJECT) a).value(), ((INJECT) a).pureValue(), ((INJECT) a).required(), null };
			if (VALUE.class.equals(type))
				return new Object[] { ((VALUE) a).value(), ((VALUE) a).pureValue(), ((VALUE) a).required(), null };
			if (allowSpringJsrAnno) {
				if (Inject.class.equals(type))
					return new Object[] { EMPTY.class, false, true, null };
				if (Autowired.class.equals(type))
					return new Object[] { EMPTY.class, false, ((Autowired) a).required(), null };
			}
		}
		return null;
	}

	
	private static BeanBox[] getParameterInjectAsBeanBoxArray(Object o, boolean allowSpringJsrAnno) {
		Annotation[][] annoss = null;
		Class<?>[] paramTypes = null;
		if (o instanceof Method) {
			annoss = ((Method) o).getParameterAnnotations();
			paramTypes = ((Method) o).getParameterTypes();
		} else if (o instanceof Constructor) {
			annoss = ((Constructor<?>) o).getParameterAnnotations();
			paramTypes = ((Constructor<?>) o).getParameterTypes();
		} else
			return BeanBoxException.throwEX("Only method or Constructor are allowed at here for:" + o);
		BeanBox[] beanBoxes = new BeanBox[annoss.length];
		for (int i = 0; i < annoss.length; i++) {
			Annotation[] annos = annoss[i];
			Object[] v = getInjectAsArray(annos, allowSpringJsrAnno);
			BeanBox inject = new BeanBox();
			if (v != null) { 
				inject.setTarget(v[0]);
				inject.setPureValue((Boolean) v[1]);
				inject.setRequired((Boolean) v[2]);
				inject.setType(paramTypes[i]);
			} else 
				inject.setTarget(paramTypes[i]);
			beanBoxes[i] = inject;
		}
		return beanBoxes;
	}

	
	private static Annotation[] getAnnotations(Object targetClass) {
		if (targetClass instanceof Field)
			return ((Field) targetClass).getAnnotations();
		else if (targetClass instanceof Method)
			return ((Method) targetClass).getAnnotations();
		else if (targetClass instanceof Constructor)
			return ((Constructor<?>) targetClass).getAnnotations();
		else if (targetClass instanceof Class)
			return ((Class<?>) targetClass).getAnnotations();
		else
			return BeanBoxException.throwEX("targetClass should be Field, Method, Constructor or Class");
	}

	
	private static Map<String, Object> getAnnoAsMap(Object targetClass, String annoFullName) {
		Annotation[] anno = getAnnotations(targetClass);
		for (Annotation a : anno) {
			Class<? extends Annotation> type = a.annotationType();
			if (annoFullName.equals(type.getName()))
				return changeAnnotationValuesToMap(a);
		}
		return null;
	}

	
	private static boolean checkAnnoExist(Object targetClass, Class<?> annoClass) {
		Annotation[] anno = getAnnotations(targetClass);
		for (Annotation annotation : anno) {
			Class<? extends Annotation> type = annotation.annotationType();
			if (annoClass.equals(type))
				return true;
		}
		return false;
	}

	
	protected static Map<String, Object> changeAnnotationValuesToMap(Annotation annotation) {
		Map<String, Object> result = new HashMap<String, Object>();
		for (Method method : annotation.annotationType().getDeclaredMethods())
			try {
				result.put(method.getName(), method.invoke(annotation, (Object[]) null));
			} catch (Exception e) {
			}
		return result;
	}

	





	public static boolean nameMatch(String regex, String name) {
		if (regex == null || regex.length() == 0 || name == null || name.length() == 0)
			return false;
		if ('*' == (regex.charAt(0))) {
			return name.endsWith(regex.substring(1));
		} else if (regex.endsWith("*")) {
			return name.startsWith(regex.substring(0, regex.length() - 1));
		} else {
			int starPos = regex.indexOf('*');
			if (-1 == starPos)
				return regex.equals(name);
			return name.startsWith(regex.substring(0, starPos)) && name.endsWith(regex.substring(starPos + 1));
		}
	}

	



	protected static Object checkAOP(Object aop) {
		if (aop != null && aop instanceof MethodInterceptor)
			return new BeanBox().setTarget(aop).setPureValue(true);
		else
			return aop;
	}

	



	protected static BeanBox wrapParamToBox(Object param) {
		if (param != null) {
			if (param instanceof Class)
				return new BeanBox().setTarget(param);
			if (param instanceof BeanBox)
				return (BeanBox) param;
		}
		return new BeanBox().setAsValue(param);
	}

 

}
