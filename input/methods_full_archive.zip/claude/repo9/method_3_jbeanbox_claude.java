





































import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;









public class method_3_jbeanbox_claude implements Opcodes {

    



    static class CountingAnalyzer extends Analyzer<BasicValue> {
        int edges;
        int exceptionEdges;

        CountingAnalyzer() {
            super(new BasicInterpreter());
        }

        protected void newControlFlowEdge(int insn, int successor) {
            edges++;
        }

        protected boolean newControlFlowExceptionEdge(int insn, TryCatchBlockNode tcb) {
            exceptionEdges++;
            return super.newControlFlowExceptionEdge(insn, tcb);
        }
    }

    
    
    

    
    static MethodNode maxMethod() {
        MethodNode m = new MethodNode(ACC_PUBLIC | ACC_STATIC, "max", "(II)I");
        LabelNode second = new LabelNode();
        m.instructions.add(new VarInsnNode(ILOAD, 0));
        m.instructions.add(new VarInsnNode(ILOAD, 1));
        m.instructions.add(new JumpInsnNode(IF_ICMPLT, second));
        m.instructions.add(new VarInsnNode(ILOAD, 0));
        m.instructions.add(new InsnNode(IRETURN));
        m.instructions.add(second);
        m.instructions.add(new VarInsnNode(ILOAD, 1));
        m.instructions.add(new InsnNode(IRETURN));
        m.maxLocals = 2;
        m.maxStack = 2;
        return m;
    }

    
    static MethodNode accumulateMethod() {
        MethodNode m = new MethodNode(ACC_PUBLIC | ACC_STATIC, "accumulate", "(JD)J");
        LabelNode loop = new LabelNode();
        LabelNode done = new LabelNode();
        m.instructions.add(new VarInsnNode(LLOAD, 0));
        m.instructions.add(new VarInsnNode(LSTORE, 4)); 
        m.instructions.add(new InsnNode(ICONST_0));
        m.instructions.add(new VarInsnNode(ISTORE, 6)); 
        m.instructions.add(loop);
        m.instructions.add(new VarInsnNode(ILOAD, 6));
        m.instructions.add(new IntInsnNode(BIPUSH, 10));
        m.instructions.add(new JumpInsnNode(IF_ICMPGE, done));
        m.instructions.add(new VarInsnNode(LLOAD, 4));
        m.instructions.add(new VarInsnNode(DLOAD, 2));
        m.instructions.add(new InsnNode(D2L));
        m.instructions.add(new InsnNode(LADD));
        m.instructions.add(new VarInsnNode(LSTORE, 4));
        m.instructions.add(new IincInsnNode(6, 1));
        m.instructions.add(new JumpInsnNode(GOTO, loop));
        m.instructions.add(done);
        m.instructions.add(new VarInsnNode(LLOAD, 4));
        m.instructions.add(new InsnNode(LRETURN));
        m.maxLocals = 7;
        m.maxStack = 4;
        return m;
    }

    
    static MethodNode tableSwitchMethod() {
        MethodNode m = new MethodNode(ACC_PUBLIC | ACC_STATIC, "classify", "(I)Ljava/lang/String;");
        LabelNode one = new LabelNode();
        LabelNode two = new LabelNode();
        LabelNode three = new LabelNode();
        LabelNode other = new LabelNode();
        m.instructions.add(new VarInsnNode(ILOAD, 0));
        m.instructions.add(new TableSwitchInsnNode(1, 3, other, new LabelNode[] { one, two, three }));
        m.instructions.add(one);
        m.instructions.add(new LdcInsnNode("one"));
        m.instructions.add(new InsnNode(ARETURN));
        m.instructions.add(two);
        m.instructions.add(new LdcInsnNode("two"));
        m.instructions.add(new InsnNode(ARETURN));
        m.instructions.add(three);
        m.instructions.add(new LdcInsnNode("three"));
        m.instructions.add(new InsnNode(ARETURN));
        m.instructions.add(other);
        m.instructions.add(new InsnNode(ACONST_NULL));
        m.instructions.add(new InsnNode(ARETURN));
        m.maxLocals = 1;
        m.maxStack = 1;
        return m;
    }

    
    static MethodNode lookupSwitchMethod() {
        MethodNode m = new MethodNode(ACC_PUBLIC | ACC_STATIC, "lookup", "(I)I");
        LabelNode ten = new LabelNode();
        LabelNode twenty = new LabelNode();
        LabelNode other = new LabelNode();
        m.instructions.add(new VarInsnNode(ILOAD, 0));
        m.instructions.add(new LookupSwitchInsnNode(other, new int[] { 10, 20 },
                new LabelNode[] { ten, twenty }));
        m.instructions.add(ten);
        m.instructions.add(new InsnNode(ICONST_1));
        m.instructions.add(new InsnNode(IRETURN));
        m.instructions.add(twenty);
        m.instructions.add(new InsnNode(ICONST_2));
        m.instructions.add(new InsnNode(IRETURN));
        m.instructions.add(other);
        m.instructions.add(new InsnNode(ICONST_M1));
        m.instructions.add(new InsnNode(IRETURN));
        m.maxLocals = 1;
        m.maxStack = 1;
        return m;
    }

    
    static MethodNode tryCatchMethod() {
        MethodNode m = new MethodNode(ACC_PUBLIC | ACC_STATIC, "parse", "(Ljava/lang/String;)I");
        LabelNode start = new LabelNode();
        LabelNode end = new LabelNode();
        LabelNode handler = new LabelNode();
        m.instructions.add(start);
        m.instructions.add(new VarInsnNode(ALOAD, 0));
        m.instructions.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Integer", "parseInt",
                "(Ljava/lang/String;)I", false));
        m.instructions.add(new InsnNode(IRETURN));
        m.instructions.add(end);
        m.instructions.add(handler);
        m.instructions.add(new VarInsnNode(ASTORE, 1));
        m.instructions.add(new InsnNode(ICONST_M1));
        m.instructions.add(new InsnNode(IRETURN));
        m.tryCatchBlocks.add(new TryCatchBlockNode(start, end, handler, "java/lang/NumberFormatException"));
        m.tryCatchBlocks.add(new TryCatchBlockNode(start, end, handler, null)); 
        m.maxLocals = 2;
        m.maxStack = 1;
        return m;
    }

    
    static MethodNode subroutineMethod() {
        MethodNode m = new MethodNode(ACC_PUBLIC | ACC_STATIC, "withSubroutine", "()V");
        LabelNode sub = new LabelNode();
        m.instructions.add(new JumpInsnNode(JSR, sub));
        m.instructions.add(new InsnNode(RETURN));
        m.instructions.add(sub);
        m.instructions.add(new VarInsnNode(ASTORE, 0)); 
        m.instructions.add(new InsnNode(NOP));
        m.instructions.add(new VarInsnNode(RET, 0));
        m.maxLocals = 1;
        m.maxStack = 1;
        return m;
    }

    
    static MethodNode unreachableMethod() {
        MethodNode m = new MethodNode(ACC_PUBLIC | ACC_STATIC, "dead", "()I");
        m.instructions.add(new InsnNode(ICONST_0));
        m.instructions.add(new InsnNode(IRETURN));
        m.instructions.add(new InsnNode(ICONST_1));
        m.instructions.add(new InsnNode(IRETURN));
        m.maxLocals = 0;
        m.maxStack = 1;
        return m;
    }

    
    
    

    public static void main(String[] args) throws Exception {
        title("METHOD 3  |  Analyzer<V>.analyze(String owner, MethodNode m)");

        report("demo/Sample", maxMethod());
        report("demo/Sample", accumulateMethod());
        report("demo/Sample", tableSwitchMethod());
        report("demo/Sample", lookupSwitchMethod());
        report("demo/Sample", tryCatchMethod());
        report("demo/Sample", subroutineMethod());
        report("demo/Sample", unreachableMethod());

        section("abstract and native methods - the ACC_ABSTRACT / ACC_NATIVE early return");
        MethodNode abstractMethod = new MethodNode(ACC_PUBLIC | ACC_ABSTRACT, "abstractMethod", "(I)I");
        MethodNode nativeMethod = new MethodNode(ACC_PUBLIC | ACC_NATIVE, "nativeMethod", "(I)I");
        for (MethodNode m : new MethodNode[] { abstractMethod, nativeMethod }) {
            Frame<BasicValue>[] frames = new Analyzer<BasicValue>(new BasicInterpreter()).analyze("demo/Sample", m);
            System.out.println("   " + m.name + m.desc + "  ->  frames.length = " + frames.length
                    + "   (analyze() returned immediately, no data flow was performed)");
        }

        section("invalid byte code - the AnalyzerException branch");
        MethodNode broken = new MethodNode(ACC_PUBLIC | ACC_STATIC, "broken", "()V");
        broken.instructions.add(new InsnNode(IADD)); 
        broken.instructions.add(new InsnNode(RETURN));
        broken.maxLocals = 0;
        broken.maxStack = 2;
        try {
            new Analyzer<BasicValue>(new BasicInterpreter()).analyze("demo/Sample", broken);
            System.out.println("   !! the expected AnalyzerException was not thrown");
        } catch (AnalyzerException e) {
            System.out.println("   expected AnalyzerException: " + e.getMessage());
        }

        section("RET outside of a sub routine - the second AnalyzerException branch");
        MethodNode strayRet = new MethodNode(ACC_PUBLIC | ACC_STATIC, "strayRet", "()V");
        strayRet.instructions.add(new VarInsnNode(RET, 0));
        strayRet.maxLocals = 1;
        strayRet.maxStack = 1;
        try {
            new Analyzer<BasicValue>(new BasicInterpreter()).analyze("demo/Sample", strayRet);
            System.out.println("   !! the expected AnalyzerException was not thrown");
        } catch (AnalyzerException e) {
            System.out.println("   expected AnalyzerException: " + e.getMessage());
        }

        title("END OF METHOD 3 SCENARIOS");
    }

    static void report(String owner, MethodNode m) throws AnalyzerException {
        section("analysing " + m.name + m.desc);
        CountingAnalyzer analyzer = new CountingAnalyzer();
        Frame<BasicValue>[] frames = analyzer.analyze(owner, m);

        System.out.println("   instructions        : " + m.instructions.size());
        System.out.println("   maxLocals/maxStack  : " + m.maxLocals + " / " + m.maxStack);
        System.out.println("   try-catch blocks    : " + m.tryCatchBlocks.size());
        System.out.println("   frames returned     : " + frames.length);
        System.out.println("   control flow edges  : " + analyzer.edges);
        System.out.println("   exception edges     : " + analyzer.exceptionEdges);

        int reachable = 0;
        int deepest = 0;
        List<String> notes = new ArrayList<String>();
        for (int i = 0; i < frames.length; i++) {
            if (frames[i] != null) {
                reachable++;
                deepest = Math.max(deepest, frames[i].getStackSize());
            } else {
                notes.add("instruction " + i + " is unreachable");
            }
            AbstractInsnNode insn = m.instructions.get(i);
            if (insn.getType() == AbstractInsnNode.TABLESWITCH_INSN) {
                notes.add("TABLESWITCH at " + i);
            } else if (insn.getType() == AbstractInsnNode.LOOKUPSWITCH_INSN) {
                notes.add("LOOKUPSWITCH at " + i);
            } else if (insn.getOpcode() == JSR) {
                notes.add("JSR at " + i + " -> sub routine analysis");
            } else if (insn.getOpcode() == RET) {
                notes.add("RET at " + i + " -> merge back into every caller");
            }
        }
        System.out.println("   reachable / unreachable instructions : " + reachable + " / "
                + (frames.length - reachable));
        System.out.println("   deepest operand stack computed       : " + deepest);
        if (!notes.isEmpty()) {
            System.out.println("   notes               : " + notes);
        }
        for (Object o : m.tryCatchBlocks) {
            TryCatchBlockNode tcb = (TryCatchBlockNode) o;
            int at = m.instructions.indexOf(tcb.handler);
            System.out.println("   handler for " + (tcb.type == null ? "any Throwable" : tcb.type)
                    + " at instruction " + at + ", frame on entry = " + describe(frames[at]));
        }
        int shown = 0;
        for (int i = 0; i < frames.length && shown < 3; i++) {
            if (frames[i] == null) {
                continue;
            }
            System.out.println("   frame[" + i + "] " + describe(frames[i]));
            shown++;
        }
        Type[] argTypes = Type.getArgumentTypes(m.desc);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < argTypes.length; i++) {
            sb.append(i > 0 ? ", " : "").append(argTypes[i].getClassName());
        }
        System.out.println("   arguments seeded into frame 0        : [" + sb + "] , returns "
                + Type.getReturnType(m.desc).getClassName());
    }

    static String describe(Frame<BasicValue> f) {
        if (f == null) {
            return "<unreachable>";
        }
        StringBuilder locals = new StringBuilder("locals=[");
        for (int i = 0; i < f.getLocals(); i++) {
            locals.append(i > 0 ? "," : "").append(f.getLocal(i));
        }
        StringBuilder stack = new StringBuilder("] stack=[");
        for (int i = 0; i < f.getStackSize(); i++) {
            stack.append(i > 0 ? "," : "").append(f.getStack(i));
        }
        return locals.toString() + stack + "]";
    }

    static void title(String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}
















abstract class AbstractInsnNode {

    public static final int INSN = 0;
    public static final int INT_INSN = 1;
    public static final int VAR_INSN = 2;
    public static final int TYPE_INSN = 3;
    public static final int FIELD_INSN = 4;
    public static final int METHOD_INSN = 5;
    public static final int INVOKE_DYNAMIC_INSN = 6;
    public static final int JUMP_INSN = 7;
    public static final int LABEL = 8;
    public static final int LDC_INSN = 9;
    public static final int IINC_INSN = 10;
    public static final int TABLESWITCH_INSN = 11;
    public static final int LOOKUPSWITCH_INSN = 12;
    public static final int MULTIANEWARRAY_INSN = 13;
    public static final int FRAME = 14;
    public static final int LINE = 15;

    protected int opcode;

    
    int index = -1;

    protected AbstractInsnNode(final int opcode) {
        this.opcode = opcode;
    }

    public int getOpcode() {
        return opcode;
    }

    public abstract int getType();
}

class InsnNode extends AbstractInsnNode {

    public InsnNode(final int opcode) {
        super(opcode);
    }

    public int getType() {
        return INSN;
    }
}

class IntInsnNode extends AbstractInsnNode {

    public int operand;

    public IntInsnNode(final int opcode, final int operand) {
        super(opcode);
        this.operand = operand;
    }

    public int getType() {
        return INT_INSN;
    }
}

class VarInsnNode extends AbstractInsnNode {

    public int var;

    public VarInsnNode(final int opcode, final int var) {
        super(opcode);
        this.var = var;
    }

    public int getType() {
        return VAR_INSN;
    }
}

class TypeInsnNode extends AbstractInsnNode {

    public String desc;

    public TypeInsnNode(final int opcode, final String desc) {
        super(opcode);
        this.desc = desc;
    }

    public int getType() {
        return TYPE_INSN;
    }
}

class FieldInsnNode extends AbstractInsnNode {

    public String owner;
    public String name;
    public String desc;

    public FieldInsnNode(final int opcode, final String owner, final String name, final String desc) {
        super(opcode);
        this.owner = owner;
        this.name = name;
        this.desc = desc;
    }

    public int getType() {
        return FIELD_INSN;
    }
}

class MethodInsnNode extends AbstractInsnNode {

    public String owner;
    public String name;
    public String desc;
    public boolean itf;

    public MethodInsnNode(final int opcode, final String owner, final String name, final String desc,
            final boolean itf) {
        super(opcode);
        this.owner = owner;
        this.name = name;
        this.desc = desc;
        this.itf = itf;
    }

    public int getType() {
        return METHOD_INSN;
    }
}

class InvokeDynamicInsnNode extends AbstractInsnNode {

    public String name;
    public String desc;
    public Handle bsm;
    public Object[] bsmArgs;

    public InvokeDynamicInsnNode(final String name, final String desc, final Handle bsm, final Object... bsmArgs) {
        super(Opcodes.INVOKEDYNAMIC);
        this.name = name;
        this.desc = desc;
        this.bsm = bsm;
        this.bsmArgs = bsmArgs;
    }

    public int getType() {
        return INVOKE_DYNAMIC_INSN;
    }
}

class JumpInsnNode extends AbstractInsnNode {

    public LabelNode label;

    public JumpInsnNode(final int opcode, final LabelNode label) {
        super(opcode);
        this.label = label;
    }

    public int getType() {
        return JUMP_INSN;
    }
}

class LabelNode extends AbstractInsnNode {

    public LabelNode() {
        super(-1);
    }

    public int getType() {
        return LABEL;
    }
}

class LineNumberNode extends AbstractInsnNode {

    public int line;
    public LabelNode start;

    public LineNumberNode(final int line, final LabelNode start) {
        super(-1);
        this.line = line;
        this.start = start;
    }

    public int getType() {
        return LINE;
    }
}

class FrameNode extends AbstractInsnNode {

    public int type;
    public List<Object> local;
    public List<Object> stack;

    public FrameNode(final int type, final int nLocal, final Object[] local, final int nStack, final Object[] stack) {
        super(-1);
        this.type = type;
        this.local = local == null ? new ArrayList<Object>() : Arrays.asList(local);
        this.stack = stack == null ? new ArrayList<Object>() : Arrays.asList(stack);
    }

    public int getType() {
        return FRAME;
    }
}

class LdcInsnNode extends AbstractInsnNode {

    public Object cst;

    public LdcInsnNode(final Object cst) {
        super(Opcodes.LDC);
        this.cst = cst;
    }

    public int getType() {
        return LDC_INSN;
    }
}

class IincInsnNode extends AbstractInsnNode {

    public int var;
    public int incr;

    public IincInsnNode(final int var, final int incr) {
        super(Opcodes.IINC);
        this.var = var;
        this.incr = incr;
    }

    public int getType() {
        return IINC_INSN;
    }
}

class TableSwitchInsnNode extends AbstractInsnNode {

    public int min;
    public int max;
    public LabelNode dflt;
    public List<LabelNode> labels;

    public TableSwitchInsnNode(final int min, final int max, final LabelNode dflt, final LabelNode... labels) {
        super(Opcodes.TABLESWITCH);
        this.min = min;
        this.max = max;
        this.dflt = dflt;
        this.labels = new ArrayList<LabelNode>();
        if (labels != null) {
            this.labels.addAll(Arrays.asList(labels));
        }
    }

    public int getType() {
        return TABLESWITCH_INSN;
    }
}

class LookupSwitchInsnNode extends AbstractInsnNode {

    public LabelNode dflt;
    public List<Integer> keys;
    public List<LabelNode> labels;

    public LookupSwitchInsnNode(final LabelNode dflt, final int[] keys, final LabelNode[] labels) {
        super(Opcodes.LOOKUPSWITCH);
        this.dflt = dflt;
        this.keys = new ArrayList<Integer>(keys == null ? 0 : keys.length);
        this.labels = new ArrayList<LabelNode>(labels == null ? 0 : labels.length);
        if (keys != null) {
            for (int key : keys) {
                this.keys.add(key);
            }
        }
        if (labels != null) {
            this.labels.addAll(Arrays.asList(labels));
        }
    }

    public int getType() {
        return LOOKUPSWITCH_INSN;
    }
}

class MultiANewArrayInsnNode extends AbstractInsnNode {

    public String desc;
    public int dims;

    public MultiANewArrayInsnNode(final String desc, final int dims) {
        super(Opcodes.MULTIANEWARRAY);
        this.desc = desc;
        this.dims = dims;
    }

    public int getType() {
        return MULTIANEWARRAY_INSN;
    }
}

class TryCatchBlockNode {

    public LabelNode start;
    public LabelNode end;
    public LabelNode handler;
    public String type;

    public TryCatchBlockNode(final LabelNode start, final LabelNode end, final LabelNode handler, final String type) {
        this.start = start;
        this.end = end;
        this.handler = handler;
        this.type = type;
    }
}







class InsnList {

    private final List<AbstractInsnNode> nodes = new ArrayList<AbstractInsnNode>();

    public int size() {
        return nodes.size();
    }

    public AbstractInsnNode get(final int index) {
        return nodes.get(index);
    }

    public int indexOf(final AbstractInsnNode insn) {
        return insn == null ? -1 : insn.index;
    }

    public void add(final AbstractInsnNode insn) {
        insn.index = nodes.size();
        nodes.add(insn);
    }

    public AbstractInsnNode getFirst() {
        return nodes.isEmpty() ? null : nodes.get(0);
    }

    public AbstractInsnNode getLast() {
        return nodes.isEmpty() ? null : nodes.get(nodes.size() - 1);
    }
}








class MethodNode {

    public int access;
    public String name;
    public String desc;
    public InsnList instructions = new InsnList();
    public List<TryCatchBlockNode> tryCatchBlocks = new ArrayList<TryCatchBlockNode>();
    public int maxLocals;
    public int maxStack;

    public MethodNode(final int access, final String name, final String desc) {
        this.access = access;
        this.name = name;
        this.desc = desc;
    }
}















































interface Opcodes {

    

    int ASM4 = 4 << 16 | 0 << 8 | 0;
    int ASM5 = 5 << 16 | 0 << 8 | 0;

    

    int V1_1 = 3 << 16 | 45;
    int V1_2 = 0 << 16 | 46;
    int V1_3 = 0 << 16 | 47;
    int V1_4 = 0 << 16 | 48;
    int V1_5 = 0 << 16 | 49;
    int V1_6 = 0 << 16 | 50;
    int V1_7 = 0 << 16 | 51;
    int V1_8 = 0 << 16 | 52;

    

    int ACC_PUBLIC = 0x0001; 
    int ACC_PRIVATE = 0x0002; 
    int ACC_PROTECTED = 0x0004; 
    int ACC_STATIC = 0x0008; 
    int ACC_FINAL = 0x0010; 
    int ACC_SUPER = 0x0020; 
    int ACC_SYNCHRONIZED = 0x0020; 
    int ACC_VOLATILE = 0x0040; 
    int ACC_BRIDGE = 0x0040; 
    int ACC_VARARGS = 0x0080; 
    int ACC_TRANSIENT = 0x0080; 
    int ACC_NATIVE = 0x0100; 
    int ACC_INTERFACE = 0x0200; 
    int ACC_ABSTRACT = 0x0400; 
    int ACC_STRICT = 0x0800; 
    int ACC_SYNTHETIC = 0x1000; 
    int ACC_ANNOTATION = 0x2000; 
    int ACC_ENUM = 0x4000; 
    int ACC_MANDATED = 0x8000; 

    

    int ACC_DEPRECATED = 0x20000; 

    

    int T_BOOLEAN = 4;
    int T_CHAR = 5;
    int T_FLOAT = 6;
    int T_DOUBLE = 7;
    int T_BYTE = 8;
    int T_SHORT = 9;
    int T_INT = 10;
    int T_LONG = 11;

    

    int H_GETFIELD = 1;
    int H_GETSTATIC = 2;
    int H_PUTFIELD = 3;
    int H_PUTSTATIC = 4;
    int H_INVOKEVIRTUAL = 5;
    int H_INVOKESTATIC = 6;
    int H_INVOKESPECIAL = 7;
    int H_NEWINVOKESPECIAL = 8;
    int H_INVOKEINTERFACE = 9;

    

    


    int F_NEW = -1;

    


    int F_FULL = 0;

    




    int F_APPEND = 1;

    




    int F_CHOP = 2;

    



    int F_SAME = 3;

    



    int F_SAME1 = 4;

    Integer TOP = new Integer(0);
    Integer INTEGER = new Integer(1);
    Integer FLOAT = new Integer(2);
    Integer DOUBLE = new Integer(3);
    Integer LONG = new Integer(4);
    Integer NULL = new Integer(5);
    Integer UNINITIALIZED_THIS = new Integer(6);

    

    int NOP = 0; 
    int ACONST_NULL = 1; 
    int ICONST_M1 = 2; 
    int ICONST_0 = 3; 
    int ICONST_1 = 4; 
    int ICONST_2 = 5; 
    int ICONST_3 = 6; 
    int ICONST_4 = 7; 
    int ICONST_5 = 8; 
    int LCONST_0 = 9; 
    int LCONST_1 = 10; 
    int FCONST_0 = 11; 
    int FCONST_1 = 12; 
    int FCONST_2 = 13; 
    int DCONST_0 = 14; 
    int DCONST_1 = 15; 
    int BIPUSH = 16; 
    int SIPUSH = 17; 
    int LDC = 18; 
    
    
    int ILOAD = 21; 
    int LLOAD = 22; 
    int FLOAD = 23; 
    int DLOAD = 24; 
    int ALOAD = 25; 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    int IALOAD = 46; 
    int LALOAD = 47; 
    int FALOAD = 48; 
    int DALOAD = 49; 
    int AALOAD = 50; 
    int BALOAD = 51; 
    int CALOAD = 52; 
    int SALOAD = 53; 
    int ISTORE = 54; 
    int LSTORE = 55; 
    int FSTORE = 56; 
    int DSTORE = 57; 
    int ASTORE = 58; 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    int IASTORE = 79; 
    int LASTORE = 80; 
    int FASTORE = 81; 
    int DASTORE = 82; 
    int AASTORE = 83; 
    int BASTORE = 84; 
    int CASTORE = 85; 
    int SASTORE = 86; 
    int POP = 87; 
    int POP2 = 88; 
    int DUP = 89; 
    int DUP_X1 = 90; 
    int DUP_X2 = 91; 
    int DUP2 = 92; 
    int DUP2_X1 = 93; 
    int DUP2_X2 = 94; 
    int SWAP = 95; 
    int IADD = 96; 
    int LADD = 97; 
    int FADD = 98; 
    int DADD = 99; 
    int ISUB = 100; 
    int LSUB = 101; 
    int FSUB = 102; 
    int DSUB = 103; 
    int IMUL = 104; 
    int LMUL = 105; 
    int FMUL = 106; 
    int DMUL = 107; 
    int IDIV = 108; 
    int LDIV = 109; 
    int FDIV = 110; 
    int DDIV = 111; 
    int IREM = 112; 
    int LREM = 113; 
    int FREM = 114; 
    int DREM = 115; 
    int INEG = 116; 
    int LNEG = 117; 
    int FNEG = 118; 
    int DNEG = 119; 
    int ISHL = 120; 
    int LSHL = 121; 
    int ISHR = 122; 
    int LSHR = 123; 
    int IUSHR = 124; 
    int LUSHR = 125; 
    int IAND = 126; 
    int LAND = 127; 
    int IOR = 128; 
    int LOR = 129; 
    int IXOR = 130; 
    int LXOR = 131; 
    int IINC = 132; 
    int I2L = 133; 
    int I2F = 134; 
    int I2D = 135; 
    int L2I = 136; 
    int L2F = 137; 
    int L2D = 138; 
    int F2I = 139; 
    int F2L = 140; 
    int F2D = 141; 
    int D2I = 142; 
    int D2L = 143; 
    int D2F = 144; 
    int I2B = 145; 
    int I2C = 146; 
    int I2S = 147; 
    int LCMP = 148; 
    int FCMPL = 149; 
    int FCMPG = 150; 
    int DCMPL = 151; 
    int DCMPG = 152; 
    int IFEQ = 153; 
    int IFNE = 154; 
    int IFLT = 155; 
    int IFGE = 156; 
    int IFGT = 157; 
    int IFLE = 158; 
    int IF_ICMPEQ = 159; 
    int IF_ICMPNE = 160; 
    int IF_ICMPLT = 161; 
    int IF_ICMPGE = 162; 
    int IF_ICMPGT = 163; 
    int IF_ICMPLE = 164; 
    int IF_ACMPEQ = 165; 
    int IF_ACMPNE = 166; 
    int GOTO = 167; 
    int JSR = 168; 
    int RET = 169; 
    int TABLESWITCH = 170; 
    int LOOKUPSWITCH = 171; 
    int IRETURN = 172; 
    int LRETURN = 173; 
    int FRETURN = 174; 
    int DRETURN = 175; 
    int ARETURN = 176; 
    int RETURN = 177; 
    int GETSTATIC = 178; 
    int PUTSTATIC = 179; 
    int GETFIELD = 180; 
    int PUTFIELD = 181; 
    int INVOKEVIRTUAL = 182; 
    int INVOKESPECIAL = 183; 
    int INVOKESTATIC = 184; 
    int INVOKEINTERFACE = 185; 
    int INVOKEDYNAMIC = 186; 
    int NEW = 187; 
    int NEWARRAY = 188; 
    int ANEWARRAY = 189; 
    int ARRAYLENGTH = 190; 
    int ATHROW = 191; 
    int CHECKCAST = 192; 
    int INSTANCEOF = 193; 
    int MONITORENTER = 194; 
    int MONITOREXIT = 195; 
    
    int MULTIANEWARRAY = 197; 
    int IFNULL = 198; 
    int IFNONNULL = 199; 
    
    
}










































class Type {

    


    public static final int VOID = 0;

    


    public static final int BOOLEAN = 1;

    


    public static final int CHAR = 2;

    


    public static final int BYTE = 3;

    


    public static final int SHORT = 4;

    


    public static final int INT = 5;

    


    public static final int FLOAT = 6;

    


    public static final int LONG = 7;

    


    public static final int DOUBLE = 8;

    


    public static final int ARRAY = 9;

    


    public static final int OBJECT = 10;

    


    public static final int METHOD = 11;

    


    public static final Type VOID_TYPE = new Type(VOID, null, ('V' << 24)
            | (5 << 16) | (0 << 8) | 0, 1);

    


    public static final Type BOOLEAN_TYPE = new Type(BOOLEAN, null, ('Z' << 24)
            | (0 << 16) | (5 << 8) | 1, 1);

    


    public static final Type CHAR_TYPE = new Type(CHAR, null, ('C' << 24)
            | (0 << 16) | (6 << 8) | 1, 1);

    


    public static final Type BYTE_TYPE = new Type(BYTE, null, ('B' << 24)
            | (0 << 16) | (5 << 8) | 1, 1);

    


    public static final Type SHORT_TYPE = new Type(SHORT, null, ('S' << 24)
            | (0 << 16) | (7 << 8) | 1, 1);

    


    public static final Type INT_TYPE = new Type(INT, null, ('I' << 24)
            | (0 << 16) | (0 << 8) | 1, 1);

    


    public static final Type FLOAT_TYPE = new Type(FLOAT, null, ('F' << 24)
            | (2 << 16) | (2 << 8) | 1, 1);

    


    public static final Type LONG_TYPE = new Type(LONG, null, ('J' << 24)
            | (1 << 16) | (1 << 8) | 2, 1);

    


    public static final Type DOUBLE_TYPE = new Type(DOUBLE, null, ('D' << 24)
            | (3 << 16) | (3 << 8) | 2, 1);

    
    
    

    


    private final int sort;

    



    private final char[] buf;

    





    private final int off;

    


    private final int len;

    
    
    

    











    private Type(final int sort, final char[] buf, final int off, final int len) {
        this.sort = sort;
        this.buf = buf;
        this.off = off;
        this.len = len;
    }

    






    public static Type getType(final String typeDescriptor) {
        return getType(typeDescriptor.toCharArray(), 0);
    }

    






    public static Type getObjectType(final String internalName) {
        char[] buf = internalName.toCharArray();
        return new Type(buf[0] == '[' ? ARRAY : OBJECT, buf, 0, buf.length);
    }

    







    public static Type getMethodType(final String methodDescriptor) {
        return getType(methodDescriptor.toCharArray(), 0);
    }

    










    public static Type getMethodType(final Type returnType,
            final Type... argumentTypes) {
        return getType(getMethodDescriptor(returnType, argumentTypes));
    }

    






    public static Type getType(final Class<?> c) {
        if (c.isPrimitive()) {
            if (c == Integer.TYPE) {
                return INT_TYPE;
            } else if (c == Void.TYPE) {
                return VOID_TYPE;
            } else if (c == Boolean.TYPE) {
                return BOOLEAN_TYPE;
            } else if (c == Byte.TYPE) {
                return BYTE_TYPE;
            } else if (c == Character.TYPE) {
                return CHAR_TYPE;
            } else if (c == Short.TYPE) {
                return SHORT_TYPE;
            } else if (c == Double.TYPE) {
                return DOUBLE_TYPE;
            } else if (c == Float.TYPE) {
                return FLOAT_TYPE;
            } else {
                return LONG_TYPE;
            }
        } else {
            return getType(getDescriptor(c));
        }
    }

    






    public static Type getType(final Constructor<?> c) {
        return getType(getConstructorDescriptor(c));
    }

    






    public static Type getType(final Method m) {
        return getType(getMethodDescriptor(m));
    }

    








    public static Type[] getArgumentTypes(final String methodDescriptor) {
        char[] buf = methodDescriptor.toCharArray();
        int off = 1;
        int size = 0;
        while (true) {
            char car = buf[off++];
            if (car == ')') {
                break;
            } else if (car == 'L') {
                while (buf[off++] != ';') {
                }
                ++size;
            } else if (car != '[') {
                ++size;
            }
        }
        Type[] args = new Type[size];
        off = 1;
        size = 0;
        while (buf[off] != ')') {
            args[size] = getType(buf, off);
            off += args[size].len + (args[size].sort == OBJECT ? 2 : 0);
            size += 1;
        }
        return args;
    }

    








    public static Type[] getArgumentTypes(final Method method) {
        Class<?>[] classes = method.getParameterTypes();
        Type[] types = new Type[classes.length];
        for (int i = classes.length - 1; i >= 0; --i) {
            types[i] = getType(classes[i]);
        }
        return types;
    }

    








    public static Type getReturnType(final String methodDescriptor) {
        char[] buf = methodDescriptor.toCharArray();
        return getType(buf, methodDescriptor.indexOf(')') + 1);
    }

    








    public static Type getReturnType(final Method method) {
        return getType(method.getReturnType());
    }

    










    public static int getArgumentsAndReturnSizes(final String desc) {
        int n = 1;
        int c = 1;
        while (true) {
            char car = desc.charAt(c++);
            if (car == ')') {
                car = desc.charAt(c);
                return n << 2
                        | (car == 'V' ? 0 : (car == 'D' || car == 'J' ? 2 : 1));
            } else if (car == 'L') {
                while (desc.charAt(c++) != ';') {
                }
                n += 1;
            } else if (car == '[') {
                while ((car = desc.charAt(c)) == '[') {
                    ++c;
                }
                if (car == 'D' || car == 'J') {
                    n -= 1;
                }
            } else if (car == 'D' || car == 'J') {
                n += 2;
            } else {
                n += 1;
            }
        }
    }

    










    private static Type getType(final char[] buf, final int off) {
        int len;
        switch (buf[off]) {
        case 'V':
            return VOID_TYPE;
        case 'Z':
            return BOOLEAN_TYPE;
        case 'C':
            return CHAR_TYPE;
        case 'B':
            return BYTE_TYPE;
        case 'S':
            return SHORT_TYPE;
        case 'I':
            return INT_TYPE;
        case 'F':
            return FLOAT_TYPE;
        case 'J':
            return LONG_TYPE;
        case 'D':
            return DOUBLE_TYPE;
        case '[':
            len = 1;
            while (buf[off + len] == '[') {
                ++len;
            }
            if (buf[off + len] == 'L') {
                ++len;
                while (buf[off + len] != ';') {
                    ++len;
                }
            }
            return new Type(ARRAY, buf, off, len + 1);
        case 'L':
            len = 1;
            while (buf[off + len] != ';') {
                ++len;
            }
            return new Type(OBJECT, buf, off + 1, len - 1);
            
        default:
            return new Type(METHOD, buf, off, buf.length - off);
        }
    }

    
    
    

    








    public int getSort() {
        return sort;
    }

    





    public int getDimensions() {
        int i = 1;
        while (buf[off + i] == '[') {
            ++i;
        }
        return i;
    }

    





    public Type getElementType() {
        return getType(buf, off + getDimensions());
    }

    





    public String getClassName() {
        switch (sort) {
        case VOID:
            return "void";
        case BOOLEAN:
            return "boolean";
        case CHAR:
            return "char";
        case BYTE:
            return "byte";
        case SHORT:
            return "short";
        case INT:
            return "int";
        case FLOAT:
            return "float";
        case LONG:
            return "long";
        case DOUBLE:
            return "double";
        case ARRAY:
            StringBuilder sb = new StringBuilder(getElementType().getClassName());
            for (int i = getDimensions(); i > 0; --i) {
                sb.append("[]");
            }
            return sb.toString();
        case OBJECT:
            return new String(buf, off, len).replace('/', '.');
        default:
            return null;
        }
    }

    







    public String getInternalName() {
        return new String(buf, off, len);
    }

    





    public Type[] getArgumentTypes() {
        return getArgumentTypes(getDescriptor());
    }

    





    public Type getReturnType() {
        return getReturnType(getDescriptor());
    }

    










    public int getArgumentsAndReturnSizes() {
        return getArgumentsAndReturnSizes(getDescriptor());
    }

    
    
    

    




    public String getDescriptor() {
        StringBuffer buf = new StringBuffer();
        getDescriptor(buf);
        return buf.toString();
    }

    










    public static String getMethodDescriptor(final Type returnType,
            final Type... argumentTypes) {
        StringBuffer buf = new StringBuffer();
        buf.append('(');
        for (int i = 0; i < argumentTypes.length; ++i) {
            argumentTypes[i].getDescriptor(buf);
        }
        buf.append(')');
        returnType.getDescriptor(buf);
        return buf.toString();
    }

    






    private void getDescriptor(final StringBuffer buf) {
        if (this.buf == null) {
            
            
            buf.append((char) ((off & 0xFF000000) >>> 24));
        } else if (sort == OBJECT) {
            buf.append('L');
            buf.append(this.buf, off, len);
            buf.append(';');
        } else { 
            buf.append(this.buf, off, len);
        }
    }

    
    
    
    

    








    public static String getInternalName(final Class<?> c) {
        return c.getName().replace('.', '/');
    }

    






    public static String getDescriptor(final Class<?> c) {
        StringBuffer buf = new StringBuffer();
        getDescriptor(buf, c);
        return buf.toString();
    }

    






    public static String getConstructorDescriptor(final Constructor<?> c) {
        Class<?>[] parameters = c.getParameterTypes();
        StringBuffer buf = new StringBuffer();
        buf.append('(');
        for (int i = 0; i < parameters.length; ++i) {
            getDescriptor(buf, parameters[i]);
        }
        return buf.append(")V").toString();
    }

    






    public static String getMethodDescriptor(final Method m) {
        Class<?>[] parameters = m.getParameterTypes();
        StringBuffer buf = new StringBuffer();
        buf.append('(');
        for (int i = 0; i < parameters.length; ++i) {
            getDescriptor(buf, parameters[i]);
        }
        buf.append(')');
        getDescriptor(buf, m.getReturnType());
        return buf.toString();
    }

    







    private static void getDescriptor(final StringBuffer buf, final Class<?> c) {
        Class<?> d = c;
        while (true) {
            if (d.isPrimitive()) {
                char car;
                if (d == Integer.TYPE) {
                    car = 'I';
                } else if (d == Void.TYPE) {
                    car = 'V';
                } else if (d == Boolean.TYPE) {
                    car = 'Z';
                } else if (d == Byte.TYPE) {
                    car = 'B';
                } else if (d == Character.TYPE) {
                    car = 'C';
                } else if (d == Short.TYPE) {
                    car = 'S';
                } else if (d == Double.TYPE) {
                    car = 'D';
                } else if (d == Float.TYPE) {
                    car = 'F';
                } else {
                    car = 'J';
                }
                buf.append(car);
                return;
            } else if (d.isArray()) {
                buf.append('[');
                d = d.getComponentType();
            } else {
                buf.append('L');
                String name = d.getName();
                int len = name.length();
                for (int i = 0; i < len; ++i) {
                    char car = name.charAt(i);
                    buf.append(car == '.' ? '/' : car);
                }
                buf.append(';');
                return;
            }
        }
    }

    
    
    

    






    public int getSize() {
        
        return buf == null ? (off & 0xFF) : 1;
    }

    











    public int getOpcode(final int opcode) {
        if (opcode == Opcodes.IALOAD || opcode == Opcodes.IASTORE) {
            
            
            return opcode + (buf == null ? (off & 0xFF00) >> 8 : 4);
        } else {
            
            
            return opcode + (buf == null ? (off & 0xFF0000) >> 16 : 4);
        }
    }

    
    
    

    






    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Type)) {
            return false;
        }
        Type t = (Type) o;
        if (sort != t.sort) {
            return false;
        }
        if (sort >= ARRAY) {
            if (len != t.len) {
                return false;
            }
            for (int i = off, j = t.off, end = i + len; i < end; i++, j++) {
                if (buf[i] != t.buf[j]) {
                    return false;
                }
            }
        }
        return true;
    }

    




    @Override
    public int hashCode() {
        int hc = 13 * sort;
        if (sort >= ARRAY) {
            for (int i = off, end = i + len; i < end; i++) {
                hc = 17 * (hc + buf[i]);
            }
        }
        return hc;
    }

    




    @Override
    public String toString() {
        return getDescriptor();
    }
}









































final class Handle {

    







    final int tag;

    



    final String owner;

    


    final String name;

    


    final String desc;

    




















    public Handle(int tag, String owner, String name, String desc) {
        this.tag = tag;
        this.owner = owner;
        this.name = name;
        this.desc = desc;
    }

    









    public int getTag() {
        return tag;
    }

    






    public String getOwner() {
        return owner;
    }

    




    public String getName() {
        return name;
    }

    




    public String getDesc() {
        return desc;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Handle)) {
            return false;
        }
        Handle h = (Handle) obj;
        return tag == h.tag && owner.equals(h.owner) && name.equals(h.name)
                && desc.equals(h.desc);
    }

    @Override
    public int hashCode() {
        return tag + owner.hashCode() * name.hashCode() * desc.hashCode();
    }

    









    @Override
    public String toString() {
        return owner + '.' + name + desc + " (" + tag + ')';
    }
}







































interface Value {

    




    int getSize();
}










































class BasicValue implements Value {

    public static final BasicValue UNINITIALIZED_VALUE = new BasicValue(null);

    public static final BasicValue INT_VALUE = new BasicValue(Type.INT_TYPE);

    public static final BasicValue FLOAT_VALUE = new BasicValue(Type.FLOAT_TYPE);

    public static final BasicValue LONG_VALUE = new BasicValue(Type.LONG_TYPE);

    public static final BasicValue DOUBLE_VALUE = new BasicValue(
            Type.DOUBLE_TYPE);

    public static final BasicValue REFERENCE_VALUE = new BasicValue(
            Type.getObjectType("java/lang/Object"));

    public static final BasicValue RETURNADDRESS_VALUE = new BasicValue(
            Type.VOID_TYPE);

    private final Type type;

    public BasicValue(final Type type) {
        this.type = type;
    }

    public Type getType() {
        return type;
    }

    public int getSize() {
        return type == Type.LONG_TYPE || type == Type.DOUBLE_TYPE ? 2 : 1;
    }

    public boolean isReference() {
        return type != null
                && (type.getSort() == Type.OBJECT || type.getSort() == Type.ARRAY);
    }

    @Override
    public boolean equals(final Object value) {
        if (value == this) {
            return true;
        } else if (value instanceof BasicValue) {
            if (type == null) {
                return ((BasicValue) value).type == null;
            } else {
                return type.equals(((BasicValue) value).type);
            }
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return type == null ? 0 : type.hashCode();
    }

    @Override
    public String toString() {
        if (this == UNINITIALIZED_VALUE) {
            return ".";
        } else if (this == RETURNADDRESS_VALUE) {
            return "A";
        } else if (this == REFERENCE_VALUE) {
            return "R";
        } else {
            return type.getDescriptor();
        }
    }
}

















































abstract class Interpreter<V extends Value> {

    protected final int api;

    protected Interpreter(final int api) {
        this.api = api;
    }

    












    public abstract V newValue(Type type);

    













    public abstract V newOperation(AbstractInsnNode insn)
            throws AnalyzerException;

    















    public abstract V copyOperation(AbstractInsnNode insn, V value)
            throws AnalyzerException;

    

















    public abstract V unaryOperation(AbstractInsnNode insn, V value)
            throws AnalyzerException;

    




















    public abstract V binaryOperation(AbstractInsnNode insn, V value1, V value2)
            throws AnalyzerException;

    

















    public abstract V ternaryOperation(AbstractInsnNode insn, V value1,
            V value2, V value3) throws AnalyzerException;

    














    public abstract V naryOperation(AbstractInsnNode insn,
            List<? extends V> values) throws AnalyzerException;

    














    public abstract void returnOperation(AbstractInsnNode insn, V value,
            V expected) throws AnalyzerException;

    













    public abstract V merge(V v, V w);
}










































class BasicInterpreter extends Interpreter<BasicValue> implements
        Opcodes {

    public BasicInterpreter() {
        super(ASM5);
    }

    protected BasicInterpreter(final int api) {
        super(api);
    }

    @Override
    public BasicValue newValue(final Type type) {
        if (type == null) {
            return BasicValue.UNINITIALIZED_VALUE;
        }
        switch (type.getSort()) {
        case Type.VOID:
            return null;
        case Type.BOOLEAN:
        case Type.CHAR:
        case Type.BYTE:
        case Type.SHORT:
        case Type.INT:
            return BasicValue.INT_VALUE;
        case Type.FLOAT:
            return BasicValue.FLOAT_VALUE;
        case Type.LONG:
            return BasicValue.LONG_VALUE;
        case Type.DOUBLE:
            return BasicValue.DOUBLE_VALUE;
        case Type.ARRAY:
        case Type.OBJECT:
            return BasicValue.REFERENCE_VALUE;
        default:
            throw new Error("Internal error");
        }
    }

    @Override
    public BasicValue newOperation(final AbstractInsnNode insn)
            throws AnalyzerException {
        switch (insn.getOpcode()) {
        case ACONST_NULL:
            return newValue(Type.getObjectType("null"));
        case ICONST_M1:
        case ICONST_0:
        case ICONST_1:
        case ICONST_2:
        case ICONST_3:
        case ICONST_4:
        case ICONST_5:
            return BasicValue.INT_VALUE;
        case LCONST_0:
        case LCONST_1:
            return BasicValue.LONG_VALUE;
        case FCONST_0:
        case FCONST_1:
        case FCONST_2:
            return BasicValue.FLOAT_VALUE;
        case DCONST_0:
        case DCONST_1:
            return BasicValue.DOUBLE_VALUE;
        case BIPUSH:
        case SIPUSH:
            return BasicValue.INT_VALUE;
        case LDC:
            Object cst = ((LdcInsnNode) insn).cst;
            if (cst instanceof Integer) {
                return BasicValue.INT_VALUE;
            } else if (cst instanceof Float) {
                return BasicValue.FLOAT_VALUE;
            } else if (cst instanceof Long) {
                return BasicValue.LONG_VALUE;
            } else if (cst instanceof Double) {
                return BasicValue.DOUBLE_VALUE;
            } else if (cst instanceof String) {
                return newValue(Type.getObjectType("java/lang/String"));
            } else if (cst instanceof Type) {
                int sort = ((Type) cst).getSort();
                if (sort == Type.OBJECT || sort == Type.ARRAY) {
                    return newValue(Type.getObjectType("java/lang/Class"));
                } else if (sort == Type.METHOD) {
                    return newValue(Type
                            .getObjectType("java/lang/invoke/MethodType"));
                } else {
                    throw new IllegalArgumentException("Illegal LDC constant "
                            + cst);
                }
            } else if (cst instanceof Handle) {
                return newValue(Type
                        .getObjectType("java/lang/invoke/MethodHandle"));
            } else {
                throw new IllegalArgumentException("Illegal LDC constant "
                        + cst);
            }
        case JSR:
            return BasicValue.RETURNADDRESS_VALUE;
        case GETSTATIC:
            return newValue(Type.getType(((FieldInsnNode) insn).desc));
        case NEW:
            return newValue(Type.getObjectType(((TypeInsnNode) insn).desc));
        default:
            throw new Error("Internal error.");
        }
    }

    @Override
    public BasicValue copyOperation(final AbstractInsnNode insn,
            final BasicValue value) throws AnalyzerException {
        return value;
    }

    @Override
    public BasicValue unaryOperation(final AbstractInsnNode insn,
            final BasicValue value) throws AnalyzerException {
        switch (insn.getOpcode()) {
        case INEG:
        case IINC:
        case L2I:
        case F2I:
        case D2I:
        case I2B:
        case I2C:
        case I2S:
            return BasicValue.INT_VALUE;
        case FNEG:
        case I2F:
        case L2F:
        case D2F:
            return BasicValue.FLOAT_VALUE;
        case LNEG:
        case I2L:
        case F2L:
        case D2L:
            return BasicValue.LONG_VALUE;
        case DNEG:
        case I2D:
        case L2D:
        case F2D:
            return BasicValue.DOUBLE_VALUE;
        case IFEQ:
        case IFNE:
        case IFLT:
        case IFGE:
        case IFGT:
        case IFLE:
        case TABLESWITCH:
        case LOOKUPSWITCH:
        case IRETURN:
        case LRETURN:
        case FRETURN:
        case DRETURN:
        case ARETURN:
        case PUTSTATIC:
            return null;
        case GETFIELD:
            return newValue(Type.getType(((FieldInsnNode) insn).desc));
        case NEWARRAY:
            switch (((IntInsnNode) insn).operand) {
            case T_BOOLEAN:
                return newValue(Type.getType("[Z"));
            case T_CHAR:
                return newValue(Type.getType("[C"));
            case T_BYTE:
                return newValue(Type.getType("[B"));
            case T_SHORT:
                return newValue(Type.getType("[S"));
            case T_INT:
                return newValue(Type.getType("[I"));
            case T_FLOAT:
                return newValue(Type.getType("[F"));
            case T_DOUBLE:
                return newValue(Type.getType("[D"));
            case T_LONG:
                return newValue(Type.getType("[J"));
            default:
                throw new AnalyzerException(insn, "Invalid array type");
            }
        case ANEWARRAY:
            String desc = ((TypeInsnNode) insn).desc;
            return newValue(Type.getType("[" + Type.getObjectType(desc)));
        case ARRAYLENGTH:
            return BasicValue.INT_VALUE;
        case ATHROW:
            return null;
        case CHECKCAST:
            desc = ((TypeInsnNode) insn).desc;
            return newValue(Type.getObjectType(desc));
        case INSTANCEOF:
            return BasicValue.INT_VALUE;
        case MONITORENTER:
        case MONITOREXIT:
        case IFNULL:
        case IFNONNULL:
            return null;
        default:
            throw new Error("Internal error.");
        }
    }

    @Override
    public BasicValue binaryOperation(final AbstractInsnNode insn,
            final BasicValue value1, final BasicValue value2)
            throws AnalyzerException {
        switch (insn.getOpcode()) {
        case IALOAD:
        case BALOAD:
        case CALOAD:
        case SALOAD:
        case IADD:
        case ISUB:
        case IMUL:
        case IDIV:
        case IREM:
        case ISHL:
        case ISHR:
        case IUSHR:
        case IAND:
        case IOR:
        case IXOR:
            return BasicValue.INT_VALUE;
        case FALOAD:
        case FADD:
        case FSUB:
        case FMUL:
        case FDIV:
        case FREM:
            return BasicValue.FLOAT_VALUE;
        case LALOAD:
        case LADD:
        case LSUB:
        case LMUL:
        case LDIV:
        case LREM:
        case LSHL:
        case LSHR:
        case LUSHR:
        case LAND:
        case LOR:
        case LXOR:
            return BasicValue.LONG_VALUE;
        case DALOAD:
        case DADD:
        case DSUB:
        case DMUL:
        case DDIV:
        case DREM:
            return BasicValue.DOUBLE_VALUE;
        case AALOAD:
            return BasicValue.REFERENCE_VALUE;
        case LCMP:
        case FCMPL:
        case FCMPG:
        case DCMPL:
        case DCMPG:
            return BasicValue.INT_VALUE;
        case IF_ICMPEQ:
        case IF_ICMPNE:
        case IF_ICMPLT:
        case IF_ICMPGE:
        case IF_ICMPGT:
        case IF_ICMPLE:
        case IF_ACMPEQ:
        case IF_ACMPNE:
        case PUTFIELD:
            return null;
        default:
            throw new Error("Internal error.");
        }
    }

    @Override
    public BasicValue ternaryOperation(final AbstractInsnNode insn,
            final BasicValue value1, final BasicValue value2,
            final BasicValue value3) throws AnalyzerException {
        return null;
    }

    @Override
    public BasicValue naryOperation(final AbstractInsnNode insn,
            final List<? extends BasicValue> values) throws AnalyzerException {
        int opcode = insn.getOpcode();
        if (opcode == MULTIANEWARRAY) {
            return newValue(Type.getType(((MultiANewArrayInsnNode) insn).desc));
        } else if (opcode == INVOKEDYNAMIC) {
            return newValue(Type
                    .getReturnType(((InvokeDynamicInsnNode) insn).desc));
        } else {
            return newValue(Type.getReturnType(((MethodInsnNode) insn).desc));
        }
    }

    @Override
    public void returnOperation(final AbstractInsnNode insn,
            final BasicValue value, final BasicValue expected)
            throws AnalyzerException {
    }

    @Override
    public BasicValue merge(final BasicValue v, final BasicValue w) {
        if (!v.equals(w)) {
            return BasicValue.UNINITIALIZED_VALUE;
        }
        return v;
    }
}









































@SuppressWarnings("serial")
class AnalyzerException extends Exception {

    public final AbstractInsnNode node;

    public AnalyzerException(final AbstractInsnNode node, final String msg) {
        super(msg);
        this.node = node;
    }

    public AnalyzerException(final AbstractInsnNode node, final String msg,
            final Throwable exception) {
        super(msg, exception);
        this.node = node;
    }

    public AnalyzerException(final AbstractInsnNode node, final String msg,
            final Object expected, final Value encountered) {
        super((msg == null ? "Expected " : msg + ": expected ") + expected
                + ", but found " + encountered);
        this.node = node;
    }
}















































@SuppressWarnings({ "unchecked" })
class Frame<V extends Value> {

    



    private V returnValue;

    


    private V[] values;

    


    private int locals;

    


    private int top;

    







    public Frame(final int nLocals, final int nStack) {
        this.values = (V[]) new Value[nLocals + nStack];
        this.locals = nLocals;
    }

    





    public Frame(final Frame<? extends V> src) {
        this(src.locals, src.values.length - src.locals);
        init(src);
    }

    






    public Frame<V> init(final Frame<? extends V> src) {
        returnValue = src.returnValue;
        System.arraycopy(src.values, 0, values, 0, values.length);
        top = src.top;
        return this;
    }

    






    public void setReturn(final V v) {
        returnValue = v;
    }

    




    public int getLocals() {
        return locals;
    }

    




    public int getMaxStackSize() {
        return values.length - locals;
    }
    
    








    public V getLocal(final int i) throws IndexOutOfBoundsException {
        if (i >= locals) {
            throw new IndexOutOfBoundsException(
                    "Trying to access an inexistant local variable");
        }
        return values[i];
    }

    









    public void setLocal(final int i, final V value)
            throws IndexOutOfBoundsException {
        if (i >= locals) {
            throw new IndexOutOfBoundsException(
                    "Trying to access an inexistant local variable " + i);
        }
        values[i] = value;
    }

    





    public int getStackSize() {
        return top;
    }

    








    public V getStack(final int i) throws IndexOutOfBoundsException {
        return values[i + locals];
    }

    


    public void clearStack() {
        top = 0;
    }

    






    public V pop() throws IndexOutOfBoundsException {
        if (top == 0) {
            throw new IndexOutOfBoundsException(
                    "Cannot pop operand off an empty stack.");
        }
        return values[--top + locals];
    }

    







    public void push(final V value) throws IndexOutOfBoundsException {
        if (top + locals >= values.length) {
            throw new IndexOutOfBoundsException(
                    "Insufficient maximum stack size.");
        }
        values[top++ + locals] = value;
    }

    public void execute(final AbstractInsnNode insn,
            final Interpreter<V> interpreter) throws AnalyzerException {
        V value1, value2, value3, value4;
        List<V> values;
        int var;

        switch (insn.getOpcode()) {
        case Opcodes.NOP:
            break;
        case Opcodes.ACONST_NULL:
        case Opcodes.ICONST_M1:
        case Opcodes.ICONST_0:
        case Opcodes.ICONST_1:
        case Opcodes.ICONST_2:
        case Opcodes.ICONST_3:
        case Opcodes.ICONST_4:
        case Opcodes.ICONST_5:
        case Opcodes.LCONST_0:
        case Opcodes.LCONST_1:
        case Opcodes.FCONST_0:
        case Opcodes.FCONST_1:
        case Opcodes.FCONST_2:
        case Opcodes.DCONST_0:
        case Opcodes.DCONST_1:
        case Opcodes.BIPUSH:
        case Opcodes.SIPUSH:
        case Opcodes.LDC:
            push(interpreter.newOperation(insn));
            break;
        case Opcodes.ILOAD:
        case Opcodes.LLOAD:
        case Opcodes.FLOAD:
        case Opcodes.DLOAD:
        case Opcodes.ALOAD:
            push(interpreter.copyOperation(insn,
                    getLocal(((VarInsnNode) insn).var)));
            break;
        case Opcodes.IALOAD:
        case Opcodes.LALOAD:
        case Opcodes.FALOAD:
        case Opcodes.DALOAD:
        case Opcodes.AALOAD:
        case Opcodes.BALOAD:
        case Opcodes.CALOAD:
        case Opcodes.SALOAD:
            value2 = pop();
            value1 = pop();
            push(interpreter.binaryOperation(insn, value1, value2));
            break;
        case Opcodes.ISTORE:
        case Opcodes.LSTORE:
        case Opcodes.FSTORE:
        case Opcodes.DSTORE:
        case Opcodes.ASTORE:
            value1 = interpreter.copyOperation(insn, pop());
            var = ((VarInsnNode) insn).var;
            setLocal(var, value1);
            if (value1.getSize() == 2) {
                setLocal(var + 1, interpreter.newValue(null));
            }
            if (var > 0) {
                Value local = getLocal(var - 1);
                if (local != null && local.getSize() == 2) {
                    setLocal(var - 1, interpreter.newValue(null));
                }
            }
            break;
        case Opcodes.IASTORE:
        case Opcodes.LASTORE:
        case Opcodes.FASTORE:
        case Opcodes.DASTORE:
        case Opcodes.AASTORE:
        case Opcodes.BASTORE:
        case Opcodes.CASTORE:
        case Opcodes.SASTORE:
            value3 = pop();
            value2 = pop();
            value1 = pop();
            interpreter.ternaryOperation(insn, value1, value2, value3);
            break;
        case Opcodes.POP:
            if (pop().getSize() == 2) {
                throw new AnalyzerException(insn, "Illegal use of POP");
            }
            break;
        case Opcodes.POP2:
            if (pop().getSize() == 1) {
                if (pop().getSize() != 1) {
                    throw new AnalyzerException(insn, "Illegal use of POP2");
                }
            }
            break;
        case Opcodes.DUP:
            value1 = pop();
            if (value1.getSize() != 1) {
                throw new AnalyzerException(insn, "Illegal use of DUP");
            }
            push(value1);
            push(interpreter.copyOperation(insn, value1));
            break;
        case Opcodes.DUP_X1:
            value1 = pop();
            value2 = pop();
            if (value1.getSize() != 1 || value2.getSize() != 1) {
                throw new AnalyzerException(insn, "Illegal use of DUP_X1");
            }
            push(interpreter.copyOperation(insn, value1));
            push(value2);
            push(value1);
            break;
        case Opcodes.DUP_X2:
            value1 = pop();
            if (value1.getSize() == 1) {
                value2 = pop();
                if (value2.getSize() == 1) {
                    value3 = pop();
                    if (value3.getSize() == 1) {
                        push(interpreter.copyOperation(insn, value1));
                        push(value3);
                        push(value2);
                        push(value1);
                        break;
                    }
                } else {
                    push(interpreter.copyOperation(insn, value1));
                    push(value2);
                    push(value1);
                    break;
                }
            }
            throw new AnalyzerException(insn, "Illegal use of DUP_X2");
        case Opcodes.DUP2:
            value1 = pop();
            if (value1.getSize() == 1) {
                value2 = pop();
                if (value2.getSize() == 1) {
                    push(value2);
                    push(value1);
                    push(interpreter.copyOperation(insn, value2));
                    push(interpreter.copyOperation(insn, value1));
                    break;
                }
            } else {
                push(value1);
                push(interpreter.copyOperation(insn, value1));
                break;
            }
            throw new AnalyzerException(insn, "Illegal use of DUP2");
        case Opcodes.DUP2_X1:
            value1 = pop();
            if (value1.getSize() == 1) {
                value2 = pop();
                if (value2.getSize() == 1) {
                    value3 = pop();
                    if (value3.getSize() == 1) {
                        push(interpreter.copyOperation(insn, value2));
                        push(interpreter.copyOperation(insn, value1));
                        push(value3);
                        push(value2);
                        push(value1);
                        break;
                    }
                }
            } else {
                value2 = pop();
                if (value2.getSize() == 1) {
                    push(interpreter.copyOperation(insn, value1));
                    push(value2);
                    push(value1);
                    break;
                }
            }
            throw new AnalyzerException(insn, "Illegal use of DUP2_X1");
        case Opcodes.DUP2_X2:
            value1 = pop();
            if (value1.getSize() == 1) {
                value2 = pop();
                if (value2.getSize() == 1) {
                    value3 = pop();
                    if (value3.getSize() == 1) {
                        value4 = pop();
                        if (value4.getSize() == 1) {
                            push(interpreter.copyOperation(insn, value2));
                            push(interpreter.copyOperation(insn, value1));
                            push(value4);
                            push(value3);
                            push(value2);
                            push(value1);
                            break;
                        }
                    } else {
                        push(interpreter.copyOperation(insn, value2));
                        push(interpreter.copyOperation(insn, value1));
                        push(value3);
                        push(value2);
                        push(value1);
                        break;
                    }
                }
            } else {
                value2 = pop();
                if (value2.getSize() == 1) {
                    value3 = pop();
                    if (value3.getSize() == 1) {
                        push(interpreter.copyOperation(insn, value1));
                        push(value3);
                        push(value2);
                        push(value1);
                        break;
                    }
                } else {
                    push(interpreter.copyOperation(insn, value1));
                    push(value2);
                    push(value1);
                    break;
                }
            }
            throw new AnalyzerException(insn, "Illegal use of DUP2_X2");
        case Opcodes.SWAP:
            value2 = pop();
            value1 = pop();
            if (value1.getSize() != 1 || value2.getSize() != 1) {
                throw new AnalyzerException(insn, "Illegal use of SWAP");
            }
            push(interpreter.copyOperation(insn, value2));
            push(interpreter.copyOperation(insn, value1));
            break;
        case Opcodes.IADD:
        case Opcodes.LADD:
        case Opcodes.FADD:
        case Opcodes.DADD:
        case Opcodes.ISUB:
        case Opcodes.LSUB:
        case Opcodes.FSUB:
        case Opcodes.DSUB:
        case Opcodes.IMUL:
        case Opcodes.LMUL:
        case Opcodes.FMUL:
        case Opcodes.DMUL:
        case Opcodes.IDIV:
        case Opcodes.LDIV:
        case Opcodes.FDIV:
        case Opcodes.DDIV:
        case Opcodes.IREM:
        case Opcodes.LREM:
        case Opcodes.FREM:
        case Opcodes.DREM:
            value2 = pop();
            value1 = pop();
            push(interpreter.binaryOperation(insn, value1, value2));
            break;
        case Opcodes.INEG:
        case Opcodes.LNEG:
        case Opcodes.FNEG:
        case Opcodes.DNEG:
            push(interpreter.unaryOperation(insn, pop()));
            break;
        case Opcodes.ISHL:
        case Opcodes.LSHL:
        case Opcodes.ISHR:
        case Opcodes.LSHR:
        case Opcodes.IUSHR:
        case Opcodes.LUSHR:
        case Opcodes.IAND:
        case Opcodes.LAND:
        case Opcodes.IOR:
        case Opcodes.LOR:
        case Opcodes.IXOR:
        case Opcodes.LXOR:
            value2 = pop();
            value1 = pop();
            push(interpreter.binaryOperation(insn, value1, value2));
            break;
        case Opcodes.IINC:
            var = ((IincInsnNode) insn).var;
            setLocal(var, interpreter.unaryOperation(insn, getLocal(var)));
            break;
        case Opcodes.I2L:
        case Opcodes.I2F:
        case Opcodes.I2D:
        case Opcodes.L2I:
        case Opcodes.L2F:
        case Opcodes.L2D:
        case Opcodes.F2I:
        case Opcodes.F2L:
        case Opcodes.F2D:
        case Opcodes.D2I:
        case Opcodes.D2L:
        case Opcodes.D2F:
        case Opcodes.I2B:
        case Opcodes.I2C:
        case Opcodes.I2S:
            push(interpreter.unaryOperation(insn, pop()));
            break;
        case Opcodes.LCMP:
        case Opcodes.FCMPL:
        case Opcodes.FCMPG:
        case Opcodes.DCMPL:
        case Opcodes.DCMPG:
            value2 = pop();
            value1 = pop();
            push(interpreter.binaryOperation(insn, value1, value2));
            break;
        case Opcodes.IFEQ:
        case Opcodes.IFNE:
        case Opcodes.IFLT:
        case Opcodes.IFGE:
        case Opcodes.IFGT:
        case Opcodes.IFLE:
            interpreter.unaryOperation(insn, pop());
            break;
        case Opcodes.IF_ICMPEQ:
        case Opcodes.IF_ICMPNE:
        case Opcodes.IF_ICMPLT:
        case Opcodes.IF_ICMPGE:
        case Opcodes.IF_ICMPGT:
        case Opcodes.IF_ICMPLE:
        case Opcodes.IF_ACMPEQ:
        case Opcodes.IF_ACMPNE:
            value2 = pop();
            value1 = pop();
            interpreter.binaryOperation(insn, value1, value2);
            break;
        case Opcodes.GOTO:
            break;
        case Opcodes.JSR:
            push(interpreter.newOperation(insn));
            break;
        case Opcodes.RET:
            break;
        case Opcodes.TABLESWITCH:
        case Opcodes.LOOKUPSWITCH:
            interpreter.unaryOperation(insn, pop());
            break;
        case Opcodes.IRETURN:
        case Opcodes.LRETURN:
        case Opcodes.FRETURN:
        case Opcodes.DRETURN:
        case Opcodes.ARETURN:
            value1 = pop();
            interpreter.unaryOperation(insn, value1);
            interpreter.returnOperation(insn, value1, returnValue);
            break;
        case Opcodes.RETURN:
            if (returnValue != null) {
                throw new AnalyzerException(insn, "Incompatible return type");
            }
            break;
        case Opcodes.GETSTATIC:
            push(interpreter.newOperation(insn));
            break;
        case Opcodes.PUTSTATIC:
            interpreter.unaryOperation(insn, pop());
            break;
        case Opcodes.GETFIELD:
            push(interpreter.unaryOperation(insn, pop()));
            break;
        case Opcodes.PUTFIELD:
            value2 = pop();
            value1 = pop();
            interpreter.binaryOperation(insn, value1, value2);
            break;
        case Opcodes.INVOKEVIRTUAL:
        case Opcodes.INVOKESPECIAL:
        case Opcodes.INVOKESTATIC:
        case Opcodes.INVOKEINTERFACE: {
            values = new ArrayList<V>();
            String desc = ((MethodInsnNode) insn).desc;
            for (int i = Type.getArgumentTypes(desc).length; i > 0; --i) {
                values.add(0, pop());
            }
            if (insn.getOpcode() != Opcodes.INVOKESTATIC) {
                values.add(0, pop());
            }
            if (Type.getReturnType(desc) == Type.VOID_TYPE) {
                interpreter.naryOperation(insn, values);
            } else {
                push(interpreter.naryOperation(insn, values));
            }
            break;
        }
        case Opcodes.INVOKEDYNAMIC: {
            values = new ArrayList<V>();
            String desc = ((InvokeDynamicInsnNode) insn).desc;
            for (int i = Type.getArgumentTypes(desc).length; i > 0; --i) {
                values.add(0, pop());
            }
            if (Type.getReturnType(desc) == Type.VOID_TYPE) {
                interpreter.naryOperation(insn, values);
            } else {
                push(interpreter.naryOperation(insn, values));
            }
            break;
        }
        case Opcodes.NEW:
            push(interpreter.newOperation(insn));
            break;
        case Opcodes.NEWARRAY:
        case Opcodes.ANEWARRAY:
        case Opcodes.ARRAYLENGTH:
            push(interpreter.unaryOperation(insn, pop()));
            break;
        case Opcodes.ATHROW:
            interpreter.unaryOperation(insn, pop());
            break;
        case Opcodes.CHECKCAST:
        case Opcodes.INSTANCEOF:
            push(interpreter.unaryOperation(insn, pop()));
            break;
        case Opcodes.MONITORENTER:
        case Opcodes.MONITOREXIT:
            interpreter.unaryOperation(insn, pop());
            break;
        case Opcodes.MULTIANEWARRAY:
            values = new ArrayList<V>();
            for (int i = ((MultiANewArrayInsnNode) insn).dims; i > 0; --i) {
                values.add(0, pop());
            }
            push(interpreter.naryOperation(insn, values));
            break;
        case Opcodes.IFNULL:
        case Opcodes.IFNONNULL:
            interpreter.unaryOperation(insn, pop());
            break;
        default:
            throw new RuntimeException("Illegal opcode " + insn.getOpcode());
        }
    }

    











    public boolean merge(final Frame<? extends V> frame,
            final Interpreter<V> interpreter) throws AnalyzerException {
        if (top != frame.top) {
            throw new AnalyzerException(null, "Incompatible stack heights");
        }
        boolean changes = false;
        for (int i = 0; i < locals + top; ++i) {
            V v = interpreter.merge(values[i], frame.values[i]);
            if (!v.equals(values[i])) {
                values[i] = v;
                changes = true;
            }
        }
        return changes;
    }

    










    public boolean merge(final Frame<? extends V> frame, final boolean[] access) {
        boolean changes = false;
        for (int i = 0; i < locals; ++i) {
            if (!access[i] && !values[i].equals(frame.values[i])) {
                values[i] = frame.values[i];
                changes = true;
            }
        }
        return changes;
    }

    




    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < getLocals(); ++i) {
            sb.append(getLocal(i));
        }
        sb.append(' ');
        for (int i = 0; i < getStackSize(); ++i) {
            sb.append(getStack(i).toString());
        }
        return sb.toString();
    }
}









































class Subroutine {

    LabelNode start;

    boolean[] access;

    List<JumpInsnNode> callers;

    private Subroutine() {
    }

    Subroutine(final LabelNode start, final int maxLocals,
            final JumpInsnNode caller) {
        this.start = start;
        this.access = new boolean[maxLocals];
        this.callers = new ArrayList<JumpInsnNode>();
        callers.add(caller);
    }

    public Subroutine copy() {
        Subroutine result = new Subroutine();
        result.start = start;
        result.access = new boolean[access.length];
        System.arraycopy(access, 0, result.access, 0, access.length);
        result.callers = new ArrayList<JumpInsnNode>(callers);
        return result;
    }

    public boolean merge(final Subroutine subroutine) throws AnalyzerException {
        boolean changes = false;
        for (int i = 0; i < access.length; ++i) {
            if (subroutine.access[i] && !access[i]) {
                access[i] = true;
                changes = true;
            }
        }
        if (subroutine.start == start) {
            for (int i = 0; i < subroutine.callers.size(); ++i) {
                JumpInsnNode caller = subroutine.callers.get(i);
                if (!callers.contains(caller)) {
                    callers.add(caller);
                    changes = true;
                }
            }
        }
        return changes;
    }
}













































@SuppressWarnings({"unchecked"  })
class Analyzer<V extends Value> implements Opcodes {

    private final Interpreter<V> interpreter;

    private int n;

    private InsnList insns;

    private List<TryCatchBlockNode>[] handlers;

    private Frame<V>[] frames;

    private Subroutine[] subroutines;

    private boolean[] queued;

    private int[] queue;

    private int top;

    






    public Analyzer(final Interpreter<V> interpreter) {
        this.interpreter = interpreter;
    }

    














    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public Frame<V>[] analyze(final String owner, final MethodNode m)
            throws AnalyzerException {
        if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) != 0) {
            frames = (Frame<V>[]) new Frame<?>[0];
            return frames;
        }
        n = m.instructions.size();
        insns = m.instructions;
        handlers = (List<TryCatchBlockNode>[]) new List<?>[n];
        frames = (Frame<V>[]) new Frame<?>[n];
        subroutines = new Subroutine[n];
        queued = new boolean[n];
        queue = new int[n];
        top = 0;

        
        for (int i = 0; i < m.tryCatchBlocks.size(); ++i) {
            TryCatchBlockNode tcb = m.tryCatchBlocks.get(i);
            int begin = insns.indexOf(tcb.start);
            int end = insns.indexOf(tcb.end);
            for (int j = begin; j < end; ++j) {
                List<TryCatchBlockNode> insnHandlers = handlers[j];
                if (insnHandlers == null) {
                    insnHandlers = new ArrayList<TryCatchBlockNode>();
                    handlers[j] = insnHandlers;
                }
                insnHandlers.add(tcb);
            }
        }

        
        Subroutine main = new Subroutine(null, m.maxLocals, null);
        List<AbstractInsnNode> subroutineCalls = new ArrayList<AbstractInsnNode>();
        Map<LabelNode, Subroutine> subroutineHeads = new HashMap<LabelNode, Subroutine>();
        findSubroutine(0, main, subroutineCalls);
        while (!subroutineCalls.isEmpty()) {
            JumpInsnNode jsr = (JumpInsnNode) subroutineCalls.remove(0);
            Subroutine sub = subroutineHeads.get(jsr.label);
            if (sub == null) {
                sub = new Subroutine(jsr.label, m.maxLocals, jsr);
                subroutineHeads.put(jsr.label, sub);
                findSubroutine(insns.indexOf(jsr.label), sub, subroutineCalls);
            } else {
                sub.callers.add(jsr);
            }
        }
        for (int i = 0; i < n; ++i) {
            if (subroutines[i] != null && subroutines[i].start == null) {
                subroutines[i] = null;
            }
        }

        
        Frame<V> current = newFrame(m.maxLocals, m.maxStack);
        Frame<V> handler = newFrame(m.maxLocals, m.maxStack);
        current.setReturn(interpreter.newValue(Type.getReturnType(m.desc)));
        Type[] args = Type.getArgumentTypes(m.desc);
        int local = 0;
        if ((m.access & ACC_STATIC) == 0) {
            Type ctype = Type.getObjectType(owner);
            current.setLocal(local++, interpreter.newValue(ctype));
        }
        for (int i = 0; i < args.length; ++i) {
            current.setLocal(local++, interpreter.newValue(args[i]));
            if (args[i].getSize() == 2) {
                current.setLocal(local++, interpreter.newValue(null));
            }
        }
        while (local < m.maxLocals) {
            current.setLocal(local++, interpreter.newValue(null));
        }
        merge(0, current, null);

        init(owner, m);

        
        while (top > 0) {
            int insn = queue[--top];
            Frame<V> f = frames[insn];
            Subroutine subroutine = subroutines[insn];
            queued[insn] = false;

            AbstractInsnNode insnNode = null;
            try {
                insnNode = m.instructions.get(insn);
                int insnOpcode = insnNode.getOpcode();
                int insnType = insnNode.getType();

                if (insnType == AbstractInsnNode.LABEL
                        || insnType == AbstractInsnNode.LINE
                        || insnType == AbstractInsnNode.FRAME) {
                    merge(insn + 1, f, subroutine);
                    newControlFlowEdge(insn, insn + 1);
                } else {
                    current.init(f).execute(insnNode, interpreter);
                    subroutine = subroutine == null ? null : subroutine.copy();

                    if (insnNode instanceof JumpInsnNode) {
                        JumpInsnNode j = (JumpInsnNode) insnNode;
                        if (insnOpcode != GOTO && insnOpcode != JSR) {
                            merge(insn + 1, current, subroutine);
                            newControlFlowEdge(insn, insn + 1);
                        }
                        int jump = insns.indexOf(j.label);
                        if (insnOpcode == JSR) {
                            merge(jump, current, new Subroutine(j.label,
                                    m.maxLocals, j));
                        } else {
                            merge(jump, current, subroutine);
                        }
                        newControlFlowEdge(insn, jump);
                    } else if (insnNode instanceof LookupSwitchInsnNode) {
                        LookupSwitchInsnNode lsi = (LookupSwitchInsnNode) insnNode;
                        int jump = insns.indexOf(lsi.dflt);
                        merge(jump, current, subroutine);
                        newControlFlowEdge(insn, jump);
                        for (int j = 0; j < lsi.labels.size(); ++j) {
                            LabelNode label = lsi.labels.get(j);
                            jump = insns.indexOf(label);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                        }
                    } else if (insnNode instanceof TableSwitchInsnNode) {
                        TableSwitchInsnNode tsi = (TableSwitchInsnNode) insnNode;
                        int jump = insns.indexOf(tsi.dflt);
                        merge(jump, current, subroutine);
                        newControlFlowEdge(insn, jump);
                        for (int j = 0; j < tsi.labels.size(); ++j) {
                            LabelNode label = tsi.labels.get(j);
                            jump = insns.indexOf(label);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                        }
                    } else if (insnOpcode == RET) {
                        if (subroutine == null) {
                            throw new AnalyzerException(insnNode,
                                    "RET instruction outside of a sub routine");
                        }
                        for (int i = 0; i < subroutine.callers.size(); ++i) {
                            JumpInsnNode caller = subroutine.callers.get(i);
                            int call = insns.indexOf(caller);
                            if (frames[call] != null) {
                                merge(call + 1, frames[call], current,
                                        subroutines[call], subroutine.access);
                                newControlFlowEdge(insn, call + 1);
                            }
                        }
                    } else if (insnOpcode != ATHROW
                            && (insnOpcode < IRETURN || insnOpcode > RETURN)) {
                        if (subroutine != null) {
                            if (insnNode instanceof VarInsnNode) {
                                int var = ((VarInsnNode) insnNode).var;
                                subroutine.access[var] = true;
                                if (insnOpcode == LLOAD || insnOpcode == DLOAD
                                        || insnOpcode == LSTORE
                                        || insnOpcode == DSTORE) {
                                    subroutine.access[var + 1] = true;
                                }
                            } else if (insnNode instanceof IincInsnNode) {
                                int var = ((IincInsnNode) insnNode).var;
                                subroutine.access[var] = true;
                            }
                        }
                        merge(insn + 1, current, subroutine);
                        newControlFlowEdge(insn, insn + 1);
                    }
                }

                List<TryCatchBlockNode> insnHandlers = handlers[insn];
                if (insnHandlers != null) {
                    for (int i = 0; i < insnHandlers.size(); ++i) {
                        TryCatchBlockNode tcb = insnHandlers.get(i);
                        Type type;
                        if (tcb.type == null) {
                            type = Type.getObjectType("java/lang/Throwable");
                        } else {
                            type = Type.getObjectType(tcb.type);
                        }
                        int jump = insns.indexOf(tcb.handler);
                        if (newControlFlowExceptionEdge(insn, tcb)) {
                            handler.init(f);
                            handler.clearStack();
                            handler.push(interpreter.newValue(type));
                            merge(jump, handler, subroutine);
                        }
                    }
                }
            } catch (AnalyzerException e) {
                throw new AnalyzerException(e.node, "Error at instruction "
                        + insn + ": " + e.getMessage(), e);
            } catch (Exception e) {
                throw new AnalyzerException(insnNode, "Error at instruction "
                        + insn + ": " + e.getMessage(), e);
            }
        }

        return frames;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private void findSubroutine(int insn, final Subroutine sub,
            final List<AbstractInsnNode> calls) throws AnalyzerException {
        while (true) {
            if (insn < 0 || insn >= n) {
                throw new AnalyzerException(null,
                        "Execution can fall off end of the code");
            }
            if (subroutines[insn] != null) {
                return;
            }
            subroutines[insn] = sub.copy();
            AbstractInsnNode node = insns.get(insn);

            
            if (node instanceof JumpInsnNode) {
                if (node.getOpcode() == JSR) {
                    
                    calls.add(node);
                } else {
                    JumpInsnNode jnode = (JumpInsnNode) node;
                    findSubroutine(insns.indexOf(jnode.label), sub, calls);
                }
            } else if (node instanceof TableSwitchInsnNode) {
                TableSwitchInsnNode tsnode = (TableSwitchInsnNode) node;
                findSubroutine(insns.indexOf(tsnode.dflt), sub, calls);
                for (int i = tsnode.labels.size() - 1; i >= 0; --i) {
                    LabelNode l = tsnode.labels.get(i);
                    findSubroutine(insns.indexOf(l), sub, calls);
                }
            } else if (node instanceof LookupSwitchInsnNode) {
                LookupSwitchInsnNode lsnode = (LookupSwitchInsnNode) node;
                findSubroutine(insns.indexOf(lsnode.dflt), sub, calls);
                for (int i = lsnode.labels.size() - 1; i >= 0; --i) {
                    LabelNode l = lsnode.labels.get(i);
                    findSubroutine(insns.indexOf(l), sub, calls);
                }
            }

            
            List<TryCatchBlockNode> insnHandlers = handlers[insn];
            if (insnHandlers != null) {
                for (int i = 0; i < insnHandlers.size(); ++i) {
                    TryCatchBlockNode tcb = insnHandlers.get(i);
                    findSubroutine(insns.indexOf(tcb.handler), sub, calls);
                }
            }

            
            switch (node.getOpcode()) {
            case GOTO:
            case RET:
            case TABLESWITCH:
            case LOOKUPSWITCH:
            case IRETURN:
            case LRETURN:
            case FRETURN:
            case DRETURN:
            case ARETURN:
            case RETURN:
            case ATHROW:
                return;
            }
            insn++;
        }
    }

    










    public Frame<V>[] getFrames() {
        return frames;
    }

    







    public List<TryCatchBlockNode> getHandlers(final int insn) {
        return handlers[insn];
    }

    











    protected void init(String owner, MethodNode m) throws AnalyzerException {
    }

    








    protected Frame<V> newFrame(final int nLocals, final int nStack) {
        return new Frame<V>(nLocals, nStack);
    }

    






    protected Frame<V> newFrame(final Frame<? extends V> src) {
        return new Frame<V>(src);
    }

    










    protected void newControlFlowEdge(final int insn, final int successor) {
    }

    














    protected boolean newControlFlowExceptionEdge(final int insn,
            final int successor) {
        return true;
    }

    


















    protected boolean newControlFlowExceptionEdge(final int insn,
            final TryCatchBlockNode tcb) {
        return newControlFlowExceptionEdge(insn, insns.indexOf(tcb.handler));
    }

    

    private void merge(final int insn, final Frame<V> frame,
            final Subroutine subroutine) throws AnalyzerException {
        Frame<V> oldFrame = frames[insn];
        Subroutine oldSubroutine = subroutines[insn];
        boolean changes;

        if (oldFrame == null) {
            frames[insn] = newFrame(frame);
            changes = true;
        } else {
            changes = oldFrame.merge(frame, interpreter);
        }

        if (oldSubroutine == null) {
            if (subroutine != null) {
                subroutines[insn] = subroutine.copy();
                changes = true;
            }
        } else {
            if (subroutine != null) {
                changes |= oldSubroutine.merge(subroutine);
            }
        }
        if (changes && !queued[insn]) {
            queued[insn] = true;
            queue[top++] = insn;
        }
    }

    private void merge(final int insn, final Frame<V> beforeJSR,
            final Frame<V> afterRET, final Subroutine subroutineBeforeJSR,
            final boolean[] access) throws AnalyzerException {
        Frame<V> oldFrame = frames[insn];
        Subroutine oldSubroutine = subroutines[insn];
        boolean changes;

        afterRET.merge(beforeJSR, access);

        if (oldFrame == null) {
            frames[insn] = newFrame(afterRET);
            changes = true;
        } else {
            changes = oldFrame.merge(afterRET, interpreter);
        }

        if (oldSubroutine != null && subroutineBeforeJSR != null) {
            changes |= oldSubroutine.merge(subroutineBeforeJSR);
        }
        if (changes && !queued[insn]) {
            queued[insn] = true;
            queue[top++] = insn;
        }
    }
}
