






































import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class method_4_qualitycheck_claude {

    public static void main(String[] args) {
        title("METHOD 4  |  MethodUtil.determineAccessorName(AccessorPrefix prefix, String fieldName)");

        section("1. the three named prefixes, on an ordinary field name");
        show(AccessorPrefix.GET, "name");
        show(AccessorPrefix.HAS, "children");
        show(AccessorPrefix.IS, "active");

        section("2. AccessorPrefix.NOT_NEEDED - the empty prefix constant");
        show(AccessorPrefix.NOT_NEEDED, "name");

        section("3. a custom prefix built through the public constructor");
        show(new AccessorPrefix("with"), "value");

        section("4. field names the PATTERN has to isolate the identifier from");
        show(AccessorPrefix.GET, "_internalId");
        show(AccessorPrefix.GET, "m_count");
        show(AccessorPrefix.GET, "123abc");
        show(AccessorPrefix.GET, "  spaced  ");

        section("5. a field name that matches nothing at all - the stateIsTrue guard fires");
        try {
            MethodUtil.determineAccessorName(AccessorPrefix.GET, "___");
            System.out.println("      !! the expected exception was not thrown");
        } catch (final IllegalStateOfArgumentException e) {
            System.out.println("      \"___\" -> IllegalStateOfArgumentException: " + e.getMessage());
        }

        section("6. a null prefix and an empty field name - the two Check guards");
        try {
            MethodUtil.determineAccessorName(null, "name");
            System.out.println("      !! the expected exception was not thrown");
        } catch (final IllegalNullArgumentException e) {
            System.out.println("      prefix == null -> IllegalNullArgumentException: " + e.getMessage());
        }
        try {
            MethodUtil.determineAccessorName(AccessorPrefix.GET, "");
            System.out.println("      !! the expected exception was not thrown");
        } catch (final IllegalEmptyArgumentException e) {
            System.out.println("      fieldName == \"\" -> IllegalEmptyArgumentException: " + e.getMessage());
        }

        section("7. the sibling determineMutatorName(String), sharing the same PATTERN and regex logic");
        System.out.println("      MethodUtil.determineMutatorName(\"count\")   = " + MethodUtil.determineMutatorName("count"));
        System.out.println("      MethodUtil.determineMutatorName(\"_hidden\") = " + MethodUtil.determineMutatorName("_hidden"));

        section("8. branch coverage summary");
        System.out.println("      Check.notNull(prefix, ...)     guard  -> scenario 6");
        System.out.println("      Check.notEmpty(fieldName, ...) guard  -> scenario 6");
        System.out.println("      m.find() == true               -> scenarios 1-4, 7");
        System.out.println("      m.find() == false, stateIsTrue  -> scenario 5");
        System.out.println("      every AccessorPrefix constant and the public constructor -> scenarios 1-3");

        title("END OF METHOD 4 SCENARIOS");
    }

    static void show(final AccessorPrefix prefix, final String fieldName) {
        System.out.print("      prefix=\"" + prefix.getPrefix() + "\", fieldName=\"" + fieldName + "\" -> ");
        try {
            System.out.println(MethodUtil.determineAccessorName(prefix, fieldName));
        } catch (final RuntimeException e) {
            System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}








@Retention(RetentionPolicy.SOURCE)
@Target({ ElementType.METHOD, ElementType.PARAMETER, ElementType.FIELD })
@interface Nonnull {
}






class IllegalNullArgumentException extends RuntimeException {

    private static final long serialVersionUID = -6988558700678645359L;

    protected static final String DEFAULT_MESSAGE = "Argument must not be null.";
    protected static final String MESSAGE_WITH_NAME = "Argument '%s' must not be null.";

    private static String format(final String argumentName) {
        return String.format(MESSAGE_WITH_NAME, argumentName);
    }

    public IllegalNullArgumentException() {
        super(DEFAULT_MESSAGE);
    }

    public IllegalNullArgumentException(final String argumentName) {
        super(format(argumentName));
    }
}






class IllegalEmptyArgumentException extends RuntimeException {

    private static final long serialVersionUID = -6988558700678645359L;

    protected static final String DEFAULT_MESSAGE = "The passed argument must not be empty.";
    protected static final String MESSAGE_WITH_NAME = "The passed argument '%s' must not be empty.";

    private static String determineMessage(final String argumentName) {
        return argumentName != null && !argumentName.isEmpty() ? format(argumentName) : DEFAULT_MESSAGE;
    }

    private static String format(final String argumentName) {
        return String.format(MESSAGE_WITH_NAME, argumentName);
    }

    public IllegalEmptyArgumentException() {
        super(DEFAULT_MESSAGE);
    }

    public IllegalEmptyArgumentException(final String argumentName) {
        super(determineMessage(argumentName));
    }
}






class IllegalStateOfArgumentException extends RuntimeException {

    private static final long serialVersionUID = -1782626786560016442L;

    protected static final String DEFAULT_MESSAGE = "Arguments must be valid with the current state.";
    protected static final String MESSAGE_DESCRIPTION = "The passed arguments have caused an invalid state: ";

    private static String format(final String descriptionTemplate, Object... descriptionTemplateArgs) {
        if (descriptionTemplateArgs == null || descriptionTemplateArgs.length == 0) {
            return MESSAGE_DESCRIPTION + descriptionTemplate;
        } else {
            return String.format(descriptionTemplate, descriptionTemplateArgs);
        }
    }

    public IllegalStateOfArgumentException() {
        super(DEFAULT_MESSAGE);
    }

    public IllegalStateOfArgumentException(final String description, Object... descriptionTemplateArgs) {
        super(format(description, descriptionTemplateArgs));
    }
}






final class Check {

    public static <T> T notNull(final T reference, final String name) {
        if (reference == null) {
            throw new IllegalNullArgumentException(name);
        }
        return reference;
    }

    public static void notEmpty(final boolean expression, final String name) {
        if (expression) {
            throw new IllegalEmptyArgumentException(name);
        }
    }

    public static <T extends CharSequence> T notEmpty(final T chars, final String name) {
        notNull(chars, name);
        notEmpty(chars.length() == 0, name);
        return chars;
    }

    public static void stateIsTrue(final boolean expression, final String descriptionTemplate,
            final Object... descriptionTemplateArgs) {
        if (!expression) {
            throw new IllegalStateOfArgumentException(descriptionTemplate, descriptionTemplateArgs);
        }
    }

    private Check() {
    }
}






final class AccessorPrefix {

    private static final String METHOD_GET_PREFIX = "get";
    private static final String METHOD_HAS_PREFIX = "has";
    private static final String METHOD_IS_PREFIX = "is";

    public static final AccessorPrefix NOT_NEEDED = new AccessorPrefix();
    public static final AccessorPrefix GET = new AccessorPrefix(METHOD_GET_PREFIX);
    public static final AccessorPrefix HAS = new AccessorPrefix(METHOD_HAS_PREFIX);
    public static final AccessorPrefix IS = new AccessorPrefix(METHOD_IS_PREFIX);

    private final String prefix;

    private AccessorPrefix() {
        prefix = "";
    }

    public AccessorPrefix(final String prefix) {
        Check.notNull(prefix, "prefix");
        this.prefix = Check.notEmpty(prefix.trim(), "prefix");
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AccessorPrefix other = (AccessorPrefix) obj;
        if (!prefix.equals(other.prefix)) {
            return false;
        }
        return true;
    }

    public String getPrefix() {
        return prefix;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + prefix.hashCode();
        return result;
    }
}







final class MethodUtil {

    private static final String METHOD_SET_PREFIX = "set";

    private static final Pattern PATTERN = Pattern.compile("([A-Za-z][A-Za-z0-9]*)");

	
	public static String determineAccessorName(@Nonnull final AccessorPrefix prefix, @Nonnull final String fieldName) {
		Check.notNull(prefix, "prefix");
		Check.notEmpty(fieldName, "fieldName");
		final Matcher m = PATTERN.matcher(fieldName);
		Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
		final String name = m.group();
		return prefix.getPrefix() + name.substring(0, 1).toUpperCase() + name.substring(1);
	}
	

    public static String determineMutatorName(final String fieldName) {
        Check.notEmpty(fieldName, "fieldName");
        final Matcher m = PATTERN.matcher(fieldName);
        Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
        final String name = m.group();
        return METHOD_SET_PREFIX + name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    private MethodUtil() {
    }
}
