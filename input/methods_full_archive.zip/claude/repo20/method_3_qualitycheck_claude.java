







































import java.math.BigDecimal;
import java.math.BigInteger;

public class method_3_qualitycheck_claude {

    public static void main(String[] args) {
        title("METHOD 3  |  Check.checkNumberInRange(String value, Class<T> type)");

        section("1. every supported target type, valid values");
        show("120", Byte.class);
        show("3.5", Double.class);
        show("2.25", Float.class);
        show("123456", Integer.class);
        show("9999999999", Long.class);
        show("30000", Short.class);
        show("123456789012345678901234567890", BigInteger.class);
        show("3.14159265358979323846", BigDecimal.class);

        section("2. values outside the target range - IllegalNumberRangeException");
        show("200", Byte.class);
        show("99999999999999999999", Integer.class);
        show("99999999999999999999999999999999999999", Long.class);
        show("999999", Short.class);

        section("3. a value that is not a number at all - NumberFormatException, wrapped by the caller");
        try {
            Check.isNumber("not-a-number", "count", Integer.class);
            System.out.println("      !! expected exception was not thrown");
        } catch (final IllegalNumberArgumentException e) {
            System.out.println("      \"not-a-number\" -> Integer : IllegalNumberArgumentException: " + e.getMessage());
            System.out.println("      cause : " + e.getCause());
        }

        section("4. an unsupported target type - the target method's own else branch");
        try {
            Check.isNumber("1", "value", castUnsafe(Number.class));
            System.out.println("      !! expected exception was not thrown");
        } catch (final IllegalNumberArgumentException e) {
            System.out.println("      Number.class -> IllegalNumberArgumentException: " + e.getMessage());
            System.out.println("      thrown directly by checkNumberInRange and propagated unchanged through");
            System.out.println("      isNumber, because it is not a NumberFormatException");
        }

        section("5. branch coverage summary");
        System.out.println("      type == Byte.class     -> scenario 1");
        System.out.println("      type == Double.class    -> scenario 1");
        System.out.println("      type == Float.class     -> scenario 1");
        System.out.println("      type == Integer.class    -> scenario 1");
        System.out.println("      type == Long.class      -> scenario 1");
        System.out.println("      type == Short.class     -> scenario 1");
        System.out.println("      type == BigInteger.class -> scenario 1");
        System.out.println("      type == BigDecimal.class -> scenario 1");
        System.out.println("      unsupported type (else)  -> scenario 4");
        System.out.println("      NumberInRange.checkXxx throwing IllegalNumberRangeException -> scenario 2");

        title("END OF METHOD 3 SCENARIOS");
    }

    @SuppressWarnings("unchecked")
    static <T extends Number> Class<T> castUnsafe(final Class<?> type) {
        return (Class<T>) type;
    }

    static void show(final String value, final Class<?> type) {
        System.out.print("      \"" + value + "\" -> " + type.getSimpleName() + pad(type.getSimpleName()) + " : ");
        try {
            final Number result = Check.isNumber(value, "value", castUnsafe(type));
            System.out.println(result + "   (" + result.getClass().getSimpleName() + ")");
        } catch (final IllegalNumberArgumentException e) {
            System.out.println("IllegalNumberArgumentException: " + e.getMessage());
        } catch (final IllegalNumberRangeException e) {
            
            
            System.out.println("IllegalNumberRangeException: " + e.getMessage());
        }
    }

    static String pad(final String s) {
        final StringBuilder sb = new StringBuilder();
        for (int i = s.length(); i < 12; i++) {
            sb.append(' ');
        }
        return sb.toString();
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}






class IllegalNullArgumentException extends RuntimeException {

    private static final long serialVersionUID = -6988558700678645359L;

    protected static final String DEFAULT_MESSAGE = "Argument must not be null.";
    protected static final String MESSAGE_WITH_NAME = "Argument '%s' must not be null.";

    private static String format(final String argumentName) {
        return String.format(MESSAGE_WITH_NAME, argumentName);
    }

    public IllegalNullArgumentException() {
        super(DEFAULT_MESSAGE);
    }

    public IllegalNullArgumentException(final String argumentName) {
        super(format(argumentName));
    }
}






class IllegalNumberRangeException extends RuntimeException {

    private static final long serialVersionUID = 8948110906636813037L;

    protected static final String DEFAULT_MESSAGE = "Number must be in a valid range for the given datatype.";
    protected static final String MESSAGE_WITH_VALUES = "Argument value '%s' must be in the range '%s' to '%s'.";

    private static String format(final String value, final BigDecimal min, final BigDecimal max) {
        return String.format(MESSAGE_WITH_VALUES, value, min.toString(), max.toString());
    }

    public IllegalNumberRangeException() {
        super(DEFAULT_MESSAGE);
    }

    public IllegalNumberRangeException(final String value, final BigDecimal min, final BigDecimal max) {
        super(format(value, min, max));
    }

    public IllegalNumberRangeException(final String value, final BigInteger min, final BigInteger max) {
        super(format(value, new BigDecimal(min), new BigDecimal(max)));
    }
}






class IllegalNumberArgumentException extends RuntimeException {

    private static final long serialVersionUID = 8431282453454923405L;

    protected static final String DEFAULT_MESSAGE = "The passed argument must be a number.";
    protected static final String MESSAGE_WITH_NAME = "The passed argument '%s' must be a number.";

    private static String determineMessage(final String argumentName) {
        return argumentName != null && !argumentName.isEmpty() ? format(argumentName) : DEFAULT_MESSAGE;
    }

    private static String format(final String argumentName) {
        return String.format(MESSAGE_WITH_NAME, argumentName);
    }

    private final CharSequence illegalArgumentValue;

    public IllegalNumberArgumentException(final CharSequence illegalArgumentValue) {
        super(DEFAULT_MESSAGE);
        this.illegalArgumentValue = illegalArgumentValue;
    }

    public IllegalNumberArgumentException(final CharSequence illegalArgumentValue, final Throwable cause) {
        super(DEFAULT_MESSAGE, cause);
        this.illegalArgumentValue = illegalArgumentValue;
    }

    public IllegalNumberArgumentException(final String argumentName, final CharSequence illegalArgumentValue) {
        super(determineMessage(argumentName));
        this.illegalArgumentValue = illegalArgumentValue;
    }

    public IllegalNumberArgumentException(final String argumentName, final CharSequence illegalArgumentValue,
            final Throwable cause) {
        super(determineMessage(argumentName), cause);
        this.illegalArgumentValue = illegalArgumentValue;
    }

    public CharSequence getIllegalArgument() {
        return illegalArgumentValue;
    }
}







final class NumberInRange {

    public static final BigInteger BYTE_MIN = BigInteger.valueOf((long) Byte.MIN_VALUE);
    public static final BigInteger BYTE_MAX = BigInteger.valueOf((long) Byte.MAX_VALUE);
    public static final BigInteger SHORT_MIN = BigInteger.valueOf((long) Short.MIN_VALUE);
    public static final BigInteger SHORT_MAX = BigInteger.valueOf((long) Short.MAX_VALUE);
    public static final BigInteger INTEGER_MIN = BigInteger.valueOf((long) Integer.MIN_VALUE);
    public static final BigInteger INTEGER_MAX = BigInteger.valueOf((long) Integer.MAX_VALUE);
    public static final BigInteger LONG_MIN = BigInteger.valueOf(Long.MIN_VALUE);
    public static final BigInteger LONG_MAX = BigInteger.valueOf(Long.MAX_VALUE);
    public static final BigDecimal FLOAT_MAX = new BigDecimal(Float.MAX_VALUE);
    public static final BigDecimal FLOAT_MIN = new BigDecimal(-Float.MAX_VALUE);
    public static final BigDecimal DOUBLE_MAX = new BigDecimal(Double.MAX_VALUE);
    public static final BigDecimal DOUBLE_MIN = new BigDecimal(-Double.MAX_VALUE);

    public static byte checkByte(final Number number) {
        Check.notNull(number, "number");
        if (!isInByteRange(number)) {
            throw new IllegalNumberRangeException(number.toString(), BYTE_MIN, BYTE_MAX);
        }
        return number.byteValue();
    }

    public static double checkDouble(final Number number) {
        Check.notNull(number, "number");
        if (!isInDoubleRange(number)) {
            throw new IllegalNumberRangeException(number.toString(), DOUBLE_MIN, DOUBLE_MAX);
        }
        return number.doubleValue();
    }

    public static float checkFloat(final Number number) {
        Check.notNull(number, "number");
        if (!isInFloatRange(number)) {
            throw new IllegalNumberRangeException(number.toString(), FLOAT_MIN, FLOAT_MAX);
        }
        return number.floatValue();
    }

    public static int checkInteger(final Number number) {
        Check.notNull(number, "number");
        if (!isInIntegerRange(number)) {
            throw new IllegalNumberRangeException(number.toString(), INTEGER_MIN, INTEGER_MAX);
        }
        return number.intValue();
    }

    public static int checkLong(final Number number) {
        Check.notNull(number, "number");
        if (!isInLongRange(number)) {
            throw new IllegalNumberRangeException(number.toString(), LONG_MIN, LONG_MAX);
        }
        return number.intValue();
    }

    public static short checkShort(final Number number) {
        Check.notNull(number, "number");
        if (!isInShortRange(number)) {
            throw new IllegalNumberRangeException(number.toString(), SHORT_MIN, SHORT_MAX);
        }
        return number.shortValue();
    }

    public static boolean isInByteRange(final Number number) {
        final BigInteger value = new BigInteger(number.toString());
        return value.compareTo(BYTE_MIN) >= 0 && value.compareTo(BYTE_MAX) <= 0;
    }

    public static boolean isInShortRange(final Number number) {
        final BigInteger value = new BigInteger(number.toString());
        return value.compareTo(SHORT_MIN) >= 0 && value.compareTo(SHORT_MAX) <= 0;
    }

    public static boolean isInIntegerRange(final Number number) {
        final BigInteger value = new BigInteger(number.toString());
        return value.compareTo(INTEGER_MIN) >= 0 && value.compareTo(INTEGER_MAX) <= 0;
    }

    public static boolean isInLongRange(final Number number) {
        final BigInteger value = new BigInteger(number.toString());
        return value.compareTo(LONG_MIN) >= 0 && value.compareTo(LONG_MAX) <= 0;
    }

    public static boolean isInFloatRange(final Number number) {
        final BigDecimal value = new BigDecimal(number.toString());
        return value.compareTo(FLOAT_MIN) >= 0 && value.compareTo(FLOAT_MAX) <= 0;
    }

    public static boolean isInDoubleRange(final Number number) {
        final BigDecimal value = new BigDecimal(number.toString());
        return value.compareTo(DOUBLE_MIN) >= 0 && value.compareTo(DOUBLE_MAX) <= 0;
    }

    private NumberInRange() {
    }
}








final class Check {

    public static <T> T notNull(final T reference) {
        if (reference == null) {
            throw new IllegalNullArgumentException();
        }
        return reference;
    }

    public static <T> T notNull(final T reference, final String name) {
        if (reference == null) {
            throw new IllegalNullArgumentException(name);
        }
        return reference;
    }

    public static <T extends Number> T isNumber(final String value, final String name, final Class<T> type) {
        Check.notNull(value, "value");
        Check.notNull(type, "type");

        final Number ret;
        try {
            ret = checkNumberInRange(value, type);
        } catch (final NumberFormatException nfe) {
            if (name == null) {
                throw new IllegalNumberArgumentException(value, nfe);
            } else {
                throw new IllegalNumberArgumentException(name, value, nfe);
            }
        }

        return type.cast(ret);
    }

	
	private static <T> Number checkNumberInRange(final String value, final Class<T> type) {
		final Number ret;
		if (type.equals(Byte.class)) {
			final Number number = new BigInteger(value);
			NumberInRange.checkByte(number);
			ret = Byte.valueOf(number.byteValue());
		} else if (type.equals(Double.class)) {
			final Number number = new BigDecimal(value);
			NumberInRange.checkDouble(number);
			ret = Double.valueOf(number.doubleValue());
		} else if (type.equals(Float.class)) {
			final Number number = new BigDecimal(value);
			NumberInRange.checkFloat(number);
			ret = Float.valueOf(number.floatValue());
		} else if (type.equals(Integer.class)) {
			final Number number = new BigInteger(value);
			NumberInRange.checkInteger(number);
			ret = Integer.valueOf(number.intValue());
		} else if (type.equals(Long.class)) {
			final Number number = new BigInteger(value);
			NumberInRange.checkLong(number);
			ret = Long.valueOf(number.longValue());
		} else if (type.equals(Short.class)) {
			final Number number = new BigInteger(value);
			NumberInRange.checkShort(number);
			ret = Short.valueOf(number.shortValue());
		} else if (type.equals(BigInteger.class)) {
			ret = new BigInteger(value);
		} else if (type.equals(BigDecimal.class)) {
			ret = new BigDecimal(value);
		} else {
			throw new IllegalNumberArgumentException("Return value is no known subclass of 'java.lang.Number': " + type.getName());
		}
		return ret;
	}
	
}
