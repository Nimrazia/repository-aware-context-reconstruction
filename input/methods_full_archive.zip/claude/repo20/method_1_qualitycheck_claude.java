




















































import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class method_1_qualitycheck_claude {

    public static void main(String[] args) {
        title("METHOD 1  |  InterfaceAnalyzer.analyze(String code)");

        section("1. a simple immutable-style interface with a package, imports and getters");
        analyze(join(
                "package com.example.model;",
                "",
                "import java.util.List;",
                "import java.io.Serializable;",
                "",
                "public interface Customer extends Serializable {",
                "    String getName();",
                "    int getAge();",
                "    List<String> getEmails();",
                "}"));

        section("2. an interface with a class level annotation and an annotated method");
        analyze(join(
                "package com.example.model;",
                "",
                "import javax.annotation.concurrent.Immutable;",
                "",
                "@Immutable",
                "public interface Coordinate {",
                "    double getLatitude();",
                "    double getLongitude();",
                "}"));

        section("3. an interface with no package declaration - Package.UNDEFINED");
        analyze(join(
                "public interface Point {",
                "    int getX();",
                "    int getY();",
                "}"));

        section("4. an interface that extends another interface");
        analyze(join(
                "package com.example.model;",
                "",
                "public interface Identified extends Comparable {",
                "    String getId();",
                "}"));

        section("5. a method that takes a parameter - hasPossibleMutatingMethods fires");
        try {
            analyze(join(
                    "package com.example.model;",
                    "",
                    "public interface Mutable {",
                    "    String getName();",
                    "    void setName(String name);",
                    "}"));
            System.out.println("      !! the expected exception was not thrown");
        } catch (final IllegalStateOfArgumentException e) {
            System.out.println("      IllegalStateOfArgumentException: " + e.getMessage());
        }

        section("6. more than one top level declaration - stateIsTrue(types.size() == 1, ...)");
        try {
            analyze(join(
                    "package com.example.model;",
                    "",
                    "interface First {",
                    "    String getName();",
                    "}",
                    "interface Second {",
                    "    String getValue();",
                    "}"));
            System.out.println("      !! the expected exception was not thrown");
        } catch (final IllegalStateOfArgumentException e) {
            System.out.println("      IllegalStateOfArgumentException: " + e.getMessage());
        }

        section("7. a null argument - Check.notNull(code, ...)");
        try {
            InterfaceAnalyzer.analyze(null);
            System.out.println("      !! the expected exception was not thrown");
        } catch (final IllegalNullArgumentException e) {
            System.out.println("      IllegalNullArgumentException: " + e.getMessage());
        }

        section("8. branch coverage summary");
        System.out.println("      Check.notNull(code, ...) guard              -> scenario 7");
        System.out.println("      Check.notEmpty(types, ...) / size() == 1    -> scenario 6");
        System.out.println("      unit.getPackage() != null                   -> scenarios 1, 2, 4, 5, 6");
        System.out.println("      unit.getPackage() == null -> Package.UNDEFINED -> scenario 3");
        System.out.println("      hasPossibleMutatingMethods(...) == true     -> scenario 5");
        System.out.println("      the extends clause / imports / annotations paths -> scenarios 1, 2, 4");

        title("END OF METHOD 1 SCENARIOS");
    }

    static void analyze(final String code) {
        System.out.println("      source:");
        for (final String line : code.split("\n")) {
            System.out.println("          " + line);
        }
        final InterfaceAnalysis analysis = InterfaceAnalyzer.analyze(code);
        System.out.println("      interfaceName : " + analysis.getInterfaceName());
        System.out.println("      package       : '" + analysis.getPackage() + "'");
        System.out.println("      imports       : " + analysis.getImports());
        System.out.println("      extends       : " + analysis.getExtends());
        System.out.println("      annotations   : " + analysis.getAnnotations());
        System.out.println("      methods       : " + analysis.getMethods().size());
        for (final Method m : analysis.getMethods()) {
            System.out.println("          " + m.getReturnType().getType() + " " + m.getName() + "()");
        }
    }

    static String join(final String... lines) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            sb.append(lines[i]);
            if (i < lines.length - 1) {
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}







final class InterfaceAnalyzer {

	
	@Nonnull
	public static InterfaceAnalysis analyze(@Nonnull final String code) {
		Check.notNull(code, "code");

		final CompilationUnit unit = Check.notNull(SourceCodeReader.parse(code), "compilationUnit");
		final List<TypeDeclaration> types = Check.notEmpty(unit.getTypes(), "typeDeclarations");
		Check.stateIsTrue(types.size() == 1, "only one interface declaration per analysis is supported");

		final ClassOrInterfaceDeclaration type = (ClassOrInterfaceDeclaration) types.get(0);

		final Imports imports = SourceCodeReader.findImports(unit.getImports());
		final Package pkg = unit.getPackage() != null ? new Package(unit.getPackage().getName().toString()) : Package.UNDEFINED;
		final List<Annotation> annotations = SourceCodeReader.findAnnotations(type.getAnnotations(), imports);
		final List<Method> methods = SourceCodeReader.findMethods(type.getMembers(), imports);
		Check.stateIsTrue(!hasPossibleMutatingMethods(methods), "The passed interface '%s' seems to have mutating methods", type.getName());
		final List<Interface> extendsInterfaces = SourceCodeReader.findExtends(type);
		final String interfaceName = type.getName();
		return new ImmutableInterfaceAnalysis(annotations, extendsInterfaces, imports.asList(), interfaceName, methods, pkg);
	}
	

    private static boolean hasPossibleMutatingMethods(final List<Method> methods) {
        boolean result = false;
        for (final Method method : methods) {
            if (!method.getAttributes().isEmpty()) {
                result = true;
                break;
            }
        }
        return result;
    }

    private InterfaceAnalyzer() {
    }
}


















class ParseException extends Exception {

    private static final long serialVersionUID = 1L;

    ParseException(final String message) {
        super(message);
    }
}


class PackageDeclaration {

    private final String name;

    PackageDeclaration(final String name) {
        this.name = name;
    }

    public NameExpr getName() {
        return new NameExpr(name);
    }
}


class NameExpr {

    private final String name;

    NameExpr(final String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}


class ImportDeclaration {

    private final String name;

    ImportDeclaration(final String name) {
        this.name = name;
    }

    public NameExpr getName() {
        return new NameExpr(name);
    }
}


class AnnotationExpr {

    private final String name;

    AnnotationExpr(final String name) {
        this.name = name;
    }

    public NameExpr getName() {
        return new NameExpr(name);
    }
}


class Type_ {

    private final String rendered;

    Type_(final String rendered) {
        this.rendered = rendered;
    }

    @Override
    public String toString() {
        return rendered;
    }
}


class ClassOrInterfaceType {

    private final String name;

    ClassOrInterfaceType(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}


class VariableDeclaratorId {

    private final String name;

    VariableDeclaratorId(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}


class Parameter {

    private final List<AnnotationExpr> annotations;
    private final Type_ type;
    private final VariableDeclaratorId id;

    Parameter(final List<AnnotationExpr> annotations, final Type_ type, final VariableDeclaratorId id) {
        this.annotations = annotations;
        this.type = type;
        this.id = id;
    }

    public List<AnnotationExpr> getAnnotations() {
        return annotations;
    }

    public Type_ getType() {
        return type;
    }

    public VariableDeclaratorId getId() {
        return id;
    }
}


abstract class BodyDeclaration {
}


class MethodDeclaration extends BodyDeclaration {

    private final List<AnnotationExpr> annotations;
    private final Type_ type;
    private final String name;
    private final List<Parameter> parameters;

    MethodDeclaration(final List<AnnotationExpr> annotations, final Type_ type, final String name,
            final List<Parameter> parameters) {
        this.annotations = annotations;
        this.type = type;
        this.name = name;
        this.parameters = parameters;
    }

    public List<AnnotationExpr> getAnnotations() {
        return annotations;
    }

    public Type_ getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public List<Parameter> getParameters() {
        return parameters;
    }
}


abstract class TypeDeclaration {

    public abstract String getName();
}


class ClassOrInterfaceDeclaration extends TypeDeclaration {

    private final String name;
    private final List<AnnotationExpr> annotations;
    private final List<BodyDeclaration> members;
    private final List<ClassOrInterfaceType> extendsList;

    ClassOrInterfaceDeclaration(final String name, final List<AnnotationExpr> annotations,
            final List<BodyDeclaration> members, final List<ClassOrInterfaceType> extendsList) {
        this.name = name;
        this.annotations = annotations;
        this.members = members;
        this.extendsList = extendsList;
    }

    @Override
    public String getName() {
        return name;
    }

    public List<AnnotationExpr> getAnnotations() {
        return annotations;
    }

    public List<BodyDeclaration> getMembers() {
        return members;
    }

    public List<ClassOrInterfaceType> getExtends() {
        return extendsList;
    }
}


class CompilationUnit {

    private final PackageDeclaration pkg;
    private final List<ImportDeclaration> imports;
    private final List<TypeDeclaration> types;

    CompilationUnit(final PackageDeclaration pkg, final List<ImportDeclaration> imports,
            final List<TypeDeclaration> types) {
        this.pkg = pkg;
        this.imports = imports;
        this.types = types;
    }

    public PackageDeclaration getPackage() {
        return pkg;
    }

    public List<ImportDeclaration> getImports() {
        return imports;
    }

    public List<TypeDeclaration> getTypes() {
        return types;
    }
}








final class JavaParser {

    private JavaParser() {
    }

    public static CompilationUnit parse(final java.io.InputStream in) throws ParseException {
        final String source;
        try {
            final java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
            final byte[] chunk = new byte[4096];
            int read;
            while ((read = in.read(chunk)) != -1) {
                buffer.write(chunk, 0, read);
            }
            source = new String(buffer.toByteArray(), "UTF-8");
        } catch (final java.io.IOException e) {
            throw new ParseException("I/O error while reading source: " + e.getMessage());
        }
        return new Tokenizer(source).parseCompilationUnit();
    }

    
    private static final class Tokenizer {

        private final String src;
        private int pos;
        private final List<String> tokens = new ArrayList<String>();
        private int idx;

        Tokenizer(final String src) {
            this.src = src;
            tokenize();
        }

        private void tokenize() {
            while (pos < src.length()) {
                final char c = src.charAt(pos);
                if (Character.isWhitespace(c)) {
                    pos++;
                } else if (c == '/' && pos + 1 < src.length() && src.charAt(pos + 1) == '/') {
                    while (pos < src.length() && src.charAt(pos) != '\n') {
                        pos++;
                    }
                } else if (c == '/' && pos + 1 < src.length() && src.charAt(pos + 1) == '*') {
                    pos += 2;
                    while (pos + 1 < src.length() && !(src.charAt(pos) == '*' && src.charAt(pos + 1) == '/')) {
                        pos++;
                    }
                    pos += 2;
                } else if (c == '"') {
                    final int start = pos;
                    pos++;
                    while (pos < src.length() && src.charAt(pos) != '"') {
                        if (src.charAt(pos) == '\\') {
                            pos++;
                        }
                        pos++;
                    }
                    pos++;
                    tokens.add(src.substring(start, Math.min(pos, src.length())));
                } else if (Character.isJavaIdentifierStart(c)) {
                    final int start = pos;
                    while (pos < src.length() && Character.isJavaIdentifierPart(src.charAt(pos))) {
                        pos++;
                    }
                    tokens.add(src.substring(start, pos));
                } else if ("(){}[]<>,;.@?".indexOf(c) >= 0) {
                    tokens.add(String.valueOf(c));
                    pos++;
                } else {
                    pos++;
                }
            }
        }

        private String peek() {
            return idx < tokens.size() ? tokens.get(idx) : null;
        }

        private String next() {
            return idx < tokens.size() ? tokens.get(idx++) : null;
        }

        private boolean atEnd() {
            return idx >= tokens.size();
        }

        private void expect(final String token) throws ParseException {
            final String actual = next();
            if (!token.equals(actual)) {
                throw new ParseException("expected '" + token + "' but found '" + actual + "'");
            }
        }

        CompilationUnit parseCompilationUnit() throws ParseException {
            PackageDeclaration pkg = null;
            final List<ImportDeclaration> imports = new ArrayList<ImportDeclaration>();
            final List<TypeDeclaration> types = new ArrayList<TypeDeclaration>();

            if ("package".equals(peek())) {
                next();
                pkg = new PackageDeclaration(parseQualifiedName());
                expect(";");
            }
            while ("import".equals(peek())) {
                next();
                imports.add(new ImportDeclaration(parseQualifiedName()));
                expect(";");
            }
            while (!atEnd()) {
                final List<AnnotationExpr> annotations = parseAnnotations();
                skipModifiers();
                if ("interface".equals(peek()) || "class".equals(peek())) {
                    types.add(parseTypeDeclaration(annotations));
                } else if (atEnd()) {
                    break;
                } else {
                    
                    next();
                }
            }
            return new CompilationUnit(pkg, imports, types);
        }

        private void skipModifiers() {
            while ("public".equals(peek()) || "abstract".equals(peek()) || "final".equals(peek())
                    || "static".equals(peek())) {
                next();
            }
        }

        private String parseQualifiedName() {
            final StringBuilder sb = new StringBuilder(next());
            while (".".equals(peek())) {
                next();
                sb.append('.').append(next());
            }
            return sb.toString();
        }

        private List<AnnotationExpr> parseAnnotations() {
            final List<AnnotationExpr> list = new ArrayList<AnnotationExpr>();
            while ("@".equals(peek())) {
                next();
                final String name = parseQualifiedName();
                list.add(new AnnotationExpr(name));
                if ("(".equals(peek())) {
                    skipBalanced("(", ")");
                }
            }
            return list;
        }

        private void skipBalanced(final String open, final String close) {
            int depth = 0;
            do {
                final String t = next();
                if (open.equals(t)) {
                    depth++;
                } else if (close.equals(t)) {
                    depth--;
                }
            } while (depth > 0 && !atEnd());
        }

        private ClassOrInterfaceDeclaration parseTypeDeclaration(final List<AnnotationExpr> annotations)
                throws ParseException {
            next(); 
            final String name = next();
            skipGenericsIfPresent();
            final List<ClassOrInterfaceType> extendsList = new ArrayList<ClassOrInterfaceType>();
            if ("extends".equals(peek())) {
                next();
                extendsList.add(parseClassOrInterfaceType());
                while (",".equals(peek())) {
                    next();
                    extendsList.add(parseClassOrInterfaceType());
                }
            }
            if ("implements".equals(peek())) {
                next();
                parseClassOrInterfaceType();
                while (",".equals(peek())) {
                    next();
                    parseClassOrInterfaceType();
                }
            }
            expect("{");
            final List<BodyDeclaration> members = new ArrayList<BodyDeclaration>();
            while (!"}".equals(peek()) && !atEnd()) {
                final BodyDeclaration member = parseMember();
                if (member != null) {
                    members.add(member);
                }
            }
            expect("}");
            return new ClassOrInterfaceDeclaration(name, annotations, members, extendsList);
        }

        private void skipGenericsIfPresent() {
            if ("<".equals(peek())) {
                skipBalanced("<", ">");
            }
        }

        private ClassOrInterfaceType parseClassOrInterfaceType() {
            final String name = parseQualifiedName();
            skipGenericsIfPresent();
            return new ClassOrInterfaceType(name);
        }

        
        private BodyDeclaration parseMember() throws ParseException {
            final List<AnnotationExpr> annotations = parseAnnotations();
            skipModifiers();
            skipGenericsIfPresent(); 
            final Type_ returnType = parseType();
            final String name = next();
            expect("(");
            final List<Parameter> parameters = new ArrayList<Parameter>();
            while (!")".equals(peek())) {
                final List<AnnotationExpr> paramAnnotations = parseAnnotations();
                skipModifiers();
                final Type_ paramType = parseType();
                final String paramName = next();
                parameters.add(new Parameter(paramAnnotations, paramType, new VariableDeclaratorId(paramName)));
                if (",".equals(peek())) {
                    next();
                }
            }
            expect(")");
            if ("throws".equals(peek())) {
                next();
                parseQualifiedName();
                while (",".equals(peek())) {
                    next();
                    parseQualifiedName();
                }
            }
            expect(";");
            return new MethodDeclaration(annotations, returnType, name, parameters);
        }

        private Type_ parseType() {
            final StringBuilder sb = new StringBuilder(next());
            while (".".equals(peek())) {
                next();
                sb.append('.').append(next());
            }
            if ("<".equals(peek())) {
                sb.append(parseGenericArgs());
            }
            while ("[".equals(peek())) {
                next();
                expect2("]");
                sb.append("[]");
            }
            return new Type_(sb.toString());
        }

        private void expect2(final String token) {
            if (token.equals(peek())) {
                next();
            }
        }

        private String parseGenericArgs() {
            final StringBuilder sb = new StringBuilder();
            sb.append(next()); 
            int depth = 1;
            while (depth > 0 && !atEnd()) {
                final String t = next();
                if ("<".equals(t)) {
                    depth++;
                } else if (">".equals(t)) {
                    depth--;
                }
                sb.append(t);
            }
            return sb.toString();
        }
    }
}








final class Objects {

    private Objects() {
    }

    public static boolean equal(final Object a, final Object b) {
        return a == b || (a != null && a.equals(b));
    }

    public static int hashCode(final Object... values) {
        return Arrays.hashCode(values);
    }
}

interface Predicate<T> {
    boolean apply(T input);
}

final class Predicates {

    private Predicates() {
    }

    public static <T> Predicate<T> and(final Predicate<? super T> first, final Predicate<? super T> second) {
        return new Predicate<T>() {
            public boolean apply(final T input) {
                return first.apply(input) && second.apply(input);
            }
        };
    }
}

final class Collections2 {

    private Collections2() {
    }

    public static <T> List<T> filter(final Collection<T> in, final Predicate<? super T> predicate) {
        final List<T> out = new ArrayList<T>();
        for (final T t : in) {
            if (predicate.apply(t)) {
                out.add(t);
            }
        }
        return out;
    }
}

final class Lists {

    private Lists() {
    }

    public static <T> List<T> newArrayList() {
        return new ArrayList<T>();
    }

    public static <T> List<T> newArrayList(final Iterable<? extends T> in) {
        final List<T> out = new ArrayList<T>();
        for (final T t : in) {
            out.add(t);
        }
        return out;
    }

    @SafeVarargs
    public static <T> List<T> newArrayList(final T... items) {
        final List<T> out = new ArrayList<T>();
        for (final T t : items) {
            out.add(t);
        }
        return out;
    }
}

final class Sets {

    private Sets() {
    }

    public static <T> java.util.HashSet<T> newHashSet(final Iterable<? extends T> in) {
        final java.util.HashSet<T> out = new java.util.HashSet<T>();
        for (final T t : in) {
            out.add(t);
        }
        return out;
    }

    public static <T> java.util.LinkedHashSet<T> newLinkedHashSet() {
        return new java.util.LinkedHashSet<T>();
    }
}


abstract class Ordering<T> implements java.util.Comparator<T> {

    
    public java.util.Comparator<T> nullsLast() {
        final Ordering<T> self = this;
        return new java.util.Comparator<T>() {
            public int compare(final T a, final T b) {
                if (a == b) {
                    return 0;
                }
                if (a == null) {
                    return 1;
                }
                if (b == null) {
                    return -1;
                }
                return self.compare(a, b);
            }
        };
    }
}

final class ImmutableList<T> extends java.util.AbstractList<T> {

    private final List<T> delegate;

    private ImmutableList(final List<T> delegate) {
        this.delegate = delegate;
    }

    public T get(final int index) {
        return delegate.get(index);
    }

    public int size() {
        return delegate.size();
    }

    public static <T> ImmutableList<T> of() {
        return new ImmutableList<T>(new ArrayList<T>());
    }

    @SafeVarargs
    public static <T> ImmutableList<T> of(final T... values) {
        return new ImmutableList<T>(Arrays.asList(values));
    }

    public static <T> ImmutableList<T> copyOf(final Iterable<? extends T> in) {
        final List<T> out = new ArrayList<T>();
        for (final T t : in) {
            out.add(t);
        }
        return new ImmutableList<T>(out);
    }
}









@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
@interface Nonnull {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
@interface Nullable {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
@interface Nonnegative {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
@java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
@interface NotThreadSafe {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
@java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
@interface Immutable {
}

@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
@java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
@interface ThreadSafe {
}









final class Check {

    public static <T> T notNull(final T reference) {
        if (reference == null) {
            throw new IllegalNullArgumentException();
        }
        return reference;
    }

    public static <T> T notNull(final T reference, final String name) {
        if (reference == null) {
            throw new IllegalNullArgumentException(name);
        }
        return reference;
    }

    public static void notEmpty(final boolean expression, final String name) {
        if (expression) {
            throw new IllegalEmptyArgumentException(name);
        }
    }

    public static <T extends CharSequence> T notEmpty(final T chars, final String name) {
        notNull(chars, name);
        notEmpty(chars.length() == 0, name);
        return chars;
    }

    public static <T extends Collection<?>> T notEmpty(final T collection, final String name) {
        notNull(collection, name);
        notEmpty(collection.isEmpty(), name);
        return collection;
    }

    public static void stateIsTrue(final boolean expression, final String descriptionTemplate,
            final Object... descriptionTemplateArgs) {
        if (!expression) {
            throw new IllegalStateOfArgumentException(descriptionTemplate, descriptionTemplateArgs);
        }
    }

    private Check() {
    }
}






class IllegalNullArgumentException extends RuntimeException {

    private static final long serialVersionUID = -6988558700678645359L;
    protected static final String DEFAULT_MESSAGE = "Argument must not be null.";
    protected static final String MESSAGE_WITH_NAME = "Argument '%s' must not be null.";

    private static String format(final String argumentName) {
        return String.format(MESSAGE_WITH_NAME, argumentName);
    }

    public IllegalNullArgumentException() {
        super(DEFAULT_MESSAGE);
    }

    public IllegalNullArgumentException(final String argumentName) {
        super(format(argumentName));
    }
}






class IllegalEmptyArgumentException extends RuntimeException {

    private static final long serialVersionUID = -6988558700678645359L;
    protected static final String DEFAULT_MESSAGE = "The passed argument must not be empty.";
    protected static final String MESSAGE_WITH_NAME = "The passed argument '%s' must not be empty.";

    private static String determineMessage(final String argumentName) {
        return argumentName != null && !argumentName.isEmpty() ? format(argumentName) : DEFAULT_MESSAGE;
    }

    private static String format(final String argumentName) {
        return String.format(MESSAGE_WITH_NAME, argumentName);
    }

    public IllegalEmptyArgumentException() {
        super(DEFAULT_MESSAGE);
    }

    public IllegalEmptyArgumentException(final String argumentName) {
        super(determineMessage(argumentName));
    }
}






class IllegalStateOfArgumentException extends RuntimeException {

    private static final long serialVersionUID = -1782626786560016442L;
    protected static final String DEFAULT_MESSAGE = "Arguments must be valid with the current state.";
    protected static final String MESSAGE_DESCRIPTION = "The passed arguments have caused an invalid state: ";

    private static String format(final String descriptionTemplate, Object... descriptionTemplateArgs) {
        if (descriptionTemplateArgs == null || descriptionTemplateArgs.length == 0) {
            return MESSAGE_DESCRIPTION + descriptionTemplate;
        } else {
            return String.format(descriptionTemplate, descriptionTemplateArgs);
        }
    }

    public IllegalStateOfArgumentException() {
        super(DEFAULT_MESSAGE);
    }

    public IllegalStateOfArgumentException(final String description, Object... descriptionTemplateArgs) {
        super(format(description, descriptionTemplateArgs));
    }
}







final class AccessorPrefix {

    private static final String METHOD_GET_PREFIX = "get";
    private static final String METHOD_HAS_PREFIX = "has";
    private static final String METHOD_IS_PREFIX = "is";

    public static final AccessorPrefix NOT_NEEDED = new AccessorPrefix();
    public static final AccessorPrefix GET = new AccessorPrefix(METHOD_GET_PREFIX);
    public static final AccessorPrefix HAS = new AccessorPrefix(METHOD_HAS_PREFIX);
    public static final AccessorPrefix IS = new AccessorPrefix(METHOD_IS_PREFIX);

    private final String prefix;

    private AccessorPrefix() {
        prefix = "";
    }

    public AccessorPrefix(final String prefix) {
        Check.notNull(prefix, "prefix");
        this.prefix = Check.notEmpty(prefix.trim(), "prefix");
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AccessorPrefix other = (AccessorPrefix) obj;
        if (!prefix.equals(other.prefix)) {
            return false;
        }
        return true;
    }

    public String getPrefix() {
        return prefix;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + prefix.hashCode();
        return result;
    }
}






final class MethodUtil {

    private static final String METHOD_SET_PREFIX = "set";

    private static final java.util.regex.Pattern PATTERN = java.util.regex.Pattern.compile("([A-Za-z][A-Za-z0-9]*)");

    public static String determineAccessorName(final AccessorPrefix prefix, final String fieldName) {
        Check.notNull(prefix, "prefix");
        Check.notEmpty(fieldName, "fieldName");
        final java.util.regex.Matcher m = PATTERN.matcher(fieldName);
        Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
        final String name = m.group();
        return prefix.getPrefix() + name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    public static String determineMutatorName(final String fieldName) {
        Check.notEmpty(fieldName, "fieldName");
        final java.util.regex.Matcher m = PATTERN.matcher(fieldName);
        Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
        final String name = m.group();
        return METHOD_SET_PREFIX + name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    private MethodUtil() {
    }
}









interface Modifier {

	




	String getName();

}





interface Characters {

	


	char AT_SIGN = '@';

	


	char BRACE_CLOSE = '}';

	


	char BRACE_OPEN = '{';

	


	char BRACKET_CLOSE = '>';

	


	char BRACKET_OPEN = '<';

	


	char COMMA = ',';

	


	String COMMA_SPACE = ", ";

	


	char DOT = '.';

	


	char EQUALS_SIGN = '=';

	


	char NEWLINE = '\n';

	


	char PARENTHESES_CLOSE = ')';

	


	char PARENTHESES_OPEN = '(';

	


	char SEMICOLON = ';';

	


	char SPACE = ' ';

}





enum ReservedWord {

	ABSTRACT("abstract"),

	ASSERT("assert"),

	BOOLEAN("boolean"),

	BREAK("break"),

	BYTE("byte"),

	CASE("case"),

	CATCH("catch"),

	CHAR("char"),

	CLASS("class"),

	CONST("const"),

	CONTINUE("continue"),

	DEFAULT("default"),

	DO("do"),

	DOUBLE("double"),

	ELSE("else"),

	ENUM("enum"),

	EXTENDS("extends"),

	FINAL("final"),

	FINALLY("finally"),

	FLOAT("float"),

	FOR("for"),

	GOTO("goto"),

	IF("if"),

	IMPLEMENTS("implements"),

	IMPORT("import"),

	INSTANCEOF("instanceof"),

	INT("int"),

	INTERFACE("interface"),

	LONG("long"),

	NATIVE("native"),

	NEW("new"),

	PACKAGE("package"),

	PRIVATE("private"),

	PROTECTED("protected"),

	PUBLIC("public"),

	RETURN("return"),

	SHORT("short"),

	STATIC("static"),

	STRICTFP("strictfp"),

	SUPER("super"),

	SWITCH("switch"),

	SYNCHRONIZED("synchronized"),

	THIS("this"),

	THROW("throw"),

	THROWS("throws"),

	TRANSIENT("transient"),

	TRY("try"),

	VOID("void"),

	VOLATILE("volatile"),

	WHILE("while");

	public static boolean isReserved(final String word) {
		Check.notNull(word, "word");
		boolean ret = false;
		for (final ReservedWord w : values()) {
			if (w.word.equals(word)) {
				ret = true;
				break;
			}
		}
		return ret;
	}

	private final String word;

	ReservedWord(final String word) {
		this.word = word;
	}

	public String getWord() {
		return word;
	}

}





enum CollectionVariant {

	COLLECTION(Collection.class, "new ArrayList%s(%s)", "Lists.newArrayList(%s)", "Collections.unmodifiableList(new ArrayList%s(%s))",
			"ImmutableCollection.copyOf(%s)"),

	ITERABLE(Iterable.class, "new ArrayList%s(%s)", "Lists.newArrayList(%s)", "Collections.unmodifiableList(new ArrayList%s(%s))",
			"ImmutableCollection.copyOf(%s)"),

	LIST(List.class, "new ArrayList%s(%s)", "Lists.newArrayList(%s)", "Collections.unmodifiableList(new ArrayList%s(%s))",
			"ImmutableList.copyOf(%s)"),

	MAP(Map.class, "new HashMap%s(%s)", "Maps.newHashMap(%s)", "Collections.unmodifiableMap(new HashMap%s(%s))", "ImmutableMap.copyOf(%s)"),

	SET(Set.class, "new HashSet%s(%s)", "Sets.newHashSet(%s)", "Collections.unmodifiableSet(new HashSet%s(%s))", "ImmutableSet.copyOf(%s)"),

	SORTEDMAP(SortedMap.class, "new TreeMap%s(%s)", "Maps.newTreeMap(%s)", "Collections.unmodifiableSortedMap(new TreeMap%s(%s))",
			"ImmutableSortedMap.copyOf(%s)"),

	SORTEDSET(SortedSet.class, "new TreeSet%s(%s)", "Sets.newTreeSet(%)", "Collections.unmodifiableSortedSet(new TreeSet%s(%s))",
			"ImmutableSortedSet.copyOf(%s)");

	@Nullable
	public static CollectionVariant evaluate(@Nonnull final Package pkg, @Nonnull final String typeName) {
		Check.notNull(pkg, "pkg");
		Check.notNull(typeName, "typeName");
		CollectionVariant variant = null;
		for (final CollectionVariant v : values()) {
			if (v.type.getPackage().getName().equals(pkg.getName()) && v.type.getSimpleName().equals(typeName)) {
				variant = v;
				break;
			}
		}
		return variant;
	}

	@Nullable
	public static CollectionVariant evaluate(@Nonnull final Type type) {
		Check.notNull(type, "type");
		return evaluate(type.getPackage(), type.getName());
	}

	private final String defaultCopy;
	private final String defaultImmutable;
	private final String guavaCopy;
	private final String guavaImmutable;
	private final Class<?> type;

	CollectionVariant(@Nonnull final Class<?> type, @Nonnull final String defaultCopy, @Nonnull final String guavaCopy,
			@Nonnull final String defaultImmutable, @Nonnull final String guavaImmutable) {
		this.type = Check.notNull(type, "type");
		this.defaultCopy = Check.notNull(defaultCopy, "defaultCopy");
		this.guavaCopy = Check.notNull(guavaCopy, "guavaCopy");
		this.defaultImmutable = Check.notNull(defaultImmutable, "defaultImmutable");
		this.guavaImmutable = Check.notNull(guavaImmutable, "guavaImmutable");
	}

	public String getDefaultCopy() {
		return defaultCopy;
	}

	public String getDefaultImmutable() {
		return defaultImmutable;
	}

	public String getGuavaCopy() {
		return guavaCopy;
	}

	public String getGuavaImmutable() {
		return guavaImmutable;
	}

}








@Immutable
final class Package {

	


	public static final Package UNDEFINED = new Package();

	


	public static final Package JAVA_LANG = new Package("java.lang");

	


	private static final String PREFIX = "package";

	






	private static String removeLastDot(final String pkgName) {
		return pkgName.charAt(pkgName.length() - 1) == Characters.DOT ? pkgName.substring(0, pkgName.length() - 1) : pkgName;
	}

	


	@Nonnull
	private final String name;

	


	private Package() {
		name = "";
	}

	





	public Package(@Nonnull final String packageName) {
		Check.notEmpty(packageName, "packageName");
		name = Check.notEmpty(removeLastDot(packageName.trim()), "packageName");
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Package other = (Package) obj;
		if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}

	




	@Nonnull
	public String getName() {
		return name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + name.hashCode();
		return result;
	}

	public boolean isUndefined() {
		return UNDEFINED.equals(this);
	}

	@Override
	public String toString() {
		return PREFIX + Characters.SPACE + name;
	}

}








@Immutable
final class Type {

	


	public static final Type BOOLEAN = new Type(Package.UNDEFINED, Primitive.BOOLEAN.getName(), GenericDeclaration.UNDEFINED);

	


	public static final Type BOOLEAN_BOXED = new Type(Package.JAVA_LANG, Boolean.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final Type BYTE = new Type(Package.UNDEFINED, Primitive.BYTE.getName(), GenericDeclaration.UNDEFINED);

	


	public static final Type BYTE_BOXED = new Type(Package.JAVA_LANG, Byte.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final Type CHAR = new Type(Package.UNDEFINED, Primitive.CHAR.getName(), GenericDeclaration.UNDEFINED);

	


	public static final Type CHARACTER_BOXED = new Type(Package.JAVA_LANG, Character.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final Type DOUBLE = new Type(Package.UNDEFINED, Primitive.DOUBLE.getName(), GenericDeclaration.UNDEFINED);

	


	public static final Type DOUBLE_BOXED = new Type(Package.JAVA_LANG, Double.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final Type FLOAT = new Type(Package.UNDEFINED, Primitive.FLOAT.getName(), GenericDeclaration.UNDEFINED);

	


	public static final Type FLOAT_BOXED = new Type(Package.JAVA_LANG, Float.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final Type INT = new Type(Package.UNDEFINED, Primitive.INT.getName(), GenericDeclaration.UNDEFINED);

	


	public static final Type INTEGER_BOXED = new Type(Package.JAVA_LANG, Integer.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final Type LONG = new Type(Package.UNDEFINED, Primitive.LONG.getName(), GenericDeclaration.UNDEFINED);

	


	public static final Type LONG_BOXED = new Type(Package.JAVA_LANG, Long.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final Type NUMBER = new Type(Package.JAVA_LANG, Number.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	




	private static final Pattern PATTERN = Pattern.compile("^(((\\d|\\w)+\\.)*)((\\d|\\w)+)(\\$((\\d|\\w)+))?(<([\\w\\?].*)>)?$");

	


	public static final Type SHORT = new Type(Package.UNDEFINED, Primitive.SHORT.getName(), GenericDeclaration.UNDEFINED);

	


	public static final Type SHORT_BOXED = new Type(Package.JAVA_LANG, Short.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final Type STRING = new Type(Package.JAVA_LANG, String.class.getSimpleName(), GenericDeclaration.UNDEFINED);

	


	public static final List<Type> JAVA_LANG_VALUE_TYPES = ImmutableList.of(BOOLEAN_BOXED, BYTE_BOXED, CHARACTER_BOXED, DOUBLE_BOXED,
			FLOAT_BOXED, INTEGER_BOXED, LONG_BOXED, NUMBER, SHORT_BOXED, STRING);

	







	@Nonnull
	private static GenericDeclaration createGenericDeclaration(@Nonnull final String declaration) {
		Check.notNull(declaration, "declaration");
		return declaration.isEmpty() ? GenericDeclaration.UNDEFINED : GenericDeclaration.of(declaration);
	}

	







	@Nonnull
	private static Package createPackage(@Nonnull final String packageName) {
		Check.notNull(packageName, "packageName");
		return packageName.isEmpty() ? Package.UNDEFINED : new Package(packageName);
	}

	







	@Nullable
	public static Type evaluateJavaLangType(@Nonnull final String name) {
		Check.notEmpty(name, "name");
		Type ret = null;
		for (final Type type : JAVA_LANG_VALUE_TYPES) {
			if (type.getName().equals(name.replace("java.lang.", ""))) {
				ret = type;
				break;
			}
		}
		return ret;
	}

	@Nonnull
	public static Type of(@Nonnull final Class<?> clazz) {
		Check.notNull(clazz, "clazz");
		return new Type(clazz.getName());
	}

	@Nullable
	private final transient boolean collectionVariant;

	@Nonnull
	private final GenericDeclaration genericDeclaration;

	@Nonnull
	private final String name;

	@Nonnull
	private final Package packageDeclaration;

	public Type(@Nonnull final Package pkg, @Nonnull final String name, @Nonnull final GenericDeclaration genericDeclaration) {
		packageDeclaration = Check.notNull(pkg, "pkg");
		this.name = Check.notEmpty(name, "name");
		this.genericDeclaration = Check.notNull(genericDeclaration, "genericDeclaration");
		collectionVariant = CollectionVariant.evaluate(pkg, name) != null ? true : false;
	}

	public Type(@Nonnull final String qualifiedName) {
		Check.notNull(qualifiedName, "qualifiedName");
		final Matcher m = PATTERN.matcher(Check.notEmpty(qualifiedName.trim(), "qualifiedName"));
		Check.stateIsTrue(m.matches(), "qualified name must match against: %s", PATTERN.pattern());
		
		final Package pkg = m.group(7) != null ? createPackage(m.group(1) + m.group(4)) : createPackage(m.group(1));
		final String name = m.group(7) != null ? m.group(7) : Check.notEmpty(m.group(4), "name");
		collectionVariant = CollectionVariant.evaluate(pkg, name) != null ? true : false;
		genericDeclaration = m.group(10) != null ? createGenericDeclaration(m.group(10)) : GenericDeclaration.UNDEFINED;
		packageDeclaration = pkg;
		this.name = name;
	}

	public Type(@Nonnull final String packageName, @Nonnull final String typeName, @Nonnull final String genericDeclaration) {
		this(createPackage(Check.notNull(packageName, "packageName")), Check.notEmpty(typeName, "typeName"), createGenericDeclaration(Check
				.notNull(genericDeclaration, "genericDeclaration")));
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Type other = (Type) obj;
		if (!genericDeclaration.equals(other.genericDeclaration)) {
			return false;
		}
		if (!packageDeclaration.equals(other.packageDeclaration)) {
			return false;
		}
		if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}

	@Nonnull
	public GenericDeclaration getGenericDeclaration() {
		return genericDeclaration;
	}

	@Nonnull
	public String getName() {
		return name;
	}

	@Nonnull
	public Package getPackage() {
		return packageDeclaration;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + genericDeclaration.hashCode();
		result = prime * result + packageDeclaration.hashCode();
		result = prime * result + name.hashCode();
		return result;
	}

	public boolean isBoolean() {
		return equals(BOOLEAN);
	}

	public boolean isBoxedBoolean() {
		return equals(BOOLEAN_BOXED);
	}

	public boolean isBoxedByte() {
		return equals(BYTE_BOXED);
	}

	public boolean isBoxedCharacter() {
		return equals(CHARACTER_BOXED);
	}

	public boolean isBoxedDouble() {
		return equals(DOUBLE_BOXED);
	}

	public boolean isBoxedFloat() {
		return equals(FLOAT_BOXED);
	}

	public boolean isBoxedInteger() {
		return equals(INTEGER_BOXED);
	}

	public boolean isBoxedLong() {
		return equals(LONG_BOXED);
	}

	public boolean isBoxedShort() {
		return equals(SHORT_BOXED);
	}

	public boolean isBoxedType() {
		return isBoxedBoolean() || isBoxedByte() || isBoxedCharacter() || isBoxedDouble() || isBoxedFloat() || isBoxedInteger()
				|| isBoxedLong() || isBoxedShort();
	}

	public boolean isByte() {
		return equals(BYTE);
	}

	public boolean isChar() {
		return equals(CHAR);
	}

	public boolean isCollectionVariant() {
		return collectionVariant;
	}

	public boolean isDouble() {
		return equals(DOUBLE);
	}

	public boolean isFloat() {
		return equals(FLOAT);
	}

	public boolean isInt() {
		return equals(INT);
	}

	public boolean isJavaLangType() {
		return isBoxedType() || isNumber() || isString();
	}

	public boolean isLong() {
		return equals(LONG);
	}

	public boolean isNumber() {
		return equals(NUMBER);
	}

	public boolean isPrimitive() {
		return Primitive.isPrimitive(name);
	}

	public boolean isShort() {
		return equals(SHORT);
	}

	public boolean isString() {
		return equals(STRING);
	}

	@Override
	public String toString() {
		final StringBuilder b = new StringBuilder();
		if (!packageDeclaration.getName().isEmpty()) {
			b.append(packageDeclaration.getName());
			b.append(Characters.DOT);
		}
		b.append(name);
		if (!genericDeclaration.getDeclaration().isEmpty()) {
			b.append('<');
			b.append(genericDeclaration.getDeclaration());
			b.append('>');
		}
		return b.toString();
	}

}





final class GenericDeclaration {

	


	public static final GenericDeclaration UNDEFINED = new GenericDeclaration();

	


	private static final Pattern PATTERN = Pattern.compile("((\\w[\\d\\w])*)(<(\\w+.*)>)?");

	public static GenericDeclaration of(@Nonnull final String declaration) {
		return new GenericDeclaration(Check.notEmpty(declaration, "declaration"));
	}

	public static GenericDeclaration parseFrom(@Nonnull final String typeDeclaration) {
		Check.notNull(typeDeclaration, "typeDeclaration");
		final Matcher m = PATTERN.matcher(typeDeclaration);
		return m.matches() && m.group(4) != null ? GenericDeclaration.of(m.group(4)) : GenericDeclaration.UNDEFINED;
	}

	@Nonnull
	private final String declaration;

	


	private GenericDeclaration() {
		declaration = "";
	}

	private GenericDeclaration(@Nonnull final String declaration) {
		this.declaration = Check.notEmpty(declaration, "declaration");
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final GenericDeclaration other = (GenericDeclaration) obj;
		if (!declaration.equals(other.declaration)) {
			return false;
		}
		return true;
	}

	public String getDeclaration() {
		return declaration;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + declaration.hashCode();
		return result;
	}

	public boolean isUndefined() {
		return UNDEFINED.equals(this);
	}

	@Override
	public String toString() {
		return declaration;
	}

}





enum Primitive {

	BOOLEAN(ReservedWord.BOOLEAN.getWord()),

	BYTE(ReservedWord.BYTE.getWord()),

	LONG(ReservedWord.LONG.getWord()),

	INT(ReservedWord.INT.getWord()),

	DOUBLE(ReservedWord.DOUBLE.getWord()),

	FLOAT(ReservedWord.FLOAT.getWord()),

	CHAR(ReservedWord.CHAR.getWord()),

	SHORT(ReservedWord.SHORT.getWord());

	public static boolean isPrimitive(final String name) {
		Check.notNull(name, "name");
		boolean ret = false;
		for (final Primitive p : values()) {
			if (p.name.equals(name)) {
				ret = true;
				break;
			}
		}
		return ret;
	}

	private final String name;

	private Primitive(final String name) {
		this.name = Check.notNull(name);
	}

	public String getName() {
		return name;
	}

}





@Immutable
final class Annotation {

	


	public static final Annotation IMMUTABLE = Annotation.of(Immutable.class);

	


	public static final Annotation NONNEGATIVE = Annotation.of(Nonnegative.class);

	


	public static final Annotation NONNULL = Annotation.of(Nonnull.class);

	


	public static final Annotation NOT_THREAD_SAFE = Annotation.of(NotThreadSafe.class);

	


	public static final Annotation NULLABLE = Annotation.of(Nullable.class);

	public static Annotation of(@Nonnull final Class<?> annotationType) {
		Check.notNull(annotationType, "annotationType");
		Check.stateIsTrue(annotationType.isAnnotation(), "requires an annotation");
		return new Annotation(Type.of(annotationType));
	}

	public static Annotation of(@Nonnull final java.lang.annotation.Annotation annotation) {
		Check.notNull(annotation, "annotation");
		return new Annotation(Type.of(annotation.annotationType()));
	}

	public static Annotation of(@Nonnull final String annotationType) {
		Check.notEmpty(annotationType, "annotationType");
		return new Annotation(new Type(annotationType));
	}

	private final Type type;

	public Annotation(final Type annotationType) {
		type = Check.notNull(annotationType, "annotationType");
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Annotation other = (Annotation) obj;
		if (!type.equals(other.type)) {
			return false;
		}
		return true;
	}

	public Type getType() {
		return type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + type.hashCode();
		return result;
	}

	public boolean isImmutable() {
		return IMMUTABLE.equals(this);
	}

	public boolean isNonnegative() {
		return NONNEGATIVE.equals(this);
	}

	public boolean isNonnull() {
		return NONNULL.equals(this);
	}

	public boolean isNotThreadSafe() {
		return NOT_THREAD_SAFE.equals(this);
	}

	public boolean isNullable() {
		return NULLABLE.equals(this);
	}

	@Override
	public String toString() {
		return Characters.AT_SIGN + type.getName();
	}

}








@Immutable
final class Import {

	


	private static final String PREFIX = "import";

	private static Type filterGenericDeclaration(final Type type) {
		return type.getGenericDeclaration() == GenericDeclaration.UNDEFINED ? type : new Type(type.getPackage(), type.getName(),
				GenericDeclaration.UNDEFINED);
	}

	public static Import of(@Nonnull final Annotation annotation) {
		Check.notNull(annotation, "annotation");
		return of(annotation.getType());
	}

	public static Import of(@Nonnull final Attribute attribute) {
		Check.notNull(attribute, "attribute");
		return of(attribute.getType());
	}

	public static Import of(@Nonnull final Class<?> type) {
		Check.notNull(type, "type");
		return of(Type.of(type));
	}

	public static Import of(@Nonnull final Field field) {
		Check.notNull(field, "field");
		return of(field.getType());
	}

	public static Import of(@Nonnull final Interface interfaceType) {
		Check.notNull(interfaceType, "interfaceType");
		return of(interfaceType.getType());
	}

	public static Import of(@Nonnull final String type) {
		return Import.of(new Type(Check.notNull(type, "type")));
	}

	public static Import of(@Nonnull final Type type) {
		return new Import(Check.notNull(type, "type"));
	}

	@Nonnull
	private final Type type;

	private Import(@Nonnull final Type type) {
		this.type = filterGenericDeclaration(Check.notNull(type, "type"));
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Import other = (Import) obj;
		if (!type.equals(other.type)) {
			return false;
		}
		return true;
	}

	public Type getType() {
		return type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + type.hashCode();
		return result;
	}

	@Override
	public String toString() {
		return PREFIX + Characters.SPACE + type.toString() + Characters.SEMICOLON;
	}

}








@Immutable
final class Imports {

	private static final Predicate<Import> IGNORE_JAVA_LANG = new Predicate<Import>() {
		@Override
		public boolean apply(@Nonnull final Import imp) { 
			return !Package.JAVA_LANG.equals(imp.getType().getPackage());
		}
	};

	private static final Predicate<Import> IGNORE_UNDEFINED = new Predicate<Import>() {
		@Override
		public boolean apply(@Nonnull final Import imp) { 
			return !Package.UNDEFINED.equals(imp.getType().getPackage());
		}
	};

	private static final Ordering<Import> ORDER = new Ordering<Import>() {
		@Override
		public int compare(@Nonnull final Import left, @Nonnull final Import right) { 
			return left.getType().toString().compareTo(right.getType().toString());
		}
	};

	public static Imports allOf(@Nonnull final Clazz clazz) {
		Check.notNull(clazz, "clazz");
		final List<Import> imports = Lists.newArrayList();
		imports.addAll(ofAnnotations(clazz.getAnnotations()).asList());
		imports.addAll(ofConstructors(clazz.getConstructors()).asList());
		imports.addAll(ofFields(clazz.getFields()).asList());
		imports.addAll(ofInterfaces(clazz.getInterfaces()).asList());
		imports.addAll(ofMethods(clazz.getMethods()).asList());
		return new Imports(imports);
	}

	public static Imports allOf(@Nonnull final Field field) {
		Check.notNull(field, "field");
		final List<Import> imports = Lists.newArrayList();
		imports.add(Import.of(field));
		imports.addAll(ofAnnotations(field.getAnnotations()).asList());
		return new Imports(imports);
	}

	public static Imports allOf(@Nonnull final Method method) {
		Check.notNull(method, "method");
		final List<Import> imports = Lists.newArrayList();
		imports.add(Import.of(method.getReturnType().getType()));
		imports.addAll(ofAnnotations(method.getAnnotations()).asList());
		return new Imports(imports);
	}

	public static Imports copyOf(final Iterable<Import> imports) {
		Check.notNull(imports, "imports");
		return new Imports(imports);
	}

	public static Imports of(final Import... imports) {
		Check.notNull(imports, "imports");
		return new Imports(Lists.newArrayList(imports));
	}

	public static Imports of(final Iterable<Import> imports) {
		Check.notNull(imports, "imports");
		return new Imports(Lists.newArrayList(imports));
	}

	private static Imports ofAnnotations(@Nonnull final Iterable<Annotation> annotations) {
		Check.notNull(annotations, "annotations");
		final List<Import> imports = Lists.newArrayList();
		for (final Annotation annotation : annotations) {
			imports.add(Import.of(annotation));
		}
		return new Imports(imports);
	}

	private static Imports ofAttributes(@Nonnull final Iterable<Attribute> attributes) {
		Check.notNull(attributes, "attributes");
		final List<Import> imports = Lists.newArrayList();
		for (final Attribute attribute : attributes) {
			imports.add(Import.of(attribute));
		}
		return new Imports(imports);
	}

	private static Imports ofConstructors(@Nonnull final Iterable<Constructor> constructors) {
		Check.notNull(constructors, "attributes");
		final List<Import> imports = Lists.newArrayList();
		for (final Constructor constructor : constructors) {
			imports.addAll(ofAnnotations(constructor.getAnnotations()).asList());
			imports.addAll(ofAttributes(constructor.getAttributes()).asList());
		}
		return new Imports(imports);
	}

	private static Imports ofFields(@Nonnull final Iterable<Field> fields) {
		Check.notNull(fields, "fields");
		final List<Import> imports = Lists.newArrayList();
		for (final Field field : fields) {
			imports.add(Import.of(field));
		}
		return new Imports(imports);
	}

	private static Imports ofInterfaces(@Nonnull final Iterable<Interface> interfaces) {
		Check.notNull(interfaces, "interfaces");
		final List<Import> imports = Lists.newArrayList();
		for (final Interface i : interfaces) {
			imports.add(Import.of(i));
		}
		return new Imports(imports);
	}

	private static Imports ofMethods(@Nonnull final Iterable<Method> methods) {
		Check.notNull(methods, "methods");
		final List<Import> imports = Lists.newArrayList();
		for (final Method method : methods) {
			imports.addAll(allOf(method).asList());
		}
		return new Imports(imports);
	}

	@Nonnull
	private final List<Import> imports;

	private Imports(final Iterable<Import> imports) {
		Check.notNull(imports, "imports");
		this.imports = ImmutableList.copyOf(imports);
	}

	




	@Nonnull
	public List<Import> asList() {
		return imports;
	}

	






	@Nonnull
	public Imports copyAndAdd(final Collection<Import> imports) {
		Check.notNull(imports, "imports");
		final List<Import> internal = Lists.newArrayList(imports);
		internal.addAll(imports);
		return new Imports(internal);
	}

	






	@Nonnull
	public Imports copyAndAdd(final Imports imports) {
		Check.notNull(imports, "imports");
		return copyAndAdd(imports.asList());
	}

	





	@Nonnull
	public Imports filter() {
		return new Imports(Sets.newHashSet(Collections2.filter(imports, Predicates.and(IGNORE_JAVA_LANG, IGNORE_UNDEFINED))));
	}

	






	@Nullable
	public Import find(@Nonnull final String typeName) {
		Check.notEmpty(typeName, "typeName");
		Import ret = null;
		final Type type = new Type(typeName);
		for (final Import imp : imports) {
			if (imp.getType().getName().equals(type.getName())) {
				ret = imp;
				break;
			}
		}
		if (ret == null) {
			final Type javaLangType = Type.evaluateJavaLangType(typeName);
			if (javaLangType != null) {
				ret = Import.of(javaLangType);
			}
		}
		return ret;
	}

	




	@Nonnull
	public Imports sortByName() {
		final List<Import> imports = Lists.newArrayList(this.imports);
		Collections.sort(imports, ORDER.nullsLast());
		return new Imports(imports);
	}

}





@Immutable
final class Interface {

	public static final Interface UNDEFINED = new Interface();

	public static Interface of(@Nonnull final Class<?> interfaceType) {
		Check.notNull(interfaceType, "interfaceType");
		Check.stateIsTrue(interfaceType.isInterface(), "requires an interface");
		return new Interface(Type.of(interfaceType));
	}

	public static Interface of(@Nonnull final String interfaceType) {
		Check.notEmpty(interfaceType, "interfaceType");
		return new Interface(new Type(interfaceType));
	}

	@Nonnull
	private final Type type;

	public Interface() {
		type = new Type("void");
	}

	public Interface(final Type interfaceType) {
		type = Check.notNull(interfaceType, "interfaceType");
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Interface other = (Interface) obj;
		if (!type.equals(other.type)) {
			return false;
		}
		return true;
	}

	public Type getType() {
		return type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + type.hashCode();
		return result;
	}

	@Override
	public String toString() {
		return type.toString();
	}

}








@Immutable
final class Method {

	@Nonnull
	private final String name;

	@Nonnull
	private final ReturnType returnType;

	@Nonnull
	private final List<Attribute> attributes;

	@Nonnull
	private final Visibility visibility;

	@Nonnull
	private final Final final1;

	@Nonnull
	private final Static static1;

	@Nonnull
	private final List<Annotation> annotations;

	public Method(@Nonnull final String name, @Nonnull final ReturnType returnType, @Nonnull final List<Attribute> attributes,
			@Nonnull final Visibility visibility, @Nonnull final Final final1, @Nonnull final Static static1,
			@Nonnull final List<Annotation> annotations) {
		this.name = Check.notEmpty(name, "name");
		this.returnType = Check.notNull(returnType, "returnType");
		this.attributes = ImmutableList.copyOf(Check.notNull(attributes, "attributes"));
		this.visibility = Check.notNull(visibility, "visibility");
		this.final1 = Check.notNull(final1, "final1");
		this.static1 = Check.notNull(static1, "static1");
		this.annotations = ImmutableList.copyOf(Check.notNull(annotations, "annotations"));
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Method other = (Method) obj;
		return Objects.equal(name, other.name) && Objects.equal(returnType, other.returnType)
				&& Objects.equal(attributes, other.attributes) && Objects.equal(visibility, other.visibility)
				&& Objects.equal(final1, other.final1) && Objects.equal(static1, other.static1)
				&& Objects.equal(annotations, other.annotations);
	}

	@Nonnull
	public List<Annotation> getAnnotations() {
		return annotations;
	}

	@Nonnull
	public List<Attribute> getAttributes() {
		return attributes;
	}

	@Nonnull
	public Final getFinal() {
		return final1;
	}

	@Nonnull
	public String getName() {
		return name;
	}

	@Nonnull
	public ReturnType getReturnType() {
		return returnType;
	}

	@Nonnull
	public Static getStatic() {
		return static1;
	}

	@Nonnull
	public Visibility getVisibility() {
		return visibility;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(name, returnType, attributes, visibility, final1, static1, annotations);
	}

	@Override
	public String toString() {
		return "Method [name=" + name + ", returnType=" + returnType + ", attributes=" + attributes + ", visibility=" + visibility
				+ ", final1=" + final1 + ", static1=" + static1 + ", annotations=" + annotations + "]";
	}

}





@Immutable
final class Attribute {

	@Nonnull
	private final List<Annotation> annotations;

	@Nonnull
	private final Final finalModifier;

	@Nonnull
	private final String name;

	@Nonnull
	private final Type type;

	public Attribute(@Nonnull final String name, @Nonnull final Type type, @Nonnull final Final finalModifier,
			@Nonnull final List<Annotation> annotations) {
		this.name = Check.notNull(name, "name");
		this.type = Check.notNull(type, "type");
		this.finalModifier = Check.notNull(finalModifier, "finalModifier");
		this.annotations = ImmutableList.copyOf(Check.notNull(annotations, "annotations"));
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Attribute other = (Attribute) obj;
		return Objects.equal(annotations, other.annotations) && Objects.equal(finalModifier, other.finalModifier)
				&& Objects.equal(name, other.name) && Objects.equal(type, other.type);
	}

	@Nonnull
	public List<Annotation> getAnnotations() {
		return annotations;
	}

	@Nonnull
	public Final getFinal() {
		return finalModifier;
	}

	@Nonnull
	public String getName() {
		return name;
	}

	@Nonnull
	public Type getType() {
		return type;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(annotations, finalModifier, name, type);
	}

	@Override
	public String toString() {
		return "Attribute [annotations=" + annotations + ", final1=" + finalModifier + ", name=" + name + ", type=" + type + "]";
	}

}





@Immutable
final class ReturnType {

	public static final ReturnType BOOLEAN = ReturnType.of("boolean");

	public static final ReturnType INT = ReturnType.of("int");

	public static final ReturnType VOID = new ReturnType();

	public static ReturnType of(@Nonnull final Class<?> clazz) {
		return new ReturnType(Type.of(Check.notNull(clazz, "clazz")));
	}

	public static ReturnType of(@Nonnull final String type) {
		return new ReturnType(new Type(Check.notEmpty(type, "type")));
	}

	public static ReturnType of(@Nonnull final Type type) {
		return new ReturnType(Check.notNull(type, "type"));
	}

	@Nonnull
	private final Type type;

	private ReturnType() {
		type = new Type("void");
	}

	private ReturnType(@Nonnull final Type type) {
		this.type = Check.notNull(type, "type");
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ReturnType other = (ReturnType) obj;
		if (!type.equals(other.type)) {
			return false;
		}
		return true;
	}

	public Type getType() {
		return type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + type.hashCode();
		return result;
	}

	@Override
	public String toString() {
		return type.toString();
	}

}





interface InterfaceAnalysis {

	@Nonnull
	List<Annotation> getAnnotations();

	@Nonnull
	List<Interface> getExtends();

	@Nonnull
	List<Import> getImports();

	@Nonnull
	String getInterfaceName();

	@Nonnull
	List<Method> getMethods();

	@Nonnull
	Package getPackage();

}





@Immutable
final class ImmutableInterfaceAnalysis implements InterfaceAnalysis {

	@Nonnull
	public static ImmutableInterfaceAnalysis copyOf(@Nonnull final InterfaceAnalysis interfaceanalysis) {
		Check.notNull(interfaceanalysis, "interfaceanalysis");
		return new ImmutableInterfaceAnalysis(interfaceanalysis.getAnnotations(), interfaceanalysis.getExtends(),
				interfaceanalysis.getImports(), interfaceanalysis.getInterfaceName(), interfaceanalysis.getMethods(),
				interfaceanalysis.getPackage());
	}

	@Nonnull
	private final List<Annotation> annotations;

	@Nonnull
	private final List<Interface> extends1;

	@Nonnull
	private final List<Import> imports;

	@Nonnull
	private final String interfaceName;

	@Nonnull
	private final List<Method> methods;

	@Nonnull
	private final Package package1;

	public ImmutableInterfaceAnalysis(@Nonnull final List<Annotation> annotations, @Nonnull final List<Interface> extends1,
			@Nonnull final List<Import> imports, @Nonnull final String interfaceName, @Nonnull final List<Method> methods,
			@Nonnull final Package package1) {
		this.annotations = ImmutableList.copyOf(Check.notNull(annotations, "annotations"));
		this.extends1 = ImmutableList.copyOf(Check.notNull(extends1, "extends1"));
		this.imports = ImmutableList.copyOf(Check.notNull(imports, "imports"));
		this.interfaceName = Check.notNull(interfaceName, "interfaceName");
		this.methods = ImmutableList.copyOf(Check.notNull(methods, "methods"));
		this.package1 = Check.notNull(package1, "package1");
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ImmutableInterfaceAnalysis other = (ImmutableInterfaceAnalysis) obj;
		return Objects.equal(annotations, other.annotations) && Objects.equal(extends1, other.extends1)
				&& Objects.equal(imports, other.imports) && Objects.equal(interfaceName, other.interfaceName)
				&& Objects.equal(methods, other.methods) && Objects.equal(package1, other.package1);
	}

	@Override
	@Nonnull
	public List<Annotation> getAnnotations() {
		return annotations;
	}

	@Override
	@Nonnull
	public List<Interface> getExtends() {
		return extends1;
	}

	@Override
	@Nonnull
	public List<Import> getImports() {
		return imports;
	}

	@Override
	@Nonnull
	public String getInterfaceName() {
		return interfaceName;
	}

	@Override
	@Nonnull
	public List<Method> getMethods() {
		return methods;
	}

	@Override
	@Nonnull
	public Package getPackage() {
		return package1;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(annotations, extends1, imports, interfaceName, methods, package1);
	}

}








enum Final implements Modifier {

	


	UNDEFINED(""),

	


	FINAL("final");

	private final String name;

	Final(@Nonnull final String name) {
		this.name = name;
	}

	@Override
	@Nonnull
	public String getName() {
		return name;
	}

	public boolean isUndefined() {
		return UNDEFINED.equals(this);
	}

}








enum Static implements Modifier {

	


	UNDEFINED(""),

	STATIC("static");

	private final String name;

	Static(@Nonnull final String name) {
		this.name = name;
	}

	@Override
	@Nonnull
	public String getName() {
		return name;
	}

	public boolean isUndefined() {
		return UNDEFINED.equals(this);
	}

}








enum Visibility implements Modifier {

	


	UNDEFINED(""),

	PRIVATE("private"),

	PROTECTED("protected"),

	PUBLIC("public");

	private final String name;

	Visibility(@Nonnull final String name) {
		this.name = name;
	}

	@Override
	@Nonnull
	public String getName() {
		return name;
	}

	public boolean isUndefined() {
		return UNDEFINED.equals(this);
	}

}








enum Abstract implements Modifier {

	


	UNDEFINED(""),

	


	ABSTRACT("abstract");

	private final String name;

	Abstract(@Nonnull final String name) {
		this.name = name;
	}

	@Override
	@Nonnull
	public String getName() {
		return name;
	}

	public boolean isUndefined() {
		return UNDEFINED.equals(this);
	}

}





@Immutable
final class Field {

	


	public static final String WITHOUT_VALUE = "";

	@Nonnull
	private final transient String accessorMethodName;

	@Nonnull
	private final AccessorPrefix accessorPrefix;

	@Nonnull
	private final List<Annotation> annotations;

	@Nonnull
	private final Final finalModifier;

	@Nonnull
	private final transient String mutatorMethodName;

	@Nonnull
	private final String name;

	@Nonnull
	private final Static staticModifier;

	@Nonnull
	private final Type type;

	@Nonnull
	private final String value;

	@Nonnull
	private final Visibility visibility;

	public Field(@Nonnull final String name, @Nonnull final Type type, @Nonnull final Visibility visibility,
			@Nonnull final Final finalModifier, @Nonnull final Static staticModifier, @Nonnull final List<Annotation> annotations,
			@Nonnull final String value, @Nonnull final AccessorPrefix accessorPrefix) {
		this.name = Check.notNull(name, "name");
		this.type = Check.notNull(type, "type");
		this.visibility = Check.notNull(visibility, "visibility");
		this.finalModifier = Check.notNull(finalModifier, "finalModifier");
		this.staticModifier = Check.notNull(staticModifier, "staticModifier");
		this.annotations = ImmutableList.copyOf(Check.notNull(annotations, "annotations"));
		this.value = Check.notNull(value, "value");
		this.accessorPrefix = Check.notNull(accessorPrefix, "accessorPrefix");

		accessorMethodName = MethodUtil.determineAccessorName(accessorPrefix, name);
		mutatorMethodName = MethodUtil.determineMutatorName(name);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Field other = (Field) obj;
		return Objects.equal(accessorPrefix, other.accessorPrefix) && Objects.equal(annotations, other.annotations)
				&& Objects.equal(finalModifier, other.finalModifier) && Objects.equal(name, other.name)
				&& Objects.equal(staticModifier, other.staticModifier) && Objects.equal(type, other.type)
				&& Objects.equal(value, other.value) && Objects.equal(visibility, other.visibility);
	}

	public String getAccessorMethodName() {
		return accessorMethodName;
	}

	@Nonnull
	public AccessorPrefix getAccessorPrefix() {
		return accessorPrefix;
	}

	@Nonnull
	public List<Annotation> getAnnotations() {
		return annotations;
	}

	@Nonnull
	public Final getFinal() {
		return finalModifier;
	}

	public String getMutatorMethodName() {
		return mutatorMethodName;
	}

	@Nonnull
	public String getName() {
		return name;
	}

	@Nonnull
	public Static getStatic() {
		return staticModifier;
	}

	@Nonnull
	public Type getType() {
		return type;
	}

	@Nonnull
	public String getValue() {
		return value;
	}

	@Nonnull
	public Visibility getVisibility() {
		return visibility;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(accessorPrefix, annotations, finalModifier, name, staticModifier, type, value, visibility);
	}

	public boolean isNonnegative() {
		return annotations.contains(Annotation.NONNEGATIVE);
	}

	public boolean isNonnull() {
		return annotations.contains(Annotation.NONNULL);
	}

	public boolean isNullable() {
		return annotations.contains(Annotation.NULLABLE) || !(isNonnull() || isNonnegative());
	}

	@Override
	public String toString() {
		return "Field [accessorPrefix=" + accessorPrefix + ", annotations=" + annotations + ", final1=" + finalModifier + ", name=" + name
				+ ", static1=" + staticModifier + ", type=" + type + ", value=" + value + ", visibility=" + visibility + "]";
	}

}





@Immutable
final class Constructor {

	@Nonnull
	private final List<Annotation> annotations;

	@Nonnull
	private final List<Attribute> attributes;

	@Nonnull
	private final String name;

	@Nonnull
	private final Visibility visibility;

	public Constructor(@Nonnull final String name, @Nonnull final List<Attribute> attributes, @Nonnull final Visibility visibility,
			@Nonnull final List<Annotation> annotations) {
		this.name = Check.notEmpty(name, "name");
		this.attributes = ImmutableList.copyOf(Check.notNull(attributes, "attributes"));
		this.visibility = Check.notNull(visibility, "visibility");
		this.annotations = ImmutableList.copyOf(Check.notNull(annotations, "annotations"));
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Constructor other = (Constructor) obj;
		return Objects.equal(name, other.name) && Objects.equal(attributes, other.attributes)
				&& Objects.equal(visibility, other.visibility) && Objects.equal(annotations, other.annotations);
	}

	@Nonnull
	public List<Annotation> getAnnotations() {
		return annotations;
	}

	@Nonnull
	public List<Attribute> getAttributes() {
		return attributes;
	}

	@Nonnull
	public String getName() {
		return name;
	}

	@Nonnull
	public Visibility getVisibility() {
		return visibility;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(name, attributes, visibility, annotations);
	}

	@Override
	public String toString() {
		return "Constructor [name=" + name + ", attributes=" + attributes + ", visibility=" + visibility + ", annotations=" + annotations
				+ "]";
	}

}





@Immutable
final class Clazz {

	@Nonnull
	private final Abstract abstractModifier;

	@Nonnull
	private final List<Annotation> annotations;

	@Nonnull
	private final List<Constructor> constructors;

	@Nonnull
	private final List<Field> fields;

	@Nonnull
	private final Final finalModifier;

	@Nonnull
	private final List<Import> imports;

	@Nonnull
	private final List<Interface> interfaces;

	@Nonnull
	private final List<Method> methods;

	@Nonnull
	private final String name;

	@Nonnull
	private final Package package1;

	@Nonnull
	private final Visibility visibility;

	public Clazz(@Nonnull final String name, @Nonnull final Package package1, @Nonnull final List<Field> fields,
			@Nonnull final List<Constructor> constructors, @Nonnull final List<Method> methods, @Nonnull final Visibility visibility,
			@Nonnull final Final final1, @Nonnull final Abstract abstract1, @Nonnull final List<Interface> interfaces,
			@Nonnull final List<Import> imports, @Nonnull final List<Annotation> annotations) {
		this.name = Check.notEmpty(name, "name");
		this.package1 = Check.notNull(package1, "package1");
		this.fields = ImmutableList.copyOf(Check.notNull(fields, "fields"));
		this.constructors = ImmutableList.copyOf(Check.notNull(constructors, "constructors"));
		this.methods = ImmutableList.copyOf(Check.notNull(methods, "methods"));
		this.visibility = Check.notNull(visibility, "visibility");
		finalModifier = Check.notNull(final1, "final1");
		abstractModifier = Check.notNull(abstract1, "abstract1");
		this.interfaces = ImmutableList.copyOf(Check.notNull(interfaces, "interfaces"));
		this.imports = ImmutableList.copyOf(Check.notNull(imports, "imports"));

		
		Check.notNull(annotations, "annotations");
		this.annotations = ImmutableList.copyOf(Annotations.of(annotations).removeUnqualified(imports).getAnnotations());

		Check.stateIsTrue(!abstractAndFinal(), "A class can be either abstract or final, not both.");
	}

	private boolean abstractAndFinal() {
		return abstractModifier == Abstract.ABSTRACT && finalModifier == Final.FINAL ? true : false;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Clazz other = (Clazz) obj;
		return Objects.equal(name, other.name) && Objects.equal(package1, other.package1) && Objects.equal(fields, other.fields)
				&& Objects.equal(constructors, other.constructors) && Objects.equal(methods, other.methods)
				&& Objects.equal(visibility, other.visibility) && Objects.equal(finalModifier, other.finalModifier)
				&& Objects.equal(abstractModifier, other.abstractModifier) && Objects.equal(interfaces, other.interfaces)
				&& Objects.equal(imports, other.imports) && Objects.equal(annotations, other.annotations);
	}

	@Nonnull
	public Abstract getAbstract() {
		return abstractModifier;
	}

	@Nonnull
	public List<Annotation> getAnnotations() {
		return annotations;
	}

	@Nonnull
	public List<Constructor> getConstructors() {
		return constructors;
	}

	@Nonnull
	public List<Field> getFields() {
		return fields;
	}

	@Nonnull
	public Final getFinal() {
		return finalModifier;
	}

	@Nonnull
	public List<Import> getImports() {
		return Imports.copyOf(imports).copyAndAdd(Imports.allOf(this)).filter().sortByName().asList();
	}

	@Nonnull
	public List<Interface> getInterfaces() {
		return interfaces;
	}

	@Nonnull
	public List<Method> getMethods() {
		return methods;
	}

	@Nonnull
	public String getName() {
		return name;
	}

	@Nonnull
	public Package getPackage() {
		return package1;
	}

	@Nonnull
	public Visibility getVisibility() {
		return visibility;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(name, package1, fields, constructors, methods, visibility, finalModifier, abstractModifier, interfaces,
				imports, annotations);
	}

	@Override
	public String toString() {
		return "Clazz [name=" + name + ", package1=" + package1 + ", fields=" + fields + ", constructors=" + constructors + ", methods="
				+ methods + ", visibility=" + visibility + ", final1=" + finalModifier + ", abstract1=" + abstractModifier
				+ ", interfaces=" + interfaces + ", imports=" + imports + ", annotations=" + annotations + "]";
	}

}





@Immutable
final class Annotations {

	@Nonnull
	public static Annotations of(@Nonnull final Iterable<Annotation> annotations) {
		Check.notNull(annotations, "annotations");
		return new Annotations(annotations);
	}

	@Nonnull
	private static Set<Annotation> removeUnqualified(@Nonnull final List<Annotation> annotations, @Nonnull final Imports imports) {
		final Set<Annotation> result = Sets.newLinkedHashSet();
		for (final Annotation annotation : annotations) {
			if (annotation.getType().getPackage() == Package.UNDEFINED) {
				final Import imp = imports.find(annotation.getType().getName());
				if (imp != null) {
					result.add(new Annotation(imp.getType()));
				}
			} else {
				result.add(annotation);
			}
		}
		return result;
	}

	@Nonnull
	private final List<Annotation> _annotations;

	private Annotations(@Nonnull final Iterable<Annotation> annotations) {
		Check.notNull(annotations, "annotations");
		_annotations = ImmutableList.copyOf(annotations);
	}

	@Nonnull
	public List<Annotation> getAnnotations() {
		return _annotations;
	}

	@Nonnull
	public Annotations removeUnqualified(@Nonnull final List<Import> imports) {
		Check.notNull(imports, "imports");
		return Annotations.of(removeUnqualified(getAnnotations(), Imports.copyOf(imports)));
	}

}










@ThreadSafe
final class SourceCodeReader {

	@Nonnull
	public static Method createMethod(@Nonnull final MethodDeclaration methodDeclaration, @Nonnull final Imports imports) {
		Check.notNull(methodDeclaration, "methodDeclaration");
		Check.notNull(imports, "imports");
		final List<Annotation> annotations = findAnnotations(methodDeclaration.getAnnotations(), imports);
		final List<Attribute> attributes = findAttributes(methodDeclaration.getParameters(), imports);
		final ReturnType returnType = ReturnType.of(findType(methodDeclaration.getType(), imports));
		return new Method(methodDeclaration.getName(), returnType, attributes, Visibility.PUBLIC, Final.UNDEFINED, Static.UNDEFINED,
				annotations);
	}

	@Nonnull
	public static List<Annotation> findAnnotations(@Nullable final List<AnnotationExpr> annotationExprs, @Nonnull final Imports imports) {
		Check.notNull(imports, "imports");
		final List<Annotation> annotations = Lists.newArrayList();
		if (annotationExprs != null) {
			for (final AnnotationExpr annotation : annotationExprs) {
				final String name = annotation.getName().toString();
				if (!name.isEmpty()) {
					final Import imp = imports.find(name);
					if (imp != null) {
						annotations.add(new Annotation(imp.getType()));
					}
				}
			}
		}
		return annotations;
	}

	@Nonnull
	public static List<Attribute> findAttributes(@Nullable final List<Parameter> parameters, @Nonnull final Imports imports) {
		Check.notNull(imports, "imports");
		final List<Attribute> attributes = Lists.newArrayList();
		if (parameters != null) {
			for (final Parameter parameter : parameters) {
				final VariableDeclaratorId var = parameter.getId();
				final Type type = findType(parameter.getType(), imports);
				final List<Annotation> annotations = findAnnotations(parameter.getAnnotations(), imports);
				attributes.add(new Attribute(var.getName(), type, Final.UNDEFINED, annotations));
			}
		}
		return attributes;
	}

	public static List<Interface> findExtends(@Nonnull final ClassOrInterfaceDeclaration type) {
		final List<Interface> ret = Lists.newArrayList();
		if (type.getExtends() != null) {
			for (final ClassOrInterfaceType extend : type.getExtends()) {
				ret.add(Interface.of(extend.getName()));
			}
		}
		return ret;
	}

	@Nonnull
	public static Imports findImports(@Nullable final List<ImportDeclaration> importDeclarations) {
		final List<Import> imports = Lists.newArrayList();
		if (importDeclarations != null) {
			for (final ImportDeclaration importDeclaration : importDeclarations) {
				imports.add(Import.of(importDeclaration.getName().toString()));
			}
		}
		return Imports.copyOf(imports);
	}

	@Nonnull
	public static List<Method> findMethods(@Nonnull final List<BodyDeclaration> members, @Nonnull final Imports imports) {
		Check.notNull(members, "members");
		Check.notNull(imports, "imports");
		final List<Method> methods = Lists.newArrayList();
		for (final BodyDeclaration member : members) {
			if (member instanceof MethodDeclaration) {
				methods.add(createMethod((MethodDeclaration) member, imports));
			}
		}
		return methods;
	}

	@Nonnull
	public static Type findType(@Nonnull final Type_ type, @Nonnull final Imports imports) {
		Check.notNull(type, "type");
		Check.notNull(imports, "imports");
		final Type ret;
		if (Primitive.isPrimitive(type.toString())) {
			ret = new Type(type.toString());
		} else {
			final Type t = new Type(type.toString());
			final Import imp = imports.find(t.getName());
			ret = imp != null ? new Type(imp.getType().getPackage(), imp.getType().getName(), t.getGenericDeclaration()) : t;
		}
		return ret;
	}

	@Nullable
	static CompilationUnit parse(@Nonnull final String code) {
		Check.notNull(code, "code");
		CompilationUnit unit = null;
		try {
			unit = JavaParser.parse(new ByteArrayInputStream(code.getBytes("UTF-8")));
		} catch (final UnsupportedEncodingException e) {
			throw new RuntimeException("Character encoding is not supported: switch to UTF-8");
		} catch (final ParseException e) {
			throw new RuntimeException("Failed to parse interface: " + e.getLocalizedMessage(), e);
		}
		return unit;
	}

	


	private SourceCodeReader() {
		
	}

}

