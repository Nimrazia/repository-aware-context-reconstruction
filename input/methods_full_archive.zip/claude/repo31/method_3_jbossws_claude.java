





















import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class method_3_jbossws_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== Log4jOutputStream.flush() - repository-aware reconstruction ===");
      System.out.println("Repository : jbossws/jbossws-common-tools @ d05ad85663d706e5f0d634f2f8ca6665a6147b3e");
      System.out.println();

      RecordingAppender appender = new RecordingAppender();
      Category category = Category.getInstance("org.jboss.ws.tools.cmd");
      category.addAppender(appender);
      category.setLevel(Priority.DEBUG); 

      
      
      
      
      
      System.out.println("--- Scenario 1: normal message, no early return ---");
      Log4jOutputStream out1 = new Log4jOutputStream(category, Priority.INFO);
      writeString(out1, "compiling module descriptor for org.jboss.ws.api");
      out1.flush();
      System.out.println("messages recorded : " + appender.events.size());
      System.out.println("last message       : \"" + appender.events.get(appender.events.size() - 1).message + "\"");
      System.out.println("last priority       : " + appender.events.get(appender.events.size() - 1).priority);
      System.out.println("count field reset to 0 after flush : " + (out1.getCount() == 0));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 2: flush() called with nothing buffered ---");
      int before = appender.events.size();
      Log4jOutputStream out2 = new Log4jOutputStream(category, Priority.DEBUG);
      out2.flush();
      System.out.println("events before : " + before + ", events after : " + appender.events.size());
      System.out.println("no new message was logged : " + (appender.events.size() == before));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: buffer holding only the line separator ---");
      String sep = System.getProperty("line.separator");
      before = appender.events.size();
      Log4jOutputStream out3 = new Log4jOutputStream(category, Priority.WARN);
      writeString(out3, sep);
      out3.flush();
      System.out.println("line.separator length : " + sep.length());
      System.out.println("events before : " + before + ", events after : " + appender.events.size());
      System.out.println("blank line was swallowed : " + (appender.events.size() == before));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 4: PrintStream(Log4jOutputStream, autoFlush=true) idiom ---");
      before = appender.events.size();
      Log4jOutputStream errStream = new Log4jOutputStream(category, Priority.ERROR);
      java.io.PrintStream captured = new java.io.PrintStream(errStream, true);
      captured.println("stack trace line 1");
      captured.println("stack trace line 2");
      System.out.println("events logged via PrintStream.println (auto-flush) : " + (appender.events.size() - before));
      for (int i = before; i < appender.events.size(); i++)
      {
         System.out.println("  [" + appender.events.get(i).priority + "] " + appender.events.get(i).message.trim());
      }
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 5: large payload that grows the internal buffer ---");
      before = appender.events.size();
      Log4jOutputStream out5 = new Log4jOutputStream(category, Priority.DEBUG);
      StringBuilder big = new StringBuilder();
      for (int i = 0; i < 3000; i++)
      {
         big.append((char) ('a' + (i % 26)));
      }
      writeString(out5, big.toString());
      out5.flush();
      String recorded = appender.events.get(appender.events.size() - 1).message;
      System.out.println("payload length            : " + big.length());
      System.out.println("recorded message length   : " + recorded.length());
      System.out.println("payload fully round-tripped : " + big.toString().equals(recorded));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 6: constructor argument validation ---");
      try
      {
         new Log4jOutputStream(null, Priority.INFO);
         System.out.println("!! expected IllegalArgumentException for null category");
      }
      catch (IllegalArgumentException e)
      {
         System.out.println("null category rejected as designed : " + e.getMessage());
      }
      try
      {
         new Log4jOutputStream(category, null);
         System.out.println("!! expected IllegalArgumentException for null priority");
      }
      catch (IllegalArgumentException e)
      {
         System.out.println("null priority rejected as designed : " + e.getMessage());
      }
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 7: close() delegates to flush(), then further writes fail ---");
      before = appender.events.size();
      Log4jOutputStream out7 = new Log4jOutputStream(category, Priority.INFO);
      writeString(out7, "final message before shutdown");
      out7.close();
      System.out.println("message flushed by close() : " + (appender.events.size() == before + 1));
      try
      {
         out7.write('x');
         System.out.println("!! expected IOException after close");
      }
      catch (IOException e)
      {
         System.out.println("write after close correctly rejected : " + e.getMessage());
      }

      System.out.println();
      System.out.println("Total messages captured by RecordingAppender : " + appender.events.size());
      System.out.println("=== done ===");
   }

   private static void writeString(Log4jOutputStream out, String s) throws IOException
   {
      byte[] bytes = s.getBytes("ISO-8859-1");
      for (byte b : bytes)
      {
         out.write(b);
      }
   }
}







class Priority
{
   public static final int DEBUG_INT = 10000;
   public static final int INFO_INT = 20000;
   public static final int WARN_INT = 30000;
   public static final int ERROR_INT = 40000;
   public static final int FATAL_INT = 50000;

   public static final Priority DEBUG = new Priority(DEBUG_INT, "DEBUG");
   public static final Priority INFO = new Priority(INFO_INT, "INFO");
   public static final Priority WARN = new Priority(WARN_INT, "WARN");
   public static final Priority ERROR = new Priority(ERROR_INT, "ERROR");
   public static final Priority FATAL = new Priority(FATAL_INT, "FATAL");

   private final int level;
   private final String name;

   protected Priority(int level, String name)
   {
      this.level = level;
      this.name = name;
   }

   public int toInt()
   {
      return level;
   }

   public boolean isGreaterOrEqual(Priority other)
   {
      return this.level >= other.level;
   }

   @Override
   public String toString()
   {
      return name;
   }
}







class Category
{
   private final String name;
   private Priority level = Priority.DEBUG;
   private final List<RecordingAppender> appenders = new ArrayList<RecordingAppender>();

   private Category(String name)
   {
      this.name = name;
   }

   public static Category getInstance(String name)
   {
      return new Category(name);
   }

   public String getName()
   {
      return name;
   }

   public void setLevel(Priority level)
   {
      this.level = level;
   }

   public Priority getEffectiveLevel()
   {
      return level;
   }

   public void addAppender(RecordingAppender appender)
   {
      appenders.add(appender);
   }

   
   public void log(Priority priority, Object message)
   {
      if (!priority.isGreaterOrEqual(level))
      {
         return;
      }
      for (RecordingAppender appender : appenders)
      {
         appender.append(name, priority, String.valueOf(message));
      }
   }
}


class RecordingAppender
{
   static final class Event
   {
      final String logger;
      final Priority priority;
      final String message;

      Event(String logger, Priority priority, String message)
      {
         this.logger = logger;
         this.priority = priority;
         this.message = message;
      }
   }

   final List<Event> events = new ArrayList<Event>();

   void append(String logger, Priority priority, String message)
   {
      events.add(new Event(logger, priority, message));
   }
}

















final class Log4jOutputStream extends java.io.OutputStream
{
   protected static final String LINE_SEPERATOR = System.getProperty("line.separator");

   


   protected boolean hasBeenClosed = false;

   


   protected byte[] buf;

   





   protected int count;

   


   private int bufLength;

   


   public static final int DEFAULT_BUFFER_LENGTH = 2048;

   


   protected Category category;

   


   protected Priority priority;

   @SuppressWarnings("unused")
   private Log4jOutputStream()
   {
      
   }

   









   public Log4jOutputStream(Category cat, Priority priority) throws IllegalArgumentException
   {
      if (cat == null)
      {
         throw new IllegalArgumentException("cat == null");
      }
      if (priority == null)
      {
         throw new IllegalArgumentException("priority == null");
      }

      this.priority = priority;
      category = cat;
      bufLength = DEFAULT_BUFFER_LENGTH;
      buf = new byte[DEFAULT_BUFFER_LENGTH];
      count = 0;
   }

   





   public void close()
   {
      flush();
      hasBeenClosed = true;
   }

   













   public void write(final int b) throws IOException
   {
      if (hasBeenClosed)
      {
         throw new IOException("The stream has been closed.");
      }

      
      if (b == 0)
      {
         return;
      }

      
      if (count == bufLength)
      {
         
         final int newBufLength = bufLength + DEFAULT_BUFFER_LENGTH;
         final byte[] newBuf = new byte[newBufLength];

         System.arraycopy(buf, 0, newBuf, 0, bufLength);

         buf = newBuf;
         bufLength = newBufLength;
      }

      buf[count] = (byte)b;
      count++;
   }


// ORIGINAL CODESEARCHNET METHOD — START

public void flush()
   {
      if (count == 0)
      {
         return;
      }

      
      if (count == LINE_SEPERATOR.length())
      {
         if (((char)buf[0]) == LINE_SEPERATOR.charAt(0) && ((count == 1) || 
               ((count == 2) && ((char)buf[1]) == LINE_SEPERATOR.charAt(1))))
         {
            reset();
            return;
         }
      }

      final byte[] theBytes = new byte[count];

      System.arraycopy(buf, 0, theBytes, 0, count);

      category.log(priority, new String(theBytes));

      reset();
   }

// ORIGINAL CODESEARCHNET METHOD — END


   private void reset()
   {
      
      
      count = 0;
   }

   
   int getCount()
   {
      return count;
   }
}
