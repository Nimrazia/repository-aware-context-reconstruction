



















import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_1_jbossws_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== InstallModulesTask.execute() - repository-aware reconstruction ===");
      System.out.println("Repository : jbossws/jbossws-common-tools @ d05ad85663d706e5f0d634f2f8ca6665a6147b3e");
      System.out.println("Ant types  : lightweight adaptation (org.apache.tools.ant artifact unavailable offline)");
      System.out.println();

      
      
      
      
      
      
      
      
      Path root = Files.createTempDirectory("jbossws-modules-");
      File srcDir = new File(root.toFile(), "src-modules");
      File targetDir = new File(root.toFile(), "target-modules");

      String apiModule = "org/jboss/ws/api/main";
      String spiModule = "org/jboss/ws/spi/main";

      writeModuleXml(new File(srcDir, apiModule + "/module.xml"), "org.jboss.ws.api");
      writeModuleXml(new File(srcDir, spiModule + "/module.xml"), "org.jboss.ws.spi");

      File apiLibDir = new File(targetDir, apiModule);
      apiLibDir.mkdirs();
      touch(new File(apiLibDir, "jbossws-api.jar"));
      touch(new File(apiLibDir, "jbossws-common.jar"));
      touch(new File(apiLibDir, "resources.sar"));
      touch(new File(apiLibDir, "README.txt")); 

      System.out.println("Source module dir : " + srcDir);
      System.out.println("Target module dir : " + targetDir);
      System.out.println("Pre-existing libs : " + Arrays.toString(apiLibDir.list()));
      System.out.println();

      
      
      
      Project project = new Project();
      project.setName("jbossws-install");

      InstallModulesTask task = new InstallModulesTask();
      task.setProject(project);
      task.setTaskName("installModules");
      task.setTargetDir(targetDir.getAbsolutePath());

      FileSet fileset = task.createFileset();
      fileset.setDir(srcDir);
      fileset.setIncludes("**/module.xml");

      System.out.println("--- invoking execute() ---");
      task.execute();
      System.out.println("--- execute() returned normally ---");
      System.out.println();

      File apiDest = new File(targetDir, apiModule + "/module.xml");
      File spiDest = new File(targetDir, spiModule + "/module.xml");

      System.out.println("[branch A: lib dir existed] " + apiDest.getName()
            + " written, " + apiDest.length() + " bytes");
      System.out.println(indent(readAll(apiDest)));
      System.out.println("  -> resource-root entries injected : "
            + countOccurrences(readAll(apiDest), "<resource-root path="));
      System.out.println("  -> placeholder still present      : "
            + readAll(apiDest).contains("<!-- Insert resources here -->"));
      System.out.println();

      System.out.println("[branch B: lib dir created by task] " + spiDest.getName()
            + " written, " + spiDest.length() + " bytes");
      System.out.println("  -> lib dir now exists             : " + new File(targetDir, spiModule).isDirectory());
      System.out.println("  -> resource-root entries injected : "
            + countOccurrences(readAll(spiDest), "<resource-root path="));
      System.out.println("  -> placeholder left untouched     : "
            + readAll(spiDest).contains("<!-- Insert resources here -->"));
      System.out.println();

      
      
      
      
      
      System.out.println("--- invoking execute() a second time over the same tree ---");
      task.execute();
      System.out.println("  -> spi module.xml resource-root entries after re-run : "
            + countOccurrences(readAll(spiDest), "<resource-root path="));
      System.out.println("     (zero: the lib dir exists but holds no jar/ear/sar/war)");
      System.out.println("  -> spi placeholder consumed by replaceFirst          : "
            + !readAll(spiDest).contains("<!-- Insert resources here -->"));
      System.out.println();

      
      
      
      
      
      System.out.println("--- exercising the catch block (expected failure) ---");
      InstallModulesTask failing = new InstallModulesTask();
      failing.setProject(project);
      failing.setTargetDir(targetDir.getAbsolutePath());
      FileSet badFileset = failing.createFileset();
      badFileset.setDir(new File(root.toFile(), "does-not-exist"));
      badFileset.setIncludes("**/module.xml");
      try
      {
         failing.execute();
         System.out.println("  !! no exception thrown — unexpected");
      }
      catch (BuildException e)
      {
         System.out.println("  -> BuildException caught as designed");
         System.out.println("  -> cause type    : " + (e.getCause() == null ? "<none>" : e.getCause().getClass().getName()));
         System.out.println("  -> cause message : " + (e.getCause() == null ? "<none>" : e.getCause().getMessage()));
      }

      deleteRecursively(root.toFile());
      System.out.println();
      System.out.println("=== done ===");
   }

   private static void writeModuleXml(File f, String moduleName) throws IOException
   {
      f.getParentFile().mkdirs();
      String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
            + "<module xmlns=\"urn:jboss:module:1.0\" name=\"" + moduleName + "\">\n"
            + "    <resources>\n"
            + "        <!-- Insert resources here -->\n"
            + "    </resources>\n"
            + "    <dependencies>\n"
            + "        <module name=\"javax.api\"/>\n"
            + "    </dependencies>\n"
            + "</module>\n";
      try (BufferedWriter w = new BufferedWriter(new FileWriter(f)))
      {
         w.write(xml);
      }
   }

   private static void touch(File f) throws IOException
   {
      f.getParentFile().mkdirs();
      f.createNewFile();
   }

   private static String readAll(File f) throws IOException
   {
      return new String(Files.readAllBytes(f.toPath()));
   }

   private static String indent(String s)
   {
      StringBuilder sb = new StringBuilder();
      for (String line : s.split("\n"))
      {
         sb.append("    | ").append(line).append('\n');
      }
      return sb.toString();
   }

   private static int countOccurrences(String haystack, String needle)
   {
      int count = 0;
      int idx = haystack.indexOf(needle);
      while (idx >= 0)
      {
         count++;
         idx = haystack.indexOf(needle, idx + needle.length());
      }
      return count;
   }

   private static void deleteRecursively(File f)
   {
      File[] kids = f.listFiles();
      if (kids != null)
      {
         for (File kid : kids)
         {
            deleteRecursively(kid);
         }
      }
      f.delete();
   }
}










class InstallModulesTask extends Task
{
   private String targetDir; 
   private FileSet fileset; 


// ORIGINAL CODESEARCHNET METHOD — START

@Override
   public void execute() throws BuildException
   {
      try
      {
         DirectoryScanner dsc = fileset.getDirectoryScanner(getProject());
         File baseDir = dsc.getBasedir();
         String[] files = dsc.getIncludedFiles();
         for (int i = 0; i < files.length; i++)
         {
            String currentFile = files[i];
            File moduleXml = new File(baseDir, currentFile);
            String modulePath = currentFile.substring(0, currentFile.lastIndexOf(File.separator));
            File libDir = new File(targetDir, modulePath);
            File destFile = new File(targetDir, currentFile);
            System.out.println("Processing descriptor for module " + modulePath);
            System.out.println("* Source module descriptor: " + moduleXml);
            System.out.println("* Destination module descriptor: " + destFile);
            String c = readFileContents(moduleXml);
            if (libDir.exists())
            {
               String[] libs = libDir.list(new FilenameFilter()
               {
                  @Override
                  public boolean accept(File dir, String name)
                  {
                     return name.endsWith(".jar") || name.endsWith(".ear") || name.endsWith(".sar")
                           || name.endsWith(".war");
                  }
               });
               BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
               out.write(updateContents(c, libs));
               out.close();
            }
            else
            {
               libDir.mkdirs();
               BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
               out.write(c);
               out.close();
            }
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new BuildException(e);
      }
   }

// ORIGINAL CODESEARCHNET METHOD — END


   private static String readFileContents(File file) throws Exception
   {
      StringBuilder sb = new StringBuilder();
      BufferedReader in = null;
      try
      {
         in = new BufferedReader(new FileReader(file));
         String line;
         while ((line = in.readLine()) != null)
         {
            sb.append(line);
            sb.append("\n");
         }
      }
      finally
      {
         if (in != null)
         {
            try
            {
               in.close();
            }
            catch (Exception e)
            {
               
            }
         }
      }
      return sb.toString();
   }

   private static String updateContents(String contents, String[] libs)
   {
      StringBuilder sb = new StringBuilder();
      for (String f : libs) {
         sb.append("<resource-root path=\"");
         sb.append(f);
         sb.append("\"/>\n        ");
      }
      return contents.replaceFirst("<!-- Insert resources here -->", sb.toString());
   }

   public FileSet createFileset()
   {
      this.fileset = new FileSet();
      return fileset;
   }

   public void setTargetDir(String targetDir)
   {
      this.targetDir = targetDir;
   }
}





class BuildException extends RuntimeException
{
   private static final long serialVersionUID = 1L;

   public BuildException()
   {
      super();
   }

   public BuildException(String message)
   {
      super(message);
   }

   public BuildException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public BuildException(Throwable cause)
   {
      super(cause == null ? null : cause.toString(), cause);
   }
}





class Project
{
   public static final int MSG_ERR = 0;
   public static final int MSG_WARN = 1;
   public static final int MSG_INFO = 2;
   public static final int MSG_VERBOSE = 3;
   public static final int MSG_DEBUG = 4;

   private String name;
   private File baseDir = new File(".");
   private final Map<String, String> properties = new HashMap<String, String>();

   public String getName()
   {
      return name;
   }

   public void setName(String name)
   {
      this.name = name;
      setProperty("ant.project.name", name);
   }

   public File getBaseDir()
   {
      return baseDir;
   }

   public void setBaseDir(File baseDir)
   {
      this.baseDir = baseDir;
   }

   public void setProperty(String key, String value)
   {
      properties.put(key, value);
   }

   public String getProperty(String key)
   {
      return properties.get(key);
   }

   public Map<String, String> getProperties()
   {
      return Collections.unmodifiableMap(properties);
   }

   public void log(String message)
   {
      log(message, MSG_INFO);
   }

   public void log(String message, int level)
   {
      if (level <= MSG_INFO)
      {
         System.out.println("[" + (name == null ? "ant" : name) + "] " + message);
      }
   }
}







class Task
{
   private Project project;
   private String taskName;
   private String description;

   public void setProject(Project project)
   {
      this.project = project;
   }

   public Project getProject()
   {
      return project;
   }

   public void setTaskName(String taskName)
   {
      this.taskName = taskName;
   }

   public String getTaskName()
   {
      return taskName;
   }

   public void setDescription(String description)
   {
      this.description = description;
   }

   public String getDescription()
   {
      return description;
   }

   public void execute() throws BuildException
   {
      
   }

   public void log(String message)
   {
      if (project != null)
      {
         project.log((taskName == null ? "" : taskName + ": ") + message);
      }
      else
      {
         System.out.println(message);
      }
   }
}









class DirectoryScanner
{
   private File basedir;
   private String[] includes = new String[] {"**"};
   private final List<String> includedFiles = new ArrayList<String>();
   private final List<String> includedDirectories = new ArrayList<String>();
   private boolean scanned = false;

   public void setBasedir(File basedir)
   {
      this.basedir = basedir;
   }

   public File getBasedir()
   {
      return basedir;
   }

   public void setIncludes(String[] includes)
   {
      if (includes == null || includes.length == 0)
      {
         this.includes = new String[] {"**"};
      }
      else
      {
         this.includes = includes.clone();
      }
   }

   public void scan() throws IllegalStateException
   {
      if (basedir == null)
      {
         throw new IllegalStateException("No basedir set");
      }
      if (!basedir.exists())
      {
         throw new IllegalStateException("basedir " + basedir + " does not exist");
      }
      if (!basedir.isDirectory())
      {
         throw new IllegalStateException("basedir " + basedir + " is not a directory");
      }
      includedFiles.clear();
      includedDirectories.clear();
      scanDir(basedir, "");
      Collections.sort(includedFiles);
      Collections.sort(includedDirectories);
      scanned = true;
   }

   private void scanDir(File dir, String relativePrefix)
   {
      File[] children = dir.listFiles();
      if (children == null)
      {
         return;
      }
      Arrays.sort(children);
      for (File child : children)
      {
         String relative = relativePrefix + child.getName();
         if (child.isDirectory())
         {
            if (matchesAny(relative))
            {
               includedDirectories.add(relative);
            }
            scanDir(child, relative + File.separator);
         }
         else if (matchesAny(relative))
         {
            includedFiles.add(relative);
         }
      }
   }

   private boolean matchesAny(String relativePath)
   {
      for (String pattern : includes)
      {
         if (matchPath(normalise(pattern), normalise(relativePath)))
         {
            return true;
         }
      }
      return false;
   }

   private static String normalise(String p)
   {
      return p.replace('\\', '/').replace('/', '\u0001').replace(File.separatorChar, '\u0001');
   }

   
   private static boolean matchPath(String pattern, String path)
   {
      String[] patDirs = pattern.split("\u0001", -1);
      String[] strDirs = path.split("\u0001", -1);
      return matchSegments(patDirs, 0, strDirs, 0);
   }

   private static boolean matchSegments(String[] pat, int pi, String[] str, int si)
   {
      while (pi < pat.length)
      {
         if ("**".equals(pat[pi]))
         {
            
            for (int skip = si; skip <= str.length; skip++)
            {
               if (matchSegments(pat, pi + 1, str, skip))
               {
                  return true;
               }
            }
            return false;
         }
         if (si >= str.length || !matchName(pat[pi], str[si]))
         {
            return false;
         }
         pi++;
         si++;
      }
      return si == str.length;
   }

   
   private static boolean matchName(String pattern, String name)
   {
      return matchName(pattern, 0, name, 0);
   }

   private static boolean matchName(String pattern, int pi, String name, int ni)
   {
      while (pi < pattern.length())
      {
         char pc = pattern.charAt(pi);
         if (pc == '*')
         {
            for (int skip = ni; skip <= name.length(); skip++)
            {
               if (matchName(pattern, pi + 1, name, skip))
               {
                  return true;
               }
            }
            return false;
         }
         if (ni >= name.length())
         {
            return false;
         }
         if (pc != '?' && pc != name.charAt(ni))
         {
            return false;
         }
         pi++;
         ni++;
      }
      return ni == name.length();
   }

   public String[] getIncludedFiles()
   {
      if (!scanned)
      {
         scan();
      }
      return includedFiles.toArray(new String[includedFiles.size()]);
   }

   public String[] getIncludedDirectories()
   {
      if (!scanned)
      {
         scan();
      }
      return includedDirectories.toArray(new String[includedDirectories.size()]);
   }
}






class FileSet
{
   private File dir;
   private final List<String> includes = new ArrayList<String>();

   public void setDir(File dir)
   {
      this.dir = dir;
   }

   public File getDir()
   {
      return dir;
   }

   public void setIncludes(String includes)
   {
      this.includes.clear();
      if (includes != null)
      {
         for (String token : includes.split("[,\\s]+"))
         {
            if (token.length() > 0)
            {
               this.includes.add(token);
            }
         }
      }
   }

   public DirectoryScanner getDirectoryScanner(Project project)
   {
      DirectoryScanner scanner = new DirectoryScanner();
      File base = dir;
      if (base == null && project != null)
      {
         base = project.getBaseDir();
      }
      scanner.setBasedir(base);
      scanner.setIncludes(includes.toArray(new String[includes.size()]));
      scanner.scan();
      return scanner;
   }
}
