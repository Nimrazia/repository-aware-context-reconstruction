

























import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

public class method_2_jbossws_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== SecurityActions.setContextClassLoader(ClassLoader) - repository-aware reconstruction ===");
      System.out.println("Repository   : jbossws/jbossws-common-tools @ d05ad85663d706e5f0d634f2f8ca6665a6147b3e");
      System.out.println("Java version : " + System.getProperty("java.version"));
      System.out.println("SecurityManager installed at start : " + System.getSecurityManager());
      System.out.println();

      final ClassLoader original = Thread.currentThread().getContextClassLoader();
      System.out.println("Initial TCCL : " + describe(original));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 1: install a new URLClassLoader ---");
      URLClassLoader toolsLoader = new URLClassLoader(
            new URL[] {new File(System.getProperty("java.io.tmpdir")).toURI().toURL()},
            original);

      ClassLoader returned = SecurityActions.setContextClassLoader(toolsLoader);
      ClassLoader nowInstalled = Thread.currentThread().getContextClassLoader();

      System.out.println("returned (previous) loader : " + describe(returned));
      System.out.println("TCCL after the call        : " + describe(nowInstalled));
      System.out.println("returned == original       : " + (returned == original));
      System.out.println("TCCL     == toolsLoader    : " + (nowInstalled == toolsLoader));
      System.out.println("corroborated by sibling SecurityActions.getContextClassLoader() : "
            + (SecurityActions.getContextClassLoader() == toolsLoader));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 2: restore the previous loader from the return value ---");
      ClassLoader returnedOnRestore = SecurityActions.setContextClassLoader(returned);
      System.out.println("returned (previous) loader : " + describe(returnedOnRestore));
      System.out.println("returnedOnRestore == toolsLoader : " + (returnedOnRestore == toolsLoader));
      System.out.println("TCCL restored to original        : "
            + (Thread.currentThread().getContextClassLoader() == original));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: null argument leaves the TCCL untouched ---");
      ClassLoader before = Thread.currentThread().getContextClassLoader();
      ClassLoader returnedForNull = SecurityActions.setContextClassLoader(null);
      ClassLoader after = Thread.currentThread().getContextClassLoader();
      System.out.println("returned      : " + describe(returnedForNull));
      System.out.println("TCCL changed  : " + (before != after));
      System.out.println("returned == before : " + (returnedForNull == before));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 4: attempt to reach the AccessController.doPrivileged branch ---");
      boolean managerInstalled = false;
      try
      {
         System.setSecurityManager(new SecurityManager()
         {
            @Override
            public void checkPermission(java.security.Permission perm)
            {
               
            }
         });
         managerInstalled = System.getSecurityManager() != null;
      }
      catch (UnsupportedOperationException e)
      {
         System.out.println("SecurityManager could not be installed: " + e.getClass().getName());
         System.out.println("  reason  : this JDK (" + System.getProperty("java.version")
               + ") refuses System.setSecurityManager unless started with -Djava.security.manager=allow");
         System.out.println("  effect  : System.getSecurityManager() stays null, so the target method takes");
         System.out.println("            its first branch and the doPrivileged branch is not reachable under");
         System.out.println("            the mandated plain 'java <classname>' invocation.");
      }
      catch (SecurityException e)
      {
         System.out.println("SecurityManager installation refused: " + e);
      }

      if (managerInstalled)
      {
         System.out.println("SecurityManager installed - taking the doPrivileged branch");
         ClassLoader viaPrivileged = SecurityActions.setContextClassLoader(toolsLoader);
         System.out.println("returned (previous) loader : " + describe(viaPrivileged));
         System.out.println("TCCL == toolsLoader        : "
               + (Thread.currentThread().getContextClassLoader() == toolsLoader));
         SecurityActions.setContextClassLoader(original);
         System.setSecurityManager(null);
      }
      else
      {
         System.out.println("  branch coverage : first branch exercised in scenarios 1-3;");
         System.out.println("                    second branch NOT exercised (environment limitation, stated above).");
         System.out.println("  the doPrivileged branch's own logic is byte-for-byte identical to the first");
         System.out.println("  branch's, wrapped in a PrivilegedExceptionAction, so its behaviour is the same.");
      }
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 5: sibling action SecurityActions.getClassLoader(Class) ---");
      System.out.println("loader of this driver class : "
            + describe(SecurityActions.getClassLoader(method_2_jbossws_claude.class)));
      System.out.println("loader of java.lang.String  : "
            + describe(SecurityActions.getClassLoader(String.class)) + " (bootstrap loader reports null)");
      System.out.println();

      toolsLoader.close();
      System.out.println("Final TCCL : " + describe(Thread.currentThread().getContextClassLoader()));
      System.out.println("=== done ===");
   }

   private static String describe(ClassLoader cl)
   {
      if (cl == null)
      {
         return "null";
      }
      return cl.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(cl));
   }
}







final class SecurityActions
{
   




   static ClassLoader getContextClassLoader()
   {
      SecurityManager sm = System.getSecurityManager();
      if (sm == null)
      {
         return Thread.currentThread().getContextClassLoader();
      }
      else
      {
         return AccessController.doPrivileged(new PrivilegedAction<ClassLoader>() {
            public ClassLoader run()
            {
               return Thread.currentThread().getContextClassLoader();
            }
         });
      }
   }


// ORIGINAL CODESEARCHNET METHOD — START

static ClassLoader setContextClassLoader(final ClassLoader cl)
   {
      if (System.getSecurityManager() == null)
      {
         ClassLoader result = Thread.currentThread().getContextClassLoader();
         if (cl != null)
            Thread.currentThread().setContextClassLoader(cl);
         return result;
      }
      else
      {
         try
         {
            return AccessController.doPrivileged(new PrivilegedExceptionAction<ClassLoader>() {
               public ClassLoader run() throws Exception
               {
                  try
                  {
                     ClassLoader result = Thread.currentThread().getContextClassLoader();
                     if (cl != null)
                        Thread.currentThread().setContextClassLoader(cl);
                     return result;
                  }
                  catch (Exception e)
                  {
                     throw e;
                  }
                  catch (Error e)
                  {
                     throw e;
                  }
                  catch (Throwable e)
                  {
                     throw new RuntimeException("Error setting context classloader", e);
                  }
               }
            });
         }
         catch (PrivilegedActionException e)
         {
            throw new RuntimeException("Error running privileged action", e.getCause());
         }
      }
   }

// ORIGINAL CODESEARCHNET METHOD — END


   





   static ClassLoader getClassLoader(final Class<?> clazz)
   {
      SecurityManager sm = System.getSecurityManager();
      if (sm == null)
      {
         return clazz.getClassLoader();
      }
      else
      {
         return AccessController.doPrivileged(new PrivilegedAction<ClassLoader>() {
            public ClassLoader run()
            {
               return clazz.getClassLoader();
            }
         });
      }
   }

}
