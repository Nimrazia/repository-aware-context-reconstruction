import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class method_2_structlogger_claude {
    interface VariableContext { }
    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
    @java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
    @interface VarContextProvider { }
    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
    @java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
    @interface Var { }

    @VarContextProvider
    interface CacheContext extends VariableContext {
        @Var CacheContext blockId(long id);
        @Var CacheContext reason(String reason);
    }

    private final Map<String, Class<?>> varsHashMap = new HashMap<>();
    private final Set<Class<?>> processed = new HashSet<>();

    // ORIGINAL CODESEARCHNET METHOD — START (JDK-only compatible adaptation)
    private boolean checkVarContextProvider(final Class<?> typeMirror) {
        if (processed.contains(typeMirror)) return true;
        if (!typeMirror.isInterface()) return false;
        if (!VariableContext.class.isAssignableFrom(typeMirror)) return false;
        if (!typeMirror.isAnnotationPresent(VarContextProvider.class)) return false;
        for (Method method : typeMirror.getDeclaredMethods()) {
            if (!method.isAnnotationPresent(Var.class)) continue;
            String name = method.getName();
            if (name.equals("log") || name.endsWith("Event")
                    || java.util.Set.of("info", "warn", "debug", "error", "trace", "audit").contains(name)) {
                return false;
            }
            if (method.getParameterCount() != 1 || method.getReturnType() != typeMirror
                    || varsHashMap.containsKey(name)) return false;
            varsHashMap.put(name, method.getParameterTypes()[0]);
        }
        processed.add(typeMirror);
        return true;
    }
    // ORIGINAL CODESEARCHNET METHOD — END

    public static void main(String[] args) {
        method_2_structlogger_claude processor = new method_2_structlogger_claude();
        boolean valid = processor.checkVarContextProvider(CacheContext.class);
        System.out.println("valid=" + valid);
        System.out.println("variables=" + processor.varsHashMap);
        if (!valid || processor.varsHashMap.size() != 2) throw new IllegalStateException("validation failed");
        System.out.println("EXECUTION PASS");
    }
}
