import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;


public class method_3_structlogger_claude {
    interface VariableContext { }
    static final class CacheContext implements VariableContext { }
    static final class OtherContext implements VariableContext { }
    static final class StructLogger<T extends VariableContext> { }
    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
    @java.lang.annotation.Target(java.lang.annotation.ElementType.FIELD)
    @interface LoggerContext { Class<? extends VariableContext> context(); }

    static final class Demo {
        @LoggerContext(context = CacheContext.class)
        static StructLogger<CacheContext> cacheLog = new StructLogger<>();
        @LoggerContext(context = OtherContext.class)
        static StructLogger<OtherContext> userLog = new StructLogger<>();
        static String ignored = "not a logger";
    }

    private final Map<String, Class<? extends VariableContext>> fields = new LinkedHashMap<>();

    // ORIGINAL CODESEARCHNET METHOD — START (JDK-only compatible adaptation)
    private void processStructLogExpressions(final Class<?> roundEnv) {
        for (Field field : roundEnv.getDeclaredFields()) {
            LoggerContext annotation = field.getAnnotation(LoggerContext.class);
            if (annotation == null) continue;
            if (!StructLogger.class.isAssignableFrom(field.getType())) {
                throw new IllegalArgumentException("@LoggerContext field must be a StructLogger: " + field.getName());
            }
            fields.put(field.getName(), annotation.context());
        }
    }
    // ORIGINAL CODESEARCHNET METHOD — END

    public static void main(String[] args) {
        method_3_structlogger_claude processor = new method_3_structlogger_claude();
        processor.processStructLogExpressions(Demo.class);
        processor.fields.forEach((name, ctx) -> System.out.println(name + " -> " + ctx.getSimpleName()));
        if (processor.fields.size() != 2) throw new IllegalStateException("field scan failed");
        System.out.println("EXECUTION PASS");
    }
}
