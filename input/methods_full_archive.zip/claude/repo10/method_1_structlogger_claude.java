import java.util.ArrayList;
import java.util.List;
import java.util.Stack;


public class method_1_structlogger_claude {
    static final class MethodAndParameter {
        final String method;
        final Object value;
        MethodAndParameter(String method, Object value) { this.method = method; this.value = value; }
    }
    static final class StatementInfo {
        String message;
        String eventName;
        final List<String> variables = new ArrayList<>();
    }
    static final class ScannerParams {
        final boolean parametrized;
        ScannerParams(boolean parametrized) { this.parametrized = parametrized; }
    }

    // ORIGINAL CODESEARCHNET METHOD — START (JDK-only compatible adaptation)
    private void handleStructLogExpression(final Stack<MethodAndParameter> stack,
            final String invocation, final String loggerName,
            final StatementInfo statementInfo, final ScannerParams scannerParams) {
        if (invocation == null || !invocation.contains(".log(")) {
            throw new IllegalArgumentException("Structured log statement must terminate with log(eventName)");
        }
        if (statementInfo.message == null) {
            throw new IllegalArgumentException("Log message must be a string literal");
        }
        while (!stack.isEmpty()) {
            MethodAndParameter item = stack.remove(0);
            if (!"info".equals(item.method) && !"warn".equals(item.method)
                    && !"debug".equals(item.method) && !"error".equals(item.method)
                    && !"trace".equals(item.method) && !"audit".equals(item.method)
                    && !"log".equals(item.method)) {
                statementInfo.variables.add(item.method + "=" + item.value);
            }
        }
        if (scannerParams.parametrized) {
            int placeholders = 0;
            for (int i = 0; i + 1 < statementInfo.message.length(); i++) {
                if (statementInfo.message.charAt(i) == '{' && statementInfo.message.charAt(i + 1) == '}') placeholders++;
            }
            if (placeholders != statementInfo.variables.size()) {
                throw new IllegalArgumentException("Placeholder count " + placeholders
                        + " does not match variables " + statementInfo.variables.size());
            }
        }
        if (statementInfo.eventName == null || !statementInfo.eventName.matches("[A-Za-z_$][A-Za-z0-9_$.]*")) {
            throw new IllegalArgumentException("Invalid event class name: " + statementInfo.eventName);
        }
        System.out.println("logger=" + loggerName + ", event=" + statementInfo.eventName);
        System.out.println("message=" + format(statementInfo.message, statementInfo.variables));
    }
    // ORIGINAL CODESEARCHNET METHOD — END

    private static String format(String message, List<String> vars) {
        String result = message;
        for (String v : vars) result = result.replaceFirst("\\{\\}", java.util.regex.Matcher.quoteReplacement(v));
        return result;
    }

    public static void main(String[] args) {
        method_1_structlogger_claude scanner = new method_1_structlogger_claude();
        Stack<MethodAndParameter> stack = new Stack<>();
        stack.add(new MethodAndParameter("blockId", 42L));
        stack.add(new MethodAndParameter("reason", "evicted"));
        StatementInfo info = new StatementInfo();
        info.message = "block {} removed because {}";
        info.eventName = "com.github.structlogging.BlockRemoved";
        scanner.handleStructLogExpression(stack, "log.info(...).log(...)" , "log", info, new ScannerParams(true));
        System.out.println("EXECUTION PASS");
    }
}
