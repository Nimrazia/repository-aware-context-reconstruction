import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;



























public class method_3_metacsp_gpt {

    
    
    
    
    
    static class DirectedSparseMultigraph<V, E> {
        private final Set<V> vertices = new HashSet<>();
        private final List<Object[]> edges = new ArrayList<>(); 

        public boolean addVertex(V v) {
            return vertices.add(v);
        }

        public boolean addEdge(E edge, V source, V dest) {
            edges.add(new Object[]{edge, source, dest});
            return true;
        }

        public int getVertexCount() { return vertices.size(); }
        public int getEdgeCount() { return edges.size(); }

        public List<Object[]> getEdgesRaw() { return edges; }
    }

    
    
    
    
    
    static class AllenIntervalConstraint extends Constraint {
        enum Type { BeforeOrMeets, After, Overlaps, During }
        private final Type[] types;
        private final Variable from;
        private final Variable to;

        AllenIntervalConstraint(Type type, Variable from, Variable to) {
            this.types = new Type[]{type};
            this.from = from;
            this.to = to;
        }

        Type[] getTypes() { return types; }
        Variable getFrom() { return from; }
        Variable getTo() { return to; }
    }

    
    
    
    
    static abstract class Constraint {}

    
    
    
    
    static abstract class Variable {}

    
    
    
    
    static class Trajectory {
        private final int seqStart;
        private final int seqEnd;
        Trajectory(int seqStart, int seqEnd) { this.seqStart = seqStart; this.seqEnd = seqEnd; }
        int getSequenceNumberStart() { return seqStart; }
        int getSequenceNumberEnd() { return seqEnd; }
    }

    
    
    
    
    
    
    
    
    static class TrajectoryEnvelope extends Variable {
        private final String id;
        private final Trajectory trajectory;
        private TrajectoryEnvelope superEnvelope;
        private final List<TrajectoryEnvelope> subEnvelopes = new ArrayList<>();
        private final List<Variable> recursivelyDependentVariables = new ArrayList<>();

        TrajectoryEnvelope(String id, Trajectory trajectory) {
            this.id = id;
            this.trajectory = trajectory;
        }

        Trajectory getTrajectory() { return trajectory; }

        boolean hasSuperEnvelope() { return superEnvelope != null; }
        TrajectoryEnvelope getSuperEnvelope() { return superEnvelope; }
        void setSuperEnvelope(TrajectoryEnvelope parent) { this.superEnvelope = parent; }

        boolean hasSubEnvelopes() { return !subEnvelopes.isEmpty(); }
        void addSubEnvelope(TrajectoryEnvelope sub) { this.subEnvelopes.add(sub); }

        List<Variable> getRecursivelyDependentVariables() { return recursivelyDependentVariables; }
        void addRecursivelyDependentVariable(Variable v) { this.recursivelyDependentVariables.add(v); }

        
        
        int getSequenceNumberStart() { return trajectory.getSequenceNumberStart(); }
        int getSequenceNumberEnd() { return trajectory.getSequenceNumberEnd(); }

        @Override public String toString() { return "TE[" + id + "]"; }
    }

    
    
    
    static class ConstraintNetwork {
        private final List<Constraint> constraints = new ArrayList<>();
        void addConstraint(Constraint c) { constraints.add(c); }
        Constraint[] getConstraints() { return constraints.toArray(new Constraint[0]); }
    }

    
    
    
    static class ConstraintSolver {
        private final ConstraintNetwork network = new ConstraintNetwork();
        ConstraintNetwork getConstraintNetwork() { return network; }
    }

    
    
    
    
    
    
    static class TrajectoryEnvelopeScheduler {
        private final ConstraintSolver[] solvers;

        TrajectoryEnvelopeScheduler(ConstraintSolver[] solvers) { this.solvers = solvers; }

        ConstraintSolver[] getConstraintSolvers() { return solvers; }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> getCurrentDependencies() {
		DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> depGraph = new DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]>();
		ConstraintNetwork cn = this.getConstraintSolvers()[0].getConstraintNetwork();
		Constraint[] cons = cn.getConstraints();
		for (Constraint con : cons) {
			if (con instanceof AllenIntervalConstraint) {
				AllenIntervalConstraint aic = (AllenIntervalConstraint)con;
				if (aic.getTypes()[0].equals(AllenIntervalConstraint.Type.BeforeOrMeets)) {

					
					TrajectoryEnvelope mustWaitToStart = (TrajectoryEnvelope)aic.getTo();
					TrajectoryEnvelope mustFinishBeforeOtherCanStart = (TrajectoryEnvelope)aic.getFrom();
					TrajectoryEnvelope waitingEnvelope = null;

					
					TrajectoryEnvelope root = mustWaitToStart;
					while (root.hasSuperEnvelope()) root = root.getSuperEnvelope();
					for (Variable depVar : root.getRecursivelyDependentVariables()) {
						TrajectoryEnvelope depTE = (TrajectoryEnvelope)depVar;
						if (!depTE.hasSubEnvelopes() && depTE.getTrajectory().getSequenceNumberEnd() == mustWaitToStart.getSequenceNumberStart()-1) {
							waitingEnvelope = depTE;
							break;
						}
					}

					
					Integer thresholdPoint = mustFinishBeforeOtherCanStart.getTrajectory().getSequenceNumberEnd();
					Integer waitingPoint = null;
					
					
					if (waitingEnvelope == null) {
						
						waitingPoint = mustWaitToStart.getTrajectory().getSequenceNumberStart();
						waitingEnvelope = mustWaitToStart;
					}
					else {
						waitingPoint = waitingEnvelope.getTrajectory().getSequenceNumberEnd();
					}
					
					
					ArrayList<TrajectoryEnvelope> verts = new ArrayList<TrajectoryEnvelope>();
					verts.add(waitingEnvelope);
					verts.add(mustFinishBeforeOtherCanStart);
					depGraph.addVertex(waitingEnvelope);
					depGraph.addVertex(mustFinishBeforeOtherCanStart);
					depGraph.addEdge(new Integer[] {waitingPoint,thresholdPoint}, waitingEnvelope, mustFinishBeforeOtherCanStart);
				}
			}
		}
		return depGraph;
	}
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    
    
    
    
    
    static {  }

    public static void main(String[] args) {
        System.out.println("=== method_3_metacsp_gpt : TrajectoryEnvelopeScheduler.getCurrentDependencies ===");

        
        
        
        
        
        TrajectoryEnvelope teA0 = new TrajectoryEnvelope("A0", new Trajectory(0, 14));
        TrajectoryEnvelope teA = new TrajectoryEnvelope("A", new Trajectory(15, 30));
        TrajectoryEnvelope teB = new TrajectoryEnvelope("B", new Trajectory(0, 10));
        
        
        teA.addRecursivelyDependentVariable(teA0);

        ConstraintSolver solver1 = new ConstraintSolver();
        solver1.getConstraintNetwork().addConstraint(new AllenIntervalConstraint(AllenIntervalConstraint.Type.BeforeOrMeets, teB, teA));
        TrajectoryEnvelopeScheduler scheduler1 = new TrajectoryEnvelopeScheduler(new ConstraintSolver[]{solver1});

        DirectedSparseMultigraph<TrajectoryEnvelope, Integer[]> graph1 = scheduler1.getCurrentDependencies();
        System.out.println("Scenario 1 (predecessor found): vertices=" + graph1.getVertexCount() + " edges=" + graph1.getEdgeCount());
        for (Object[] e : graph1.getEdgesRaw()) {
            Integer[] pts = (Integer[]) e[0];
            System.out.println("   edge " + e[1] + " -> " + e[2] + "  waypoints=[" + pts[0] + "," + pts[1] + "]");
        }

        
        
        
        
        TrajectoryEnvelope teC = new TrajectoryEnvelope("C", new Trajectory(20, 40)); 
        TrajectoryEnvelope teD = new TrajectoryEnvelope("D", new Trajectory(0, 5));

        ConstraintSolver solver2 = new ConstraintSolver();
        solver2.getConstraintNetwork().addConstraint(new AllenIntervalConstraint(AllenIntervalConstraint.Type.BeforeOrMeets, teD, teC));
        TrajectoryEnvelopeScheduler scheduler2 = new TrajectoryEnvelopeScheduler(new ConstraintSolver[]{solver2});

        DirectedSparseMultigraph<TrajectoryEnvelope, Integer[]> graph2 = scheduler2.getCurrentDependencies();
        System.out.println("Scenario 2 (no predecessor, robot parks): vertices=" + graph2.getVertexCount() + " edges=" + graph2.getEdgeCount());
        for (Object[] e : graph2.getEdgesRaw()) {
            Integer[] pts = (Integer[]) e[0];
            System.out.println("   edge " + e[1] + " -> " + e[2] + "  waypoints=[" + pts[0] + "," + pts[1] + "]");
        }

        
        
        
        
        
        TrajectoryEnvelope teE = new TrajectoryEnvelope("E", new Trajectory(0, 5));
        TrajectoryEnvelope teF = new TrajectoryEnvelope("F", new Trajectory(10, 20));
        ConstraintSolver solver3 = new ConstraintSolver();
        solver3.getConstraintNetwork().addConstraint(new AllenIntervalConstraint(AllenIntervalConstraint.Type.After, teE, teF));
        solver3.getConstraintNetwork().addConstraint(new Constraint() { });
        TrajectoryEnvelopeScheduler scheduler3 = new TrajectoryEnvelopeScheduler(new ConstraintSolver[]{solver3});
        DirectedSparseMultigraph<TrajectoryEnvelope, Integer[]> graph3 = scheduler3.getCurrentDependencies();
        System.out.println("Scenario 3 (no BeforeOrMeets constraints): vertices=" + graph3.getVertexCount() + " edges=" + graph3.getEdgeCount());

        System.out.println("=== Done ===");
    }
}
