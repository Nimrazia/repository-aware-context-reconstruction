import java.awt.BasicStroke;
import java.awt.Color;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;



























public class method_1_metacsp_gpt {

    
    
    
    
    interface CategoryDataset {
        int getRowCount();
        int getColumnCount();
    }

    static class DefaultCategoryDataset implements CategoryDataset {
        private final List<String> rowKeys = new ArrayList<>();
        private final List<String> columnKeys = new ArrayList<>();
        public void addValue(double value, String rowKey, String columnKey) {
            if (!rowKeys.contains(rowKey)) rowKeys.add(rowKey);
            if (!columnKeys.contains(columnKey)) columnKeys.add(columnKey);
        }
        @Override public int getRowCount() { return rowKeys.size(); }
        @Override public int getColumnCount() { return columnKeys.size(); }
    }

    
    
    
    enum PlotOrientation { HORIZONTAL, VERTICAL }

    
    
    
    enum AxisLocation { TOP_OR_LEFT, TOP_OR_RIGHT, BOTTOM_OR_LEFT, BOTTOM_OR_RIGHT }

    
    
    
    enum HorizontalAlignment { LEFT, CENTER, RIGHT }

    
    
    
    
    enum ItemLabelAnchor { INSIDE1, INSIDE2, OUTSIDE1 }
    enum TextAnchor { TOP_RIGHT, TOP_LEFT, CENTER }

    
    
    
    
    static class ItemLabelPosition {
        final ItemLabelAnchor anchor;
        final TextAnchor textAnchor;
        ItemLabelPosition(ItemLabelAnchor anchor, TextAnchor textAnchor) {
            this.anchor = anchor;
            this.textAnchor = textAnchor;
        }
    }

    
    
    
    
    
    interface CategoryItemRenderer {}

    static class CategoryToolTipGenerator {}
    static class CategoryItemLabelGenerator {}

    
    
    
    
    
    static class StackedBarRenderer implements CategoryItemRenderer {
        private boolean itemLabelsVisible;
        private CategoryItemLabelGenerator itemLabelGenerator;
        private ItemLabelPosition positiveFallback;
        private final java.util.Map<Integer, ItemLabelPosition> seriesPositiveItemLabelPosition = new java.util.HashMap<>();
        private CategoryToolTipGenerator toolTipGenerator;
        private double base;
        private final java.util.Map<Integer, Color> seriesPaint = new java.util.HashMap<>();
        private final java.util.Map<Integer, Color> seriesOutlinePaint = new java.util.HashMap<>();
        private boolean baseSeriesVisibleInLegend;
        private final java.util.Map<Integer, BasicStroke> seriesStroke = new java.util.HashMap<>();

        void setItemLabelsVisible(boolean v) { this.itemLabelsVisible = v; }
        void setItemLabelGenerator(CategoryItemLabelGenerator g) { this.itemLabelGenerator = g; }
        void setPositiveItemLabelPositionFallback(ItemLabelPosition p) { this.positiveFallback = p; }
        void setSeriesPositiveItemLabelPosition(int series, ItemLabelPosition p) { seriesPositiveItemLabelPosition.put(series, p); }
        void setToolTipGenerator(CategoryToolTipGenerator g) { this.toolTipGenerator = g; }
        void setBase(double base) { this.base = base; }
        void setSeriesPaint(int series, Color c) { seriesPaint.put(series, c); }
        void setSeriesOutlinePaint(int series, Color c) { seriesOutlinePaint.put(series, c); }
        void setBaseSeriesVisibleInLegend(boolean visible, boolean notify) { this.baseSeriesVisibleInLegend = visible; }
        void setSeriesStroke(int series, BasicStroke stroke) { seriesStroke.put(series, stroke); }

        
        double getBase() { return base; }
        Color getSeriesPaintFor(int series) { return seriesPaint.get(series); }
        int getConfiguredSeriesPaintCount() { return seriesPaint.size(); }
        boolean isItemLabelsVisible() { return itemLabelsVisible; }
    }

    
    
    
    static class NumberAxis {
        private Object standardTickUnits;
        private double lowerMargin;
        private double upperMargin;
        private NumberFormat numberFormatOverride;
        private double[] range; 

        static Object createIntegerTickUnits() { return new Object();  }

        void setStandardTickUnits(Object units) { this.standardTickUnits = units; }
        void setLowerMargin(double m) { this.lowerMargin = m; }
        void setUpperMargin(double m) { this.upperMargin = m; }
        void setNumberFormatOverride(NumberFormat nf) { this.numberFormatOverride = nf; }
        void setRange(RangeValue r) { this.range = new double[]{r.lower, r.upper}; }

        double getLowerMargin() { return lowerMargin; }
        double getUpperMargin() { return upperMargin; }
    }

    
    
    
    static class RangeValue {
        final double lower, upper;
        RangeValue(double lower, double upper) { this.lower = lower; this.upper = upper; }
    }

    
    
    
    static class CategoryPlot {
        private AxisLocation rangeAxisLocation;
        private CategoryItemRenderer renderer = new StackedBarRenderer();
        private float foregroundAlpha;
        private final NumberAxis rangeAxis = new NumberAxis();

        void setRangeAxisLocation(AxisLocation loc) { this.rangeAxisLocation = loc; }
        CategoryItemRenderer getRenderer() { return renderer; }
        void setRenderer(CategoryItemRenderer r) { this.renderer = r; }
        void setForegroundAlpha(float alpha) { this.foregroundAlpha = alpha; }
        NumberAxis getRangeAxis() { return rangeAxis; }

        AxisLocation getRangeAxisLocation() { return rangeAxisLocation; }
        float getForegroundAlpha() { return foregroundAlpha; }
    }

    
    
    
    static class TextTitle {
        private HorizontalAlignment horizontalAlignment;
        void setHorizontalAlignment(HorizontalAlignment a) { this.horizontalAlignment = a; }
        HorizontalAlignment getHorizontalAlignment() { return horizontalAlignment; }
    }

    
    
    
    static class JFreeChart {
        private final TextTitle title = new TextTitle();
        private final CategoryPlot plot = new CategoryPlot();
        TextTitle getTitle() { return title; }
        CategoryPlot getCategoryPlot() { return plot; }
    }

    
    
    
    
    
    
    static class ChartFactory {
        static JFreeChart createStackedBarChart(String title, String domainAxisLabel, String rangeAxisLabel,
                                                  CategoryDataset dataset, PlotOrientation orientation,
                                                  boolean legend, boolean tooltips, boolean urls) {
            JFreeChart chart = new JFreeChart();
            
            chart.getCategoryPlot().setRenderer(new StackedBarRenderer());
            return chart;
        }
    }

    
    
    
    
    
    static class PlotBoxTooltip extends CategoryToolTipGenerator {}

    
    
    
    
    
    
    static class LabelGenerator extends CategoryItemLabelGenerator {
        private final boolean showLabels;
        LabelGenerator(boolean showLabels) { this.showLabels = showLabels; }
    }

    
    
    
    
    
    
    
    static class SimpleTimeline {
        private final Long[] pulses;
        private final Set2<Object> inconsistent = new Set2<>();
        private final Set2<Object> critical = new Set2<>();
        private final Set2<Object> undetermined = new Set2<>();

        SimpleTimeline(Long... pulses) { this.pulses = pulses; }

        Long[] getPulses() { return pulses; }
        boolean isInconsistent(Object value) { return inconsistent.contains(value); }
        boolean isCritical(Object value) { return critical.contains(value); }
        boolean isUndetermined(Object value) { return undetermined.contains(value); }

        void markInconsistent(Object v) { inconsistent.add(v); }
        void markCritical(Object v) { critical.add(v); }
        void markUndetermined(Object v) { undetermined.add(v); }
    }

    
    
    static class Set2<T> {
        private final List<T> items = new ArrayList<>();
        void add(T t) { items.add(t); }
        boolean contains(T t) { return items.contains(t); }
    }

    
    
    
    
    
    static class PlotBoxTLSmall {
        String name;
        SimpleTimeline stl;
        RangeValue range;
        double[] durations;
        Object[] values;
        boolean showlabels;
        JFreeChart chart;

        PlotBoxTLSmall(String name, SimpleTimeline stl, RangeValue range, double[] durations, Object[] values, boolean showlabels) {
            this.name = name;
            this.stl = stl;
            this.range = range;
            this.durations = durations;
            this.values = values;
            this.showlabels = showlabels;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        @SuppressWarnings("deprecation")
	private JFreeChart createChart(CategoryDataset dataset) {


		String s = null;
		String tit = null;
		String ax = null;





		tit = this.name;
		
        chart = ChartFactory.createStackedBarChart(
            tit,  
            s,                  
            ax,                     
            dataset,                     
            PlotOrientation.HORIZONTAL,    
            false,                        
            false,                       
            false                        
        );
        CategoryPlot plot = chart.getCategoryPlot();

        chart.getTitle().setHorizontalAlignment(HorizontalAlignment.LEFT);
        plot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_RIGHT);

        
        
        StackedBarRenderer renderer = (StackedBarRenderer) plot.getRenderer();
        renderer.setItemLabelsVisible(true);
        renderer.setItemLabelGenerator(new LabelGenerator(showlabels));
        ItemLabelPosition pos = new ItemLabelPosition(ItemLabelAnchor.INSIDE1, TextAnchor.TOP_RIGHT);
    	renderer.setPositiveItemLabelPositionFallback(pos);
        for(int i = 0; i < dataset.getRowCount(); i++) {
        	renderer.setSeriesPositiveItemLabelPosition(i, pos);
        }
        
        






        renderer.setToolTipGenerator(new PlotBoxTooltip());
        plot.setRenderer(renderer);
       
        plot.setForegroundAlpha(0.8f);
                        
        NumberAxis rangeAxis = plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        rangeAxis.setLowerMargin(2.0);
        rangeAxis.setUpperMargin(2.0);
        
        
        
        long origin = stl.getPulses()[0].longValue();
        NumberFormat nf = new DecimalFormat();
        rangeAxis.setNumberFormatOverride ( nf ); 
        if (this.range != null) rangeAxis.setRange(range);
        
   
        
        renderer.setBase(origin);
        
        
        
        

        for (int i = 0; i < durations.length; i++) {
	        if (stl.isInconsistent(values[i]))
	        	renderer.setSeriesPaint(i, new Color(198, 30, 69));
	        else if (stl.isCritical(values[i]))
	        		renderer.setSeriesPaint(i, new Color(238,234,111));
	        else if (stl.isUndetermined(values[i]))
        		renderer.setSeriesPaint(i, new Color(255,255,255));
        	else renderer.setSeriesPaint(i, new Color(111,180,238));
        	renderer.setSeriesOutlinePaint(i, Color.black);
		}
        
        renderer.setBaseSeriesVisibleInLegend(false, false);
        
        renderer.setSeriesStroke(0, new BasicStroke(40f));
        
        return chart;
	}
        
        // ORIGINAL CODESEARCHNET METHOD — END
        

        JFreeChart invokeCreateChart(CategoryDataset dataset) { return createChart(dataset); }
    }

    public static void main(String[] args) {
        System.out.println("=== method_1_metacsp_gpt : PlotBoxTLSmall.createChart ===");

        
        
        
        
        
        SimpleTimeline stl = new SimpleTimeline(100L, 200L, 300L, 400L);
        Object segInconsistent = new Object() { public String toString() { return "seg-inconsistent"; } };
        Object segCritical = new Object() { public String toString() { return "seg-critical"; } };
        Object segUndetermined = new Object() { public String toString() { return "seg-undetermined"; } };
        Object segNormal = new Object() { public String toString() { return "seg-normal"; } };
        stl.markInconsistent(segInconsistent);
        stl.markCritical(segCritical);
        stl.markUndetermined(segUndetermined);

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(10, "Resource-A", "seg0");
        dataset.addValue(20, "Resource-A", "seg1");
        dataset.addValue(15, "Resource-A", "seg2");
        dataset.addValue(25, "Resource-A", "seg3");

        PlotBoxTLSmall plotBox = new PlotBoxTLSmall(
                "Resource-A timeline",
                stl,
                new RangeValue(0, 1000),
                new double[]{10, 20, 15, 25},
                new Object[]{segInconsistent, segCritical, segUndetermined, segNormal},
                true);

        JFreeChart chart = plotBox.invokeCreateChart(dataset);
        CategoryPlot plot = chart.getCategoryPlot();
        StackedBarRenderer renderer = (StackedBarRenderer) plot.getRenderer();

        System.out.println("Chart title horizontal alignment: " + chart.getTitle().getHorizontalAlignment());
        System.out.println("Plot range axis location: " + plot.getRangeAxisLocation());
        System.out.println("Plot foreground alpha: " + plot.getForegroundAlpha());
        System.out.println("Renderer base (origin pulse): " + renderer.getBase());
        System.out.println("Renderer item labels visible: " + renderer.isItemLabelsVisible());
        System.out.println("Renderer series paint count: " + renderer.getConfiguredSeriesPaintCount());
        System.out.println("Series 0 paint (expected inconsistent-red 198,30,69): " + renderer.getSeriesPaintFor(0));
        System.out.println("Series 1 paint (expected critical-yellow 238,234,111): " + renderer.getSeriesPaintFor(1));
        System.out.println("Series 2 paint (expected undetermined-white 255,255,255): " + renderer.getSeriesPaintFor(2));
        System.out.println("Series 3 paint (expected default-blue 111,180,238): " + renderer.getSeriesPaintFor(3));
        System.out.println("Range axis lower/upper margin: " + plot.getRangeAxis().getLowerMargin() + " / " + plot.getRangeAxis().getUpperMargin());

        
        
        
        
        PlotBoxTLSmall plotBoxNoRange = new PlotBoxTLSmall(
                "Resource-B timeline", stl, null, new double[]{5}, new Object[]{segNormal}, false);
        DefaultCategoryDataset dataset2 = new DefaultCategoryDataset();
        dataset2.addValue(5, "Resource-B", "seg0");
        JFreeChart chart2 = plotBoxNoRange.invokeCreateChart(dataset2);
        System.out.println("Scenario 2 (range==null): chart created successfully, title=" + chart2.getTitle());

        System.out.println("=== Done ===");
    }
}
