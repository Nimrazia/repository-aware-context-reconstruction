import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.Vector;
import java.util.Map.Entry;
import java.util.logging.Logger;
import java.util.logging.Level;































public class method_2_metacsp_gpt {

    
    
    
    
    static class MetaCSPLogging {
        private static final Map<Class<?>, Logger> loggers = new HashMap<>();

        public static Logger getLogger(Class<?> clazz) {
            return loggers.computeIfAbsent(clazz, c -> {
                Logger l = Logger.getLogger(c.getName());
                l.setLevel(Level.FINEST);
                return l;
            });
        }
    }

    
    
    
    
    
    static class Symbol implements Sentence {
        final String name;
        Symbol(String name) { this.name = name; }
        @Override public String toString() { return name; }
        @Override public boolean equals(Object o) {
            return (o instanceof Symbol) && ((Symbol) o).name.equals(this.name);
        }
        @Override public int hashCode() { return name.hashCode(); }
    }

    
    
    
    
    interface Sentence {}

    static class Not implements Sentence {
        final Sentence arg;
        Not(Sentence arg) { this.arg = arg; }
        @Override public String toString() { return "~" + arg; }
    }

    
    static class Binary implements Sentence {
        final String op;
        final Sentence left, right;
        Binary(String op, Sentence left, Sentence right) { this.op = op; this.left = left; this.right = right; }
        @Override public String toString() { return "(" + left + " " + op + " " + right + ")"; }
    }

    
    
    
    
    static class Converter<T> {
        public List<T> setToList(Set<T> set) {
            return new ArrayList<>(set);
        }
    }

    
    
    
    
    
    
    
    static class PEParser {
        private String[] tokens;
        private int pos;

        public Sentence parse(String wff) {
            this.tokens = tokenize(wff);
            this.pos = 0;
            Sentence s = parseBiconditional();
            return s;
        }

        private String[] tokenize(String s) {
            List<String> toks = new ArrayList<>();
            int i = 0;
            while (i < s.length()) {
                char c = s.charAt(i);
                if (Character.isWhitespace(c)) { i++; continue; }
                if (c == '(' || c == ')') { toks.add(String.valueOf(c)); i++; continue; }
                if (s.startsWith("<=>", i)) { toks.add("<=>"); i += 3; continue; }
                if (s.startsWith("=>", i)) { toks.add("=>"); i += 2; continue; }
                if (s.startsWith("NOT", i)) { toks.add("NOT"); i += 3; continue; }
                if (s.startsWith("AND", i)) { toks.add("AND"); i += 3; continue; }
                if (s.startsWith("OR", i)) { toks.add("OR"); i += 2; continue; }
                
                int start = i;
                while (i < s.length() && !Character.isWhitespace(s.charAt(i))
                        && s.charAt(i) != '(' && s.charAt(i) != ')') {
                    i++;
                }
                toks.add(s.substring(start, i));
            }
            return toks.toArray(new String[0]);
        }

        private String peek() { return pos < tokens.length ? tokens[pos] : null; }
        private String next() { return tokens[pos++]; }

        private Sentence parseBiconditional() {
            Sentence left = parseImplication();
            while ("<=>".equals(peek())) {
                next();
                Sentence right = parseImplication();
                left = new Binary("<=>", left, right);
            }
            return left;
        }

        private Sentence parseImplication() {
            Sentence left = parseOr();
            while ("=>".equals(peek())) {
                next();
                Sentence right = parseOr();
                left = new Binary("=>", left, right);
            }
            return left;
        }

        private Sentence parseOr() {
            Sentence left = parseAnd();
            while ("OR".equals(peek())) {
                next();
                Sentence right = parseAnd();
                left = new Binary("OR", left, right);
            }
            return left;
        }

        private Sentence parseAnd() {
            Sentence left = parseNot();
            while ("AND".equals(peek())) {
                next();
                Sentence right = parseNot();
                left = new Binary("AND", left, right);
            }
            return left;
        }

        private Sentence parseNot() {
            if ("NOT".equals(peek())) {
                next();
                return new Not(parseNot());
            }
            return parseAtom();
        }

        private Sentence parseAtom() {
            String t = peek();
            if ("(".equals(t)) {
                next();
                Sentence s = parseBiconditional();
                if (")".equals(peek())) next();
                return s;
            }
            return new Symbol(next());
        }
    }

    
    
    
    
    
    
    
    static class CNFTransformer {
        public Sentence transform(Sentence s) {
            Sentence noBicond = eliminateBiconditional(s);
            Sentence noImpl = eliminateImplication(noBicond);
            Sentence nnf = pushNegation(noImpl, false);
            return distribute(nnf);
        }

        private Sentence eliminateBiconditional(Sentence s) {
            if (s instanceof Binary) {
                Binary b = (Binary) s;
                Sentence l = eliminateBiconditional(b.left);
                Sentence r = eliminateBiconditional(b.right);
                if (b.op.equals("<=>")) {
                    return new Binary("AND", new Binary("=>", l, r), new Binary("=>", r, l));
                }
                return new Binary(b.op, l, r);
            } else if (s instanceof Not) {
                return new Not(eliminateBiconditional(((Not) s).arg));
            }
            return s;
        }

        private Sentence eliminateImplication(Sentence s) {
            if (s instanceof Binary) {
                Binary b = (Binary) s;
                Sentence l = eliminateImplication(b.left);
                Sentence r = eliminateImplication(b.right);
                if (b.op.equals("=>")) {
                    return new Binary("OR", new Not(l), r);
                }
                return new Binary(b.op, l, r);
            } else if (s instanceof Not) {
                return new Not(eliminateImplication(((Not) s).arg));
            }
            return s;
        }

        private Sentence pushNegation(Sentence s, boolean negate) {
            if (s instanceof Symbol) {
                return negate ? new Not(s) : s;
            }
            if (s instanceof Not) {
                return pushNegation(((Not) s).arg, !negate);
            }
            Binary b = (Binary) s;
            String op = b.op;
            if (negate) {
                op = op.equals("AND") ? "OR" : "AND";
            }
            return new Binary(op, pushNegation(b.left, negate), pushNegation(b.right, negate));
        }

        private Sentence distribute(Sentence s) {
            if (!(s instanceof Binary)) return s;
            Binary b = (Binary) s;
            Sentence l = distribute(b.left);
            Sentence r = distribute(b.right);
            if (b.op.equals("OR")) {
                if (l instanceof Binary && ((Binary) l).op.equals("AND")) {
                    Binary lb = (Binary) l;
                    return distribute(new Binary("AND", new Binary("OR", lb.left, r), new Binary("OR", lb.right, r)));
                }
                if (r instanceof Binary && ((Binary) r).op.equals("AND")) {
                    Binary rb = (Binary) r;
                    return distribute(new Binary("AND", new Binary("OR", l, rb.left), new Binary("OR", l, rb.right)));
                }
            }
            return new Binary(b.op, l, r);
        }
    }

    
    
    
    
    
    static class CNFClauseGatherer {
        public Set<Sentence> getClausesFrom(Sentence cnf) {
            Set<Sentence> clauses = new LinkedHashSet<>();
            collect(cnf, clauses);
            return clauses;
        }

        private void collect(Sentence s, Set<Sentence> clauses) {
            if (s instanceof Binary && ((Binary) s).op.equals("AND")) {
                Binary b = (Binary) s;
                collect(b.left, clauses);
                collect(b.right, clauses);
            } else {
                clauses.add(s);
            }
        }
    }

    
    
    
    
    static class SymbolClassifier {
        public Set<Symbol> getPositiveSymbolsIn(Sentence clause) {
            Set<Symbol> pos = new LinkedHashSet<>();
            collect(clause, false, pos, new LinkedHashSet<>());
            return pos;
        }

        public Set<Symbol> getNegativeSymbolsIn(Sentence clause) {
            Set<Symbol> neg = new LinkedHashSet<>();
            collect(clause, false, new LinkedHashSet<>(), neg);
            return neg;
        }

        private void collect(Sentence s, boolean negated, Set<Symbol> pos, Set<Symbol> neg) {
            if (s instanceof Symbol) {
                if (negated) neg.add((Symbol) s); else pos.add((Symbol) s);
            } else if (s instanceof Not) {
                collect(((Not) s).arg, !negated, pos, neg);
            } else if (s instanceof Binary) {
                Binary b = (Binary) s;
                collect(b.left, negated, pos, neg);
                collect(b.right, negated, pos, neg);
            }
        }
    }

    
    
    
    
    static class BooleanVariable {
        private final String name;
        BooleanVariable(String name) { this.name = name; }
        @Override public String toString() { return name; }
    }

    
    
    
    
    
    
    static class BooleanConstraint {
        private final BooleanVariable[] relevantVars;
        private final boolean[] positive;

        public BooleanConstraint(BooleanVariable[] relevantVars, boolean[] positive) {
            this.relevantVars = relevantVars;
            this.positive = positive;
        }

        public boolean isEquivalent(BooleanConstraint other) {
            if (this.relevantVars.length != other.relevantVars.length) return false;
            Map<BooleanVariable, Boolean> thisMap = new HashMap<>();
            for (int i = 0; i < this.relevantVars.length; i++) thisMap.put(this.relevantVars[i], this.positive[i]);
            Map<BooleanVariable, Boolean> otherMap = new HashMap<>();
            for (int i = 0; i < other.relevantVars.length; i++) otherMap.put(other.relevantVars[i], other.positive[i]);
            return thisMap.equals(otherMap);
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < relevantVars.length; i++) {
                if (i > 0) sb.append(" v ");
                if (!positive[i]) sb.append("~");
                sb.append(relevantVars[i]);
            }
            return sb.append("]").toString();
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public static BooleanConstraint[] createBooleanConstraints(BooleanVariable[] scope, String wff) {
		try {

			wff = wff.replace("~", "NOT ");
			wff = wff.replace("-", "=");
			wff = wff.replace("v", "OR");
			wff = wff.replace("^", "AND");

			MetaCSPLogging.getLogger(BooleanConstraint.class).finest("Converting WFF: " + wff);
			
			Converter<Symbol> sConv = new Converter<Symbol>();
			PEParser parser = new PEParser();
			Sentence s = parser.parse(wff);
			Set<Sentence> clauses = new CNFClauseGatherer().getClausesFrom(new CNFTransformer().transform(s));

	        
	        
			Vector<BooleanConstraint> cons = new Vector<BooleanConstraint>();
			for (Sentence cl : clauses) {
				HashMap<BooleanVariable,Boolean> newClause = new HashMap<BooleanVariable, Boolean>();
		        List<Symbol> positiveSymbols = sConv.setToList(new SymbolClassifier().getPositiveSymbolsIn(cl));
		        List<Symbol> negativeSymbols = sConv.setToList(new SymbolClassifier().getNegativeSymbolsIn(cl));
				try {
					for (Symbol ps : positiveSymbols) {
						BooleanVariable bv = scope[Integer.parseInt(ps.toString().substring(1))-1];
						newClause.put(bv,true);
					}
					for (Symbol ns : negativeSymbols) {
						BooleanVariable bv = scope[Integer.parseInt(ns.toString().substring(1))-1];
						if (newClause.containsKey(bv)) newClause.remove(bv);
						else newClause.put(bv, false);
					}
				}
				catch (ArrayIndexOutOfBoundsException e) { throw new Error("Variable numbering in WFF must be within scope"); }
				catch (NumberFormatException e) { throw new Error("Variables in WFF must be in the format [a-z][1-MAXINT]"); }			
				if (newClause.size() > 0) {
					BooleanVariable[] relevantVars = new BooleanVariable[newClause.size()];
					boolean[] positive = new boolean[newClause.size()];
					int counter = 0;
					for (Entry<BooleanVariable, Boolean> ent : newClause.entrySet()) {
						relevantVars[counter] = ent.getKey();
						positive[counter++] = ent.getValue();
					}
					BooleanConstraint bc = new BooleanConstraint(relevantVars, positive);
					MetaCSPLogging.getLogger(BooleanConstraint.class).finest("Created constraint " + bc);
					boolean subsumed = false;
					for (BooleanConstraint otherBc : cons) {
						if (bc.isEquivalent(otherBc)) {
							subsumed = true;
							break;
						}
					}
					if (!subsumed) cons.add(bc);
				}
			}
			MetaCSPLogging.getLogger(BooleanConstraint.class).finest("CNF(WFF): " + cons);
			return cons.toArray(new BooleanConstraint[cons.size()]);
		}
		catch (java.lang.RuntimeException e) { throw new Error("Malformed BooleanConstraint - allowed logical connectives:\n\t^ : AND\n\tv : OR\n\t-> : implication\n\t<-> : iff\n\t~ : NOT"); }
	}
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    public static void main(String[] args) {
        System.out.println("=== method_2_metacsp_gpt : BooleanConstraint.createBooleanConstraints ===");

        
        BooleanVariable[] scope1 = { new BooleanVariable("A"), new BooleanVariable("B") };
        BooleanConstraint[] cons1 = BooleanConstraint.createBooleanConstraints(scope1, "p1 v p2");
        System.out.println("Scenario 1 (\"p1 v p2\"): " + cons1.length + " constraint(s):");
        for (BooleanConstraint bc : cons1) System.out.println("   " + bc);

        
        
        BooleanVariable[] scope2 = { new BooleanVariable("X"), new BooleanVariable("Y") };
        BooleanConstraint[] cons2 = BooleanConstraint.createBooleanConstraints(scope2, "p1 ^ ~p2");
        System.out.println("Scenario 2 (\"p1 ^ ~p2\"): " + cons2.length + " constraint(s):");
        for (BooleanConstraint bc : cons2) System.out.println("   " + bc);

        
        
        BooleanVariable[] scope3 = { new BooleanVariable("M"), new BooleanVariable("N") };
        BooleanConstraint[] cons3 = BooleanConstraint.createBooleanConstraints(scope3, "p1 -> p2");
        System.out.println("Scenario 3 (\"p1 -> p2\"): " + cons3.length + " constraint(s):");
        for (BooleanConstraint bc : cons3) System.out.println("   " + bc);

        
        
        
        BooleanVariable[] scope4 = { new BooleanVariable("Only1") };
        try {
            BooleanConstraint.createBooleanConstraints(scope4, "p1 v p5");
            System.out.println("Scenario 4: ERROR - expected Error was not thrown");
        } catch (Error e) {
            System.out.println("Scenario 4 (out-of-scope variable p5): caught expected Error: " + e.getMessage().split("\n")[0]);
        }

        System.out.println("=== Done ===");
    }
}
