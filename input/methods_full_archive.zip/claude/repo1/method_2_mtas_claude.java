





































import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicInteger;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class method_2_mtas_claude {

  
  
  
  static class MtasParserException extends Exception {
    MtasParserException(String msg) {
      super(msg);
    }
  }

  static class MtasConfigException extends Exception {
    MtasConfigException(String msg) {
      super(msg);
    }
  }

  
  
  
  static class Log {
    void debug(Object o) {
      System.out.println("[DEBUG] " + o);
    }

    void info(Object o) {
      System.out.println("[INFO] " + o);
    }
  }

  static final Log log = new Log();

  
  
  
  
  static class MtasToken {
    final int id;
    String prefix;
    String postfix;
    String value;
    private final java.util.Set<Integer> positions = new java.util.TreeSet<>();
    private Integer offsetStart;
    private Integer offsetEnd;

    MtasToken(int id, String prefix, String postfix) {
      this.id = id;
      this.prefix = prefix;
      this.postfix = postfix;
    }

    String getPrefix() {
      return prefix;
    }

    String getPostfix() {
      return postfix;
    }

    void setValue(String value) {
      this.value = value;
    }

    String getValue() {
      return value;
    }

    void addOffset(Integer start, Integer end) {
      if (start != null) {
        this.offsetStart = start;
      }
      if (end != null) {
        this.offsetEnd = end;
      }
    }

    void addPositions(java.util.Set<Integer> newPositions) {
      if (newPositions != null) {
        this.positions.addAll(newPositions);
      }
    }

    java.util.Set<Integer> getPositions() {
      return positions;
    }

    @Override
    public String toString() {
      return "MtasToken{id=" + id + ", prefix=" + prefix + ", postfix=" + postfix + ", value="
          + value + ", positions=" + positions + ", offset=[" + offsetStart + "," + offsetEnd
          + "]}";
    }
  }

  static class MtasTokenIdFactory {
    private final AtomicInteger counter = new AtomicInteger(0);

    int createTokenId() {
      return counter.getAndIncrement();
    }
  }

  static class MtasTokenCollection {
    private final Map<Integer, MtasToken> tokens = new LinkedHashMap<>();

    void add(MtasToken token) {
      tokens.put(token.id, token);
    }

    MtasToken get(int id) {
      return tokens.get(id);
    }

    int size() {
      return tokens.size();
    }

    List<MtasToken> asList() {
      return new ArrayList<>(tokens.values());
    }

    
    
    
    void check(boolean autorepair, boolean makeunique) {
      int missing = 0;
      for (MtasToken tok : tokens.values()) {
        if (tok.getPositions().isEmpty()) {
          missing++;
        }
      }
      System.out.println("[MtasTokenCollection.check] tokens=" + tokens.size()
          + " tokensWithoutPositions=" + missing + " autorepair=" + autorepair
          + " makeunique=" + makeunique);
    }
  }

  
  
  
  
  static class MtasParserType<T> {
    final String name;
    final String refAttributeName;

    MtasParserType(String name) {
      this(name, null);
    }

    MtasParserType(String name, String refAttributeName) {
      this.name = name;
      this.refAttributeName = refAttributeName;
    }

    String getName() {
      return name;
    }

    String getRefAttributeName() {
      return refAttributeName;
    }

    @Override
    public String toString() {
      return name;
    }
  }

  static final String MAPPING_TYPE_RELATION = "relation";
  static final String MAPPING_TYPE_RELATION_ANNOTATION = "relationAnnotation";
  static final String MAPPING_TYPE_GROUP = "group";
  static final String MAPPING_TYPE_GROUP_ANNOTATION = "groupAnnotation";
  static final String MAPPING_TYPE_WORD = "word";
  static final String MAPPING_TYPE_WORD_ANNOTATION = "wordAnnotation";
  static final String MAPPING_TYPE_REF = "ref";

  static final String UPDATE_TYPE_VARIABLE = "variable";
  static final String UPDATE_TYPE_OFFSET = "offset";
  static final String UPDATE_TYPE_POSITION = "position";

  static class MtasParserObject {
    final MtasParserType<?> type;
    private final Map<String, String> attributes = new LinkedHashMap<>();
    private final java.util.Set<Integer> positions = new java.util.TreeSet<>();
    private int unknownAncestorNumber = 0;
    private Integer realOffsetStart;
    private Integer realOffsetEnd;
    private Integer offsetStart;
    private Integer offsetEnd;
    private final StringBuilder text = new StringBuilder();
    private final List<String> refIds = new ArrayList<>();
    private final List<String> updateableIdWithOffset = new ArrayList<>();
    private Integer tokenId;

    MtasParserObject(MtasParserType<?> type) {
      this.type = type;
    }

    MtasParserType<?> getType() {
      return type;
    }

    void setAttribute(String name, String value) {
      attributes.put(name, value);
    }

    String getAttribute(String name) {
      return attributes.get(name);
    }

    void setUnknownAncestorNumber(int n) {
      this.unknownAncestorNumber = n;
    }

    int getUnknownAncestorNumber() {
      return unknownAncestorNumber;
    }

    void setRealOffsetStart(Integer v) {
      this.realOffsetStart = v;
    }

    void setRealOffsetEnd(Integer v) {
      this.realOffsetEnd = v;
    }

    void setOffsetStart(Integer v) {
      this.offsetStart = v;
    }

    void setOffsetEnd(Integer v) {
      this.offsetEnd = v;
    }

    Integer getOffsetStart() {
      return offsetStart;
    }

    Integer getOffsetEnd() {
      return offsetEnd;
    }

    Integer[] getOffset() {
      return new Integer[] { offsetStart, offsetEnd };
    }

    void addPosition(int p) {
      positions.add(p);
    }

    void addPositions(java.util.Set<Integer> ps) {
      if (ps != null) {
        positions.addAll(ps);
      }
    }

    void addOffsetStart(Integer v) {
      if (v != null && (offsetStart == null || v < offsetStart)) {
        offsetStart = v;
      }
    }

    void addOffsetEnd(Integer v) {
      if (v != null && (offsetEnd == null || v > offsetEnd)) {
        offsetEnd = v;
      }
    }

    java.util.Set<Integer> getPositions() {
      return positions;
    }

    void addText(String t) {
      if (t != null) {
        text.append(t);
      }
    }

    String getText() {
      return text.toString();
    }

    void addRefId(String refId) {
      refIds.add(refId);
    }

    List<String> getRefIds() {
      return refIds;
    }

    void addUpdateableIdWithOffset(String id) {
      updateableIdWithOffset.add(id);
    }

    List<String> getUpdateableIdWithOffset() {
      return updateableIdWithOffset;
    }

    
    
    
    String getId() {
      return attributes.get("id");
    }

    void updateMappings(Map<String, java.util.Set<Integer>> idPositions,
        Map<String, Integer[]> idOffsets) {
      
      
      
      
    }
  }

  
  
  
  
  MtasTokenCollection tokenCollection;
  boolean autorepair = true;
  boolean makeunique = true;
  boolean allowNonContent = true;
  MtasParserType<?> rootTag;
  MtasParserType<?> contentTag;

  Map<QName, MtasParserType<?>> relationTypes = new HashMap<>();
  Map<QName, MtasParserType<?>> relationAnnotationTypes = new HashMap<>();
  Map<QName, MtasParserType<?>> groupTypes = new HashMap<>();
  Map<QName, MtasParserType<?>> groupAnnotationTypes = new HashMap<>();
  Map<QName, MtasParserType<?>> wordTypes = new HashMap<>();
  Map<QName, MtasParserType<?>> wordAnnotationTypes = new HashMap<>();
  Map<QName, MtasParserType<?>> refTypes = new HashMap<>();
  Map<QName, MtasParserType<?>> variableTypes = new HashMap<>();

  Map<String, SortedSet<String>> relationKeyMap = new HashMap<>();

  QName getQName(MtasParserType<?> type) {
    return new QName(type.getName());
  }

  QName getQName(String localName) {
    return new QName(localName);
  }

  
  
  Map<String, Map<Integer, Set<String>>> createUpdateList() {
    Map<String, Map<Integer, Set<String>>> updateList = new HashMap<>();
    updateList.put(UPDATE_TYPE_VARIABLE, new HashMap<>());
    updateList.put(UPDATE_TYPE_OFFSET, new HashMap<>());
    updateList.put(UPDATE_TYPE_POSITION, new HashMap<>());
    return updateList;
  }

  Map<String, List<MtasParserObject>> createCurrentList() {
    Map<String, List<MtasParserObject>> currentList = new HashMap<>();
    currentList.put(MAPPING_TYPE_RELATION, new ArrayList<>());
    currentList.put(MAPPING_TYPE_RELATION_ANNOTATION, new ArrayList<>());
    currentList.put(MAPPING_TYPE_GROUP, new ArrayList<>());
    currentList.put(MAPPING_TYPE_GROUP_ANNOTATION, new ArrayList<>());
    currentList.put(MAPPING_TYPE_WORD, new ArrayList<>());
    currentList.put(MAPPING_TYPE_WORD_ANNOTATION, new ArrayList<>());
    currentList.put(MAPPING_TYPE_REF, new ArrayList<>());
    return currentList;
  }

  Map<String, Map<String, String>> createVariables() {
    return new HashMap<>();
  }

  void collectAttributes(MtasParserObject object, XMLStreamReader streamReader) {
    for (int i = 0; i < streamReader.getAttributeCount(); i++) {
      object.setAttribute(streamReader.getAttributeLocalName(i), streamReader.getAttributeValue(i));
    }
  }

  void computeVariablesFromObject(MtasParserObject variableObject,
      Map<String, List<MtasParserObject>> currentList, Map<String, Map<String, String>> variables) {
    
    
    
    
    Map<String, String> forType = variables.computeIfAbsent(variableObject.getType().getName(),
        k -> new HashMap<>());
    forType.putAll(variableObject.attributes);
  }

  boolean prevalidateObject(MtasParserObject object, Map<String, List<MtasParserObject>> currentList) {
    
    
    
    
    return true;
  }

  void computeMappingsFromObject(MtasTokenIdFactory idFactory, MtasParserObject currentObject,
      Map<String, List<MtasParserObject>> currentList, Map<String, Map<Integer, Set<String>>> updateList) {
    
    
    
    
    if (currentObject.getType() == null) {
      return;
    }
    String typeName = currentObject.getType().getName();
    if (typeName.equals(MAPPING_TYPE_WORD) || typeName.equals(MAPPING_TYPE_WORD_ANNOTATION)) {
      int id = idFactory.createTokenId();
      MtasToken token = new MtasToken(id, typeName, currentObject.getText().trim());
      token.addPositions(currentObject.getPositions());
      currentObject.tokenId = id;
      tokenCollection.add(token);
      for (String refId : currentObject.getRefIds()) {
        updateList.get(UPDATE_TYPE_POSITION).computeIfAbsent(id, k -> new HashSet<>()).add(refId);
        updateList.get(UPDATE_TYPE_OFFSET).computeIfAbsent(id, k -> new HashSet<>()).add(refId);
      }
    }
  }

  String decodeAndUpdateWithVariables(String encodedPrefix, String encodedPostfix,
      Map<String, Map<String, String>> variables) {
    
    
    StringBuilder sb = new StringBuilder(encodedPrefix == null ? "" : encodedPrefix);
    if (encodedPostfix != null) {
      sb.append(encodedPostfix);
    }
    String result = sb.toString();
    for (Entry<String, Map<String, String>> typeEntry : variables.entrySet()) {
      for (Entry<String, String> attrEntry : typeEntry.getValue().entrySet()) {
        String placeholder = "${" + typeEntry.getKey() + "." + attrEntry.getKey() + "}";
        result = result.replace(placeholder, attrEntry.getValue());
      }
    }
    return result;
  }

  Set<String> recursiveCollect(String refId, Map<String, SortedSet<String>> relationKeyMap, int maxDepth) {
    Set<String> collected = new HashSet<>();
    recursiveCollectInto(refId, relationKeyMap, maxDepth, collected);
    return collected;
  }

  private void recursiveCollectInto(String refId, Map<String, SortedSet<String>> relationKeyMap,
      int depth, Set<String> collected) {
    if (depth <= 0) {
      return;
    }
    SortedSet<String> children = relationKeyMap.get(refId);
    if (children == null) {
      return;
    }
    for (String child : children) {
      if (collected.add(child)) {
        recursiveCollectInto(child, relationKeyMap, depth - 1, collected);
      }
    }
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public MtasTokenCollection createTokenCollection(Reader reader)
      throws MtasParserException, MtasConfigException {
    Boolean hasRoot = rootTag == null ? true : false;
    Boolean parsingContent = contentTag == null ? true : false;
    String textContent = null;
    Integer unknownAncestors = 0;
    Integer lastOffset = 0;

    AtomicInteger position = new AtomicInteger(0);
    Map<String, Set<Integer>> idPositions = new HashMap<>();
    Map<String, Integer[]> idOffsets = new HashMap<>();

    Map<String, Map<Integer, Set<String>>> updateList = createUpdateList();
    Map<String, List<MtasParserObject>> currentList = createCurrentList();
    Map<String, Map<String, String>> variables = createVariables();

    tokenCollection = new MtasTokenCollection();
    MtasTokenIdFactory mtasTokenIdFactory = new MtasTokenIdFactory();
    XMLInputFactory factory = XMLInputFactory.newInstance();
    try {      
      XMLStreamReader streamReader = factory.createXMLStreamReader(reader);
      QName qname;
      try {
        int event = streamReader.getEventType();
        MtasParserType<?> currentType;
        MtasParserType<?> tmpCurrentType;
        MtasParserType<?> tmpVariableType;
        MtasParserObject currentObject = null;
        MtasParserObject variableObject = null;
        while (true) {
          switch (event) {
          case XMLStreamConstants.START_DOCUMENT:
            log.debug("start of document");
            String encodingScheme = streamReader.getCharacterEncodingScheme();
            if (encodingScheme == null) {
              
              log.info("No encodingScheme found, assume utf-8");
              
            } else if (!encodingScheme.equalsIgnoreCase("utf-8")) {
              throw new MtasParserException(
                  "XML not UTF-8 encoded but '" + encodingScheme + "'");
            }
            break;
          case XMLStreamConstants.END_DOCUMENT:
            log.debug("end of document");
            break;
          case XMLStreamConstants.SPACE:
            
            lastOffset = streamReader.getLocation().getCharacterOffset();
            break;
          case XMLStreamConstants.START_ELEMENT:
            
            qname = streamReader.getName();
            
            if (!hasRoot) {
              if (qname.equals(getQName(rootTag))) {
                hasRoot = true;
              } else {
                throw new MtasParserException("No " + rootTag);
              }
              
            } else {
              if ((tmpVariableType = variableTypes.get(qname)) != null) {
                variableObject = new MtasParserObject(tmpVariableType);
                collectAttributes(variableObject, streamReader);
                computeVariablesFromObject(variableObject, currentList,
                    variables);
              }
              if (parsingContent) {
                
                
                if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .isEmpty())
                    && (tmpCurrentType = relationTypes.get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_RELATION).add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (!currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (tmpCurrentType = relationAnnotationTypes
                        .get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                        .add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .isEmpty())
                    && (tmpCurrentType = groupTypes.get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_GROUP).add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (!currentList.get(MAPPING_TYPE_GROUP).isEmpty())
                    && (tmpCurrentType = groupAnnotationTypes
                        .get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .isEmpty())
                    && (currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (currentList.get(MAPPING_TYPE_WORD_ANNOTATION).isEmpty())
                    && (tmpCurrentType = wordTypes.get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setOffsetStart(lastOffset);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentObject.addPosition(position.getAndIncrement());
                    currentList.get(MAPPING_TYPE_WORD).add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .isEmpty())
                    && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (tmpCurrentType = wordAnnotationTypes
                        .get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.addPositions(currentList.get(MAPPING_TYPE_WORD)
                      .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                      .getPositions());
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                        .add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()
                    && (tmpCurrentType = refTypes.get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_REF).add(currentObject);
                    unknownAncestors = 0;
                    
                    for (MtasParserObject currentRelation : currentList
                        .get(MAPPING_TYPE_RELATION)) {
                      currentRelation.addRefId(currentObject
                          .getAttribute(currentType.getRefAttributeName()));
                      
                      SortedSet<String> keyMapList;
                      if (currentRelation.getId() != null) {
                        if (relationKeyMap
                            .containsKey(currentRelation.getId())) {
                          keyMapList = relationKeyMap
                              .get(currentRelation.getId());
                        } else {
                          keyMapList = new TreeSet<>();
                          relationKeyMap.put(currentRelation.getId(),
                              keyMapList);
                        }
                        keyMapList.add(currentObject
                            .getAttribute(currentType.getRefAttributeName()));
                      }
                    }
                  }
                } else {
                  unknownAncestors++;
                }
                
              } else if (qname.equals(getQName(contentTag))) {
                parsingContent = true;
                
              } else if (!allowNonContent) {
                throw new MtasParserException(
                    "Unexpected " + qname.getLocalPart() + " in document");
              }
            }
            
            lastOffset = streamReader.getLocation().getCharacterOffset();
            break;
          case XMLStreamConstants.END_ELEMENT:
            
            lastOffset = streamReader.getLocation().getCharacterOffset();
            
            qname = streamReader.getName();
            
            if (parsingContent) {
              if (unknownAncestors > 0) {
                unknownAncestors--;
                
                
              } else if (!currentList.get(MAPPING_TYPE_REF).isEmpty()) {
                if ((currentType = refTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_REF)
                      .remove(currentList.get(MAPPING_TYPE_REF).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
                
              } else if (!currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                  .isEmpty()) {
                if ((currentType = wordAnnotationTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                      .remove(
                          currentList.get(MAPPING_TYPE_WORD_ANNOTATION).size()
                              - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  
                  
                  if ((currentObject.getId() != null)
                      && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())) {
                    currentList.get(MAPPING_TYPE_WORD)
                        .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                        .addUpdateableIdWithOffset(currentObject.getId());
                  }
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
                
              } else if (!currentList.get(MAPPING_TYPE_WORD).isEmpty()) {
                if ((currentType = wordTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_WORD)
                      .remove(currentList.get(MAPPING_TYPE_WORD).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  currentObject.setOffsetEnd(lastOffset);
                  currentObject.setRealOffsetEnd(lastOffset);
                  
                  for (MtasParserObject currentGroup : currentList
                      .get(MAPPING_TYPE_GROUP)) {
                    currentGroup.addPositions(currentObject.getPositions());
                    currentGroup.addOffsetStart(currentObject.getOffsetStart());
                    currentGroup.addOffsetEnd(currentObject.getOffsetEnd());
                  }
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
                
              } else if (!currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                  .isEmpty()) {
                if ((currentType = groupAnnotationTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                      .remove(
                          currentList.get(MAPPING_TYPE_GROUP_ANNOTATION).size()
                              - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
              } else if (!currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                  .isEmpty()) {
                if ((currentType = relationAnnotationTypes
                    .get(qname)) != null) {
                  currentObject = currentList
                      .get(MAPPING_TYPE_RELATION_ANNOTATION).remove(currentList
                          .get(MAPPING_TYPE_RELATION_ANNOTATION).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
              } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()) {
                if ((currentType = relationTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_RELATION).remove(
                      currentList.get(MAPPING_TYPE_RELATION).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
              } else if (!currentList.get(MAPPING_TYPE_GROUP).isEmpty()) {
                if ((currentType = groupTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_GROUP)
                      .remove(currentList.get(MAPPING_TYPE_GROUP).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  unknownAncestors--;
                }
              } else if (qname.equals(getQName("text"))) {
                parsingContent = false;
                assert unknownAncestors == 0 : "error in administration unknownAncestors";
                assert currentList.get(MAPPING_TYPE_REF)
                    .isEmpty() : "error in administration references";
                assert currentList.get(MAPPING_TYPE_GROUP)
                    .isEmpty() : "error in administration groups";
                assert currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                    .isEmpty() : "error in administration groupAnnotations";
                assert currentList.get(MAPPING_TYPE_WORD)
                    .isEmpty() : "error in administration words";
                assert currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                    .isEmpty() : "error in administration wordAnnotations";
                assert currentList.get(MAPPING_TYPE_RELATION)
                    .isEmpty() : "error in administration relations";
                assert currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                    .isEmpty() : "error in administration relationAnnotations";
              }
            }
            
            textContent = null;
            break;
          case XMLStreamConstants.CHARACTERS:
            
            lastOffset = streamReader.getLocation().getCharacterOffset();
            
            if (streamReader.hasText()) {
              textContent = streamReader.getText();
            }
            if (currentObject != null && unknownAncestors.equals(0)) {
              currentObject.addText(textContent);
            }
            break;
          default:
            break;
          }
          if (!streamReader.hasNext()) {
            break;
          }
          event = streamReader.next();
        }
      } finally {
        streamReader.close();
      }
      
      assert unknownAncestors == 0 : "error in administration unknownAncestors";
      assert hasRoot : "no " + rootTag;
    } catch (XMLStreamException e) {
      log.debug(e);      
      throw new MtasParserException("No valid XML: " + e.getMessage());
    }

    
    for (Entry<Integer, Set<String>> updateItem : updateList
        .get(UPDATE_TYPE_VARIABLE).entrySet()) {
      MtasToken token = tokenCollection.get(updateItem.getKey());
      String encodedPrefix = token.getPrefix();
      String encodedPostfix = token.getPostfix();
      token.setValue(decodeAndUpdateWithVariables(encodedPrefix, encodedPostfix,
          variables));
    }
    
    for (Entry<Integer, Set<String>> updateItem : updateList
        .get(UPDATE_TYPE_OFFSET).entrySet()) {
      Set<String> refIdList = new HashSet<>();
      for (String refId : updateItem.getValue()) {
        if (idPositions.containsKey(refId)) {
          refIdList.add(refId);
        }
        if (relationKeyMap.containsKey(refId)) {
          refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
        }
      }
      for (String refId : refIdList) {
        Integer[] refOffset = idOffsets.get(refId);
        Integer tokenId = updateItem.getKey();
        if (tokenId != null && refOffset != null) {
          MtasToken token = tokenCollection.get(tokenId);
          token.addOffset(refOffset[0], refOffset[1]);
        }
      }
    }
    
    for (Entry<Integer, Set<String>> updateItem : updateList
        .get(UPDATE_TYPE_POSITION).entrySet()) {
      HashSet<String> refIdList = new HashSet<>();
      for (String refId : updateItem.getValue()) {
        if (idPositions.containsKey(refId)) {
          refIdList.add(refId);
        }
        if (relationKeyMap.containsKey(refId)) {
          refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
        }
      }
      for (String refId : refIdList) {
        Set<Integer> refPositions = idPositions.get(refId);
        Integer tokenId = updateItem.getKey();
        if (tokenId != null && refPositions != null) {
          MtasToken token = tokenCollection.get(tokenId);
          token.addPositions(refPositions);
        }
      }
    }
    
    tokenCollection.check(autorepair, makeunique);
    return tokenCollection;
  }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: MtasXMLParser.createTokenCollection ===");

    method_2_mtas_claude parser = new method_2_mtas_claude();

    
    
    
    parser.rootTag = new MtasParserType<>("doc");
    parser.contentTag = new MtasParserType<>("text");
    parser.groupTypes.put(new QName("s"), new MtasParserType<>("s"));
    parser.wordTypes.put(new QName("w"), new MtasParserType<>("w"));
    parser.wordAnnotationTypes.put(new QName("lemma"), new MtasParserType<>("lemma"));
    parser.relationTypes.put(new QName("link"), new MtasParserType<>("link"));
    parser.refTypes.put(new QName("ref"), new MtasParserType<>("ref", "target"));

    String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        + "<doc>\n"
        + "  <text>\n"
        + "    <s>\n"
        + "      <w id=\"w1\">The<lemma pos=\"det\">the</lemma></w>\n"
        + "      <w id=\"w2\">quick<lemma pos=\"adj\">quick</lemma></w>\n"
        + "      <w id=\"w3\">fox<lemma pos=\"noun\">fox</lemma></w>\n"
        + "    </s>\n"
        + "    <link id=\"l1\">\n"
        + "      <ref target=\"w1\"/>\n"
        + "      <ref target=\"w3\"/>\n"
        + "    </link>\n"
        + "  </text>\n"
        + "</doc>\n";

    System.out.println("\n-- Parsing sample XML (root=doc, content=text, group=s, word=w, "
        + "wordAnnotation=lemma, relation=link, ref=ref) --");
    Reader reader = new StringReader(xml);
    MtasTokenCollection collection = parser.createTokenCollection(reader);

    System.out.println("\n-- Resulting MtasTokenCollection (" + collection.size() + " tokens) --");
    for (MtasToken tok : collection.asList()) {
      System.out.println("  " + tok);
    }

    System.out.println("\n-- Relation key map built while parsing (for recursive ref resolution) --");
    for (Entry<String, SortedSet<String>> e : parser.relationKeyMap.entrySet()) {
      System.out.println("  " + e.getKey() + " -> " + e.getValue());
    }

    System.out.println("\n=== Demo complete: method exercised the root/content/group/word/"
        + "wordAnnotation/relation/ref XML-walk branches and the position/offset update passes. ===");
  }
}
