

































import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TimeZone;
import java.util.TreeMap;

public class method_1_mtas_claude {

  
  
  
  enum DocValuesType {
    NONE, NUMERIC, BINARY, SORTED, SORTED_SET, SORTED_NUMERIC
  }

  static class BytesRef {
    byte[] bytes;
    int offset;
    int length;

    BytesRef(String s) {
      this.bytes = s.getBytes(java.nio.charset.StandardCharsets.UTF_8);
      this.offset = 0;
      this.length = this.bytes.length;
    }

    String utf8ToString() {
      return new String(bytes, offset, length, java.nio.charset.StandardCharsets.UTF_8);
    }
  }

  static class NumericDocValues {
    private final Map<Integer, Long> values;
    private long current;

    NumericDocValues(Map<Integer, Long> values) {
      this.values = values;
    }

    boolean advanceExact(int doc) {
      Long v = values.get(doc);
      if (v == null) {
        return false;
      }
      current = v;
      return true;
    }

    long longValue() {
      return current;
    }
  }

  static class SortedNumericDocValues {
    private final Map<Integer, long[]> values;
    private long[] current;
    private int idx;

    SortedNumericDocValues(Map<Integer, long[]> values) {
      this.values = values;
    }

    boolean advanceExact(int doc) {
      long[] v = values.get(doc);
      if (v == null) {
        return false;
      }
      current = v;
      idx = 0;
      return true;
    }

    int docValueCount() {
      return current.length;
    }

    long nextValue() {
      return current[idx++];
    }
  }

  static class SortedSetDocValues {
    static final long NO_MORE_ORDS = -1;
    private final Map<Integer, String[]> values;
    private String[] current;
    private int idx;

    SortedSetDocValues(Map<Integer, String[]> values) {
      this.values = values;
    }

    boolean advanceExact(int doc) {
      String[] v = values.get(doc);
      if (v == null) {
        return false;
      }
      current = v;
      idx = 0;
      return true;
    }

    long nextOrd() {
      if (idx >= current.length) {
        return NO_MORE_ORDS;
      }
      return idx++;
    }

    BytesRef lookupOrd(long ord) {
      return new BytesRef(current[(int) ord]);
    }
  }

  static class SortedDocValues {
    private final Map<Integer, String> values;
    private String current;

    SortedDocValues(Map<Integer, String> values) {
      this.values = values;
    }

    boolean advanceExact(int doc) {
      String v = values.get(doc);
      if (v == null) {
        return false;
      }
      current = v;
      return true;
    }

    BytesRef binaryValue() {
      return new BytesRef(current);
    }
  }

  static class FieldInfo {
    private final DocValuesType docValuesType;

    FieldInfo(DocValuesType t) {
      this.docValuesType = t;
    }

    DocValuesType getDocValuesType() {
      return docValuesType;
    }
  }

  static class FieldInfos {
    private final Map<String, FieldInfo> map;

    FieldInfos(Map<String, FieldInfo> map) {
      this.map = map;
    }

    FieldInfo fieldInfo(String name) {
      return map.get(name);
    }
  }

  static class PostingsEnum {
    private final Set<Integer> docsWithHits;

    PostingsEnum(Set<Integer> docsWithHits) {
      this.docsWithHits = docsWithHits;
    }

    int advance(int target) {
      for (int d = target; d < target + 1_000_000; d++) {
        if (docsWithHits.contains(d)) {
          return d;
        }
      }
      return Integer.MAX_VALUE;
    }
  }

  static class TermsEnum {
    private final Iterator<Map.Entry<String, Set<Integer>>> it;
    String currentTerm;
    Set<Integer> currentDocs;

    TermsEnum(Map<String, Set<Integer>> postings) {
      this.it = postings.entrySet().iterator();
    }

    BytesRef next() {
      if (!it.hasNext()) {
        return null;
      }
      Map.Entry<String, Set<Integer>> e = it.next();
      currentTerm = e.getKey();
      currentDocs = e.getValue();
      return new BytesRef(currentTerm);
    }

    PostingsEnum postings(PostingsEnum reuse) {
      return new PostingsEnum(currentDocs);
    }
  }

  static class Terms {
    private final Map<String, Set<Integer>> postings;

    Terms(Map<String, Set<Integer>> postings) {
      this.postings = postings;
    }

    TermsEnum iterator() {
      return new TermsEnum(postings);
    }
  }

  static class LeafReaderContext {
    final int docBase;
    private final LeafReader reader;

    LeafReaderContext(int docBase, LeafReader reader) {
      this.docBase = docBase;
      this.reader = reader;
    }

    LeafReader reader() {
      return reader;
    }
  }

  static class LeafReader {
    Map<String, NumericDocValues> numericDV = new HashMap<>();
    Map<String, SortedNumericDocValues> sortedNumericDV = new HashMap<>();
    Map<String, SortedSetDocValues> sortedSetDV = new HashMap<>();
    Map<String, SortedDocValues> sortedDV = new HashMap<>();
    Map<String, Terms> terms = new HashMap<>();
    int maxDocValue = 1000;
    LeafReaderContext ctx;

    LeafReaderContext getContext() {
      return ctx;
    }

    NumericDocValues getNumericDocValues(String field) {
      return numericDV.get(field);
    }

    SortedNumericDocValues getSortedNumericDocValues(String field) {
      return sortedNumericDV.get(field);
    }

    SortedSetDocValues getSortedSetDocValues(String field) {
      return sortedSetDV.get(field);
    }

    SortedDocValues getSortedDocValues(String field) {
      return sortedDV.get(field);
    }

    Terms terms(String field) {
      return terms.get(field);
    }

    int maxDoc() {
      return maxDocValue;
    }
  }

  static class IndexSearcher {
  }

  
  
  
  
  static class DocIdSetIterator {
    static final int NO_MORE_DOCS = Integer.MAX_VALUE;
  }

  static class Spans {
    static final int NO_MORE_POSITIONS = -1;
    private final Map<Integer, int[][]> hitsByDoc; 
    private final int docBase;
    private int currentDocLocal = -1;
    private int[][] currentHits;
    private int posIdx;
    private int lastIdx = -1;

    Spans(Map<Integer, int[][]> hitsByDoc, int docBase) {
      this.hitsByDoc = hitsByDoc;
      this.docBase = docBase;
    }

    int docID() {
      return currentDocLocal;
    }

    int advance(int target) {
      int d = target;
      while (true) {
        if (hitsByDoc.containsKey(d)) {
          currentDocLocal = d;
          currentHits = hitsByDoc.get(d);
          posIdx = 0;
          lastIdx = -1;
          return d;
        }
        d++;
        if (d - target > 1_000_000) {
          return DocIdSetIterator.NO_MORE_DOCS;
        }
      }
    }

    
    
    
    int nextStartPosition() {
      if (currentHits == null || posIdx >= currentHits.length) {
        return NO_MORE_POSITIONS;
      }
      int start = currentHits[posIdx][0];
      lastIdx = posIdx;
      posIdx++;
      return start;
    }

    int endPosition() {
      return currentHits[lastIdx][1];
    }
  }

  static class SpanWeight {
    enum Postings {
      POSITIONS
    }

    private final Map<Integer, int[][]> hitsByDoc;

    SpanWeight(Map<Integer, int[][]> hitsByDoc) {
      this.hitsByDoc = hitsByDoc;
    }

    Spans getSpans(LeafReaderContext ctx, Postings requiredPostings) {
      if (hitsByDoc.isEmpty()) {
        return null;
      }
      return new Spans(hitsByDoc, ctx.docBase);
    }
  }

  abstract static class MtasSpanQuery {
    abstract boolean isMatchAllPositionsQuery();
  }

  
  
  
  
  static class CodecInfo {
    Map<Integer, Integer> positionsByLocalDoc = new HashMap<>();
    Map<Integer, Integer> tokensByLocalDoc = new HashMap<>();

    int getNumberOfPositions(String field, int localDocId) {
      Integer v = positionsByLocalDoc.get(localDocId);
      return v == null ? 0 : v;
    }

    Map<Integer, Integer> getAllNumberOfPositions(String field, int docBase) {
      Map<Integer, Integer> result = new HashMap<>();
      for (Entry<Integer, Integer> e : positionsByLocalDoc.entrySet()) {
        result.put(e.getKey() + docBase, e.getValue());
      }
      return result;
    }

    int getNumberOfTokens(String field, int localDocId) {
      Integer v = tokensByLocalDoc.get(localDocId);
      return v == null ? 0 : v;
    }

    Map<Integer, Integer> getAllNumberOfTokens(String field, int docBase) {
      Map<Integer, Integer> result = new HashMap<>();
      for (Entry<Integer, Integer> e : tokensByLocalDoc.entrySet()) {
        result.put(e.getKey() + docBase, e.getValue());
      }
      return result;
    }
  }

  
  
  
  static class Match {
    final int startPosition;
    final int endPosition;

    Match(int startPosition, int endPosition) {
      this.startPosition = startPosition;
      this.endPosition = endPosition;
    }

    @Override
    public String toString() {
      return "[" + startPosition + "," + endPosition + ")";
    }
  }

  enum NumberType {
    INTEGER, LONG, DATE, STRING
  }

  static class LegacyNumericUtils {
    static final byte SHIFT_START_INT = 0;
    static final byte SHIFT_START_LONG = 0;

    static int prefixCodedToInt(BytesRef b) {
      return Integer.parseInt(b.utf8ToString());
    }

    static long prefixCodedToLong(BytesRef b) {
      return Long.parseLong(b.utf8ToString());
    }
  }

  
  
  
  
  interface MtasFunctionParserFunction {
    boolean needPositions();

    int needArgumentsNumber();

    HashSet<Integer> needArgument();
  }

  interface BaseParser {
    boolean needPositions();

    int needArgumentsNumber();

    HashSet<Integer> needArgument();
  }

  static class ComponentSpan {
    BaseParser parser;
    MtasSpanQuery[] queries;
    List<MtasFunctionParserFunction> functionList = new ArrayList<>();

    boolean functionNeedPositions() {
      for (MtasFunctionParserFunction f : functionList) {
        if (f.needPositions()) {
          return true;
        }
      }
      return false;
    }

    HashSet<Integer> functionNeedArguments() {
      HashSet<Integer> r = new HashSet<>();
      for (MtasFunctionParserFunction f : functionList) {
        r.addAll(f.needArgument());
      }
      return r;
    }
  }

  static class ComponentKwic {
    MtasSpanQuery query;
  }

  static class ComponentList {
    MtasSpanQuery spanQuery;
    int number;
    int position;
    int start;
  }

  static class ComponentGroup {
    MtasSpanQuery spanQuery;
  }

  static final String TYPE_POINTFIELD_WITHOUT_DOCVALUES_CONST = "pointFieldWithoutDocValues";

  static class ComponentFacet {
    String[] baseFields;
    String[] baseFieldTypes;
    BaseParser[] baseParsers;
    MtasSpanQuery[] spanQueries;
    @SuppressWarnings("unchecked")
    List<MtasFunctionParserFunction>[] baseFunctionParserFunctions;

    static final String TYPE_POINTFIELD_WITHOUT_DOCVALUES = TYPE_POINTFIELD_WITHOUT_DOCVALUES_CONST;

    boolean baseParserNeedPositions() {
      for (BaseParser p : baseParsers) {
        if (p != null && p.needPositions()) {
          return true;
        }
      }
      return false;
    }

    boolean functionNeedPositions() {
      for (List<MtasFunctionParserFunction> fl : baseFunctionParserFunctions) {
        if (fl != null) {
          for (MtasFunctionParserFunction f : fl) {
            if (f.needPositions()) {
              return true;
            }
          }
        }
      }
      return false;
    }
  }

  static class SubComponentFunction2 {
    MtasFunctionParserFunction parserFunction;
  }

  static class ComponentTermVector {
    SubComponentFunction2 subComponentFunction = new SubComponentFunction2();
    List<MtasFunctionParserFunction> functions;

    boolean functionNeedPositions() {
      if (functions == null) {
        return false;
      }
      for (MtasFunctionParserFunction f : functions) {
        if (f.needPositions()) {
          return true;
        }
      }
      return false;
    }
  }

  static class ComponentDocument {
  }

  static class ComponentField {
    List<Object> statsPositionList = new ArrayList<>();
    List<Object> statsTokenList = new ArrayList<>();
    List<ComponentTermVector> termVectorList = new ArrayList<>();
    List<MtasSpanQuery> spanQueryList = new ArrayList<>();
    List<ComponentSpan> statsSpanList = new ArrayList<>();
    List<ComponentKwic> kwicList = new ArrayList<>();
    List<ComponentList> listList = new ArrayList<>();
    List<ComponentGroup> groupList = new ArrayList<>();
    List<ComponentFacet> facetList = new ArrayList<>();
    List<ComponentDocument> documentList = new ArrayList<>();
    String uniqueKeyField = "id";
  }

  static class Status {
  }

  
  
  
  
  
  
  
  
  
  static void createPositions(List<Object> statsPositionList,
      Map<Integer, Integer> positionsData, List<Integer> docSet) {
    System.out.println("[createPositions] docs=" + docSet.size()
        + " positionsData=" + positionsData);
  }

  static void createTokens(List<Object> statsTokenList,
      Map<Integer, Integer> tokensData, List<Integer> docSet) {
    System.out.println("[createTokens] docs=" + docSet.size()
        + " tokensData=" + tokensData);
  }

  static void createDocument(List<ComponentDocument> documentList, List<Integer> docList,
      String uniqueKeyField, IndexSearcher searcher, Terms t, LeafReaderContext lrc) {
    System.out.println("[createDocument] docList=" + docList + " uniqueKeyField=" + uniqueKeyField);
  }

  static void createStats(List<ComponentSpan> statsSpanList,
      Map<Integer, Integer> positionsData,
      Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData, Integer[] docSet) {
    System.out.println("[createStats] spans=" + statsSpanList.size()
        + " docs=" + docSet.length);
  }

  static void createList(List<ComponentList> listList,
      Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData,
      Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData, List<Integer> docSet,
      String field, int docBase, String uniqueKeyField, CodecInfo mtasCodecInfo,
      IndexSearcher searcher) {
    System.out.println("[createList] lists=" + listList.size() + " field=" + field);
    for (ComponentList cl : listList) {
      Map<Integer, List<Match>> matches = spansMatchData.get(cl.spanQuery);
      Map<Integer, Integer> numbers = spansNumberData.get(cl.spanQuery);
      System.out.println("   list query -> matches=" + matches + " numbers=" + numbers);
    }
  }

  static void createGroup(List<ComponentGroup> groupList,
      Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData, List<Integer> docSet,
      FieldInfo fi, String field, int docBase, CodecInfo mtasCodecInfo, IndexSearcher searcher,
      LeafReaderContext lrc, Status status) {
    System.out.println("[createGroup] groups=" + groupList.size() + " field=" + field);
    for (ComponentGroup cg : groupList) {
      System.out.println("   group matches -> " + spansMatchData.get(cg.spanQuery));
    }
  }

  static void createKwic(List<ComponentKwic> kwicList,
      Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData, List<Integer> docList,
      String field, int docBase, String uniqueKeyField, CodecInfo mtasCodecInfo,
      IndexSearcher searcher) {
    System.out.println("[createKwic] kwics=" + kwicList.size() + " field=" + field);
    for (ComponentKwic ck : kwicList) {
      System.out.println("   kwic matches -> " + spansMatchData.get(ck.query));
    }
  }

  static void createFacet(List<ComponentFacet> facetList,
      Map<Integer, Integer> positionsData,
      Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData,
      Map<String, SortedMap<String, int[]>> facetData, List<Integer> docSet) {
    System.out.println("[createFacet] facets=" + facetList.size());
    for (Entry<String, SortedMap<String, int[]>> e : facetData.entrySet()) {
      System.out.print("   facet field '" + e.getKey() + "': ");
      for (Entry<String, int[]> t : e.getValue().entrySet()) {
        System.out.print(t.getKey() + "=" + Arrays.toString(t.getValue()) + " ");
      }
      System.out.println();
    }
  }

  static void createTermvectorFull(List<ComponentTermVector> termVectorList,
      Map<Integer, Integer> positionsData, List<Integer> docSet, Terms t, LeafReader r,
      LeafReaderContext lrc) {
    System.out.println("[createTermvectorFull] termVectors=" + termVectorList.size());
  }

  static void createTermvectorFirstRound(List<ComponentTermVector> termVectorList,
      Map<Integer, Integer> positionsData, List<Integer> docSet, Terms t, LeafReader r,
      LeafReaderContext lrc) {
    System.out.println("[createTermvectorFirstRound] termVectors=" + termVectorList.size());
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  private static void collectSpansPositionsAndTokens(
      Map<MtasSpanQuery, SpanWeight> spansQueryWeight, IndexSearcher searcher,
      CodecInfo mtasCodecInfo, LeafReader r, LeafReaderContext lrc,
      String field, Terms t, List<Integer> docSet, List<Integer> docList,
      ComponentField fieldInfo, FieldInfos fieldInfos, Status status)
      throws IOException {

    boolean needSpans = false;
    boolean needPositions = false;
    boolean needTokens = false;

    
    Map<Integer, Integer> positionsData = null;
    Map<Integer, Integer> tokensData = null;
    Set<MtasSpanQuery> spansNumberByPositions = null;
    Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData = null;
    Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData = null;
    Map<String, SortedMap<String, int[]>> facetData = null;
    Map<String, String> facetDataType = null;

    
    if (!fieldInfo.statsPositionList.isEmpty()) {
      needPositions = true;
    }
    
    if (!fieldInfo.statsTokenList.isEmpty()) {
      needTokens = true;
    }
    if (!fieldInfo.termVectorList.isEmpty()) {
      for (ComponentTermVector ctv : fieldInfo.termVectorList) {
        if (!needPositions) {
          needPositions = (ctv.functions == null
              ? ctv.subComponentFunction.parserFunction.needPositions()
              : ctv.functionNeedPositions());
        }
      }
    }

    
    if (!fieldInfo.spanQueryList.isEmpty()) {
      
      spansNumberByPositions = new HashSet<>();
      spansNumberData = new HashMap<>();
      spansMatchData = new HashMap<>();
      facetData = new HashMap<>();
      facetDataType = new HashMap<>();
      
      if (!fieldInfo.statsSpanList.isEmpty()) {
        for (ComponentSpan cs : fieldInfo.statsSpanList) {
          needPositions = (!needPositions) ? cs.parser.needPositions()
              : needPositions;
          needPositions = (!needPositions) ? cs.functionNeedPositions()
              : needPositions;
          needSpans = (!needSpans) ? cs.parser.needArgumentsNumber() > 0
              : needSpans;
          HashSet<Integer> arguments = cs.parser.needArgument();
          arguments.addAll(cs.functionNeedArguments());
          for (int a : arguments) {
            if (cs.queries.length > a) {
              MtasSpanQuery q = cs.queries[a];
              if (!spansNumberData.containsKey(q)) {
                spansNumberData.put(q, new HashMap<Integer, Integer>());
              }
            }
          }
        }
      }
      
      if (!fieldInfo.kwicList.isEmpty()) {
        needSpans = true;
        for (ComponentKwic ck : fieldInfo.kwicList) {
          if (!spansMatchData.containsKey(ck.query)) {
            spansMatchData.put(ck.query, new HashMap<Integer, List<Match>>());
          }
        }
      }
      
      if (!fieldInfo.listList.isEmpty()) {
        needSpans = true;
        for (ComponentList cl : fieldInfo.listList) {
          if (!spansMatchData.containsKey(cl.spanQuery)) {
            if (cl.number > 0) {
              
              if (cl.position < (cl.start + cl.number)) {
                spansMatchData.put(cl.spanQuery,
                    new HashMap<Integer, List<Match>>());
              } else {
                spansNumberData.put(cl.spanQuery,
                    new HashMap<Integer, Integer>());
              }
            } else if (!spansNumberData.containsKey(cl.spanQuery)) {
              spansNumberData.put(cl.spanQuery,
                  new HashMap<Integer, Integer>());
            }
          }
        }
      }
      
      if (!fieldInfo.groupList.isEmpty()) {
        needSpans = true;
        for (ComponentGroup cg : fieldInfo.groupList) {
          if (!spansMatchData.containsKey(cg.spanQuery)) {
            spansMatchData.put(cg.spanQuery,
                new HashMap<Integer, List<Match>>());
          }
        }
      }
      
      if (!fieldInfo.facetList.isEmpty()) {
        for (ComponentFacet cf : fieldInfo.facetList) {
          needPositions = !needPositions ? cf.baseParserNeedPositions()
              : needPositions;
          needPositions = !needPositions ? cf.functionNeedPositions()
              : needPositions;
          for (int i = 0; i < cf.baseFields.length; i++) {
            needSpans = !needSpans ? cf.baseParsers[i].needArgumentsNumber() > 0
                : needSpans;
            HashSet<Integer> arguments = cf.baseParsers[i].needArgument();
            for (int a : arguments) {
              if (cf.spanQueries.length > a) {
                MtasSpanQuery q = cf.spanQueries[a];
                if (!spansNumberData.containsKey(q)) {
                  spansNumberData.put(q, new HashMap<Integer, Integer>());
                }
              }
            }
            for (MtasFunctionParserFunction function : cf.baseFunctionParserFunctions[i]) {
              needSpans = !needSpans ? function.needArgumentsNumber() > 0
                  : needSpans;
              arguments = function.needArgument();
              for (int a : arguments) {
                if (cf.spanQueries.length > a) {
                  MtasSpanQuery q = cf.spanQueries[a];
                  if (!spansNumberData.containsKey(q)) {
                    spansNumberData.put(q, new HashMap<Integer, Integer>());
                  }
                }
              }
            }
            if (!facetData.containsKey(cf.baseFields[i])) {
              facetData.put(cf.baseFields[i], new TreeMap<String, int[]>());
              facetDataType.put(cf.baseFields[i], cf.baseFieldTypes[i]);
            }
          }
        }
      }
      
      if (!fieldInfo.termVectorList.isEmpty()) {
        for (ComponentTermVector ctv : fieldInfo.termVectorList) {
          if ((ctv.subComponentFunction.parserFunction != null
              && ctv.subComponentFunction.parserFunction.needPositions())
              || (ctv.functions != null && ctv.functionNeedPositions())) {
            needPositions = true;
          }
        }
      }
    }

    if (needSpans) {
      Map<Integer, Integer> numberData;
      Map<Integer, List<Match>> matchData;
      
      for (Entry<String, SortedMap<String, int[]>> entry : facetData
          .entrySet()) {
        FieldInfo fi = fieldInfos.fieldInfo(entry.getKey());
        if (fi != null) {
          
          if (!fi.getDocValuesType().equals(DocValuesType.NONE)) {
            Iterator<Integer> docIterator = docSet.iterator();
            
            if (fi.getDocValuesType().equals(DocValuesType.NUMERIC)
                || fi.getDocValuesType().equals(DocValuesType.SORTED)
                || fi.getDocValuesType().equals(DocValuesType.SORTED_SET)
                || fi.getDocValuesType().equals(DocValuesType.SORTED_NUMERIC)
                || fi.getDocValuesType().equals(DocValuesType.BINARY)) {
              
              Map<Object, List<Integer>> facetDataSubList = new HashMap<>();
              
              if (fi.getDocValuesType().equals(DocValuesType.NUMERIC)) {
                NumericDocValues docValues = r.getContext().reader()
                    .getNumericDocValues(entry.getKey());
                int docId;
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docValues.advanceExact(docId)) {
                    long value = docValues.longValue();
                    if (!facetDataSubList.containsKey(value)) {
                      List<Integer> facetDataSubListItem = new ArrayList<>();
                      facetDataSubListItem.add(docId + lrc.docBase);
                      facetDataSubList.put(value, facetDataSubListItem);
                    } else {
                      facetDataSubList.get(value).add(docId + lrc.docBase);
                    }
                  }
                }
              
              } else if (fi.getDocValuesType().equals(DocValuesType.SORTED_NUMERIC)) {
                SortedNumericDocValues docValues = r.getContext().reader()
                    .getSortedNumericDocValues(entry.getKey());
                int docId;
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docValues.advanceExact(docId)) {
                    int n = docValues.docValueCount();
                    for(int i =0; i<n; i++) {
                      long value = docValues.nextValue();
                      if (!facetDataSubList.containsKey(value)) {
                        List<Integer> facetDataSubListItem = new ArrayList<>();
                        facetDataSubListItem.add(docId + lrc.docBase);
                        facetDataSubList.put(value, facetDataSubListItem);
                      } else {
                        facetDataSubList.get(value).add(docId + lrc.docBase);
                      }  
                    }                    
                  }
                }
             
              } else if (fi.getDocValuesType().equals(DocValuesType.SORTED_SET)) {
                SortedSetDocValues docValues = r.getContext().reader()
                    .getSortedSetDocValues(entry.getKey());
                int docId;
                Map<Long, String> dictionary = new HashMap<>();
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docValues.advanceExact(docId)) {
                    long tmpValue;
                    String value;
                    while((tmpValue=docValues.nextOrd()) != SortedSetDocValues.NO_MORE_ORDS) {
                      if(!dictionary.containsKey(tmpValue)) {
                        value = docValues.lookupOrd(tmpValue).utf8ToString();
                        dictionary.put(tmpValue, value);
                      } else {
                        value = dictionary.get(tmpValue);
                      }
                      if (!facetDataSubList.containsKey(value)) {
                        List<Integer> facetDataSubListItem = new ArrayList<>();
                        facetDataSubListItem.add(docId + lrc.docBase);
                        facetDataSubList.put(value, facetDataSubListItem);
                      } else {
                        facetDataSubList.get(value).add(docId + lrc.docBase);
                      }
                    }
                  }
                }
              
              } else if (fi.getDocValuesType().equals(DocValuesType.SORTED)) {
                SortedDocValues docValues = r.getContext().reader()
                    .getSortedDocValues(entry.getKey());
                int docId;
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docValues.advanceExact(docId)) {
                    String value = docValues.binaryValue().utf8ToString();
                    if (!facetDataSubList.containsKey(value)) {
                      List<Integer> facetDataSubListItem = new ArrayList<>();
                      facetDataSubListItem.add(docId + lrc.docBase);
                      facetDataSubList.put(value, facetDataSubListItem);
                    } else {
                      facetDataSubList.get(value).add(docId + lrc.docBase);
                    }
                  }
                }
              }
              if (!facetDataSubList.isEmpty()) {
                SortedMap<String, int[]> facetDataList = entry.getValue();
                SimpleDateFormat sdf = new SimpleDateFormat(
                    "yyyy-MM-dd'T'HH:mm:ss'Z'");
                sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
                for (Entry<Object, List<Integer>> facetEntry : facetDataSubList
                    .entrySet()) {
                  int[] docIdList = facetEntry.getValue().stream()
                      .mapToInt(i -> i).toArray();
                  String termValue;
                  if (facetDataType.get(entry.getKey())
                      .equals(NumberType.DATE.name())) {
                    Date date = new Date((Long) facetEntry.getKey());
                    termValue = sdf.format(date);
                  } else {
                    termValue = facetEntry.getKey().toString();
                  }
                  if (!facetDataList.containsKey(termValue)) {
                    facetDataList.put(termValue, docIdList);
                  } else {
                    int[] oldList = facetDataList.get(termValue);
                    int[] newList = new int[oldList.length + docIdList.length];
                    System.arraycopy(oldList, 0, newList, 0, oldList.length);
                    System.arraycopy(docIdList, 0, newList, oldList.length,
                        docIdList.length);
                    facetDataList.put(termValue, newList);
                  }
                }
              }
            } else {
              throw new IOException("facets for docValues of type "
                  + fi.getDocValuesType() + " not implemented");
            }
          } else if (!docSet.isEmpty()) {
            if (facetDataType.get(entry.getKey())
                .equals(ComponentFacet.TYPE_POINTFIELD_WITHOUT_DOCVALUES)) {
              throw new IOException(
                  "can't create facets for pointField without docValues");
            }
            Terms fft = r.terms(entry.getKey());
            if (fft != null) {
              TermsEnum termsEnum = fft.iterator();
              BytesRef term = null;
              PostingsEnum postingsEnum = null;
              SortedMap<String, int[]> facetDataList = entry.getValue();
              while ((term = termsEnum.next()) != null) {
                int docId;
                int termDocId = -1;
                int[] facetDataSublist = new int[docSet.size()];
                int facetDataSublistCounter = 0;
                Iterator<Integer> docIterator = docSet.iterator();
                postingsEnum = termsEnum.postings(postingsEnum);
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docId >= termDocId
                      && ((docId == termDocId) || ((termDocId = postingsEnum
                          .advance(docId)) == docId))) {
                    facetDataSublist[facetDataSublistCounter] = docId
                        + lrc.docBase;
                    facetDataSublistCounter++;
                  }
                }
                if (facetDataSublistCounter > 0) {
                  String termValue = null;
                  if (facetDataType.get(entry.getKey())
                      .equals(NumberType.INTEGER.name())) {
                    
                    if (term.bytes[term.offset] == LegacyNumericUtils.SHIFT_START_INT) {
                      termValue = Integer
                          .toString(LegacyNumericUtils.prefixCodedToInt(term));
                    } else {
                      continue;
                    }
                  } else if (facetDataType.get(entry.getKey())
                      .equals(NumberType.LONG.name())) {
                    if (term.bytes[term.offset] == LegacyNumericUtils.SHIFT_START_LONG) {
                      termValue = Long
                          .toString(LegacyNumericUtils.prefixCodedToLong(term));
                    } else {
                      continue;
                    }
                  } else {
                    termValue = term.utf8ToString();
                  }
                  if (!facetDataList.containsKey(termValue)) {
                    facetDataList.put(termValue, Arrays.copyOf(facetDataSublist,
                        facetDataSublistCounter));
                  } else {
                    int[] oldList = facetDataList.get(termValue);
                    int[] newList = new int[oldList.length
                        + facetDataSublistCounter];
                    System.arraycopy(oldList, 0, newList, 0, oldList.length);
                    System.arraycopy(facetDataSublist, 0, newList,
                        oldList.length, facetDataSublistCounter);
                    facetDataList.put(termValue, newList);
                  }
                }
              }
            }
          }
        }
      }

      
      for (MtasSpanQuery sq : fieldInfo.spanQueryList) {
        
        if (spansNumberData.containsKey(sq)) {
          numberData = spansNumberData.get(sq);
        } else {
          numberData = null;
        }
        
        if (spansMatchData.containsKey(sq)) {
          matchData = spansMatchData.get(sq);
        } else {
          matchData = null;
        }
        boolean doNormalCollection = true;
        
        if ((numberData != null) && (matchData == null)) {
          if (sq.isMatchAllPositionsQuery()) {
            spansNumberByPositions.add(sq);
            needPositions = true;
            doNormalCollection = false;
          }
        }
        
        if (doNormalCollection
            && ((numberData != null) || (matchData != null))) {
          Spans spans = spansQueryWeight.get(sq).getSpans(lrc,
              SpanWeight.Postings.POSITIONS);
          if (spans != null) {
            Iterator<Integer> it;
            if (docSet != null) {
              it = docSet.iterator();
            } else {
              it = docList.iterator();
            }
            if (it.hasNext()) {
              int docId = it.next();
              int number;
              ArrayList<Match> matchDataList;
              Integer spansDocId = null;
              while (docId != DocIdSetIterator.NO_MORE_DOCS) {
                if (spans.advance(
                    (docId - lrc.docBase)) == DocIdSetIterator.NO_MORE_DOCS) {
                  break;
                }
                spansDocId = spans.docID() + lrc.docBase;
                while ((docId < spansDocId) && it.hasNext()) {
                  docId = it.next();
                }
                if (docId < spansDocId) {
                  break;
                }
                if (spansDocId.equals(docId)) {
                  number = 0;
                  matchDataList = new ArrayList<>();
                  int tmpStartPosition;
                  while ((tmpStartPosition = spans
                      .nextStartPosition()) != Spans.NO_MORE_POSITIONS) {
                    number++;
                    if (matchData != null) {
                      Match m = new Match(tmpStartPosition,
                          spans.endPosition());
                      matchDataList.add(m);
                    }
                  }
                  if ((numberData != null)) {
                    numberData.put(spansDocId, number);
                  }
                  if ((matchData != null)) {
                    matchData.put(spansDocId, matchDataList);
                  }
                  if (it.hasNext()) {
                    docId = it.next();
                  } else {
                    break;
                  }
                }
              }
            }
          }
        }
      }
    }

    
    if (needPositions) {
      if (mtasCodecInfo != null) {
        
        if (docSet.size() < Math.log(r.maxDoc())) {
          positionsData = new HashMap<>();
          for (int docId : docSet) {
            positionsData.put(docId, mtasCodecInfo.getNumberOfPositions(field,
                (docId - lrc.docBase)));
          }
          
        } else {
          positionsData = mtasCodecInfo.getAllNumberOfPositions(field,
              lrc.docBase);
          for (int docId : docSet) {
            if (!positionsData.containsKey(docId)) {
              positionsData.put(docId, 0);
            }
          }
        }
      } else {
        positionsData = new HashMap<>();
        for (int docId : docSet) {
          positionsData.put(docId, 0);
        }
      }
      if (spansNumberByPositions != null && spansNumberData != null) {        
        for (MtasSpanQuery sq : spansNumberByPositions) {
          Map<Integer,Integer> numberData = spansNumberData.get(sq);
          positionsData.forEach((k,v) -> numberData.put(k,v!=null?v:0));          
        }
      }
    }

    
    if (needTokens) {
      if (mtasCodecInfo != null) {
        
        if (docSet.size() < Math.log(r.maxDoc())) {
          tokensData = new HashMap<>();
          for (int docId : docSet) {
            tokensData.put(docId,
                mtasCodecInfo.getNumberOfTokens(field, (docId - lrc.docBase)));
          }
          
        } else {
          tokensData = mtasCodecInfo.getAllNumberOfTokens(field, lrc.docBase);
          for (int docId : docSet) {
            if (!tokensData.containsKey(docId)) {
              tokensData.put(docId, 0);
            }
          }
        }
      } else {
        tokensData = new HashMap<>();
        for (int docId : docSet) {
          tokensData.put(docId, 0);
        }
      }
    }

    if (!fieldInfo.statsPositionList.isEmpty()) {
      
      createPositions(fieldInfo.statsPositionList, positionsData, docSet);
    }

    if (!fieldInfo.statsTokenList.isEmpty()) {
      
      createTokens(fieldInfo.statsTokenList, tokensData, docSet);
    }

    if (!fieldInfo.documentList.isEmpty()) {
      
      createDocument(fieldInfo.documentList, docList, fieldInfo.uniqueKeyField,
          searcher, t, lrc);
    }
    if (!fieldInfo.spanQueryList.isEmpty()) {
      if (!fieldInfo.statsSpanList.isEmpty()) {
        
        createStats(fieldInfo.statsSpanList, positionsData, spansNumberData,
            docSet.toArray(new Integer[docSet.size()]));
      }
      if (!fieldInfo.listList.isEmpty()) {
        
        createList(fieldInfo.listList, spansNumberData, spansMatchData, docSet,
            field, lrc.docBase, fieldInfo.uniqueKeyField, mtasCodecInfo,
            searcher);
      }
      if (!fieldInfo.groupList.isEmpty()) {
        
        createGroup(fieldInfo.groupList, spansMatchData, docSet,
            fieldInfos.fieldInfo(field), field, lrc.docBase, mtasCodecInfo,
            searcher, lrc, status);
      }
      if (!fieldInfo.kwicList.isEmpty()) {
        
        createKwic(fieldInfo.kwicList, spansMatchData, docList, field,
            lrc.docBase, fieldInfo.uniqueKeyField, mtasCodecInfo, searcher);
      }
      if (!fieldInfo.facetList.isEmpty()) {
        
        createFacet(fieldInfo.facetList, positionsData, spansNumberData,
            facetData, docSet);
      }
    }
    if (!fieldInfo.termVectorList.isEmpty()) {
      createTermvectorFull(fieldInfo.termVectorList, positionsData, docSet, t,
          r, lrc);
      createTermvectorFirstRound(fieldInfo.termVectorList, positionsData,
          docSet, t, r, lrc);
    }
  }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: CodecCollector.collectSpansPositionsAndTokens ===");

    String field = "content";

    
    LeafReader r = new LeafReader();
    LeafReaderContext lrc = new LeafReaderContext(0, r);
    r.ctx = lrc;
    r.maxDocValue = 5;

    
    CodecInfo codecInfo = new CodecInfo();
    codecInfo.positionsByLocalDoc.put(0, 12);
    codecInfo.positionsByLocalDoc.put(1, 7);
    codecInfo.positionsByLocalDoc.put(2, 20);
    codecInfo.tokensByLocalDoc.put(0, 12);
    codecInfo.tokensByLocalDoc.put(1, 7);
    codecInfo.tokensByLocalDoc.put(2, 20);

    
    MtasSpanQuery quickQuery = new MtasSpanQuery() {
      @Override
      boolean isMatchAllPositionsQuery() {
        return false;
      }

      @Override
      public String toString() {
        return "quick";
      }
    };
    Map<Integer, int[][]> hits = new HashMap<>();
    hits.put(0, new int[][] { { 1, 2 }, { 4, 5 } });
    hits.put(2, new int[][] { { 0, 1 } });
    SpanWeight quickWeight = new SpanWeight(hits);

    Map<MtasSpanQuery, SpanWeight> spansQueryWeight = new HashMap<>();
    spansQueryWeight.put(quickQuery, quickWeight);

    
    ComponentField fieldInfo = new ComponentField();
    fieldInfo.spanQueryList.add(quickQuery);

    ComponentList cl = new ComponentList();
    cl.spanQuery = quickQuery;
    cl.number = 10; 
    cl.position = 0;
    cl.start = 0;
    fieldInfo.listList.add(cl);

    
    fieldInfo.statsPositionList.add(new Object());
    fieldInfo.statsTokenList.add(new Object());

    FieldInfos fieldInfos = new FieldInfos(new HashMap<>());
    List<Integer> docSet = Arrays.asList(0, 1, 2);
    List<Integer> docList = Arrays.asList(0, 1, 2);
    Terms t = null;
    Status status = new Status();

    System.out.println("\n-- Scenario A: list + position/token stats requested for field '"
        + field + "', docSet=" + docSet + " --");

    java.lang.reflect.Method target = method_1_mtas_claude.class.getDeclaredMethod(
        "collectSpansPositionsAndTokens", Map.class, IndexSearcher.class, CodecInfo.class,
        LeafReader.class, LeafReaderContext.class, String.class, Terms.class, List.class,
        List.class, ComponentField.class, FieldInfos.class, Status.class);
    target.setAccessible(true);
    target.invoke(null, spansQueryWeight, null, codecInfo, r, lrc, field, t, docSet, docList,
        fieldInfo, fieldInfos, status);

    
    System.out.println("\n-- Scenario B: facet on field 'category' via inverted-index terms (no DocValues) --");
    Map<String, Set<Integer>> categoryPostings = new LinkedHashMap<>();
    categoryPostings.put("fiction", new HashSet<>(Arrays.asList(0, 2)));
    categoryPostings.put("nonfiction", new HashSet<>(Arrays.asList(1)));
    r.terms.put("category", new Terms(categoryPostings));

    ComponentField fieldInfoFacet = new ComponentField();
    fieldInfoFacet.spanQueryList.add(quickQuery);
    ComponentFacet facet = new ComponentFacet();
    facet.baseFields = new String[] { "category" };
    facet.baseFieldTypes = new String[] { NumberType.STRING.name() };
    
    
    
    BaseParser oneArgParser = new BaseParser() {
      @Override
      public boolean needPositions() {
        return false;
      }

      @Override
      public int needArgumentsNumber() {
        return 1;
      }

      @Override
      public HashSet<Integer> needArgument() {
        HashSet<Integer> args = new HashSet<>();
        args.add(0);
        return args;
      }
    };
    facet.baseParsers = new BaseParser[] { oneArgParser };
    facet.spanQueries = new MtasSpanQuery[] { quickQuery };
    @SuppressWarnings("unchecked")
    List<MtasFunctionParserFunction>[] funcLists = new List[] { new ArrayList<MtasFunctionParserFunction>() };
    facet.baseFunctionParserFunctions = funcLists;
    fieldInfoFacet.facetList.add(facet);

    target.invoke(null, spansQueryWeight, null, codecInfo, r, lrc, field, t, docSet, docList,
        fieldInfoFacet, fieldInfos, status);

    System.out.println("\n=== Demo complete: method exercised needSpans/list-match collection, "
        + "needPositions/needTokens stat collection, and facet-by-inverted-terms branches. ===");
  }
}
