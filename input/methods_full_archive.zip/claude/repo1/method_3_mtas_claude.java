






























import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class method_3_mtas_claude {

  
  
  
  
  
  static class NamedList<T> {
    private final List<Entry<String, T>> entries = new ArrayList<>();

    public void add(String name, T val) {
      entries.add(new java.util.AbstractMap.SimpleEntry<>(name, val));
    }

    @SuppressWarnings("unchecked")
    public T get(String name) {
      for (Entry<String, T> e : entries) {
        if (e.getKey() == null ? name == null : e.getKey().equals(name)) {
          return e.getValue();
        }
      }
      return null;
    }

    public void clear() {
      entries.clear();
    }

    public boolean isEmpty() {
      return entries.isEmpty();
    }

    
    
    @SuppressWarnings("unchecked")
    public Object findRecursive(Object... path) {
      Object current = this;
      for (Object key : path) {
        if (!(current instanceof NamedList)) {
          return null;
        }
        current = ((NamedList<Object>) current).get((String) key);
      }
      return current;
    }
  }

  
  
  
  static class ModifiableSolrParams {
    final Map<String, List<String>> map = new LinkedHashMap<>();

    public void add(String name, String... vals) {
      if (name == null || vals == null) {
        return;
      }
      List<String> list = map.computeIfAbsent(name, k -> new ArrayList<>());
      for (String v : vals) {
        if (v != null) {
          list.add(v);
        }
      }
    }

    public boolean getBool(String name, boolean def) {
      List<String> list = map.get(name);
      if (list == null || list.isEmpty()) {
        return def;
      }
      return Boolean.parseBoolean(list.get(0));
    }

    public String[] getParams(String name) {
      List<String> list = map.get(name);
      return list == null ? null : list.toArray(new String[0]);
    }

    public Set<String> getParameterNames() {
      return map.keySet();
    }
  }

  static class CommonParams {
    static final String FQ = "fq";
    static final String Q = "q";
    static final String CACHE = "cache";
    static final String ROWS = "rows";
  }

  
  
  
  
  static class SolrResponse {
    private NamedList<Object> response = new NamedList<>();

    public NamedList<Object> getResponse() {
      return response;
    }

    public void setResponse(NamedList<Object> response) {
      this.response = response;
    }
  }

  static class ShardResponse {
    private final String shardAddress;
    private final SolrResponse solrResponse;

    ShardResponse(String shardAddress, SolrResponse solrResponse) {
      this.shardAddress = shardAddress;
      this.solrResponse = solrResponse;
    }

    public String getShardAddress() {
      return shardAddress;
    }

    public SolrResponse getSolrResponse() {
      return solrResponse;
    }
  }

  static class ShardRequest {
    static final int PURPOSE_PRIVATE = 0x80000;
    String[] shards;
    int purpose;
    ModifiableSolrParams params;
    List<ShardResponse> responses = new ArrayList<>();
  }

  static class SolrQueryRequest {
    private final ModifiableSolrParams params;
    private final ModifiableSolrParams originalParams;

    SolrQueryRequest(ModifiableSolrParams params, ModifiableSolrParams originalParams) {
      this.params = params;
      this.originalParams = originalParams;
    }

    public ModifiableSolrParams getParams() {
      return params;
    }

    public ModifiableSolrParams getOriginalParams() {
      return originalParams;
    }
  }

  static class SearchComponent {
  }

  static class ResponseBuilder {
    List<ShardRequest> finished = new ArrayList<>();
    List<ShardRequest> added = new ArrayList<>();
    SolrQueryRequest req;

    public void addRequest(SearchComponent me, ShardRequest sreq) {
      added.add(sreq);
    }
  }

  
  
  
  static class CodecUtil {
    static final String SORT_TERM = "term";
    static final String SORT_ASC = "asc";
    static final String SORT_DESC = "desc";
  }

  
  
  
  
  static class SubComponentFunction {
    String sortType;
    String sortDirection;
    String type;
    String expression;
    String key;

    SubComponentFunction(String sortType, String sortDirection) {
      this.sortType = sortType;
      this.sortDirection = sortDirection;
    }
  }

  static class SubComponentDistance {
    String type;
    String base;
    String key;
    Double minimum;
    Double maximum;
    Map<String, String> parameters;
  }

  static class ComponentTermVector {
    String key;
    String prefix;
    String regexp;
    int number;
    SubComponentFunction subComponentFunction;
    List<SubComponentDistance> distances;
    List<SubComponentFunction> functions;

    ComponentTermVector(String key, int number, SubComponentFunction f) {
      this.key = key;
      this.number = number;
      this.subComponentFunction = f;
      this.prefix = "pref_" + key;
    }
  }

  static class ComponentField {
    List<ComponentTermVector> termVectorList = new ArrayList<>();
  }

  static class ComponentFields {
    Map<String, ComponentField> list = new LinkedHashMap<>();
  }

  
  
  
  
  
  static class MtasDataItemNumberComparator {
    private double value;

    MtasDataItemNumberComparator(double value) {
      this.value = value;
    }

    double getValue() {
      return value;
    }

    int compareTo(double other) {
      return Double.compare(this.value, other);
    }

    void add(double v) {
      this.value += v;
    }

    void subtract(double v) {
      this.value -= v;
    }

    @Override
    public MtasDataItemNumberComparator clone() {
      return new MtasDataItemNumberComparator(this.value);
    }

    
    
    
    MtasDataItemNumberComparator recomputeBoundary(int numberOfShards) {
      if (numberOfShards <= 0) {
        return this.clone();
      }
      return new MtasDataItemNumberComparator(this.value / numberOfShards);
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  static class MtasResultWrapper {
    private final MtasDataItemNumberComparator lastSortValue;
    private final Map<String, MtasDataItemNumberComparator> comparatorList;

    MtasResultWrapper(MtasDataItemNumberComparator lastSortValue,
        Map<String, MtasDataItemNumberComparator> comparatorList) {
      this.lastSortValue = lastSortValue;
      this.comparatorList = comparatorList;
    }

    MtasDataItemNumberComparator getLastSortValue() {
      return lastSortValue;
    }

    Map<String, MtasDataItemNumberComparator> getComparatorList() {
      return comparatorList;
    }
  }

  static class MtasSolrMtasResult {
    private final MtasResultWrapper result;

    MtasSolrMtasResult(MtasResultWrapper result) {
      this.result = result;
    }

    MtasResultWrapper getResult() {
      return result;
    }
  }

  static class MtasSolrSearchComponent {
    static final String PARAM_MTAS = "mtas";
  }

  
  
  
  
  static final String PARAM_MTAS_TERMVECTOR = "mtas.tv";
  static final String NAME = "termvector";

  static final String NAME_MTAS_TERMVECTOR_BOUNDARY = "boundary";
  static final String NAME_MTAS_TERMVECTOR_FIELD = "field";
  static final String NAME_MTAS_TERMVECTOR_PREFIX = "prefix";
  static final String NAME_MTAS_TERMVECTOR_KEY = "key";
  static final String NAME_MTAS_TERMVECTOR_NUMBER = "number";
  static final String NAME_MTAS_TERMVECTOR_SORT_TYPE = "sort.type";
  static final String NAME_MTAS_TERMVECTOR_SORT_DIRECTION = "sort.direction";
  static final String NAME_MTAS_TERMVECTOR_TYPE = "type";
  static final String NAME_MTAS_TERMVECTOR_DISTANCE = "distance";
  static final String NAME_MTAS_TERMVECTOR_DISTANCE_TYPE = "type";
  static final String NAME_MTAS_TERMVECTOR_DISTANCE_BASE = "base";
  static final String NAME_MTAS_TERMVECTOR_DISTANCE_KEY = "key";
  static final String NAME_MTAS_TERMVECTOR_DISTANCE_MINIMUM = "minimum";
  static final String NAME_MTAS_TERMVECTOR_DISTANCE_MAXIMUM = "maximum";
  static final String NAME_MTAS_TERMVECTOR_DISTANCE_PARAMETER = "parameter";
  static final String NAME_MTAS_TERMVECTOR_FUNCTION = "function";
  static final String NAME_MTAS_TERMVECTOR_FUNCTION_EXPRESSION = "expression";
  static final String NAME_MTAS_TERMVECTOR_FUNCTION_KEY = "key";
  static final String NAME_MTAS_TERMVECTOR_FUNCTION_TYPE = "type";
  static final String NAME_MTAS_TERMVECTOR_REGEXP = "regexp";

  
  
  
  static class Log {
    void debug(Object o) {
      System.out.println("[DEBUG] " + o);
    }
  }

  final Log log = new Log();
  final SearchComponent searchComponent = new SearchComponent();

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  @SuppressWarnings("unchecked")
  private void distributedProcessMissingTop(ResponseBuilder rb,
      ComponentFields mtasFields) throws IOException {
    
    Map<String, SortedMap<String, MtasDataItemNumberComparator>> mergedComparatorLists = new HashMap<>();
    Map<String, MtasDataItemNumberComparator> mergedComparatorBoundaryList = new HashMap<>();
    Map<String, MtasDataItemNumberComparator> summedComparatorBoundaryList = new HashMap<>();
    Map<String, Map<String, MtasDataItemNumberComparator>> comparatorBoundariesList = new HashMap<>();
    
    for (String field : mtasFields.list.keySet()) {
      List<ComponentTermVector> tvList = mtasFields.list
          .get(field).termVectorList;
      if (tvList != null) {
        for (ComponentTermVector tv : tvList) {
          if (!tv.subComponentFunction.sortType.equals(CodecUtil.SORT_TERM)) {
            mergedComparatorLists.put(tv.key,
                new TreeMap<String, MtasDataItemNumberComparator>());
          }
        }
      }
    }
    
    
    for (ShardRequest sreq : rb.finished) {
      if (sreq.params.getBool(MtasSolrSearchComponent.PARAM_MTAS, false)
          && sreq.params.getBool(PARAM_MTAS_TERMVECTOR, false)) {
        for (ShardResponse shardResponse : sreq.responses) {
          SortedMap<String, MtasDataItemNumberComparator> mergedComparatorList;
          NamedList<Object> response = shardResponse.getSolrResponse()
              .getResponse();
          String key;
          MtasSolrMtasResult list;
          MtasDataItemNumberComparator comparatorLast;
          Map<String, MtasDataItemNumberComparator> comparatorList;
          try {
            List<NamedList<Object>> data = (List<NamedList<Object>>) response
                .findRecursive("mtas", NAME);
            if (data != null) {
              for (int i = 0; i < data.size(); i++) {
                NamedList<Object> dataItem = data.get(i);
                try {
                  key = (String) dataItem.get("key");
                  list = (MtasSolrMtasResult) dataItem.get("list");
                  if (list != null) {
                    comparatorLast = list.getResult().getLastSortValue();
                    comparatorList = list.getResult().getComparatorList();
                    if (key == null) {
                      dataItem.clear();
                    } else if (comparatorLast == null || comparatorList == null
                        || !mergedComparatorLists.containsKey(key)) {
                      
                    } else {
                      mergedComparatorList = mergedComparatorLists.get(key);
                      for (Entry<String, MtasDataItemNumberComparator> entry : comparatorList
                          .entrySet()) {
                        if (mergedComparatorList.containsKey(entry.getKey())) {
                          mergedComparatorList.get(entry.getKey())
                              .add(entry.getValue().getValue());
                        } else {
                          mergedComparatorList.put(entry.getKey(),
                              entry.getValue().clone());
                        }
                      }
                      if (!comparatorBoundariesList.containsKey(key)) {
                        comparatorBoundariesList.put(key,
                            new HashMap<String, MtasDataItemNumberComparator>());
                      }
                      comparatorBoundariesList.get(key)
                          .put(shardResponse.getShardAddress(), comparatorLast);
                      if (summedComparatorBoundaryList.containsKey(key)) {
                        summedComparatorBoundaryList.get(key)
                            .add(comparatorLast.getValue());
                      } else {
                        summedComparatorBoundaryList.put(key,
                            comparatorLast.clone());
                      }
                    }
                  } else {
                    throw new IOException("no data returned");
                  }
                } catch (ClassCastException e) {
                  log.debug(e);
                  dataItem.clear();
                }
              }
            }
          } catch (ClassCastException e) {
            log.debug(e);
            
          }
          shardResponse.getSolrResponse().setResponse(response);
        }
      }
    }
    
    HashMap<String, HashMap<String, HashMap<String, MtasDataItemNumberComparator>>> recomputeFieldList = new HashMap<>();
    for (String field : mtasFields.list.keySet()) {
      List<ComponentTermVector> tvList = mtasFields.list
          .get(field).termVectorList;
      if (tvList != null) {
        for (ComponentTermVector tv : tvList) {
          SortedMap<String, MtasDataItemNumberComparator> mergedComparatorList;
          if (mergedComparatorLists.containsKey(tv.key)) {
            mergedComparatorList = mergedComparatorLists.get(tv.key);
            if (mergedComparatorList.size() < tv.number || tv.number <= 0) {
              
            } else {
              final int sortDirection = tv.subComponentFunction.sortDirection
                  .equals(CodecUtil.SORT_DESC) ? -1 : 1;
              SortedSet<Map.Entry<String, MtasDataItemNumberComparator>> sortedSet = new TreeSet<>(
                  (Map.Entry<String, MtasDataItemNumberComparator> e1,
                      Map.Entry<String, MtasDataItemNumberComparator> e2) -> (e1
                          .getValue().compareTo(e2.getValue().getValue()) == 0)
                              ? e1.getKey().compareTo(e2.getKey())
                              : e1.getValue().compareTo(
                                  e2.getValue().getValue()) * sortDirection);
              sortedSet.addAll(mergedComparatorLists.get(tv.key).entrySet());
              Optional<Map.Entry<String, MtasDataItemNumberComparator>> optionalItem = sortedSet
                  .stream().skip(tv.number - 1L).findFirst();
              if (optionalItem.isPresent()) {
                mergedComparatorBoundaryList.put(tv.key,
                    optionalItem.get().getValue());
              }
            }
          }
        }
      }
      HashMap<String, HashMap<String, MtasDataItemNumberComparator>> recomputeList = new HashMap<>();
      if (tvList != null) {
        for (ComponentTermVector tv : tvList) {
          String key = tv.key;
          if (mergedComparatorBoundaryList.containsKey(key)
              && summedComparatorBoundaryList.containsKey(key)) {
            
            recomputeList.put(key,
                new HashMap<String, MtasDataItemNumberComparator>());
            
            List<Entry<String, MtasDataItemNumberComparator>> list = new LinkedList<>(
                comparatorBoundariesList.get(key).entrySet());
            Collections.sort(list,
                (Entry<String, MtasDataItemNumberComparator> e1,
                    Entry<String, MtasDataItemNumberComparator> e2) -> e1
                        .getValue().compareTo(e2.getValue().getValue()));
            HashMap<String, MtasDataItemNumberComparator> sortedHashMap = new LinkedHashMap<>();
            for (Iterator<Map.Entry<String, MtasDataItemNumberComparator>> it = list
                .iterator(); it.hasNext();) {
              Map.Entry<String, MtasDataItemNumberComparator> entry = it.next();
              sortedHashMap.put(entry.getKey(), entry.getValue());
            }

            MtasDataItemNumberComparator mainNewBoundary = mergedComparatorBoundaryList
                .get(key).recomputeBoundary(sortedHashMap.size());
            
            

            MtasDataItemNumberComparator sum = null;
            int number = 0;
            for (Entry<String, MtasDataItemNumberComparator> entry : sortedHashMap
                .entrySet()) {
              MtasDataItemNumberComparator newBoundary = mainNewBoundary
                  .clone();
              MtasDataItemNumberComparator currentBoundary = entry.getValue();
              int compare = currentBoundary.compareTo(newBoundary.getValue());
              if (tv.subComponentFunction.sortDirection
                  .equals(CodecUtil.SORT_DESC)) {
                compare *= -1;
              }
              if (compare < 0) {
                HashMap<String, MtasDataItemNumberComparator> recomputeSubList = new HashMap<>();
                
                if (number > 0 && sum != null
                    && tv.subComponentFunction.sortDirection
                        .equals(CodecUtil.SORT_DESC)) {
                  MtasDataItemNumberComparator tmpSumBoundary = mergedComparatorBoundaryList
                      .get(key);
                  tmpSumBoundary.subtract(sum.getValue());
                  MtasDataItemNumberComparator alternativeNewBoundary = tmpSumBoundary
                      .recomputeBoundary(sortedHashMap.size() - number);
                  compare = newBoundary
                      .compareTo(alternativeNewBoundary.getValue());
                  if (compare < 0) {
                    newBoundary = alternativeNewBoundary;
                    compare = currentBoundary.compareTo(newBoundary.getValue());
                    if (tv.subComponentFunction.sortDirection
                        .equals(CodecUtil.SORT_DESC)) {
                      compare *= -1;
                    }
                    if (compare < 0) {
                      recomputeSubList.put(entry.getKey(), newBoundary);
                    }
                  } else {
                    recomputeSubList.put(entry.getKey(), newBoundary);
                  }
                } else {
                  recomputeSubList.put(entry.getKey(), newBoundary);
                }
                if (!recomputeSubList.isEmpty()) {
                  if (!recomputeList.containsKey(key)) {
                    recomputeList.put(key, recomputeSubList);
                  } else {
                    recomputeList.get(key).putAll(recomputeSubList);
                  }
                }
              } else {
                newBoundary = currentBoundary.clone();
              }
              if (sum == null) {
                sum = newBoundary.clone();
              } else {
                sum.add(newBoundary.getValue());
              }
              number++;
            }
          }
        }
      }
      if (!recomputeList.isEmpty()) {
        recomputeFieldList.put(field, recomputeList);
      }
    }

    
    if (recomputeFieldList.size() > 0) {

      
      HashSet<String> shards = new HashSet<>();
      for (ShardRequest sreq : rb.finished) {
        if (sreq.params.getBool(MtasSolrSearchComponent.PARAM_MTAS, false)
            && sreq.params.getBool(PARAM_MTAS_TERMVECTOR, false)) {
          for (ShardResponse shardResponse : sreq.responses) {
            NamedList<Object> response = shardResponse.getSolrResponse()
                .getResponse();
            String key;
            String field;
            String shardAddress = shardResponse.getShardAddress();
            try {
              ArrayList<NamedList<Object>> data = (ArrayList<NamedList<Object>>) response
                  .findRecursive("mtas", NAME);
              shards.add(shardAddress);
              if (data != null) {
                for (int i = 0; i < data.size(); i++) {
                  NamedList<Object> dataItem = data.get(i);
                  try {
                    key = (String) dataItem.get("key");
                    field = (String) dataItem.get("field");
                    boolean doClear;
                    doClear = field != null && key != null;
                    doClear = doClear ? recomputeFieldList.get(field) != null
                        : false;
                    doClear = doClear
                        ? recomputeFieldList.get(field).containsKey(key)
                        : false;
                    doClear = doClear ? recomputeFieldList.get(field).get(key)
                        .containsKey(shardAddress) : false;
                    if (doClear) {
                      dataItem.clear();
                      dataItem.add("key", key);
                    }
                  } catch (ClassCastException e) {
                    log.debug(e);
                    dataItem.clear();
                  }
                }
              }
            } catch (ClassCastException e) {
              log.debug(e);
              
            }
            shardResponse.getSolrResponse().setResponse(response);
          }
        }
      }

      
      HashMap<String, ModifiableSolrParams> requestParamList = new HashMap<>();
      for (String shardAddress : shards) {
        ModifiableSolrParams paramsNewRequest = new ModifiableSolrParams();
        int termvectorCounter = 0;
        for (String field : mtasFields.list.keySet()) {
          List<ComponentTermVector> tvList = mtasFields.list
              .get(field).termVectorList;
          if (recomputeFieldList.containsKey(field)) {
            HashMap<String, HashMap<String, MtasDataItemNumberComparator>> recomputeList = recomputeFieldList
                .get(field);
            if (tvList != null) {
              for (ComponentTermVector tv : tvList) {
                if (recomputeList.containsKey(tv.key)
                    && recomputeList.get(tv.key).containsKey(shardAddress)) {
                  paramsNewRequest.add(
                      PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                          + NAME_MTAS_TERMVECTOR_BOUNDARY,
                      String.valueOf(recomputeList.get(tv.key).get(shardAddress)
                          .getValue()));
                  paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                      + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_FIELD,
                      field);
                  paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                      + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_PREFIX,
                      tv.prefix);
                  paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                      + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_KEY,
                      tv.key);
                  paramsNewRequest.add(
                      PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                          + NAME_MTAS_TERMVECTOR_NUMBER,
                      String.valueOf(tv.number));
                  if (tv.subComponentFunction.sortType != null) {
                    paramsNewRequest.add(
                        PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                            + NAME_MTAS_TERMVECTOR_SORT_TYPE,
                        tv.subComponentFunction.sortType);
                  }
                  if (tv.subComponentFunction.sortDirection != null) {
                    paramsNewRequest.add(
                        PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                            + NAME_MTAS_TERMVECTOR_SORT_DIRECTION,
                        tv.subComponentFunction.sortDirection);
                  }
                  if (tv.subComponentFunction.type != null) {
                    paramsNewRequest.add(
                        PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                            + NAME_MTAS_TERMVECTOR_TYPE,
                        tv.subComponentFunction.type);
                  }
                  if (tv.distances != null) {
                    int distanceCounter = 0;
                    for (SubComponentDistance distance : tv.distances) {
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                              + distanceCounter + "."
                              + NAME_MTAS_TERMVECTOR_DISTANCE_TYPE,
                          distance.type);
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                              + distanceCounter + "."
                              + NAME_MTAS_TERMVECTOR_DISTANCE_BASE,
                          distance.base);
                      if (distance.key != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                + distanceCounter + "."
                                + NAME_MTAS_TERMVECTOR_DISTANCE_KEY,
                            distance.key);
                      }
                      if (distance.minimum != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                + distanceCounter + "."
                                + NAME_MTAS_TERMVECTOR_DISTANCE_MINIMUM,
                            String.valueOf(distance.minimum));
                      }
                      if (distance.maximum != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                + distanceCounter + "."
                                + NAME_MTAS_TERMVECTOR_DISTANCE_MAXIMUM,
                            String.valueOf(distance.maximum));
                      }
                      if (distance.parameters != null) {
                        for (Entry<String, String> parameter : distance.parameters
                            .entrySet()) {
                          paramsNewRequest.add(
                              PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                  + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                  + distanceCounter + "."
                                  + NAME_MTAS_TERMVECTOR_DISTANCE_PARAMETER
                                  + "." + parameter.getKey(),
                              parameter.getValue());
                        }
                      }
                      distanceCounter++;
                    }
                  }
                  if (tv.functions != null) {
                    int functionCounter = 0;
                    for (SubComponentFunction function : tv.functions) {
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                              + functionCounter + "."
                              + NAME_MTAS_TERMVECTOR_FUNCTION_EXPRESSION,
                          function.expression);
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                              + functionCounter + "."
                              + NAME_MTAS_TERMVECTOR_FUNCTION_KEY,
                          function.key);
                      if (function.type != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                + "." + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                                + functionCounter + "."
                                + NAME_MTAS_TERMVECTOR_FUNCTION_TYPE,
                            function.type);
                      }
                      functionCounter++;
                    }
                  }
                  if (tv.regexp != null) {
                    paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                        + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_REGEXP,
                        tv.regexp);
                  }
                  termvectorCounter++;
                }
              }
            }
          }
        }
        if (!paramsNewRequest.getParameterNames().isEmpty()) {
          requestParamList.put(shardAddress, paramsNewRequest);
        }
      }

      
      for (Entry<String, ModifiableSolrParams> entry : requestParamList
          .entrySet()) {
        ShardRequest sreq = new ShardRequest();
        sreq.shards = new String[] { entry.getKey() };
        sreq.purpose = ShardRequest.PURPOSE_PRIVATE;
        sreq.params = entry.getValue();
        sreq.params.add(CommonParams.FQ,
            rb.req.getParams().getParams(CommonParams.FQ));
        sreq.params.add(CommonParams.Q,
            rb.req.getParams().getParams(CommonParams.Q));
        sreq.params.add(CommonParams.CACHE,
            rb.req.getParams().getParams(CommonParams.CACHE));
        sreq.params.add(CommonParams.ROWS, "0");
        sreq.params.add(MtasSolrSearchComponent.PARAM_MTAS, rb.req
            .getOriginalParams().getParams(MtasSolrSearchComponent.PARAM_MTAS));
        sreq.params.add(PARAM_MTAS_TERMVECTOR,
            rb.req.getOriginalParams().getParams(PARAM_MTAS_TERMVECTOR));
        rb.addRequest(searchComponent, sreq);
      }
    }

  }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  
  
  private static NamedList<Object> buildShardResponse(
      List<Object[]> items ) {
    List<NamedList<Object>> dataList = new ArrayList<>();
    for (Object[] item : items) {
      NamedList<Object> dataItem = new NamedList<>();
      dataItem.add("key", item[0]);
      dataItem.add("field", item[1]);
      dataItem.add("list", item[2]);
      dataList.add(dataItem);
    }
    NamedList<Object> mtasNode = new NamedList<>();
    mtasNode.add(NAME, dataList);
    NamedList<Object> top = new NamedList<>();
    top.add("mtas", mtasNode);
    return top;
  }

  
  
  
  public static void main(String[] args) throws Exception {
    method_3_mtas_claude harness = new method_3_mtas_claude();

    System.out.println("=== Reconstruction demo: MtasSolrComponentTermvector.distributedProcessMissingTop ===");

    
    
    ComponentFields mtasFields = new ComponentFields();
    ComponentField cf = new ComponentField();
    SubComponentFunction sortDesc = new SubComponentFunction(CodecUtil.SORT_ASC, CodecUtil.SORT_DESC);
    ComponentTermVector tv = new ComponentTermVector("tv1", 2, sortDesc);
    cf.termVectorList.add(tv);
    mtasFields.list.put("title", cf);

    
    
    
    ResponseBuilder rb = new ResponseBuilder();
    ModifiableSolrParams reqParams = new ModifiableSolrParams();
    reqParams.add(MtasSolrSearchComponent.PARAM_MTAS, "true");
    reqParams.add(CommonParams.Q, "*:*");
    reqParams.add(CommonParams.FQ, "type:book");
    rb.req = new SolrQueryRequest(reqParams, reqParams);

    ShardRequest sreq = new ShardRequest();
    sreq.params = new ModifiableSolrParams();
    sreq.params.add(MtasSolrSearchComponent.PARAM_MTAS, "true");
    sreq.params.add(PARAM_MTAS_TERMVECTOR, "true");

    
    Map<String, MtasDataItemNumberComparator> shard1Comparators = new LinkedHashMap<>();
    shard1Comparators.put("alpha", new MtasDataItemNumberComparator(10));
    shard1Comparators.put("beta", new MtasDataItemNumberComparator(4));
    MtasSolrMtasResult shard1Result = new MtasSolrMtasResult(
        new MtasResultWrapper(new MtasDataItemNumberComparator(4), shard1Comparators));

    
    Map<String, MtasDataItemNumberComparator> shard2Comparators = new LinkedHashMap<>();
    shard2Comparators.put("alpha", new MtasDataItemNumberComparator(6));
    shard2Comparators.put("gamma", new MtasDataItemNumberComparator(9));
    MtasSolrMtasResult shard2Result = new MtasSolrMtasResult(
        new MtasResultWrapper(new MtasDataItemNumberComparator(6), shard2Comparators));

    
    Map<String, MtasDataItemNumberComparator> shard3Comparators = new LinkedHashMap<>();
    shard3Comparators.put("delta", new MtasDataItemNumberComparator(2));
    MtasSolrMtasResult shard3Result = new MtasSolrMtasResult(
        new MtasResultWrapper(new MtasDataItemNumberComparator(2), shard3Comparators));

    List<Object[]> shard1Items = new ArrayList<>();
    shard1Items.add(new Object[] { "tv1", "title", shard1Result });
    List<Object[]> shard2Items = new ArrayList<>();
    shard2Items.add(new Object[] { "tv1", "title", shard2Result });
    List<Object[]> shard3Items = new ArrayList<>();
    shard3Items.add(new Object[] { "tv1", "title", shard3Result });

    SolrResponse solrResponse1 = new SolrResponse();
    solrResponse1.setResponse(buildShardResponse(shard1Items));
    SolrResponse solrResponse2 = new SolrResponse();
    solrResponse2.setResponse(buildShardResponse(shard2Items));
    SolrResponse solrResponse3 = new SolrResponse();
    solrResponse3.setResponse(buildShardResponse(shard3Items));

    sreq.responses.add(new ShardResponse("shard1.example.com", solrResponse1));
    sreq.responses.add(new ShardResponse("shard2.example.com", solrResponse2));
    sreq.responses.add(new ShardResponse("shard3.example.com", solrResponse3));

    rb.finished.add(sreq);

    System.out.println("\n-- Input shard data (per-shard partial term sums) --");
    System.out.println("shard1: alpha=10, beta=4  (boundary=4)");
    System.out.println("shard2: alpha=6,  gamma=9 (boundary=6)");
    System.out.println("shard3: delta=2           (boundary=2)");
    System.out.println("Requested top " + tv.number + " terms, sort direction="
        + tv.subComponentFunction.sortDirection);

    
    java.lang.reflect.Method target = method_3_mtas_claude.class.getDeclaredMethod(
        "distributedProcessMissingTop", ResponseBuilder.class, ComponentFields.class);
    target.setAccessible(true);
    target.invoke(harness, rb, mtasFields);

    
    System.out.println("\n-- Effect: additional private ShardRequest(s) queued by the method --");
    if (rb.added.isEmpty()) {
      System.out.println("No re-fetch requests were queued (merged top-N already satisfied "
          + "from the first pass, or fewer distinct terms than requested).");
    } else {
      for (ShardRequest newReq : rb.added) {
        System.out.println("New ShardRequest -> shard(s): " + java.util.Arrays.toString(newReq.shards)
            + ", purpose=PRIVATE(" + newReq.purpose + ")");
        for (String name : newReq.params.getParameterNames()) {
          System.out.println("   " + name + " = "
              + java.util.Arrays.toString(newReq.params.getParams(name)));
        }
      }
    }

    
    System.out.println("\n-- Shard responses after distributedProcessMissingTop --");
    for (ShardResponse sr : sreq.responses) {
      NamedList<Object> resp = sr.getSolrResponse().getResponse();
      Object dataObj = resp.findRecursive("mtas", NAME);
      System.out.println(sr.getShardAddress() + " -> " + dataObj);
    }

    System.out.println("\n=== Demo complete: method exercised the merge, boundary recompute, "
        + "shard-response-clear, and new-ShardRequest-building branches. ===");
  }
}
