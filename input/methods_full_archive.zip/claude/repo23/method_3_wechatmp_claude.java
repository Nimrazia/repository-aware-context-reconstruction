














































import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class method_3_wechatmp_claude {

    public static void main(final String[] args) throws Exception {
        title("METHOD 3  |  AccessServlet.doGet(HttpServletRequest request, HttpServletResponse response)");

        final AccessServlet servlet = new AccessServlet();
        final com.sun.net.httpserver.HttpServer server =
                com.sun.net.httpserver.HttpServer.create(new java.net.InetSocketAddress("localhost", 0), 0);
        server.createContext("/access", new com.sun.net.httpserver.HttpHandler() {
            public void handle(final com.sun.net.httpserver.HttpExchange exchange) throws IOException {
                try {
                    servlet.doGet(ExchangeAdapter.request(exchange), ExchangeAdapter.response(exchange));
                } catch (final ServletException e) {
                    throw new IOException(e);
                } finally {
                    
                    
                    
                    
                    ExchangeAdapter.ensureResponded(exchange);
                }
            }
        });
        server.start();
        final int port = server.getAddress().getPort();
        try {
            final String timestamp = "1700000000";
            final String nonce = "987654321";
            final String echostr = "ECHO-STRING-42";

            section("1. a request with a valid signature - the echostr is written back");
            final String validSignature = sha1(sortedJoin("token", timestamp, nonce));
            System.out.println("      GET request : " + get(port, "/access?signature=" + validSignature
                    + "&timestamp=" + timestamp + "&nonce=" + nonce + "&echostr=" + echostr));

            section("2. a request with an invalid signature - checkSignature returns false, nothing is written");
            System.out.println("      GET request : " + get(port, "/access?signature=deadbeef"
                    + "&timestamp=" + timestamp + "&nonce=" + nonce + "&echostr=" + echostr));

            section("3. a request missing the nonce parameter - Validate.notNull throws inside buildSignatureText");
            System.out.println("      GET request : " + get(port, "/access?signature=" + validSignature
                    + "&timestamp=" + timestamp + "&echostr=" + echostr));
            System.out.println("      the doGet target method's own catch (Exception e) block absorbs the");
            System.out.println("      IllegalArgumentException from Validate.notNull and logs it; the HTTP");
            System.out.println("      response above is empty because nothing was ever written to it");

            section("4. branch coverage summary");
            System.out.println("      hasRights == true  (echostr written)         -> scenario 1");
            System.out.println("      hasRights == false (signature-not-match log) -> scenario 2");
            System.out.println("      checkSignature(...) itself throws            -> scenario 3, caught by doGet");
        } finally {
            server.stop(0);
        }

        title("END OF METHOD 3 SCENARIOS");
    }

    static String get(final int port, final String path) throws IOException {
        final java.net.URL url = new java.net.URL("http://localhost:" + port + path);
        final java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        final int code = conn.getResponseCode();
        final java.io.InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        final String body = in == null ? "" : readAll(in);
        return "HTTP " + code + ", body=\"" + body + "\"";
    }

    static String readAll(final java.io.InputStream in) throws IOException {
        final java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        final byte[] chunk = new byte[4096];
        int read;
        while ((read = in.read(chunk)) != -1) {
            buffer.write(chunk, 0, read);
        }
        in.close();
        return new String(buffer.toByteArray(), "UTF-8");
    }

    static String sortedJoin(final String... values) {
        final List<String> list = new ArrayList<String>(java.util.Arrays.asList(values));
        Collections.sort(list);
        final StringBuilder sb = new StringBuilder();
        for (final String v : list) {
            sb.append(v);
        }
        return sb.toString();
    }

    static String sha1(final String text) throws Exception {
        final java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-1");
        final byte[] bytes = digest.digest(text.getBytes("UTF-8"));
        final StringBuilder sb = new StringBuilder();
        for (final byte b : bytes) {
            sb.append(Character.forDigit((b >> 4) & 0xF, 16));
            sb.append(Character.forDigit(b & 0xF, 16));
        }
        return sb.toString();
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}







abstract class AbstractToStringBuilder {
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder(getClass().getSimpleName()).append('[');
        boolean first = true;
        for (Class<?> c = getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (final java.lang.reflect.Field f : c.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                f.setAccessible(true);
                try {
                    if (!first) {
                        sb.append(',');
                    }
                    first = false;
                    sb.append(f.getName()).append('=').append(f.get(this));
                } catch (final IllegalAccessException e) {
                    
                }
            }
        }
        return sb.append(']').toString();
    }
}






class Signature extends AbstractToStringBuilder {
    private String token;
    private String signature;
    private String timestamp;
    private String nonce;
    private String echostr;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getNonce() {
        return nonce;
    }

    public void setNonce(String nonce) {
        this.nonce = nonce;
    }

    public String getEchostr() {
        return echostr;
    }

    public void setEchostr(String echostr) {
        this.echostr = echostr;
    }
}






final class Validate {
    private Validate() {
    }

    public static <T> T notNull(final T object, final String message, final Object... values) {
        if (object == null) {
            throw new IllegalArgumentException(String.format(message, values));
        }
        return object;
    }
}

final class StringUtils {
    private StringUtils() {
    }

    public static boolean isNotEmpty(final CharSequence cs) {
        return cs != null && cs.length() > 0;
    }

    public static String join(final Iterable<?> iterable, final String separator) {
        final StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (final Object o : iterable) {
            if (!first) {
                sb.append(separator);
            }
            first = false;
            sb.append(o);
        }
        return sb.toString();
    }

    public static String upperCase(final String s) {
        return s == null ? null : s.toUpperCase();
    }

    public static String substringBetween(final String str, final String open, final String close) {
        if (str == null || open == null || close == null) {
            return null;
        }
        final int start = str.indexOf(open);
        if (start < 0) {
            return null;
        }
        final int end = str.indexOf(close, start + open.length());
        if (end < 0) {
            return null;
        }
        return str.substring(start + open.length(), end);
    }
}






final class WebUtil {
    public static final String DEFAULT_ENCODING = "UTF-8";

    private WebUtil() {
    }

    public static void outputString(final HttpServletResponse response, final Object obj) {
        try {
            response.setContentType("text/javascript");
            response.setCharacterEncoding("utf-8");
            disableCache(response);
            response.getWriter().write(obj.toString());
            response.getWriter().flush();
            response.getWriter().close();
        } catch (IOException e) {
        }
    }

    public static void disableCache(HttpServletResponse response) {
        response.setHeader("Pragma", "No-cache");
        response.setDateHeader("Expires", 0);
        response.setHeader("Cache-Control", "no-cache");
    }
}





interface Logger {
    void info(String format, Object... args);

    void error(String format, Object... args);
}

final class LoggerFactory {
    private LoggerFactory() {
    }

    public static Logger getLogger(final Class<?> clazz) {
        final String name = clazz.getSimpleName();
        return new Logger() {
            private String fmt(final String format, final Object... args) {
                String msg = format;
                for (final Object a : args) {
                    final int i = msg.indexOf("{}");
                    if (i < 0) {
                        break;
                    }
                    msg = msg.substring(0, i) + a + msg.substring(i + 2);
                }
                return msg;
            }

            public void info(final String format, final Object... args) {
                System.out.println("        [INFO ] " + name + " - " + fmt(format, args));
            }

            public void error(final String format, final Object... args) {
                System.out.println("        [ERROR] " + name + " - " + fmt(format, args));
            }
        };
    }
}








@WebServlet(urlPatterns = "/access")
class AccessServlet extends HttpServlet {
    private static final long serialVersionUID = 8022360243246207991L;
    private static final Logger log = LoggerFactory.getLogger(AccessServlet.class);

    private static final String TOKEN = "token"; 

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Signature signature = new Signature();
            boolean hasRights = checkSignature(signature, request);

            if (hasRights) {
                log.info("signature-success:{}", signature);
                WebUtil.outputString(response, signature.getEchostr());
            } else {
                log.info("signature-not-match:{}", signature);
            }
        } catch (Exception e) {
            log.error("signature-error", e);
        }
    }
    

    private boolean checkSignature(Signature signature, HttpServletRequest request) throws IllegalAccessException, InvocationTargetException {
        BeanUtils.populate(signature, request.getParameterMap());
        signature.setToken(TOKEN);

        String sign = Hashing.sha1().hashString(buildSignatureText(signature), Charsets.UTF_8).toString();
        return sign.equalsIgnoreCase(signature.getSignature());
    }

    private String buildSignatureText(Signature signature) {
        List<String> list = new ArrayList<String>();
        list.add(Validate.notNull(signature.getToken(), "missing-token"));
        list.add(Validate.notNull(signature.getTimestamp(), "missing-timestamp"));
        list.add(Validate.notNull(signature.getNonce(), "missing-nonce"));
        Collections.sort(list);

        return StringUtils.join(list, "");
    }
}























class ServletException extends Exception {
    ServletException(final String message) {
        super(message);
    }
}


@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
@interface WebServlet {
    String urlPatterns() default "";
}






interface HttpServletRequest {
    java.util.Map<String, String[]> getParameterMap();

    HttpSession getSession();

    java.io.InputStream getInputStream() throws java.io.IOException;
}


interface HttpSession {
    String getId();
}


interface HttpServletResponse {
    void setContentType(String type);

    void setCharacterEncoding(String encoding);

    void setHeader(String name, String value);

    void setDateHeader(String name, long date);

    java.io.PrintWriter getWriter() throws java.io.IOException;
}


abstract class HttpServlet {
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, java.io.IOException {
    }

    protected void doPost(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, java.io.IOException {
    }
}






final class ExchangeAdapter {

    private static final java.util.Map<com.sun.net.httpserver.HttpExchange, boolean[]> RESPONDED =
            new java.util.WeakHashMap<com.sun.net.httpserver.HttpExchange, boolean[]>();

    
    static void ensureResponded(final com.sun.net.httpserver.HttpExchange exchange) throws java.io.IOException {
        final boolean[] flag = RESPONDED.get(exchange);
        if (flag == null || !flag[0]) {
            exchange.sendResponseHeaders(200, 0);
            exchange.getResponseBody().close();
        }
    }

    static HttpServletRequest request(final com.sun.net.httpserver.HttpExchange exchange) {
        final java.util.Map<String, String[]> params = new java.util.LinkedHashMap<String, String[]>();
        final String query = exchange.getRequestURI().getQuery();
        if (query != null) {
            for (final String pair : query.split("&")) {
                final int eq = pair.indexOf('=');
                if (eq < 0) {
                    continue;
                }
                try {
                    final String key = java.net.URLDecoder.decode(pair.substring(0, eq), "UTF-8");
                    final String value = java.net.URLDecoder.decode(pair.substring(eq + 1), "UTF-8");
                    params.put(key, new String[] { value });
                } catch (final java.io.UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return new HttpServletRequest() {
            public java.util.Map<String, String[]> getParameterMap() {
                return params;
            }

            public HttpSession getSession() {
                return new HttpSession() {
                    public String getId() {
                        return "test-session";
                    }
                };
            }

            public java.io.InputStream getInputStream() {
                return exchange.getRequestBody();
            }
        };
    }

    static HttpServletResponse response(final com.sun.net.httpserver.HttpExchange exchange) {
        final boolean[] flag = new boolean[] { false };
        RESPONDED.put(exchange, flag);
        return new HttpServletResponse() {
            private final java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
            private boolean headersSent;
            private java.io.PrintWriter cachedWriter;

            public void setContentType(final String type) {
                exchange.getResponseHeaders().set("Content-Type", type);
            }

            public void setCharacterEncoding(final String encoding) {
                
            }

            public void setHeader(final String name, final String value) {
                exchange.getResponseHeaders().set(name, value);
            }

            public void setDateHeader(final String name, final long date) {
                exchange.getResponseHeaders().set(name, String.valueOf(date));
            }

            
            public java.io.PrintWriter getWriter() {
                if (cachedWriter != null) {
                    return cachedWriter;
                }
                try {
                    if (!headersSent) {
                        exchange.sendResponseHeaders(200, 0);
                        headersSent = true;
                        flag[0] = true;
                    }
                } catch (final java.io.IOException e) {
                    throw new RuntimeException(e);
                }
                cachedWriter = new java.io.PrintWriter(new java.io.OutputStreamWriter(buffer)) {
                    @Override
                    public void close() {
                        super.flush();
                        try {
                            exchange.getResponseBody().write(buffer.toByteArray());
                            exchange.getResponseBody().close();
                        } catch (final java.io.IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                };
                return cachedWriter;
            }
        };
    }
}








final class BeanUtils {
    private BeanUtils() {
    }

    public static void populate(final Object bean, final java.util.Map<String, String[]> properties)
            throws IllegalAccessException, java.lang.reflect.InvocationTargetException {
        for (final java.util.Map.Entry<String, String[]> entry : properties.entrySet()) {
            final String property = entry.getKey();
            final String[] values = entry.getValue();
            if (values == null || values.length == 0) {
                continue;
            }
            final String setterName = "set" + Character.toUpperCase(property.charAt(0)) + property.substring(1);
            for (final java.lang.reflect.Method m : bean.getClass().getMethods()) {
                if (m.getName().equals(setterName) && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0] == String.class) {
                    m.invoke(bean, (Object) values[0]);
                    break;
                }
            }
        }
    }
}







final class Charsets {
    public static final java.nio.charset.Charset UTF_8 = java.nio.charset.StandardCharsets.UTF_8;

    private Charsets() {
    }
}

final class HashCode {
    private final byte[] bytes;

    HashCode(final byte[] bytes) {
        this.bytes = bytes;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (final byte b : bytes) {
            sb.append(Character.forDigit((b >> 4) & 0xF, 16));
            sb.append(Character.forDigit(b & 0xF, 16));
        }
        return sb.toString();
    }
}

final class Hasher {
    private final java.security.MessageDigest digest;

    Hasher(final java.security.MessageDigest digest) {
        this.digest = digest;
    }

    public HashCode hashString(final CharSequence input, final java.nio.charset.Charset charset) {
        return new HashCode(digest.digest(input.toString().getBytes(charset)));
    }
}

final class Hashing {
    private Hashing() {
    }

    public static Hasher sha1() {
        try {
            return new Hasher(java.security.MessageDigest.getInstance("SHA-1"));
        } catch (final java.security.NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}

