







































import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class method_2_wechatmp_claude {

    public static class WechatMessage {
        @XmlElement(name = "ToUserName")
        private String toUserName;

        @XmlElement(name = "FromUserName")
        private String fromUserName;

        @XmlElement(name = "MsgType")
        private String msgType;

        @XmlElement(name = "CreateTime")
        private long createTime;

        @Override
        public String toString() {
            return "WechatMessage[toUserName=" + toUserName + ", fromUserName=" + fromUserName
                    + ", msgType=" + msgType + ", createTime=" + createTime + "]";
        }
    }

    @XmlRootElement(name = "xml")
    public static class TextMessage extends WechatMessage {
        @XmlElement(name = "Content")
        private String content;

        @Override
        public String toString() {
            return "TextMessage[content=" + content + ", " + super.toString() + "]";
        }
    }

    @XmlRootElement(name = "somethingElse")
    public static class Unrelated {
        @XmlElement(name = "Value")
        private String value;
    }

    public static void main(final String[] args) {
        title("METHOD 2  |  XmlUtil.unmarshal(String message, Class<?> childClass)");

        section("1. a message that matches the exact childClass root element name");
        final String textXml = "<xml>"
                + "<ToUserName>gh_1234</ToUserName>"
                + "<FromUserName>o1234</FromUserName>"
                + "<CreateTime>1700000000</CreateTime>"
                + "<MsgType>text</MsgType>"
                + "<Content>hello there</Content>"
                + "</xml>";
        final Object parsed = XmlUtil.unmarshal(textXml, TextMessage.class);
        System.out.println("      result : " + parsed);
        System.out.println("      result class : " + (parsed == null ? "null" : parsed.getClass().getSimpleName()));

        section("2. getAllSuperTypes(...) really walks the class hierarchy - a superclass field is populated too");
        final TextMessage message = (TextMessage) parsed;
        System.out.println("      inherited field populated from the same document : msgType="
                + fieldOf(message, "msgType"));

        section("3. malformed XML - the empty catch block swallows the exception, returns null");
        final Object malformed = XmlUtil.unmarshal("<xml><ToUserName>unterminated", TextMessage.class);
        System.out.println("      result : " + malformed);

        section("4. a root element that does not match childClass or any of its supertypes - returns null");
        final Object mismatch = XmlUtil.unmarshal("<somethingElse><Value>x</Value></somethingElse>", TextMessage.class);
        System.out.println("      result : " + mismatch);

        section("5. childClass itself has Object as an ultimate supertype - included in the context array");
        System.out.println("      getAllSuperTypes(TextMessage.class) walks TextMessage -> WechatMessage -> Object");
        System.out.println("      reverseAndToArray therefore starts with Object.class, then WechatMessage, then");
        System.out.println("      TextMessage - JAXBContext.newInstance(...) is handed all three, exactly as the");
        System.out.println("      unmodified target method computes it.");

        section("6. branch coverage summary");
        System.out.println("      successful parse and field population -> scenarios 1, 2");
        System.out.println("      caught exception (malformed XML)       -> scenario 3");
        System.out.println("      caught exception (no matching class)   -> scenario 4");

        title("END OF METHOD 2 SCENARIOS");
    }

    static String fieldOf(final Object o, final String name) {
        try {
            final java.lang.reflect.Field f = WechatMessage.class.getDeclaredField(name);
            f.setAccessible(true);
            return String.valueOf(f.get(o));
        } catch (final Exception e) {
            return "<error: " + e + ">";
        }
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}







final class XmlUtil {
    private static List<Class<?>> getAllSuperTypes(Class<?> type) {
        List<Class<?>> result = new ArrayList<Class<?>>();
        for (; type != null; type = type.getSuperclass()) {
            result.add(type);
        }

        return result;
    }

    
    public static Object unmarshal(String message, Class<?> childClass) {
        try {
            Class<?>[] reverseAndToArray = Iterables.toArray(Lists.reverse(getAllSuperTypes(childClass)), Class.class);
            JAXBContext jaxbCtx = JAXBContext.newInstance(reverseAndToArray);
            Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();

            return unmarshaller.unmarshal(new StringReader(message));
        } catch (Exception e) {
        }

        return null;
    }
    
}















@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
@interface XmlRootElement {
    String name() default "##default";
}


@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@java.lang.annotation.Target(java.lang.annotation.ElementType.FIELD)
@interface XmlElement {
    String name() default "##default";
}


class JAXBException extends Exception {
    JAXBException(final String message) {
        super(message);
    }

    JAXBException(final Throwable cause) {
        super(cause);
    }
}






final class JAXBContext {

    private final Class<?>[] contextClasses;

    private JAXBContext(final Class<?>[] contextClasses) {
        this.contextClasses = contextClasses;
    }

    public static JAXBContext newInstance(final Class<?>... contextClasses) throws JAXBException {
        if (contextClasses == null || contextClasses.length == 0) {
            throw new JAXBException("at least one context class is required");
        }
        return new JAXBContext(contextClasses);
    }

    public Unmarshaller createUnmarshaller() {
        return new Unmarshaller(contextClasses);
    }

    public Marshaller createMarshaller() {
        return new Marshaller(contextClasses.length > 0 ? contextClasses[0] : null);
    }
}







final class Unmarshaller {

    private final Class<?>[] contextClasses;

    Unmarshaller(final Class<?>[] contextClasses) {
        this.contextClasses = contextClasses;
    }

    public Object unmarshal(final java.io.Reader reader) throws JAXBException {
        try {
            final javax.xml.parsers.DocumentBuilderFactory factory =
                    javax.xml.parsers.DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(false);
            final javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
            final org.w3c.dom.Document document = builder.parse(new org.xml.sax.InputSource(reader));
            final org.w3c.dom.Element root = document.getDocumentElement();
            final String rootName = root.getTagName();

            Class<?> match = null;
            for (final Class<?> candidate : contextClasses) {
                if (candidate == null || candidate == Object.class) {
                    continue;
                }
                final XmlRootElement annotation = candidate.getAnnotation(XmlRootElement.class);
                final String expected = annotation != null && !"##default".equals(annotation.name())
                        ? annotation.name() : candidate.getSimpleName();
                if (expected.equalsIgnoreCase(rootName)) {
                    match = candidate;
                    break;
                }
            }
            if (match == null) {
                throw new JAXBException("unrecognized element <" + rootName + ">, expected one of "
                        + java.util.Arrays.toString(contextClasses));
            }

            final Object instance = match.newInstance();
            final java.util.List<java.lang.reflect.Field> allFields = new java.util.ArrayList<java.lang.reflect.Field>();
            for (Class<?> c = match; c != null && c != Object.class; c = c.getSuperclass()) {
                for (final java.lang.reflect.Field f : c.getDeclaredFields()) {
                    allFields.add(f);
                }
            }
            for (final java.lang.reflect.Field field : allFields) {
                if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                    continue;
                }
                final XmlElement el = field.getAnnotation(XmlElement.class);
                final String elementName = el != null && !"##default".equals(el.name()) ? el.name() : field.getName();
                final org.w3c.dom.NodeList children = root.getElementsByTagName(elementName);
                if (children.getLength() == 0) {
                    continue;
                }
                final String text = children.item(0).getTextContent();
                field.setAccessible(true);
                final Class<?> type = field.getType();
                if (type == int.class || type == Integer.class) {
                    field.set(instance, text.trim().isEmpty() ? 0 : Integer.parseInt(text.trim()));
                } else if (type == long.class || type == Long.class) {
                    field.set(instance, text.trim().isEmpty() ? 0L : Long.parseLong(text.trim()));
                } else {
                    field.set(instance, text);
                }
            }
            return instance;
        } catch (final JAXBException e) {
            throw e;
        } catch (final Exception e) {
            throw new JAXBException(e);
        }
    }
}


final class Marshaller {

    public static final String JAXB_FRAGMENT = "jaxb.fragment";

    private final Class<?> rootClass;

    Marshaller(final Class<?> rootClass) {
        this.rootClass = rootClass;
    }

    public void setProperty(final String name, final Object value) {
        
    }

    public void marshal(final Object object, final java.io.Writer writer) throws JAXBException {
        try {
            final XmlRootElement annotation = object.getClass().getAnnotation(XmlRootElement.class);
            final String rootName = annotation != null && !"##default".equals(annotation.name())
                    ? annotation.name() : object.getClass().getSimpleName();
            writer.write('<' + rootName + '>');
            for (final java.lang.reflect.Field field : object.getClass().getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                    continue;
                }
                field.setAccessible(true);
                final XmlElement el = field.getAnnotation(XmlElement.class);
                final String elementName = el != null && !"##default".equals(el.name()) ? el.name() : field.getName();
                final Object value = field.get(object);
                writer.write('<' + elementName + '>' + (value == null ? "" : String.valueOf(value)) + "</" + elementName + '>');
            }
            writer.write("</" + rootName + '>');
        } catch (final Exception e) {
            throw new JAXBException(e);
        }
    }
}






final class Lists {
    private Lists() {
    }

    public static <T> java.util.List<T> reverse(final java.util.List<T> list) {
        final java.util.List<T> copy = new java.util.ArrayList<T>(list);
        java.util.Collections.reverse(copy);
        return copy;
    }
}

final class Iterables {
    private Iterables() {
    }

    @SuppressWarnings("unchecked")
    public static <T> T[] toArray(final Iterable<? extends T> iterable, final Class<T> type) {
        final java.util.List<T> list = new java.util.ArrayList<T>();
        for (final T t : iterable) {
            list.add(t);
        }
        final T[] array = (T[]) java.lang.reflect.Array.newInstance(type, list.size());
        return list.toArray(array);
    }
}

