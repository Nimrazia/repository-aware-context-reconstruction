




















































import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class method_1_wechatmp_claude {

    public static void main(final String[] args) throws Exception {
        title("METHOD 1  |  MediaUtil.uploadMedia(License license, MediaFile mediaFile)");

        final File image = File.createTempFile("wechat-demo", ".jpg");
        image.deleteOnExit();
        final java.io.FileOutputStream fos = new java.io.FileOutputStream(image);
        fos.write(new byte[] { (byte) 0xFF, (byte) 0xD8, (byte) 0xFF, 0, 1, 2, 3, 4 });
        fos.close();

        final TestServer server = new TestServer();
        server.start();
        try {
            WechatRequest.pointAt("http://localhost:" + server.port() + "/media/upload");
            AccessTokenUtil.pointAt("http://localhost:" + server.port() + "/token");

            final License license = new License("demo-app", "wx1234567890", "s3cr3t");

            section("1. missing mediaFile - the first guard, no HTTP call at all");
            final MediaJsonRtn missing = MediaUtil.uploadMedia(license, null);
            System.out.println("      errCode=" + missing.getErrCode() + ", errMsg=" + missing.getErrMsg());
            System.out.println("      HTTP requests received by the server so far : " + server.requestCount());

            section("2. a successful upload - the server returns a valid media_id");
            server.nextResponse(200, "{\"type\":\"image\",\"media_id\":\"MEDIA_ID_1\",\"created_at\":1700000000}");
            final MediaFile mediaFile = new MediaFile(MediaType.IMAGE, image);
            final MediaJsonRtn success = MediaUtil.uploadMedia(license, mediaFile);
            System.out.println("      type=" + success.getType() + ", mediaId=" + success.getMediaId()
                    + ", createdAt=" + success.getCreatedAt());
            System.out.println("      last request path : " + server.lastPath());
            System.out.println("      last request had a multipart body : " + server.lastRequestWasMultipart());

            section("3. the server returns a WeChat style error - errcode/errmsg are parsed, not an HTTP failure");
            server.nextResponse(200, "{\"errcode\":\"40004\",\"errmsg\":\"invalid media type\"}");
            final MediaJsonRtn wechatError = MediaUtil.uploadMedia(license, mediaFile);
            System.out.println("      errCode=" + wechatError.getErrCode() + ", errMsg=" + wechatError.getErrMsg());

            section("4. the server returns an HTTP error status - UTF8_CONTENT_HANDLER throws, caught by uploadMedia");
            server.nextResponse(500, "internal server error");
            final MediaJsonRtn httpError = MediaUtil.uploadMedia(license, mediaFile);
            System.out.println("      errCode=" + httpError.getErrCode() + ", errMsg=" + httpError.getErrMsg());

            section("5. the server is unreachable - a connection exception is caught by uploadMedia");
            server.stop();
            final MediaJsonRtn unreachable = MediaUtil.uploadMedia(license, mediaFile);
            System.out.println("      errCode=" + unreachable.getErrCode() + ", errMsg=" + unreachable.getErrMsg());

            section("6. branch coverage summary");
            System.out.println("      mediaFile == null                            -> scenario 1");
            System.out.println("      successful HTTP call, valid WeChat JSON       -> scenario 2");
            System.out.println("      successful HTTP call, WeChat level error JSON -> scenario 3");
            System.out.println("      HTTP status >= 300 (UTF8_CONTENT_HANDLER throws HttpResponseException) -> scenario 4");
            System.out.println("      the catch (Exception e) block (connection refused) -> scenario 5");
        } finally {
            server.stopIfRunning();
        }

        title("END OF METHOD 1 SCENARIOS");
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}






final class TestServer {

    private com.sun.net.httpserver.HttpServer httpServer;
    private int statusCode = 200;
    private String responseBody = "{}";
    private int requestCount = 0;
    private String lastPath;
    private boolean lastRequestWasMultipart;
    private boolean running;

    void start() throws java.io.IOException {
        httpServer = com.sun.net.httpserver.HttpServer.create(new java.net.InetSocketAddress("localhost", 0), 0);
        httpServer.createContext("/", new com.sun.net.httpserver.HttpHandler() {
            public void handle(final com.sun.net.httpserver.HttpExchange exchange) throws java.io.IOException {
                requestCount++;
                lastPath = exchange.getRequestURI().getPath();
                final String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
                lastRequestWasMultipart = contentType != null && contentType.startsWith("multipart/form-data");
                final byte[] ignored = readAll(exchange.getRequestBody());
                final byte[] out = responseBody.getBytes("UTF-8");
                exchange.sendResponseHeaders(statusCode, out.length);
                final java.io.OutputStream os = exchange.getResponseBody();
                os.write(out);
                os.close();
            }
        });
        httpServer.start();
        running = true;
    }

    void nextResponse(final int statusCode, final String body) {
        this.statusCode = statusCode;
        this.responseBody = body;
    }

    int port() {
        return httpServer.getAddress().getPort();
    }

    int requestCount() {
        return requestCount;
    }

    String lastPath() {
        return lastPath;
    }

    boolean lastRequestWasMultipart() {
        return lastRequestWasMultipart;
    }

    void stop() {
        if (running) {
            httpServer.stop(0);
            running = false;
        }
    }

    void stopIfRunning() {
        stop();
    }

    private static byte[] readAll(final java.io.InputStream in) throws java.io.IOException {
        final java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        final byte[] chunk = new byte[4096];
        int read;
        while ((read = in.read(chunk)) != -1) {
            buffer.write(chunk, 0, read);
        }
        return buffer.toByteArray();
    }
}





interface Logger {
    void info(String format, Object... args);

    void error(String format, Object... args);
}

final class LoggerFactory {
    private LoggerFactory() {
    }

    public static Logger getLogger(final Class<?> clazz) {
        final String name = clazz.getSimpleName();
        return new Logger() {
            private String fmt(final String format, final Object... args) {
                String msg = format;
                for (final Object a : args) {
                    final int i = msg.indexOf("{}");
                    if (i < 0) {
                        break;
                    }
                    msg = msg.substring(0, i) + a + msg.substring(i + 2);
                }
                return msg;
            }

            public void info(final String format, final Object... args) {
                System.out.println("        [INFO ] " + name + " - " + fmt(format, args));
            }

            public void error(final String format, final Object... args) {
                System.out.println("        [ERROR] " + name + " - " + fmt(format, args));
            }
        };
    }
}









abstract class AbstractToStringBuilder {
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder(getClass().getSimpleName()).append('[');
        boolean first = true;
        for (Class<?> c = getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (final java.lang.reflect.Field f : c.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                f.setAccessible(true);
                try {
                    if (!first) {
                        sb.append(',');
                    }
                    first = false;
                    sb.append(f.getName()).append('=').append(f.get(this));
                } catch (final IllegalAccessException e) {
                    
                }
            }
        }
        return sb.append(']').toString();
    }
}






class JsonRtn extends AbstractToStringBuilder {
    @JSONField(name = "errcode")
    private String errCode;

    @JSONField(name = "errmsg")
    private String errMsg;

    private String errHumanMsg;

    public JsonRtn() {
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public String getErrHumanMsg() {
        return errHumanMsg;
    }

    public void setErrHumanMsg(String errHumanMsg) {
        this.errHumanMsg = errHumanMsg;
    }
}






class MediaJsonRtn extends JsonRtn {
    @JSONField(name = "type")
    private String type;

    @JSONField(name = "media_id")
    private String mediaId;

    @JSONField(name = "thumb_media_id")
    private String thumbMediaId;

    @JSONField(name = "created_at")
    private long createdAt;

    public MediaJsonRtn() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMediaId() {
        return mediaId;
    }

    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }

    public String getThumbMediaId() {
        return thumbMediaId;
    }

    public void setThumbMediaId(String thumbMediaId) {
        this.thumbMediaId = thumbMediaId;
        this.mediaId = StringUtils.defaultIfEmpty(this.mediaId, thumbMediaId);
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}






enum MimeType {
    IMAGE_JPG("jpg", "image/jpeg"),
    VOICE_AMR("amr", "audio/amr"),
    VOICE_MP3("mp3", "audio/mp3"),
    VIDEO_MP4("mp4", "video/mp4"),
    THUMB_JPG("jpg", "image/jpeg");

    private final String extension;
    private final String contentType;

    MimeType(final String extension, final String contentType) {
        this.extension = extension;
        this.contentType = contentType;
    }

    public String getExtension() {
        return extension;
    }

    public String getContentType() {
        return contentType;
    }
}


class MediaLimit {
    private final long maxSize;
    private final int maxSeconds;
    private final List<MimeType> allowTypes;

    MediaLimit(final long maxSize, final List<MimeType> allowTypes) {
        this(maxSize, -1, allowTypes);
    }

    MediaLimit(final long maxSize, final int maxSeconds, final List<MimeType> allowTypes) {
        this.maxSize = maxSize;
        this.maxSeconds = maxSeconds;
        this.allowTypes = allowTypes;
    }

    public long getMaxSize() {
        return maxSize;
    }

    public int getMaxSeconds() {
        return maxSeconds;
    }

    public List<MimeType> getAllowTypes() {
        return allowTypes;
    }
}






enum MediaType {
    IMAGE("image") {
        @Override
        public MediaLimit getMediaLimit() {
            List<MimeType> allowTypes = java.util.Arrays.asList(MimeType.IMAGE_JPG);
            MediaLimit mediaLimit = new MediaLimit(128 * 1024L, allowTypes);
            return mediaLimit;
        }
    },
    VOICE("voice") {
        @Override
        public MediaLimit getMediaLimit() {
            List<MimeType> allowTypes = java.util.Arrays.asList(MimeType.VOICE_AMR, MimeType.VOICE_MP3);
            MediaLimit mediaLimit = new MediaLimit(256 * 1024L, 60, allowTypes);
            return mediaLimit;
        }
    },
    VIDEO("video") {
        @Override
        public MediaLimit getMediaLimit() {
            List<MimeType> allowTypes = java.util.Arrays.asList(MimeType.VIDEO_MP4);
            MediaLimit mediaLimit = new MediaLimit(1 * 1024 * 1024L, allowTypes);
            return mediaLimit;
        }
    },
    THUMB("thumb") {
        @Override
        public MediaLimit getMediaLimit() {
            List<MimeType> allowTypes = java.util.Arrays.asList(MimeType.THUMB_JPG);
            MediaLimit mediaLimit = new MediaLimit(64 * 1024L, allowTypes);
            return mediaLimit;
        }
    },
    ;

    private String name;

    private MediaType(String name) {
        this.name = name;
    }

    public abstract MediaLimit getMediaLimit();

    public String getName() {
        return name;
    }
}






class MediaFile extends AbstractToStringBuilder {
    private MediaType mediaType;
    private File file;

    public MediaFile() {
    }

    public MediaFile(MediaType mediaType, File file) {
        this.mediaType = mediaType;
        this.file = file;
    }

    public MediaType getMediaType() {
        return mediaType;
    }

    public void setMediaType(MediaType mediaType) {
        this.mediaType = mediaType;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }
}






class License extends AbstractToStringBuilder {
    private String app;
    private String appId;
    private String appSecret;

    public License(String app, String appId, String appSecret) {
        this.app = app;
        this.appId = appId;
        this.appSecret = appSecret;
    }

    public String getApp() {
        return app;
    }

    public String getAppId() {
        return appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(app, appId, appSecret);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        License other = (License) obj;
        return java.util.Objects.equals(this.app, other.app)
                && java.util.Objects.equals(this.appId, other.appId)
                && java.util.Objects.equals(this.appSecret, other.appSecret);
    }
}









final class WechatRequest {

    static String uploadMediaUrl = "http://api.weixin.qq.com/cgi-bin/media/upload";

    static final WechatRequest UPLOAD_MEDIA = new WechatRequest("UPLOAD_MEDIA");

    private final String enumName;

    private WechatRequest(final String enumName) {
        this.enumName = enumName;
    }

    static void pointAt(final String url) {
        uploadMediaUrl = url;
    }

    public String getName() {
        return StringUtils.lowerCase(StringUtils.replace(enumName, "_", " "));
    }

    public String getUrl() {
        return uploadMediaUrl;
    }
}









final class AccessTokenUtil {

    private static String tokenUrl = "https://api.weixin.qq.com/cgi-bin/token";

    private AccessTokenUtil() {
    }

    static void pointAt(final String url) {
        tokenUrl = url;
    }

    public static String getAccessToken(final License license) {
        try {
            final java.net.URI uri = new URIBuilder(tokenUrl)
                    .setParameter("grant_type", "client_credential")
                    .setParameter("appid", license.getAppId())
                    .setParameter("secret", license.getAppSecret())
                    .build();
            final String json = Request.Get(uri)
                    .connectTimeout(HttpUtil.CONNECT_TIMEOUT)
                    .socketTimeout(HttpUtil.SOCKET_TIMEOUT)
                    .execute().returnContent().asString();
            final JsonRtn rtn = JSONObject.parseObject(json, JsonRtn.class);
            if (rtn != null && StringUtils.isNotEmpty(rtn.getErrCode())) {
                return StringUtils.EMPTY;
            }
            final int start = json.indexOf("\"access_token\"");
            if (start < 0) {
                return StringUtils.EMPTY;
            }
            final int colon = json.indexOf(':', start);
            final int firstQuote = json.indexOf('"', colon + 1);
            final int secondQuote = json.indexOf('"', firstQuote + 1);
            return json.substring(firstQuote + 1, secondQuote);
        } catch (final Exception e) {
            return StringUtils.EMPTY;
        }
    }
}








final class JsonRtnUtil {
    private static final String WECHAT_GLOBAL_MESSAGE_FILE_NAME = "wechate-global-message";
    private static final String WECHAT_JSON_RTN_SUCCESS_CODE = "0";
    private static java.util.ResourceBundle bundle;

    static {
        try {
            bundle = java.util.ResourceBundle.getBundle(WECHAT_GLOBAL_MESSAGE_FILE_NAME);
        } catch (Exception e) {
        }
    }

    public static <T extends JsonRtn> T parseJsonRtn(String jsonRtn, Class<T> jsonRtnClazz) {
        T rtn = JSONObject.parseObject(jsonRtn, jsonRtnClazz);
        appendErrorHumanMsg(rtn);
        return rtn;
    }

    private static JsonRtn appendErrorHumanMsg(JsonRtn jsonRtn) {
        if (bundle == null || jsonRtn == null || StringUtils.isEmpty(jsonRtn.getErrCode())) {
            return null;
        }

        try {
            jsonRtn.setErrHumanMsg(bundle.getString(jsonRtn.getErrCode()));
            return jsonRtn;
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean isSuccess(JsonRtn jsonRtn) {
        if (jsonRtn == null) {
            return false;
        }

        String errCode = jsonRtn.getErrCode();
        if (StringUtils.isEmpty(errCode) || StringUtils.equals(WECHAT_JSON_RTN_SUCCESS_CODE, errCode)) {
            return true;
        }

        return false;
    }

    public static <T extends JsonRtn> T buildFailureJsonRtn(Class<T> jsonRtnClazz, String errMsg) {
        try {
            T jsonRtn = jsonRtnClazz.newInstance();
            jsonRtn.setErrCode("-1");
            jsonRtn.setErrMsg(errMsg);

            appendErrorHumanMsg(jsonRtn);

            return jsonRtn;
        } catch (Exception e) {
            return null;
        }
    }
}







final class HttpUtil {
    public static final int CONNECT_TIMEOUT = 2000;
    public static final int SOCKET_TIMEOUT = 2000;

    public static final ResponseHandler<String> UTF8_CONTENT_HANDLER = new ResponseHandler<String>() {
        @Override
        public String handleResponse(HttpResponse response) throws ClientProtocolException, java.io.IOException {
            final StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() >= 300) {
                throw new HttpResponseException(statusLine.getStatusCode(), statusLine.getReasonPhrase());
            }

            final HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, "UTF-8");
            }

            return StringUtils.EMPTY;
        }
    };
}







final class MediaUtil {

    private static final Logger log = LoggerFactory.getLogger(MediaUtil.class);

        
    public static MediaJsonRtn uploadMedia(License license, MediaFile mediaFile) {
        if (mediaFile == null) {
            return JsonRtnUtil.buildFailureJsonRtn(MediaJsonRtn.class, "missing mediaFile");
        }
        

        String accessToken = AccessTokenUtil.getAccessToken(license);
        String url = WechatRequest.UPLOAD_MEDIA.getUrl();
        try {
            MediaType mediaType = mediaFile.getMediaType();
            URI uri = new URIBuilder(url)
                    .setParameter("access_token", accessToken)
                    .setParameter("type", mediaType.getName())
                    .build();

            HttpEntity httpEntity = MultipartEntityBuilder.create()
                    .addBinaryBody("body", mediaFile.getFile())
                    .build();

            String rtnJson = Request.Post(uri)
                    .connectTimeout(HttpUtil.CONNECT_TIMEOUT)
                    .socketTimeout(HttpUtil.SOCKET_TIMEOUT)
                    .body(httpEntity)
                    .execute().handleResponse(HttpUtil.UTF8_CONTENT_HANDLER);

            MediaJsonRtn jsonRtn = JsonRtnUtil.parseJsonRtn(rtnJson, MediaJsonRtn.class);
            log.info("upload media:\n url={},\n body={},\n rtn={},{}", uri, mediaFile, rtnJson, jsonRtn);
            return jsonRtn;
        } catch (Exception e) {
            String msg = "upload media failed:\n " +
                    "url=" + url + "?access_token=" + accessToken + ",\n body=" + mediaFile;
            log.error(msg, e);
            return JsonRtnUtil.buildFailureJsonRtn(MediaJsonRtn.class, "uploadMedia failed");
        }
    }
        
}



















@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@java.lang.annotation.Target(java.lang.annotation.ElementType.FIELD)
@interface JSONField {
    String name() default "";
}







final class JSONObject {

    private JSONObject() {
    }

    public static <T> T parseObject(final String json, final Class<T> clazz) {
        if (json == null) {
            return null;
        }
        final Map<String, Object> raw = parseFlatObject(json);
        try {
            final T instance = clazz.newInstance();
            for (final java.lang.reflect.Field field : allFields(clazz)) {
                final JSONField jf = field.getAnnotation(JSONField.class);
                final String key = jf != null && !jf.name().isEmpty() ? jf.name() : field.getName();
                if (!raw.containsKey(key)) {
                    continue;
                }
                field.setAccessible(true);
                final Object value = raw.get(key);
                final Class<?> type = field.getType();
                if (type == long.class || type == Long.class) {
                    field.set(instance, value == null ? 0L : Long.parseLong(String.valueOf(value)));
                } else if (type == int.class || type == Integer.class) {
                    field.set(instance, value == null ? 0 : Integer.parseInt(String.valueOf(value)));
                } else if (type == boolean.class || type == Boolean.class) {
                    field.set(instance, value == null ? false : Boolean.parseBoolean(String.valueOf(value)));
                } else {
                    field.set(instance, value == null ? null : String.valueOf(value));
                }
            }
            return instance;
        } catch (final Exception e) {
            throw new RuntimeException("Unable to parse JSON into " + clazz.getName() + ": " + json, e);
        }
    }

    public static String toJSONString(final Object object) {
        if (object == null) {
            return "null";
        }
        final StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (final java.lang.reflect.Field field : allFields(object.getClass())) {
            final JSONField jf = field.getAnnotation(JSONField.class);
            final String key = jf != null && !jf.name().isEmpty() ? jf.name() : field.getName();
            field.setAccessible(true);
            try {
                final Object value = field.get(object);
                if (!first) {
                    sb.append(',');
                }
                first = false;
                sb.append('"').append(key).append("\":");
                if (value == null) {
                    sb.append("null");
                } else if (value instanceof Number || value instanceof Boolean) {
                    sb.append(value);
                } else {
                    sb.append('"').append(String.valueOf(value).replace("\"", "\\\"")).append('"');
                }
            } catch (final IllegalAccessException e) {
                
            }
        }
        return sb.append('}').toString();
    }

    private static List<java.lang.reflect.Field> allFields(final Class<?> clazz) {
        final List<java.lang.reflect.Field> fields = new ArrayList<java.lang.reflect.Field>();
        for (Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
            for (final java.lang.reflect.Field f : c.getDeclaredFields()) {
                if (!java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    fields.add(f);
                }
            }
        }
        return fields;
    }

    
    private static Map<String, Object> parseFlatObject(final String json) {
        final Map<String, Object> out = new LinkedHashMap<String, Object>();
        final String trimmed = json.trim();
        if (trimmed.length() < 2 || trimmed.charAt(0) != '{') {
            return out;
        }
        int i = 1;
        final int end = trimmed.lastIndexOf('}');
        while (i < end) {
            while (i < end && Character.isWhitespace(trimmed.charAt(i))) {
                i++;
            }
            if (i >= end || trimmed.charAt(i) == ',') {
                i++;
                continue;
            }
            if (trimmed.charAt(i) != '"') {
                break;
            }
            final int keyEnd = trimmed.indexOf('"', i + 1);
            final String key = trimmed.substring(i + 1, keyEnd);
            i = keyEnd + 1;
            while (i < end && (trimmed.charAt(i) == ':' || Character.isWhitespace(trimmed.charAt(i)))) {
                i++;
            }
            final Object value;
            if (trimmed.charAt(i) == '"') {
                final int valEnd = findStringEnd(trimmed, i + 1);
                value = trimmed.substring(i + 1, valEnd).replace("\\\"", "\"");
                i = valEnd + 1;
            } else {
                int valEnd = i;
                while (valEnd < end && trimmed.charAt(valEnd) != ',' && trimmed.charAt(valEnd) != '}') {
                    valEnd++;
                }
                final String raw = trimmed.substring(i, valEnd).trim();
                value = "null".equals(raw) ? null : raw;
                i = valEnd;
            }
            out.put(key, value);
            while (i < end && Character.isWhitespace(trimmed.charAt(i))) {
                i++;
            }
            if (i < end && trimmed.charAt(i) == ',') {
                i++;
            }
        }
        return out;
    }

    private static int findStringEnd(final String s, final int from) {
        int i = from;
        while (i < s.length() && s.charAt(i) != '"') {
            if (s.charAt(i) == '\\') {
                i++;
            }
            i++;
        }
        return i;
    }
}








interface HttpEntity {
    String getContentType();

    void writeTo(java.io.OutputStream out) throws java.io.IOException;
}


final class MultipartEntityBuilder {

    private final List<Object[]> parts = new ArrayList<Object[]>(); 
    private final String boundary = "----wechatBoundary" + System.currentTimeMillis();

    public static MultipartEntityBuilder create() {
        return new MultipartEntityBuilder();
    }

    public MultipartEntityBuilder addBinaryBody(final String name, final java.io.File file) {
        parts.add(new Object[] { name, file });
        return this;
    }

    public HttpEntity build() {
        final String boundaryFinal = boundary;
        final List<Object[]> partsFinal = parts;
        return new HttpEntity() {
            public String getContentType() {
                return "multipart/form-data; boundary=" + boundaryFinal;
            }

            public void writeTo(final java.io.OutputStream out) throws java.io.IOException {
                final java.io.Writer writer = new java.io.OutputStreamWriter(out, "UTF-8");
                for (final Object[] part : partsFinal) {
                    final String name = (String) part[0];
                    final java.io.File file = (java.io.File) part[1];
                    writer.write("--" + boundaryFinal + "\r\n");
                    writer.write("Content-Disposition: form-data; name=\"" + name + "\"; filename=\""
                            + file.getName() + "\"\r\n");
                    writer.write("Content-Type: application/octet-stream\r\n\r\n");
                    writer.flush();
                    final java.io.FileInputStream in = new java.io.FileInputStream(file);
                    try {
                        final byte[] buffer = new byte[4096];
                        int read;
                        while ((read = in.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                        }
                    } finally {
                        in.close();
                    }
                    writer.write("\r\n");
                    writer.flush();
                }
                writer.write("--" + boundaryFinal + "--\r\n");
                writer.flush();
            }
        };
    }
}


class StatusLine {
    private final int statusCode;
    private final String reasonPhrase;

    StatusLine(final int statusCode, final String reasonPhrase) {
        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public String getReasonPhrase() {
        return reasonPhrase;
    }
}


class HttpResponse {
    private final StatusLine statusLine;
    private final byte[] body;

    HttpResponse(final int code, final String reason, final byte[] body) {
        this.statusLine = new StatusLine(code, reason);
        this.body = body;
    }

    public StatusLine getStatusLine() {
        return statusLine;
    }

    public HttpEntity getEntity() {
        if (body == null) {
            return null;
        }
        return new HttpEntity() {
            public String getContentType() {
                return "application/octet-stream";
            }

            public void writeTo(final java.io.OutputStream out) throws java.io.IOException {
                out.write(body);
            }
        };
    }

    byte[] rawBody() {
        return body;
    }
}


class ClientProtocolException extends java.io.IOException {
    ClientProtocolException(final String message) {
        super(message);
    }
}


class HttpResponseException extends ClientProtocolException {
    private final int statusCode;

    HttpResponseException(final int statusCode, final String message) {
        super(message);
        this.statusCode = statusCode;
    }

    public int getStatusCode() {
        return statusCode;
    }
}


interface ResponseHandler<T> {
    T handleResponse(HttpResponse response) throws ClientProtocolException, java.io.IOException;
}


final class EntityUtils {
    private EntityUtils() {
    }

    public static String toString(final HttpEntity entity, final String charset) throws java.io.IOException {
        final java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        entity.writeTo(buffer);
        return new String(buffer.toByteArray(), charset);
    }
}


class Header {
    private final String name;
    private final String value;

    Header(final String name, final String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }
}





final class Request {

    private final String method;
    private final java.net.URI uri;
    private int connectTimeout = 0;
    private int socketTimeout = 0;
    private HttpEntity entity;

    private Request(final String method, final java.net.URI uri) {
        this.method = method;
        this.uri = uri;
    }

    public static Request Post(final java.net.URI uri) {
        return new Request("POST", uri);
    }

    public static Request Get(final java.net.URI uri) {
        return new Request("GET", uri);
    }

    public Request connectTimeout(final int millis) {
        this.connectTimeout = millis;
        return this;
    }

    public Request socketTimeout(final int millis) {
        this.socketTimeout = millis;
        return this;
    }

    public Request body(final HttpEntity entity) {
        this.entity = entity;
        return this;
    }

    public Request bodyString(final String body, final Object contentType) {
        final byte[] bytes;
        try {
            bytes = body.getBytes("UTF-8");
        } catch (final java.io.UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        this.entity = new HttpEntity() {
            public String getContentType() {
                return "text/html; charset=UTF-8";
            }

            public void writeTo(final java.io.OutputStream out) throws java.io.IOException {
                out.write(bytes);
            }
        };
        return this;
    }

    public Response execute() throws java.io.IOException {
        final java.net.HttpURLConnection connection = (java.net.HttpURLConnection) uri.toURL().openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(connectTimeout);
        connection.setReadTimeout(socketTimeout);
        if (entity != null) {
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", entity.getContentType());
            final java.io.OutputStream out = connection.getOutputStream();
            try {
                entity.writeTo(out);
            } finally {
                out.close();
            }
        }
        final int code = connection.getResponseCode();
        final String message = connection.getResponseMessage();
        final java.io.InputStream in = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
        final byte[] body = in == null ? new byte[0] : readAll(in);
        return new Response(new HttpResponse(code, message, body));
    }

    private static byte[] readAll(final java.io.InputStream in) throws java.io.IOException {
        final java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        final byte[] chunk = new byte[4096];
        int read;
        while ((read = in.read(chunk)) != -1) {
            buffer.write(chunk, 0, read);
        }
        in.close();
        return buffer.toByteArray();
    }

    
    static final class Response {
        private final HttpResponse httpResponse;

        Response(final HttpResponse httpResponse) {
            this.httpResponse = httpResponse;
        }

        public <T> T handleResponse(final ResponseHandler<T> handler) throws java.io.IOException {
            return handler.handleResponse(httpResponse);
        }

        public Content returnContent() throws java.io.IOException {
            return new Content(httpResponse.rawBody());
        }
    }

    
    static final class Content {
        private final byte[] bytes;

        Content(final byte[] bytes) {
            this.bytes = bytes;
        }

        public String asString() throws java.io.IOException {
            return new String(bytes, "UTF-8");
        }
    }
}


final class URIBuilder {

    private final String base;
    private final List<String[]> params = new ArrayList<String[]>();

    public URIBuilder(final String url) {
        this.base = url;
    }

    public URIBuilder setParameter(final String name, final String value) {
        params.add(new String[] { name, value });
        return this;
    }

    public URIBuilder setParameters(final List<Object[]> nameValuePairs) {
        for (final Object[] pair : nameValuePairs) {
            params.add(new String[] { (String) pair[0], (String) pair[1] });
        }
        return this;
    }

    public java.net.URI build() throws java.net.URISyntaxException {
        if (params.isEmpty()) {
            return java.net.URI.create(base);
        }
        final StringBuilder sb = new StringBuilder(base);
        sb.append(base.contains("?") ? '&' : '?');
        for (int i = 0; i < params.size(); i++) {
            if (i > 0) {
                sb.append('&');
            }
            try {
                sb.append(java.net.URLEncoder.encode(params.get(i)[0], "UTF-8")).append('=')
                  .append(java.net.URLEncoder.encode(String.valueOf(params.get(i)[1]), "UTF-8"));
            } catch (final java.io.UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }
        }
        return java.net.URI.create(sb.toString());
    }
}







final class StringUtils {

    public static final String EMPTY = "";

    private StringUtils() {
    }

    public static boolean isEmpty(final CharSequence cs) {
        return cs == null || cs.length() == 0;
    }

    public static boolean isNotEmpty(final CharSequence cs) {
        return !isEmpty(cs);
    }

    public static boolean equals(final CharSequence a, final CharSequence b) {
        if (a == b) {
            return true;
        }
        if (a == null || b == null) {
            return false;
        }
        return a.toString().equals(b.toString());
    }

    public static String lowerCase(final String s) {
        return s == null ? null : s.toLowerCase();
    }

    public static String replace(final String text, final String search, final String replacement) {
        return text == null ? null : text.replace(search, replacement);
    }

    public static String defaultIfEmpty(final String str, final String defaultStr) {
        return isEmpty(str) ? defaultStr : str;
    }
}

