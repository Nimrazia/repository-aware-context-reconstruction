

































import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class method_8_logging_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== FoundationFileRollingAppender.activateOptions() - repository-aware reconstruction ===");
      System.out.println("Repository : foundation-runtime/logging @ cd0a07b3c5b458ecf90ab92a1e0c72a067f5cbd6");
      System.out.println("log4j      : lightweight adaptation (log4j 1.2.17 unavailable offline)");
      System.out.println();

      
      
      
      
      
      
      
      System.out.println("--- Scenario 1: fresh appender, roll-on-activation enabled ---");
      File logFile = File.createTempFile("foundation-appender", ".log");
      logFile.deleteOnExit();
      FoundationFileRollingAppender appender = new FoundationFileRollingAppender(new SimpleLayout(), logFile.getAbsolutePath());
      appender.setName("fileAppender");

      appender.activateOptions();

      System.out.println("fileRollable installed            : " + (appender.getFileRollableForTesting() instanceof CompositeRoller));
      System.out.println("scavenger started                 : " + appender.getLogFileScavenger().isStarted());
      System.out.println("compressor started                 : " + appender.getLogFileCompressor().isStarted());
      System.out.println("compressor subscribed to roller     : "
            + ((CompositeRoller) appender.getFileRollableForTesting()).getListeners().contains(appender.getLogFileCompressor()));
      System.out.println("roll enforcer started               : " + appender.getLogRollEnforcerForTesting().isStarted());
      System.out.println("rolled once on activation (roll count == 1) : "
            + (((CompositeRoller) appender.getFileRollableForTesting()).getRollCount() == 1));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 2: roll-on-activation disabled ---");
      File logFile2 = File.createTempFile("foundation-appender-2", ".log");
      logFile2.deleteOnExit();
      FoundationFileRollingAppender appender2 = new FoundationFileRollingAppender(new SimpleLayout(), logFile2.getAbsolutePath());
      appender2.setName("fileAppender2");
      appender2.getPropertiesForTesting().setRollOnStartup(false);

      appender2.activateOptions();

      System.out.println("scavenger started            : " + appender2.getLogFileScavenger().isStarted());
      System.out.println("roll count stayed 0           : "
            + (((CompositeRoller) appender2.getFileRollableForTesting()).getRollCount() == 0));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: a guest FileRollEventListener gets attached ---");
      File logFile3 = File.createTempFile("foundation-appender-3", ".log");
      logFile3.deleteOnExit();
      FoundationFileRollingAppender appender3 = new FoundationFileRollingAppender(new SimpleLayout(), logFile3.getAbsolutePath());
      appender3.setName("fileAppender3");
      RecordingFileRollEventListener guestListener = new RecordingFileRollEventListener();
      appender3.setGuestFileRollEventListenerForTesting(guestListener);
      appender3.getPropertiesForTesting().setRollOnStartup(true);

      appender3.activateOptions();

      System.out.println("guest listener attached to the roller : "
            + ((CompositeRoller) appender3.getFileRollableForTesting()).getListeners().contains(guestListener));
      System.out.println("guest listener notified by the startup roll : " + (guestListener.rollCount > 0));
      System.out.println();

      
      
      
      
      
      
      
      System.out.println("--- Scenario 4: re-activation deactivates the previous collaborators cleanly ---");
      LogFileScavenger firstScavenger = appender3.getLogFileScavenger();
      LogFileCompressor firstCompressor = appender3.getLogFileCompressor();
      TimeBasedRollEnforcer firstEnforcer = appender3.getLogRollEnforcerForTesting();
      FileRollable firstRoller = appender3.getFileRollableForTesting();

      appender3.activateOptions();

      System.out.println("previous scavenger ended      : " + firstScavenger.isEnded());
      System.out.println("previous compressor ended     : " + firstCompressor.isEnded());
      System.out.println("previous roll enforcer ended  : " + firstEnforcer.isEnded());
      System.out.println("guest listener detached from the OLD roller : "
            + !((CompositeRoller) firstRoller).getListeners().contains(guestListener));
      System.out.println("guest listener re-attached to the NEW roller : "
            + ((CompositeRoller) appender3.getFileRollableForTesting()).getListeners().contains(guestListener));
      System.out.println("scavenger instance is REUSED across reactivations (only created once, lazily) : "
            + (appender3.getLogFileScavenger() == firstScavenger));
      System.out.println("but it was re-begin()'d (still started)      : " + appender3.getLogFileScavenger().isStarted());
      System.out.println("compressor instance is REPLACED each activation (real behaviour: unconditional 'new') : "
            + (appender3.getLogFileCompressor() != firstCompressor));
      System.out.println("roll enforcer instance is REPLACED each activation : "
            + (appender3.getLogRollEnforcerForTesting() != firstEnforcer));

      System.out.println();
      System.out.println("=== done ===");
   }
}




class FoundationFileRollingAppender extends FileAppender
{
   private final AppenderRollingProperties properties = new AppenderRollingProperties();

   private FileRollable fileRollable = null;

   private LogFileScavenger logFileScavenger = null;

   private LogFileCompressor logFileCompressor = null;

   private TimeBasedRollEnforcer logRollEnforcer = null;

   private FileRollEventListener guestFileRollEventListener = null;

   private boolean addApplicationState = true;

   public boolean isAddApplicationState()
   {
      return addApplicationState;
   }

   public void setAddApplicationState(boolean addApplicationState)
   {
      this.addApplicationState = addApplicationState;
   }

   public FoundationFileRollingAppender()
   {
      super();
   }

   public FoundationFileRollingAppender(final Layout layout, final String filename) throws IOException
   {
      this();
      this.initSuper(layout, filename, super.getAppend(), super.getBufferedIO(), super.getBufferSize());
   }

   private void initSuper(final Layout layout, final String filename, final boolean append, final boolean bufferedIO, final int bufferSize) throws IOException
   {
      super.setLayout(layout);
      super.setFile(filename);
      super.setAppend(append);
      super.setBufferedIO(bufferedIO);
      super.setBufferSize(bufferSize);
   }

   

   FileRollable getFileRollableForTesting()
   {
      return fileRollable;
   }

   AppenderRollingProperties getPropertiesForTesting()
   {
      return properties;
   }

   TimeBasedRollEnforcer getLogRollEnforcerForTesting()
   {
      return logRollEnforcer;
   }

   void setGuestFileRollEventListenerForTesting(FileRollEventListener listener)
   {
      this.deregisterGuestFileRollEventListener();
      this.guestFileRollEventListener = listener;
   }


// ORIGINAL CODESEARCHNET METHOD — START

public synchronized final void activateOptions() {
		this.deactivateOptions();
		super.activateOptions();
		if (getFilterEmptyMessages()) {
			addFilter(new EmptyMessageFilter());
		}

		
		this.setFileRollable(new CompositeRoller(this, this.getProperties()));
		
		LogFileScavenger fileScavenger = this.getLogFileScavenger();
		if (fileScavenger == null) {
			fileScavenger = this.initLogFileScavenger(new DefaultLogFileScavenger());
		}
		fileScavenger.begin();
		
		final LogFileCompressor logFileCompressor = new LogFileCompressor(this, this.getProperties());
		this.setLogFileCompressor(logFileCompressor);
		this.getFileRollable().addFileRollEventListener(logFileCompressor);
		logFileCompressor.begin();
		
		this.registerGuestFileRollEventListener();
		
		final TimeBasedRollEnforcer logRollEnforcer = new TimeBasedRollEnforcer(this, this.getProperties());
		this.setLogRollEnforcer(logRollEnforcer);
		logRollEnforcer.begin();
		
		if (this.getProperties().shouldRollOnActivation()) {
			synchronized (this) {
				this.rollFile(new StartupFileRollEvent());
			}
		}
	}

// ORIGINAL CODESEARCHNET METHOD — END


   public synchronized final void close()
   {
      this.deactivateOptions();
      super.close();
   }

   public String getDatePattern()
   {
      return this.getProperties().getDatePattern();
   }

   public boolean getFilterEmptyMessages()
   {
      return this.getProperties().getFilterEmptyMessages();
   }

   public void setFilterEmptyMessages(final boolean filterEmptyMessages)
   {
      this.getProperties().setFilterEmptyMessages(filterEmptyMessages);
   }

   private synchronized void deactivateOptions()
   {
      final LogFileScavenger logFileScavenger = this.getLogFileScavenger();
      if (logFileScavenger != null)
      {
         logFileScavenger.end();
      }
      final TimeBasedRollEnforcer logRollEnforcer = this.getLogRollEnforcer();
      if (logRollEnforcer != null)
      {
         logRollEnforcer.end();
      }
      final LogFileCompressor logFileCompressor = this.getLogFileCompressor();
      if (logFileCompressor != null)
      {
         logFileCompressor.end();
      }
      final FileRollable rollable = this.getFileRollable();
      if (rollable != null)
      {
         rollable.removeFileRollEventListener(logFileCompressor);
      }
      this.deregisterGuestFileRollEventListener();
   }

   private void deregisterGuestFileRollEventListener()
   {
      if (this.getGuestFileRollEventListener() != null)
      {
         final FileRollable fileRollable = this.getFileRollable();
         if (fileRollable != null)
         {
            fileRollable.removeFileRollEventListener(this.getGuestFileRollEventListener());
         }
      }
   }

   private void registerGuestFileRollEventListener()
   {
      if (this.getGuestFileRollEventListener() != null)
      {
         final FileRollable fileRollable = this.getFileRollable();
         if (fileRollable != null)
         {
            fileRollable.addFileRollEventListener(this.getGuestFileRollEventListener());
         }
      }
   }

   private void rollFile(final LoggingEvent event)
   {
      this.getFileRollable().roll(event);
   }

   private AppenderRollingProperties getProperties()
   {
      return this.properties;
   }

   private FileRollable getFileRollable()
   {
      return this.fileRollable;
   }

   private void setFileRollable(final FileRollable fileRollable)
   {
      this.fileRollable = fileRollable;
   }

   final LogFileScavenger getLogFileScavenger()
   {
      return this.logFileScavenger;
   }

   private LogFileScavenger initLogFileScavenger(final LogFileScavenger logFileScavenger)
   {
      if (this.logFileScavenger != null)
      {
         this.logFileScavenger.end();
      }
      this.logFileScavenger = logFileScavenger;
      this.logFileScavenger.init(this, this.getProperties());
      return this.logFileScavenger;
   }

   final LogFileCompressor getLogFileCompressor()
   {
      return this.logFileCompressor;
   }

   private void setLogFileCompressor(final LogFileCompressor logFileCompressor)
   {
      if (this.logFileCompressor != null)
      {
         this.logFileCompressor.end();
      }
      this.logFileCompressor = logFileCompressor;
   }

   private TimeBasedRollEnforcer getLogRollEnforcer()
   {
      return logRollEnforcer;
   }

   private void setLogRollEnforcer(final TimeBasedRollEnforcer logRollEnforcer)
   {
      if (this.logRollEnforcer != null)
      {
         this.logRollEnforcer.end();
      }
      this.logRollEnforcer = logRollEnforcer;
   }

   final FileRollEventListener getGuestFileRollEventListener()
   {
      return this.guestFileRollEventListener;
   }
}







class AppenderRollingProperties
{
   private boolean filterEmptyMessages = false;
   private boolean rollOnStartup = true;
   private String datePattern = "'.'yyyy-MM-dd";

   boolean getFilterEmptyMessages()
   {
      return filterEmptyMessages;
   }

   void setFilterEmptyMessages(boolean value)
   {
      this.filterEmptyMessages = value;
   }

   boolean shouldRollOnActivation()
   {
      return rollOnStartup;
   }

   void setRollOnStartup(boolean value)
   {
      this.rollOnStartup = value;
   }

   String getDatePattern()
   {
      return datePattern;
   }
}




interface FileRollEventListener
{
   void onFileRoll(Object fileRollEvent);
}



class RecordingFileRollEventListener implements FileRollEventListener
{
   int rollCount = 0;

   public void onFileRoll(Object fileRollEvent)
   {
      rollCount++;
   }
}





interface FileRollable
{
   void roll(LoggingEvent event);

   void addFileRollEventListener(FileRollEventListener listener);

   void removeFileRollEventListener(FileRollEventListener listener);
}










class CompositeRoller implements FileRollable
{
   private final List<FileRollEventListener> listeners = new ArrayList<FileRollEventListener>();
   private int rollCount = 0;

   CompositeRoller(FoundationFileRollingAppender appender, AppenderRollingProperties properties)
   {
   }

   public void roll(LoggingEvent event)
   {
      rollCount++;
      for (FileRollEventListener l : listeners)
      {
         l.onFileRoll(event);
      }
   }

   public void addFileRollEventListener(FileRollEventListener listener)
   {
      if (listener != null && !listeners.contains(listener))
      {
         listeners.add(listener);
      }
   }

   public void removeFileRollEventListener(FileRollEventListener listener)
   {
      listeners.remove(listener);
   }

   List<FileRollEventListener> getListeners()
   {
      return listeners;
   }

   int getRollCount()
   {
      return rollCount;
   }
}






interface LogFileScavenger
{
   void init(FoundationFileRollingAppender appender, AppenderRollingProperties properties);

   void begin();

   void end();

   boolean isStarted();

   boolean isEnded();
}






class DefaultLogFileScavenger implements LogFileScavenger
{
   private boolean started = false;
   private boolean ended = false;

   public void init(FoundationFileRollingAppender appender, AppenderRollingProperties properties)
   {
   }

   public void begin()
   {
      started = true;
   }

   public void end()
   {
      ended = true;
   }

   public boolean isStarted()
   {
      return started;
   }

   public boolean isEnded()
   {
      return ended;
   }
}








class LogFileCompressor implements FileRollEventListener
{
   private boolean started = false;
   private boolean ended = false;
   int rollNotifications = 0;

   LogFileCompressor(FoundationFileRollingAppender appender, AppenderRollingProperties properties)
   {
   }

   void begin()
   {
      started = true;
   }

   void end()
   {
      ended = true;
   }

   boolean isStarted()
   {
      return started;
   }

   boolean isEnded()
   {
      return ended;
   }

   public void onFileRoll(Object fileRollEvent)
   {
      rollNotifications++;
   }
}






class TimeBasedRollEnforcer
{
   private boolean started = false;
   private boolean ended = false;

   TimeBasedRollEnforcer(FoundationFileRollingAppender appender, AppenderRollingProperties properties)
   {
   }

   void begin()
   {
      started = true;
   }

   void end()
   {
      ended = true;
   }

   boolean isStarted()
   {
      return started;
   }

   boolean isEnded()
   {
      return ended;
   }
}





class StartupFileRollEvent extends LoggingEvent
{
}






class LoggingEvent
{
}

abstract class Layout
{
   public abstract String format(LoggingEvent event);
}

class SimpleLayout extends Layout
{
   public String format(LoggingEvent event)
   {
      return String.valueOf(event);
   }
}

abstract class Filter
{
}

class EmptyMessageFilter extends Filter
{
}



abstract class AppenderSkeleton
{
   protected String name;
   protected Layout layout;
   private final List<Filter> filters = new ArrayList<Filter>();

   public String getName()
   {
      return name;
   }

   public void setName(String name)
   {
      this.name = name;
   }

   public Layout getLayout()
   {
      return layout;
   }

   public void setLayout(Layout layout)
   {
      this.layout = layout;
   }

   public void addFilter(Filter filter)
   {
      filters.add(filter);
   }

   public void activateOptions()
   {
      
   }

   public void close()
   {
   }
}






class FileAppender extends AppenderSkeleton
{
   private String fileName;
   private boolean append = true;
   private boolean bufferedIO = false;
   private int bufferSize = 8192;

   public void setFile(String fileName)
   {
      this.fileName = fileName;
   }

   public String getFile()
   {
      return fileName;
   }

   public void setAppend(boolean append)
   {
      this.append = append;
   }

   public boolean getAppend()
   {
      return append;
   }

   public void setBufferedIO(boolean bufferedIO)
   {
      this.bufferedIO = bufferedIO;
   }

   public boolean getBufferedIO()
   {
      return bufferedIO;
   }

   public void setBufferSize(int bufferSize)
   {
      this.bufferSize = bufferSize;
   }

   public int getBufferSize()
   {
      return bufferSize;
   }
}
