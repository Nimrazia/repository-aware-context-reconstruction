






























import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_2_logging_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== FoundationRollEventListener.logState(FileRollEvent) - repository-aware reconstruction ===");
      System.out.println("Repository : foundation-runtime/logging @ cd0a07b3c5b458ecf90ab92a1e0c72a067f5cbd6");
      System.out.println("log4j      : lightweight adaptation (log4j 1.2.17 unavailable offline)");
      System.out.println();

      
      
      
      
      
      
      
      System.out.println("--- Scenario 1: dispatches application-state entries to a *.log appender ---");
      ApplicationState.getAppStateEntriesForTesting().clear();
      ApplicationState.LOGGER.setLevel(Level.DEBUG);
      ApplicationState.setStateForTesting(FoundationLevel.INFO, "Queue depth: 12");
      ApplicationState.setStateForTesting(FoundationLevel.WARN, "Retry budget low");

      Layout originalLayout = new SimpleLayout("[orig] %m");
      RecordingFoundationFileRollingAppender appender = new RecordingFoundationFileRollingAppender("service.log", true, originalLayout);
      FileRollEvent event1 = new FileRollEvent(appender);

      MDC.put("flowCtxt", "flow-123");

      FoundationRollEventListener listener = new FoundationRollEventListener();
      listener.onFileRoll(event1);

      System.out.println("events dispatched to appender : " + appender.dispatched.size());
      for (LoggingEvent le : appender.dispatched)
      {
         System.out.println("  [" + le.getLevel() + "] " + le.getMessage());
      }
      System.out.println("layout restored to original after dispatch : " + (appender.getLayout() == originalLayout));
      System.out.println("MDC flowCtxt restored after dispatch        : " + "flow-123".equals(MDC.get("flowCtxt")));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 2: addApplicationState=false suppresses dispatch ---");
      RecordingFoundationFileRollingAppender appenderNoState = new RecordingFoundationFileRollingAppender("service.log", false, originalLayout);
      FileRollEvent event2 = new FileRollEvent(appenderNoState);
      listener.onFileRoll(event2);
      System.out.println("events dispatched : " + appenderNoState.dispatched.size());
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: file not ending in \"log\" suppresses dispatch ---");
      RecordingFoundationFileRollingAppender appenderArchive = new RecordingFoundationFileRollingAppender("service.log.2024-01-01.gz", true, originalLayout);
      FileRollEvent event3 = new FileRollEvent(appenderArchive);
      listener.onFileRoll(event3);
      System.out.println("events dispatched : " + appenderArchive.dispatched.size());
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 4: entries below the effective log level are filtered ---");
      ApplicationState.getAppStateEntriesForTesting().clear();
      ApplicationState.LOGGER.setLevel(Level.WARN);
      ApplicationState.setStateForTesting(FoundationLevel.DEBUG, "verbose diagnostic - should be filtered");
      ApplicationState.setStateForTesting(FoundationLevel.ERROR, "critical - should pass");
      RecordingFoundationFileRollingAppender appenderFiltered = new RecordingFoundationFileRollingAppender("service.log", true, originalLayout);
      FileRollEvent event4 = new FileRollEvent(appenderFiltered);
      listener.onFileRoll(event4);
      System.out.println("events dispatched : " + appenderFiltered.dispatched.size());
      for (LoggingEvent le : appenderFiltered.dispatched)
      {
         System.out.println("  [" + le.getLevel() + "] " + le.getMessage());
      }
      ApplicationState.LOGGER.setLevel(Level.DEBUG);

      System.out.println();
      System.out.println("=== done ===");
   }
}




interface FileRollEventListener
{
   void onFileRoll(FileRollEvent fileRollEvent);
}





class FoundationRollEventListener implements FileRollEventListener
{
   public void onFileRoll(final FileRollEvent fileRollEvent)
   {
      logState(fileRollEvent);
   }


// ORIGINAL CODESEARCHNET METHOD — START

private void logState(final FileRollEvent fileRollEvent) {


			
			synchronized (this) {
				
				final Collection<ApplicationState.ApplicationStateMessage> entries = ApplicationState.getAppStateEntries();
				for (ApplicationState.ApplicationStateMessage entry : entries) {
                    Level level = ApplicationState.getLog4jLevel(entry.getLevel());
				    if(level.isGreaterOrEqual(ApplicationState.LOGGER.getEffectiveLevel())) {
						final LoggingEvent loggingEvent = new LoggingEvent(ApplicationState.FQCN, ApplicationState.LOGGER, level, entry.getMessage(), null);

						
						Layout current=fileRollEvent.getSource().getLayout();
						
						String flowContext = (String) MDC.get("flowCtxt");
						MDC.remove("flowCtxt");
						
						if(fileRollEvent.getSource().isAddApplicationState() && fileRollEvent.getSource().getFile().endsWith("log")){
							fileRollEvent.dispatchToAppender(loggingEvent);
						}
						
						fileRollEvent.getSource().setLayout(current);
						if (flowContext != null) {
							MDC.put("flowCtxt", flowContext);
						}
						
					}
				}
				
			}
			

	}

// ORIGINAL CODESEARCHNET METHOD — END

}







class ApplicationState
{
   public static final String FQCN = ApplicationState.class.getName() + ".";

   public static final Logger LOGGER = Logger.getLogger(ApplicationState.class);

   private static final Map<Integer, ApplicationStateMessage> appState = new HashMap<Integer, ApplicationStateMessage>();
   private static int nextKey = 0;

   public static Collection<ApplicationStateMessage> getAppStateEntries()
   {
      return appState.values();
   }

   


   static synchronized void setStateForTesting(FoundationLevel level, String message)
   {
      appState.put(nextKey++, new ApplicationStateMessage(level, message));
   }

   static Map<Integer, ApplicationStateMessage> getAppStateEntriesForTesting()
   {
      return appState;
   }

   public static Level getLog4jLevel(FoundationLevel foundationLevel)
   {
      switch (foundationLevel)
      {
         case TRACE:
            return Level.TRACE;
         case DEBUG:
            return Level.DEBUG;
         case INFO:
            return Level.INFO;
         case WARN:
            return Level.WARN;
         case ERROR:
            return Level.ERROR;
         case All:
            return Level.ALL;
         default:
            return Level.ALL;
      }
   }

   public static class ApplicationStateMessage
   {
      private final FoundationLevel level;
      private final String message;

      public ApplicationStateMessage(final FoundationLevel level, final String message)
      {
         this.level = level;
         this.message = message;
      }

      public FoundationLevel getLevel()
      {
         return level;
      }

      public String getMessage()
      {
         return message;
      }
   }
}


enum FoundationLevel
{
   TRACE, DEBUG, INFO, WARN, ERROR, All
}









class FoundationFileRollingAppender
{
   private Layout layout;
   private boolean addApplicationState;
   private String file;

   FoundationFileRollingAppender(String file, boolean addApplicationState, Layout layout)
   {
      this.file = file;
      this.addApplicationState = addApplicationState;
      this.layout = layout;
   }

   public Layout getLayout()
   {
      return layout;
   }

   public void setLayout(Layout layout)
   {
      this.layout = layout;
   }

   public boolean isAddApplicationState()
   {
      return addApplicationState;
   }

   public String getFile()
   {
      return file;
   }
}



class RecordingFoundationFileRollingAppender extends FoundationFileRollingAppender
{
   final List<LoggingEvent> dispatched = new ArrayList<LoggingEvent>();

   RecordingFoundationFileRollingAppender(String file, boolean addApplicationState, Layout layout)
   {
      super(file, addApplicationState, layout);
   }

   void append(LoggingEvent event)
   {
      dispatched.add(event);
   }
}






class FileRollEvent
{
   private final RecordingFoundationFileRollingAppender source;

   FileRollEvent(RecordingFoundationFileRollingAppender source)
   {
      this.source = source;
   }

   FoundationFileRollingAppender getSource()
   {
      return source;
   }

   void dispatchToAppender(final LoggingEvent customLoggingEvent)
   {
      source.append(customLoggingEvent);
   }
}








class LoggingEvent
{
   private final String fqnOfCategoryClass;
   private final Category logger;
   private final Level level;
   private final Object message;
   private final Throwable throwable;

   public LoggingEvent(String fqnOfCategoryClass, Category logger, Level level, Object message, Throwable throwable)
   {
      this.fqnOfCategoryClass = fqnOfCategoryClass;
      this.logger = logger;
      this.level = level;
      this.message = message;
      this.throwable = throwable;
   }

   public Category getLogger()
   {
      return logger;
   }

   public Level getLevel()
   {
      return level;
   }

   public Object getMessage()
   {
      return message;
   }
}

class Level
{
   public static final Level ALL = new Level(Integer.MIN_VALUE, "ALL");
   public static final Level TRACE = new Level(5000, "TRACE");
   public static final Level DEBUG = new Level(10000, "DEBUG");
   public static final Level INFO = new Level(20000, "INFO");
   public static final Level WARN = new Level(30000, "WARN");
   public static final Level ERROR = new Level(40000, "ERROR");
   public static final Level FATAL = new Level(50000, "FATAL");

   private final int level;
   private final String name;

   private Level(int level, String name)
   {
      this.level = level;
      this.name = name;
   }

   public int toInt()
   {
      return level;
   }

   public boolean isGreaterOrEqual(Level other)
   {
      return this.level >= other.level;
   }

   @Override
   public String toString()
   {
      return name;
   }
}

class Category
{
   private final String name;
   protected Level level = Level.DEBUG;

   protected Category(String name)
   {
      this.name = name;
   }

   public String getName()
   {
      return name;
   }

   public void setLevel(Level level)
   {
      this.level = level;
   }

   public Level getEffectiveLevel()
   {
      return level;
   }
}

class Logger extends Category
{
   private static final Map<String, Logger> LOGGERS = new HashMap<String, Logger>();

   private Logger(String name)
   {
      super(name);
   }

   public static synchronized Logger getLogger(String name)
   {
      Logger logger = LOGGERS.get(name);
      if (logger == null)
      {
         logger = new Logger(name);
         LOGGERS.put(name, logger);
      }
      return logger;
   }

   public static Logger getLogger(Class<?> clazz)
   {
      return getLogger(clazz.getName());
   }
}


abstract class Layout
{
   public abstract String format(LoggingEvent event);
}

class SimpleLayout extends Layout
{
   private final String pattern;

   SimpleLayout(String pattern)
   {
      this.pattern = pattern;
   }

   public String format(LoggingEvent event)
   {
      return pattern.replace("%m", String.valueOf(event.getMessage()));
   }
}




class MDC
{
   private static final ThreadLocal<Map<String, Object>> CONTEXT = new ThreadLocal<Map<String, Object>>()
   {
      protected Map<String, Object> initialValue()
      {
         return new HashMap<String, Object>();
      }
   };

   public static void put(String key, Object value)
   {
      CONTEXT.get().put(key, value);
   }

   public static Object get(String key)
   {
      return CONTEXT.get().get(key);
   }

   public static void remove(String key)
   {
      CONTEXT.get().remove(key);
   }
}
