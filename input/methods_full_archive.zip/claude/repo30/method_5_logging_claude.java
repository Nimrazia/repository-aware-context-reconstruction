































import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_5_logging_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== FoundationLogger.updateSniffingLoggersLevel(Logger) - repository-aware reconstruction ===");
      System.out.println("Repository : foundation-runtime/logging @ cd0a07b3c5b458ecf90ab92a1e0c72a067f5cbd6");
      System.out.println("log4j / jdom : lightweight adaptations (both unavailable offline)");
      System.out.println();

      Logger callerLogger = Logger.getLogger("com.example.Init");

      
      
      
      
      
      System.out.println("--- Scenario 1: no /sniffingLogger.xml on the classpath ---");
      File resourceFile = classpathResourceFile();
      resourceFile.delete();
      Logger someLogger = Logger.getLogger("com.example.Sniffed");
      someLogger.setLevel(Level.INFO);
      FoundationLogger.updateSniffingLoggersLevelForTesting(callerLogger);
      System.out.println("com.example.Sniffed level unchanged (still INFO) : "
            + (someLogger.getEffectiveLevel() == Level.INFO));
      System.out.println();

      
      
      
      
      
      
      
      
      
      System.out.println("--- Scenario 2: sniffingLogger.xml lists two loggers ---");
      writeFile(resourceFile,
            "<sniffingLoggers>\n"
                  + "  <sniffingLogger id=\"com.example.dao.OrderDao\"/>\n"
                  + "  <sniffingLogger id=\"com.example.service.PaymentService\"/>\n"
                  + "</sniffingLoggers>\n");
      Logger orderDaoLogger = Logger.getLogger("com.example.dao.OrderDao");
      Logger paymentServiceLogger = Logger.getLogger("com.example.service.PaymentService");
      Logger untouchedLogger = Logger.getLogger("com.example.Untouched");
      orderDaoLogger.setLevel(Level.WARN);
      paymentServiceLogger.setLevel(Level.ERROR);
      untouchedLogger.setLevel(Level.INFO);

      FoundationLogger.updateSniffingLoggersLevelForTesting(callerLogger);

      System.out.println("OrderDao level after call        : " + orderDaoLogger.getEffectiveLevel());
      System.out.println("PaymentService level after call   : " + paymentServiceLogger.getEffectiveLevel());
      System.out.println("Untouched logger level unchanged  : " + untouchedLogger.getEffectiveLevel());
      System.out.println("both sniffed loggers now TRACE     : "
            + (orderDaoLogger.getEffectiveLevel() == Level.TRACE && paymentServiceLogger.getEffectiveLevel() == Level.TRACE));
      System.out.println("untouched logger still INFO        : " + (untouchedLogger.getEffectiveLevel() == Level.INFO));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: malformed sniffingLogger.xml ---");
      writeFile(resourceFile, "<sniffingLoggers><sniffingLogger id=\"unterminated\n");
      try
      {
         FoundationLogger.updateSniffingLoggersLevelForTesting(callerLogger);
         System.out.println("!! expected IllegalArgumentException");
      }
      catch (IllegalArgumentException e)
      {
         System.out.println("IllegalArgumentException correctly thrown : " + e.getMessage());
         System.out.println("cause is the underlying parse failure      : " + (e.getCause() != null));
      }
      resourceFile.delete();

      System.out.println();
      System.out.println("=== done ===");
   }

   private static File classpathResourceFile() throws Exception
   {
      File runningClassDir = new File(method_5_logging_claude.class
            .getProtectionDomain().getCodeSource().getLocation().toURI());
      return new File(runningClassDir, "sniffingLogger.xml");
   }

   private static void writeFile(File f, String content) throws Exception
   {
      try (java.io.FileWriter w = new java.io.FileWriter(f))
      {
         w.write(content);
      }
   }
}






class FoundationLogger
{
   static void updateSniffingLoggersLevelForTesting(Logger logger)
   {
      updateSniffingLoggersLevel(logger);
   }


// ORIGINAL CODESEARCHNET METHOD — START

private static void updateSniffingLoggersLevel(Logger logger) {

		InputStream settingIS = FoundationLogger.class
				.getResourceAsStream("/sniffingLogger.xml");
		if (settingIS == null) {
			logger.debug("file sniffingLogger.xml not found in classpath");
		} else {
			try {
				SAXBuilder builder = new SAXBuilder();
				Document document = builder.build(settingIS);
				settingIS.close();
				Element rootElement = document.getRootElement();
				List<Element> sniffingloggers = rootElement
						.getChildren("sniffingLogger");
				for (Element sniffinglogger : sniffingloggers) {
					String loggerName = sniffinglogger.getAttributeValue("id");
					Logger.getLogger(loggerName).setLevel(Level.TRACE);
				}
			} catch (Exception e) {
				logger.error(
						"cannot load the sniffing logger configuration file. error is: "
								+ e, e);
				throw new IllegalArgumentException(
						"Problem parsing sniffingLogger.xml", e);
			}
		}

	}

// ORIGINAL CODESEARCHNET METHOD — END

}












class Element
{
   private final String name;
   private final Map<String, String> attributes = new HashMap<String, String>();
   private final List<Element> children = new ArrayList<Element>();

   Element(String name)
   {
      this.name = name;
   }

   Element setAttribute(String key, String value)
   {
      attributes.put(key, value);
      return this;
   }

   String getAttributeValue(String key)
   {
      return attributes.get(key);
   }

   Element addContent(Element child)
   {
      children.add(child);
      return this;
   }

   List<Element> getChildren(String childName)
   {
      List<Element> result = new ArrayList<Element>();
      for (Element c : children)
      {
         if (c.name.equals(childName))
         {
            result.add(c);
         }
      }
      return result;
   }
}

class Document
{
   private final Element root;

   Document(Element root)
   {
      this.root = root;
   }

   Element getRootElement()
   {
      return root;
   }
}

class SAXBuilder
{
   Document build(InputStream is) throws Exception
   {
      String xml = new String(is.readAllBytes(), "UTF-8");
      
      
      int openCount = 0;
      int closeCount = 0;
      for (char c : xml.toCharArray())
      {
         if (c == '<')
         {
            openCount++;
         }
         else if (c == '>')
         {
            closeCount++;
         }
      }
      if (openCount != closeCount || openCount == 0)
      {
         throw new Exception("XML parsing error: unterminated or empty element in sniffingLogger.xml");
      }
      Element root = new Element("sniffingLoggers");
      java.util.regex.Matcher m = java.util.regex.Pattern
            .compile("<sniffingLogger\\s+id=\"([^\"]+)\"\\s*/>")
            .matcher(xml);
      while (m.find())
      {
         root.addContent(new Element("sniffingLogger").setAttribute("id", m.group(1)));
      }
      return new Document(root);
   }
}







class Level
{
   public static final Level TRACE = new Level(5000, "TRACE");
   public static final Level DEBUG = new Level(10000, "DEBUG");
   public static final Level INFO = new Level(20000, "INFO");
   public static final Level WARN = new Level(30000, "WARN");
   public static final Level ERROR = new Level(40000, "ERROR");

   private final int level;
   private final String name;

   private Level(int level, String name)
   {
      this.level = level;
      this.name = name;
   }

   @Override
   public String toString()
   {
      return name;
   }
}

class Logger
{
   private static final Map<String, Logger> LOGGERS = new HashMap<String, Logger>();

   private final String name;
   private Level level = Level.DEBUG;

   private Logger(String name)
   {
      this.name = name;
   }

   public static synchronized Logger getLogger(String name)
   {
      Logger logger = LOGGERS.get(name);
      if (logger == null)
      {
         logger = new Logger(name);
         LOGGERS.put(name, logger);
      }
      return logger;
   }

   public void setLevel(Level level)
   {
      this.level = level;
   }

   public Level getEffectiveLevel()
   {
      return level;
   }

   public void debug(String message)
   {
      System.out.println("[DEBUG] " + name + " - " + message);
   }

   public void error(String message, Throwable t)
   {
      System.out.println("[ERROR] " + name + " - " + message);
   }
}
