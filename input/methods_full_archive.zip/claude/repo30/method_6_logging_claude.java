



























import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

public class method_6_logging_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== FoundationHierarchyEventListener.addAppenderEvent(Category,Appender) - repository-aware reconstruction ===");
      System.out.println("Repository : foundation-runtime/logging @ cd0a07b3c5b458ecf90ab92a1e0c72a067f5cbd6");
      System.out.println("log4j      : lightweight adaptation (log4j 1.2.17 unavailable offline)");
      System.out.println();

      FoundationHierarchyEventListener listener = new FoundationHierarchyEventListener();
      Category cat = Category.getInstance("com.example.Service");

      
      
      
      
      
      
      System.out.println("--- Scenario 1: plain appender, no layout -> default layout installed ---");
      ConsoleAppender plainAppender = new ConsoleAppender("console");
      System.out.println("layout before : " + plainAppender.getLayout());
      listener.addAppenderEvent(cat, plainAppender);
      System.out.println("layout after  : " + plainAppender.getLayout());
      System.out.println("default FoundationLoggingPatternLayout installed : "
            + (plainAppender.getLayout() instanceof FoundationLoggingPatternLayout));
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 2: EnhancedPatternLayout with default pattern gets overridden ---");
      ConsoleAppender enhancedAppender = new ConsoleAppender("enhanced");
      EnhancedPatternLayout enhancedLayout = new EnhancedPatternLayout(EnhancedPatternLayout.DEFAULT_CONVERSION_PATTERN);
      enhancedAppender.setLayout(enhancedLayout);
      listener.addAppenderEvent(cat, enhancedAppender);
      System.out.println("conversion pattern after : " + enhancedLayout.getConversionPattern());
      System.out.println("overridden to Foundation default : "
            + FoundationLoggerConstants.DEFAULT_CONV_PATTERN.toString().equals(enhancedLayout.getConversionPattern()));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 3: custom PatternLayout pattern is preserved ---");
      ConsoleAppender customAppender = new ConsoleAppender("custom");
      PatternLayout customLayout = new PatternLayout("%d [%t] %-5p %c - %m%n");
      customAppender.setLayout(customLayout);
      listener.addAppenderEvent(cat, customAppender);
      System.out.println("pattern unchanged : " + "%d [%t] %-5p %c - %m%n".equals(customLayout.getConversionPattern()));
      System.out.println();

      
      
      
      
      
      
      System.out.println("--- Scenario 4: FoundationFileRollingAppender gets archiving + defaults ---");
      FoundationLogger.log4jConfigProps = new java.util.Properties();
      FoundationLogger.log4jConfigProps.setProperty(FoundationLoggerConstants.Foundation_FILE_ARCHIVE.toString(), "true");
      FoundationFileRollingAppender rollingAppender = new FoundationFileRollingAppender("fileAppender");
      listener.addAppenderEvent(cat, rollingAppender);
      System.out.println("compression algorithm chosen (non-Windows -> gz) : " + rollingAppender.getCompressionAlgorithm());
      System.out.println("date pattern defaulted     : " + rollingAppender.getDatePattern());
      System.out.println("max file size defaulted    : " + rollingAppender.getMaxFileSize());
      System.out.println("max roll file count default: " + rollingAppender.getMaxRollFileCount());
      System.out.println();

      
      
      
      
      
      
      System.out.println("--- Scenario 5: async wrapping via Foundation_ASYNC_REF ---");
      FoundationLogger.log4jConfigProps.setProperty(FoundationLoggerConstants.Foundation_ASYNC_REF.toString(), "[fileAppender]");
      Logger.getRootLogger().addAppender(rollingAppender);
      cat.addAppender(rollingAppender);

      listener.addAppenderEvent(cat, rollingAppender);

      
      
      
      
      
      
      
      Appender onRootByOldName = Logger.getRootLogger().getAppender("fileAppender");
      System.out.println("root no longer resolves the OLD appender name (async has no name) : " + (onRootByOldName == null));
      System.out.println("internal asyncAppenders map now wraps fileAppender in a real AsyncAppender : "
            + listener.hasAsyncWrapperForTesting("fileAppender"));

      System.out.println();
      System.out.println("=== done ===");
   }
}




class FoundationHierarchyEventListener implements HierarchyEventListener
{
   private static HashMap<String, AsyncAppender> asyncAppenders = new HashMap<String, AsyncAppender>();

   private static final int Foundation_MAX_ROLL_COUNT = 100;

   private static final int LOG4J_MAX_ROLL_COUNT = 10;

   


   boolean hasAsyncWrapperForTesting(String appenderName)
   {
      return asyncAppenders.containsKey(appenderName);
   }


// ORIGINAL CODESEARCHNET METHOD — START

public void addAppenderEvent(final Category cat, final Appender appender) {

		updateDefaultLayout(appender);

		if (appender instanceof FoundationFileRollingAppender) {
			final FoundationFileRollingAppender timeSizeRollingAppender = (FoundationFileRollingAppender) appender;

			
			

			
			updateArchivingSupport(timeSizeRollingAppender);

			
			
			timeSizeRollingAppender.setFileRollEventListener(FoundationRollEventListener.class.getName());

			boolean rollOnStartup = true;

			if (FoundationLogger.log4jConfigProps != null && FoundationLogger.log4jConfigProps.containsKey(FoundationLoggerConstants.Foundation_ROLL_ON_STARTUP.toString())) {
				rollOnStartup = Boolean.valueOf(FoundationLogger.log4jConfigProps.getProperty(FoundationLoggerConstants.Foundation_ROLL_ON_STARTUP.toString()));
			}

			timeSizeRollingAppender.setRollOnStartup(rollOnStartup);

			
			timeSizeRollingAppender.activateOptions();

			
		

		}else if(!(appender instanceof FoundationFileRollingAppender) && (appender instanceof TimeAndSizeRollingAppender)){ 
			final TimeAndSizeRollingAppender timeSizeRollingAppender = (TimeAndSizeRollingAppender) appender;

			
			updateDefaultTimeAndSizeRollingAppender(timeSizeRollingAppender);

			
			updateArchivingSupport(timeSizeRollingAppender);

			
			
			timeSizeRollingAppender.setFileRollEventListener(FoundationRollEventListener.class.getName());

			boolean rollOnStartup = true;

			if (FoundationLogger.log4jConfigProps != null && FoundationLogger.log4jConfigProps.containsKey(FoundationLoggerConstants.Foundation_ROLL_ON_STARTUP.toString())) {
				rollOnStartup = Boolean.valueOf(FoundationLogger.log4jConfigProps.getProperty(FoundationLoggerConstants.Foundation_ROLL_ON_STARTUP.toString()));
			}

			timeSizeRollingAppender.setRollOnStartup(rollOnStartup);

			
			timeSizeRollingAppender.activateOptions();

			
		
		}
		if ( ! (appender instanceof AsyncAppender))
            initiateAsyncSupport(appender);

	}

// ORIGINAL CODESEARCHNET METHOD — END


   public void initiateAsyncSupport(final Appender appender)
   {
      final String asyncAppenderReferencesKey = FoundationLoggerConstants.Foundation_ASYNC_REF.toString();

      if (FoundationLogger.log4jConfigProps != null && FoundationLogger.log4jConfigProps.containsKey(asyncAppenderReferencesKey))
      {
         String asyncAppenderReferences = FoundationLogger.log4jConfigProps.getProperty(asyncAppenderReferencesKey);
         String[] asyncAppenderReferencesList = asyncAppenderReferences.split(",");

         for (String asyncAppenderRef : asyncAppenderReferencesList)
         {
            if (!(asyncAppenderRef.startsWith("[") && asyncAppenderRef.endsWith("]")))
            {
               System.err.println("could not parse async appender ref. Illegal format. " + asyncAppenderRef);
               continue;
            }
            else
            {
               asyncAppenderRef = asyncAppenderRef.substring(1, asyncAppenderRef.lastIndexOf("]"));

               if (appender.getName().equals(asyncAppenderRef))
               {
                  Appender appenderRefInAsync = asyncAppenders.get(appender.getName());

                  if (appenderRefInAsync != null)
                  {
                     asyncAppenders.remove(appender.getName());
                  }
                  AsyncAppender async = createAsyncAppender();
                  async.addAppender(appender);
                  async.activateOptions();
                  asyncAppenders.put(appender.getName(), async);

                  Enumeration currentLoggers = LogManager.getLoggerRepository().getCurrentLoggers();
                  while (currentLoggers.hasMoreElements())
                  {
                     Logger logger = (Logger) currentLoggers.nextElement();
                     if (logger.getAppender(appender.getName()) != null)
                     {
                        logger.removeAppender(appender.getName());
                        logger.addAppender(async);
                     }
                  }

                  if (LogManager.getRootLogger().getAppender(appender.getName()) != null)
                  {
                     LogManager.getRootLogger().removeAppender(appender.getName());
                     LogManager.getRootLogger().addAppender(async);
                  }
               }
            }
         }
      }
   }

   private AsyncAppender createAsyncAppender()
   {
      AsyncAppender asyncAppender = new AsyncAppender();
      String bufferSize = FoundationLogger.log4jConfigProps.getProperty(FoundationLoggerConstants.Foundation_ASYNC_BUFFER_SIZE.toString(), "2500");
      try
      {
         asyncAppender.setBufferSize(Integer.parseInt(bufferSize));
      }
      catch (NumberFormatException e)
      {
         asyncAppender.setBufferSize(2500);
      }
      return asyncAppender;
   }

   private void updateArchivingSupport(final FoundationFileRollingAppender timeSizeRollingAppender)
   {
      boolean shouldArchive = true;

      final String foundationFileArchiveKey = FoundationLoggerConstants.Foundation_FILE_ARCHIVE.toString();

      if (FoundationLogger.log4jConfigProps != null && FoundationLogger.log4jConfigProps.containsKey(foundationFileArchiveKey))
      {
         shouldArchive = Boolean.valueOf(FoundationLogger.log4jConfigProps.getProperty(foundationFileArchiveKey));
      }

      if (shouldArchive)
      {
         if (OperatingSystem.getOperatingSystem().equals(OperatingSystem.Windows))
         {
            timeSizeRollingAppender.setCompressionAlgorithm(FoundationLoggerConstants.ZIP.toString());
         }
         else
         {
            timeSizeRollingAppender.setCompressionAlgorithm(FoundationLoggerConstants.GZIP.toString());
         }
      }
   }

   private void updateDefaultTimeAndSizeRollingAppender(final FoundationFileRollingAppender appender)
   {
      if (appender.getDatePattern().trim().length() == 0)
      {
         appender.setDatePattern(FoundationLoggerConstants.DEFAULT_DATE_PATTERN.toString());
      }

      String maxFileSizeKey = "log4j.appender." + appender.getName() + ".MaxFileSize";
      appender.setMaxFileSize(FoundationLogger.log4jConfigProps.getProperty(maxFileSizeKey, FoundationLoggerConstants.Foundation_MAX_FILE_SIZE.toString()));

      String maxRollCountKey = "log4j.appender." + appender.getName() + ".MaxRollFileCount";
      appender.setMaxRollFileCount(Integer.parseInt(FoundationLogger.log4jConfigProps.getProperty(maxRollCountKey, "100")));
   }

   private void updateDefaultLayout(final Appender appender)
   {
      Layout layout = appender.getLayout();

      if (layout == null)
      {
         layout = new FoundationLoggingPatternLayout();
         appender.setLayout(layout);
      }

      if (layout instanceof EnhancedPatternLayout)
      {
         final EnhancedPatternLayout enhancedPatternLayout = (EnhancedPatternLayout) layout;
         String conversionPattern = enhancedPatternLayout.getConversionPattern();

         if (shouldUpdatePattern(conversionPattern))
         {
            conversionPattern = FoundationLoggerConstants.DEFAULT_CONV_PATTERN.toString();
            enhancedPatternLayout.setConversionPattern(conversionPattern);
         }
      }
      else if (layout instanceof PatternLayout)
      {
         final PatternLayout patternLayout = (PatternLayout) layout;
         String conversionPattern = patternLayout.getConversionPattern();

         if (shouldUpdatePattern(conversionPattern))
         {
            conversionPattern = FoundationLoggerConstants.DEFAULT_CONV_PATTERN.toString();
            patternLayout.setConversionPattern(conversionPattern);
         }
      }
   }

   private boolean shouldUpdatePattern(final String conversionPattern)
   {
      return conversionPattern == null || conversionPattern.equals(FoundationLoggingPatternLayout.DEFAULT_CONVERSION_PATTERN) || conversionPattern.equals(PatternLayout.DEFAULT_CONVERSION_PATTERN) || conversionPattern.equals("");
   }
}





enum FoundationLoggerConstants
{
   GZIP("gz"),
   ZIP("zip"),
   Foundation_MAX_FILE_SIZE("104857600"),
   DEFAULT_DATE_PATTERN(".yyyy-MM-dd"),
   DEFAULT_CONV_PATTERN("%d{yyyy/MM/dd HH:mm:ss.SSS}{UTC} [%c{1}] [%t]:  %audit %p: [%X{flowCtxt}] %sl %errorcode %throwable{full} %n"),
   Foundation_FILE_ARCHIVE("FoundationfileArchive"),
   Foundation_ROLL_ON_STARTUP("FoundationrollOnStartup"),
   Foundation_ASYNC_REF("FoundationasyncAppenderRef"),
   Foundation_ASYNC_BUFFER_SIZE("FoundationasyncBufferSize");

   private final String value;

   FoundationLoggerConstants(String value)
   {
      this.value = value;
   }

   @Override
   public String toString()
   {
      return value;
   }
}




class FoundationLogger
{
   static java.util.Properties log4jConfigProps = null;
}




class FoundationRollEventListener
{
}




final class OperatingSystem
{
   static final OperatingSystem Windows = new OperatingSystem("Windows");
   static final OperatingSystem Linux = new OperatingSystem("Linux");

   private final String name;

   private OperatingSystem(String name)
   {
      this.name = name;
   }

   static OperatingSystem getOperatingSystem()
   {
      String osName = System.getProperty("os.name", "").toLowerCase();
      return osName.contains("win") ? Windows : Linux;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof OperatingSystem) && ((OperatingSystem) o).name.equals(name);
   }

   @Override
   public int hashCode()
   {
      return name.hashCode();
   }
}



















class FoundationFileRollingAppender extends AppenderSkeleton
{
   private String fileRollEventListener;
   private boolean rollOnStartup;
   private String compressionAlgorithm;
   private String datePattern = "";
   private String maxFileSize;
   private int maxRollFileCount;

   FoundationFileRollingAppender(String name)
   {
      setName(name);
   }

   void setFileRollEventListener(String className)
   {
      this.fileRollEventListener = className;
   }

   void setRollOnStartup(boolean rollOnStartup)
   {
      this.rollOnStartup = rollOnStartup;
   }

   void activateOptions()
   {
      
   }

   void setCompressionAlgorithm(String algorithm)
   {
      this.compressionAlgorithm = algorithm;
   }

   String getCompressionAlgorithm()
   {
      return compressionAlgorithm;
   }

   String getDatePattern()
   {
      return datePattern;
   }

   void setDatePattern(String datePattern)
   {
      this.datePattern = datePattern;
   }

   void setMaxFileSize(String maxFileSize)
   {
      this.maxFileSize = maxFileSize;
   }

   String getMaxFileSize()
   {
      return maxFileSize;
   }

   void setMaxRollFileCount(int count)
   {
      this.maxRollFileCount = count;
   }

   int getMaxRollFileCount()
   {
      return maxRollFileCount;
   }
}









interface HierarchyEventListener
{
   void addAppenderEvent(Category cat, Appender appender);
}

abstract class Layout
{
}

class FoundationLoggingPatternLayout extends Layout
{
   static final String DEFAULT_CONVERSION_PATTERN = "%m%n";
}

class PatternLayout extends Layout
{
   static final String DEFAULT_CONVERSION_PATTERN = "%m%n";

   private String conversionPattern;

   PatternLayout()
   {
      this(DEFAULT_CONVERSION_PATTERN);
   }

   PatternLayout(String conversionPattern)
   {
      this.conversionPattern = conversionPattern;
   }

   String getConversionPattern()
   {
      return conversionPattern;
   }

   void setConversionPattern(String conversionPattern)
   {
      this.conversionPattern = conversionPattern;
   }
}

class EnhancedPatternLayout extends PatternLayout
{
   EnhancedPatternLayout(String conversionPattern)
   {
      super(conversionPattern);
   }
}

interface Appender
{
   String getName();

   void setName(String name);

   Layout getLayout();

   void setLayout(Layout layout);
}

class AppenderSkeleton implements Appender
{
   private String name;
   private Layout layout;

   public String getName()
   {
      return name;
   }

   public void setName(String name)
   {
      this.name = name;
   }

   public Layout getLayout()
   {
      return layout;
   }

   public void setLayout(Layout layout)
   {
      this.layout = layout;
   }
}

class ConsoleAppender extends AppenderSkeleton
{
   ConsoleAppender(String name)
   {
      setName(name);
   }
}











class TimeAndSizeRollingAppender extends FoundationFileRollingAppender
{
   TimeAndSizeRollingAppender(String name)
   {
      super(name);
   }
}

class AsyncAppender extends AppenderSkeleton
{
   private int bufferSize = 128;
   private final java.util.Vector<Appender> wrapped = new java.util.Vector<Appender>();

   void setBufferSize(int size)
   {
      this.bufferSize = size;
   }

   void addAppender(Appender a)
   {
      wrapped.add(a);
   }

   void activateOptions()
   {
   }
}

class Category
{
   private final String name;
   private final Map<String, Appender> appenders = new HashMap<String, Appender>();

   protected Category(String name)
   {
      this.name = name;
   }

   static Category getInstance(String name)
   {
      return new Category(name);
   }

   String getName()
   {
      return name;
   }

   void addAppender(Appender a)
   {
      appenders.put(a.getName(), a);
   }

   void removeAppender(String appenderName)
   {
      appenders.remove(appenderName);
   }

   Appender getAppender(String appenderName)
   {
      return appenders.get(appenderName);
   }
}

class Logger extends Category
{
   private Logger(String name)
   {
      super(name);
   }

   static Logger getLogger(String name)
   {
      return LogManager.getLoggerRepositoryInternal().getOrCreateLogger(name);
   }

   static Logger getRootLogger()
   {
      return LogManager.getLoggerRepositoryInternal().getRoot();
   }
}





class LogManager
{
   private static final SimpleLoggerRepository REPO = new SimpleLoggerRepository();

   static Logger getRootLogger()
   {
      return REPO.getRoot();
   }

   static SimpleLoggerRepository getLoggerRepository()
   {
      return REPO;
   }

   static SimpleLoggerRepository getLoggerRepositoryInternal()
   {
      return REPO;
   }
}

class SimpleLoggerRepository
{
   private final Map<String, Logger> loggers = new HashMap<String, Logger>();
   private final Logger root;

   SimpleLoggerRepository()
   {
      try
      {
         java.lang.reflect.Constructor<Logger> ctor = Logger.class.getDeclaredConstructor(String.class);
         ctor.setAccessible(true);
         root = ctor.newInstance("root");
      }
      catch (Exception e)
      {
         throw new RuntimeException(e);
      }
   }

   Logger getRoot()
   {
      return root;
   }

   synchronized Logger getOrCreateLogger(String name)
   {
      Logger logger = loggers.get(name);
      if (logger == null)
      {
         try
         {
            java.lang.reflect.Constructor<Logger> ctor = Logger.class.getDeclaredConstructor(String.class);
            ctor.setAccessible(true);
            logger = ctor.newInstance(name);
         }
         catch (Exception e)
         {
            throw new RuntimeException(e);
         }
         loggers.put(name, logger);
      }
      return logger;
   }

   Enumeration getCurrentLoggers()
   {
      return java.util.Collections.enumeration(loggers.values());
   }
}
