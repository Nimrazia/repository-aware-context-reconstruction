



























import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public class method_7_logging_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== TransactionLogger.addPropertiesProcessingTime() - repository-aware reconstruction ===");
      System.out.println("Repository : foundation-runtime/logging @ cd0a07b3c5b458ecf90ab92a1e0c72a067f5cbd6");
      System.out.println("slf4j      : lightweight adaptation (unavailable offline)");
      System.out.println();

      TestTransactionLogger.loggingKeys = new LoggingKeysHandler();
      TestTransactionLogger.loggingKeys.put("dbCall", "DB_CALL_TIME");
      

      
      
      
      
      
      
      System.out.println("--- Scenario 1: single-threaded components, max-time-per-type semantics ---");
      TestTransactionLogger tx1 = new TestTransactionLogger();
      tx1.startTotalTimer();

      tx1.recordComponent("dbCall", 40);
      tx1.recordComponent("dbCall", 120); 
      tx1.recordComponent("httpCall", 75);

      tx1.stopTotalTimer();
      tx1.addPropertiesProcessingTimeForTesting();

      System.out.println("properties recorded : " + tx1.getPropertiesForTesting());
      System.out.println("dbCall mapped through loggingKeys to DB_CALL_TIME : "
            + tx1.getPropertiesForTesting().containsKey("DB_CALL_TIME"));
      System.out.println("dbCall time reflects the MAX of {40,120}, not the sum : "
            + "120ms".equals(tx1.getPropertiesForTesting().get("DB_CALL_TIME")));
      System.out.println("dbCall invocation count property is NOT emitted for single-threaded components");
      System.out.println("  (the original method only calls addInvocationPerComponent inside the");
      System.out.println("   componentsMultiThread branch, never for the plain components loop) : "
            + !tx1.getPropertiesForTesting().containsKey("dbCall_Invocations"));
      System.out.println("httpCall falls back to its raw key (unmapped) : "
            + tx1.getPropertiesForTesting().containsKey("httpCall"));
      System.out.println("Total component present : " + tx1.getPropertiesForTesting().containsKey("Total"));
      System.out.println();

      
      
      
      
      
      
      System.out.println("--- Scenario 2: multi-threaded components are also aggregated ---");
      TestTransactionLogger tx2 = new TestTransactionLogger();
      tx2.startTotalTimer();
      tx2.recordMultiThreadComponent("workerTask", 60);
      tx2.recordMultiThreadComponent("workerTask", 200); 
      tx2.recordComponent("mainThreadTask", 15);
      tx2.stopTotalTimer();
      tx2.addPropertiesProcessingTimeForTesting();

      System.out.println("properties recorded : " + tx2.getPropertiesForTesting());
      System.out.println("workerTask (from componentsMultiThread) present : "
            + tx2.getPropertiesForTesting().containsKey("workerTask"));
      System.out.println("workerTask time reflects MAX of {60,200}, not the sum (allowing sleep jitter) : "
            + isApproximately(tx2.getPropertiesForTesting().get("workerTask"), 200, 15));
      System.out.println("mainThreadTask (from components) also present    : "
            + tx2.getPropertiesForTesting().containsKey("mainThreadTask"));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 3: printTimeUnits=false changes duration formatting ---");
      TestTransactionLogger.setPrintTimeUnitsForTesting(false);
      TestTransactionLogger tx3 = new TestTransactionLogger();
      tx3.startTotalTimer();
      tx3.recordComponent("dbCall", 33);
      tx3.stopTotalTimer();
      tx3.addPropertiesProcessingTimeForTesting();
      System.out.println("DB_CALL_TIME without unit suffix : " + tx3.getPropertiesForTesting().get("DB_CALL_TIME"));
      System.out.println("no 'ms' suffix present            : "
            + !tx3.getPropertiesForTesting().get("DB_CALL_TIME").contains("ms"));
      TestTransactionLogger.setPrintTimeUnitsForTesting(true);

      System.out.println();
      System.out.println("=== done ===");
   }

   private static boolean isApproximately(String durationWithMs, long expected, long toleranceMillis)
   {
      long actual = Long.parseLong(durationWithMs.replace("ms", ""));
      return Math.abs(actual - expected) <= toleranceMillis;
   }
}




class TestTransactionLogger extends TransactionLogger
{
   void startTotalTimer()
   {
      totalForTesting().startTimer();
   }

   void stopTotalTimer()
   {
      totalForTesting().pauseTimer();
   }

   void recordComponent(String type, long millis)
   {
      Component c = new Component(type);
      c.startTimer();
      sleepFor(millis);
      c.pauseTimer();
      componentsForTesting().put(type + "#" + componentsForTesting().size(), c);
   }

   void recordMultiThreadComponent(String type, long millis)
   {
      Component c = new Component(type);
      c.startTimer();
      sleepFor(millis);
      c.pauseTimer();
      componentsMultiThreadForTesting().getComponents().add(c);
   }

   private void sleepFor(long millis)
   {
      try
      {
         Thread.sleep(millis);
      }
      catch (InterruptedException e)
      {
         Thread.currentThread().interrupt();
      }
   }

   void addPropertiesProcessingTimeForTesting()
   {
      addPropertiesProcessingTime();
   }

   Map<String, String> getPropertiesForTesting()
   {
      return propertiesForTesting();
   }
}





abstract class TransactionLogger
{
   protected final static String TOTAL_COMPONENT = "Total";

   protected static String separator = " | ";
   protected static boolean printTimeUnits = true;
   protected static LoggingKeysHandler loggingKeys;

   protected Map<String, String> properties = new LinkedHashMap<String, String>();

   private Map<String, Component> components = new LinkedHashMap<String, Component>();
   private ComponentsMultiThread componentsMultiThread = new ComponentsMultiThread();
   private Component total = new Component(TOTAL_COMPONENT);

   static void setPrintTimeUnitsForTesting(boolean value)
   {
      printTimeUnits = value;
   }

   

   protected Component totalForTesting()
   {
      return total;
   }

   protected Map<String, Component> componentsForTesting()
   {
      return components;
   }

   protected ComponentsMultiThread componentsMultiThreadForTesting()
   {
      return componentsMultiThread;
   }

   protected Map<String, String> propertiesForTesting()
   {
      return properties;
   }


// ORIGINAL CODESEARCHNET METHOD — START

protected void addPropertiesProcessingTime() {

    HashMap<String, Long> mapComponentTimes			= new HashMap<>();
    HashMap<String, Long> mapComponentInvocations	= new HashMap<>();

    
    if (this.componentsMultiThread != null) {
      for (Component component : this.componentsMultiThread.getComponents()) {
        addTimePerComponent(mapComponentTimes, component);
        addInvocationPerComponent(mapComponentInvocations, component);
      }
    }

    for (Component component : this.components.values()) {
      addTimePerComponent(mapComponentTimes, component);
    }

    for (Entry<String, Long> entry : mapComponentTimes.entrySet()) {
      putProperty(entry.getKey(), addDuration(entry.getValue()));
    }

    for (Entry<String, Long> entry : mapComponentInvocations.entrySet()) {
      putProperty(entry.getKey(), entry.getValue().toString());
    }
    putProperty(TOTAL_COMPONENT, addDuration(this.total.getTime()));
  }

// ORIGINAL CODESEARCHNET METHOD — END


   private String addDuration(Long duration)
   {
      return printTimeUnits ? duration + "ms" : duration.toString();
   }

   private static void addTimePerComponent(HashMap<String, Long> mapComponentTimes, Component component)
   {
      Long currentTimeOfComponent = 0L;
      String key = component.getComponentType();
      if (mapComponentTimes.containsKey(key))
      {
         currentTimeOfComponent = mapComponentTimes.get(key);
      }
      Long maxTime = Math.max(component.getTime(), currentTimeOfComponent);
      mapComponentTimes.put(key, maxTime);
   }

   private static void addInvocationPerComponent(HashMap<String, Long> mapComponentInvocations, Component component)
   {
      Long invocationComponent = 0L;
      String key = component.getComponentType() + "_Invocations";
      if (mapComponentInvocations.containsKey(key))
      {
         invocationComponent = mapComponentInvocations.get(key);
      }
      invocationComponent++;
      mapComponentInvocations.put(key, invocationComponent);
   }

   protected void putProperty(String key, String value)
   {
      String keyName = loggingKeys.getKeyValue(key);
      if (!Objects.equals(keyName, ""))
      {
         this.properties.put(keyName, value);
      }
      else
      {
         this.properties.put(key, value);
      }
   }
}


class Component
{
   private Timer timer;
   private final String componentType;

   public Component(String componentType)
   {
      this.componentType = componentType;
      this.timer = new Timer();
   }

   public long getLastTime()
   {
      return timer.getLastTime();
   }

   public long getTime()
   {
      return timer.getTime();
   }

   public void startTimer()
   {
      timer.start(getComponentType());
   }

   public void pauseTimer()
   {
      timer.pause(getComponentType());
   }

   public void resetTimer()
   {
      timer.reset(getComponentType());
   }

   public String getComponentType()
   {
      return componentType;
   }
}


class Timer
{
   private static final Logger LOGGER = LoggerFactory.getLogger(Timer.class);

   private long startTime = 0;
   private long time = 0;
   private long lastTime = 0;
   private boolean isRunning = false;

   public Timer()
   {
   }

   public void start(String actionName)
   {
      this.startTime = System.currentTimeMillis();
      this.isRunning = true;
      LOGGER.trace("Start {} timer. Running:{} Time:{} (now={}).", actionName, this.isRunning, this.time, this.startTime);
   }

   public void pause(String actionName)
   {
      if (this.isRunning)
      {
         this.isRunning = false;
         long latestTime = System.currentTimeMillis();
         this.lastTime = latestTime - this.startTime;
         this.time += this.lastTime;
         LOGGER.trace("Pause {} timer. Running:{} Time:{} (now={}).", actionName, this.isRunning, this.time, latestTime);
      }
   }

   public void reset(String actionName)
   {
      this.time = 0;
      this.isRunning = false;
      LOGGER.trace("Reset {} timer. Time:{}.", actionName, this.time);
   }

   public long getLastTime()
   {
      return this.lastTime;
   }

   public long getTime()
   {
      return this.time;
   }
}



class ComponentsMultiThread
{
   private List<Component> components = new CopyOnWriteArrayList<Component>();

   public List<Component> getComponents()
   {
      return components;
   }
}








class LoggingKeysHandler
{
   private final Map<String, String> keysMap = new HashMap<String, String>();

   void put(String key, String value)
   {
      keysMap.put(key, value);
   }

   public String getKeyValue(String key)
   {
      String keyName = keysMap.get(key);
      if (keyName != null)
      {
         return keyName;
      }
      return "";
   }

   public int getMapSize()
   {
      return keysMap.size();
   }
}






class Logger
{
   private final String name;

   Logger(String name)
   {
      this.name = name;
   }

   void trace(String pattern, Object... args)
   {
      String message = pattern;
      for (Object arg : args)
      {
         message = message.replaceFirst("\\{\\}", java.util.regex.Matcher.quoteReplacement(String.valueOf(arg)));
      }
      
      
   }
}

class LoggerFactory
{
   static Logger getLogger(Class<?> clazz)
   {
      return new Logger(clazz.getName());
   }
}
