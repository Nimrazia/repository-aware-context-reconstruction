












































import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

public class method_3_logging_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== FoundationLogger.init() - repository-aware reconstruction ===");
      System.out.println("Repository : foundation-runtime/logging @ cd0a07b3c5b458ecf90ab92a1e0c72a067f5cbd6");
      System.out.println("log4j / jdom / commons-lang3 / joda-time : lightweight adaptations (all unavailable offline)");
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 1: init() with log4j.configuration system property set ---");
      File configFile = File.createTempFile("log4j", ".properties");
      configFile.deleteOnExit();
      try (FileWriter w = new FileWriter(configFile))
      {
         w.write("log4j.rootLogger=WARN\n");
         w.write("log4j.logger.com.example.noisy=ERROR\n");
         w.write("FoundationfileReloadDelay=500\n");
         w.write("Foundation_JUL_SUPPORT_ENABLED=false\n");
      }
      System.setProperty("log4j.configuration", configFile.toURI().toURL().toString());

      Logger beforeInit = Logger.getLogger("com.example.Before");
      System.out.println("logger repository identity before init() : " + beforeInit.repositoryTag());

      FoundationLogger.init();

      Logger afterInit = Logger.getLogger(FoundationLogger.class);
      System.out.println("logger repository identity after init()  : " + afterInit.repositoryTag());
      System.out.println("repository selector was actually swapped  : "
            + !beforeInit.repositoryTag().equals(afterInit.repositoryTag()));
      System.out.println("log4jConfigProps loaded from the temp file : " + (FoundationLogger.log4jConfigProps != null));
      System.out.println("root logger level from properties applied  : " + Logger.getRootLogger().getEffectiveLevel());
      System.out.println("com.example.noisy level from properties applied : "
            + Logger.getLogger("com.example.noisy").getEffectiveLevel());
      System.out.println("NT event log support probed (non-Windows -> false) : " + FoundationLogger.isNtEventLogSupportedForTesting());
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 2: init() with Foundation_JUL_SUPPORT_ENABLED=true ---");
      File configFile2 = File.createTempFile("log4j-jul", ".properties");
      configFile2.deleteOnExit();
      try (FileWriter w = new FileWriter(configFile2))
      {
         w.write("log4j.rootLogger=INFO\n");
         w.write("Foundation_JUL_SUPPORT_ENABLED=true\n");
      }
      System.setProperty("log4j.configuration", configFile2.toURI().toURL().toString());
      File julLogFile = File.createTempFile("jul-target", ".log");
      julLogFile.deleteOnExit();
      Logger.getRootLogger().addAppender(new FileAppender("fileAppender", julLogFile.getAbsolutePath()));

      int julHandlersBefore = java.util.logging.Logger.getLogger("").getHandlers().length;
      FoundationLogger.init();
      int julHandlersAfter = java.util.logging.Logger.getLogger("").getHandlers().length;
      System.out.println("JUL handlers on root logger before init() : " + julHandlersBefore);
      System.out.println("JUL handlers on root logger after init()  : " + julHandlersAfter);
      boolean fileHandlerInstalled = false;
      for (Handler h : java.util.logging.Logger.getLogger("").getHandlers())
      {
         if (h instanceof FileHandler)
         {
            fileHandlerInstalled = true;
         }
      }
      System.out.println("a real java.util.logging.FileHandler was installed : " + fileHandlerInstalled);
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: no resolvable log4j.properties resource ---");
      System.clearProperty("log4j.configuration");
      try
      {
         FoundationLogger.init();
         System.out.println("!! expected FoundationIOException");
      }
      catch (FoundationIOException e)
      {
         System.out.println("FoundationIOException correctly thrown : " + e.getMessage());
      }

      System.out.println();
      System.out.println("=== done ===");
   }
}





class FoundationLogger extends Logger
{
   private static final String Foundation_FILE_RELOAD_DELAY = "FoundationfileReloadDelay";

   private static final int FILE_RELOAD_DELAY = 10000;

   static Properties log4jConfigProps = null;

   private static final String DEFAULT_CONFIGURATION_FILE = "log4j.properties";

   private static final String DEFAULT_CONFIGURATION_KEY = "log4j.configuration";

   private static final String FQCN = FoundationLogger.class.getName();

   public static Map<String, Map<String, Layout>> markerAppendersMap = new HashMap<String, Map<String, Layout>>();

   private static boolean ntEventLogSupported = true;

   FoundationLogger(final String name)
   {
      super(name);
   }

   static boolean isNtEventLogSupportedForTesting()
   {
      return ntEventLogSupported;
   }


// ORIGINAL CODESEARCHNET METHOD — START

static void init() {

		determineIfNTEventLogIsSupported();

		URL resource = null;

		final String configurationOptionStr = OptionConverter.getSystemProperty(DEFAULT_CONFIGURATION_KEY, null);

		if (configurationOptionStr != null) {
			try {
				resource = new URL(configurationOptionStr);
			} catch (MalformedURLException ex) {
				
				
				resource = Loader.getResource(configurationOptionStr);
			}
		}
		if (resource == null) {
			resource = Loader.getResource(DEFAULT_CONFIGURATION_FILE); 
		}

		if (resource == null) {
			System.err.println("[FoundationLogger] Can not find resource: " + DEFAULT_CONFIGURATION_FILE); 
			throw new FoundationIOException("Can not find resource: " + DEFAULT_CONFIGURATION_FILE); 
		}

		
		final RepositorySelector foundationRepositorySelector = new FoundationRepositorySelector(FoundationLogFactory.foundationLogHierarchy);
		LogManager.setRepositorySelector(foundationRepositorySelector, null);

		
		
		final Logger logger = getLogger(FoundationLogger.class);

		final String logPropFile = resource.getPath();
		log4jConfigProps = getLogProperties(resource);
		
		
		
		OptionConverter.selectAndConfigure(resource, null, FoundationLogFactory.foundationLogHierarchy);

		
		setUpPropFileReloading(logger, logPropFile, log4jConfigProps);

		


		
		


        AbstractFoundationLoggingMarker.init();

		updateSniffingLoggersLevel(logger);

        setupJULSupport(resource);

    }

// ORIGINAL CODESEARCHNET METHOD — END


   private static void setupJULSupport(URL resource)
   {
      boolean julSupportEnabled = Boolean.valueOf(log4jConfigProps.getProperty("Foundation_JUL_SUPPORT_ENABLED", "false"));
      if (julSupportEnabled)
      {
         String appenderRef = log4jConfigProps.getProperty("Foundation_JUL_APPENDER_REF");

         if (isBlank(appenderRef))
         {
            Enumeration allAppenders = Logger.getRootLogger().getAllAppenders();

            while (allAppenders.hasMoreElements())
            {
               Appender appender = (Appender) allAppenders.nextElement();

               if (appender instanceof FileAppender)
               {
                  appenderRef = appender.getName();
                  getLogger(FoundationLogger.class).info("*** Using '" + appenderRef + "' as the Java util logging appender ref ***");
                  System.err.println("*** Using '" + appenderRef + "' as the Java util logging appender ref ***");
                  break;
               }
            }
         }

         Handler handler = null;

         Appender appender = Logger.getRootLogger().getAppender(appenderRef);
         if (appender == null)
         {
            Enumeration allAppenders = Logger.getRootLogger().getAllAppenders();

            while (allAppenders.hasMoreElements())
            {
               Appender tempAppender = (Appender) allAppenders.nextElement();

               if (tempAppender instanceof AsyncAppender)
               {
                  AsyncAppender asyncAppender = (AsyncAppender) tempAppender;
                  Enumeration asyncAppenderAllAppenders = asyncAppender.getAllAppenders();

                  while (asyncAppenderAllAppenders.hasMoreElements())
                  {
                     Appender asyncTempAppender = (Appender) asyncAppenderAllAppenders.nextElement();

                     if (appenderRef != null && appenderRef.equals(asyncTempAppender.getName()))
                     {
                        appender = asyncTempAppender;
                        break;
                     }
                  }
                  if (appender != null)
                  {
                     break;
                  }
               }
            }
         }

         if (appender instanceof FileAppender)
         {
            try
            {
               handler = new FileHandler(((FileAppender) appender).getFile());
            }
            catch (IOException e)
            {
               throw new IllegalArgumentException("IOException encountered when trying to setup jul logging: " + e, e);
            }
         }
         else if (appender instanceof ConsoleAppender)
         {
            handler = new ConsoleHandler();
         }
         else
         {
            getLogger(FoundationLogger.class).error("got a reference to an unsupported appender: " + appenderRef);
         }

         if (handler != null)
         {
            java.util.logging.LogManager.getLogManager().reset();
            try
            {
               java.util.logging.LogManager.getLogManager().readConfiguration(resource.openStream());
            }
            catch (IOException e)
            {
               throw new IllegalArgumentException("IOException encountered when trying to read log4j properties file: " + e, e);
            }

            handler.setLevel(java.util.logging.Level.FINEST);
            handler.setFormatter(new FoundationLogFormatter());

            java.util.logging.Logger rootLogger = java.util.logging.Logger.getLogger("");
            rootLogger.addHandler(handler);
            rootLogger.setLevel(java.util.logging.Level.SEVERE);

            Properties julLoggerSubset = getPropertiesSubset("jul.logger");
            if (!julLoggerSubset.isEmpty())
            {
               Set<Object> keySet = julLoggerSubset.keySet();
               for (Object key : keySet)
               {
                  java.util.logging.Logger julLogger = java.util.logging.Logger.getLogger((String) key);
                  julLogger.setLevel(java.util.logging.Level.parse((String) julLoggerSubset.get(key)));
               }
            }
         }
      }
   }

   private static boolean isBlank(String s)
   {
      return s == null || s.trim().isEmpty();
   }

   private static void determineIfNTEventLogIsSupported()
   {
      boolean supported = true;
      try
      {
         new NTEventLogAppender();
      }
      catch (Throwable t)
      {
         supported = false;
      }

      ntEventLogSupported = supported;
   }

   private static void setUpPropFileReloading(final Logger logger, final String logPropFile, final Properties properties)
   {
      int fileReloadDelay = FILE_RELOAD_DELAY;
      if (properties.containsKey(Foundation_FILE_RELOAD_DELAY))
      {
         final String fileReloadDelayStr = properties.getProperty(Foundation_FILE_RELOAD_DELAY);
         try
         {
            fileReloadDelay = Integer.parseInt(fileReloadDelayStr);
         }
         catch (NumberFormatException e)
         {
            logger.error("Can not format to integer the property: " + Foundation_FILE_RELOAD_DELAY + ". using default of: " + FILE_RELOAD_DELAY);
         }
      }

      PropertyConfigurator.configureAndWatch(logPropFile, fileReloadDelay);
   }

   private static Properties getLogProperties(final URL logPropFileResource)
   {
      final Properties properties = new Properties();
      InputStream propertiesInStream = null;
      final String log4jFilePath = logPropFileResource.getPath();
      try
      {
         propertiesInStream = logPropFileResource.openStream();
         properties.load(propertiesInStream);
      }
      catch (FileNotFoundException e)
      {
         System.err.println("[FoundationLogger] Can not find the file: " + log4jFilePath);
         throw new FoundationIOException("Can not find the file: " + log4jFilePath, e);
      }
      catch (IOException e)
      {
         System.err.println("[FoundationLogger] IO Exception during load of file: " + log4jFilePath + ". Exception is: " + e.toString());
         throw new FoundationIOException("IO Exception during load of file: " + log4jFilePath + ". Exception is: " + e.toString(), e);
      }
      finally
      {
         if (propertiesInStream != null)
         {
            try
            {
               propertiesInStream.close();
            }
            catch (IOException e)
            {
               System.err.println("[FoundationLogger] IO Exception during close of file: " + log4jFilePath + ". Exception is: " + e.toString());
            }
         }
      }
      return properties;
   }

   




   private static void updateSniffingLoggersLevel(Logger logger)
   {
      InputStream settingIS = FoundationLogger.class.getResourceAsStream("/sniffingLogger.xml");
      if (settingIS == null)
      {
         logger.debug("file sniffingLogger.xml not found in classpath");
      }
      else
      {
         try
         {
            SAXBuilder builder = new SAXBuilder();
            Document document = builder.build(settingIS);
            settingIS.close();
            Element rootElement = document.getRootElement();
            java.util.List<Element> sniffingloggers = rootElement.getChildren("sniffingLogger");
            for (Element sniffinglogger : sniffingloggers)
            {
               String loggerName = sniffinglogger.getAttributeValue("id");
               Logger.getLogger(loggerName).setLevel(Level.TRACE);
            }
         }
         catch (Exception e)
         {
            logger.error("cannot load the sniffing logger configuration file. error is: " + e, e);
            throw new IllegalArgumentException("Problem parsing sniffingLogger.xml", e);
         }
      }
   }

   private static Properties getPropertiesSubset(String prefix)
   {
      Properties subset = new Properties();
      Enumeration<Object> keys = log4jConfigProps.keys();
      while (keys.hasMoreElements())
      {
         Object keyObj = keys.nextElement();
         String key = (String) keyObj;
         if (key.startsWith(prefix + "."))
         {
            subset.put(key.substring((prefix + ".").length()), log4jConfigProps.get(key));
         }
      }
      return subset;
   }

   



   private static class FoundationRepositorySelector implements RepositorySelector
   {
      final private LoggerRepository repository;

      public FoundationRepositorySelector(final LoggerRepository repository)
      {
         this.repository = repository;
      }

      public LoggerRepository getLoggerRepository()
      {
         return repository;
      }
   }

   






   private static class FoundationLogFormatter extends java.util.logging.Formatter
   {
      MessageFormat messageFormat = new MessageFormat("{3} [{0}] [{2}]: {1}: {5} {4} \n");

      SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

      @Override
      public String format(LogRecord record)
      {
         Object[] arguments = new Object[] {
               truncateLoggerName(record.getLoggerName(), 1),
               record.getLevel(),
               Thread.currentThread().getName(),
               dateFormatter.format(new Date(record.getMillis())),
               record.getMessage(),
               "" };
         return messageFormat.format(arguments);
      }

      private String truncateLoggerName(String n, int precision)
      {
         String[] split = n.split("\\.");
         return split[split.length - 1];
      }
   }
}


final class FoundationIOException extends RuntimeException
{
   FoundationIOException(final String message)
   {
      super(message);
   }

   FoundationIOException(final String message, final Throwable cause)
   {
      super(message, cause);
   }
}










class FoundationLogFactory
{
   static LoggerRepository foundationLogHierarchy = new SimpleLoggerRepository("foundation");
}






class AbstractFoundationLoggingMarker
{
   static void init()
   {
      
      
      
   }
}





class Element
{
   private final String name;
   private final java.util.Map<String, String> attributes = new HashMap<String, String>();
   private final java.util.List<Element> children = new java.util.ArrayList<Element>();

   Element(String name)
   {
      this.name = name;
   }

   Element setAttribute(String key, String value)
   {
      attributes.put(key, value);
      return this;
   }

   String getAttributeValue(String key)
   {
      return attributes.get(key);
   }

   Element addContent(Element child)
   {
      children.add(child);
      return this;
   }

   java.util.List<Element> getChildren(String childName)
   {
      java.util.List<Element> result = new java.util.ArrayList<Element>();
      for (Element c : children)
      {
         if (c.name.equals(childName))
         {
            result.add(c);
         }
      }
      return result;
   }
}

class Document
{
   private final Element root;

   Document(Element root)
   {
      this.root = root;
   }

   Element getRootElement()
   {
      return root;
   }
}



class SAXBuilder
{
   Document build(InputStream is) throws Exception
   {
      String xml = new String(is.readAllBytes(), "UTF-8");
      Element root = new Element("sniffingLoggers");
      java.util.regex.Matcher m = java.util.regex.Pattern.compile("<sniffingLogger\\s+id=\"([^\"]+)\"\\s*/>").matcher(xml);
      while (m.find())
      {
         root.addContent(new Element("sniffingLogger").setAttribute("id", m.group(1)));
      }
      return new Document(root);
   }
}








class Level
{
   public static final Level ALL = new Level(Integer.MIN_VALUE, "ALL");
   public static final Level TRACE = new Level(5000, "TRACE");
   public static final Level DEBUG = new Level(10000, "DEBUG");
   public static final Level INFO = new Level(20000, "INFO");
   public static final Level WARN = new Level(30000, "WARN");
   public static final Level ERROR = new Level(40000, "ERROR");
   public static final Level FATAL = new Level(50000, "FATAL");

   private final int level;
   private final String name;

   private Level(int level, String name)
   {
      this.level = level;
      this.name = name;
   }

   public static Level toLevel(String s)
   {
      if (s == null)
      {
         return DEBUG;
      }
      switch (s.trim().toUpperCase())
      {
         case "ALL": return ALL;
         case "TRACE": return TRACE;
         case "DEBUG": return DEBUG;
         case "INFO": return INFO;
         case "WARN": return WARN;
         case "ERROR": return ERROR;
         case "FATAL": return FATAL;
         default: return DEBUG;
      }
   }

   @Override
   public String toString()
   {
      return name;
   }
}

abstract class Layout
{
   public abstract String format(Object event);
}

interface Appender
{
   String getName();

   void setName(String name);
}

class AppenderSkeleton implements Appender
{
   protected String name;
   protected Layout layout;

   public String getName()
   {
      return name;
   }

   public void setName(String name)
   {
      this.name = name;
   }
}

class ConsoleAppender extends AppenderSkeleton
{
   ConsoleAppender(String name)
   {
      setName(name);
   }
}

class FileAppender extends AppenderSkeleton
{
   private final String file;

   FileAppender(String name, String file)
   {
      setName(name);
      this.file = file;
   }

   public String getFile()
   {
      return file;
   }
}

class AsyncAppender extends AppenderSkeleton
{
   private final Vector<Appender> wrapped = new Vector<Appender>();

   AsyncAppender(String name)
   {
      setName(name);
   }

   void addAppender(Appender a)
   {
      wrapped.add(a);
   }

   Enumeration getAllAppenders()
   {
      return wrapped.elements();
   }
}




class NTEventLogAppender
{
   NTEventLogAppender()
   {
      throw new UnsatisfiedLinkError("NTEventLogAppender native library not available on this platform");
   }
}


interface LoggerRepository
{
   Logger getLogger(String name);

   Logger getRootLogger();

   String tag();
}


class SimpleLoggerRepository implements LoggerRepository
{
   private final String tag;
   private final Map<String, Logger> loggers = new HashMap<String, Logger>();
   private final Logger root;

   SimpleLoggerRepository(String tag)
   {
      this.tag = tag;
      this.root = new Logger("root");
      this.root.repositoryTagInternal = tag;
   }

   public synchronized Logger getLogger(String name)
   {
      Logger logger = loggers.get(name);
      if (logger == null)
      {
         logger = new Logger(name);
         logger.repositoryTagInternal = tag;
         loggers.put(name, logger);
      }
      return logger;
   }

   public Logger getRootLogger()
   {
      return root;
   }

   public String tag()
   {
      return tag;
   }
}


interface RepositorySelector
{
   LoggerRepository getLoggerRepository();
}






class LogManager
{
   private static volatile RepositorySelector selector;
   private static final LoggerRepository DEFAULT_REPOSITORY = new SimpleLoggerRepository("default");

   static void setRepositorySelector(RepositorySelector newSelector, Object guard)
   {
      selector = newSelector;
   }

   static LoggerRepository getLoggerRepository()
   {
      return selector != null ? selector.getLoggerRepository() : DEFAULT_REPOSITORY;
   }
}




class Logger
{
   private final String name;
   private Level level = Level.DEBUG;
   private final Vector<Appender> appenders = new Vector<Appender>();
   String repositoryTagInternal = "default";

   Logger(String name)
   {
      this.name = name;
   }

   public static Logger getLogger(String name)
   {
      return LogManager.getLoggerRepository().getLogger(name);
   }

   public static Logger getLogger(Class<?> clazz)
   {
      return getLogger(clazz.getName());
   }

   public static Logger getRootLogger()
   {
      return LogManager.getLoggerRepository().getRootLogger();
   }

   public String getName()
   {
      return name;
   }

   public String repositoryTag()
   {
      return repositoryTagInternal;
   }

   public void setLevel(Level level)
   {
      this.level = level;
   }

   public Level getEffectiveLevel()
   {
      return level;
   }

   public void addAppender(Appender a)
   {
      appenders.add(a);
   }

   public Appender getAppender(String appenderName)
   {
      if (appenderName == null)
      {
         return null;
      }
      for (Appender a : appenders)
      {
         if (appenderName.equals(a.getName()))
         {
            return a;
         }
      }
      return null;
   }

   public Enumeration getAllAppenders()
   {
      return appenders.elements();
   }

   public void debug(String message)
   {
      if (level.toString().equals("DEBUG") || level.toString().equals("TRACE"))
      {
         System.out.println("[DEBUG] " + name + " - " + message);
      }
   }

   public void info(String message)
   {
      System.out.println("[INFO] " + name + " - " + message);
   }

   public void error(String message)
   {
      System.out.println("[ERROR] " + name + " - " + message);
   }

   public void error(String message, Throwable t)
   {
      System.out.println("[ERROR] " + name + " - " + message + " (" + t + ")");
   }
}





class OptionConverter
{
   static String getSystemProperty(String key, String def)
   {
      try
      {
         return System.getProperty(key, def);
      }
      catch (Throwable t)
      {
         return def;
      }
   }

   static void selectAndConfigure(URL configURL, String clazz, LoggerRepository repository)
   {
      try
      {
         Properties props = new Properties();
         props.load(configURL.openStream());
         String rootSpec = props.getProperty("log4j.rootLogger");
         if (rootSpec != null)
         {
            String levelToken = rootSpec.split(",")[0].trim();
            repository.getRootLogger().setLevel(Level.toLevel(levelToken));
         }
         for (String key : props.stringPropertyNames())
         {
            if (key.startsWith("log4j.logger."))
            {
               String loggerName = key.substring("log4j.logger.".length());
               String levelToken = props.getProperty(key).split(",")[0].trim();
               repository.getLogger(loggerName).setLevel(Level.toLevel(levelToken));
            }
         }
      }
      catch (IOException e)
      {
         System.err.println("OptionConverter.selectAndConfigure: " + e);
      }
   }
}



class Loader
{
   static URL getResource(String resourceName)
   {
      return Thread.currentThread().getContextClassLoader().getResource(resourceName);
   }
}





class PropertyConfigurator
{
   static Thread configureAndWatch(String fileName, int delayMillis)
   {
      Thread watcher = new Thread(() -> {
         File file = new File(fileName);
         long lastModified = file.exists() ? file.lastModified() : -1;
         try
         {
            while (!Thread.currentThread().isInterrupted())
            {
               Thread.sleep(delayMillis);
               if (file.exists() && file.lastModified() != lastModified)
               {
                  lastModified = file.lastModified();
                  OptionConverter.selectAndConfigure(file.toURI().toURL(), null, LogManager.getLoggerRepository());
               }
            }
         }
         catch (InterruptedException e)
         {
            Thread.currentThread().interrupt();
         }
         catch (MalformedURLException e)
         {
            
         }
      }, "FoundationLogger-PropertyWatcher");
      watcher.setDaemon(true);
      watcher.start();
      return watcher;
   }
}
