
























import java.lang.reflect.Field;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class method_1_logging_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== FoundationLoggingDispatcher.run() - repository-aware reconstruction ===");
      System.out.println("Repository : foundation-runtime/logging @ cd0a07b3c5b458ecf90ab92a1e0c72a067f5cbd6");
      System.out.println("log4j      : lightweight adaptation (log4j 1.2.17 unavailable offline)");
      System.out.println();

      RecordingAppender recordingAppender = new RecordingAppender("fileAppender");
      AppenderAttachableImpl appenders = new AppenderAttachableImpl();
      appenders.addAppender(recordingAppender);

      List<LoggingEvent> buffer = new ArrayList<LoggingEvent>();
      Map<String, FoundationLoggingDispatcher.DiscardSummary> discardMap = new LinkedHashMap<String, FoundationLoggingDispatcher.DiscardSummary>();
      AsyncAppender parent = new AsyncAppender();

      FoundationLoggingDispatcher dispatcher = new FoundationLoggingDispatcher(parent, buffer, discardMap, appenders);
      Thread dispatcherThread = new Thread(dispatcher, "dispatcher-under-test");
      dispatcherThread.setDaemon(true);
      dispatcherThread.start();

      
      
      
      
      
      System.out.println("--- Scenario 1: ordinary buffered events get dispatched ---");
      Logger logger = Logger.getLogger("com.example.Service");
      synchronized (buffer)
      {
         buffer.add(new LoggingEvent("fqn", logger, Level.INFO, "starting up", null));
         buffer.add(new LoggingEvent("fqn", logger, Level.WARN, "low disk space", null));
         buffer.notifyAll();
      }
      waitUntil(() -> recordingAppender.events.size() >= 2, 2000);
      System.out.println("events delivered to wrapped appender : " + recordingAppender.events.size());
      for (LoggingEvent e : recordingAppender.events)
      {
         System.out.println("  [" + e.getLevel() + "] " + e.getMessage());
      }
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 2: buffer overflow discard summary gets appended ---");
      final int beforeScenario2 = recordingAppender.events.size();
      synchronized (buffer)
      {
         buffer.add(new LoggingEvent("fqn", logger, Level.ERROR, "disk full", null));
         discardMap.put("com.example.Service", new FoundationLoggingDispatcher.DiscardSummary(
               new LoggingEvent("fqn", logger, Level.WARN, "dropped event 1", null)));
         discardMap.get("com.example.Service").add(new LoggingEvent("fqn", logger, Level.ERROR, "dropped event 2", null));
         buffer.notifyAll();
      }
      waitUntil(() -> recordingAppender.events.size() >= beforeScenario2 + 2, 2000);
      System.out.println("events delivered this round : " + (recordingAppender.events.size() - beforeScenario2));
      LoggingEvent summaryEvent = recordingAppender.events.get(recordingAppender.events.size() - 1);
      System.out.println("last event message (discard summary) : " + summaryEvent.getMessage());
      System.out.println("summary reflects highest severity dropped (ERROR) : "
            + summaryEvent.getLevel().equals(Level.ERROR));
      System.out.println("discard map cleared after dispatch : " + discardMap.isEmpty());
      System.out.println();

      
      
      
      
      
      System.out.println("--- Scenario 3: marker-specific layout override, restored afterwards ---");
      Layout defaultLayout = new SimpleLayout("[default] %m");
      Layout markerLayout = new SimpleLayout("[audit] %m");
      recordingAppender.setLayout(defaultLayout);
      FoundationLogger.markerAppendersMap.put("AUDIT", new HashMap<String, Layout>());
      FoundationLogger.markerAppendersMap.get("AUDIT").put(recordingAppender.getName(), markerLayout);

      final int beforeScenario3 = recordingAppender.events.size();
      Marker auditMarker = new Marker("AUDIT");
      FoundationLof4jLoggingEvent markedEvent = new FoundationLof4jLoggingEvent(auditMarker, "fqn", logger, Level.INFO, "user login", null);
      synchronized (buffer)
      {
         buffer.add(markedEvent);
         buffer.notifyAll();
      }
      waitUntil(() -> recordingAppender.events.size() >= beforeScenario3 + 1, 2000);
      System.out.println("layout observed during doAppend : " + recordingAppender.layoutDuringLastAppend.format(markedEvent));
      System.out.println("appender layout restored to default afterwards : "
            + (recordingAppender.getLayout() == defaultLayout));
      System.out.println();

      
      
      
      
      System.out.println("--- Scenario 4: closing the parent appender stops the dispatcher loop ---");
      parent.close();
      synchronized (buffer)
      {
         buffer.notifyAll();
      }
      dispatcherThread.join(2000);
      System.out.println("dispatcher thread terminated : " + !dispatcherThread.isAlive());

      System.out.println();
      System.out.println("=== done ===");
   }

   private interface Condition
   {
      boolean check();
   }

   private static void waitUntil(Condition condition, long timeoutMillis) throws InterruptedException
   {
      long deadline = System.currentTimeMillis() + timeoutMillis;
      while (!condition.check() && System.currentTimeMillis() < deadline)
      {
         Thread.sleep(10);
      }
   }
}






class FoundationLoggingDispatcher implements Runnable
{
   private final AsyncAppender parent;

   private final List<LoggingEvent> buffer;

   private final Map<String, DiscardSummary> discardMap;

   private final AppenderAttachableImpl appenders;

   public FoundationLoggingDispatcher(final AsyncAppender parent, final List<LoggingEvent> buffer, final Map<String, DiscardSummary> discardMap, final AppenderAttachableImpl appenders)
   {
      this.parent = parent;
      this.buffer = buffer;
      this.appenders = appenders;
      this.discardMap = discardMap;
   }


// ORIGINAL CODESEARCHNET METHOD — START

public void run() {
		boolean isActive = true;

		
		
		
		try {
			
			
			
			while (isActive) {
				LoggingEvent[] events = null;

				
				
				
				
				synchronized (buffer) {
					int bufferSize = buffer.size();
					isActive = !isAsyncAppenderClosed(parent);

					while ((bufferSize == 0) && isActive) {
						buffer.wait();
						bufferSize = buffer.size();
						isActive = !isAsyncAppenderClosed(parent);
					}

					if (bufferSize > 0) {
						events = new LoggingEvent[bufferSize + discardMap.size()];
						buffer.toArray(events);

						
						
						
						int index = bufferSize;

						for (Iterator iter = discardMap.values().iterator(); iter.hasNext();) {
							events[index++] = ((DiscardSummary) iter.next()).createEvent();
						}

						
						
						
						buffer.clear();
						discardMap.clear();

						
						
						buffer.notifyAll();
					}
				}

				
				
				
				if (events != null) {
					for (int i = 0; i < events.length; i++) {
						synchronized (appenders) {
							LoggingEvent event = events[i];											
							@SuppressWarnings("unchecked")
							Enumeration<Appender> allAppenders = appenders.getAllAppenders();
							
							while (allAppenders.hasMoreElements()) {
								Appender appender = allAppenders.nextElement();

								
								synchronized (appender) {
									Layout originalLayout = appender.getLayout();
									boolean appenderUpdated = udpateLayoutIfNeeded(appender, event);

									appender.doAppend(event);
									if (appenderUpdated) {
										appender.setLayout(originalLayout);
									}
								}

							}																										
						}
					}
				}
			}
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}

// ORIGINAL CODESEARCHNET METHOD — END


   private boolean udpateLayoutIfNeeded(Appender appender, LoggingEvent event)
   {
      if (event instanceof FoundationLof4jLoggingEvent)
      {
         FoundationLof4jLoggingEvent foundationLof4jLoggingEvent = (FoundationLof4jLoggingEvent) event;
         Marker marker = foundationLof4jLoggingEvent.getSlf4jMarker();

         if (marker != null)
         {
            Map<String, Layout> map = FoundationLogger.markerAppendersMap.get(marker.getName());

            if (map != null)
            {
               Layout specificPatternLayout = map.get(appender.getName());
               if (specificPatternLayout != null)
               {
                  appender.setLayout(specificPatternLayout);
                  return true;
               }
            }
         }
      }
      return false;
   }

   private boolean isAsyncAppenderClosed(Appender appender)
   {
      
      
      try
      {
         Field closedField = AppenderSkeleton.class.getDeclaredField("closed");
         closedField.setAccessible(true);
         boolean closed = (Boolean) closedField.get(appender);

         return closed;
      }
      catch (Exception e)
      {
         System.err.println("Cannot check AsyncAppender state. Error is: " + e);
         
         return true;
      }
   }

   


   public static final class DiscardSummary
   {
      private LoggingEvent maxEvent;

      private int count;

      public DiscardSummary(final LoggingEvent event)
      {
         maxEvent = event;
         count = 1;
      }

      public void add(final LoggingEvent event)
      {
         if (event.getLevel().toInt() > maxEvent.getLevel().toInt())
         {
            maxEvent = event;
         }

         count++;
      }

      public LoggingEvent createEvent()
      {
         String msg = MessageFormat.format("Discarded {0} messages due to full event buffer including: {1}", new Object[] {new Integer(count), maxEvent.getMessage()});

         return new LoggingEvent("org.apache.log4j.AsyncAppender.DONT_REPORT_LOCATION", Logger.getLogger(maxEvent.getLoggerName()), maxEvent.getLevel(), msg, null);
      }
   }
}








class FoundationLogger
{
   static final Map<String, Map<String, Layout>> markerAppendersMap = new HashMap<String, Map<String, Layout>>();
}








interface FoundationLoggingEvent
{
   Marker getSlf4jMarker();

   void setAppenderName(String name);

   String getAppenderName();
}

class FoundationLof4jLoggingEvent extends LoggingEvent implements FoundationLoggingEvent
{
   private Marker marker = null;
   private String appenderName;

   public FoundationLof4jLoggingEvent(String fqnOfCategoryClass, Category logger, Level level, Object message, Throwable throwable)
   {
      super(fqnOfCategoryClass, logger, level, message, throwable);
   }

   public FoundationLof4jLoggingEvent(Marker marker, String fqnOfCategoryClass, Category logger, Level level, Object message, Throwable throwable)
   {
      super(fqnOfCategoryClass, logger, level, message, throwable);
      this.marker = marker;
   }

   public Marker getSlf4jMarker()
   {
      return marker;
   }

   public void setAppenderName(String name)
   {
      this.appenderName = name;
   }

   public String getAppenderName()
   {
      return appenderName;
   }
}









class Marker
{
   private final String name;

   Marker(String name)
   {
      this.name = name;
   }

   public String getName()
   {
      return name;
   }
}

class Level
{
   public static final Level DEBUG = new Level(10000, "DEBUG");
   public static final Level INFO = new Level(20000, "INFO");
   public static final Level WARN = new Level(30000, "WARN");
   public static final Level ERROR = new Level(40000, "ERROR");

   private final int level;
   private final String name;

   private Level(int level, String name)
   {
      this.level = level;
      this.name = name;
   }

   public int toInt()
   {
      return level;
   }

   @Override
   public String toString()
   {
      return name;
   }

   @Override
   public boolean equals(Object o)
   {
      return (o instanceof Level) && ((Level) o).level == level;
   }

   @Override
   public int hashCode()
   {
      return level;
   }
}

class Category
{
   private final String name;

   protected Category(String name)
   {
      this.name = name;
   }

   public String getName()
   {
      return name;
   }
}

class Logger extends Category
{
   private static final Map<String, Logger> LOGGERS = new HashMap<String, Logger>();

   private Logger(String name)
   {
      super(name);
   }

   public static synchronized Logger getLogger(String name)
   {
      Logger logger = LOGGERS.get(name);
      if (logger == null)
      {
         logger = new Logger(name);
         LOGGERS.put(name, logger);
      }
      return logger;
   }
}


class LoggingEvent
{
   protected final String fqnOfCategoryClass;
   private final Category logger;
   private final Level level;
   private final Object message;
   private final Throwable throwable;

   public LoggingEvent(String fqnOfCategoryClass, Category logger, Level level, Object message, Throwable throwable)
   {
      this.fqnOfCategoryClass = fqnOfCategoryClass;
      this.logger = logger;
      this.level = level;
      this.message = message;
      this.throwable = throwable;
   }

   public Category getLogger()
   {
      return logger;
   }

   public String getLoggerName()
   {
      return logger.getName();
   }

   public Level getLevel()
   {
      return level;
   }

   public Object getMessage()
   {
      return message;
   }

   public Throwable getThrowable()
   {
      return throwable;
   }
}


abstract class Layout
{
   public abstract String format(LoggingEvent event);
}

class SimpleLayout extends Layout
{
   private final String pattern;

   SimpleLayout(String pattern)
   {
      this.pattern = pattern;
   }

   public String format(LoggingEvent event)
   {
      return pattern.replace("%m", String.valueOf(event.getMessage()));
   }
}


interface Appender
{
   String getName();

   Layout getLayout();

   void setLayout(Layout layout);

   void doAppend(LoggingEvent event);
}






abstract class AppenderSkeleton implements Appender
{
   private boolean closed = false;
   protected Layout layout;
   protected String name;

   public String getName()
   {
      return name;
   }

   public void setName(String name)
   {
      this.name = name;
   }

   public Layout getLayout()
   {
      return layout;
   }

   public void setLayout(Layout layout)
   {
      this.layout = layout;
   }

   public void close()
   {
      closed = true;
   }

   public boolean isClosed()
   {
      return closed;
   }
}


class AppenderAttachableImpl
{
   private final Vector<Appender> appenderList = new Vector<Appender>();

   public void addAppender(Appender appender)
   {
      if (!appenderList.contains(appender))
      {
         appenderList.add(appender);
      }
   }

   @SuppressWarnings("unchecked")
   public Enumeration<Appender> getAllAppenders()
   {
      return appenderList.elements();
   }
}






class AsyncAppender extends AppenderSkeleton
{
   public void doAppend(LoggingEvent event)
   {
      
   }
}




class RecordingAppender extends AppenderSkeleton
{
   final List<LoggingEvent> events = new ArrayList<LoggingEvent>();
   Layout layoutDuringLastAppend;

   RecordingAppender(String name)
   {
      setName(name);
   }

   public void doAppend(LoggingEvent event)
   {
      layoutDuringLastAppend = getLayout();
      events.add(event);
   }
}
