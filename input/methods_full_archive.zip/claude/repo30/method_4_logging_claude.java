









































import java.io.File;
import java.io.FileWriter;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

public class method_4_logging_claude
{
   public static void main(String[] args) throws Exception
   {
      System.out.println("=== AbstractFoundationLoggingMarker.scanClassPathForFormattingAnnotations() - repository-aware reconstruction ===");
      System.out.println("Repository : foundation-runtime/logging @ cd0a07b3c5b458ecf90ab92a1e0c72a067f5cbd6");
      System.out.println("reflections / slf4j : lightweight adaptations (both unavailable offline)");
      System.out.println("NOTE: the target method's own body sleeps 30s before returning — this run really takes that long.");
      System.out.println();

      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      compileTestMarkerClasses();

      System.out.println("--- invoking scanClassPathForFormattingAnnotations() ---");
      long start = System.currentTimeMillis();
      AbstractFoundationLoggingMarker.scanClassPathForFormattingAnnotations();
      long elapsedSeconds = (System.currentTimeMillis() - start) / 1000;
      System.out.println("--- returned after ~" + elapsedSeconds + "s (>= 30s expected, from the verbatim sleep) ---");
      System.out.println();

      System.out.println("markersMap now contains an entry for GoodMarker : "
            + AbstractFoundationLoggingMarker.markersMapContainsForTesting("GoodMarker"));
      System.out.println("markersMap has NO entry for BadAnnotatedType (not a FoundationLoggingMarker) : "
            + !AbstractFoundationLoggingMarker.markersMapContainsForTesting("BadAnnotatedType"));

      System.out.println();
      System.out.println("=== done ===");
   }

   private static File compileTestMarkerClasses() throws Exception
   {
      File runningClassDir = new File(method_4_logging_claude.class
            .getProtectionDomain().getCodeSource().getLocation().toURI());
      File srcDir = new File(System.getProperty("java.io.tmpdir"), "scan-src-" + System.currentTimeMillis());
      srcDir.mkdirs();

      File goodMarkerSrc = new File(srcDir, "GoodMarker.java");
      try (FileWriter w = new FileWriter(goodMarkerSrc))
      {
         
         
         
         
         
         
         
         
         
         
         
         
         w.write("@DefaultFormat(\"test\")\n");
         w.write("public class GoodMarker implements FoundationLoggingMarker {\n");
         w.write("  public String valueOf(String f) { return null; }\n");
         w.write("  public String getName() { return \"GoodMarker\"; }\n");
         w.write("  public FoundationLoggingMarkerFormatter getFormatter() { return null; }\n");
         w.write("  public void add(Marker r) {}\n");
         w.write("  public boolean remove(Marker r) { return false; }\n");
         w.write("  public boolean hasChildren() { return false; }\n");
         w.write("  public boolean hasReferences() { return false; }\n");
         w.write("  public java.util.Iterator iterator() { return null; }\n");
         w.write("  public boolean contains(Marker o) { return false; }\n");
         w.write("  public boolean contains(String n) { return false; }\n");
         w.write("}\n");
      }

      File badTypeSrc = new File(srcDir, "BadAnnotatedType.java");
      try (FileWriter w = new FileWriter(badTypeSrc))
      {
         w.write("@DefaultFormat(\"test\")\n");
         w.write("public class BadAnnotatedType {\n");
         w.write("}\n");
      }

      JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
      int result = compiler.run(null, null, null,
            "-cp", System.getProperty("java.class.path"),
            "-d", runningClassDir.getAbsolutePath(),
            goodMarkerSrc.getAbsolutePath(), badTypeSrc.getAbsolutePath());
      if (result != 0)
      {
         throw new IllegalStateException("failed to compile test marker classes");
      }
      return runningClassDir;
   }
}






abstract class AbstractFoundationLoggingMarker implements FoundationLoggingMarker
{
   private static Logger LOGGER = LoggerFactory.getLogger(AbstractFoundationLoggingMarker.class);

   private static HashMap<Class<? extends FoundationLoggingMarker>, Class<FoundationLoggingMarkerFormatter>> markersMap = new HashMap<Class<? extends FoundationLoggingMarker>, Class<FoundationLoggingMarkerFormatter>>();

   static boolean markersMapContainsForTesting(String className)
   {
      for (Class<?> c : markersMap.keySet())
      {
         if (c.getName().equals(className))
         {
            return true;
         }
      }
      return false;
   }


// ORIGINAL CODESEARCHNET METHOD — START

public static void scanClassPathForFormattingAnnotations() {

		ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 2);

		
		Reflections reflections = new Reflections("com.nds","com.cisco");

		Set<Class<?>> annotated = reflections.getTypesAnnotatedWith(DefaultFormat.class);





		for (Class<?> markerClass : annotated) {

			
			
			if (FoundationLoggingMarker.class.isAssignableFrom(markerClass)) {

				final Class<? extends FoundationLoggingMarker> clazz = (Class<? extends FoundationLoggingMarker>) markerClass;

				executorService.execute(new Runnable() {

					@Override
					public void run() {

						if (markersMap.get(clazz) == null) {
							try {
								
								
								generateAndUpdateFormatterInMap(clazz);
							} catch (Exception e) {
								LOGGER.trace("problem generating formatter class from static scan method. error is: " + e.toString());
							}
						}

					}
				});

			} else {
					

				
				
				if (LOGGER == null) {
					LOGGER = LoggerFactory.getLogger(AbstractFoundationLoggingMarker.class);
				}
				LOGGER.error("Formatter annotations should only appear on foundationLoggingMarker implementations");
			}
		}

		try {
			TimeUnit.SECONDS.sleep(30);
		} catch (InterruptedException e) {
			LOGGER.trace(e.toString(), e);
		}
		executorService.shutdown();
		
		
		
		
		
	}

// ORIGINAL CODESEARCHNET METHOD — END


   






   private static void generateAndUpdateFormatterInMap(Class<? extends FoundationLoggingMarker> markerClass)
   {
      if (markersMap.get(markerClass) == null)
      {
         synchronized (markerClass)
         {
            markersMap.put(markerClass, FoundationLoggingMarkerFormatter.class);
         }
      }
   }
}





interface FoundationLoggingMarkerFormatter
{
}

interface FoundationLoggingMarker extends Marker
{
   String NO_OPERATION = "NOP";

   String valueOf(String userFieldName);

   String getName();

   FoundationLoggingMarkerFormatter getFormatter();
}

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface DefaultFormat
{
   String value();
}




interface Marker
{
   String getName();

   void add(Marker reference);

   boolean remove(Marker reference);

   boolean hasChildren();

   boolean hasReferences();

   java.util.Iterator iterator();

   boolean contains(Marker other);

   boolean contains(String name);
}

class Logger
{
   private final String name;

   Logger(String name)
   {
      this.name = name;
   }

   void trace(String message)
   {
      System.out.println("[TRACE] " + name + " - " + message);
   }

   void trace(String message, Throwable t)
   {
      System.out.println("[TRACE] " + name + " - " + message + " (" + t + ")");
   }

   void debug(String message, Object... args)
   {
      System.out.println("[DEBUG] " + name + " - " + message);
   }

   void error(String message)
   {
      System.out.println("[ERROR] " + name + " - " + message);
   }
}

class LoggerFactory
{
   static Logger getLogger(Class<?> clazz)
   {
      return new Logger(clazz.getName());
   }
}









class Reflections
{
   private final String[] prefixes;

   Reflections(String... prefixes)
   {
      this.prefixes = prefixes;
   }

   Set<Class<?>> getTypesAnnotatedWith(Class<? extends java.lang.annotation.Annotation> annotation)
   {
      Set<Class<?>> result = new HashSet<Class<?>>();
      ClassLoader loader = Thread.currentThread().getContextClassLoader();
      String classPath = System.getProperty("java.class.path");
      List<String> roots = new ArrayList<String>();
      for (String entry : classPath.split(File.pathSeparator))
      {
         roots.add(entry);
      }
      
      
      if (loader instanceof URLClassLoader)
      {
         for (URL url : ((URLClassLoader) loader).getURLs())
         {
            roots.add(new File(url.getPath()).getAbsolutePath());
         }
      }

      for (String root : roots)
      {
         File rootFile = new File(root);
         if (!rootFile.isDirectory())
         {
            continue;
         }
         scanDirectory(rootFile, "", loader, annotation, result);
      }
      return result;
   }

   private void scanDirectory(File dir, String packagePrefix, ClassLoader loader,
         Class<? extends java.lang.annotation.Annotation> annotation, Set<Class<?>> result)
   {
      File[] children = dir.listFiles();
      if (children == null)
      {
         return;
      }
      for (File child : children)
      {
         if (child.isDirectory())
         {
            scanDirectory(child, packagePrefix.isEmpty() ? child.getName() : packagePrefix + "." + child.getName(), loader, annotation, result);
         }
         else if (child.getName().endsWith(".class"))
         {
            String simpleName = child.getName().substring(0, child.getName().length() - ".class".length());
            String className = packagePrefix.isEmpty() ? simpleName : packagePrefix + "." + simpleName;
            if (!matchesPrefix(className))
            {
               continue;
            }
            try
            {
               Class<?> clazz = Class.forName(className, false, loader);
               if (clazz.isAnnotationPresent(annotation))
               {
                  result.add(clazz);
               }
            }
            catch (Throwable t)
            {
               
               
            }
         }
      }
   }

   private boolean matchesPrefix(String className)
   {
      if (!className.contains("."))
      {
         
         
         
         
         
         
         
         return true;
      }
      for (String prefix : prefixes)
      {
         if (className.startsWith(prefix + "."))
         {
            return true;
         }
      }
      return false;
   }
}
