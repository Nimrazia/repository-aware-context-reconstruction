import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
import java.security.cert.CertificateException;


























public class method_2_nitro_gpt {

    
    
    
    
    static class nitro_exception extends Exception {
        private static final long serialVersionUID = 1L;
        private long errorcode;
        private String severity;
        private String response;

        public nitro_exception(String message) { super(message); }

        public nitro_exception(String message, long errorcode) {
            super(message);
            this.errorcode = errorcode;
        }

        public nitro_exception(String message, long errorcode, String response) {
            super(message);
            this.errorcode = errorcode;
            this.response = response;
        }

        public long getErrorCode() { return errorcode; }
        public String getSeverity() { return severity; }
        public String getResponse() { return response; }

        @Override
        public String toString() {
            return "nitro_exception errorcode=" + errorcode + " message=" + getMessage();
        }
    }

    
    
    
    
    
    static class nitro_util {
        public static String encode(String str) {
            if (str == null) return null;
            try {
                return java.net.URLEncoder.encode(str, "UTF-8");
            } catch (Exception e) {
                return str;
            }
        }
    }

    
    
    
    
    
    
    
    static class payload_formatter {
        @SuppressWarnings("unchecked")
        public <T> T string_to_resource(Class<T> clazz, String response) throws Exception {
            if (clazz == base_response.class) {
                base_response r = new base_response();
                r.errorcode = extractLong(response, "errorcode", 0);
                r.message = extractString(response, "message");
                r.severity = extractString(response, "severity");
                return (T) r;
            }
            throw new Exception("Unsupported resource class in this reconstruction: " + clazz);
        }

        private long extractLong(String json, String key, long def) {
            String v = extractRaw(json, key);
            if (v == null) return def;
            try { return Long.parseLong(v.trim()); } catch (Exception e) { return def; }
        }

        private String extractString(String json, String key) {
            String v = extractRaw(json, key);
            if (v == null) return null;
            v = v.trim();
            if (v.startsWith("\"") && v.endsWith("\"") && v.length() >= 2) {
                return v.substring(1, v.length() - 1);
            }
            if (v.equals("null")) return null;
            return v;
        }

        private String extractRaw(String json, String key) {
            String marker = "\"" + key + "\":";
            int idx = json.indexOf(marker);
            if (idx < 0) return null;
            int start = idx + marker.length();
            int depth = 0;
            int i = start;
            boolean inString = false;
            for (; i < json.length(); i++) {
                char c = json.charAt(i);
                if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) inString = !inString;
                if (!inString) {
                    if (c == '{' || c == '[') depth++;
                    if (c == '}' || c == ']') {
                        if (depth == 0) break;
                        depth--;
                    }
                    if (c == ',' && depth == 0) break;
                }
            }
            return json.substring(start, i);
        }
    }

    
    
    
    
    
    static class options {
        private boolean compression = false;
        private String action;

        public boolean get_compression() { return compression; }
        public void set_compression(boolean c) { this.compression = c; }
        public void set_action(String action) { this.action = action; }

        public String to_string() {
            StringBuilder sb = new StringBuilder();
            if (action != null) sb.append("action=").append(action);
            return sb.toString();
        }
    }

    
    
    
    
    static class base_response {
        public long errorcode;
        public String message;
        public String severity;
    }

    
    
    
    
    
    static class nitro_service {
        private String ipaddress;
        private String version = "v1";
        private String sessionid = "MOCKSESSIONID123";
        private String protocol = "http";
        private Boolean warning = false;
        private Boolean certvalidation = false;
        private Boolean hostnameverification = false;
        private payload_formatter formatter = new payload_formatter();
        private boolean sessionCleared = false;

        public nitro_service(String ipaddress, String protocol) {
            this.ipaddress = ipaddress;
            this.protocol = protocol;
        }

        public String get_ipaddress() { return ipaddress; }
        public String get_version() { return version; }
        public String get_sessionid() { return sessionid; }
        public String get_protocol() { return protocol; }
        public Boolean get_warning() { return warning; }
        public Boolean get_certvalidation() { return certvalidation; }
        public Boolean get_hostnameverification() { return hostnameverification; }
        public payload_formatter get_payload_formatter() { return formatter; }

        public void clear_session() {
            this.sessionCleared = true;
            System.out.println("[nitro_service] clear_session() invoked because errorcode == 444");
        }

        public boolean wasSessionCleared() { return sessionCleared; }
    }

    
    
    
    
    static class EmptyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) { return true; }
    }

    static class EmptyTrustManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }

    
    
    
    
    
    
    
    
    
    static abstract class base_resource {

        protected abstract base_resource[] get_nitro_response(nitro_service service, String str) throws Exception;

        protected abstract String get_object_name();

        protected String get_object_type() {
            String name = this.getClass().getName();
            int index = name.lastIndexOf(".");
            if (index > 0) name = name.substring(index + 1);
            index = name.lastIndexOf("_stats");
            if (index > 0) name = name.substring(0, index);
            return name;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private  base_resource[] get_request(nitro_service service,options option) throws Exception  
        {
            StringBuilder responseStr = new StringBuilder();
            HttpURLConnection httpURLConnection = null;
            try
            {
                String urlstr;
                String ipaddress = service.get_ipaddress();
                String version = service.get_version();
                String sessionid = service.get_sessionid();
                String objtype = get_object_type();
                String protocol = service.get_protocol();

                
                urlstr = protocol + "://" + ipaddress + "/nitro/" + version + "/config/" + objtype;

                String name = this.get_object_name();
                if (name != null && name.length() > 0)
                {
                    urlstr = urlstr+"/"+nitro_util.encode(nitro_util.encode(name));
                }

                if (option != null || (service.get_warning()!=null && service.get_warning()) )
                {
                    String optionstr=null;
                    if (option != null)
                    {
                        optionstr = option.to_string();
                        if (optionstr.length() > 0)
                        {
                            urlstr = urlstr+"?";
                            urlstr = urlstr+optionstr;
                        }
                    }	
                    if (service.get_warning()!=null && service.get_warning())
                    {					
                        if (option != null && optionstr.length() > 0)
                        {
                            urlstr = urlstr+"&";
                        }
                        else
                        {
                            urlstr = urlstr+"?";
                        }
                        urlstr = urlstr+"warning=yes";
                    }
                }
                
                
                URL url = java.net.URI.create(urlstr).toURL();
                httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setRequestMethod("GET");

                httpURLConnection.setRequestProperty("Cookie", "sessionid=" + nitro_util.encode(sessionid));
                if ((option != null) && (option.get_compression()))
                    httpURLConnection.setRequestProperty("Accept-Encoding", "gzip, deflate");

                if (httpURLConnection instanceof HttpsURLConnection)
                {
                    if (service.get_certvalidation()) {
                        SocketFactory sslSocketFactory = SSLSocketFactory.getDefault();
                        HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
                        secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);	
                        if (!service.get_hostnameverification()) {
                            



                            secured.setHostnameVerifier(new EmptyHostnameVerifier());
                        }
                    } else {
                        SSLContext sslContext = SSLContext.getInstance("SSL");
                        
                        
                        
                        sslContext.init(null, new TrustManager[]{new EmptyTrustManager()}, null);
                        SocketFactory sslSocketFactory = sslContext.getSocketFactory();
                        
                        HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
                        secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);
                        if (!service.get_hostnameverification()) {
                            



                            secured.setHostnameVerifier(new EmptyHostnameVerifier());
                        }
                    }
                }

                InputStream input;
                try {
                    input = httpURLConnection.getInputStream();
                }
                catch (Exception e) {
                    input = httpURLConnection.getErrorStream();	
                }
                String contentEncoding = httpURLConnection.getContentEncoding();
                
                if (contentEncoding != null)
                {
                    if(contentEncoding.equalsIgnoreCase("gzip"))
                        input = new GZIPInputStream(input); 
                    else if(contentEncoding.equalsIgnoreCase("deflate"))
                        input = new InflaterInputStream(input);
                }

                int numOfTotalBytesRead;
                byte [] buffer = new byte[1024];
                while ((numOfTotalBytesRead = input.read(buffer, 0, buffer.length)) != -1)
                {
                    responseStr.append(new String(buffer, 0, numOfTotalBytesRead));
                }

                httpURLConnection.disconnect();
                input.close();
            }
            catch (MalformedURLException mue)
            {
                throw mue;
            }
            catch (IOException ioe)
            {
                throw ioe;
            }
            catch(Exception e)
            {
                throw e;
            }
            base_resource[] result = get_nitro_response(service, responseStr.toString());
            return result;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        

        
        
        base_resource[] invokeGetRequest(nitro_service service, options option) throws Exception {
            return get_request(service, option);
        }
    }

    
    
    
    
    
    static class demo_resource extends base_resource {
        private String name;

        demo_resource() {}
        demo_resource(String name) { this.name = name; }

        
        
        
        @Override
        protected base_resource[] get_nitro_response(nitro_service service, String str) throws Exception {
            java.util.List<demo_resource> list = new java.util.ArrayList<>();
            int arrStart = str.indexOf('[');
            int arrEnd = str.indexOf(']');
            if (arrStart >= 0 && arrEnd > arrStart) {
                String inner = str.substring(arrStart + 1, arrEnd).trim();
                if (!inner.isEmpty()) {
                    for (String tok : inner.split(",")) {
                        String cleaned = tok.trim().replaceAll("^\"|\"$", "");
                        if (!cleaned.isEmpty()) list.add(new demo_resource(cleaned));
                    }
                }
            }
            return list.toArray(new base_resource[0]);
        }

        @Override
        protected String get_object_name() { return name; }

        @Override
        public String toString() { return "demo_resource{name=" + name + "}"; }
    }

    
    
    
    
    
    static com.sun.net.httpserver.HttpServer startMockNitroListServer(String[] names) throws IOException {
        com.sun.net.httpserver.HttpServer server = com.sun.net.httpserver.HttpServer.create(new java.net.InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/nitro/", exchange -> {
            StringBuilder arr = new StringBuilder();
            for (int i = 0; i < names.length; i++) {
                if (i > 0) arr.append(",");
                arr.append("\"").append(names[i]).append("\"");
            }
            String body = "{\"demo_resource\":[" + arr + "]}";
            byte[] bytes = body.getBytes("UTF-8");
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStreamWriter w = new OutputStreamWriter(exchange.getResponseBody())) {
                w.write(body);
            }
        });
        server.start();
        return server;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== method_2_nitro_gpt : base_resource.get_request ===");

        com.sun.net.httpserver.HttpServer server1 = startMockNitroListServer(new String[]{"vsvr-a", "vsvr-b", "vsvr-c"});
        int port1 = server1.getAddress().getPort();
        try {
            nitro_service service1 = new nitro_service("127.0.0.1:" + port1, "http");
            demo_resource resource1 = new demo_resource(null);
            base_resource[] results1 = resource1.invokeGetRequest(service1, null);
            System.out.println("Scenario 1 (option=null): retrieved " + results1.length + " resources:");
            for (base_resource r : results1) System.out.println("   " + r);
        } finally {
            server1.stop(0);
        }

        com.sun.net.httpserver.HttpServer server2 = startMockNitroListServer(new String[]{"vsvr-details-target"});
        int port2 = server2.getAddress().getPort();
        try {
            nitro_service service2 = new nitro_service("127.0.0.1:" + port2, "http");
            demo_resource resource2 = new demo_resource(null);
            options option2 = new options();
            option2.set_action("details");
            option2.set_compression(true);
            base_resource[] results2 = resource2.invokeGetRequest(service2, option2);
            System.out.println("Scenario 2 (option with action+compression): retrieved " + results2.length + " resource(s):");
            for (base_resource r : results2) System.out.println("   " + r);
        } finally {
            server2.stop(0);
        }

        com.sun.net.httpserver.HttpServer server3 = startMockNitroListServer(new String[]{});
        int port3 = server3.getAddress().getPort();
        try {
            nitro_service service3 = new nitro_service("127.0.0.1:" + port3, "http");
            demo_resource resource3 = new demo_resource("specific-vserver-name");
            base_resource[] results3 = resource3.invokeGetRequest(service3, null);
            System.out.println("Scenario 3 (named resource, empty result): retrieved " + results3.length + " resource(s)");
        } finally {
            server3.stop(0);
        }

        System.out.println("=== Done ===");
    }
}
