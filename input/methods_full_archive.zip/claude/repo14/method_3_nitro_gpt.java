import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
import java.security.cert.CertificateException;


























public class method_3_nitro_gpt {

    
    
    
    
    static class nitro_exception extends Exception {
        private static final long serialVersionUID = 1L;
        private long errorcode;
        private String severity;
        private String response;

        public nitro_exception(String message) { super(message); }

        public nitro_exception(String message, long errorcode) {
            super(message);
            this.errorcode = errorcode;
        }

        public nitro_exception(String message, long errorcode, String response) {
            super(message);
            this.errorcode = errorcode;
            this.response = response;
        }

        public long getErrorCode() { return errorcode; }
        public String getSeverity() { return severity; }
        public String getResponse() { return response; }

        @Override
        public String toString() {
            return "nitro_exception errorcode=" + errorcode + " message=" + getMessage();
        }
    }

    
    
    
    
    
    static class nitro_util {
        public static String encode(String str) {
            if (str == null) return null;
            try {
                return java.net.URLEncoder.encode(str, "UTF-8");
            } catch (Exception e) {
                return str;
            }
        }
    }

    
    
    
    
    
    
    
    static class payload_formatter {
        @SuppressWarnings("unchecked")
        public <T> T string_to_resource(Class<T> clazz, String response) throws Exception {
            if (clazz == base_response.class) {
                base_response r = new base_response();
                r.errorcode = extractLong(response, "errorcode", 0);
                r.message = extractString(response, "message");
                r.severity = extractString(response, "severity");
                return (T) r;
            }
            throw new Exception("Unsupported resource class in this reconstruction: " + clazz);
        }

        private long extractLong(String json, String key, long def) {
            String v = extractRaw(json, key);
            if (v == null) return def;
            try { return Long.parseLong(v.trim()); } catch (Exception e) { return def; }
        }

        private String extractString(String json, String key) {
            String v = extractRaw(json, key);
            if (v == null) return null;
            v = v.trim();
            if (v.startsWith("\"") && v.endsWith("\"") && v.length() >= 2) {
                return v.substring(1, v.length() - 1);
            }
            if (v.equals("null")) return null;
            return v;
        }

        private String extractRaw(String json, String key) {
            String marker = "\"" + key + "\":";
            int idx = json.indexOf(marker);
            if (idx < 0) return null;
            int start = idx + marker.length();
            int depth = 0;
            int i = start;
            boolean inString = false;
            for (; i < json.length(); i++) {
                char c = json.charAt(i);
                if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) inString = !inString;
                if (!inString) {
                    if (c == '{' || c == '[') depth++;
                    if (c == '}' || c == ']') {
                        if (depth == 0) break;
                        depth--;
                    }
                    if (c == ',' && depth == 0) break;
                }
            }
            return json.substring(start, i);
        }
    }

    
    
    
    
    static class base_response {
        public long errorcode;
        public String message;
        public String severity;
    }

    
    
    
    
    
    static class nitro_service {
        private String ipaddress;
        private String version = "v1";
        private String sessionid = "MOCKSESSIONID123";
        private String protocol = "http";
        private Boolean warning = false;
        private Boolean certvalidation = false;
        private Boolean hostnameverification = false;
        private payload_formatter formatter = new payload_formatter();
        private boolean sessionCleared = false;

        public nitro_service(String ipaddress, String protocol) {
            this.ipaddress = ipaddress;
            this.protocol = protocol;
        }

        public String get_ipaddress() { return ipaddress; }
        public String get_version() { return version; }
        public String get_sessionid() { return sessionid; }
        public String get_protocol() { return protocol; }
        public Boolean get_warning() { return warning; }
        public Boolean get_certvalidation() { return certvalidation; }
        public Boolean get_hostnameverification() { return hostnameverification; }
        public payload_formatter get_payload_formatter() { return formatter; }

        public void clear_session() {
            this.sessionCleared = true;
            System.out.println("[nitro_service] clear_session() invoked because errorcode == 444");
        }

        public boolean wasSessionCleared() { return sessionCleared; }
    }

    
    
    
    
    static class EmptyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) { return true; }
    }

    static class EmptyTrustManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }

    
    
    
    
    
    
    
    
    
    static abstract class base_resource {

        protected abstract base_resource[] get_nitro_response(nitro_service service, String str) throws Exception;

        protected abstract String get_object_name();

        protected String get_object_type() {
            String name = this.getClass().getName();
            int index = name.lastIndexOf(".");
            if (index > 0) name = name.substring(index + 1);
            index = name.lastIndexOf("_stats");
            if (index > 0) name = name.substring(0, index);
            return name;
        }

        
        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private static String _put(nitro_service service, String request) throws Exception {
		HttpURLConnection httpURLConnection;
		StringBuilder responseStr = new StringBuilder();
		try
		{
			String urlstr;
			String ipaddress = service.get_ipaddress();
			String version = service.get_version();
			String protocol = service.get_protocol();
			urlstr = protocol+"://" + ipaddress + "/nitro/" + version + "/config/";
			URL url = java.net.URI.create(urlstr).toURL();
			httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("PUT");
			if (httpURLConnection instanceof HttpsURLConnection)
			{
				if (service.get_certvalidation()) {
					SocketFactory sslSocketFactory = SSLSocketFactory.getDefault();
					HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);	
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				} else {
					SSLContext sslContext = SSLContext.getInstance("SSL");
					
					
					
					sslContext.init(null, new TrustManager[]{new EmptyTrustManager()}, null);
					SocketFactory sslSocketFactory = sslContext.getSocketFactory();
					
					HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				}
			}

			httpURLConnection.setDoInput(true);
			httpURLConnection.setDoOutput(true);
			httpURLConnection.setUseCaches(false);
			httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			
			httpURLConnection.setDoOutput(true);
			OutputStreamWriter ouput = new OutputStreamWriter(httpURLConnection.getOutputStream());
			ouput.write(request);
			ouput.flush();
			ouput.close();

			InputStream input;
			try {
				input = httpURLConnection.getInputStream();
			}
			catch (Exception e) {
				input = httpURLConnection.getErrorStream();	
			}
			String contentEncoding = httpURLConnection.getContentEncoding();
			
			if (contentEncoding != null)
			{
				if(contentEncoding.equalsIgnoreCase("gzip"))
					input = new GZIPInputStream(input); 
				else if(contentEncoding.equalsIgnoreCase("deflate"))
					input = new InflaterInputStream(input);
			}

			int numOfTotalBytesRead;
			byte [] buffer = new byte[1024];
			while ((numOfTotalBytesRead = input.read(buffer, 0, buffer.length)) != -1)
			{
				responseStr.append(new String(buffer, 0, numOfTotalBytesRead));
			}

			httpURLConnection.disconnect();
			input.close();
		}
		catch (MalformedURLException mue)
		{
			throw mue;
		}
		catch (IOException ioe)
		{
			throw ioe;
		}
		catch(Exception e)
		{
			throw e;
		}
		
		return responseStr.toString();
	}
        
        // ORIGINAL CODESEARCHNET METHOD — END
        

        
        
        static String invokePut(nitro_service service, String request) throws Exception {
            return _put(service, request);
        }
    }

    
    
    
    
    
    static class demo_resource extends base_resource {
        private String name;

        demo_resource(String name) { this.name = name; }

        @Override
        protected base_resource[] get_nitro_response(nitro_service service, String str) throws Exception {
            return new base_resource[0];
        }

        @Override
        protected String get_object_name() { return name; }
    }

    
    
    
    
    
    static com.sun.net.httpserver.HttpServer startMockPutEchoServer() throws IOException {
        com.sun.net.httpserver.HttpServer server = com.sun.net.httpserver.HttpServer.create(new java.net.InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/nitro/", exchange -> {
            byte[] reqBytes = exchange.getRequestBody().readAllBytes();
            String receivedBody = new String(reqBytes, "UTF-8");
            String responseBody = "{\"echoed_method\":\"" + exchange.getRequestMethod()
                    + "\",\"echoed_body\":\"" + receivedBody.replace("\"", "\\\"") + "\",\"errorcode\":0}";
            byte[] bytes = responseBody.getBytes("UTF-8");
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStreamWriter w = new OutputStreamWriter(exchange.getResponseBody())) {
                w.write(responseBody);
            }
        });
        server.start();
        return server;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== method_3_nitro_gpt : base_resource._put ===");

        
        
        
        com.sun.net.httpserver.HttpServer server1 = startMockPutEchoServer();
        int port1 = server1.getAddress().getPort();
        try {
            nitro_service service1 = new nitro_service("127.0.0.1:" + port1, "http");
            String requestBody1 = "object={\"lbvserver\":{\"name\":\"vsvr-prod\",\"ipv46\":\"10.0.0.5\"}}";
            String response1 = base_resource.invokePut(service1, requestBody1);
            System.out.println("Scenario 1 response: " + response1);
        } finally {
            server1.stop(0);
        }

        
        
        com.sun.net.httpserver.HttpServer server2 = startMockPutEchoServer();
        int port2 = server2.getAddress().getPort();
        try {
            nitro_service service2 = new nitro_service("127.0.0.1:" + port2, "http");
            String response2 = base_resource.invokePut(service2, "");
            System.out.println("Scenario 2 response: " + response2);
        } finally {
            server2.stop(0);
        }

        
        
        try {
            nitro_service service3 = new nitro_service("127.0.0.1:1", "http");
            base_resource.invokePut(service3, "object=irrelevant");
            System.out.println("Scenario 3: ERROR - expected IOException was not thrown");
        } catch (IOException ioe) {
            System.out.println("Scenario 3: caught expected IOException: " + ioe.getClass().getSimpleName());
        }

        System.out.println("=== Done ===");
    }
}
