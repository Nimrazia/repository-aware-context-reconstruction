




































import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_1_naether_claude {

  
  
  
  
  
  
  
  
  
  interface RepositorySystemSession {
  }

  interface DependencySelector {
  }

  static class AndDependencySelector implements DependencySelector {
    final DependencySelector[] selectors;

    AndDependencySelector(DependencySelector... selectors) {
      this.selectors = selectors;
    }
  }

  static class ValidSystemScopeDependencySelector implements DependencySelector {
  }

  interface TransferListener {
  }

  static class LogTransferListener implements TransferListener {
  }

  interface RepositoryListener {
  }

  static class LogRepositoryListener implements RepositoryListener {
  }

  static class LocalRepository {
    private final File basedir;

    LocalRepository(String path) {
      this.basedir = new File(path);
    }

    File getBasedir() {
      return basedir;
    }
  }

  interface LocalRepositoryManager {
    File getRepository();
  }

  static class SimpleLocalRepositoryManager implements LocalRepositoryManager {
    private final File repoDir;

    SimpleLocalRepositoryManager(File repoDir) {
      this.repoDir = repoDir;
    }

    @Override
    public File getRepository() {
      return repoDir;
    }
  }

  static class MavenRepositorySystemSession implements RepositorySystemSession {
    DependencySelector dependencySelector;
    TransferListener transferListener;
    RepositoryListener repositoryListener;
    boolean ignoreMissingArtifactDescriptor = true;
    LocalRepositoryManager localRepositoryManager;

    MavenRepositorySystemSession setDependencySelector(DependencySelector selector) {
      this.dependencySelector = selector;
      return this;
    }

    MavenRepositorySystemSession setTransferListener(TransferListener listener) {
      this.transferListener = listener;
      return this;
    }

    MavenRepositorySystemSession setRepositoryListener(RepositoryListener listener) {
      this.repositoryListener = listener;
      return this;
    }

    MavenRepositorySystemSession setIgnoreMissingArtifactDescriptor(boolean ignore) {
      this.ignoreMissingArtifactDescriptor = ignore;
      return this;
    }

    DependencySelector getDependencySelector() {
      return dependencySelector;
    }

    void setLocalRepositoryManager(LocalRepositoryManager manager) {
      this.localRepositoryManager = manager;
    }

    @Override
    public String toString() {
      return "MavenRepositorySystemSession{dependencySelector=" + dependencySelector + ", transferListener="
          + transferListener + ", repositoryListener=" + repositoryListener + ", ignoreMissingArtifactDescriptor="
          + ignoreMissingArtifactDescriptor + ", localRepositoryManager=" + localRepositoryManager + "}";
    }
  }

  
  
  
  
  
  
  interface WagonProvider {
  }

  static class ManualWagonProvider implements WagonProvider {
  }

  interface RepositoryConnectorFactory {
  }

  static class WagonRepositoryConnectorFactory implements RepositoryConnectorFactory {
  }

  interface RepositorySystem {
    LocalRepositoryManager newLocalRepositoryManager(LocalRepository localRepository);
  }

  
  
  
  
  
  static class SimpleRepositorySystem implements RepositorySystem {
    @Override
    public LocalRepositoryManager newLocalRepositoryManager(LocalRepository localRepository) {
      return new SimpleLocalRepositoryManager(localRepository.getBasedir());
    }
  }

  
  
  
  
  
  
  
  static class DefaultServiceLocator {
    private final Map<Class<?>, List<Object>> services = new HashMap<>();
    private RepositorySystem repositorySystem;

    @SuppressWarnings("unchecked")
    <T> void setServices(Class<T> type, T... instances) {
      services.put(type, new ArrayList<>(Arrays.asList(instances)));
    }

    <T> void addService(Class<T> type, Class<? extends T> implClass) {
      try {
        services.computeIfAbsent(type, k -> new ArrayList<>()).add(implClass.getDeclaredConstructor().newInstance());
      } catch (ReflectiveOperationException e) {
        throw new RuntimeException(e);
      }
    }

    @SuppressWarnings("unchecked")
    <T> T getService(Class<T> type) {
      if (type == RepositorySystem.class) {
        if (repositorySystem == null) {
          repositorySystem = new SimpleRepositorySystem();
        }
        return (T) repositorySystem;
      }
      List<Object> l = services.get(type);
      return (l == null || l.isEmpty()) ? null : (T) l.get(0);
    }
  }

  
  
  
  
  String localRepoPath;
  RepositorySystem repositorySystem;
  RepositorySystemSession systemSession;

  method_1_naether_claude(String localRepoPath) {
    this.localRepoPath = localRepoPath;
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public void newRepositorySystem() {
        DefaultServiceLocator locator = new DefaultServiceLocator();
        locator.setServices(WagonProvider.class, new ManualWagonProvider());
        locator.addService(RepositoryConnectorFactory.class, WagonRepositoryConnectorFactory.class);

        repositorySystem = locator.getService(RepositorySystem.class);

        MavenRepositorySystemSession session = new MavenRepositorySystemSession();
        session = (MavenRepositorySystemSession)session.setDependencySelector( new AndDependencySelector( session.getDependencySelector(), new ValidSystemScopeDependencySelector() ) );
        session = (MavenRepositorySystemSession)session.setTransferListener(new LogTransferListener());
        session = (MavenRepositorySystemSession)session.setRepositoryListener(new LogRepositoryListener());

        session = (MavenRepositorySystemSession)session.setIgnoreMissingArtifactDescriptor( false );

        LocalRepository localRepo = new LocalRepository( localRepoPath );
        session.setLocalRepositoryManager(repositorySystem.newLocalRepositoryManager(localRepo));

        systemSession = session;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: RepositoryClient.newRepositorySystem ===");

    String localRepoPath = System.getProperty("java.io.tmpdir") + File.separator + "naether-demo-repo";
    method_1_naether_claude client = new method_1_naether_claude(localRepoPath);

    client.newRepositorySystem();

    System.out.println("\n-- After newRepositorySystem() --");
    System.out.println("  repositorySystem: " + client.repositorySystem.getClass().getSimpleName());
    System.out.println("  systemSession: " + client.systemSession);

    MavenRepositorySystemSession session = (MavenRepositorySystemSession) client.systemSession;
    System.out.println("\n  dependencySelector is AndDependencySelector: "
        + (session.dependencySelector instanceof AndDependencySelector));
    if (session.dependencySelector instanceof AndDependencySelector) {
      AndDependencySelector and = (AndDependencySelector) session.dependencySelector;
      System.out.println("  wrapped selector count: " + and.selectors.length + " (expected 2: prior [null] + "
          + "ValidSystemScopeDependencySelector)");
    }
    System.out.println("  transferListener is LogTransferListener: "
        + (session.transferListener instanceof LogTransferListener));
    System.out.println("  repositoryListener is LogRepositoryListener: "
        + (session.repositoryListener instanceof LogRepositoryListener));
    System.out.println("  ignoreMissingArtifactDescriptor: " + session.ignoreMissingArtifactDescriptor
        + " (expected false)");
    System.out.println("  localRepositoryManager repository dir: "
        + session.localRepositoryManager.getRepository());

    System.out.println("\n=== Demo complete: method exercised the full service-locator wiring "
        + "(WagonProvider + RepositoryConnectorFactory registration, RepositorySystem lookup), "
        + "the chained MavenRepositorySystemSession configuration (dependency selector wrapping, "
        + "transfer/repository listeners, ignoreMissingArtifactDescriptor), and the local "
        + "repository manager assignment. ===");
  }
}
