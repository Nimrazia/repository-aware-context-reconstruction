











































import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class method_3_aerogear_claude {

    public static void main(final String[] args) throws Exception {
        title("METHOD 3  |  RestAdapter.remove(String id, Callback<Void> callback)");

        section("1. a successful remove - onRemove(id) does not throw, onSuccess(null) is called");
        run(new PipeHandler<Object>() {
            public void onRemove(final String id) {
                System.out.println("        [restRunner] onRemove(" + id + ") - deleted");
            }
        }, "widget-1");

        section("2. onRemove(id) throws - the exception is captured and onFailure(exception) is called");
        run(new PipeHandler<Object>() {
            public void onRemove(final String id) {
                throw new RuntimeException("no widget with id " + id);
            }
        }, "widget-missing");

        section("3. several concurrent removes - THREAD_POOL_EXECUTOR really runs them off the calling thread");
        final CountDownLatch latch = new CountDownLatch(3);
        final RestAdapter<Object> adapter = new RestAdapter<Object>(new PipeHandler<Object>() {
            public void onRemove(final String id) {
                System.out.println("        [restRunner, thread=" + Thread.currentThread().getName()
                        + "] onRemove(" + id + ")");
            }
        });
        for (final String id : new String[] { "a", "b", "c" }) {
            adapter.remove(id, new Callback<Void>() {
                public void onSuccess(final Void result) {
                    latch.countDown();
                }

                public void onFailure(final Exception e) {
                    latch.countDown();
                }
            });
        }
        final boolean completed = latch.await(5, TimeUnit.SECONDS);
        System.out.println("      all three completed within 5s : " + completed);
        System.out.println("      the calling thread (main) never blocked while they ran");

        section("4. branch coverage summary");
        System.out.println("      exception == null  -> callback.onSuccess(null) -> scenarios 1, 3");
        System.out.println("      exception != null  -> callback.onFailure(exception) -> scenario 2");
        System.out.println("      the Runnable really executes on THREAD_POOL_EXECUTOR, not the caller's thread");

        ((ThreadPoolExecutor) RestAdapter.THREAD_POOL_EXECUTOR).shutdownNow();

        title("END OF METHOD 3 SCENARIOS");
    }

    static void run(final PipeHandler<Object> handler, final String id) throws Exception {
        final RestAdapter<Object> adapter = new RestAdapter<Object>(handler);
        final CountDownLatch latch = new CountDownLatch(1);
        adapter.remove(id, new Callback<Void>() {
            public void onSuccess(final Void result) {
                System.out.println("      callback.onSuccess(" + result + ")");
                latch.countDown();
            }

            public void onFailure(final Exception e) {
                System.out.println("      callback.onFailure(" + e + ")");
                latch.countDown();
            }
        });
        latch.await(5, TimeUnit.SECONDS);
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}







interface Callback<T> {
    void onSuccess(T result);

    void onFailure(Exception e);
}






interface PipeHandler<T> {
    void onRemove(String id);
}







interface Pipe<T> {
    void remove(String id, Callback<Void> callback);
}








final class RestAdapter<T> implements Pipe<T> {

    private static final int CORE_POOL_SIZE = 5;
    private static final int MAX_POOL_SIZE = 64;
    private static final int KEEP_ALIVE = 1;
    private static final BlockingQueue<Runnable> WORK_QUEUE = new LinkedBlockingQueue<Runnable>(10);
    public static final Executor THREAD_POOL_EXECUTOR = new ThreadPoolExecutor(CORE_POOL_SIZE, MAX_POOL_SIZE, KEEP_ALIVE,
            TimeUnit.SECONDS, WORK_QUEUE);

    private final PipeHandler<T> restRunner;

    RestAdapter(final PipeHandler<T> restRunner) {
        this.restRunner = restRunner;
    }

    
    @Override
    public void remove(final String id, final Callback<Void> callback) {

        THREAD_POOL_EXECUTOR.execute(new Runnable() {
            Exception exception = null;

            @Override
            public void run() {
                try {
                    RestAdapter.this.restRunner.onRemove(id);
                } catch (Exception e) {
                    exception = e;
                }
                if (exception == null) {
                    callback.onSuccess(null);
                } else {
                    callback.onFailure(exception);
                }
            }
        });

    }
    
}
