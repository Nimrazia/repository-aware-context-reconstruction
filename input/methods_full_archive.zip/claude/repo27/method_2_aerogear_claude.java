






































import java.net.URI;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class method_2_aerogear_claude {

    static final class BasicAuthModule implements PipeModule {
        public ModuleFields loadModule(final URI relativeURI, final String httpMethod, final byte[] requestBody) {
            final ModuleFields fields = new ModuleFields();
            fields.addHeader("Authorization", "Basic dXNlcjpwYXNz");
            return fields;
        }

        public boolean handleError(final HttpException exception) {
            return false;
        }
    }

    static final class ApiKeyModule implements PipeModule {
        public ModuleFields loadModule(final URI relativeURI, final String httpMethod, final byte[] requestBody) {
            final ModuleFields fields = new ModuleFields();
            fields.addQueryParameter("api_key", "SECRET123");
            return fields;
        }

        public boolean handleError(final HttpException exception) {
            return false;
        }
    }

    static final class NoOpModule implements PipeModule {
        public ModuleFields loadModule(final URI relativeURI, final String httpMethod, final byte[] requestBody) {
            return new ModuleFields();
        }

        public boolean handleError(final HttpException exception) {
            return false;
        }
    }

    static final class SignatureModule implements PipeModule {
        public ModuleFields loadModule(final URI relativeURI, final String httpMethod, final byte[] requestBody) {
            final ModuleFields fields = new ModuleFields();
            fields.addHeader("X-Signature", "abc123");
            fields.addQueryParameter("ts", "1700000000");
            return fields;
        }

        public boolean handleError(final HttpException exception) {
            return false;
        }
    }

    public static void main(final String[] args) throws Exception {
        title("METHOD 2  |  RestRunner.loadAuth(URI relativeURI, String httpMethod)");

        section("1. no modules registered - an empty ModuleFields is returned");
        show(new RestRunner());

        section("2. a single module contributing a header");
        show(new RestRunner(new BasicAuthModule()));

        section("3. a single module contributing a query parameter");
        show(new RestRunner(new ApiKeyModule()));

        section("4. a module contributing nothing - both isEmpty() guards skip their loops");
        show(new RestRunner(new NoOpModule()));

        section("5. several modules, aggregating headers and query parameters from all of them");
        show(new RestRunner(new BasicAuthModule(), new ApiKeyModule(), new SignatureModule(), new NoOpModule()));

        section("6. branch coverage summary");
        System.out.println("      modules is empty                                -> scenario 1");
        System.out.println("      moduleFields.getHeaders() not empty              -> scenarios 2, 5");
        System.out.println("      moduleFields.getHeaders() empty (guard skipped)  -> scenarios 3, 4");
        System.out.println("      moduleFields.getQueryParameters() not empty      -> scenarios 3, 5");
        System.out.println("      moduleFields.getQueryParameters() empty (guard skipped) -> scenarios 2, 4");
        System.out.println("      several modules aggregated into one ModuleFields -> scenario 5");

        title("END OF METHOD 2 SCENARIOS");
    }

    static void show(final RestRunner runner) throws Exception {
        final ModuleFields result = invokeLoadAuth(runner, new URI("http://example.org/widgets"), "GET");
        System.out.println("      headers          : " + result.getHeaders());
        System.out.println("      query parameters : " + result.getQueryParameters());
    }

    static ModuleFields invokeLoadAuth(final RestRunner runner, final URI relativeURI, final String httpMethod)
            throws Exception {
        final java.lang.reflect.Method m = RestRunner.class.getDeclaredMethod("loadAuth", URI.class, String.class);
        m.setAccessible(true);
        return (ModuleFields) m.invoke(runner, relativeURI, httpMethod);
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}








class HttpException extends RuntimeException {
}






interface PipeModule {
    ModuleFields loadModule(URI relativeURI, String httpMethod, byte[] requestBody);

    boolean handleError(HttpException exception);
}






class ModuleFields {
    private List<Pair<String, String>> queryParameters = new ArrayList<Pair<String, String>>();
    private List<Pair<String, String>> headers = new ArrayList<Pair<String, String>>();

    public List<Pair<String, String>> getQueryParameters() {
        return new ArrayList<Pair<String, String>>(queryParameters);
    }

    public void setQueryParameters(List<Pair<String, String>> queryParameters) {
        if (queryParameters == null) {
            throw new IllegalArgumentException("queryParameters may not be null");
        }
        this.queryParameters = new ArrayList<Pair<String, String>>(queryParameters);
    }

    public List<Pair<String, String>> getHeaders() {
        return new ArrayList<Pair<String, String>>(headers);
    }

    public void setHeaders(List<Pair<String, String>> headers) {
        if (headers == null) {
            throw new IllegalArgumentException("headers may not be null");
        }
        this.headers = new ArrayList<Pair<String, String>>(headers);
    }

    public void addHeader(String headerName, String headerValue) {
        Pair<String, String> newToken = new Pair<String, String>(headerName, headerValue);
        headers.add(newToken);
    }

    public void addQueryParameter(String parameterName, String parameterValue) {
        Pair<String, String> newParameter = new Pair<String, String>(parameterName, parameterValue);
        queryParameters.add(newParameter);
    }
}







final class RestRunner {

    private Set<PipeModule> modules = new HashSet<PipeModule>();

    RestRunner(final PipeModule... pipeModules) {
        for (final PipeModule m : pipeModules) {
            modules.add(m);
        }
    }

        
    private ModuleFields loadAuth(URI relativeURI, String httpMethod) {

        ModuleFields authFields = new ModuleFields();

        for (PipeModule module : modules) {
            ModuleFields moduleFields = module.loadModule(relativeURI, httpMethod, new byte[] {});
            if (!moduleFields.getHeaders().isEmpty()) {
                for (Pair<String, String> header : moduleFields.getHeaders()) {
                    authFields.addHeader(header.first, header.second);
                }
            }

            if (!moduleFields.getQueryParameters().isEmpty()) {
                for (Pair<String, String> header : moduleFields.getQueryParameters()) {
                    authFields.addQueryParameter(header.first, header.second);
                }
            }

        }

        return authFields;

    }
        
}









final class Log {
    private Log() {
    }

    public static int e(final String tag, final String msg) {
        System.out.println("        [E/" + tag + "] " + msg);
        return 0;
    }

    public static int e(final String tag, final String msg, final Throwable tr) {
        System.out.println("        [E/" + tag + "] " + msg + " (" + tr + ")");
        return 0;
    }

    public static int d(final String tag, final String msg) {
        System.out.println("        [D/" + tag + "] " + msg);
        return 0;
    }

    public static int w(final String tag, final String msg) {
        System.out.println("        [W/" + tag + "] " + msg);
        return 0;
    }
}

final class TextUtils {
    private TextUtils() {
    }

    public static String join(final CharSequence delimiter, final Iterable<?> tokens) {
        final StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (final Object token : tokens) {
            if (!first) {
                sb.append(delimiter);
            }
            first = false;
            sb.append(token);
        }
        return sb.toString();
    }

    public static boolean isEmpty(final CharSequence str) {
        return str == null || str.length() == 0;
    }
}







final class Pair<F, S> {
    public final F first;
    public final S second;

    public Pair(final F first, final S second) {
        this.first = first;
        this.second = second;
    }

    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof Pair)) {
            return false;
        }
        final Pair<?, ?> p = (Pair<?, ?>) o;
        return objectsEqual(p.first, first) && objectsEqual(p.second, second);
    }

    private static boolean objectsEqual(final Object a, final Object b) {
        return a == b || (a != null && a.equals(b));
    }

    @Override
    public int hashCode() {
        return (first == null ? 0 : first.hashCode()) ^ (second == null ? 0 : second.hashCode());
    }

    @Override
    public String toString() {
        return "Pair{" + first + " " + second + "}";
    }

    public static <A, B> Pair<A, B> create(final A a, final B b) {
        return new Pair<A, B>(a, b);
    }
}

