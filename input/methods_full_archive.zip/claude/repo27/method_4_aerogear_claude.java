









































import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class method_4_aerogear_claude {

    public static void main(final String[] args) throws Exception {
        title("METHOD 4  |  HttpRestProvider.get()");

        final TestServer server = new TestServer();
        server.start();
        try {
            final URL base = new URL("http://localhost:" + server.port() + "/widgets");

            section("1. a successful GET (HTTP 200) - the body and headers are read back");
            server.nextResponse(200, "{\"id\":1,\"name\":\"Sprocket\"}", "application/json");
            final HttpRestProvider provider = new HttpRestProvider(base, 2000);
            final HeaderAndBody ok = provider.get();
            System.out.println("      body : " + new String(ok.getBody(), "UTF-8"));
            System.out.println("      Content-Type header : " + ok.getHeader("Content-type"));

            section("2. HTTP 201 Created is also treated as success");
            server.nextResponse(201, "{\"id\":2,\"name\":\"Widget\"}", "application/json");
            final HeaderAndBody created = provider.get();
            System.out.println("      body : " + new String(created.getBody(), "UTF-8"));

            section("3. HTTP 204 No Content - an empty body, still success");
            server.nextResponse(204, "", "application/json");
            final HeaderAndBody noContent = provider.get();
            System.out.println("      body length : " + noContent.getBody().length);

            section("4. an error status (HTTP 404) - HttpException is thrown with the error body and headers");
            server.nextResponse(404, "{\"error\":\"not found\"}", "application/json");
            try {
                provider.get();
                System.out.println("      !! expected exception was not thrown");
            } catch (final HttpException e) {
                System.out.println("      HttpException status=" + e.getStatusCode() + ", data="
                        + new String(e.getData(), "UTF-8"));
            }

            section("5. the server is unreachable - the target method's own catch (IOException) fires");
            server.stop();
            try {
                provider.get();
                System.out.println("      !! expected exception was not thrown");
            } catch (final RuntimeException e) {
                System.out.println("      RuntimeException wrapping : " + e.getCause());
            }

            section("6. branch coverage summary");
            System.out.println("      HTTP_OK / HTTP_CREATED (real response body read)   -> scenarios 1, 2");
            System.out.println("      HTTP_NO_CONTENT (empty body)                        -> scenario 3");
            System.out.println("      default branch (HttpException with headers/body)    -> scenario 4");
            System.out.println("      catch (IOException e) -> RuntimeException            -> scenario 5");
            System.out.println("      the finally block's urlConnection.disconnect() runs in every scenario");
        } finally {
            server.stopIfRunning();
        }

        title("END OF METHOD 4 SCENARIOS");
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}






final class TestServer {

    private com.sun.net.httpserver.HttpServer httpServer;
    private int statusCode = 200;
    private String responseBody = "{}";
    private String contentType = "application/json";
    private boolean running;

    void start() throws java.io.IOException {
        httpServer = com.sun.net.httpserver.HttpServer.create(new java.net.InetSocketAddress("localhost", 0), 0);
        httpServer.createContext("/", new com.sun.net.httpserver.HttpHandler() {
            public void handle(final com.sun.net.httpserver.HttpExchange exchange) throws java.io.IOException {
                exchange.getRequestBody().close();
                exchange.getResponseHeaders().set("Content-Type", contentType);
                final byte[] out = responseBody.getBytes("UTF-8");
                exchange.sendResponseHeaders(statusCode, out.length);
                final java.io.OutputStream os = exchange.getResponseBody();
                os.write(out);
                os.close();
            }
        });
        httpServer.start();
        running = true;
    }

    void nextResponse(final int statusCode, final String body, final String contentType) {
        this.statusCode = statusCode;
        this.responseBody = body;
        this.contentType = contentType;
    }

    int port() {
        return httpServer.getAddress().getPort();
    }

    void stop() {
        if (running) {
            httpServer.stop(0);
            running = false;
        }
    }

    void stopIfRunning() {
        stop();
    }
}






interface Provider<T> {
    T get(Object... in);
}






interface HttpProvider {
    URL getUrl();

    HeaderAndBody get() throws HttpException;

    HeaderAndBody post(String data) throws HttpException;

    HeaderAndBody post(byte[] data) throws HttpException;

    HeaderAndBody put(String id, String data) throws HttpException;

    HeaderAndBody put(String id, byte[] data) throws HttpException;

    HeaderAndBody delete(String id) throws HttpException;

    void setDefaultHeader(String headerName, String headerValue);
}






class HeaderAndBody {
    private final byte[] body;
    private final Map<String, Object> headers;

    public HeaderAndBody(byte[] body, Map<String, Object> headers) {
        this.body = java.util.Arrays.copyOf(body, body.length);
        this.headers = new HashMap<String, Object>(headers);
    }

    public byte[] getBody() {
        return java.util.Arrays.copyOf(body, body.length);
    }

    public Object getHeader(String headerName) {
        return headers.get(headerName);
    }

    public void setHeader(String headerName, Object headerValue) {
        headers.put(headerName, headerValue);
    }
}






class HttpException extends RuntimeException {
    private static final String DEFAULT_MESSAGE = "The server returned the error code %d.";

    private final byte[] data;
    private final Map<String, String> headers = new HashMap<String, String>();
    private final int statusCode;

    public HttpException(byte[] data, int statusCode) {
        this(data, statusCode, String.format(java.util.Locale.getDefault(), DEFAULT_MESSAGE, statusCode), new HashMap<String, String>());
    }

    public HttpException(byte[] data, int statusCode, Map<String, String> headers) {
        this(data, statusCode, String.format(java.util.Locale.getDefault(), DEFAULT_MESSAGE, statusCode), headers);
    }

    public HttpException(byte[] data, int statusCode, String message) {
        this(data, statusCode, message, new HashMap<String, String>());
    }

    public HttpException(byte[] data, int statusCode, String message, Map<String, String> headers) {
        super(message);
        this.data = data;
        this.statusCode = statusCode;
        this.headers.putAll(headers);
    }

    public byte[] getData() {
        return java.util.Arrays.copyOf(data, data.length);
    }

    public int getStatusCode() {
        return statusCode;
    }

    public Map<String, String> getHeaders() {
        return new HashMap<String, String>(headers);
    }
}






final class UrlUtils {
    private static final String TAG = UrlUtils.class.getSimpleName();

    private UrlUtils() {
    }

    public static URL appendToBaseURL(final URL baseURL, String endpoint) {
        try {
            String baseString = baseURL.toString();
            if (endpoint.isEmpty()) {
                return baseURL;
            } else if (!baseString.endsWith("/") && !endpoint.startsWith("/")) {
                baseString += "/";
            } else if (baseString.endsWith("/") && endpoint.startsWith("/")) {
                endpoint = endpoint.replaceFirst("/", "");
            }
            return new URL(baseString + endpoint);
        } catch (java.net.MalformedURLException ex) {
            String message = "Could not append " + endpoint + " to " + baseURL.toString();
            Log.e(TAG, message, ex);
            throw new IllegalArgumentException(message, ex);
        }
    }

    public static URL appendQueryToBaseURL(final URL baseURL, String query) {
        if (query == null || query.isEmpty()) {
            return baseURL;
        }
        try {
            String baseString = baseURL.toString();
            if (baseString.endsWith("/")) {
                baseString = baseString.replaceAll("/$", "");
            }
            if (!query.startsWith("?")) {
                query = "?" + query;
            } else {
                query = query.replaceFirst("[?]", "");
                query = "?" + query;
            }
            return new URL(baseString + query);
        } catch (java.net.MalformedURLException ex) {
            String message = "Could not append " + query + " to " + baseURL.toString();
            Log.e(TAG, message, ex);
            throw new IllegalArgumentException(message, ex);
        }
    }
}






final class HttpRestProvider implements HttpProvider {

    private static final String TAG = HttpRestProvider.class.getSimpleName();
    private final URL url;
    private final Map<String, String> defaultHeaders = new HashMap<String, String>();
    private final Integer timeout;
    private final static CookieManager cm = new CookieManager();

    static {
        CookieHandler.setDefault(cm);
    }

    private final Provider<HttpURLConnection> connectionPreparer = new Provider<HttpURLConnection>() {
        @Override
        public HttpURLConnection get(Object... in) {
            String id = null;
            if (in != null) {
                id = (String) in[0];
            }

            URL resourceURL = HttpRestProvider.this.url;

            if (id != null) {
                resourceURL = UrlUtils.appendToBaseURL(HttpRestProvider.this.url, id);
            }

            HttpURLConnection urlConnection;
            try {
                urlConnection = (HttpURLConnection) resourceURL
                        .openConnection();

            } catch (IOException ex) {
                Log.e(TAG, String.format("Failed to open %s", resourceURL
                        .toString()), ex);
                throw new RuntimeException(ex);
            }

            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/json");

            for (Entry<String, String> entry : defaultHeaders.entrySet()) {
                urlConnection.setRequestProperty(entry.getKey(), entry
                        .getValue());
            }

            return urlConnection;

        }
    };

    public HttpRestProvider(URL url) {
        this.url = url;
        this.timeout = 0;
    }

    public HttpRestProvider(URL url, Integer timeout) {
        this.url = url;
        this.timeout = timeout;
    }

    @Override
    public URL getUrl() {
        return url;
    }

    
    @Override
    public HeaderAndBody get() throws HttpException {
        HttpURLConnection urlConnection = null;
        try {
            urlConnection = prepareConnection();
            return getHeaderAndBody(urlConnection);

        } catch (IOException e) {
            Log.e(TAG, "Error on GET of " + url, e);
            throw new RuntimeException(e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
    }
    

    @Override
    public HeaderAndBody post(String data) throws RuntimeException {
        return post(data.getBytes());
    }

    @Override
    public HeaderAndBody post(byte[] data) throws RuntimeException {
        HttpURLConnection urlConnection = null;

        try {
            urlConnection = prepareConnection();
            urlConnection.setRequestMethod("POST");
            addBodyRequest(urlConnection, data);
            return getHeaderAndBody(urlConnection);

        } catch (IOException e) {
            Log.e(TAG, "Error on POST of " + url, e);
            throw new RuntimeException(e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
    }

    @Override
    public HeaderAndBody put(String id, String data) throws RuntimeException {
        return put(id, data.getBytes());
    }

    @Override
    public HeaderAndBody put(String id, byte[] data) throws RuntimeException {
        HttpURLConnection urlConnection = null;

        try {
            urlConnection = prepareConnection(id);
            urlConnection.setRequestMethod("PUT");
            addBodyRequest(urlConnection, data);

            return getHeaderAndBody(urlConnection);
        } catch (IOException e) {
            Log.e(TAG, "Error on PUT of " + url, e);
            throw new RuntimeException(e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
    }

    @Override
    public HeaderAndBody delete(String id) throws RuntimeException {

        HttpURLConnection urlConnection = null;
        try {
            urlConnection = prepareConnection(id);
            urlConnection.setRequestMethod("DELETE");
            return getHeaderAndBody(urlConnection);
        } catch (IOException e) {
            Log.e(TAG, "Error on DELETE of " + url, e);
            throw new RuntimeException(e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
    }

    private void addBodyRequest(HttpURLConnection urlConnection, byte[] data)
            throws IOException {

        urlConnection.setDoOutput(true);

        if (data != null) {
            OutputStream out = new BufferedOutputStream(urlConnection
                    .getOutputStream());
            out.write(data);
            out.flush();
        }

    }

    private HttpURLConnection prepareConnection() throws IOException {
        return prepareConnection(null);
    }

    private HttpURLConnection prepareConnection(String id) {
        HttpURLConnection connection = connectionPreparer.get(id);
        connection.setReadTimeout(timeout);
        connection.setConnectTimeout(timeout);
        return connection;
    }

    @Override
    public void setDefaultHeader(String headerName, String headerValue) {
        defaultHeaders.put(headerName, headerValue);
    }

    private HeaderAndBody getHeaderAndBody(HttpURLConnection urlConnection)
            throws IOException {

        int statusCode = urlConnection.getResponseCode();
        HeaderAndBody result;
        Map<String, List<String>> headers;
        byte[] responseData;

        switch (statusCode) {
        case HttpURLConnection.HTTP_OK:
        case HttpURLConnection.HTTP_CREATED:
            InputStream in = new BufferedInputStream(urlConnection
                    .getInputStream());

            responseData = readBytes(in);

            break;

        case HttpURLConnection.HTTP_NO_CONTENT:
            responseData = new byte[0];

            break;

        default:
            InputStream err = new BufferedInputStream(urlConnection
                    .getErrorStream());

            byte[] errData = readBytes(err);
            Map<String, List<String>> errorListHeaders = urlConnection.getHeaderFields();
            Map<String, String> errorHeaders = new HashMap<String, String>();

            for (String header : errorListHeaders.keySet()) {

                String comma = "";
                StringBuilder errorHeaderBuilder = new StringBuilder();

                for (String errorHeader : errorListHeaders.get(header)) {
                    errorHeaderBuilder.append(comma).append(errorHeader);
                    comma = ",";
                }

                errorHeaders.put(header, errorHeaderBuilder.toString());

            }

            throw new HttpException(errData, statusCode, errorHeaders);

        }

        headers = urlConnection.getHeaderFields();
        result = new HeaderAndBody(responseData, new HashMap<String, Object>(
                headers.size()));

        for (Entry<String, List<String>> header : headers.entrySet()) {
            result.setHeader(header.getKey(), TextUtils.join(",", header.getValue()));
        }

        return result;

    }

    private byte[] readBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();

        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }

        return byteBuffer.toByteArray();
    }

}









final class Log {
    private Log() {
    }

    public static int e(final String tag, final String msg) {
        System.out.println("        [E/" + tag + "] " + msg);
        return 0;
    }

    public static int e(final String tag, final String msg, final Throwable tr) {
        System.out.println("        [E/" + tag + "] " + msg + " (" + tr + ")");
        return 0;
    }

    public static int d(final String tag, final String msg) {
        System.out.println("        [D/" + tag + "] " + msg);
        return 0;
    }

    public static int w(final String tag, final String msg) {
        System.out.println("        [W/" + tag + "] " + msg);
        return 0;
    }
}

final class TextUtils {
    private TextUtils() {
    }

    public static String join(final CharSequence delimiter, final Iterable<?> tokens) {
        final StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (final Object token : tokens) {
            if (!first) {
                sb.append(delimiter);
            }
            first = false;
            sb.append(token);
        }
        return sb.toString();
    }

    public static boolean isEmpty(final CharSequence str) {
        return str == null || str.length() == 0;
    }
}

