













































import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_1_aerogear_claude {

    public static void main(final String[] args) throws Exception {
        title("METHOD 1  |  RestAdapter.computePagedList(List<T>, HeaderAndBody, JSONObject, Pipe<T>)");

        final List<String> items = java.util.Arrays.asList("widget-1", "widget-2");
        final JSONObject where = new JSONObject().put("status", "active");
        final DummyPipe<String> pipe = new DummyPipe<String>();

        section("1. WEB_LINKING metadata location - a real Link header is parsed into next/previous ReadFilters");
        final PageConfig webLinkingConfig = new PageConfig();
        webLinkingConfig.setMetadataLocation(PageConfig.MetadataLocations.WEB_LINKING);
        final RestAdapter<String> webLinkingAdapter = new RestAdapter<String>(webLinkingConfig);
        final Map<String, Object> headers1 = new HashMap<String, Object>();
        headers1.put("Link", "<http://example.org/widgets?page=2>; rel=\"next\", "
                + "<http://example.org/widgets?page=0>; rel=\"previous\"");
        final HeaderAndBody response1 = new HeaderAndBody(new byte[0], headers1);
        final List<String> result1 = invokeComputePagedList(webLinkingAdapter, items, response1, where, pipe);
        final WrappingPagedList<String> paged1 = (WrappingPagedList<String>) result1;
        System.out.println("      result contents   : " + result1);
        System.out.println("      next filter       : " + paged1.getNextFilter());
        System.out.println("      previous filter    : " + paged1.getPreviousFilter());

        section("2. WEB_LINKING metadata location - no Link header at all, so paging is skipped entirely");
        final HeaderAndBody response2 = new HeaderAndBody(new byte[0], new HashMap<String, Object>());
        final List<String> result2 = invokeComputePagedList(webLinkingAdapter, items, response2, where, pipe);
        System.out.println("      same list instance returned unchanged : " + (result2 == items));

        section("3. WEB_LINKING metadata location - a malformed Link header triggers the ParseException catch");
        final Map<String, Object> headers3 = new HashMap<String, Object>();
        headers3.put("Link", "not a valid link header at all");
        final HeaderAndBody response3 = new HeaderAndBody(new byte[0], headers3);
        try {
            invokeComputePagedList(webLinkingAdapter, items, response3, where, pipe);
            System.out.println("      !! expected exception was not thrown");
        } catch (final RuntimeException e) {
            System.out.println("      RuntimeException wrapping : " + e.getCause());
        }

        section("4. HEADERS metadata location - a custom PageParameterExtractor supplies both filters");
        final PageConfig headersConfig = new PageConfig();
        headersConfig.setMetadataLocation(PageConfig.MetadataLocations.HEADERS);
        headersConfig.setPageParameterExtractor(new PageParameterExtractor<PageConfig>() {
            public ReadFilter getNextFilter(final HeaderAndBody response, final PageConfig config) {
                final ReadFilter f = new ReadFilter();
                f.setOffset(20);
                return f;
            }

            public ReadFilter getPreviousFilter(final HeaderAndBody response, final PageConfig config) {
                final ReadFilter f = new ReadFilter();
                f.setOffset(0);
                return f;
            }
        });
        final RestAdapter<String> headersAdapter = new RestAdapter<String>(headersConfig);
        final List<String> result4 = invokeComputePagedList(headersAdapter, items,
                new HeaderAndBody(new byte[0], new HashMap<String, Object>()), where, pipe);
        final WrappingPagedList<String> paged4 = (WrappingPagedList<String>) result4;
        System.out.println("      next filter (offset)     : " + paged4.getNextFilter().getOffset());
        System.out.println("      previous filter (offset) : " + paged4.getPreviousFilter().getOffset());
        System.out.println("      both filters carry the same 'where' clause that was passed in : "
                + (paged4.getNextFilter().getWhere() == where && paged4.getPreviousFilter().getWhere() == where));

        section("5. BODY metadata location - the same extractor-driven path as HEADERS");
        final PageConfig bodyConfig = new PageConfig();
        bodyConfig.setMetadataLocation(PageConfig.MetadataLocations.BODY);
        bodyConfig.setPageParameterExtractor(new PageParameterExtractor<PageConfig>() {
            public ReadFilter getNextFilter(final HeaderAndBody response, final PageConfig config) {
                return null;
            }

            public ReadFilter getPreviousFilter(final HeaderAndBody response, final PageConfig config) {
                return null;
            }
        });
        final RestAdapter<String> bodyAdapter = new RestAdapter<String>(bodyConfig);
        final List<String> result5 = invokeComputePagedList(bodyAdapter, items,
                new HeaderAndBody(new byte[0], new HashMap<String, Object>()), where, pipe);
        final WrappingPagedList<String> paged5 = (WrappingPagedList<String>) result5;
        System.out.println("      next filter (null, no where applied) : " + paged5.getNextFilter());
        System.out.println("      previous filter (null)                : " + paged5.getPreviousFilter());

        section("6. an unsupported metadata location - IllegalStateException");
        final PageConfig badConfig = new PageConfig();
        badConfig.setMetadataLocation(new MetadataLocation() {
            @Override
            public String toString() {
                return "unsupported";
            }
        });
        final RestAdapter<String> badAdapter = new RestAdapter<String>(badConfig);
        try {
            invokeComputePagedList(badAdapter, items, new HeaderAndBody(new byte[0], new HashMap<String, Object>()),
                    where, pipe);
            System.out.println("      !! expected exception was not thrown");
        } catch (final RuntimeException e) {
            System.out.println("      " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }

        section("7. branch coverage summary");
        System.out.println("      WEB_LINKING, Link header present, both rel links found -> scenario 1");
        System.out.println("      WEB_LINKING, no Link header -> return result unchanged  -> scenario 2");
        System.out.println("      WEB_LINKING, malformed header -> ParseException wrapped -> scenario 3");
        System.out.println("      HEADERS -> pageParameterExtractor drives both filters    -> scenario 4");
        System.out.println("      BODY -> same extractor-driven path as HEADERS            -> scenario 5");
        System.out.println("      unsupported location -> IllegalStateException            -> scenario 6");
        System.out.println("      nextRead != null / previousRead != null -> setWhere(where) -> scenarios 1, 4");

        title("END OF METHOD 1 SCENARIOS");
    }

    static final class DummyPipe<T> implements Pipe<T> {
        public void remove(final String id, final Callback<Void> callback) {
        }

        public void read(final ReadFilter filter, final Callback<List<T>> callback) {
        }
    }

    @SuppressWarnings("unchecked")
    static List<String> invokeComputePagedList(final RestAdapter<String> adapter, final List<String> result,
            final HeaderAndBody httpResponse, final JSONObject where, final Pipe<String> requestingPipe)
            throws Exception {
        final java.lang.reflect.Method m = RestAdapter.class.getDeclaredMethod("computePagedList", List.class,
                HeaderAndBody.class, JSONObject.class, Pipe.class);
        m.setAccessible(true);
        try {
            return (List<String>) m.invoke(adapter, result, httpResponse, where, requestingPipe);
        } catch (final java.lang.reflect.InvocationTargetException e) {
            if (e.getCause() instanceof RuntimeException) {
                throw (RuntimeException) e.getCause();
            }
            throw e;
        }
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}






interface Pipe<T> {
    void remove(String id, Callback<Void> callback);

    void read(ReadFilter filter, Callback<List<T>> callback);
}






interface Callback<T> {
    void onSuccess(T result);

    void onFailure(Exception e);
}






class HeaderAndBody {
    private final byte[] body;
    private final Map<String, Object> headers;

    public HeaderAndBody(byte[] body, Map<String, Object> headers) {
        this.body = java.util.Arrays.copyOf(body, body.length);
        this.headers = new HashMap<String, Object>(headers);
    }

    public byte[] getBody() {
        return java.util.Arrays.copyOf(body, body.length);
    }

    public Object getHeader(String headerName) {
        return headers.get(headerName);
    }

    public void setHeader(String headerName, Object headerValue) {
        headers.put(headerName, headerValue);
    }
}








final class RestAdapter<T> {

    private static final String TAG = RestAdapter.class.getSimpleName();

    private final PageConfig pageConfig;

    RestAdapter(final PageConfig pageConfig) {
        this.pageConfig = pageConfig;
    }

        
    private List<T> computePagedList(List<T> result, HeaderAndBody httpResponse, JSONObject where, Pipe<T> requestingPipe) {
        ReadFilter previousRead = null;
        ReadFilter nextRead = null;

        if (PageConfig.MetadataLocations.WEB_LINKING.equals(pageConfig.getMetadataLocation())) {
            String webLinksRaw = "";
            final String relHeader = "rel";
            final String nextIdentifier = pageConfig.getNextIdentifier();
            final String prevIdentifier = pageConfig.getPreviousIdentifier();
            try {
                webLinksRaw = getWebLinkHeader(httpResponse);
                if (webLinksRaw == null) { 
                    return result;
                }
                List<WebLink> webLinksParsed = WebLinkParser.parse(webLinksRaw);
                for (WebLink link : webLinksParsed) {
                    if (nextIdentifier.equals(link.getParameters().get(relHeader))) {
                        nextRead = new ReadFilter();
                        nextRead.setLinkUri(new URI(link.getUri()));
                    } else if (prevIdentifier.equals(link.getParameters().get(relHeader))) {
                        previousRead = new ReadFilter();
                        previousRead.setLinkUri(new URI(link.getUri()));
                    }

                }
            } catch (URISyntaxException ex) {
                Log.e(TAG, webLinksRaw + " did not contain a valid context URI", ex);
                throw new RuntimeException(ex);
            } catch (ParseException ex) {
                Log.e(TAG, webLinksRaw + " could not be parsed as a web link header", ex);
                throw new RuntimeException(ex);
            }
        } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.HEADERS)) {
            nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, RestAdapter.this.pageConfig);
            previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, RestAdapter.this.pageConfig);
        } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.BODY)) {
            nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, RestAdapter.this.pageConfig);
            previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, RestAdapter.this.pageConfig);
        } else {
            throw new IllegalStateException("Not supported");
        }
        if (nextRead != null) {
            nextRead.setWhere(where);
        }

        if (previousRead != null) {
            previousRead.setWhere(where);
        }

        return new WrappingPagedList<T>(requestingPipe, result, nextRead, previousRead);
    }
        

    private String getWebLinkHeader(HeaderAndBody httpResponse) {
        String linkHeaderName = "Link";
        Object header = httpResponse.getHeader(linkHeaderName);
        if (header != null) {
            return header.toString();
        }
        return null;
    }

}





class PageConfig {

    public static enum MetadataLocations implements MetadataLocation {

        WEB_LINKING("webLinking"),
        HEADERS("headers"),
        BODY("body");
        private final String value;

        private MetadataLocations(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    private MetadataLocation metadataLocation = MetadataLocations.WEB_LINKING;
    private String nextIdentifier = "next";
    private String previousIdentifier = "previous";
    private String offsetValue = "0";
    private Integer limitValue = 10;
    private ParameterProvider parameterProvider = new DefaultParameterProvider();
    private PageParameterExtractor pageParameterExtractor;

    






    public MetadataLocation getMetadataLocation() {
        return metadataLocation;
    }

    






    public void setMetadataLocation(MetadataLocation metadataLocation) {
        this.metadataLocation = metadataLocation;
    }

    





    public String getNextIdentifier() {
        return nextIdentifier;
    }

    







    public void setNextIdentifier(String nextIdentifier) {
        this.nextIdentifier = nextIdentifier;
    }

    





    public String getPreviousIdentifier() {
        return previousIdentifier;
    }

    






    public void setPreviousIdentifier(String previousIdentifier) {
        this.previousIdentifier = previousIdentifier;
    }

    





    public String getOffsetValue() {
        return offsetValue;
    }

    






    public void setOffsetValue(String offsetValue) {
        this.offsetValue = offsetValue;
    }

    





    public Integer getLimitValue() {
        return limitValue;
    }

    





    public void setLimitValue(Integer limitValue) {
        this.limitValue = limitValue;
    }

    




    public ParameterProvider getParameterProvider() {
        return parameterProvider;
    }

    




    public void setParameterProvider(ParameterProvider parameterProvider) {
        this.parameterProvider = parameterProvider;
    }

    








    public PageParameterExtractor getPageParameterExtractor() {
        return pageParameterExtractor;
    }

    









    public void setPageParameterExtractor(PageParameterExtractor pageParameterExtractor) {
        this.pageParameterExtractor = pageParameterExtractor;
    }
}







interface MetadataLocation {

}







interface ParameterProvider {

    




    public URI getParameters(ReadFilter filter);

}







class DefaultParameterProvider implements ParameterProvider {

    @Override
    public URI getParameters(ReadFilter filter) {
        return URI.create(filter.getQuery());
    }

}







interface PageParameterExtractor<T extends PageConfig> {

    







    public ReadFilter getNextFilter(HeaderAndBody response, T config);

    







    public ReadFilter getPreviousFilter(HeaderAndBody response, T config);
}








class WebLink {

    private static final java.util.regex.Pattern P = java.util.regex.Pattern.compile("\\s*<(.*)>\\s*(.*)");

    private static final String EQUALS = "=";

    private String uri;
    private Map<String, String> parameters;

    





    public WebLink(String headerContent) throws ParseException {
        java.util.regex.Matcher uriAndFields = P.matcher(headerContent);
        if (!uriAndFields.matches()) {
            throw new ParseException("Can not parse value:" + headerContent);
        }

        uri = uriAndFields.group(1);

        parameters = parseParams(uriAndFields.group(2));

    }

    private Map<String, String> parseParams(String group) throws ParseException {
        String[] params = group.split(";");
        HashMap<String, String> paramsMap = new HashMap<String, String>(params.length);
        for (String param : params) {
            if (param.trim().isEmpty()) {
                continue;
            }
            String[] pair = param.split(EQUALS);
            if (pair.length != 2) {
                throw new ParseException(param + " could not be parsed");
            } else {
                if (paramsMap.get(pair[0]) == null) {
                    paramsMap.put(pair[0], pair[1].replace("\"", ""));
                }
            }
        }
        return paramsMap;
    }

    


    public String getUri() {
        return uri;
    }

    



    public Map<String, String> getParameters() {
        return parameters;
    }

}









class WebLinkParser {

    private static final String TAG = WebLinkParser.class.getSimpleName();
    private static final Character COMMA = ',';
    private static final Character QUOTE = '"';
    private static final Character OPEN_LINK = '<';
    private static final Character CLOSE_LINK = '>';

    public static List<WebLink> parse(String linkHeader) throws ParseException {

        if (linkHeader == null) {
            throw new IllegalArgumentException("null String passed to WebLinkParser.parse");
        }

        List<WebLink> linksList = new ArrayList<WebLink>();

        boolean inBrackets = false;
        boolean inQuotes = false;

        char[] linkHeaderCharacters = linkHeader.trim().toCharArray();
        StringBuilder buffer = new StringBuilder(linkHeader.length());

        for (Character c : linkHeaderCharacters) {

            if (inBrackets) {
                inBrackets = !c.equals(CLOSE_LINK);
                appendPrintedCharacter(buffer, c);
            } else if (inQuotes) {
                inQuotes = !c.equals(QUOTE);
                appendPrintedCharacter(buffer, c);
            } else {
                inBrackets = c.equals(OPEN_LINK);
                inQuotes = c.equals(QUOTE);

                if (c.equals(COMMA)) {
                    String link = buffer.toString();
                    buffer.delete(0, buffer.length());
                    try {
                        linksList.add(new WebLink(link));
                    } catch (ParseException parseEx) {
                        Log.e(TAG, "Parse error", parseEx);
                        throw parseEx;
                    }
                } else {
                    appendPrintedCharacter(buffer, c);
                }

            }

        }
        if (buffer.toString().trim().length() > 0) {
            try {
                linksList.add(new WebLink(buffer.toString()));
            } catch (ParseException parseEx) {
                Log.e(TAG, "Parse error", parseEx);
                throw parseEx;
            }
        }
        return linksList;
    }

    private static void appendPrintedCharacter(StringBuilder buffer, Character c) {
        if (!Character.isWhitespace(c)) {
            buffer.append(c);
        }
    }
}







class ParseException extends Exception {

    public ParseException(String string) {
        super(string);
    }

}









interface PagedList<T> extends List<T> {

    




    public void next(Callback<List<T>> callback);

    




    public void previous(Callback<List<T>> callback);
}










class WrappingPagedList<T> extends ArrayList<T> implements PagedList<T> {

    private final Pipe<T> pipe;
    private final List<T> data;
    private final ReadFilter nextFilter;
    private final ReadFilter previousFilter;

    





    public WrappingPagedList(Pipe<T> pipe, List<T> data, ReadFilter nextFilter, ReadFilter previousFilter) {
        super(data);
        this.pipe = pipe;
        this.data = data;
        this.nextFilter = nextFilter;
        this.previousFilter = previousFilter;
    }

    @Override
    public void next(Callback<List<T>> callback) {
        pipe.read(nextFilter, callback);
    }

    @Override
    public void previous(Callback<List<T>> callback) {
        pipe.read(previousFilter, callback);
    }

    public ReadFilter getNextFilter() {
        return nextFilter;
    }

    public ReadFilter getPreviousFilter() {
        return previousFilter;
    }

}










class ReadFilter {

    private java.net.URI linkUri;
    private JSONObject where;
    private Integer limit;
    private Integer offset;

    public java.net.URI getLinkUri() {
        return linkUri;
    }

    public void setLinkUri(final java.net.URI linkUri) {
        this.linkUri = linkUri;
    }

    public JSONObject getWhere() {
        return where;
    }

    public void setWhere(final JSONObject where) {
        this.where = where;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(final Integer limit) {
        this.limit = limit;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(final Integer offset) {
        this.offset = offset;
    }

    
    public String getQuery() {
        if (linkUri != null) {
            return linkUri.getQuery() == null ? "" : linkUri.getQuery();
        }
        final StringBuilder sb = new StringBuilder();
        if (where != null) {
            sb.append(sb.length() > 0 ? "&" : "").append("where=").append(where);
        }
        if (limit != null) {
            sb.append(sb.length() > 0 ? "&" : "").append("limit=").append(limit);
        }
        if (offset != null) {
            sb.append(sb.length() > 0 ? "&" : "").append("offset=").append(offset);
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return "ReadFilter[linkUri=" + linkUri + ", where=" + where + ", limit=" + limit + ", offset=" + offset + "]";
    }
}









class JSONObject {
    private final java.util.Map<String, Object> values = new java.util.LinkedHashMap<String, Object>();

    public JSONObject put(final String name, final Object value) {
        values.put(name, value);
        return this;
    }

    public Object get(final String name) {
        return values.get(name);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (final java.util.Map.Entry<String, Object> e : values.entrySet()) {
            if (!first) {
                sb.append(',');
            }
            first = false;
            sb.append('"').append(e.getKey()).append("\":\"").append(e.getValue()).append('"');
        }
        return sb.append('}').toString();
    }
}









final class Log {
    private Log() {
    }

    public static int e(final String tag, final String msg) {
        System.out.println("        [E/" + tag + "] " + msg);
        return 0;
    }

    public static int e(final String tag, final String msg, final Throwable tr) {
        System.out.println("        [E/" + tag + "] " + msg + " (" + tr + ")");
        return 0;
    }

    public static int d(final String tag, final String msg) {
        System.out.println("        [D/" + tag + "] " + msg);
        return 0;
    }

    public static int w(final String tag, final String msg) {
        System.out.println("        [W/" + tag + "] " + msg);
        return 0;
    }
}

final class TextUtils {
    private TextUtils() {
    }

    public static String join(final CharSequence delimiter, final Iterable<?> tokens) {
        final StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (final Object token : tokens) {
            if (!first) {
                sb.append(delimiter);
            }
            first = false;
            sb.append(token);
        }
        return sb.toString();
    }

    public static boolean isEmpty(final CharSequence str) {
        return str == null || str.length() == 0;
    }
}







final class Pair<F, S> {
    public final F first;
    public final S second;

    public Pair(final F first, final S second) {
        this.first = first;
        this.second = second;
    }

    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof Pair)) {
            return false;
        }
        final Pair<?, ?> p = (Pair<?, ?>) o;
        return objectsEqual(p.first, first) && objectsEqual(p.second, second);
    }

    private static boolean objectsEqual(final Object a, final Object b) {
        return a == b || (a != null && a.equals(b));
    }

    @Override
    public int hashCode() {
        return (first == null ? 0 : first.hashCode()) ^ (second == null ? 0 : second.hashCode());
    }

    @Override
    public String toString() {
        return "Pair{" + first + " " + second + "}";
    }

    public static <A, B> Pair<A, B> create(final A a, final B b) {
        return new Pair<A, B>(a, b);
    }
}

