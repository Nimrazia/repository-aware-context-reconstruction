



































import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_2_geomajas_claude {

  
  
  
  
  static class SerializationUtils {
    static Object clone(Object o) {
      if (o == null) {
        return null;
      }
      try {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(bos)) {
          oos.writeObject(o);
        }
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()))) {
          return ois.readObject();
        }
      } catch (Exception e) {
        throw new RuntimeException("SerializationUtils.clone failed", e);
      }
    }
  }

  
  
  
  
  
  interface ClientWidgetInfo extends Serializable {
  }

  interface ServerSideOnlyInfo extends ClientWidgetInfo {
  }

  static class AttributeInfo implements Serializable {
    private final String name;

    AttributeInfo(String name) {
      this.name = name;
    }

    String getName() {
      return name;
    }

    @Override
    public String toString() {
      return name;
    }
  }

  static class FeatureInfo implements Serializable {
    private List<AttributeInfo> attributes = new ArrayList<>();

    List<AttributeInfo> getAttributes() {
      return attributes;
    }

    void setAttributes(List<AttributeInfo> attributes) {
      this.attributes = attributes;
    }
  }

  static class LayerInfo implements Serializable {
    private Map<String, ClientWidgetInfo> extraInfo = new HashMap<>();

    Map<String, ClientWidgetInfo> getExtraInfo() {
      return extraInfo;
    }

    void setExtraInfo(Map<String, ClientWidgetInfo> extraInfo) {
      this.extraInfo = extraInfo;
    }
  }

  static class VectorLayerInfo extends LayerInfo {
    private FeatureInfo featureInfo = new FeatureInfo();

    FeatureInfo getFeatureInfo() {
      return featureInfo;
    }
  }

  static class ClientLayerInfo implements Serializable, Cloneable {
    private String serverLayerId;
    private Map<String, ClientWidgetInfo> widgetInfo = new HashMap<>();
    private LayerInfo layerInfo = new LayerInfo();

    String getServerLayerId() {
      return serverLayerId;
    }

    void setServerLayerId(String id) {
      this.serverLayerId = id;
    }

    Map<String, ClientWidgetInfo> getWidgetInfo() {
      return widgetInfo;
    }

    void setWidgetInfo(Map<String, ClientWidgetInfo> widgetInfo) {
      this.widgetInfo = widgetInfo;
    }

    LayerInfo getLayerInfo() {
      return layerInfo;
    }

    void setLayerInfo(LayerInfo layerInfo) {
      this.layerInfo = layerInfo;
    }
  }

  static class ClientVectorLayerInfo extends ClientLayerInfo {
    private boolean creatable;
    private boolean updatable;
    private boolean deletable;
    private VectorLayerInfo vectorLayerInfo = new VectorLayerInfo();

    void setCreatable(boolean b) {
      creatable = b;
    }

    void setUpdatable(boolean b) {
      updatable = b;
    }

    void setDeletable(boolean b) {
      deletable = b;
    }

    FeatureInfo getFeatureInfo() {
      return vectorLayerInfo.getFeatureInfo();
    }

    @Override
    LayerInfo getLayerInfo() {
      return vectorLayerInfo;
    }

    @Override
    void setLayerInfo(LayerInfo layerInfo) {
      if (layerInfo instanceof VectorLayerInfo) {
        this.vectorLayerInfo = (VectorLayerInfo) layerInfo;
      }
    }

    @Override
    public String toString() {
      return "ClientVectorLayerInfo{serverLayerId=" + getServerLayerId() + ", creatable=" + creatable
          + ", updatable=" + updatable + ", deletable=" + deletable + ", attributes="
          + vectorLayerInfo.getFeatureInfo().getAttributes() + ", widgetInfo=" + getWidgetInfo() + "}";
    }
  }

  
  
  
  
  interface SecurityContext {
    boolean isLayerVisible(String layerId);

    boolean isLayerCreateAuthorized(String layerId);

    boolean isLayerUpdateAuthorized(String layerId);

    boolean isLayerDeleteAuthorized(String layerId);

    boolean isAttributeReadable(String layerId, Object feature, String attributeName);
  }

  
  
  static class SimpleSecurityContext implements SecurityContext {
    @Override
    public boolean isLayerVisible(String layerId) {
      return !"restricted".equals(layerId);
    }

    @Override
    public boolean isLayerCreateAuthorized(String layerId) {
      return true;
    }

    @Override
    public boolean isLayerUpdateAuthorized(String layerId) {
      return true;
    }

    @Override
    public boolean isLayerDeleteAuthorized(String layerId) {
      return false;
    }

    @Override
    public boolean isAttributeReadable(String layerId, Object feature, String attributeName) {
      return !"internalNotes".equals(attributeName);
    }
  }

  
  
  
  SecurityContext securityContext;

  method_2_geomajas_claude(SecurityContext securityContext) {
    this.securityContext = securityContext;
  }

  
  
  
  public Map<String, ClientWidgetInfo> securityClone(Map<String, ClientWidgetInfo> widgetInfo) {
    Map<String, ClientWidgetInfo> res = new HashMap<String, ClientWidgetInfo>();
    for (Map.Entry<String, ClientWidgetInfo> entry : widgetInfo.entrySet()) {
      ClientWidgetInfo value = entry.getValue();
      if (!(value instanceof ServerSideOnlyInfo)) {
        res.put(entry.getKey(), value);
      }
    }
    return res;
  }

  
  
  
  
  
  Map<String, ClientWidgetInfo> securityCloneLayerExtraInfo(Map<String, ClientWidgetInfo> extraInfo) {
    return securityClone(extraInfo);
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public ClientLayerInfo securityClone(ClientLayerInfo original) {
		
		if (null == original) {
			return null;
		}
		ClientLayerInfo client = null;
		String layerId = original.getServerLayerId();
		if (securityContext.isLayerVisible(layerId)) {
			client = (ClientLayerInfo) SerializationUtils.clone(original);
			client.setWidgetInfo(securityClone(original.getWidgetInfo()));
			client.getLayerInfo().setExtraInfo(securityCloneLayerExtraInfo(original.getLayerInfo().getExtraInfo()));
			if (client instanceof ClientVectorLayerInfo) {
				ClientVectorLayerInfo vectorLayer = (ClientVectorLayerInfo) client;
				
				vectorLayer.setCreatable(securityContext.isLayerCreateAuthorized(layerId));
				vectorLayer.setUpdatable(securityContext.isLayerUpdateAuthorized(layerId));
				vectorLayer.setDeletable(securityContext.isLayerDeleteAuthorized(layerId));
				
				FeatureInfo featureInfo = vectorLayer.getFeatureInfo();
				List<AttributeInfo> originalAttr = featureInfo.getAttributes();
				List<AttributeInfo> filteredAttr = new ArrayList<AttributeInfo>();
				featureInfo.setAttributes(filteredAttr);
				for (AttributeInfo ai : originalAttr) {
					if (securityContext.isAttributeReadable(layerId, null, ai.getName())) {
						filteredAttr.add(ai);
					}
				}
			}
		}
		return client;
	}
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: GetMapConfigurationCommand.securityClone(ClientLayerInfo) ===");

    method_2_geomajas_claude command = new method_2_geomajas_claude(new SimpleSecurityContext());

    
    
    ClientVectorLayerInfo original = new ClientVectorLayerInfo();
    original.setServerLayerId("countries");
    original.getFeatureInfo().getAttributes().add(new AttributeInfo("name"));
    original.getFeatureInfo().getAttributes().add(new AttributeInfo("internalNotes"));
    original.getLayerInfo().getExtraInfo().put("legend", new SerializableWidgetInfo("Legend for countries"));
    original.getLayerInfo().getExtraInfo().put("dbConn", new ServerOnlyWidgetInfo("jdbc:internal"));
    original.setWidgetInfo(new HashMap<>());
    original.getWidgetInfo().put("toolbar", new SerializableWidgetInfo("Toolbar config"));
    original.getWidgetInfo().put("secretConfig", new ServerOnlyWidgetInfo("secret"));

    ClientLayerInfo cloned = command.securityClone(original);
    System.out.println("\n-- Scenario A (visible vector layer) --");
    System.out.println("  clone: " + cloned);
    if (cloned instanceof ClientVectorLayerInfo) {
      ClientVectorLayerInfo cvl = (ClientVectorLayerInfo) cloned;
      System.out.println("  widgetInfo keys after filtering: " + cvl.getWidgetInfo().keySet());
      System.out.println("  extraInfo keys after filtering: " + cvl.getLayerInfo().getExtraInfo().keySet());
      System.out.println("  attributes after filtering: " + cvl.getFeatureInfo().getAttributes());
    }

    
    ClientVectorLayerInfo restricted = new ClientVectorLayerInfo();
    restricted.setServerLayerId("restricted");
    ClientLayerInfo restrictedClone = command.securityClone(restricted);
    System.out.println("\n-- Scenario B (invisible layer) --");
    System.out.println("  clone: " + restrictedClone);

    
    System.out.println("\n-- Scenario C (null input) --");
    System.out.println("  clone: " + command.securityClone((ClientLayerInfo) null));

    System.out.println("\n=== Demo complete: method exercised the visible/ClientVectorLayerInfo "
        + "branch (widget-info + extra-info + attribute filtering + status flags), the "
        + "invisible-layer branch, and the null-input short-circuit. ===");
  }

  
  static class SerializableWidgetInfo implements ClientWidgetInfo {
    String value;

    SerializableWidgetInfo(String value) {
      this.value = value;
    }

    @Override
    public String toString() {
      return "SerializableWidgetInfo{" + value + "}";
    }
  }

  static class ServerOnlyWidgetInfo implements ServerSideOnlyInfo {
    String value;

    ServerOnlyWidgetInfo(String value) {
      this.value = value;
    }

    @Override
    public String toString() {
      return "ServerOnlyWidgetInfo{" + value + "}";
    }
  }
}
