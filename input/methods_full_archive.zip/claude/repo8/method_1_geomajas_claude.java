































import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class method_1_geomajas_claude {

  
  
  
  
  
  
  interface ClientWidgetInfo extends Serializable {
  }

  interface ServerSideOnlyInfo extends ClientWidgetInfo {
  }

  
  static class LegendWidgetInfo implements ClientWidgetInfo {
    String title;

    LegendWidgetInfo(String title) {
      this.title = title;
    }

    @Override
    public String toString() {
      return "LegendWidgetInfo{title=" + title + "}";
    }
  }

  
  
  static class DatabaseConnectionWidgetInfo implements ServerSideOnlyInfo {
    String jdbcUrl;

    DatabaseConnectionWidgetInfo(String jdbcUrl) {
      this.jdbcUrl = jdbcUrl;
    }

    @Override
    public String toString() {
      return "DatabaseConnectionWidgetInfo{jdbcUrl=" + jdbcUrl + "}";
    }
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public Map<String, ClientWidgetInfo> securityClone(Map<String, ClientWidgetInfo> widgetInfo) {
		Map<String, ClientWidgetInfo> res = new HashMap<String, ClientWidgetInfo>();
		for (Map.Entry<String, ClientWidgetInfo> entry : widgetInfo.entrySet()) {
			ClientWidgetInfo value = entry.getValue();
			if (!(value instanceof ServerSideOnlyInfo)) {
				res.put(entry.getKey(), value);
			}
		}
		return res;
	}
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: GetMapConfigurationCommand.securityClone(Map) ===");

    method_1_geomajas_claude command = new method_1_geomajas_claude();

    Map<String, ClientWidgetInfo> widgetInfo = new HashMap<>();
    widgetInfo.put("legend", new LegendWidgetInfo("Layer legend"));
    widgetInfo.put("layerTree", new LegendWidgetInfo("Layer tree"));
    widgetInfo.put("dbConnection", new DatabaseConnectionWidgetInfo("jdbc:postgresql://internal-db/geo"));

    System.out.println("\n-- Input widgetInfo (" + widgetInfo.size() + " entries) --");
    for (Map.Entry<String, ClientWidgetInfo> e : widgetInfo.entrySet()) {
      System.out.println("  " + e.getKey() + " -> " + e.getValue());
    }

    Map<String, ClientWidgetInfo> filtered = command.securityClone(widgetInfo);

    System.out.println("\n-- Output after securityClone (" + filtered.size() + " entries; "
        + "ServerSideOnlyInfo entries stripped) --");
    for (Map.Entry<String, ClientWidgetInfo> e : filtered.entrySet()) {
      System.out.println("  " + e.getKey() + " -> " + e.getValue());
    }

    System.out.println("\n=== Demo complete: method filtered out the ServerSideOnlyInfo "
        + "(dbConnection) entry while preserving both regular ClientWidgetInfo entries. ===");
  }
}
