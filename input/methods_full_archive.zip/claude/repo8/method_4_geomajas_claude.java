



































import java.util.ArrayList;
import java.util.List;

public class method_4_geomajas_claude {

  
  
  
  
  interface CoordinateReferenceSystem {
    String getCode();
  }

  static class SimpleCrs implements CoordinateReferenceSystem {
    private final String code;

    SimpleCrs(String code) {
      this.code = code;
    }

    @Override
    public String getCode() {
      return code;
    }

    @Override
    public boolean equals(Object o) {
      return o instanceof SimpleCrs && ((SimpleCrs) o).code.equals(code);
    }

    @Override
    public int hashCode() {
      return code.hashCode();
    }

    @Override
    public String toString() {
      return code;
    }
  }

  static class MismatchedDimensionException extends Exception {
    MismatchedDimensionException(String msg) {
      super(msg);
    }
  }

  
  
  
  static class Envelope {
    double minX, maxX, minY, maxY;
    boolean isNull;

    Envelope(double minX, double maxX, double minY, double maxY) {
      this.minX = minX;
      this.maxX = maxX;
      this.minY = minY;
      this.maxY = maxY;
      this.isNull = false;
    }

    static Envelope nullEnvelope() {
      Envelope e = new Envelope(0, 0, 0, 0);
      e.isNull = true;
      return e;
    }

    double getWidth() {
      return isNull ? 0 : maxX - minX;
    }

    double getHeight() {
      return isNull ? 0 : maxY - minY;
    }

    boolean isNull() {
      return isNull;
    }

    @Override
    public String toString() {
      return isNull ? "Envelope[null]" : "Envelope[" + minX + "," + minY + " -> " + maxX + "," + maxY + "]";
    }
  }

  
  
  
  
  interface CrsTransform {
  }

  static class SimpleCrsTransform implements CrsTransform {
  }

  static class Bbox {
    private final double x, y, width, height;

    Bbox(double x, double y, double width, double height) {
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;
    }

    double getX() {
      return x;
    }

    double getY() {
      return y;
    }

    double getMaxX() {
      return x + width;
    }

    double getMaxY() {
      return y + height;
    }

    @Override
    public String toString() {
      return "Bbox[" + x + "," + y + " " + width + "x" + height + "]";
    }
  }

  static class TileCode {
    final int level, x, y;

    TileCode(int level, int x, int y) {
      this.level = level;
      this.x = x;
      this.y = y;
    }

    @Override
    public String toString() {
      return level + "/" + x + "/" + y;
    }
  }

  static class RasterTile {
    private final Bbox screenBox;
    private final String id;
    private TileCode code;
    private String url;

    RasterTile(Bbox screenBox, String id) {
      this.screenBox = screenBox;
      this.id = id;
    }

    void setCode(TileCode code) {
      this.code = code;
    }

    void setUrl(String url) {
      this.url = url;
    }

    @Override
    public String toString() {
      return "RasterTile{id=" + id + ", code=" + code + ", box=" + screenBox + ", url=" + url + "}";
    }
  }

  
  
  
  
  static class Coordinate {
    final double x, y;

    Coordinate(double x, double y) {
      this.x = x;
      this.y = y;
    }
  }

  static class Resolution {
    private final int level;
    private final double tileWidth;
    private final double tileHeight;
    private final int tileWidthPx;
    private final int tileHeightPx;

    Resolution(int level, double tileWidth, double tileHeight, int tileWidthPx, int tileHeightPx) {
      this.level = level;
      this.tileWidth = tileWidth;
      this.tileHeight = tileHeight;
      this.tileWidthPx = tileWidthPx;
      this.tileHeightPx = tileHeightPx;
    }

    int getLevel() {
      return level;
    }

    double getTileWidth() {
      return tileWidth;
    }

    double getTileHeight() {
      return tileHeight;
    }

    int getTileWidthPx() {
      return tileWidthPx;
    }

    int getTileHeightPx() {
      return tileHeightPx;
    }
  }

  static class RasterGrid {
    private final int xmin, xmax, ymin, ymax;
    private final Coordinate lowerLeft;
    private final double tileWidth, tileHeight;

    RasterGrid(int xmin, int xmax, int ymin, int ymax, Coordinate lowerLeft, double tileWidth, double tileHeight) {
      this.xmin = xmin;
      this.xmax = xmax;
      this.ymin = ymin;
      this.ymax = ymax;
      this.lowerLeft = lowerLeft;
      this.tileWidth = tileWidth;
      this.tileHeight = tileHeight;
    }

    int getXmin() {
      return xmin;
    }

    int getXmax() {
      return xmax;
    }

    int getYmin() {
      return ymin;
    }

    int getYmax() {
      return ymax;
    }

    Coordinate getLowerLeft() {
      return lowerLeft;
    }

    double getTileWidth() {
      return tileWidth;
    }

    double getTileHeight() {
      return tileHeight;
    }
  }

  
  
  
  interface GeoService {
    CrsTransform getCrsTransform(CoordinateReferenceSystem source, CoordinateReferenceSystem target)
        throws MismatchedDimensionException;

    Envelope transform(Envelope bounds, CrsTransform transform);

    Bbox transform(Bbox bbox, CrsTransform transform);
  }

  
  
  
  
  enum ExceptionCode {
    RENDER_DIMENSION_MISMATCH
  }

  static class GeomajasException extends Exception {
    GeomajasException(Exception cause, ExceptionCode code) {
      super(code.toString(), cause);
    }
  }

  
  
  
  
  String id;
  CoordinateReferenceSystem crs;
  GeoService geoService;
  List<Resolution> resolutions = new ArrayList<>();
  
  static final int TILE_WIDTH_PX = 256;
  static final int TILE_HEIGHT_PX = 256;

  String getId() {
    return id;
  }

  
  
  
  Envelope clipBounds(Envelope bounds) {
    return bounds;
  }

  
  
  
  
  
  Resolution getResolutionForScale(double scale) {
    Resolution best = resolutions.get(resolutions.size() - 1);
    for (Resolution r : resolutions) {
      double metersPerTilePx = r.getTileWidth() / r.getTileWidthPx();
      if (metersPerTilePx <= 1.0 / scale) {
        best = r;
        break;
      }
    }
    return best;
  }

  
  
  
  RasterGrid getRasterGrid(Envelope bounds, double tileWidth, double tileHeight) {
    int xmin = (int) Math.floor(bounds.minX / tileWidth);
    int xmax = (int) Math.ceil(bounds.maxX / tileWidth);
    int ymin = (int) Math.floor(bounds.minY / tileHeight);
    int ymax = (int) Math.ceil(bounds.maxY / tileHeight);
    Coordinate lowerLeft = new Coordinate(xmin * tileWidth, ymin * tileHeight);
    return new RasterGrid(xmin, xmax, ymin, ymax, lowerLeft, tileWidth, tileHeight);
  }

  
  
  
  String formatUrl(int widthPx, int heightPx, Bbox layerBox) {
    return "wms?SERVICE=WMS&REQUEST=GetMap&LAYERS=" + id + "&WIDTH=" + widthPx + "&HEIGHT=" + heightPx
        + "&BBOX=" + layerBox.getX() + "," + layerBox.getY() + "," + layerBox.getMaxX() + "," + layerBox.getMaxY();
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public List<RasterTile> paint(CoordinateReferenceSystem targetCrs, Envelope bounds, double scale)
			throws GeomajasException {
		Envelope layerBounds = bounds;
		double layerScale = scale;
		CrsTransform layerToMap = null;
		boolean needTransform = !crs.equals(targetCrs);

		try {
			
			
			
			if (needTransform) {
				layerToMap = geoService.getCrsTransform(crs, targetCrs);
				CrsTransform mapToLayer = geoService.getCrsTransform(targetCrs, crs);

				
				layerBounds = geoService.transform(bounds, mapToLayer);
				layerScale = bounds.getWidth() * scale / layerBounds.getWidth();
			}
		} catch (MismatchedDimensionException e) {
			throw new GeomajasException(e, ExceptionCode.RENDER_DIMENSION_MISMATCH);
		}
		layerBounds = clipBounds(layerBounds);
		if (layerBounds.isNull()) {
			return new ArrayList<RasterTile>(0);
		}

		
		Resolution bestResolution = getResolutionForScale(layerScale);
		RasterGrid grid = getRasterGrid(layerBounds, bestResolution.getTileWidth(), bestResolution.getTileHeight());

		
		List<RasterTile> result = new ArrayList<RasterTile>();
		for (int i = grid.getXmin(); i < grid.getXmax(); i++) {
			for (int j = grid.getYmin(); j < grid.getYmax(); j++) {
				double x = grid.getLowerLeft().x + (i - grid.getXmin()) * grid.getTileWidth();
				double y = grid.getLowerLeft().y + (j - grid.getYmin()) * grid.getTileHeight();
				
				Bbox worldBox;
				Bbox layerBox;
				if (needTransform) {
					layerBox = new Bbox(x, y, grid.getTileWidth(), grid.getTileHeight());
					
					
					worldBox = geoService.transform(layerBox, layerToMap);
				} else {
					worldBox = new Bbox(x, y, grid.getTileWidth(), grid.getTileHeight());
					layerBox = worldBox;
				}
				
				Bbox screenBox = new Bbox(Math.round(scale * worldBox.getX()), -Math.round(scale * worldBox.getMaxY()),
						Math.round(scale * worldBox.getMaxX()) - Math.round(scale * worldBox.getX()), Math.round(scale
								* worldBox.getMaxY())
								- Math.round(scale * worldBox.getY()));

				RasterTile image = new RasterTile(screenBox, getId() + "." + bestResolution.getLevel() + "." + i + ","
						+ j);

				image.setCode(new TileCode(bestResolution.getLevel(), i, j));
				String url = formatUrl(bestResolution.getTileWidthPx(), bestResolution.getTileHeightPx(), layerBox);
				image.setUrl(url);
				result.add(image);
			}
		}

		return result;
	}
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: WmsLayer.paint ===");

    method_4_geomajas_claude layer = new method_4_geomajas_claude();
    layer.id = "countries";
    SimpleCrs epsg4326 = new SimpleCrs("EPSG:4326");
    SimpleCrs epsg3857 = new SimpleCrs("EPSG:3857");
    layer.crs = epsg4326;
    
    layer.resolutions.add(new Resolution(0, 40.0, 40.0, TILE_WIDTH_PX, TILE_HEIGHT_PX));
    layer.resolutions.add(new Resolution(1, 20.0, 20.0, TILE_WIDTH_PX, TILE_HEIGHT_PX));
    layer.resolutions.add(new Resolution(2, 10.0, 10.0, TILE_WIDTH_PX, TILE_HEIGHT_PX));

    
    layer.geoService = new GeoService() {
      @Override
      public CrsTransform getCrsTransform(CoordinateReferenceSystem source, CoordinateReferenceSystem target) {
        return new SimpleCrsTransform();
      }

      @Override
      public Envelope transform(Envelope bounds, CrsTransform transform) {
        return bounds;
      }

      @Override
      public Bbox transform(Bbox bbox, CrsTransform transform) {
        return bbox;
      }
    };

    Envelope requestBoundsA = new Envelope(0, 40, 0, 40);
    List<RasterTile> tilesA = layer.paint(epsg4326, requestBoundsA, 1.0);
    System.out.println("\n-- Scenario A (same CRS, bounds=" + requestBoundsA + ", scale=1.0) --");
    System.out.println("  tile count: " + tilesA.size());
    for (RasterTile t : tilesA) {
      System.out.println("  " + t);
    }

    
    List<RasterTile> tilesB = layer.paint(epsg3857, new Envelope(0, 20, 0, 20), 2.0);
    System.out.println("\n-- Scenario B (CRS transform branch, bounds=[0,20,0,20], scale=2.0) --");
    System.out.println("  tile count: " + tilesB.size());
    for (RasterTile t : tilesB) {
      System.out.println("  " + t);
    }

    
    method_4_geomajas_claude layerClipped = new method_4_geomajas_claude() {
      @Override
      Envelope clipBounds(Envelope bounds) {
        return Envelope.nullEnvelope();
      }
    };
    layerClipped.id = "clipped";
    layerClipped.crs = epsg4326;
    layerClipped.resolutions.add(new Resolution(0, 40.0, 40.0, TILE_WIDTH_PX, TILE_HEIGHT_PX));
    layerClipped.geoService = layer.geoService;
    List<RasterTile> tilesC = layerClipped.paint(epsg4326, new Envelope(0, 40, 0, 40), 1.0);
    System.out.println("\n-- Scenario C (clipBounds -> null envelope) --");
    System.out.println("  tile count: " + tilesC.size());

    System.out.println("\n=== Demo complete: method exercised the same-CRS identity path, the "
        + "CRS-transform path (getCrsTransform/transform + layerScale rescale), the "
        + "clipBounds-null-envelope early return, and the nested tile grid construction with "
        + "formatUrl/setCode/setUrl wiring. ===");
  }
}
