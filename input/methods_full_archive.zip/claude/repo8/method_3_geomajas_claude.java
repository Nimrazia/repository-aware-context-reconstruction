



































import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_3_geomajas_claude {

  
  
  
  
  
  
  static class Geometry {
    final double minX, minY, maxX, maxY;

    Geometry(double minX, double minY, double maxX, double maxY) {
      this.minX = minX;
      this.minY = minY;
      this.maxX = maxX;
      this.maxY = maxY;
    }

    double getArea() {
      return Math.max(0, maxX - minX) * Math.max(0, maxY - minY);
    }

    Geometry buffer(double distance) {
      return new Geometry(minX - distance, minY - distance, maxX + distance, maxY + distance);
    }

    Geometry intersection(Geometry other) {
      double ix1 = Math.max(minX, other.minX);
      double iy1 = Math.max(minY, other.minY);
      double ix2 = Math.min(maxX, other.maxX);
      double iy2 = Math.min(maxY, other.maxY);
      if (ix2 < ix1 || iy2 < iy1) {
        return new Geometry(0, 0, 0, 0);
      }
      return new Geometry(ix1, iy1, ix2, iy2);
    }

    @Override
    public String toString() {
      return "Geometry[" + minX + "," + minY + " -> " + maxX + "," + maxY + "]";
    }
  }

  static class GeometryDto {
    double minX, minY, maxX, maxY;

    GeometryDto(double minX, double minY, double maxX, double maxY) {
      this.minX = minX;
      this.minY = minY;
      this.maxX = maxX;
      this.maxY = maxY;
    }
  }

  
  
  
  
  interface Command<REQ, RESP> {
    void execute(REQ request, RESP response) throws Exception;
  }

  enum ExceptionCode {
    PARAMETER_MISSING
  }

  static class GeomajasException extends Exception {
    GeomajasException(ExceptionCode code, String param) {
      super(code + ": " + param);
    }
  }

  
  
  
  
  static class SearchByLocationRequest {
    static final int QUERY_INTERSECTS = 1;
    static final int QUERY_CONTAINS = 2;
    static final int QUERY_TOUCHES = 3;
    static final int QUERY_WITHIN = 4;
    static final int SEARCH_FIRST_LAYER = 1;
    static final int SEARCH_ALL_LAYERS = 2;

    String[] layerIds;
    Map<String, String> clientToServerLayerId = new HashMap<>();
    String crs;
    GeometryDto location;
    double buffer;
    int queryType = QUERY_INTERSECTS;
    double ratio = -1;
    int searchType = SEARCH_ALL_LAYERS;
    Map<String, String> perLayerFilter = new HashMap<>();
    String globalFilter;
    Object featureIncludes;

    String[] getLayerIds() {
      return layerIds;
    }

    String getCrs() {
      return crs;
    }

    GeometryDto getLocation() {
      return location;
    }

    double getBuffer() {
      return buffer;
    }

    int getQueryType() {
      return queryType;
    }

    double getRatio() {
      return ratio;
    }

    int getSearchType() {
      return searchType;
    }

    String getServerLayerId(String clientLayerId) {
      return clientToServerLayerId.get(clientLayerId);
    }

    String getFilter(String clientLayerId) {
      return perLayerFilter.get(clientLayerId);
    }

    String getFilter() {
      return globalFilter;
    }

    Object getFeatureIncludes() {
      return featureIncludes;
    }
  }

  static class Feature {
    String id;
    String crs;

    void setCrs(String crs) {
      this.crs = crs;
    }

    @Override
    public String toString() {
      return "Feature{id=" + id + ", crs=" + crs + "}";
    }
  }

  static class InternalFeature {
    String id;
    Geometry geometry;

    InternalFeature(String id, Geometry geometry) {
      this.id = id;
      this.geometry = geometry;
    }

    Geometry getGeometry() {
      return geometry;
    }

    @Override
    public String toString() {
      return "InternalFeature{id=" + id + ", geometry=" + geometry + "}";
    }
  }

  static class SearchByLocationResponse {
    final Map<String, List<Feature>> layerFeatures = new HashMap<>();

    void addLayer(String clientLayerId, List<Feature> features) {
      layerFeatures.put(clientLayerId, features);
    }
  }

  
  
  
  
  
  
  static class Crs {
    final String code;

    Crs(String code) {
      this.code = code;
    }

    @Override
    public String toString() {
      return code;
    }
  }

  interface DtoConverterService {
    Geometry toInternal(GeometryDto dto);

    Feature toDto(InternalFeature feature);
  }

  interface GeoService {
    Crs getCrs2(String crsCode) throws GeomajasException;

    Geometry transform(Geometry geometry, Crs source, Crs target);
  }

  interface SecurityContext {
    boolean isLayerVisible(String layerId);
  }

  static class FeatureInfoDescriptor {
    private final String geometryTypeName;

    FeatureInfoDescriptor(String geometryTypeName) {
      this.geometryTypeName = geometryTypeName;
    }

    NamedType getGeometryType() {
      return new NamedType(geometryTypeName);
    }
  }

  static class NamedType {
    private final String name;

    NamedType(String name) {
      this.name = name;
    }

    String getName() {
      return name;
    }
  }

  static class VectorLayerInfo {
    private final FeatureInfoDescriptor featureInfo;

    VectorLayerInfo(FeatureInfoDescriptor featureInfo) {
      this.featureInfo = featureInfo;
    }

    FeatureInfoDescriptor getFeatureInfo() {
      return featureInfo;
    }
  }

  static class VectorLayer {
    private final VectorLayerInfo layerInfo;

    VectorLayer(VectorLayerInfo layerInfo) {
      this.layerInfo = layerInfo;
    }

    VectorLayerInfo getLayerInfo() {
      return layerInfo;
    }
  }

  interface ConfigurationService {
    VectorLayer getVectorLayer(String serverLayerId);
  }

  interface Filter {
  }

  static class NamedFilter implements Filter {
    final String description;

    NamedFilter(String description) {
      this.description = description;
    }

    @Override
    public String toString() {
      return description;
    }
  }

  interface FilterCreator {
    Filter createIntersectsFilter(Geometry geometry, String geomName);

    Filter createContainsFilter(Geometry geometry, String geomName);

    Filter createTouchesFilter(Geometry geometry, String geomName);

    Filter createWithinFilter(Geometry geometry, String geomName);

    Filter parseFilter(String filterText) throws GeomajasException;

    Filter createAndFilter(Filter a, Filter b);
  }

  interface VectorLayerService {
    Crs getCrs(VectorLayer layer);

    List<InternalFeature> getFeatures(String serverLayerId, Crs crs, Filter filter, Object extraFilter,
        Object featureIncludes) throws GeomajasException;
  }

  
  
  
  static class Log {
    void debug(String msg) {
      System.out.println("[DEBUG] " + msg);
    }

    void trace(String msg) {
      System.out.println("[TRACE] " + msg);
    }
  }

  
  
  
  
  final Log log = new Log();
  DtoConverterService converter;
  GeoService geoService;
  SecurityContext securityContext;
  ConfigurationService configurationService;
  VectorLayerService layerService;
  FilterCreator filterCreator;

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public void execute(SearchByLocationRequest request, SearchByLocationResponse response) throws Exception {
		if (null == request.getLayerIds()) {
			throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, "layerIds");
		}
		String crsCode = request.getCrs();
		if (null == crsCode) {
			throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, "crs");
		}
		Geometry location = converter.toInternal(request.getLocation());
		int queryType = request.getQueryType();
		double ratio = request.getRatio();
		int searchType = request.getSearchType();
		Crs crs = geoService.getCrs2(request.getCrs());

		
		Geometry geometry = location;
		if (request.getBuffer() > 0) {
			geometry = location.buffer(request.getBuffer());
		}
		log.debug("search by location " + geometry);

		for (String clientLayerId : request.getLayerIds()) {
			String serverLayerId = request.getServerLayerId(clientLayerId);
			if (null == serverLayerId) {
				throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, 
								"serverLayerId for clientLayerId " + clientLayerId);
			}
			if (securityContext.isLayerVisible(serverLayerId)) {
				VectorLayer vectorLayer = configurationService.getVectorLayer(serverLayerId);
				if (vectorLayer != null) {
					String geomName = vectorLayer.getLayerInfo().getFeatureInfo().getGeometryType().getName();

					
					Geometry layerGeometry = geoService.transform(geometry, crs, layerService.getCrs(vectorLayer));
					log.trace("on layer " + serverLayerId + " use " + layerGeometry);

					
					Filter f = null;
					switch (queryType) {
						case SearchByLocationRequest.QUERY_INTERSECTS:
							f = filterCreator.createIntersectsFilter(layerGeometry, geomName);
							break;
						case SearchByLocationRequest.QUERY_CONTAINS:
							f = filterCreator.createContainsFilter(layerGeometry, geomName);
							break;
						case SearchByLocationRequest.QUERY_TOUCHES:
							f = filterCreator.createTouchesFilter(layerGeometry, geomName);
							break;
						case SearchByLocationRequest.QUERY_WITHIN:
							f = filterCreator.createWithinFilter(layerGeometry, geomName);
							break;
						default:
							throw new IllegalArgumentException("Unknown query type " + queryType);
					}
					
					if (null != request.getFilter(clientLayerId)) {
						if (null == f) {
							f = filterCreator.parseFilter(request.getFilter(clientLayerId));
						} else {
							f = filterCreator.createAndFilter(
									filterCreator.parseFilter(request.getFilter(clientLayerId)), f);
						}
					}
					
					if (null != request.getFilter()) {
						if (null == f) {
							f = filterCreator.parseFilter(request.getFilter());
						} else {
							f = filterCreator.createAndFilter(filterCreator.parseFilter(request.getFilter()), f);
						}
					}

					
					List<InternalFeature> temp = layerService.getFeatures(serverLayerId, crs, f, null, request
							.getFeatureIncludes());
					if (temp.size() > 0) {
						List<Feature> features = new ArrayList<Feature>();

						
						if (queryType == SearchByLocationRequest.QUERY_INTERSECTS && ratio >= 0 && ratio < 1) {
							for (InternalFeature feature : temp) {
								double minimalOverlap = feature.getGeometry().getArea() * ratio;
								Geometry overlap = geometry.intersection(feature.getGeometry());
								double effectiveOverlap = overlap.getArea();
								if (minimalOverlap <= effectiveOverlap) {
									log.trace("found " + feature);
									Feature dto = converter.toDto(feature);
									dto.setCrs(crsCode);
									features.add(dto);
								}
							}
						} else {
							for (InternalFeature feature : temp) {
								log.trace("found " + feature);
								Feature dto = converter.toDto(feature);
								dto.setCrs(crsCode);
								features.add(dto);
							}
						}

						
						if (features.size() > 0) {
							
							response.addLayer(clientLayerId, features);

							
							if (searchType == SearchByLocationRequest.SEARCH_FIRST_LAYER) {
								break;
							}
						}
					}
				}
			}
		}
	}
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: SearchByLocationCommand.execute ===");

    method_3_geomajas_claude command = new method_3_geomajas_claude();

    final Crs mapCrs = new Crs("EPSG:4326");
    final Crs layerCrs = new Crs("EPSG:4326"); 

    command.converter = new DtoConverterService() {
      @Override
      public Geometry toInternal(GeometryDto dto) {
        return new Geometry(dto.minX, dto.minY, dto.maxX, dto.maxY);
      }

      @Override
      public Feature toDto(InternalFeature feature) {
        Feature f = new Feature();
        f.id = feature.id;
        return f;
      }
    };
    command.geoService = new GeoService() {
      @Override
      public Crs getCrs2(String crsCode) {
        return mapCrs;
      }

      @Override
      public Geometry transform(Geometry geometry, Crs source, Crs target) {
        return geometry; 
      }
    };
    command.securityContext = layerId -> !"restrictedLayer".equals(layerId);

    VectorLayer countriesLayer = new VectorLayer(new VectorLayerInfo(new FeatureInfoDescriptor("geom")));
    command.configurationService = serverLayerId -> "countries".equals(serverLayerId) ? countriesLayer : null;
    command.layerService = new VectorLayerService() {
      @Override
      public Crs getCrs(VectorLayer layer) {
        return layerCrs;
      }

      @Override
      public List<InternalFeature> getFeatures(String serverLayerId, Crs crs, Filter filter, Object extraFilter,
          Object featureIncludes) {
        List<InternalFeature> feats = new ArrayList<>();
        
        feats.add(new InternalFeature("f1", new Geometry(0, 0, 10, 10)));
        feats.add(new InternalFeature("f2", new Geometry(9, 9, 20, 20)));
        return feats;
      }
    };
    command.filterCreator = new FilterCreator() {
      @Override
      public Filter createIntersectsFilter(Geometry geometry, String geomName) {
        return new NamedFilter("INTERSECTS(" + geomName + ")");
      }

      @Override
      public Filter createContainsFilter(Geometry geometry, String geomName) {
        return new NamedFilter("CONTAINS(" + geomName + ")");
      }

      @Override
      public Filter createTouchesFilter(Geometry geometry, String geomName) {
        return new NamedFilter("TOUCHES(" + geomName + ")");
      }

      @Override
      public Filter createWithinFilter(Geometry geometry, String geomName) {
        return new NamedFilter("WITHIN(" + geomName + ")");
      }

      @Override
      public Filter parseFilter(String filterText) {
        return new NamedFilter("PARSED(" + filterText + ")");
      }

      @Override
      public Filter createAndFilter(Filter a, Filter b) {
        return new NamedFilter("AND(" + a + "," + b + ")");
      }
    };

    
    
    SearchByLocationRequest requestA = new SearchByLocationRequest();
    requestA.layerIds = new String[] { "countriesClient" };
    requestA.clientToServerLayerId.put("countriesClient", "countries");
    requestA.crs = "EPSG:4326";
    requestA.location = new GeometryDto(0, 0, 10, 10);
    requestA.queryType = SearchByLocationRequest.QUERY_INTERSECTS;
    requestA.ratio = 0.5;
    requestA.searchType = SearchByLocationRequest.SEARCH_ALL_LAYERS;

    SearchByLocationResponse responseA = new SearchByLocationResponse();
    command.execute(requestA, responseA);

    System.out.println("\n-- Scenario A (intersects, ratio=0.5) --");
    for (Map.Entry<String, List<Feature>> e : responseA.layerFeatures.entrySet()) {
      System.out.println("  " + e.getKey() + " -> " + e.getValue());
    }

    
    SearchByLocationRequest requestB = new SearchByLocationRequest();
    requestB.layerIds = new String[] { "restrictedClient" };
    requestB.clientToServerLayerId.put("restrictedClient", "restrictedLayer");
    requestB.crs = "EPSG:4326";
    requestB.location = new GeometryDto(0, 0, 10, 10);

    SearchByLocationResponse responseB = new SearchByLocationResponse();
    command.execute(requestB, responseB);
    System.out.println("\n-- Scenario B (invisible layer) --");
    System.out.println("  layers in response: " + responseB.layerFeatures.keySet());

    
    System.out.println("\n-- Scenario C (missing layerIds) --");
    try {
      command.execute(new SearchByLocationRequest(), new SearchByLocationResponse());
      System.out.println("  (unexpectedly did not throw)");
    } catch (GeomajasException e) {
      System.out.println("  caught expected GeomajasException: " + e.getMessage());
    }

    System.out.println("\n=== Demo complete: method exercised the intersects+ratio overlap "
        + "filter, per-layer and global Filter composition, the invisible-layer skip, and the "
        + "PARAMETER_MISSING validation branch. ===");
  }
}
