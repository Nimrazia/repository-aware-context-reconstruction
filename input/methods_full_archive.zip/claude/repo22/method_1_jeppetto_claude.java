




















































import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.regex.Pattern;

public class method_1_jeppetto_claude {

    public static class Address {
        public String getCity() {
            return "Springfield";
        }

        public List<String> getLines() {
            return Arrays.asList("742 Evergreen Terrace");
        }
    }

    public static class Customer {
        public String getName() {
            return "Homer";
        }

        public Address getAddress() {
            return new Address();
        }

        public List<Address> getPastAddresses() {
            return new ArrayList<Address>();
        }

        public Map<String, Address> getAddressesByLabel() {
            return new HashMap<String, Address>();
        }
    }

    public static class EnhancedCustomerContainer implements DBObject {
        private final Map<String, Object> data = new java.util.LinkedHashMap<String, Object>();

        public static Class __getPreEnhancedClass() {
            return Customer.class;
        }

        public Object get(final String key) {
            return data.get(key);
        }

        public Object put(final String key, final Object value) {
            return data.put(key, value);
        }

        public Map<String, Object> toMap() {
            return data;
        }

        public boolean containsField(final String key) {
            return data.containsKey(key);
        }
    }

    public static void main(final String[] args) throws Exception {
        title("METHOD 1  |  MongoDBCallback.deriveClass1(String path, String lastPathPart, boolean array)");

        section("1. root level field - path equals lastPathPart, containerClass is rootClass");
        final MongoDBCallback callback = new MongoDBCallback(new DBCollection("customers"), Customer.class);
        show(callback, "name", "name", false);
        show(callback, "address", "address", false);

        section("2. nested field - containerClass looked up from classCache after visiting the parent");
        show(callback, "address.city", "city", false);

        section("3. no getter for the requested field - returns Basic(DBObject/DBList) and logs a warning");
        show(callback, "unknownField", "unknownField", false);
        System.out.println("      an internal field, name starts with __, no warning logged:");
        show(callback, "__internal", "__internal", false);
        System.out.println("      a field in EXPLAIN_PATHS_TO_IGNORE, no warning logged either:");
        show(callback, "indexBounds", "indexBounds", false);

        section("4. no container class at all - part of the document with no matching model field");
        show(callback, "address.city.unmapped", "unmapped", false);

        section("5. a Class returned type - the getter returns a plain type, enhanced through EnhancerHelper");
        show(callback, "address", "address", false);
        System.out.println("      (already covered by scenario 1; repeated here to point out the branch:");
        System.out.println("       Class.class.isAssignableFrom(returnType.getClass()) is true for getAddress())");

        section("6. a parameterized Map return type - classCache stores the raw type, value type may be enhanced");
        show(callback, "addressesByLabel", "addressesByLabel", false);

        section("7. a parameterized List/Iterable return type - element type may be enhanced");
        show(callback, "pastAddresses", "pastAddresses", false);
        show(callback, "pastAddresses.0", "pastAddresses", true);

        section("8. a container class whose Class is actually a DBObject - __getPreEnhancedClass() branch");
        final MongoDBCallback enhancedCallback = new MongoDBCallback(new DBCollection("customers"), Customer.class);
        seedCache(enhancedCallback, "Customer.container", EnhancedCustomerContainer.class);
        show(enhancedCallback, "container.name", "name", false);
        System.out.println("      containerClass was swapped from the enhanced DBObject class");
        System.out.println("      (EnhancedCustomerContainer) back to Customer via reflection on");
        System.out.println("      __getPreEnhancedClass(), and Customer.getName() was then found and used -");
        System.out.println("      the whole __getPreEnhancedClass() branch genuinely fired.");

        section("9. branch coverage summary");
        System.out.println("      path.equals(lastPathPart)                         -> scenario 1");
        System.out.println("      containerClass from classCache                    -> scenario 2");
        System.out.println("      containerClass is a DBObject, __getPreEnhancedClass() -> scenario 8");
        System.out.println("      no getter found, not ignored, warning logged      -> scenario 3");
        System.out.println("      no getter found, in EXPLAIN_PATHS_TO_IGNORE or __ prefixed, no warning -> scenario 3");
        System.out.println("      containerClass == null                           -> scenario 4");
        System.out.println("      Class.class.isAssignableFrom(returnType)          -> scenarios 1, 5");
        System.out.println("      ParameterizedType, Map.class.isAssignableFrom(rawType)   -> scenario 6");
        System.out.println("      ParameterizedType, Iterable.class.isAssignableFrom(rawType) -> scenario 7");

        title("END OF METHOD 1 SCENARIOS");
    }

    static void show(final MongoDBCallback callback, final String path, final String lastPathPart, final boolean array)
            throws Exception {
        final Class result = invokeDeriveClass1(callback, path, lastPathPart, array);
        System.out.println("      deriveClass1(\"" + path + "\", \"" + lastPathPart + "\", " + array + ") -> "
                + (result == null ? "null" : result.getName()));
    }

    static Class invokeDeriveClass1(final MongoDBCallback callback, final String path, final String lastPathPart,
            final boolean array) throws Exception {
        final java.lang.reflect.Method m = MongoDBCallback.class.getDeclaredMethod("deriveClass1", String.class,
                String.class, boolean.class);
        m.setAccessible(true);
        return (Class) m.invoke(callback, path, lastPathPart, array);
    }

    static void seedCache(final MongoDBCallback callback, final String cacheKey, final Class value) throws Exception {
        final java.lang.reflect.Field f = MongoDBCallback.class.getDeclaredField("classCache");
        f.setAccessible(true);
        @SuppressWarnings("unchecked")
        final Map<String, Class> cache = (Map<String, Class>) f.get(null);
        cache.put(cacheKey, value);
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}











final class EnhancerHelper {

    private static final Map<Class, Enhancer> dirtyableDBObjectEnhancers = new HashMap<Class, Enhancer>();

    @SuppressWarnings({ "unchecked" })
    public static <T> Enhancer<T> getDirtyableDBObjectEnhancer(Class<T> baseClass) {
        if (dirtyableDBObjectEnhancers.containsKey(baseClass)) {
            return (Enhancer<T>) dirtyableDBObjectEnhancers.get(baseClass);
        }

        synchronized (dirtyableDBObjectEnhancers) {
            Enhancer<T> enhancer;

            if (dirtyableDBObjectEnhancers.get(baseClass) != null) {
                enhancer = (Enhancer<T>) dirtyableDBObjectEnhancers.get(baseClass);
            } else if (DirtyableDBObject.class.isAssignableFrom(baseClass)) {
                enhancer = new NoOpEnhancer<T>(baseClass);

                dirtyableDBObjectEnhancers.put(baseClass, enhancer);
            } else {
                enhancer = new Enhancer<T>(baseClass) {
                    public boolean needsEnhancement(Object object) {
                        return object != null && !(object instanceof DirtyableDBObject);
                    }

                    protected Class<? extends T> enhanceClass(Class<T> baseClass) {
                        return baseClass;
                    }
                };

                dirtyableDBObjectEnhancers.put(baseClass, enhancer);
            }

            return enhancer;
        }
    }

    private EnhancerHelper() {
    }
}











class MongoDBCallback extends DefaultDBCallback {

    
    
    

    private static final Map<String, Class> classCache = new HashMap<String, Class>();
    private Class rootClass;

    private static Logger logger = LoggerFactory.getLogger(MongoDBCallback.class);

    
    
    private static final List<String> EXPLAIN_PATHS_TO_IGNORE = Arrays.asList("allPlans",
                                                                              "indexBounds",
                                                                              "shards",
                                                                              "oldPlan");


    
    
    

    public MongoDBCallback(DBCollection dbCollection, Class rootClass) {
        super(dbCollection);

        if (dbCollection != null && !dbCollection.getName().equals("$cmd")) {
            this.rootClass = rootClass;
        }
    }


    
    
    

    @Override
    public BSONObject create(boolean array, List<String> pathParts) {
        if (rootClass == null) {
            return array ? new BasicDBList() : new BasicDBObject();
        }

        if (pathParts == null) {
            try {
                return (DBObject) rootClass.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        String path = buildPath(pathParts);
        Class returnClass;

        if ((returnClass = getClassFromCache(path)) == null) {
            returnClass = deriveClass(path, pathParts.get(pathParts.size() - 1), array);
        }

        

        if (DBObject.class.isAssignableFrom(returnClass)) {
            try {
                return (DBObject) returnClass.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else if (Map.class.isAssignableFrom(returnClass)) {
            
            
            
            
            if (Modifier.isAbstract(returnClass.getModifiers()) || Modifier.isInterface(returnClass.getModifiers())) {
                return new SimpleDirtyableMap(new java.util.LinkedHashMap());
            } else {
                try {
                    return new SimpleDirtyableMap((Map) returnClass.newInstance());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        } else if (List.class.isAssignableFrom(returnClass)) {
            
            if (Modifier.isAbstract(returnClass.getModifiers()) || Modifier.isInterface(returnClass.getModifiers())) {
                return new SimpleDirtyableList(new java.util.ArrayList());
            } else {
                try {
                    return new SimpleDirtyableList((List) returnClass.newInstance());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        } else if (Set.class.isAssignableFrom(returnClass)) {
            
            
            
            Set resultSet;

            if (Modifier.isAbstract(returnClass.getModifiers()) || Modifier.isInterface(returnClass.getModifiers())) {
                resultSet = new java.util.LinkedHashSet();
            } else {
                try {
                    resultSet = (Set) returnClass.newInstance();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            return new SimpleDirtyableSet(resultSet);
        } else {
            return new BasicDBObject();
        }
    }


    
    
    

    private String buildPath(List<String> path) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < path.size(); i++) {
            if (i > 0) {
                sb.append('.');
            }

            sb.append(path.get(i));
        }

        return sb.toString();
    }


    private Class getClassFromCache(String path) {
        Class clazz = classCache.get(rootClass.getSimpleName() + "." + path);

        if (clazz != null) {
            return clazz;
        }

        int lastDotIndex = path.lastIndexOf('.');

        if (lastDotIndex > 0) {
            return classCache.get(rootClass.getSimpleName() + "." + path.substring(0, lastDotIndex + 1));
        }

        return null;
    }


    private Class deriveClass(String path, String lastPathPart, boolean array) {
        synchronized (classCache) {
            
            Class cachedClass = getClassFromCache(path);

            if (cachedClass != null) {
                return cachedClass;
            }

            return deriveClass1(path, lastPathPart, array);
        }
    }


    










        
private Class deriveClass1(String path, String lastPathPart, boolean array) {
        Class containerClass;

        if (path.equals(lastPathPart)) {
            containerClass = rootClass;
        } else {
            containerClass = classCache.get(rootClass.getSimpleName() + "." + path.substring(0, path.lastIndexOf('.')));
        }

        if (containerClass != null && DBObject.class.isAssignableFrom(containerClass)) {
            try {
                Method m = containerClass.getMethod("__getPreEnhancedClass");

                containerClass = (Class) m.invoke(null);
            } catch (Exception e) {
                logger.warn("DBObject without __getPreEnhancedClass() method.  Was the container class enhanced?");
            }
        }

        
        
        if (containerClass == null) {
            return array ? BasicDBList.class : BasicDBObject.class;
        }

        Method getter;

        try {
            
            getter = containerClass.getMethod("get" + Character.toUpperCase(lastPathPart.charAt(0)) + lastPathPart.substring(1));
        } catch (NoSuchMethodException e) {
            if (!EXPLAIN_PATHS_TO_IGNORE.contains(lastPathPart) && !lastPathPart.startsWith("__")) {
                logger.warn("No getter for: {} ({})", lastPathPart, e.getMessage());
            }

            return array ? BasicDBList.class : BasicDBObject.class;
        }

        Type returnType = getter.getGenericReturnType();
        String qualifiedPath = rootClass.getSimpleName() + "." + path;

        if (Class.class.isAssignableFrom(returnType.getClass())) {
            
            Class enhancedClass = EnhancerHelper.getDirtyableDBObjectEnhancer((Class) returnType).getEnhancedClass();

            classCache.put(qualifiedPath, enhancedClass);

            return enhancedClass;
        } else if (ParameterizedType.class.isAssignableFrom(returnType.getClass())) {
            ParameterizedType parameterizedType = (ParameterizedType) returnType;
            Class rawType = (Class) parameterizedType.getRawType();
            Class rawClass;
            Class enhancedClass;

            if (Map.class.isAssignableFrom(rawType)) {
                rawClass = (Class) parameterizedType.getActualTypeArguments()[1];
            } else if (Iterable.class.isAssignableFrom(rawType)) {
                rawClass = (Class) parameterizedType.getActualTypeArguments()[0];
            } else {
                throw new RuntimeException("unknown type: " + rawType);
            }

            classCache.put(qualifiedPath, rawType);

            if (!DBObjectUtil.needsNoConversion(rawClass)) {
                
                enhancedClass = EnhancerHelper.getDirtyableDBObjectEnhancer(rawClass).getEnhancedClass();

                classCache.put(qualifiedPath + ".", enhancedClass);
            }

            return rawType;
        } else {
            throw new RuntimeException("Don't know how to handle: " + qualifiedPath);
        }
    }
    
}














interface BSONObject {

    Object get(String key);

    Object put(String key, Object value);

    java.util.Map<String, Object> toMap();

    boolean containsField(String key);
}


interface DBObject extends BSONObject {
}


class BasicDBObject extends java.util.LinkedHashMap<String, Object> implements BSONObject {

    public Object get(final String key) {
        return super.get(key);
    }

    public Object put(final String key, final Object value) {
        return super.put(key, value);
    }

    public java.util.Map<String, Object> toMap() {
        return new java.util.LinkedHashMap<String, Object>(this);
    }

    public boolean containsField(final String key) {
        return containsKey(key);
    }
}


class BasicDBList extends java.util.ArrayList<Object> implements BSONObject {

    public Object get(final String key) {
        try {
            return get(Integer.parseInt(key));
        } catch (final NumberFormatException e) {
            return null;
        }
    }

    public Object put(final String key, final Object value) {
        final int index = Integer.parseInt(key);
        while (size() <= index) {
            add(null);
        }
        return set(index, value);
    }

    public java.util.Map<String, Object> toMap() {
        final java.util.Map<String, Object> map = new java.util.LinkedHashMap<String, Object>();
        for (int i = 0; i < size(); i++) {
            map.put(String.valueOf(i), get(i));
        }
        return map;
    }

    public boolean containsField(final String key) {
        try {
            final int index = Integer.parseInt(key);
            return index >= 0 && index < size();
        } catch (final NumberFormatException e) {
            return false;
        }
    }
}


class DBCollection {

    private final String name;

    DBCollection(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}







class DefaultDBCallback {

    protected final DBCollection collection;

    public DefaultDBCallback(final DBCollection collection) {
        this.collection = collection;
    }

    
    public BSONObject create(final boolean array, final java.util.List<String> pathParts) {
        return array ? new BasicDBList() : new BasicDBObject();
    }
}


final class BSON {

    public static void addDecodingHook(final Class<?> clazz, final Object hook) {
        
    }

    private BSON() {
    }
}







class ObjectId {
}

class DBRefBase {
}






interface Logger {
    boolean isDebugEnabled();
    void debug(String msg);
    void warn(String msg);
    void warn(String format, Object arg1, Object arg2);
    void error(String msg, Throwable t);
}

final class LoggerFactory {
    private LoggerFactory() {
    }

    public static Logger getLogger(final Class<?> clazz) {
        final String name = clazz.getSimpleName();
        return new Logger() {
            public boolean isDebugEnabled() {
                return true;
            }

            public void debug(final String msg) {
                System.out.println("        [DEBUG] " + name + " - " + msg);
            }

            public void warn(final String msg) {
                System.out.println("        [WARN ] " + name + " - " + msg);
            }

            public void warn(final String format, final Object arg1, final Object arg2) {
                
                String msg = format;
                int i = msg.indexOf("{}");
                if (i >= 0) {
                    msg = msg.substring(0, i) + arg1 + msg.substring(i + 2);
                }
                i = msg.indexOf("{}");
                if (i >= 0) {
                    msg = msg.substring(0, i) + arg2 + msg.substring(i + 2);
                }
                System.out.println("        [WARN ] " + name + " - " + msg);
            }

            public void error(final String msg, final Throwable t) {
                System.out.println("        [ERROR] " + name + " - " + msg);
            }
        };
    }
}










class SimpleDirtyableMap extends java.util.AbstractMap<Object, Object> implements BSONObject {

    private final Map delegate;

    SimpleDirtyableMap(final Map delegate) {
        this.delegate = delegate;
    }

    @SuppressWarnings("unchecked")
    public java.util.Set<java.util.Map.Entry<Object, Object>> entrySet() {
        return delegate.entrySet();
    }

    public Object get(final String key) {
        return delegate.get(key);
    }

    @SuppressWarnings("unchecked")
    public Object put(final String key, final Object value) {
        return delegate.put(key, value);
    }

    public java.util.Map<String, Object> toMap() {
        return delegate;
    }

    public boolean containsField(final String key) {
        return delegate.containsKey(key);
    }
}

class SimpleDirtyableList extends java.util.AbstractList<Object> implements BSONObject {

    private final List delegate;

    SimpleDirtyableList(final List delegate) {
        this.delegate = delegate;
    }

    @SuppressWarnings("unchecked")
    public Object get(final int index) {
        return delegate.get(index);
    }

    public int size() {
        return delegate.size();
    }

    public Object get(final String key) {
        return get(Integer.parseInt(key));
    }

    @SuppressWarnings("unchecked")
    public Object put(final String key, final Object value) {
        final int index = Integer.parseInt(key);
        while (delegate.size() <= index) {
            delegate.add(null);
        }
        return delegate.set(index, value);
    }

    public java.util.Map<String, Object> toMap() {
        final java.util.Map<String, Object> map = new java.util.LinkedHashMap<String, Object>();
        for (int i = 0; i < delegate.size(); i++) {
            map.put(String.valueOf(i), delegate.get(i));
        }
        return map;
    }

    public boolean containsField(final String key) {
        try {
            final int index = Integer.parseInt(key);
            return index >= 0 && index < delegate.size();
        } catch (final NumberFormatException e) {
            return false;
        }
    }
}

class SimpleDirtyableSet extends java.util.AbstractSet<Object> implements BSONObject {

    private final Set delegate;

    SimpleDirtyableSet(final Set delegate) {
        this.delegate = delegate;
    }

    @SuppressWarnings("unchecked")
    public java.util.Iterator<Object> iterator() {
        return delegate.iterator();
    }

    public int size() {
        return delegate.size();
    }

    public Object get(final String key) {
        return null;
    }

    public Object put(final String key, final Object value) {
        delegate.add(value);
        return value;
    }

    public java.util.Map<String, Object> toMap() {
        final java.util.Map<String, Object> map = new java.util.LinkedHashMap<String, Object>();
        int i = 0;
        for (final Object o : delegate) {
            map.put(String.valueOf(i++), o);
        }
        return map;
    }

    public boolean containsField(final String key) {
        return false;
    }
}





abstract class Enhancer<T> {

    
    
    

    private final Class<T> baseClass;
    private Class<? extends T> enhancedClass;

    private static final Logger logger = LoggerFactory.getLogger(Enhancer.class);


    
    
    

    protected Enhancer(Class<T> baseClass) {
        validateClassIsEnhanceable(baseClass);

        this.baseClass = baseClass;
    }


    
    
    

    public abstract boolean needsEnhancement(Object object);


    
    
    

    protected abstract Class<? extends T> enhanceClass(Class<T> baseClass);


    
    
    

    public void validateClassIsEnhanceable(Class<T> baseClass) {
        if (baseClass.isInterface()) {
            throw new IllegalArgumentException("Cannot enhance interface: " + baseClass.getSimpleName());
        }
    }


    public final Class<T> getBaseClass() {
        return baseClass;
    }


    public Class<? extends T> getEnhancedClass() {
        if (enhancedClass == null) {
            synchronized (baseClass) {
                if (enhancedClass == null) {
                    enhancedClass = enhanceClass(baseClass);
                }
            }
        }

        return enhancedClass;
    }


    




    public T newInstance() {
        try {
            return getEnhancedClass().newInstance();
        } catch (Exception e) {
            logger.error("Could not instantiate enhanced object.", e);

            throw ExceptionUtil.propagate(e);
        }
    }


    






    public T enhance(T t) {
        if (!needsEnhancement(t)) {
            return t;
        }

        try {
            return getEnhancedClass().getConstructor(baseClass).newInstance(t);
        } catch (Exception e) {
            throw new RuntimeException(String.format("Could not enhance object %s (%s)", t, t.getClass()), e);
        }
    }
}




class NoOpEnhancer<T> extends Enhancer<T> {

    
    
    

    public NoOpEnhancer(Class<T> baseClass) {
        super(baseClass);
    }


    
    
    

    @Override
    public boolean needsEnhancement(Object object) {
        return false;
    }


    @Override
    protected Class<? extends T> enhanceClass(Class<T> baseClass) {
        return null;
    }


    
    
    

    @Override
    public Class<? extends T> getEnhancedClass() {
        return getBaseClass();
    }


    @Override
    public T newInstance() {
        try {
            return getBaseClass().newInstance();
        } catch (Exception e) {
            throw ExceptionUtil.propagate(e);
        }
    }


    @Override
    public T enhance(T obj) {
        return obj;
    }
}




class ExceptionUtil {

    
    
    

    public static RuntimeException propagate(Throwable t) {
        if (t instanceof RuntimeException) {
            throw (RuntimeException) t;
        } else {
            throw new RuntimeException(t);
        }
    }


    public static <T extends Throwable> void propagateIfInstanceOf(Throwable t, Class<T> cls)
            throws T {
        if (cls.isInstance(t)) {
            throw cls.cast(t);
        }
    }


    public static void propagateIfPossible(Throwable t) {
        propagateIfInstanceOf(t, RuntimeException.class);
    }
}




class DBObjectUtil {

    
    
    

    private static final Set<Class<?>> NO_CONVERSION_CLASSES = new HashSet<Class<?>>();


    
    
    

    static {
        
        Collections.addAll(NO_CONVERSION_CLASSES,
                           Date.class,
                           boolean.class,
                           char.class,
                           byte.class,
                           short.class,
                           int.class,
                           long.class,
                           float.class,
                           double.class,
                           Number.class,
                           BigDecimal.class,
                           BigInteger.class,
                           String.class,
                           Boolean.class,
                           Character.class,
                           Byte.class,
                           Short.class,
                           Integer.class,
                           Long.class,
                           Float.class,
                           Double.class,
                           Pattern.class,
                           byte[].class,
                           DBRefBase.class,
                           ObjectId.class);
    }


    








    public static boolean objectIsMutable(Object object) {
        if (object == null) {
            return false;
        }

        Class<?> clazz = object.getClass();

        return Collection.class.isAssignableFrom(clazz);
    }


    public static boolean needsNoConversion(Class clazz) {
        return NO_CONVERSION_CLASSES.contains(clazz);
    }
    
    
}




interface DirtyableDBObject extends DBObject {

    

    


    boolean isDirty();


    


    void markPersisted(DBCollection dbCollection);


    


    boolean isPersisted(DBCollection dbCollection);

    
    


    Iterator<String> getDirtyKeys();


    


    Object getDelegate();






}
