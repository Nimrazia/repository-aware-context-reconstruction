












































import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_2_jeppetto_claude {

    public interface Nameable {
        String getName();

        void setName(String name);
    }

    public static class Widget implements Nameable {
        private String name = "unnamed";
        private int quantity;
        private final String serial = "SN-0001";

        public String getName() {
            return name;
        }

        public void setName(final String name) {
            this.name = name;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(final int quantity) {
            this.quantity = quantity;
        }

        public String getSerial() {
            return serial;
        }

        public boolean isDiscontinued() {
            return false;
        }

        public void setDiscontinued(final boolean discontinued) {
        }
    }

    public abstract static class AbstractShape {
        public abstract double getArea();

        public abstract void setArea(double area);
    }

    static final class DirtyTrackingEnhancer<T> extends VelocityEnhancer<T> {

        static final String TEMPLATE_LOCATION = "demo/dirtyTracking.template";

        static {
            VelocityEngine.registerTemplate(TEMPLATE_LOCATION, new Template.Renderer() {
                public void render(final VelocityContext context, final Writer writer) throws Exception {
                    final TemplateHelper helper = (TemplateHelper) context.get("_");
                    final CtClass base = (CtClass) context.get("base");
                    final CtMethod[] getters = (CtMethod[]) context.get("getters");
                    final CtMethod[] abstractMethods = (CtMethod[]) context.get("abstractMethods");

                    helper.cls(base.getSimpleName()).ext(base);

                    helper.field("private java.util.Set dirtyFields = new java.util.HashSet();");

                    helper.ctor("public " + helper.clsName() + "() { super(); }");

                    for (final CtMethod getter : getters) {
                        final String field = helper.fieldFor(getter.getName());
                        final String returnType = getter.getReturnTypeName();

                        helper.method("public " + returnType + " " + getter.getName() + "() { "
                                + "dirtyFields.add(\"" + field + "\"); return super." + getter.getName() + "(); }");
                    }

                    
                    
                    
                    
                    
                    
                    
                    final java.util.Set<String> handledAbstract = new java.util.HashSet<String>();
                    for (final CtMethod abstractMethod : abstractMethods) {
                        if (!handledAbstract.add(abstractMethod.getName())) {
                            continue;
                        }
                        final String returnType = abstractMethod.getReturnTypeName();
                        final String body = "void".equals(returnType) ? "" : "return " + defaultValueFor(returnType) + ";";
                        final CtClass[] paramTypes = abstractMethod.getParameterTypes();
                        final StringBuilder params = new StringBuilder();
                        for (int i = 0; i < paramTypes.length; i++) {
                            params.append(i > 0 ? ", " : "").append(paramTypes[i].getName()).append(" p").append(i);
                        }
                        helper.method("public " + returnType + " " + abstractMethod.getName() + "(" + params + ") { " + body + " }");
                    }

                    writer.write(helper.toString());
                }

                private String defaultValueFor(final String returnType) {
                    if ("double".equals(returnType) || "float".equals(returnType)) {
                        return "0";
                    }
                    if ("boolean".equals(returnType)) {
                        return "false";
                    }
                    if ("int".equals(returnType) || "long".equals(returnType) || "short".equals(returnType)
                            || "byte".equals(returnType) || "char".equals(returnType)) {
                        return "0";
                    }
                    return "null";
                }
            });
        }

        DirtyTrackingEnhancer(final Class<T> baseClass) {
            super(baseClass);
        }

        public boolean needsEnhancement(final Object object) {
            return true;
        }

        protected String getTemplateLocation() {
            return TEMPLATE_LOCATION;
        }

        protected boolean shouldEnhanceMethod(final CtMethod method) {
            return true;
        }
    }

    static final class GetOnlyEnhancer<T> extends VelocityEnhancer<T> {

        static final String TEMPLATE_LOCATION = "demo/getOnly.template";

        static {
            VelocityEngine.registerTemplate(TEMPLATE_LOCATION, new Template.Renderer() {
                public void render(final VelocityContext context, final Writer writer) throws Exception {
                    final TemplateHelper helper = (TemplateHelper) context.get("_");
                    final CtClass base = (CtClass) context.get("base");
                    final CtMethod[] getters = (CtMethod[]) context.get("getters");

                    helper.cls(base.getSimpleName()).ext(base);
                    helper.ctor("public " + helper.clsName() + "() { super(); }");

                    for (final CtMethod getter : getters) {
                        helper.method("public " + getter.getReturnTypeName() + " " + getter.getName()
                                + "() { return super." + getter.getName() + "(); }");
                    }

                    writer.write(helper.toString());
                }
            });
        }

        GetOnlyEnhancer(final Class<T> baseClass) {
            super(baseClass);
        }

        public boolean needsEnhancement(final Object object) {
            return true;
        }

        protected String getTemplateLocation() {
            return TEMPLATE_LOCATION;
        }

        protected boolean shouldEnhanceMethod(final CtMethod method) {
            return method.getName().startsWith("get");
        }
    }

    public static void main(final String[] args) throws Exception {
        title("METHOD 2  |  VelocityEnhancer.enhanceClass(Class<T> baseClass)");

        section("1. enhancing a concrete class with getter/setter pairs");
        final DirtyTrackingEnhancer<Widget> enhancer = new DirtyTrackingEnhancer<Widget>(Widget.class);
        final Class<? extends Widget> enhancedClass = enhancer.enhanceClass(Widget.class);
        System.out.println("      enhanced class name : " + enhancedClass.getName());
        System.out.println("      real superclass      : " + enhancedClass.getSuperclass().getName());
        final Widget instance = enhancedClass.newInstance();
        instance.setName("Sprocket");
        instance.setQuantity(5);
        System.out.println("      instance.getName()     : " + instance.getName());
        System.out.println("      instance.getQuantity()  : " + instance.getQuantity());
        System.out.println("      instance.getSerial()    : " + instance.getSerial()
                + "   (getSerial has no setter, so it was NOT enhanced by findGetters' setterExists check)");
        final java.lang.reflect.Field dirtyFields = enhancedClass.getDeclaredField("dirtyFields");
        dirtyFields.setAccessible(true);
        System.out.println("      dirty fields recorded so far : " + dirtyFields.get(instance));

        section("2. an abstract base class - findAbstractMethods() fires and the enhancer must implement it");
        final DirtyTrackingEnhancer<AbstractShape> shapeEnhancer = new DirtyTrackingEnhancer<AbstractShape>(AbstractShape.class);
        final Class<? extends AbstractShape> enhancedShape = shapeEnhancer.enhanceClass(AbstractShape.class);
        System.out.println("      enhanced abstract class is instantiable : " + !Modifier.isAbstract(enhancedShape.getModifiers()));
        final AbstractShape shapeInstance = enhancedShape.newInstance();
        System.out.println("      shapeInstance.getArea() default value    : " + shapeInstance.getArea());

        section("3. shouldEnhanceMethod(...) filters which getters get enhanced");
        final GetOnlyEnhancer<Widget> getOnly = new GetOnlyEnhancer<Widget>(Widget.class);
        final Class<? extends Widget> getOnlyClass = getOnly.enhanceClass(Widget.class);
        boolean hasIsDiscontinuedOverride = false;
        boolean hasGetNameOverride = false;
        for (final java.lang.reflect.Method m : getOnlyClass.getDeclaredMethods()) {
            if ("isDiscontinued".equals(m.getName())) {
                hasIsDiscontinuedOverride = true;
            }
            if ("getName".equals(m.getName())) {
                hasGetNameOverride = true;
            }
        }
        System.out.println("      getName() was enhanced (starts with \"get\")   : " + hasGetNameOverride);
        System.out.println("      isDiscontinued() was enhanced (starts with \"is\") : " + hasIsDiscontinuedOverride
                + "   (GetOnlyEnhancer.shouldEnhanceMethod rejects \"is*\" getters)");

        section("4. Enhancer.getEnhancedClass() caches the result - enhanceClass(...) runs only once per instance");
        final Class<? extends Widget> first = enhancer.getEnhancedClass();
        final Class<? extends Widget> second = enhancer.getEnhancedClass();
        System.out.println("      same Class object returned on the second call : " + (first == second));

        section("5. branch coverage summary");
        System.out.println("      normal path: pool.get succeeds, template renders, class compiles and loads -> scenario 1");
        System.out.println("      findAbstractMethods() returns a non-empty array -> scenario 2");
        System.out.println("      shouldEnhanceMethod(...) rejecting a getter -> scenario 3");
        System.out.println("      Enhancer.getEnhancedClass() caching (enhanceClass called at most once) -> scenario 4");
        System.out.println("      the finally block's original.detach() runs on every successful and failed call");

        title("END OF METHOD 2 SCENARIOS");
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}










abstract class VelocityEnhancer<T> extends Enhancer<T> {

    
    
    

    private static VelocityEngine engine;
    private static ClassPool pool;
    private static Logger logger = LoggerFactory.getLogger(VelocityEnhancer.class);


    
    
    

    static {
        engine = new VelocityEngine();
        try {
            engine.setProperty(RuntimeConstants.RESOURCE_LOADER, "class");
            engine.setProperty("class.resource.loader.description", "Classpath Loader");
            engine.setProperty("class.resource.loader.class", ClasspathResourceLoader.class.getName());
            engine.setProperty(RuntimeConstants.RUNTIME_LOG_LOGSYSTEM_CLASS, "org.iternine.jeppetto.enhance.SLF4JLogChute");
            engine.setProperty("velocimacro.library", "");
            engine.setProperty("runtime.log.invalid.references", "false");

            engine.init();
        } catch (Exception e) {
            logger.error("Unrecoverable error initializing Velocity.", e);
        }

        pool = ClassPool.getDefault();
        pool.insertClassPath(new ClassClassPath(VelocityEnhancer.class));
    }


    public VelocityEnhancer(Class<T> baseClass) {
        super(baseClass);
    }


    
    
    

    protected abstract String getTemplateLocation();


    protected abstract boolean shouldEnhanceMethod(CtMethod method);


    
    
    

    @Override
        
public final Class<? extends T> enhanceClass(Class<T> baseClass) {
        logger.info("Enhancing {}", baseClass);

        CtClass original = null;

        try {
            original = pool.get(baseClass.getName());

            TemplateHelper templateHelper = new TemplateHelper(pool);
            VelocityContext velocityContext = new VelocityContext();

            velocityContext.put("_", templateHelper);
            velocityContext.put("base", original);
            velocityContext.put("getters", findGetters(original));
            velocityContext.put("abstractMethods", findAbstractMethods(original));

            Map<String, Object> contextItems = getAdditionalContextItems();

            for (Map.Entry<String, Object> contextItem : contextItems.entrySet()) {
                velocityContext.put(contextItem.getKey(), contextItem.getValue());
            }

            StringWriter writer = new StringWriter();
            engine.getTemplate(getTemplateLocation()).merge(velocityContext, writer);

            logger.debug("Enhanced {} to form new class {} with source:\n{}",
                         baseClass.getSimpleName(), templateHelper.clsName(), writer);

            return ClassLoadingUtil.toClass(templateHelper.compile());
        } catch (Exception e) {
            logger.error("An error occurred while enhancing {}", baseClass);

            throw ExceptionUtil.propagate(e);
        } finally {
            if (original != null) {
                original.detach();
            }
        }
    }
    


    
    
    

    protected Map<String, Object> getAdditionalContextItems() {
        return new HashMap<String, Object>();
    }


    
    
    

    private Iterable<CtMethod> getMethodsFrom(CtClass superClass) {
        
        List<CtMethod> methods = new ArrayList<CtMethod>();

        methods.addAll(Arrays.asList(superClass.getDeclaredMethods()));
        methods.addAll(Arrays.asList(superClass.getMethods()));

        return methods;
    }


    private CtMethod[] findGetters(CtClass superClass)
            throws NotFoundException, ClassNotFoundException {
        List<CtMethod> getters = new ArrayList<CtMethod>();
        String objectFullName = Object.class.getName();
        Set<String> handledMethods = new HashSet<String>();

        for (CtMethod method : getMethodsFrom(superClass)) {
            String methodName = method.getName();
            boolean methodIsGetter = methodName.startsWith("get") || methodName.startsWith("is");

            
            if (!handledMethods.contains(methodName)
                && methodIsGetter
                && !method.getDeclaringClass().getName().equals(objectFullName)
                && !Modifier.isFinal(method.getModifiers())
                && !Modifier.isAbstract(method.getModifiers())
                && method.getParameterTypes().length == 0
                && setterExists(superClass, extractFieldName(methodName))
                && shouldEnhanceMethod(method)) {

                handledMethods.add(methodName);
                getters.add(method);
            }
        }

        return getters.toArray(new CtMethod[getters.size()]);
    }


    private CtMethod[] findAbstractMethods(CtClass superClass) {
        List<CtMethod> abstractMethods = new ArrayList<CtMethod>();

        for (CtMethod method : getMethodsFrom(superClass)) {
            if (Modifier.isAbstract(method.getModifiers())) {
                abstractMethods.add(method);
            }
        }

        return abstractMethods.toArray(new CtMethod[abstractMethods.size()]);
    }


    private String extractFieldName(String from) {
        final String result;

        if (from.startsWith("is")) {
            result = from.substring(2);
        } else {
            result = from.substring(3);
        }

        if (result.length() > 1) {
            return result.substring(0, 1).toLowerCase().concat(result.substring(1));
        } else {
            return result.toLowerCase();
        }
    }


    private boolean setterExists(CtClass cls, String fieldName) {
        final String name;

        if (fieldName.length() > 1) {
            name = "set".concat(fieldName.substring(0, 1).toUpperCase()).concat(fieldName.substring(1));
        } else {
            name = "set".concat(fieldName.toUpperCase());
        }

        for (CtMethod method : cls.getMethods()) {
            if (name.equals(method.getName())) {
                return true;
            }
        }

        return false;
    }
}





abstract class Enhancer<T> {

    
    
    

    private final Class<T> baseClass;
    private Class<? extends T> enhancedClass;

    private static final Logger logger = LoggerFactory.getLogger(Enhancer.class);


    
    
    

    protected Enhancer(Class<T> baseClass) {
        validateClassIsEnhanceable(baseClass);

        this.baseClass = baseClass;
    }


    
    
    

    public abstract boolean needsEnhancement(Object object);


    
    
    

    protected abstract Class<? extends T> enhanceClass(Class<T> baseClass);


    
    
    

    public void validateClassIsEnhanceable(Class<T> baseClass) {
        if (baseClass.isInterface()) {
            throw new IllegalArgumentException("Cannot enhance interface: " + baseClass.getSimpleName());
        }
    }


    public final Class<T> getBaseClass() {
        return baseClass;
    }


    public Class<? extends T> getEnhancedClass() {
        if (enhancedClass == null) {
            synchronized (baseClass) {
                if (enhancedClass == null) {
                    enhancedClass = enhanceClass(baseClass);
                }
            }
        }

        return enhancedClass;
    }


    




    public T newInstance() {
        try {
            return getEnhancedClass().newInstance();
        } catch (Exception e) {
            logger.error("Could not instantiate enhanced object.", e);

            throw ExceptionUtil.propagate(e);
        }
    }


    






    public T enhance(T t) {
        if (!needsEnhancement(t)) {
            return t;
        }

        try {
            return getEnhancedClass().getConstructor(baseClass).newInstance(t);
        } catch (Exception e) {
            throw new RuntimeException(String.format("Could not enhance object %s (%s)", t, t.getClass()), e);
        }
    }
}




class ExceptionUtil {

    
    
    

    public static RuntimeException propagate(Throwable t) {
        if (t instanceof RuntimeException) {
            throw (RuntimeException) t;
        } else {
            throw new RuntimeException(t);
        }
    }


    public static <T extends Throwable> void propagateIfInstanceOf(Throwable t, Class<T> cls)
            throws T {
        if (cls.isInstance(t)) {
            throw cls.cast(t);
        }
    }


    public static void propagateIfPossible(Throwable t) {
        propagateIfInstanceOf(t, RuntimeException.class);
    }
}





























class NotFoundException extends Exception {
    NotFoundException(final String message) {
        super(message);
    }
}


class CannotCompileException extends Exception {
    CannotCompileException(final String message) {
        super(message);
    }

    CannotCompileException(final Throwable cause) {
        super(cause);
    }
}


class CtMethod {

    final java.lang.reflect.Method method;

    CtMethod(final java.lang.reflect.Method method) {
        this.method = method;
    }

    public String getName() {
        return method.getName();
    }

    public int getModifiers() {
        return method.getModifiers();
    }

    public CtClass getDeclaringClass() {
        return new CtClass(method.getDeclaringClass());
    }

    public CtClass[] getParameterTypes() {
        final Class<?>[] params = method.getParameterTypes();
        final CtClass[] out = new CtClass[params.length];
        for (int i = 0; i < params.length; i++) {
            out[i] = new CtClass(params[i]);
        }
        return out;
    }

    public String getReturnTypeName() {
        return method.getReturnType().getName();
    }

    @Override
    public String toString() {
        return method.toString();
    }
}







class CtClass {

    
    private final Class<?> wrapped;

    
    private String name;
    private String superClassName = "Object";
    private final java.util.List<String> interfaceNames = new java.util.ArrayList<String>();
    private final java.util.List<String> fields = new java.util.ArrayList<String>();
    private final java.util.List<String> constructors = new java.util.ArrayList<String>();
    private final java.util.List<String> methods = new java.util.ArrayList<String>();

    CtClass(final Class<?> wrapped) {
        this.wrapped = wrapped;
        this.name = wrapped == null ? null : wrapped.getName();
    }

    CtClass(final String synthesizedName) {
        this.wrapped = null;
        this.name = synthesizedName;
    }

    public String getName() {
        return name;
    }

    public String getSimpleName() {
        final int i = name.lastIndexOf('.');
        return i < 0 ? name : name.substring(i + 1);
    }

    public CtMethod[] getDeclaredMethods() {
        final java.lang.reflect.Method[] ms = wrapped.getDeclaredMethods();
        final CtMethod[] out = new CtMethod[ms.length];
        for (int i = 0; i < ms.length; i++) {
            out[i] = new CtMethod(ms[i]);
        }
        return out;
    }

    public CtMethod[] getMethods() {
        final java.lang.reflect.Method[] ms = wrapped.getMethods();
        final CtMethod[] out = new CtMethod[ms.length];
        for (int i = 0; i < ms.length; i++) {
            out[i] = new CtMethod(ms[i]);
        }
        return out;
    }

    public void detach() {
        
        
    }

    

    void setSuperclass(final CtClass superClass) {
        this.superClassName = superClass.getName();
    }

    void addInterface(final CtClass iface) {
        this.interfaceNames.add(iface.getName());
    }

    void addField(final String fieldSource) {
        fields.add(fieldSource);
    }

    void addConstructor(final String ctorSource) {
        constructors.add(ctorSource);
    }

    void addMethod(final String methodSource) {
        methods.add(methodSource);
    }

    
    String toSource() {
        final StringBuilder sb = new StringBuilder();
        sb.append("public class ").append(getSimpleName());
        if (superClassName != null && !"Object".equals(superClassName)) {
            sb.append(" extends ").append(superClassName);
        }
        if (!interfaceNames.isEmpty()) {
            sb.append(" implements ").append(String.join(", ", interfaceNames));
        }
        sb.append(" {\n");
        for (final String f : fields) {
            sb.append("    ").append(f).append('\n');
        }
        for (final String c : constructors) {
            sb.append("    ").append(rewriteCtorName(c)).append('\n');
        }
        for (final String m : methods) {
            sb.append("    ").append(m).append('\n');
        }
        sb.append("}\n");
        return sb.toString();
    }

    private String rewriteCtorName(final String ctorSource) {
        
        
        return ctorSource;
    }
}







class ClassPool {

    private static final ClassPool DEFAULT = new ClassPool();

    public static ClassPool getDefault() {
        return DEFAULT;
    }

    public void insertClassPath(final Object classPath) {
        
    }

    public CtClass get(final String className) throws NotFoundException {
        try {
            return new CtClass(Class.forName(className));
        } catch (final ClassNotFoundException e) {
            throw new NotFoundException(className);
        }
    }

    public CtClass makeClass(final String className) {
        return new CtClass(className);
    }
}


class ClassClassPath {
    ClassClassPath(final Class<?> clazz) {
    }
}


class VelocityContext {

    private final java.util.Map<String, Object> values = new java.util.LinkedHashMap<String, Object>();

    public void put(final String key, final Object value) {
        values.put(key, value);
    }

    public Object get(final String key) {
        return values.get(key);
    }
}






class Template {

    interface Renderer {
        void render(VelocityContext context, java.io.Writer writer) throws Exception;
    }

    private final Renderer renderer;

    Template(final Renderer renderer) {
        this.renderer = renderer;
    }

    public void merge(final VelocityContext context, final java.io.Writer writer) {
        try {
            renderer.render(context, writer);
        } catch (final Exception e) {
            throw new RuntimeException(e);
        }
    }
}


class VelocityEngine {

    private static final java.util.Map<String, Template.Renderer> TEMPLATES =
            new java.util.HashMap<String, Template.Renderer>();

    public static void registerTemplate(final String location, final Template.Renderer renderer) {
        TEMPLATES.put(location, renderer);
    }

    public void setProperty(final String key, final Object value) {
        
        
    }

    public void init() {
    }

    public Template getTemplate(final String location) {
        final Template.Renderer renderer = TEMPLATES.get(location);
        if (renderer == null) {
            throw new RuntimeException("No template registered for location: " + location);
        }
        return new Template(renderer);
    }
}


final class RuntimeConstants {
    public static final String RESOURCE_LOADER = "resource.loader";
    public static final String RUNTIME_LOG_LOGSYSTEM_CLASS = "runtime.log.logsystem.class";

    private RuntimeConstants() {
    }
}


class ClasspathResourceLoader {
}











final class ClassLoadingUtil {

    private ClassLoadingUtil() {
    }

    @SuppressWarnings("unchecked")
    public static <T> Class<T> toClass(final CtClass ctClass) throws CannotCompileException {
        final String source = ctClass.toSource();
        final String className = ctClass.getSimpleName();

        try {
            final java.nio.file.Path dir = java.nio.file.Files.createTempDirectory("jeppetto-enhance");
            final java.nio.file.Path javaFile = dir.resolve(className + ".java");
            java.nio.file.Files.write(javaFile, source.getBytes("UTF-8"));

            final javax.tools.JavaCompiler compiler = javax.tools.ToolProvider.getSystemJavaCompiler();
            final javax.tools.DiagnosticCollector<javax.tools.JavaFileObject> diagnostics =
                    new javax.tools.DiagnosticCollector<javax.tools.JavaFileObject>();
            final javax.tools.StandardJavaFileManager fileManager =
                    compiler.getStandardFileManager(diagnostics, null, null);
            final javax.tools.JavaCompiler.CompilationTask task = compiler.getTask(null, fileManager, diagnostics,
                    java.util.Arrays.asList("-d", dir.toString(), "-cp", System.getProperty("java.class.path")),
                    null, fileManager.getJavaFileObjectsFromFiles(
                            java.util.Collections.singletonList(javaFile.toFile())));
            final boolean ok = task.call();
            fileManager.close();

            if (!ok) {
                final StringBuilder sb = new StringBuilder("Failed to compile generated class:\n" + source + "\n");
                for (final javax.tools.Diagnostic<?> d : diagnostics.getDiagnostics()) {
                    sb.append(d).append('\n');
                }
                throw new CannotCompileException(sb.toString());
            }

            final java.net.URLClassLoader loader = new java.net.URLClassLoader(
                    new java.net.URL[] { dir.toUri().toURL() }, ClassLoadingUtil.class.getClassLoader());

            return (Class<T>) loader.loadClass(className);
        } catch (final CannotCompileException e) {
            throw e;
        } catch (final Exception e) {
            throw new CannotCompileException(e);
        }
    }
}














final class TemplateHelper {

    private static java.util.concurrent.atomic.AtomicInteger COUNT =
            new java.util.concurrent.atomic.AtomicInteger(1);

    private String className;
    private CtClass thisClass;
    private final ClassPool pool;

    TemplateHelper(final ClassPool pool) {
        this.pool = pool;
    }

    public TemplateHelper cls(final String name) {
        final String newClassName = name + "$" + COUNT.getAndIncrement();

        thisClass = pool.makeClass(newClassName);
        className = thisClass.getSimpleName();

        return this;
    }

    public String clsName() {
        return className;
    }

    public TemplateHelper ext(final CtClass superClass) {
        thisClass.setSuperclass(superClass);

        return this;
    }

    public String field(final String code) {
        thisClass.addField(code);

        return code;
    }

    public String ctor(final String code) {
        thisClass.addConstructor(code);

        return code;
    }

    public String method(final String code) {
        thisClass.addMethod(code);

        return code;
    }

    public String asSetter(final String field) {
        return String.format("set%s%s", Character.toUpperCase(field.charAt(0)), field.substring(1));
    }

    public String fieldFor(final String getterName) {
        final String sub;

        if (getterName.startsWith("is")) {
            sub = getterName.substring(2);
        } else if (getterName.startsWith("get")) {
            sub = getterName.substring(3);
        } else {
            throw new RuntimeException("Unexpected getter: " + getterName);
        }

        return sub.substring(0, 1).toLowerCase().concat(sub.substring(1));
    }

    public CtClass compile() {
        return thisClass;
    }

    @Override
    public String toString() {
        return thisClass.toSource();
    }
}






interface Logger {
    boolean isDebugEnabled();
    void debug(String format, Object... args);
    void info(String format, Object... args);
    void error(String format, Object... args);
}

final class LoggerFactory {
    private LoggerFactory() {
    }

    public static Logger getLogger(final Class<?> clazz) {
        final String name = clazz.getSimpleName();
        return new Logger() {
            public boolean isDebugEnabled() {
                return true;
            }

            private String fmt(final String format, final Object... args) {
                String msg = format;
                for (final Object a : args) {
                    final int i = msg.indexOf("{}");
                    if (i < 0) {
                        break;
                    }
                    msg = msg.substring(0, i) + a + msg.substring(i + 2);
                }
                return msg;
            }

            public void debug(final String format, final Object... args) {
                System.out.println("        [DEBUG] " + name + " - " + fmt(format, args));
            }

            public void info(final String format, final Object... args) {
                System.out.println("        [INFO ] " + name + " - " + fmt(format, args));
            }

            public void error(final String format, final Object... args) {
                System.out.println("        [ERROR] " + name + " - " + fmt(format, args));
            }
        };
    }
}

