






















































import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class method_3_jeppetto_claude {

    public static void main(final String[] args) throws Exception {
        title("METHOD 3  |  DynamoDBQueryModelDAO.processIndexes(TableDescription, ProjectionExpressionBuilder, IndexData)");

        section("1. a table with a range key, one local secondary index, no global indexes, no projection object");
        run("orderId", "createdAt", localIndexes("byStatus", "status"), null, null);

        section("2. a table with a range key and one global secondary index that also has a range key");
        run("customerId", "orderId", null, globalIndexes(new String[][] { { "byRegion", "region", "signupDate" } }), null);

        section("3. a table with NO range key - the rangeKeyField != null branch is skipped");
        run("sessionId", null, null, null, null);

        section("4. a table with a range key but no local AND no global secondary indexes at all");
        run("userId", "timestamp", null, null, null);

        section("5. a projectionExpressionBuilder is supplied - projectsOverEntity is computed via isCoveredBy(...)");
        final ProjectionExpressionBuilder builder = new ProjectionExpressionBuilder();
        builder.setNonKeyAttributes(new HashSet<String>(java.util.Arrays.asList("email", "name")));
        run("userId", "timestamp", localIndexes("byEmail", "email"), null, builder);

        section("6. two global secondary indexes sharing the same hash key - the 'best index' selection logic");
        run("tenantId", "itemId", null, globalIndexes(new String[][] {
                { "byCategoryA", "category", null }, { "byCategoryB", "category", "createdAt" } }), null);

        section("7. branch coverage summary");
        System.out.println("      localSecondaryIndexes != null                 -> scenarios 1, 5, 6");
        System.out.println("      localSecondaryIndexes == null, rangeKeyField != null -> scenario 2, 4");
        System.out.println("      localSecondaryIndexes == null, rangeKeyField == null -> scenario 3");
        System.out.println("      globalSecondaryIndexes != null                -> scenarios 2, 6");
        System.out.println("      globalSecondaryIndexes == null                -> scenarios 1, 3, 4, 5");
        System.out.println("      projectionExpressionBuilder != null, isCoveredBy(...) -> scenario 5");
        System.out.println("      two global indexes on the same hash key, second projects over entity -> scenario 6");

        title("END OF METHOD 3 SCENARIOS");
    }

    static void run(final String hashKeyField, final String rangeKeyField,
            final List<LocalSecondaryIndexDescription> local, final List<GlobalSecondaryIndexDescription> global,
            final ProjectionExpressionBuilder projectionExpressionBuilder) throws Exception {
        final DynamoDBQueryModelDAO dao = new DynamoDBQueryModelDAO(hashKeyField, rangeKeyField);

        final TableDescription table = new TableDescription();
        table.setLocalSecondaryIndexes(local);
        table.setGlobalSecondaryIndexes(global);

        final List<String> baseKeyFields = rangeKeyField == null ? Collections.singletonList(hashKeyField)
                : java.util.Arrays.asList(hashKeyField, rangeKeyField);
        final DynamoDBQueryModelDAO.IndexData baseIndexData = newIndexData(null, baseKeyFields, true);

        final Map<String, Map<String, DynamoDBQueryModelDAO.IndexData>> indexes =
                invokeProcessIndexes(dao, table, projectionExpressionBuilder, baseIndexData);

        System.out.println("      hashKeyField=" + hashKeyField + ", rangeKeyField=" + rangeKeyField);
        System.out.println("      indexes.keySet()  : " + indexes.keySet());
        for (final Map.Entry<String, Map<String, DynamoDBQueryModelDAO.IndexData>> outer : indexes.entrySet()) {
            for (final Map.Entry<String, DynamoDBQueryModelDAO.IndexData> inner : outer.getValue().entrySet()) {
                final DynamoDBQueryModelDAO.IndexData d = inner.getValue();
                System.out.println("        [" + outer.getKey() + "][" + inner.getKey() + "] -> indexName="
                        + d.indexName + ", keyFields=" + d.keyFields + ", projectsOverEntity=" + d.projectsOverEntity);
            }
        }
    }

    static List<LocalSecondaryIndexDescription> localIndexes(final String indexName, final String rangeField) {
        final LocalSecondaryIndexDescription description = new LocalSecondaryIndexDescription();
        description.setIndexName(indexName);
        description.setKeySchema(java.util.Arrays.asList(
                keySchemaElement(rangeField, KeyType.RANGE)));
        description.setProjection(allProjection());
        final List<LocalSecondaryIndexDescription> list = new ArrayList<LocalSecondaryIndexDescription>();
        list.add(description);
        return list;
    }

    static List<GlobalSecondaryIndexDescription> globalIndexes(final String[][] spec) {
        final List<GlobalSecondaryIndexDescription> list = new ArrayList<GlobalSecondaryIndexDescription>();
        for (final String[] row : spec) {
            final GlobalSecondaryIndexDescription description = new GlobalSecondaryIndexDescription();
            description.setIndexName(row[0]);
            final List<KeySchemaElement> schema = new ArrayList<KeySchemaElement>();
            schema.add(keySchemaElement(row[1], KeyType.HASH));
            if (row.length > 2 && row[2] != null) {
                schema.add(keySchemaElement(row[2], KeyType.RANGE));
            }
            description.setKeySchema(schema);
            description.setProjection(allProjection());
            list.add(description);
        }
        return list;
    }

    static KeySchemaElement keySchemaElement(final String name, final KeyType type) {
        final KeySchemaElement e = new KeySchemaElement();
        e.setAttributeName(name);
        e.setKeyType(type.name());
        return e;
    }

    static Projection allProjection() {
        final Projection p = new Projection();
        p.setProjectionType(ProjectionType.ALL.name());
        return p;
    }

    






    @SuppressWarnings("unchecked")
    static DynamoDBQueryModelDAO.IndexData newIndexData(final String indexName, final List<String> keyFields,
            final boolean projectsOverEntity) throws Exception {
        final java.lang.reflect.Constructor<DynamoDBQueryModelDAO.IndexData> ctor =
                DynamoDBQueryModelDAO.IndexData.class.getDeclaredConstructor(String.class, List.class, boolean.class);
        ctor.setAccessible(true);
        return ctor.newInstance(indexName, keyFields, projectsOverEntity);
    }

    @SuppressWarnings("unchecked")
    static Map<String, Map<String, DynamoDBQueryModelDAO.IndexData>> invokeProcessIndexes(
            final DynamoDBQueryModelDAO dao, final TableDescription table,
            final ProjectionExpressionBuilder projectionExpressionBuilder,
            final DynamoDBQueryModelDAO.IndexData baseIndexData) throws Exception {
        final java.lang.reflect.Method m = DynamoDBQueryModelDAO.class.getDeclaredMethod("processIndexes",
                TableDescription.class, ProjectionExpressionBuilder.class, DynamoDBQueryModelDAO.IndexData.class);
        m.setAccessible(true);
        return (Map<String, Map<String, DynamoDBQueryModelDAO.IndexData>>) m.invoke(dao, table,
                projectionExpressionBuilder, baseIndexData);
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}







class TableDescription {
    private java.util.List<LocalSecondaryIndexDescription> localSecondaryIndexes;
    private java.util.List<GlobalSecondaryIndexDescription> globalSecondaryIndexes;

    public java.util.List<LocalSecondaryIndexDescription> getLocalSecondaryIndexes() {
        return localSecondaryIndexes;
    }

    public void setLocalSecondaryIndexes(final java.util.List<LocalSecondaryIndexDescription> v) {
        this.localSecondaryIndexes = v;
    }

    public java.util.List<GlobalSecondaryIndexDescription> getGlobalSecondaryIndexes() {
        return globalSecondaryIndexes;
    }

    public void setGlobalSecondaryIndexes(final java.util.List<GlobalSecondaryIndexDescription> v) {
        this.globalSecondaryIndexes = v;
    }
}

class LocalSecondaryIndexDescription {
    private String indexName;
    private java.util.List<KeySchemaElement> keySchema;
    private Projection projection;

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(final String v) {
        this.indexName = v;
    }

    public java.util.List<KeySchemaElement> getKeySchema() {
        return keySchema;
    }

    public void setKeySchema(final java.util.List<KeySchemaElement> v) {
        this.keySchema = v;
    }

    public Projection getProjection() {
        return projection;
    }

    public void setProjection(final Projection v) {
        this.projection = v;
    }
}

class GlobalSecondaryIndexDescription {
    private String indexName;
    private java.util.List<KeySchemaElement> keySchema;
    private Projection projection;

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(final String v) {
        this.indexName = v;
    }

    public java.util.List<KeySchemaElement> getKeySchema() {
        return keySchema;
    }

    public void setKeySchema(final java.util.List<KeySchemaElement> v) {
        this.keySchema = v;
    }

    public Projection getProjection() {
        return projection;
    }

    public void setProjection(final Projection v) {
        this.projection = v;
    }
}

class KeySchemaElement {
    private String attributeName;
    private String keyType;

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(final String v) {
        this.attributeName = v;
    }

    public String getKeyType() {
        return keyType;
    }

    public void setKeyType(final String v) {
        this.keyType = v;
    }
}

enum KeyType {
    HASH, RANGE
}

class Projection {
    private String projectionType;
    private java.util.List<String> nonKeyAttributes;

    public String getProjectionType() {
        return projectionType;
    }

    public void setProjectionType(final String v) {
        this.projectionType = v;
    }

    public java.util.List<String> getNonKeyAttributes() {
        return nonKeyAttributes;
    }

    public void setNonKeyAttributes(final java.util.List<String> v) {
        this.nonKeyAttributes = v;
    }
}

enum ProjectionType {
    ALL, KEYS_ONLY, INCLUDE
}






class Pair<T1, T2> {

    private T1 first;
    private T2 second;

    public Pair() {
    }

    public Pair(T1 first, T2 second) {
        this.first = first;
        this.second = second;
    }

    public T1 getFirst() {
        return first;
    }

    public void setFirst(T1 first) {
        this.first = first;
    }

    public T2 getSecond() {
        return second;
    }

    public void setSecond(T2 second) {
        this.second = second;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Pair pair = (Pair) o;

        return !(first != null ? !first.equals(pair.first) : pair.first != null)
               && !(second != null ? !second.equals(pair.second) : pair.second != null);
    }

    @Override
    public int hashCode() {
        int result = first != null ? first.hashCode() : 0;

        result = 31 * result + (second != null ? second.hashCode() : 0);

        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Pair{");

        sb.append("Pair");
        sb.append("{ first=").append(first);
        sb.append(", second=").append(second);
        sb.append(" }");

        return sb.toString();
    }
}










class ProjectionExpressionBuilder {

    private Set<String> nonKeyAttributes = new HashSet<String>();

    public void setNonKeyAttributes(final Set<String> nonKeyAttributes) {
        this.nonKeyAttributes = nonKeyAttributes;
    }

    public Boolean isCoveredBy(Projection projection) {
        switch (ProjectionType.valueOf(projection.getProjectionType())) {
        case ALL:
            return Boolean.TRUE;
        case KEYS_ONLY:
            return nonKeyAttributes.isEmpty();
        case INCLUDE:
            return projection.getNonKeyAttributes().containsAll(nonKeyAttributes);
        }

        return Boolean.FALSE;
    }
}








class DynamoDBQueryModelDAO {

    private final String hashKeyField;
    private final String rangeKeyField;

    DynamoDBQueryModelDAO(final String hashKeyField, final String rangeKeyField) {
        this.hashKeyField = hashKeyField;
        this.rangeKeyField = rangeKeyField;
    }

    private Pair<String, String> getKeyAttributeNames(List<KeySchemaElement> keySchema) {
        Pair<String, String> keyAttributes = new Pair<>();

        for (KeySchemaElement keySchemaElement : keySchema) {
            if (keySchemaElement.getKeyType().equals(KeyType.HASH.name())) {
                keyAttributes.setFirst(keySchemaElement.getAttributeName());
            } else {
                keyAttributes.setSecond(keySchemaElement.getAttributeName());
            }
        }

        return keyAttributes;
    }

    
    private Map<String, Map<String, IndexData>> processIndexes(TableDescription tableDescription,
                                                               ProjectionExpressionBuilder projectionExpressionBuilder,
                                                               IndexData baseIndexData) {
        
        Map<String, IndexData> localIndexes;
        List<LocalSecondaryIndexDescription> localSecondaryIndexes = tableDescription.getLocalSecondaryIndexes();
        if (localSecondaryIndexes != null) {
            localIndexes = new HashMap<>(localSecondaryIndexes.size() + 2);

            
            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);

            for (LocalSecondaryIndexDescription description : localSecondaryIndexes) {
                String indexField = getKeyAttributeNames(description.getKeySchema()).getSecond();
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>(baseIndexData.keyFields);
                keyFields.add(indexField);

                localIndexes.put(indexField, new IndexData(description.getIndexName(), keyFields, projectsOverEntity));
            }
        } else if (rangeKeyField != null) {
            localIndexes = new HashMap<>(2);

            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);
        } else {
            localIndexes = Collections.singletonMap(null, baseIndexData);
        }

        
        List<GlobalSecondaryIndexDescription> globalSecondaryIndexes = tableDescription.getGlobalSecondaryIndexes();
        if (globalSecondaryIndexes != null) {
            Map<String, Map<String, IndexData>> indexes = new HashMap<>(globalSecondaryIndexes.size() + 1);

            for (GlobalSecondaryIndexDescription description : globalSecondaryIndexes) {
                Pair<String, String> indexFields = getKeyAttributeNames(description.getKeySchema());
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>();
                keyFields.add(indexFields.getFirst());
                if (indexFields.getSecond() != null) {
                    keyFields.add(indexFields.getSecond());
                }
                keyFields.add(hashKeyField);
                if (rangeKeyField != null) {
                    keyFields.add(rangeKeyField);
                }

                IndexData indexData = new IndexData(description.getIndexName(), keyFields, projectsOverEntity);

                if (!indexes.containsKey(indexFields.getFirst())) {
                    indexes.put(indexFields.getFirst(), new HashMap<String, IndexData>());
                }

                indexes.get(indexFields.getFirst()).put(indexFields.getSecond(), indexData);

                
                
                IndexData noRangeKeyIndexData = indexes.get(indexFields.getFirst()).get(null);
                if (noRangeKeyIndexData == null || !noRangeKeyIndexData.projectsOverEntity) {
                    indexes.get(indexFields.getFirst()).put(null, indexData);
                }
            }

            indexes.put(hashKeyField, localIndexes);

            return indexes;
        } else {
            return Collections.singletonMap(hashKeyField, localIndexes);
        }
    }
    

    public static class IndexData {
        String indexName;
        List<String> keyFields;
        boolean projectsOverEntity;

        private IndexData(String indexName, List<String> keyFields, boolean projectsOverEntity) {
            this.indexName = indexName;
            this.keyFields = keyFields;
            this.projectsOverEntity = projectsOverEntity;
        }
    }
}
