






























import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
















class Element {
    final String tag;
    final Map<String, String> attributes = new LinkedHashMap<String, String>();
    final List<String> classNames = new ArrayList<String>();
    final List<Element> children = new ArrayList<Element>();
    Element parent;
    String innerHtml = "";

    Element(String tag) {
        this.tag = tag;
    }

    Element addClass(String... names) {
        for (String n : names) {
            classNames.add(n);
        }
        attributes.put("class", String.join(" ", classNames));
        return this;
    }

    Element attr(String name, String value) {
        attributes.put(name, value);
        return this;
    }

    Element html(String html) {
        this.innerHtml = html;
        return this;
    }

    Element appendChild(Element child) {
        child.parent = this;
        children.add(child);
        return this;
    }

    
    String html() {
        return innerHtml;
    }

    



    String attr(String name) {
        if (name.startsWith("abs:")) {
            String v = attributes.get(name.substring(4));
            if (v == null) {
                return "";
            }
            return v.startsWith("http") ? v : "https://www.sherdog.com" + v;
        }
        String v = attributes.get(name);
        return v == null ? "" : v;
    }

    
    Elements select(String cssQuery) {
        List<Element> matches = new ArrayList<Element>();
        List<Selector.Step> steps = Selector.parse(cssQuery);
        for (Element c : children) {
            Selector.collect(c, steps, matches);
        }
        return new Elements(matches);
    }
}







class Elements extends ArrayList<Element> {
    private static final long serialVersionUID = 1L;

    Elements() {
        super();
    }

    Elements(List<Element> initial) {
        super(initial);
    }

    
    Elements select(String cssQuery) {
        List<Element> matches = new ArrayList<Element>();
        for (Element e : this) {
            matches.addAll(e.select(cssQuery));
        }
        return new Elements(matches);
    }

    
    Element first() {
        return isEmpty() ? null : get(0);
    }

    
    String html() {
        return isEmpty() ? "" : get(0).html();
    }

    
    String attr(String name) {
        return isEmpty() ? "" : get(0).attr(name);
    }
}


class Document extends Element {
    Document() {
        super("#document");
    }
}







class Selector {

    static class Step {
        String tag;
        List<String> classNames = new ArrayList<String>();
        String id;
        String attrName;
        String attrValue;
        String pseudo;
    }

    static List<Step> parse(String query) {
        List<Step> steps = new ArrayList<Step>();
        String[] parts = query.trim().split("\\s+");
        for (String part : parts) {
            steps.add(parseCompound(part));
        }
        return steps;
    }

    private static Step parseCompound(String part) {
        Step step = new Step();
        int pseudoIdx = part.indexOf(':');
        if (pseudoIdx >= 0) {
            step.pseudo = part.substring(pseudoIdx + 1);
            part = part.substring(0, pseudoIdx);
        }
        int bracket = part.indexOf('[');
        if (bracket >= 0) {
            int close = part.indexOf(']', bracket);
            String expr = part.substring(bracket + 1, close);
            String[] kv = expr.split("=", 2);
            step.attrName = kv[0].trim();
            if (kv.length > 1) {
                step.attrValue = kv[1].trim().replaceAll("^\"|\"$", "");
            }
            part = part.substring(0, bracket);
        }
        String remaining = part;
        int firstSpecial = indexOfAny(remaining, '.', '#');
        if (firstSpecial != 0) {
            step.tag = firstSpecial < 0 ? remaining : remaining.substring(0, firstSpecial);
            remaining = firstSpecial < 0 ? "" : remaining.substring(firstSpecial);
        }
        while (!remaining.isEmpty()) {
            char marker = remaining.charAt(0);
            int next = indexOfAny(remaining.substring(1), '.', '#');
            String token = next < 0 ? remaining.substring(1) : remaining.substring(1, next + 1);
            if (marker == '.') {
                step.classNames.add(token);
            } else if (marker == '#') {
                step.id = token;
            }
            remaining = next < 0 ? "" : remaining.substring(next + 1);
        }
        if (step.tag != null && step.tag.isEmpty()) {
            step.tag = null;
        }
        return step;
    }

    private static int indexOfAny(String s, char a, char b) {
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == a || s.charAt(i) == b) {
                return i;
            }
        }
        return -1;
    }

    static boolean matches(Element e, Step step) {
        if (step.tag != null && !step.tag.equals(e.tag)) {
            return false;
        }
        for (String cls : step.classNames) {
            if (!e.classNames.contains(cls)) {
                return false;
            }
        }
        if (step.id != null && !step.id.equals(e.attr("id"))) {
            return false;
        }
        if (step.attrName != null) {
            if (!e.attributes.containsKey(step.attrName)) {
                return false;
            }
            if (step.attrValue != null && !step.attrValue.equals(e.attr(step.attrName))) {
                return false;
            }
        }
        if ("first-of-type".equals(step.pseudo)) {
            if (e.parent == null) {
                return false;
            }
            for (Element sibling : e.parent.children) {
                if (sibling == e) {
                    break;
                }
                if (sibling.tag.equals(e.tag)) {
                    return false;
                }
            }
        }
        return true;
    }

    static void collect(Element node, List<Step> steps, List<Element> out) {
        int last = steps.size() - 1;
        if (matches(node, steps.get(last)) && ancestorsMatch(node.parent, steps, last - 1)) {
            out.add(node);
        }
        for (Element c : node.children) {
            collect(c, steps, out);
        }
    }

    private static boolean ancestorsMatch(Element start, List<Step> steps, int idx) {
        if (idx < 0) {
            return true;
        }
        Element cur = start;
        while (cur != null) {
            if (matches(cur, steps.get(idx)) && ancestorsMatch(cur.parent, steps, idx - 1)) {
                return true;
            }
            cur = cur.parent;
        }
        return false;
    }
}






class Logger {
    private final String name;

    Logger(String name) {
        this.name = name;
    }

    void info(String format, Object... args) {
        StringBuilder sb = new StringBuilder();
        int argIdx = 0;
        int i = 0;
        while (i < format.length()) {
            if (i + 1 < format.length() && format.charAt(i) == '{' && format.charAt(i + 1) == '}'
                    && argIdx < args.length) {
                sb.append(String.valueOf(args[argIdx++]));
                i += 2;
            } else {
                sb.append(format.charAt(i));
                i++;
            }
        }
        System.out.println("[INFO] " + name + " - " + sb);
    }
}


class LoggerFactory {
    static Logger getLogger(Class<?> clazz) {
        return new Logger(clazz.getSimpleName());
    }
}









class SherdogBaseObject {
    private String name;
    private String sherdogUrl;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSherdogUrl() { return sherdogUrl; }
    public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }

    @Override
    public String toString() {
        return name;
    }
}


enum FightResult {
    WIN, LOSS, DRAW, NC, UPCOMING, NOT_HAPPENED
}


enum FightType {
    PRO, AMATEUR, UPCOMING, UNKNOWN;

    static FightType fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        String u = s.trim().toUpperCase();
        if (u.contains("AMATEUR")) {
            return AMATEUR;
        }
        if (u.contains("UPCOMING")) {
            return UPCOMING;
        }
        if (u.contains("PRO")) {
            return PRO;
        }
        return UNKNOWN;
    }
}


class Fight {
    private SherdogBaseObject event;
    private SherdogBaseObject fighter1;
    private SherdogBaseObject fighter2;
    private FightResult result;
    private String winMethod;
    private int winRound;
    private String winTime;
    private Date date;
    private FightType type;

    public SherdogBaseObject getEvent() { return event; }
    public void setEvent(SherdogBaseObject event) { this.event = event; }
    public SherdogBaseObject getFighter1() { return fighter1; }
    public void setFighter1(SherdogBaseObject fighter1) { this.fighter1 = fighter1; }
    public SherdogBaseObject getFighter2() { return fighter2; }
    public void setFighter2(SherdogBaseObject fighter2) { this.fighter2 = fighter2; }
    public FightResult getResult() { return result; }
    public void setResult(FightResult result) { this.result = result; }
    public String getWinMethod() { return winMethod; }
    public void setWinMethod(String winMethod) { this.winMethod = winMethod; }
    public int getWinRound() { return winRound; }
    public void setWinRound(int winRound) { this.winRound = winRound; }
    public String getWinTime() { return winTime; }
    public void setWinTime(String winTime) { this.winTime = winTime; }
    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
    public FightType getType() { return type; }
    public void setType(FightType type) { this.type = type; }

    @Override
    public String toString() {
        return (fighter1 == null ? "?" : fighter1.getName()) + " vs "
                + (fighter2 == null ? "?" : fighter2.getName())
                + " [" + result + ", " + winMethod + ", R" + winRound + ", " + winTime + "]";
    }
}



class Fighter extends SherdogBaseObject {
    private String nickname;
    private Date birthday;
    private String height;
    private String weight;
    private int wins;
    private int winsKo;
    private int winsSub;
    private int winsDec;
    private int winsOther;
    private int losses;
    private int lossesKo;
    private int lossesSub;
    private int lossesDec;
    private int lossesOther;
    private int draws;
    private int nc;
    private String picture;
    private List<Fight> fights = new ArrayList<Fight>();

    public String getNickname() { return nickname; }
    public void setNickname(String nickname) { this.nickname = nickname; }
    public Date getBirthday() { return birthday; }
    public void setBirthday(Date birthday) { this.birthday = birthday; }
    public String getHeight() { return height; }
    public void setHeight(String height) { this.height = height; }
    public String getWeight() { return weight; }
    public void setWeight(String weight) { this.weight = weight; }
    public int getWins() { return wins; }
    public void setWins(int wins) { this.wins = wins; }
    public int getWinsKo() { return winsKo; }
    public void setWinsKo(int winsKo) { this.winsKo = winsKo; }
    public int getWinsSub() { return winsSub; }
    public void setWinsSub(int winsSub) { this.winsSub = winsSub; }
    public int getWinsDec() { return winsDec; }
    public void setWinsDec(int winsDec) { this.winsDec = winsDec; }
    public int getWinsOther() { return winsOther; }
    public void setWinsOther(int winsOther) { this.winsOther = winsOther; }
    public int getLosses() { return losses; }
    public void setLosses(int losses) { this.losses = losses; }
    public int getLossesKo() { return lossesKo; }
    public void setLossesKo(int lossesKo) { this.lossesKo = lossesKo; }
    public int getLossesSub() { return lossesSub; }
    public void setLossesSub(int lossesSub) { this.lossesSub = lossesSub; }
    public int getLossesDec() { return lossesDec; }
    public void setLossesDec(int lossesDec) { this.lossesDec = lossesDec; }
    public int getLossesOther() { return lossesOther; }
    public void setLossesOther(int lossesOther) { this.lossesOther = lossesOther; }
    public int getDraws() { return draws; }
    public void setDraws(int draws) { this.draws = draws; }
    public int getNc() { return nc; }
    public void setNc(int nc) { this.nc = nc; }
    public String getPicture() { return picture; }
    public void setPicture(String picture) { this.picture = picture; }
    public List<Fight> getFights() { return fights; }
    public void setFights(List<Fight> fights) { this.fights = fights; }
}







class ParserUtils {

    
    static String getSherdogPageUrl(Document doc) {
        Element canonical = doc.select("link[rel=canonical]").first();
        return canonical != null ? canonical.attr("href") : doc.attr("data-url");
    }

    



    static FightResult getFightResult(Element fightRow) {
        if (fightRow == null) {
            return FightResult.NOT_HAPPENED;
        }
        String text = fightRow.select("span.final_result").html();
        if (text == null || text.isEmpty()) {
            return FightResult.NOT_HAPPENED;
        }
        text = text.trim().toLowerCase();
        if (text.contains("win")) {
            return FightResult.WIN;
        }
        if (text.contains("loss")) {
            return FightResult.LOSS;
        }
        if (text.contains("draw")) {
            return FightResult.DRAW;
        }
        if (text.contains("nc")) {
            return FightResult.NC;
        }
        return FightResult.NOT_HAPPENED;
    }
}





public class method_3_sherdog_parser_claude {

    private static final Logger logger = LoggerFactory.getLogger(method_3_sherdog_parser_claude.class);

    
    private final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");

    
    private static final int COLUMN_RESULT = 0;
    private static final int COLUMN_OPPONENT = 1;
    private static final int COLUMN_EVENT = 2;
    private static final int COLUMN_METHOD = 3;
    private static final int COLUMN_ROUND = 4;
    private static final int COLUMN_TIME = 5;

    
    private List<Fight> getFights(Elements trs, Fighter fighter) throws ArrayIndexOutOfBoundsException {
        List<Fight> fights = new ArrayList<>();

        logger.info("{} TRs to parse through", trs.size());


        SherdogBaseObject sFighter = new SherdogBaseObject();
        sFighter.setName(fighter.getName());
        sFighter.setSherdogUrl(fighter.getSherdogUrl());


        
        if (trs.size() > 0) {
            trs.remove(0);

            trs.forEach(tr -> {
                Fight fight = new Fight();
                fight.setFighter1(sFighter);

                Elements tds = tr.select("td");
                fight.setResult(getFightResult(tds.get(COLUMN_RESULT)));
                fight.setFighter2(getOpponent(tds.get(COLUMN_OPPONENT)));
                fight.setEvent(getEvent(tds.get(COLUMN_EVENT)));
                fight.setDate(getDate(tds.get(COLUMN_EVENT)));
                fight.setWinMethod(getWinMethod(tds.get(COLUMN_METHOD)));
                fight.setWinRound(getWinRound(tds.get(COLUMN_ROUND)));
                fight.setWinTime(getWinTime(tds.get(COLUMN_TIME)));
                fights.add(fight);
                logger.info("{}", fight);
            });
        }

        return fights;
    }
    

    




    private FightResult getFightResult(Element resultTd) {
        return ParserUtils.getFightResult(resultTd);
    }

    private SherdogBaseObject getOpponent(Element opponentTd) {
        SherdogBaseObject opponent = new SherdogBaseObject();
        Element link = opponentTd.select("a").first();
        if (link != null) {
            opponent.setName(link.html());
            opponent.setSherdogUrl(link.attr("href"));
        }
        return opponent;
    }

    private SherdogBaseObject getEvent(Element eventTd) {
        SherdogBaseObject event = new SherdogBaseObject();
        Element link = eventTd.select("a").first();
        if (link != null) {
            event.setName(link.html());
            event.setSherdogUrl(link.attr("href"));
        }
        return event;
    }

    private Date getDate(Element eventTd) {
        Element dateSpan = eventTd.select("span.sub_line").first();
        if (dateSpan != null) {
            try {
                return df.parse(dateSpan.html());
            } catch (ParseException e) {
                
            }
        }
        return null;
    }

    private String getWinMethod(Element methodTd) {
        return methodTd.html();
    }

    private int getWinRound(Element roundTd) {
        try {
            return Integer.parseInt(roundTd.html().trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String getWinTime(Element timeTd) {
        return timeTd.html();
    }

    




    public static void main(String[] args) throws Exception {
        method_3_sherdog_parser_claude parser = new method_3_sherdog_parser_claude();

        Fighter fighter = new Fighter();
        fighter.setName("John Doe");
        fighter.setSherdogUrl("https://www.sherdog.com/fighter/John-Doe-123456");

        Elements rows = SherdogFixtures.buildFightRows();
        System.out.println("=== Scenario 1: three bouts plus a header row ===");
        System.out.println("  rows handed to the method : " + rows.size() + " (1 header + 3 bouts)");

        List<Fight> fights = parser.getFights(rows, fighter);

        System.out.println("  rows left in the caller's list afterwards : " + rows.size());
        System.out.println("  (the method removed the header row in place, mutating the list)");
        System.out.println();
        System.out.println("  parsed fights (" + fights.size() + "):");
        for (Fight f : fights) {
            System.out.println("    " + f);
            System.out.println("        fighter1 : " + f.getFighter1().getName()
                    + "  (" + f.getFighter1().getSherdogUrl() + ")");
            System.out.println("        fighter2 : " + f.getFighter2().getName()
                    + "  (" + f.getFighter2().getSherdogUrl() + ")");
            System.out.println("        event    : " + f.getEvent().getName()
                    + "  (" + f.getEvent().getSherdogUrl() + ")");
            System.out.println("        date     : " + f.getDate());
        }

        System.out.println();
        System.out.println("=== Scenario 2: empty row list (size 0, loop skipped) ===");
        Elements empty = new Elements();
        List<Fight> none = parser.getFights(empty, fighter);
        System.out.println("  returned list size : " + none.size());
        System.out.println("  (trs.size() was 0, so the header removal and row loop were skipped");
        System.out.println("   entirely and an empty list was returned)");
    }
}








class SherdogFixtures {

    private static Element el(String tag, String... classes) {
        Element e = new Element(tag);
        if (classes.length > 0) {
            e.addClass(classes);
        }
        return e;
    }

    static Document buildFighterPage() {
        Document doc = new Document();
        doc.attr("data-url", "https://www.sherdog.com/fighter/John-Doe-123456");

        Element bio = el("div", "bio_fighter");
        Element h1 = el("h1");
        h1.appendChild(el("span", "fn").html("John Doe"));
        bio.appendChild(h1);
        Element nick = el("span", "nickname");
        nick.appendChild(el("em").html("The Hammer"));
        bio.appendChild(nick);
        bio.appendChild(el("span").attr("itemprop", "birthDate").html("1990-05-14"));
        Element content = el("div", "content");
        content.appendChild(el("img").attr("itemprop", "image").attr("src", "/image_crop/john-doe.jpg"));
        bio.appendChild(content);
        doc.appendChild(bio);

        Element size = el("div", "size_info");
        Element h = el("div", "height");
        h.appendChild(el("strong").html("6\'1\""));
        Element w = el("div", "weight");
        w.appendChild(el("strong").html("185 lbs"));
        size.appendChild(h);
        size.appendChild(w);
        doc.appendChild(size);

        
        
        Element graphs = el("div", "graphs");
        Element wins = el("div", "bio_graph");
        wins.appendChild(el("span", "counter").html("15"));
        wins.appendChild(el("span", "graph_tag").html("8 KO/TKO"));
        wins.appendChild(el("span", "graph_tag").html("4 SUBMISSIONS"));
        wins.appendChild(el("span", "graph_tag").html("2 DECISIONS"));
        wins.appendChild(el("span", "graph_tag").html("1 OTHERS"));
        graphs.appendChild(wins);

        Element losses = el("div", "bio_graph", "loser");
        losses.appendChild(el("span", "counter").html("3"));
        losses.appendChild(el("span", "graph_tag").html("1 KO/TKO"));
        losses.appendChild(el("span", "graph_tag").html("1 SUBMISSIONS"));
        losses.appendChild(el("span", "graph_tag").html("1 DECISIONS"));
        losses.appendChild(el("span", "graph_tag").html("0 OTHERS"));
        graphs.appendChild(losses);
        doc.appendChild(graphs);

        Element right = el("div", "right_side");
        Element cards = el("div", "bio_graph");
        Element drawCard = el("div", "card");
        drawCard.appendChild(el("span", "result").html("Draws"));
        drawCard.appendChild(el("span", "counter").html("1"));
        cards.appendChild(drawCard);
        Element ncCard = el("div", "card");
        ncCard.appendChild(el("span", "result").html("N/C"));
        ncCard.appendChild(el("span", "counter").html("2"));
        cards.appendChild(ncCard);
        right.appendChild(cards);
        doc.appendChild(right);

        doc.appendChild(history("FIGHT HISTORY - PRO", false));
        doc.appendChild(history("FIGHT HISTORY - Upcoming", true));
        return doc;
    }

    private static Element history(String header, boolean upcoming) {
        Element fh = el("div", "fight_history");
        Element mh = el("div", "module_header");
        mh.appendChild(el("h2").html(header));
        fh.appendChild(mh);

        Element tableDiv = el("div", "table");
        Element table = el("table");
        tableDiv.appendChild(table);
        fh.appendChild(tableDiv);

        Element headerRow = el("tr");
        for (int i = 0; i < 6; i++) {
            headerRow.appendChild(el("th").html("col" + i));
        }
        table.appendChild(headerRow);

        if (upcoming) {
            table.appendChild(row("", "Future Opponent", "/fighter/Future-Opponent",
                    "Example FC 20", "/events/Example-FC-20", "2021-01-01", "N/A", "0", "N/A"));
        } else {
            table.appendChild(row("win", "Jane Smith", "/fighter/Jane-Smith",
                    "Example FC 9", "/events/Example-FC-9", "2019-01-10", "TKO (Punches)", "2", "3:45"));
            table.appendChild(row("loss", "Sam Roe", "/fighter/Sam-Roe",
                    "Example FC 8", "/events/Example-FC-8", "2018-07-04", "Decision (Unanimous)", "3", "5:00"));
            table.appendChild(row("win", "Alex Kim", "/fighter/Alex-Kim",
                    "Example FC 7", "/events/Example-FC-7", "2018-01-20", "Submission (RNC)", "1", "1:12"));
        }
        return fh;
    }

    static Element row(String result, String oppName, String oppUrl, String eventName,
            String eventUrl, String date, String method, String round, String time) {
        Element tr = el("tr");
        Element tdResult = el("td");
        if (!result.isEmpty()) {
            tdResult.appendChild(el("span", "final_result").html(result));
        }
        tr.appendChild(tdResult);

        Element tdOpp = el("td");
        tdOpp.appendChild(el("a").attr("href", oppUrl).html(oppName));
        tr.appendChild(tdOpp);

        Element tdEvent = el("td");
        tdEvent.appendChild(el("a").attr("href", eventUrl).html(eventName));
        tdEvent.appendChild(el("span", "sub_line").html(date));
        tr.appendChild(tdEvent);

        tr.appendChild(el("td").html(method));
        tr.appendChild(el("td").html(round));
        tr.appendChild(el("td").html(time));
        return tr;
    }

    
    static Elements buildFightRows() {
        Element table = el("table");
        Element headerRow = el("tr");
        for (int i = 0; i < 6; i++) {
            headerRow.appendChild(el("th").html("col" + i));
        }
        table.appendChild(headerRow);
        table.appendChild(row("win", "Jane Smith", "/fighter/Jane-Smith",
                "Example FC 9", "/events/Example-FC-9", "2019-01-10", "TKO (Punches)", "2", "3:45"));
        table.appendChild(row("loss", "Sam Roe", "/fighter/Sam-Roe",
                "Example FC 8", "/events/Example-FC-8", "2018-07-04", "Decision (Unanimous)", "3", "5:00"));
        table.appendChild(row("win", "Alex Kim", "/fighter/Alex-Kim",
                "Example FC 7", "/events/Example-FC-7", "2018-01-20", "Submission (RNC)", "1", "1:12"));
        return table.select("tr");
    }
}
