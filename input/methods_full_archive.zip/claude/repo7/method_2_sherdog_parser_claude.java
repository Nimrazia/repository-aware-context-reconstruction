





























import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
















class Element {
    final String tag;
    final Map<String, String> attributes = new LinkedHashMap<String, String>();
    final List<String> classNames = new ArrayList<String>();
    final List<Element> children = new ArrayList<Element>();
    Element parent;
    String innerHtml = "";

    Element(String tag) {
        this.tag = tag;
    }

    Element addClass(String... names) {
        for (String n : names) {
            classNames.add(n);
        }
        attributes.put("class", String.join(" ", classNames));
        return this;
    }

    Element attr(String name, String value) {
        attributes.put(name, value);
        return this;
    }

    Element html(String html) {
        this.innerHtml = html;
        return this;
    }

    Element appendChild(Element child) {
        child.parent = this;
        children.add(child);
        return this;
    }

    
    String html() {
        return innerHtml;
    }

    



    String attr(String name) {
        if (name.startsWith("abs:")) {
            String v = attributes.get(name.substring(4));
            if (v == null) {
                return "";
            }
            return v.startsWith("http") ? v : "https://www.sherdog.com" + v;
        }
        String v = attributes.get(name);
        return v == null ? "" : v;
    }

    
    Elements select(String cssQuery) {
        List<Element> matches = new ArrayList<Element>();
        List<Selector.Step> steps = Selector.parse(cssQuery);
        for (Element c : children) {
            Selector.collect(c, steps, matches);
        }
        return new Elements(matches);
    }
}







class Elements extends ArrayList<Element> {
    private static final long serialVersionUID = 1L;

    Elements() {
        super();
    }

    Elements(List<Element> initial) {
        super(initial);
    }

    
    Elements select(String cssQuery) {
        List<Element> matches = new ArrayList<Element>();
        for (Element e : this) {
            matches.addAll(e.select(cssQuery));
        }
        return new Elements(matches);
    }

    
    Element first() {
        return isEmpty() ? null : get(0);
    }

    
    String html() {
        return isEmpty() ? "" : get(0).html();
    }

    
    String attr(String name) {
        return isEmpty() ? "" : get(0).attr(name);
    }
}


class Document extends Element {
    Document() {
        super("#document");
    }
}







class Selector {

    static class Step {
        String tag;
        List<String> classNames = new ArrayList<String>();
        String id;
        String attrName;
        String attrValue;
        String pseudo;
    }

    static List<Step> parse(String query) {
        List<Step> steps = new ArrayList<Step>();
        String[] parts = query.trim().split("\\s+");
        for (String part : parts) {
            steps.add(parseCompound(part));
        }
        return steps;
    }

    private static Step parseCompound(String part) {
        Step step = new Step();
        int pseudoIdx = part.indexOf(':');
        if (pseudoIdx >= 0) {
            step.pseudo = part.substring(pseudoIdx + 1);
            part = part.substring(0, pseudoIdx);
        }
        int bracket = part.indexOf('[');
        if (bracket >= 0) {
            int close = part.indexOf(']', bracket);
            String expr = part.substring(bracket + 1, close);
            String[] kv = expr.split("=", 2);
            step.attrName = kv[0].trim();
            if (kv.length > 1) {
                step.attrValue = kv[1].trim().replaceAll("^\"|\"$", "");
            }
            part = part.substring(0, bracket);
        }
        String remaining = part;
        int firstSpecial = indexOfAny(remaining, '.', '#');
        if (firstSpecial != 0) {
            step.tag = firstSpecial < 0 ? remaining : remaining.substring(0, firstSpecial);
            remaining = firstSpecial < 0 ? "" : remaining.substring(firstSpecial);
        }
        while (!remaining.isEmpty()) {
            char marker = remaining.charAt(0);
            int next = indexOfAny(remaining.substring(1), '.', '#');
            String token = next < 0 ? remaining.substring(1) : remaining.substring(1, next + 1);
            if (marker == '.') {
                step.classNames.add(token);
            } else if (marker == '#') {
                step.id = token;
            }
            remaining = next < 0 ? "" : remaining.substring(next + 1);
        }
        if (step.tag != null && step.tag.isEmpty()) {
            step.tag = null;
        }
        return step;
    }

    private static int indexOfAny(String s, char a, char b) {
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == a || s.charAt(i) == b) {
                return i;
            }
        }
        return -1;
    }

    static boolean matches(Element e, Step step) {
        if (step.tag != null && !step.tag.equals(e.tag)) {
            return false;
        }
        for (String cls : step.classNames) {
            if (!e.classNames.contains(cls)) {
                return false;
            }
        }
        if (step.id != null && !step.id.equals(e.attr("id"))) {
            return false;
        }
        if (step.attrName != null) {
            if (!e.attributes.containsKey(step.attrName)) {
                return false;
            }
            if (step.attrValue != null && !step.attrValue.equals(e.attr(step.attrName))) {
                return false;
            }
        }
        if ("first-of-type".equals(step.pseudo)) {
            if (e.parent == null) {
                return false;
            }
            for (Element sibling : e.parent.children) {
                if (sibling == e) {
                    break;
                }
                if (sibling.tag.equals(e.tag)) {
                    return false;
                }
            }
        }
        return true;
    }

    static void collect(Element node, List<Step> steps, List<Element> out) {
        int last = steps.size() - 1;
        if (matches(node, steps.get(last)) && ancestorsMatch(node.parent, steps, last - 1)) {
            out.add(node);
        }
        for (Element c : node.children) {
            collect(c, steps, out);
        }
    }

    private static boolean ancestorsMatch(Element start, List<Step> steps, int idx) {
        if (idx < 0) {
            return true;
        }
        Element cur = start;
        while (cur != null) {
            if (matches(cur, steps.get(idx)) && ancestorsMatch(cur.parent, steps, idx - 1)) {
                return true;
            }
            cur = cur.parent;
        }
        return false;
    }
}






class Logger {
    private final String name;

    Logger(String name) {
        this.name = name;
    }

    void info(String format, Object... args) {
        StringBuilder sb = new StringBuilder();
        int argIdx = 0;
        int i = 0;
        while (i < format.length()) {
            if (i + 1 < format.length() && format.charAt(i) == '{' && format.charAt(i + 1) == '}'
                    && argIdx < args.length) {
                sb.append(String.valueOf(args[argIdx++]));
                i += 2;
            } else {
                sb.append(format.charAt(i));
                i++;
            }
        }
        System.out.println("[INFO] " + name + " - " + sb);
    }
}


class LoggerFactory {
    static Logger getLogger(Class<?> clazz) {
        return new Logger(clazz.getSimpleName());
    }
}









class SherdogBaseObject {
    private String name;
    private String sherdogUrl;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSherdogUrl() { return sherdogUrl; }
    public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }

    @Override
    public String toString() {
        return name;
    }
}


enum FightResult {
    WIN, LOSS, DRAW, NC, UPCOMING, NOT_HAPPENED
}


enum FightType {
    PRO, AMATEUR, UPCOMING, UNKNOWN;

    static FightType fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        String u = s.trim().toUpperCase();
        if (u.contains("AMATEUR")) {
            return AMATEUR;
        }
        if (u.contains("UPCOMING")) {
            return UPCOMING;
        }
        if (u.contains("PRO")) {
            return PRO;
        }
        return UNKNOWN;
    }
}


class Fight {
    private SherdogBaseObject event;
    private SherdogBaseObject fighter1;
    private SherdogBaseObject fighter2;
    private FightResult result;
    private String winMethod;
    private int winRound;
    private String winTime;
    private Date date;
    private FightType type;

    public SherdogBaseObject getEvent() { return event; }
    public void setEvent(SherdogBaseObject event) { this.event = event; }
    public SherdogBaseObject getFighter1() { return fighter1; }
    public void setFighter1(SherdogBaseObject fighter1) { this.fighter1 = fighter1; }
    public SherdogBaseObject getFighter2() { return fighter2; }
    public void setFighter2(SherdogBaseObject fighter2) { this.fighter2 = fighter2; }
    public FightResult getResult() { return result; }
    public void setResult(FightResult result) { this.result = result; }
    public String getWinMethod() { return winMethod; }
    public void setWinMethod(String winMethod) { this.winMethod = winMethod; }
    public int getWinRound() { return winRound; }
    public void setWinRound(int winRound) { this.winRound = winRound; }
    public String getWinTime() { return winTime; }
    public void setWinTime(String winTime) { this.winTime = winTime; }
    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
    public FightType getType() { return type; }
    public void setType(FightType type) { this.type = type; }

    @Override
    public String toString() {
        return (fighter1 == null ? "?" : fighter1.getName()) + " vs "
                + (fighter2 == null ? "?" : fighter2.getName())
                + " [" + result + ", " + winMethod + ", R" + winRound + ", " + winTime + "]";
    }
}



class Event extends SherdogBaseObject {
    private Date date;
    private List<Fight> fights = new ArrayList<Fight>();

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
    public List<Fight> getFights() { return fights; }
    public void setFights(List<Fight> fights) { this.fights = fights; }
}







class ParserUtils {

    
    static String getSherdogPageUrl(Document doc) {
        Element canonical = doc.select("link[rel=canonical]").first();
        return canonical != null ? canonical.attr("href") : doc.attr("data-url");
    }

    



    static FightResult getFightResult(Element fightRow) {
        if (fightRow == null) {
            return FightResult.NOT_HAPPENED;
        }
        String text = fightRow.select("span.final_result").html();
        if (text == null || text.isEmpty()) {
            return FightResult.NOT_HAPPENED;
        }
        text = text.trim().toLowerCase();
        if (text.contains("win")) {
            return FightResult.WIN;
        }
        if (text.contains("loss")) {
            return FightResult.LOSS;
        }
        if (text.contains("draw")) {
            return FightResult.DRAW;
        }
        if (text.contains("nc")) {
            return FightResult.NC;
        }
        return FightResult.NOT_HAPPENED;
    }
}






public class method_2_sherdog_parser_claude {

    private static final Logger logger = LoggerFactory.getLogger(method_2_sherdog_parser_claude.class);

    
    private static final int FIGHTER1_COLUMN = 0;
    private static final int METHOD_COLUMN = 2;
    private static final int ROUND_COLUMN = 3;
    private static final int TIME_COLUMN = 4;
    private static final int FIGHTER2_COLUMN = 5;

    
    private void getFights(Document doc, Event event) {
        logger.info("Getting fights for event #{}[{}]", event.getSherdogUrl(), event.getName());

        SherdogBaseObject sEvent = new SherdogBaseObject();
        sEvent.setName(event.getName());
        sEvent.setSherdogUrl(event.getSherdogUrl());

        List<Fight> fights = new ArrayList<>();

        
        Elements mainFightElement = doc.select(".content.event");

        Elements fighters = mainFightElement.select("h3 a");
        
        SherdogBaseObject mainFighter1 = new SherdogBaseObject();
        Element mainFighter1Element = fighters.get(0);
        mainFighter1.setSherdogUrl(mainFighter1Element.attr("abs:href"));
        mainFighter1.setName(mainFighter1Element.select("span[itemprop=\"name\"]").html());

        
        SherdogBaseObject mainFighter2 = new SherdogBaseObject();
        Element mainFighter2Element = fighters.get(1);
        mainFighter2.setSherdogUrl(mainFighter2Element.attr("abs:href"));
        mainFighter2.setName(mainFighter2Element.select("span[itemprop=\"name\"]").html());


        Fight mainFight = new Fight();
        mainFight.setEvent(sEvent);
        mainFight.setFighter1(mainFighter1);
        mainFight.setFighter2(mainFighter2);
        mainFight.setResult(ParserUtils.getFightResult(mainFightElement.first()));

        
        Elements mainTd = mainFightElement.select("td");
        if (mainTd.size() > 0) {
            mainFight.setWinMethod(mainTd.get(1).html().replaceAll("<em(.*)<br>", "").trim());
            mainFight.setWinRound(Integer.parseInt(mainTd.get(3).html().replaceAll("<em(.*)<br>", "").trim()));
            mainFight.setWinTime(mainTd.get(4).html().replaceAll("<em(.*)<br>", "").trim());
        }
        mainFight.setDate(event.getDate());


        fights.add(mainFight);
        logger.info("Fight added: {}", mainFight);
        

        logger.info("Found {} fights", fights.size());

        Elements tds = doc.select(".event_match table tr");

        fights.addAll(parseEventFights(tds, event));


        event.setFights(fights);
    }
    

    




    private List<Fight> parseEventFights(Elements trs, Event event) {
        SherdogBaseObject sEvent = new SherdogBaseObject();
        sEvent.setName(event.getName());
        sEvent.setSherdogUrl(event.getSherdogUrl());

        List<Fight> fights = new ArrayList<Fight>();

        if (trs.size() > 0) {
            trs.remove(0);

            trs.forEach(tr -> {
                Fight fight = new Fight();
                fight.setEvent(sEvent);
                fight.setDate(event.getDate());
                Elements tds = tr.select("td");

                fight.setFighter1(getFighter(tds.get(FIGHTER1_COLUMN)));
                fight.setFighter2(getFighter(tds.get(FIGHTER2_COLUMN)));

                if (tds.size() == 7) {
                    fight.setResult(getResult(tds.get(FIGHTER1_COLUMN)));
                    fight.setWinMethod(getMethod(tds.get(METHOD_COLUMN)));
                    fight.setWinRound(getRound(tds.get(ROUND_COLUMN)));
                    fight.setWinTime(getTime(tds.get(TIME_COLUMN)));
                }

                fights.add(fight);
                logger.info("Fight added: {}", fight);
            });
        }

        return fights;
    }

    




    private SherdogBaseObject getFighter(Element td) {
        SherdogBaseObject fighter = new SherdogBaseObject();
        Element link = td.select("a").first();
        if (link != null) {
            fighter.setName(link.html());
            fighter.setSherdogUrl(link.attr("href"));
        }
        return fighter;
    }

    private FightResult getResult(Element td) {
        return ParserUtils.getFightResult(td);
    }

    private String getMethod(Element td) {
        return td.html();
    }

    private int getRound(Element td) {
        try {
            return Integer.parseInt(td.html().trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String getTime(Element td) {
        return td.html();
    }

    



    public static void main(String[] args) throws Exception {
        Document doc = SherdogFixtures.buildEventPage();

        Event event = new Event();
        event.setName("Example FC 10");
        event.setSherdogUrl("/events/Example-FC-10-12345");
        event.setDate(new SimpleDateFormat("yyyy-MM-dd").parse("2020-06-01"));

        method_2_sherdog_parser_claude parser = new method_2_sherdog_parser_claude();
        parser.getFights(doc, event);

        System.out.println();
        System.out.println("=== Parsed Event ===");
        System.out.println("  name       : " + event.getName());
        System.out.println("  sherdogUrl : " + event.getSherdogUrl());
        System.out.println("  date       : " + event.getDate());
        System.out.println("  fights (" + event.getFights().size() + "):");
        for (int i = 0; i < event.getFights().size(); i++) {
            Fight f = event.getFights().get(i);
            String label = (i == 0) ? "main event" : "undercard ";
            System.out.println("    [" + label + "] " + f);
            System.out.println("                  fighter1 url = " + f.getFighter1().getSherdogUrl());
            System.out.println("                  fighter2 url = " + f.getFighter2().getSherdogUrl());
        }
        System.out.println();
        System.out.println("  note: the main event's fighter URLs were read with the abs:href");
        System.out.println("        selector, so they are absolute; the undercard rows use plain");
        System.out.println("        href and stay relative, exactly as upstream does it.");
        System.out.println("  note: the main event's method/round/time cells carried <em>..<br>");
        System.out.println("        label markup, which the target method stripped with its");
        System.out.println("        replaceAll before parsing the round number.");
    }
}







class SherdogFixtures {

    private static Element el(String tag, String... classes) {
        Element e = new Element(tag);
        if (classes.length > 0) {
            e.addClass(classes);
        }
        return e;
    }

    static Document buildEventPage() {
        Document doc = new Document();
        doc.attr("data-url", "https://www.sherdog.com/events/Example-FC-10-12345");

        Element main = el("div", "content", "event");
        Element h3 = el("h3");
        Element a1 = el("a").attr("href", "/fighter/Main-Eventer-One");
        a1.appendChild(el("span").attr("itemprop", "name").html("Main Eventer One"));
        Element a2 = el("a").attr("href", "/fighter/Main-Eventer-Two");
        a2.appendChild(el("span").attr("itemprop", "name").html("Main Eventer Two"));
        h3.appendChild(a1);
        h3.appendChild(a2);
        main.appendChild(h3);
        main.appendChild(el("span", "final_result").html("win"));

        Element table = el("table");
        Element tr = el("tr");
        tr.appendChild(el("td").html("Main Event"));
        tr.appendChild(el("td").html("<em>Method</em><br>KO (Punch)"));
        tr.appendChild(el("td").html("Referee"));
        tr.appendChild(el("td").html("<em>Round</em><br>1"));
        tr.appendChild(el("td").html("<em>Time</em><br>4:32"));
        table.appendChild(tr);
        main.appendChild(table);
        doc.appendChild(main);

        Element card = el("div", "event_match");
        Element cardTable = el("table");
        card.appendChild(cardTable);
        cardTable.appendChild(cardHeaderRow());
        cardTable.appendChild(cardRow("Card Fighter A", "/fighter/Card-Fighter-A",
                "Card Fighter B", "/fighter/Card-Fighter-B", "Decision (Split)", "3", "5:00"));
        cardTable.appendChild(cardRow("Card Fighter C", "/fighter/Card-Fighter-C",
                "Card Fighter D", "/fighter/Card-Fighter-D", "Submission (Armbar)", "2", "2:41"));
        doc.appendChild(card);
        return doc;
    }

    static Element cardHeaderRow() {
        Element tr = el("tr");
        for (int i = 0; i < 7; i++) {
            tr.appendChild(el("th").html("h" + i));
        }
        return tr;
    }

    




    static Element cardRow(String f1Name, String f1Url, String f2Name, String f2Url,
            String method, String round, String time) {
        
        
        
        
        
        
        Element tr = el("tr");

        Element td0 = el("td");
        td0.appendChild(el("a").attr("href", f1Url).html(f1Name));
        td0.appendChild(el("span", "final_result").html("win"));
        tr.appendChild(td0);

        tr.appendChild(el("td").html("Lightweight"));
        tr.appendChild(el("td").html(method));
        tr.appendChild(el("td").html(round));
        tr.appendChild(el("td").html(time));

        Element td5 = el("td");
        td5.appendChild(el("a").attr("href", f2Url).html(f2Name));
        tr.appendChild(td5);

        tr.appendChild(el("td").html("notes"));
        return tr;
    }

    
    static Elements buildCardRows() {
        Element table = el("table");
        table.appendChild(cardHeaderRow());
        table.appendChild(cardRow("Card Fighter A", "/fighter/Card-Fighter-A",
                "Card Fighter B", "/fighter/Card-Fighter-B", "Decision (Split)", "3", "5:00"));
        table.appendChild(cardRow("Card Fighter C", "/fighter/Card-Fighter-C",
                "Card Fighter D", "/fighter/Card-Fighter-D", "Submission (Armbar)", "2", "2:41"));
        return table.select("tr");
    }
}
