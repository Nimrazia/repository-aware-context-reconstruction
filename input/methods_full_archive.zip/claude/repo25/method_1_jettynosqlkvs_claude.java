


































import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;






abstract class NoSqlSessionManager {
  protected abstract Object refresh(NoSqlSessionManager.NoSqlSession session, Object version);

  
  
  
  
  
  static class NoSqlSession {
    private final String clusterId;
    private final java.util.Map<String, Object> attributes = new java.util.HashMap<>();
    private boolean invalidated = false;
    final java.util.List<String> lifecycleLog = new java.util.ArrayList<>();
    final java.util.List<String> boundNames = new java.util.ArrayList<>();
    final java.util.List<String> unboundNames = new java.util.ArrayList<>();

    NoSqlSession(String clusterId) {
      this.clusterId = clusterId;
    }

    String getClusterId() {
      return clusterId;
    }

    void invalidate() {
      invalidated = true;
      lifecycleLog.add("invalidate");
    }

    boolean isInvalidated() {
      return invalidated;
    }

    void willPassivate() {
      lifecycleLog.add("willPassivate");
    }

    void didActivate() {
      lifecycleLog.add("didActivate");
    }

    java.util.Set<String> getNames() {
      return new java.util.HashSet<>(attributes.keySet());
    }

    Object getAttribute(String name) {
      return attributes.get(name);
    }

    void doPutOrRemove(String name, Object value) {
      if (value == null) {
        attributes.remove(name);
      } else {
        attributes.put(name, value);
      }
    }

    void bindValue(String name, Object value) {
      boundNames.add(name);
    }

    void unbindValue(String name, Object value) {
      unboundNames.add(name);
    }

    @Override
    public String toString() {
      return "NoSqlSession{clusterId=" + clusterId + ", attributes=" + attributes + "}";
    }
  }
}

public class method_1_jettynosqlkvs_claude extends NoSqlSessionManager {

  
  
  
  static class Log {
    void debug(String msg) {
      System.out.println("[DEBUG] " + msg);
    }

    void warn(String msg) {
      System.out.println("[WARN] " + msg);
    }

    void warn(Exception e) {
      System.out.println("[WARN] " + e);
    }
  }

  static final Log log = new Log();

  
  
  
  
  
  static class TranscoderException extends Exception {
    TranscoderException(String msg) {
      super(msg);
    }
  }

  interface ISerializableSession {
    long getVersion();

    boolean isValid();

    String getId();

    String getDomain();

    String getPath();

    long getCreationTime();

    long getAccessed();

    Enumeration<String> getAttributeNames();

    Object getAttribute(String name);

    Map<String, Object> getAttributeMap();
  }

  static class SimpleSerializableSession implements ISerializableSession {
    long version;
    boolean valid = true;
    String id;
    String domain = "*";
    String path = "*";
    long creationTime = System.currentTimeMillis();
    long accessed = System.currentTimeMillis();
    final Map<String, Object> attributes = new HashMap<>();

    SimpleSerializableSession(String id, long version) {
      this.id = id;
      this.version = version;
    }

    @Override
    public long getVersion() {
      return version;
    }

    @Override
    public boolean isValid() {
      return valid;
    }

    @Override
    public String getId() {
      return id;
    }

    @Override
    public String getDomain() {
      return domain;
    }

    @Override
    public String getPath() {
      return path;
    }

    @Override
    public long getCreationTime() {
      return creationTime;
    }

    @Override
    public long getAccessed() {
      return accessed;
    }

    @Override
    public Enumeration<String> getAttributeNames() {
      return new Vector<>(attributes.keySet()).elements();
    }

    @Override
    public Object getAttribute(String name) {
      return attributes.get(name);
    }

    @Override
    public Map<String, Object> getAttributeMap() {
      return attributes;
    }
  }

  
  
  
  
  
  final Map<String, ISerializableSession> kvStore = new HashMap<>();
  boolean throwOnGetKey = false;

  ISerializableSession getKey(String clusterId) throws TranscoderException {
    if (throwOnGetKey) {
      throw new TranscoderException("simulated deserialization failure for " + clusterId);
    }
    return kvStore.get(clusterId);
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  @Override
    protected Object refresh(final NoSqlSession session, Object version)
    {
        log.debug("refresh " + session);
        ISerializableSession data = null;
        try
        {
            data = getKey(session.getClusterId());
        }
        catch (TranscoderException error)
        {
            throw (new IllegalStateException("unable to deserialize session: id=" + session.getClusterId(), error));
        }
        
        if (version != null)
        {
            long saved = 0;
            if (data != null)
            {
                saved = data.getVersion();

                if (saved == (Long) version)
                {
                    log.debug("refresh not needed");
                    return version;
                }
                version = Long.valueOf(saved);
            }
        }

        
        if (data == null)
        {
            log.debug("refresh:marking invalid, no object");
            session.invalidate();
            return null;
        }

        
        boolean valid = data.isValid();
        if (!valid)
        {
            log.debug("refresh:marking invalid, valid flag " + valid);
            session.invalidate();
            return null;
        }

        
        
        session.willPassivate();
        try
        {
            for (Enumeration<String> e = data.getAttributeNames(); e.hasMoreElements();)
            {
                String name = e.nextElement();
                Object value = data.getAttribute(name);
                
                if (!session.getNames().contains(name))
                {
                    session.doPutOrRemove(name, value);
                    session.bindValue(name, value);
                }
                else
                {
                    session.doPutOrRemove(name, value);
                }
            }

            
            for (String name : session.getNames())
            {
                if (!data.getAttributeMap().containsKey(name))
                {
                    session.doPutOrRemove(name, null);
                    session.unbindValue(name, session.getAttribute(name));
                }
            }

            session.didActivate();
            return version;
        }
        catch (Exception e)
        {
            log.warn(e);
        }

        return null;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: KeyValueStoreSessionManager.refresh ===");

    method_1_jettynosqlkvs_claude manager = new method_1_jettynosqlkvs_claude();

    
    SimpleSerializableSession dataA = new SimpleSerializableSession("sess-A", 3L);
    dataA.attributes.put("cart", "3 items");
    manager.kvStore.put("sess-A", dataA);
    NoSqlSession sessionA = new NoSqlSession("sess-A");
    Object resultA = manager.refresh(sessionA, 3L);
    System.out.println("\n-- Scenario A (version unchanged) --");
    System.out.println("  returned version: " + resultA);
    System.out.println("  lifecycle: " + sessionA.lifecycleLog + " (expected: no willPassivate/didActivate)");

    
    SimpleSerializableSession dataB = new SimpleSerializableSession("sess-B", 2L);
    dataB.attributes.put("cart", "5 items");
    dataB.attributes.put("coupon", "SAVE10");
    manager.kvStore.put("sess-B", dataB);
    NoSqlSession sessionB = new NoSqlSession("sess-B");
    sessionB.doPutOrRemove("cart", "1 item"); 
    sessionB.doPutOrRemove("staleAttr", "shouldBeRemoved"); 

    Object resultB = manager.refresh(sessionB, 1L);
    System.out.println("\n-- Scenario B (newer version, attribute merge) --");
    System.out.println("  returned version: " + resultB + " (expected 2)");
    System.out.println("  session attributes after refresh: cart=" + sessionB.getAttribute("cart") + ", coupon="
        + sessionB.getAttribute("coupon") + ", staleAttr=" + sessionB.getAttribute("staleAttr"));
    System.out.println("  newly bound: " + sessionB.boundNames + " (expected: [coupon])");
    System.out.println("  unbound: " + sessionB.unboundNames + " (expected: [staleAttr])");
    System.out.println("  lifecycle: " + sessionB.lifecycleLog);

    
    NoSqlSession sessionC = new NoSqlSession("sess-missing");
    Object resultC = manager.refresh(sessionC, null);
    System.out.println("\n-- Scenario C (no data in store) --");
    System.out.println("  returned: " + resultC + " (expected null)");
    System.out.println("  invalidated: " + sessionC.isInvalidated() + " (expected true)");

    
    SimpleSerializableSession dataD = new SimpleSerializableSession("sess-D", 1L);
    dataD.valid = false;
    manager.kvStore.put("sess-D", dataD);
    NoSqlSession sessionD = new NoSqlSession("sess-D");
    Object resultD = manager.refresh(sessionD, null);
    System.out.println("\n-- Scenario D (data flagged invalid) --");
    System.out.println("  returned: " + resultD + " (expected null)");
    System.out.println("  invalidated: " + sessionD.isInvalidated() + " (expected true)");

    
    manager.throwOnGetKey = true;
    NoSqlSession sessionE = new NoSqlSession("sess-E");
    System.out.println("\n-- Scenario E (TranscoderException from getKey) --");
    try {
      manager.refresh(sessionE, null);
      System.out.println("  (unexpectedly did not throw)");
    } catch (IllegalStateException e) {
      System.out.println("  caught expected IllegalStateException: " + e.getMessage());
    }

    System.out.println("\n=== Demo complete: method exercised the version-unchanged short-circuit, "
        + "the attribute-merge/bind/unbind passivate-activate lifecycle, the missing-data and "
        + "invalid-data invalidation branches, and the TranscoderException-wrapping branch. ===");
  }
}
