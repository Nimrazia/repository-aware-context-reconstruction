

































import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;





abstract class NoSqlSessionManager {
  protected abstract Object save(NoSqlSessionManager.NoSqlSession session, Object version, boolean activateAfterSave);

  
  
  
  static class NoSqlSession {
    private final String id;
    private boolean valid = true;
    private final Map<String, Object> attributes = new HashMap<>();
    final List<String> lifecycleLog = new ArrayList<>();

    NoSqlSession(String id) {
      this.id = id;
    }

    String getId() {
      return id;
    }

    boolean isValid() {
      return valid;
    }

    void setValid(boolean valid) {
      this.valid = valid;
    }

    void willPassivate() {
      lifecycleLog.add("willPassivate");
    }

    void didActivate() {
      lifecycleLog.add("didActivate");
    }

    void setAttributeInternal(String name, Object value) {
      attributes.put(name, value);
    }

    Map<String, Object> getAttributesSnapshot() {
      return attributes;
    }

    @Override
    public String toString() {
      return "NoSqlSession{id=" + id + ", valid=" + valid + ", attributes=" + attributes + "}";
    }
  }
}

public class method_3_jettynosqlkvs_claude extends NoSqlSessionManager {

  
  
  
  static class Log {
    void debug(String msg) {
      System.out.println("[DEBUG] " + msg);
    }

    void warn(Exception e) {
      System.out.println("[WARN] " + e);
    }
  }

  static final Log log = new Log();

  
  
  
  
  
  
  static class TranscoderException extends Exception {
    TranscoderException(String msg) {
      super(msg);
    }
  }

  interface ISerializableSession {
    void setDomain(String domain);

    void setPath(String path);

    void setVersion(long version);

    long getVersion();

    String getId();

    @Override
    String toString();
  }

  static class SimpleSerializableSession implements ISerializableSession {
    final String id;
    String domain;
    String path;
    long version;
    final Map<String, Object> attributes;

    SimpleSerializableSession(String id, Map<String, Object> attributes) {
      this.id = id;
      this.attributes = attributes;
    }

    @Override
    public void setDomain(String domain) {
      this.domain = domain;
    }

    @Override
    public void setPath(String path) {
      this.path = path;
    }

    @Override
    public void setVersion(long version) {
      this.version = version;
    }

    @Override
    public long getVersion() {
      return version;
    }

    @Override
    public String getId() {
      return id;
    }

    @Override
    public String toString() {
      return "SimpleSerializableSession{id=" + id + ", domain=" + domain + ", path=" + path + ", version=" + version
          + ", attributes=" + attributes + "}";
    }
  }

  interface SessionFactory {
    ISerializableSession create(NoSqlSession session);
  }

  
  
  
  
  
  
  final Map<String, ISerializableSession> kvStore = new HashMap<>();
  String _cookieDomain = "example.com";
  String _cookiePath = "/app";
  boolean throwOnSetKey = false;

  SessionFactory getSessionFactory() {
    return session -> new SimpleSerializableSession(session.getId(), session.getAttributesSnapshot());
  }

  boolean setKey(String id, ISerializableSession data) throws TranscoderException {
    if (throwOnSetKey) {
      throw new TranscoderException("simulated serialization failure for " + id);
    }
    kvStore.put(id, data);
    return true;
  }

  void deleteKey(String id) {
    kvStore.remove(id);
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  @Override
    protected Object save(final NoSqlSession session, final Object version, final boolean activateAfterSave)
    {
        try
        {
            log.debug("save:" + session);
            session.willPassivate();

            if (!session.isValid())
            {
                log.debug("save: skip saving invalidated session: id=" + session.getId());
                deleteKey(session.getId());
                return null;
            }

            ISerializableSession data;
            synchronized (session)
            {
                data = getSessionFactory().create(session);
            }
            data.setDomain(_cookieDomain);
            data.setPath(_cookiePath);
            long longVersion = 1; 
            if (version != null)
            {
                longVersion = (Long) version + 1L;
            }
            data.setVersion(longVersion);

            try
            {
                if (!setKey(session.getId(), data))
                {
                    throw (new RuntimeException("unable to set key: data=" + data));
                }
            }
            catch (TranscoderException error)
            {
                throw (new IllegalArgumentException("unable to serialize session: id=" + session.getId() + ", data="
                    + data, error));
            }
            log.debug("save:db.sessions.update(" + session.getId() + "," + data + ")");

            if (activateAfterSave)
            {
                session.didActivate();
            }

            return longVersion;
        }
        catch (Exception e)
        {
            log.warn(e);
        }
        return null;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: KeyValueStoreSessionManager.save ===");

    method_3_jettynosqlkvs_claude manager = new method_3_jettynosqlkvs_claude();

    
    NoSqlSession sessionA = new NoSqlSession("sess-A");
    sessionA.setAttributeInternal("user", "alice");
    Object resultA = manager.save(sessionA, null, true);
    System.out.println("\n-- Scenario A (new session, activateAfterSave=true) --");
    System.out.println("  returned version: " + resultA + " (expected 1)");
    System.out.println("  stored: " + manager.kvStore.get("sess-A"));
    System.out.println("  lifecycle: " + sessionA.lifecycleLog + " (expected willPassivate, didActivate)");

    
    NoSqlSession sessionB = new NoSqlSession("sess-B");
    sessionB.setAttributeInternal("cart", "1 item");
    Object resultB = manager.save(sessionB, 3L, false);
    System.out.println("\n-- Scenario B (existing session, version bump, no re-activate) --");
    System.out.println("  returned version: " + resultB + " (expected 4)");
    System.out.println("  stored: " + manager.kvStore.get("sess-B"));
    System.out.println("  lifecycle: " + sessionB.lifecycleLog + " (expected only willPassivate)");

    
    NoSqlSession sessionC = new NoSqlSession("sess-C");
    manager.kvStore.put("sess-C", new SimpleSerializableSession("sess-C", new HashMap<>()));
    sessionC.setValid(false);
    Object resultC = manager.save(sessionC, null, true);
    System.out.println("\n-- Scenario C (invalidated session) --");
    System.out.println("  returned: " + resultC + " (expected null)");
    System.out.println("  removed from store: " + !manager.kvStore.containsKey("sess-C"));

    
    manager.throwOnSetKey = true;
    NoSqlSession sessionD = new NoSqlSession("sess-D");
    Object resultD = manager.save(sessionD, null, true);
    System.out.println("\n-- Scenario D (TranscoderException from setKey) --");
    System.out.println("  returned: " + resultD + " (expected null, exception caught internally)");

    System.out.println("\n=== Demo complete: method exercised the new-session/version-1 branch, "
        + "the existing-session version-bump branch (with activateAfterSave=false skipping "
        + "didActivate), the invalidated-session delete-and-return-null branch, and the "
        + "TranscoderException-wrapped-and-caught branch. ===");
  }
}
