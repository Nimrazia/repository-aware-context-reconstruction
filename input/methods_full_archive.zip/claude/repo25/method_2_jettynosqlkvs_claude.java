
































import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;





abstract class NoSqlSessionManager {
  protected abstract NoSqlSessionManager.NoSqlSession loadSession(String clusterId);

  
  
  
  static class NoSqlSession {
    protected final String clusterId;
    protected final Map<String, Object> attributes = new HashMap<>();
    protected final long created;
    protected final long accessed;
    protected long version;
    final List<String> lifecycleLog = new ArrayList<>();
    final List<String> boundNames = new ArrayList<>();

    NoSqlSession(NoSqlSessionManager manager, long created, long accessed, String clusterId, long version) {
      this.created = created;
      this.accessed = accessed;
      this.clusterId = clusterId;
      this.version = version;
    }

    void didActivate() {
      lifecycleLog.add("didActivate");
    }

    void bindValue(String name, Object value) {
      boundNames.add(name);
    }

    @Override
    public String toString() {
      return "NoSqlSession{clusterId=" + clusterId + ", version=" + version + ", attributes=" + attributes + "}";
    }
  }
}







class SmarterNoSqlSession extends NoSqlSessionManager.NoSqlSession {
  SmarterNoSqlSession(NoSqlSessionManager manager, long created, long accessed, String clusterId, long version) {
    super(manager, created, accessed, clusterId, version);
  }

  void initializeAttribute(String name, Object value) {
    attributes.put(name, value);
  }
}

public class method_2_jettynosqlkvs_claude extends NoSqlSessionManager {

  
  
  
  static class Log {
    void debug(String msg) {
      System.out.println("[DEBUG] " + msg);
    }

    void warn(String msg) {
      System.out.println("[WARN] " + msg);
    }

    void warn(Exception e) {
      System.out.println("[WARN] " + e);
    }
  }

  static final Log log = new Log();

  
  
  
  interface ISerializableSession {
    long getVersion();

    boolean isValid();

    String getId();

    String getDomain();

    String getPath();

    long getCreationTime();

    long getAccessed();

    Enumeration<String> getAttributeNames();

    Object getAttribute(String name);
  }

  static class SimpleSerializableSession implements ISerializableSession {
    long version;
    boolean valid = true;
    String id;
    String domain = "*";
    String path = "*";
    long creationTime = System.currentTimeMillis();
    long accessed = System.currentTimeMillis();
    final Map<String, Object> attributes = new HashMap<>();

    SimpleSerializableSession(String id, long version) {
      this.id = id;
      this.version = version;
    }

    @Override
    public long getVersion() {
      return version;
    }

    @Override
    public boolean isValid() {
      return valid;
    }

    @Override
    public String getId() {
      return id;
    }

    @Override
    public String getDomain() {
      return domain;
    }

    @Override
    public String getPath() {
      return path;
    }

    @Override
    public long getCreationTime() {
      return creationTime;
    }

    @Override
    public long getAccessed() {
      return accessed;
    }

    @Override
    public Enumeration<String> getAttributeNames() {
      return new Vector<>(attributes.keySet()).elements();
    }

    @Override
    public Object getAttribute(String name) {
      return attributes.get(name);
    }
  }

  
  
  
  
  final Map<String, ISerializableSession> kvStore = new HashMap<>();
  String _cookieDomain;
  String _cookiePath;

  ISerializableSession getKey(String clusterId) {
    return kvStore.get(clusterId);
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  @Override
    protected NoSqlSession loadSession(final String clusterId)
    {
        log.debug("loadSession: loading: id=" + clusterId);
        ISerializableSession data = getKey(clusterId);
        log.debug("loadSession: loaded: id=" + clusterId + ", data=" + data);

        if (data == null)
        {
            return null;
        }

        boolean valid = data.isValid();
        if (!valid)
        {
            log.debug("loadSession: id=" + clusterId + ", data=" + data + " has been invalidated.");
            return null;
        }

        if (!clusterId.equals(data.getId()))
        {
            log.warn("loadSession: invalid id (expected:" + clusterId + ", got:" + data.getId() + ")");
            return null;
        }

        synchronized (_cookieDomain)
        {
            if (_cookieDomain != null && !data.getDomain().equals("*") && !_cookieDomain.equals(data.getDomain()))
            {
                log.warn("loadSession: invalid cookie domain (expected:" + _cookieDomain + ", got:" + data.getDomain()
                    + ")");
                return null;
            }
        }

        synchronized (_cookiePath)
        {
            if (_cookiePath != null && !data.getPath().equals("*") && !_cookiePath.equals(data.getPath()))
            {
                log.warn("loadSession: invalid cookie path (expected:" + _cookiePath + ", got:" + data.getPath() + ")");
                return null;
            }
        }

        try
        {
            long version = data.getVersion();
            long created = data.getCreationTime();
            long accessed = data.getAccessed();
            SmarterNoSqlSession session = new SmarterNoSqlSession(this, created, accessed, clusterId, version);

            
            Enumeration<String> attrs = data.getAttributeNames();

            
            if (attrs != null)
            {
                while (attrs.hasMoreElements())
                {
                    String name = attrs.nextElement();
                    Object value = data.getAttribute(name);

                    session.initializeAttribute(name, value);
                    session.bindValue(name, value);

                }
            }
            session.didActivate();

            return session;
        }
        catch (Exception e)
        {
            log.warn(e);
        }
        return null;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: KeyValueStoreSessionManager.loadSession ===");

    method_2_jettynosqlkvs_claude manager = new method_2_jettynosqlkvs_claude();
    manager._cookieDomain = "example.com";
    manager._cookiePath = "/app";

    
    SimpleSerializableSession dataA = new SimpleSerializableSession("sess-A", 5L);
    dataA.domain = "example.com";
    dataA.path = "/app";
    dataA.attributes.put("user", "alice");
    dataA.attributes.put("cart", "2 items");
    manager.kvStore.put("sess-A", dataA);

    NoSqlSession loadedA = manager.loadSession("sess-A");
    System.out.println("\n-- Scenario A (valid, matching domain/path) --");
    System.out.println("  loaded: " + loadedA);
    if (loadedA instanceof SmarterNoSqlSession) {
      System.out.println("  bound attribute names: " + loadedA.boundNames);
      System.out.println("  lifecycle: " + loadedA.lifecycleLog);
    }

    
    NoSqlSession loadedB = manager.loadSession("sess-missing");
    System.out.println("\n-- Scenario B (missing session) --");
    System.out.println("  loaded: " + loadedB + " (expected null)");

    
    SimpleSerializableSession dataC = new SimpleSerializableSession("sess-C", 1L);
    dataC.valid = false;
    manager.kvStore.put("sess-C", dataC);
    NoSqlSession loadedC = manager.loadSession("sess-C");
    System.out.println("\n-- Scenario C (invalidated data) --");
    System.out.println("  loaded: " + loadedC + " (expected null)");

    
    SimpleSerializableSession dataD = new SimpleSerializableSession("sess-D", 1L);
    dataD.domain = "other-domain.com";
    dataD.path = "/app";
    manager.kvStore.put("sess-D", dataD);
    NoSqlSession loadedD = manager.loadSession("sess-D");
    System.out.println("\n-- Scenario D (mismatched cookie domain) --");
    System.out.println("  loaded: " + loadedD + " (expected null)");

    
    SimpleSerializableSession dataE = new SimpleSerializableSession("sess-E", 1L);
    dataE.domain = "*";
    dataE.path = "*";
    manager.kvStore.put("sess-E", dataE);
    NoSqlSession loadedE = manager.loadSession("sess-E");
    System.out.println("\n-- Scenario E (wildcard domain/path) --");
    System.out.println("  loaded: " + loadedE + " (expected non-null)");

    System.out.println("\n=== Demo complete: method exercised the happy-path load with attribute "
        + "bind/activate, the missing-session and invalidated-data null returns, the cookie-domain "
        + "mismatch rejection, and the wildcard-domain/path acceptance branch. ===");
  }
}
