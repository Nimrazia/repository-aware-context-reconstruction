




























import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;



public class method_3_ojb_1_0_4_claude {

  private final Log log = new Log(method_3_ojb_1_0_4_claude.class.getName());

  final PersistenceBroker pb;
  boolean batchRetrieval;
  boolean prefetchProxies = true;
  Map<Object, Object> m_retrievalTasks;
  Class<?> classToPrefetch;
  final PBStateEvent afterLookupEvent = new PBStateEvent();

  public method_3_ojb_1_0_4_claude(PersistenceBroker pb) {
    this.pb = pb;
  }

  




  boolean addRetrievalTask(Object candidate, Object owner) {
    return m_retrievalTasks.put(candidate, owner) == null;
  }

  


  void performRetrievalTasks() {
    log.debug("performRetrievalTasks: " + (m_retrievalTasks == null ? 0 : m_retrievalTasks.size()) + " task(s)");
  }

  
  private ManageableCollection getCollectionByQuery(Class collectionClass, Class itemClass, Query query)
            throws ClassNotPersistenceCapableException, PersistenceBrokerException
    {
        if (log.isDebugEnabled()) log.debug("getCollectionByQuery (" + collectionClass + ", " + itemClass + ", " + query + ")");

        ClassDescriptor cld = pb.getClassDescriptor(itemClass);
        ManageableCollection result = null;
        OJBIterator iter = null;
        int fullSize = -1;
        int size = 0;

        final boolean isRetrievalTasksCreated = batchRetrieval && m_retrievalTasks == null;
        if (isRetrievalTasksCreated)
        {
            
            m_retrievalTasks = new HashMap();
        }

        
        pb.getInternalCache().enableMaterializationCache();
        try
        {
            result = (ManageableCollection) collectionClass.newInstance();
            
            
            
            iter = pb.getIteratorFromQuery(query, cld);
            iter.disableLifeCycleEvents();

            
            
            if (iter instanceof PagingIterator)
            {
                fullSize = iter.fullSize();
            }

            while (iter.hasNext())
            {
                Object candidate = iter.next();

                





                if (candidate != null)
                {
                    IndirectionHandler handler = ProxyHelper.getIndirectionHandler(candidate);

                    if ((handler != null) || itemClass.isAssignableFrom(candidate.getClass()))
                    {
                        result.ojbAdd(candidate);

                        
                        
                        size++;
                    }
                    else
                    {
                        
                        log.warn("Candidate object ["+candidate
                                    +"] class ["+candidate.getClass().getName()
                                    +"] is not a subtype of ["+itemClass.getName()
                                    +"] or any type of proxy. NOT INCLUDED in result collection");
                    }
                    if (prefetchProxies && (handler != null)
                            && (cld.getProxyPrefetchingLimit() > 0)
                            && addRetrievalTask(candidate, this))
                    {
                        new PBMaterializationListener(candidate, m_retrievalTasks,
                                this, cld.getProxyPrefetchingLimit());
                    }
                }
            }

            if (isRetrievalTasksCreated)
            {
                
                final Class saveClassToPrefetch = classToPrefetch;
                classToPrefetch = null;
                try
                {
                    performRetrievalTasks();
                }
                finally
                {
                    classToPrefetch = saveClassToPrefetch;
                }
            }

            
            
            Iterator resultIter = result.ojbIterator();
            while (resultIter.hasNext())
            {
                Object obj = resultIter.next();
                afterLookupEvent.setTarget(obj);
                pb.fireBrokerEvent(afterLookupEvent);
                afterLookupEvent.setTarget(null);
            }

            
            pb.getInternalCache().disableMaterializationCache();
        }
        catch(RuntimeException e)
        {
            
            pb.getInternalCache().doLocalClear();
            throw e;
        }
        catch (Exception ex)
        {
            
            pb.getInternalCache().doLocalClear();
            log.error(ex);
            throw new PersistenceBrokerException(ex);
        }
        finally
        {
            if (iter != null)
            {
                iter.releaseDbResources();
            }
            if (isRetrievalTasksCreated)
            {
                m_retrievalTasks = null;
            }
        }

        
        
        if (fullSize < 0)
        {
            fullSize = size;	
        }
        query.fullSize(fullSize);
        
        return result;
    }
  

  







  public static void main(String[] args) throws Exception {
    PersistenceBroker pb = new PersistenceBroker();
    method_3_ojb_1_0_4_claude broker = new method_3_ojb_1_0_4_claude(pb);

    System.out.println("=== Scenario 1: normal materialization (PagingIterator, mixed candidates) ===");
    java.util.List<Object> candidates = new java.util.ArrayList<>();
    candidates.add("apple");
    candidates.add("banana");
    candidates.add(Integer.valueOf(42)); 
    pb.setNextIteratorFromQuery(new ListBackedIterator(candidates, 99));

    FullSizeCapturingQuery query = new FullSizeCapturingQuery();
    ManageableCollection result = broker.getCollectionByQuery(SimpleManageableCollection.class, String.class, query);
    System.out.println("  result=" + result + " query.fullSize=" + query.capturedFullSize);

    System.out.println();
    System.out.println("=== Scenario 2: RuntimeException during materialization (cache-clear + rethrow) ===");
    pb.setNextIteratorFromQuery(new ThrowingIterator());
    try {
      broker.getCollectionByQuery(SimpleManageableCollection.class, String.class, new FullSizeCapturingQuery());
      System.out.println("  ERROR: expected RuntimeException was not thrown");
    } catch (RuntimeException e) {
      System.out.println("  Caught expected RuntimeException: " + e.getMessage());
    }
  }
}



class FullSizeCapturingQuery implements Query {
  int capturedFullSize = -1;
  public void fullSize(int size) { capturedFullSize = size; }
}




class ThrowingIterator implements PagingIterator {
  private int idx = 0;
  public boolean hasNext() { return idx < 2; }
  public Object next() {
    idx++;
    if (idx == 1) return "ok-first";
    throw new IllegalStateException("simulated materialization failure");
  }
  public void disableLifeCycleEvents() { }
  public int fullSize() { return 2; }
  public void releaseDbResources() {
    System.out.println("  [releaseDbResources] called from finally block");
  }
}




class Log {
  private final String name;
  Log(String name) { this.name = name; }
  boolean isDebugEnabled() { return true; }
  void debug(String msg) { System.out.println("[DEBUG] " + name + " - " + msg); }
  void warn(String msg) { System.out.println("[WARN] " + name + " - " + msg); }
  void error(Throwable t) { System.out.println("[ERROR] " + name + " - " + t); }
}






class PBMaterializationListener {
  PBMaterializationListener(Object candidate, Map<Object, Object> retrievalTasks,
      method_3_ojb_1_0_4_claude owner, int prefetchLimit) {
    
    
    
  }
}


class PersistenceBrokerException extends RuntimeException {
  PersistenceBrokerException(Throwable cause) { super(cause); }
}




class ClassNotPersistenceCapableException extends Exception {
  ClassNotPersistenceCapableException(String message) { super(message); }
}



class ClassDescriptor {
  private int proxyPrefetchingLimit;
  void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
  int getProxyPrefetchingLimit() { return proxyPrefetchingLimit; }
}




interface ManageableCollection {
  void ojbAdd(Object obj);
  Iterator<Object> ojbIterator();
}





class SimpleManageableCollection implements ManageableCollection {
  final List<Object> items = new ArrayList<>();
  public void ojbAdd(Object obj) { items.add(obj); }
  public Iterator<Object> ojbIterator() { return items.iterator(); }
  @Override
  public String toString() { return items.toString(); }
}




interface Query {
  void fullSize(int size);
}




interface OJBIterator extends Iterator<Object> {
  void disableLifeCycleEvents();
  int fullSize();
  void releaseDbResources();
}




interface PagingIterator extends OJBIterator {
}




class ListBackedIterator implements PagingIterator {
  private final List<Object> candidates;
  private final int declaredFullSize;
  private int idx = 0;

  ListBackedIterator(List<Object> candidates, int declaredFullSize) {
    this.candidates = candidates;
    this.declaredFullSize = declaredFullSize;
  }

  public boolean hasNext() { return idx < candidates.size(); }
  public Object next() { return candidates.get(idx++); }
  public void disableLifeCycleEvents() {  }
  public int fullSize() { return declaredFullSize; }
  public void releaseDbResources() {  }
}



class IndirectionHandler {
}







class ProxyHelper {
  static IndirectionHandler getIndirectionHandler(Object candidate) {
    return candidate instanceof ProxyMarker ? new IndirectionHandler() : null;
  }
}



interface ProxyMarker {
}




class PBStateEvent {
  private Object target;
  void setTarget(Object target) { this.target = target; }
  Object getTarget() { return target; }
}



class InternalCache {
  private boolean materializationCacheEnabled;
  void enableMaterializationCache() { materializationCacheEnabled = true; }
  void disableMaterializationCache() { materializationCacheEnabled = false; }
  void doLocalClear() {  }
}



class PersistenceBroker {
  private final InternalCache internalCache = new InternalCache();
  private final java.util.Map<Class<?>, ClassDescriptor> descriptors = new java.util.HashMap<>();
  private OJBIterator nextIterator;

  ClassDescriptor getClassDescriptor(Class<?> itemClass) {
    return descriptors.computeIfAbsent(itemClass, c -> new ClassDescriptor());
  }

  InternalCache getInternalCache() { return internalCache; }

  void setNextIteratorFromQuery(OJBIterator iterator) { this.nextIterator = iterator; }

  OJBIterator getIteratorFromQuery(Query query, ClassDescriptor cld) {
    return nextIterator;
  }

  void fireBrokerEvent(PBStateEvent event) {
    System.out.println("  [pb.fireBrokerEvent] target=" + event.getTarget());
  }
}
