

































import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import java.util.HashMap;
import java.util.Map;




public class method_2_ojb_1_0_4_claude extends DefaultHandler implements TagIds {

  private final Log logger = new Log(method_2_ojb_1_0_4_claude.class.getName());
  private final Tags tags = new Tags();

  final List<JdbcConnectionDescriptor> conDesList = new ArrayList<>();
  private boolean defaultConnectionFound;
  private JdbcConnectionDescriptor m_CurrentJCD;
  private DescriptorBase currentAttributeContainer;
  private SequenceDescriptor currentSequenceDescriptor;

  private int getLiteralId(String qName) {
    return Tags.getLiteralId(qName);
  }

  private boolean checkString(String s) {
    return s != null && !s.trim().isEmpty();
  }

  
  public void startElement(String uri, String name, String qName, Attributes atts)
    {
        boolean isDebug = logger.isDebugEnabled();
        try
        {
            switch (getLiteralId(qName))
            {
                case JDBC_CONNECTION_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("   > " + tags.getTagById(JDBC_CONNECTION_DESCRIPTOR));
                        JdbcConnectionDescriptor newJcd = new JdbcConnectionDescriptor();
                        currentAttributeContainer = newJcd;

                        conDesList.add(newJcd);
                        m_CurrentJCD = newJcd;

                        
                        String jcdAlias = atts.getValue(tags.getTagById(JCD_ALIAS));
                        if (isDebug) logger.debug("     " + tags.getTagById(JCD_ALIAS) + ": " + jcdAlias);
                        m_CurrentJCD.setJcdAlias(jcdAlias);

                        
                        String defaultConnection = atts.getValue(tags.getTagById(DEFAULT_CONNECTION));
                        if (isDebug) logger.debug("     " + tags.getTagById(DEFAULT_CONNECTION) + ": " + defaultConnection);
                        m_CurrentJCD.setDefaultConnection(Boolean.valueOf(defaultConnection).booleanValue());
                        if (m_CurrentJCD.isDefaultConnection())
                        {
                            if (defaultConnectionFound)
                            {
                                throw new MetadataException("Found two jdbc-connection-descriptor elements with default-connection=\"true\"");
                            }
                            else
                            {
                                defaultConnectionFound = true;
                            }
                        }

                        
                        String platform = atts.getValue(tags.getTagById(DBMS_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(DBMS_NAME) + ": " + platform);
                        m_CurrentJCD.setDbms(platform);

                        
                        String level = atts.getValue(tags.getTagById(JDBC_LEVEL));
                        if (isDebug) logger.debug("     " + tags.getTagById(JDBC_LEVEL) + ": " + level);
                        m_CurrentJCD.setJdbcLevel(level);

                        
                        String driver = atts.getValue(tags.getTagById(DRIVER_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(DRIVER_NAME) + ": " + driver);
                        m_CurrentJCD.setDriver(driver);

                        
                        String protocol = atts.getValue(tags.getTagById(URL_PROTOCOL));
                        if (isDebug) logger.debug("     " + tags.getTagById(URL_PROTOCOL) + ": " + protocol);
                        m_CurrentJCD.setProtocol(protocol);

                        
                        String subprotocol = atts.getValue(tags.getTagById(URL_SUBPROTOCOL));
                        if (isDebug) logger.debug("     " + tags.getTagById(URL_SUBPROTOCOL) + ": " + subprotocol);
                        m_CurrentJCD.setSubProtocol(subprotocol);

                        
                        String dbalias = atts.getValue(tags.getTagById(URL_DBALIAS));
                        if (isDebug) logger.debug("     " + tags.getTagById(URL_DBALIAS) + ": " + dbalias);
                        m_CurrentJCD.setDbAlias(dbalias);

                        
                        String datasource = atts.getValue(tags.getTagById(DATASOURCE_NAME));
                        
                        if(datasource != null && datasource.trim().equals("")) datasource = null;
                        if (isDebug) logger.debug("     " + tags.getTagById(DATASOURCE_NAME) + ": " + datasource);
                        m_CurrentJCD.setDatasourceName(datasource);

                        
                        String user = atts.getValue(tags.getTagById(USER_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(USER_NAME) + ": " + user);
                        m_CurrentJCD.setUserName(user);

                        
                        String password = atts.getValue(tags.getTagById(USER_PASSWD));
                        if (isDebug) logger.debug("     " + tags.getTagById(USER_PASSWD) + ": " + password);
                        m_CurrentJCD.setPassWord(password);

                        
                        String eagerRelease = atts.getValue(tags.getTagById(EAGER_RELEASE));
                        if (isDebug) logger.debug("     " + tags.getTagById(EAGER_RELEASE) + ": " + eagerRelease);
                        m_CurrentJCD.setEagerRelease(Boolean.valueOf(eagerRelease).booleanValue());

                        
                        String batchMode = atts.getValue(tags.getTagById(BATCH_MODE));
                        if (isDebug) logger.debug("     " + tags.getTagById(BATCH_MODE) + ": " + batchMode);
                        m_CurrentJCD.setBatchMode(Boolean.valueOf(batchMode).booleanValue());

                        
                        String useAutoCommit = atts.getValue(tags.getTagById(USE_AUTOCOMMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(USE_AUTOCOMMIT) + ": " + useAutoCommit);
                        m_CurrentJCD.setUseAutoCommit(Integer.valueOf(useAutoCommit).intValue());

                        
                        String ignoreAutoCommitExceptions = atts.getValue(tags.getTagById(IGNORE_AUTOCOMMIT_EXCEPTION));
                        if (isDebug) logger.debug("     " + tags.getTagById(IGNORE_AUTOCOMMIT_EXCEPTION) + ": " + ignoreAutoCommitExceptions);
                        m_CurrentJCD.setIgnoreAutoCommitExceptions(Boolean.valueOf(ignoreAutoCommitExceptions).booleanValue());

                        break;
                    }
                case CONNECTION_POOL:
                    {
                        if (m_CurrentJCD != null)
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(CONNECTION_POOL));
                            final ConnectionPoolDescriptor m_CurrentCPD = m_CurrentJCD.getConnectionPoolDescriptor();
                            this.currentAttributeContainer = null;

                            String maxActive = atts.getValue(tags.getTagById(CON_MAX_ACTIVE));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_ACTIVE) + ": " + maxActive);
                            if (checkString(maxActive)) m_CurrentCPD.setMaxActive(Integer.parseInt(maxActive));

                            String maxIdle = atts.getValue(tags.getTagById(CON_MAX_IDLE));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_IDLE) + ": " + maxIdle);
                            if (checkString(maxIdle)) m_CurrentCPD.setMaxIdle(Integer.parseInt(maxIdle));

                            String maxWait = atts.getValue(tags.getTagById(CON_MAX_WAIT));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_WAIT) + ": " + maxWait);
                            if (checkString(maxWait)) m_CurrentCPD.setMaxWait(Integer.parseInt(maxWait));

                            String minEvictableIdleTimeMillis = atts.getValue(tags.getTagById(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS) + ": " + minEvictableIdleTimeMillis);
                            if (checkString(minEvictableIdleTimeMillis)) m_CurrentCPD.setMinEvictableIdleTimeMillis(Long.parseLong(minEvictableIdleTimeMillis));

                            String numTestsPerEvictionRun = atts.getValue(tags.getTagById(CON_NUM_TESTS_PER_EVICTION_RUN));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_NUM_TESTS_PER_EVICTION_RUN) + ": " + numTestsPerEvictionRun);
                            if (checkString(numTestsPerEvictionRun)) m_CurrentCPD.setNumTestsPerEvictionRun(Integer.parseInt(numTestsPerEvictionRun));

                            String testOnBorrow = atts.getValue(tags.getTagById(CON_TEST_ON_BORROW));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_ON_BORROW) + ": " + testOnBorrow);
                            if (checkString(testOnBorrow)) m_CurrentCPD.setTestOnBorrow(Boolean.valueOf(testOnBorrow).booleanValue());

                            String testOnReturn = atts.getValue(tags.getTagById(CON_TEST_ON_RETURN));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_ON_RETURN) + ": " + testOnReturn);
                            if (checkString(testOnReturn)) m_CurrentCPD.setTestOnReturn(Boolean.valueOf(testOnReturn).booleanValue());

                            String testWhileIdle = atts.getValue(tags.getTagById(CON_TEST_WHILE_IDLE));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_WHILE_IDLE) + ": " + testWhileIdle);
                            if (checkString(testWhileIdle)) m_CurrentCPD.setTestWhileIdle(Boolean.valueOf(testWhileIdle).booleanValue());

                            String timeBetweenEvictionRunsMillis = atts.getValue(tags.getTagById(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS) + ": " + timeBetweenEvictionRunsMillis);
                            if (checkString(timeBetweenEvictionRunsMillis)) m_CurrentCPD.setTimeBetweenEvictionRunsMillis(Long.parseLong(timeBetweenEvictionRunsMillis));

                            String whenExhaustedAction = atts.getValue(tags.getTagById(CON_WHEN_EXHAUSTED_ACTION));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_WHEN_EXHAUSTED_ACTION) + ": " + whenExhaustedAction);
                            if (checkString(whenExhaustedAction)) m_CurrentCPD.setWhenExhaustedAction(Byte.parseByte(whenExhaustedAction));

                            String connectionFactoryStr = atts.getValue(tags.getTagById(CONNECTION_FACTORY));
                            if (isDebug) logger.debug("     " + tags.getTagById(CONNECTION_FACTORY) + ": " + connectionFactoryStr);
                            if (checkString(connectionFactoryStr)) m_CurrentCPD.setConnectionFactory(ClassHelper.getClass(connectionFactoryStr));

                            String validationQuery = atts.getValue(tags.getTagById(VALIDATION_QUERY));
                            if (isDebug) logger.debug("     " + tags.getTagById(VALIDATION_QUERY) + ": " + validationQuery);
                            if (checkString(validationQuery)) m_CurrentCPD.setValidationQuery(validationQuery);

                            
                            String logAbandoned = atts.getValue(tags.getTagById(CON_LOG_ABANDONED));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_LOG_ABANDONED) + ": " + logAbandoned);
                            if (checkString(logAbandoned)) m_CurrentCPD.setLogAbandoned(Boolean.valueOf(logAbandoned).booleanValue());

                            String removeAbandoned = atts.getValue(tags.getTagById(CON_REMOVE_ABANDONED));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_REMOVE_ABANDONED) + ": " + removeAbandoned);
                            if (checkString(removeAbandoned)) m_CurrentCPD.setRemoveAbandoned(Boolean.valueOf(removeAbandoned).booleanValue());

                            String removeAbandonedTimeout = atts.getValue(tags.getTagById(CON_REMOVE_ABANDONED_TIMEOUT));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_REMOVE_ABANDONED_TIMEOUT) + ": " + removeAbandonedTimeout);
                            if (checkString(removeAbandonedTimeout)) m_CurrentCPD.setRemoveAbandonedTimeout(Integer.parseInt(removeAbandonedTimeout));
                        }
                        break;
                    }

                case OBJECT_CACHE:
                    {
                        String className = atts.getValue(tags.getTagById(CLASS_NAME));
                        if(checkString(className) && m_CurrentJCD != null)
                        {
                            ObjectCacheDescriptor ocd = m_CurrentJCD.getObjectCacheDescriptor();
                            this.currentAttributeContainer = ocd;
                            ocd.setObjectCache(ClassHelper.getClass(className));
                            if (isDebug) logger.debug("    > " + tags.getTagById(OBJECT_CACHE));
                            if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + className);
                        }
                        break;
                    }
                case SEQUENCE_MANAGER:
                    {
                        String className = atts.getValue(tags.getTagById(SEQUENCE_MANAGER_CLASS));
                        if(checkString(className))
                        {
                            this.currentSequenceDescriptor = new SequenceDescriptor(this.m_CurrentJCD);
                            this.currentAttributeContainer = currentSequenceDescriptor;
                            this.m_CurrentJCD.setSequenceDescriptor(this.currentSequenceDescriptor);
                            if (isDebug) logger.debug("    > " + tags.getTagById(SEQUENCE_MANAGER));
                            if (isDebug) logger.debug("     " + tags.getTagById(SEQUENCE_MANAGER_CLASS) + ": " + className);
                            if (checkString(className)) currentSequenceDescriptor.setSequenceManagerClass(ClassHelper.getClass(className));
                        }
                        break;
                    }
                case ATTRIBUTE:
                    {
                        
                        String attributeName = atts.getValue(tags.getTagById(ATTRIBUTE_NAME));
                        String attributeValue = atts.getValue(tags.getTagById(ATTRIBUTE_VALUE));

                        
                        if (this.currentAttributeContainer != null)
                        {

                            if (checkString(attributeName))
                            {
                                if (isDebug) logger.debug("      > " + tags.getTagById(ATTRIBUTE));
                                if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_NAME) + ": " + attributeName
                                        + "  "+tags.getTagById(ATTRIBUTE_VALUE) + ": " + attributeValue);
                                this.currentAttributeContainer.addAttribute(attributeName, attributeValue);

                            }
                            else
                            {
                                logger.info("Found 'null' or 'empty' attribute object for element "+currentAttributeContainer.getClass() +
                                        " attribute-name=" + attributeName + ", attribute-value=" + attributeValue+
                                        " See jdbc-connection-descriptor with jcdAlias '"+m_CurrentJCD.getJcdAlias()+"'");
                            }
                        }






                        break;
                    }
                default :
                    {
                        
                    }
            }
        }
        catch (Exception ex)
        {
            logger.error(ex);
            throw new PersistenceBrokerException(ex);
        }
    }
  

  





  public static void main(String[] args) {
    method_2_ojb_1_0_4_claude handler = new method_2_ojb_1_0_4_claude();

    System.out.println("=== Scenario 1: jdbc-connection-descriptor + connection-pool + object-cache + sequence-manager ===");
    handler.startElement(null, "jdbc-connection-descriptor", "jdbc-connection-descriptor", attrs(
        "jcd-alias", "default", "default-connection", "true", "platform", "PostgreSQL",
        "driver", "org.postgresql.Driver", "protocol", "jdbc", "subprotocol", "postgresql",
        "dbalias", "//localhost/mydb", "username", "app", "password", "secret",
        "eager-release", "true", "batch-mode", "false", "useAutoCommit", "1",
        "ignoreAutoCommitExceptions", "false"));

    handler.startElement(null, "connection-pool", "connection-pool", attrs(
        "maxActive", "20", "maxIdle", "5", "validationQuery", "SELECT 1", "testOnBorrow", "true"));

    handler.startElement(null, "object-cache", "object-cache", attrs("class", "java.util.HashMap"));

    handler.startElement(null, "attribute", "attribute", attrs(
        "attribute-name", "cache.size", "attribute-value", "1000"));

    handler.startElement(null, "sequence-manager", "sequence-manager", attrs("className", "java.lang.Object"));

    JdbcConnectionDescriptor jcd = handler.conDesList.get(0);
    System.out.println("  " + jcd);
    System.out.println("  objectCache attributes: " + jcd.getObjectCacheDescriptor().attributes);
    System.out.println("  sequenceManagerClass: " + jcd.getSequenceDescriptor().getSequenceManagerClass());

    System.out.println();
    System.out.println("=== Scenario 2: duplicate default-connection (PersistenceBrokerException expected) ===");
    try {
      handler.startElement(null, "jdbc-connection-descriptor", "jdbc-connection-descriptor", attrs(
          "jcd-alias", "second", "default-connection", "true"));
      System.out.println("  ERROR: expected PersistenceBrokerException was not thrown");
    } catch (PersistenceBrokerException e) {
      System.out.println("  Caught expected PersistenceBrokerException wrapping: " + e.getCause());
    }
  }

  private static Attributes attrs(String... kv) {
    org.xml.sax.helpers.AttributesImpl impl = new org.xml.sax.helpers.AttributesImpl();
    for (int i = 0; i < kv.length; i += 2) {
      impl.addAttribute("", kv[i], kv[i], "CDATA", kv[i + 1]);
    }
    return impl;
  }
}




class MetadataException extends RuntimeException {
  MetadataException(String message) { super(message); }
  MetadataException(String message, Throwable cause) { super(message, cause); }
}



class Log {
  private final String name;
  Log(String name) { this.name = name; }
  boolean isDebugEnabled() { return false; }
  void debug(String msg) { System.out.println("[DEBUG] " + name + " - " + msg); }
  void error(String msg, Throwable t) {
    System.out.println("[ERROR] " + name + " - " + msg + ": " + t);
  }
  void error(Throwable t) {
    System.out.println("[ERROR] " + name + " - " + t);
  }
  void info(String msg) {
    System.out.println("[INFO] " + name + " - " + msg);
  }
}




abstract class DescriptorBase {
  final Map<String, String> attributes = new HashMap<>();
  void addAttribute(String name, String value) {
    attributes.put(name, value);
  }
}



class DescriptorRepository extends DescriptorBase {
  private int defaultIsolationLevel;
  private final Map<String, ClassDescriptor> classDescriptors = new HashMap<>();

  static String getVersion() { return "1.0"; }
  void setDefaultIsolationLevel(int level) { this.defaultIsolationLevel = level; }
  int getDefaultIsolationLevel() { return defaultIsolationLevel; }
  void put(String className, ClassDescriptor cld) { classDescriptors.put(className, cld); }
  ClassDescriptor get(String className) { return classDescriptors.get(className); }
}


class ClassDescriptor extends DescriptorBase {
  static final String DYNAMIC_STR = "dynamic";

  final DescriptorRepository repository;
  private int isolationLevel = -1;
  private Class<?> classOfObject;
  private String schema;
  private String proxyClassName;
  private int proxyPrefetchingLimit;
  private String tableName;
  private boolean isInterface;
  private String rowReader;
  private String superClass;
  private boolean acceptLocks;
  private String initializationMethod;
  private String factoryClass;
  private String factoryMethod;
  private boolean alwaysRefresh;
  private String persistentFieldClassName;
  private ObjectCacheDescriptor objectCacheDescriptor;
  private final List<String> extentClasses = new ArrayList<>();
  private final List<FieldDescriptor> fieldDescriptors = new ArrayList<>();
  private final List<ObjectReferenceDescriptor> referenceDescriptors = new ArrayList<>();
  private final List<CollectionDescriptor> collectionDescriptors = new ArrayList<>();

  ClassDescriptor(DescriptorRepository repository) { this.repository = repository; }

  void setIsolationLevel(int level) { this.isolationLevel = level; }
  int getIsolationLevel() { return isolationLevel; }
  void setClassOfObject(Class<?> clazz) { this.classOfObject = clazz; }
  Class<?> getClassOfObject() { return classOfObject; }
  String getClassNameOfObject() { return classOfObject == null ? null : classOfObject.getName(); }
  void setSchema(String schema) { this.schema = schema; }
  void setProxyClassName(String proxyClassName) { this.proxyClassName = proxyClassName; }
  String getProxyClassName() { return proxyClassName; }
  void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
  int getProxyPrefetchingLimit() { return proxyPrefetchingLimit; }
  void setTableName(String tableName) { this.tableName = tableName; }
  String getTableName() { return tableName; }
  void setIsInterface(boolean isInterface) { this.isInterface = isInterface; }
  void setRowReader(String rowReader) { this.rowReader = rowReader; }
  void setSuperClass(String superClass) { this.superClass = superClass; }
  void setAcceptLocks(boolean acceptLocks) { this.acceptLocks = acceptLocks; }
  void setInitializationMethod(String m) { this.initializationMethod = m; }
  void setFactoryClass(String factoryClass) { this.factoryClass = factoryClass; }
  void setFactoryMethod(String factoryMethod) { this.factoryMethod = factoryMethod; }
  void setAlwaysRefresh(boolean alwaysRefresh) { this.alwaysRefresh = alwaysRefresh; }
  void setPersistentFieldClassName(String name) { this.persistentFieldClassName = name; }
  String getPersistentFieldClassName() { return persistentFieldClassName; }
  void setObjectCacheDescriptor(ObjectCacheDescriptor ocd) { this.objectCacheDescriptor = ocd; }
  ObjectCacheDescriptor getObjectCacheDescriptor() { return objectCacheDescriptor; }
  void addExtentClass(String className) { extentClasses.add(className); }
  void addFieldDescriptor(FieldDescriptor fd) { fieldDescriptors.add(fd); }
  List<FieldDescriptor> getFieldDescriptors() { return fieldDescriptors; }
  void addObjectReferenceDescriptor(ObjectReferenceDescriptor ord) { referenceDescriptors.add(ord); }
  List<ObjectReferenceDescriptor> getObjectReferenceDescriptors() { return referenceDescriptors; }
  void addCollectionDescriptor(CollectionDescriptor cod) { collectionDescriptors.add(cod); }
  List<CollectionDescriptor> getCollectionDescriptors() { return collectionDescriptors; }

  @Override
  public String toString() {
    return "ClassDescriptor[" + getClassNameOfObject() + ", table=" + tableName
        + ", fields=" + fieldDescriptors.size() + ", refs=" + referenceDescriptors.size()
        + ", collections=" + collectionDescriptors.size() + ", extents=" + extentClasses
        + ", attributes=" + attributes + "]";
  }
}


class ObjectCacheDescriptor extends DescriptorBase {
  private Class<?> objectCache;
  void setObjectCache(Class<?> clazz) { this.objectCache = clazz; }
  Class<?> getObjectCache() { return objectCache; }
}



class PersistentField {
  final Class<?> declaringClass;
  final String fieldName;
  PersistentField(Class<?> declaringClass, String fieldName) {
    this.declaringClass = declaringClass;
    this.fieldName = fieldName;
  }
  @Override
  public String toString() {
    return (declaringClass == null ? "?" : declaringClass.getSimpleName()) + "." + fieldName;
  }
}



class PersistentFieldFactory {
  static PersistentField createPersistentField(String persistentFieldClassName, Class<?> clazz, String fieldName) {
    return new PersistentField(clazz, fieldName);
  }
}


class FieldDescriptor extends DescriptorBase {
  final ClassDescriptor classDescriptor;
  final int id;
  private String access;
  private PersistentField persistentField;
  private String columnName;
  private String columnType;
  private boolean primaryKey;
  private boolean required;
  private boolean indexed;
  private boolean autoIncrement;
  private String sequenceName;
  private boolean locking;
  private boolean updateLock;
  private String fieldConversionClassName;
  private int length;
  private boolean lengthSpecified;
  private int precision;
  private boolean precisionSpecified;
  private int scale;
  private boolean scaleSpecified;

  FieldDescriptor(ClassDescriptor classDescriptor, int id) {
    this.classDescriptor = classDescriptor;
    this.id = id;
  }

  void setAccess(String access) { this.access = access; }
  void setPersistentField(PersistentField pf) { this.persistentField = pf; }
  PersistentField getPersistentField() { return persistentField; }
  void setColumnName(String columnName) { this.columnName = columnName; }
  void setColumnType(String columnType) { this.columnType = columnType; }
  void setPrimaryKey(boolean primaryKey) { this.primaryKey = primaryKey; }
  void setRequired(boolean required) { this.required = required; }
  void setIndexed(boolean indexed) { this.indexed = indexed; }
  void setAutoIncrement(boolean autoIncrement) { this.autoIncrement = autoIncrement; }
  void setSequenceName(String sequenceName) { this.sequenceName = sequenceName; }
  void setLocking(boolean locking) { this.locking = locking; }
  void setUpdateLock(boolean updateLock) { this.updateLock = updateLock; }
  void setFieldConversionClassName(String c) { this.fieldConversionClassName = c; }
  void setLength(int length) { this.length = length; }
  void setLengthSpecified(boolean b) { this.lengthSpecified = b; }
  void setPrecision(int precision) { this.precision = precision; }
  void setPrecisionSpecified(boolean b) { this.precisionSpecified = b; }
  void setScale(int scale) { this.scale = scale; }
  void setScaleSpecified(boolean b) { this.scaleSpecified = b; }

  @Override
  public String toString() {
    return "FieldDescriptor[id=" + id + ", field=" + persistentField + ", column=" + columnName
        + ", type=" + columnType + ", pk=" + primaryKey + ", required=" + required
        + ", indexed=" + indexed + ", length=" + (lengthSpecified ? length : "-") + "]";
  }
}


class AnonymousFieldDescriptor extends FieldDescriptor {
  private String anonymousFieldName;

  AnonymousFieldDescriptor(ClassDescriptor cld, int id) { super(cld, id); }

  


  void setPersistentField(PersistentField pf, String fieldName) {
    this.anonymousFieldName = fieldName;
    if (pf != null) {
      setPersistentField(pf);
    }
  }

  String getAnonymousFieldName() { return anonymousFieldName; }
}


class ObjectReferenceDescriptor extends DescriptorBase {
  final ClassDescriptor classDescriptor;
  private PersistentField persistentField;
  private Class<?> itemClass;
  private boolean lazy;
  private int proxyPrefetchingLimit;
  private boolean refresh;
  private boolean cascadeRetrieve;
  private String cascadingStore;
  private String cascadingDelete;
  private boolean otmDependent;
  private final List<Object> foreignKeyFields = new ArrayList<>();

  ObjectReferenceDescriptor(ClassDescriptor classDescriptor) { this.classDescriptor = classDescriptor; }

  void setPersistentField(PersistentField pf) { this.persistentField = pf; }
  void setItemClass(Class<?> clazz) { this.itemClass = clazz; }
  Class<?> getItemClass() { return itemClass; }
  void setLazy(boolean lazy) { this.lazy = lazy; }
  void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
  void setRefresh(boolean refresh) { this.refresh = refresh; }
  void setCascadeRetrieve(boolean b) { this.cascadeRetrieve = b; }
  void setCascadingStore(String s) { this.cascadingStore = s; }
  void setCascadingDelete(String s) { this.cascadingDelete = s; }
  void setOtmDependent(boolean b) { this.otmDependent = b; }
  void addForeignKeyField(int fieldId) { foreignKeyFields.add(fieldId); }
  void addForeignKeyField(String fieldRef) { foreignKeyFields.add(fieldRef); }
  List<Object> getForeignKeyFields() { return foreignKeyFields; }

  @Override
  public String toString() {
    return "ObjectReferenceDescriptor[field=" + persistentField + ", itemClass=" + itemClass
        + ", lazy=" + lazy + ", fks=" + foreignKeyFields + "]";
  }
}


class SuperReferenceDescriptor extends ObjectReferenceDescriptor {
  static final String TAG_SUPER = "super";
  SuperReferenceDescriptor(ClassDescriptor cld) { super(cld); }
}


class CollectionDescriptor extends DescriptorBase {
  final ClassDescriptor classDescriptor;
  private PersistentField persistentField;
  private Class<?> collectionClass;
  private Class<?> itemClass;
  private String indirectionTable;
  private boolean lazy;
  private int proxyPrefetchingLimit;
  private boolean refresh;
  private boolean cascadeRetrieve;
  private String cascadingStore;
  private String cascadingDelete;
  private boolean otmDependent;
  private QueryCustomizer queryCustomizer;
  private final List<String[]> orderBy = new ArrayList<>();
  private final List<Object> foreignKeyFields = new ArrayList<>();
  private final List<String> fksToThisClass = new ArrayList<>();
  private final List<String> fksToItemClass = new ArrayList<>();

  CollectionDescriptor(ClassDescriptor classDescriptor) { this.classDescriptor = classDescriptor; }

  void setPersistentField(PersistentField pf) { this.persistentField = pf; }
  void setCollectionClass(Class<?> clazz) { this.collectionClass = clazz; }
  void setItemClass(Class<?> clazz) { this.itemClass = clazz; }
  void addOrderBy(String fieldName, boolean ascending) {
    orderBy.add(new String[] { fieldName, String.valueOf(ascending) });
  }
  void setIndirectionTable(String t) { this.indirectionTable = t; }
  void setLazy(boolean lazy) { this.lazy = lazy; }
  void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
  void setRefresh(boolean refresh) { this.refresh = refresh; }
  void setCascadeRetrieve(boolean b) { this.cascadeRetrieve = b; }
  void setCascadingStore(String s) { this.cascadingStore = s; }
  void setCascadingDelete(String s) { this.cascadingDelete = s; }
  void setOtmDependent(boolean b) { this.otmDependent = b; }
  void setQueryCustomizer(QueryCustomizer qc) { this.queryCustomizer = qc; }
  void addForeignKeyField(int fieldId) { foreignKeyFields.add(fieldId); }
  void addForeignKeyField(String fieldRef) { foreignKeyFields.add(fieldRef); }
  void addFkToThisClass(String column) { fksToThisClass.add(column); }
  void addFkToItemClass(String column) { fksToItemClass.add(column); }

  @Override
  public String toString() {
    return "CollectionDescriptor[field=" + persistentField + ", itemClass=" + itemClass
        + ", orderBy=" + orderBy + ", fks=" + foreignKeyFields
        + ", fksToThisClass=" + fksToThisClass + ", fksToItemClass=" + fksToItemClass + "]";
  }
}



interface QueryCustomizer {
}


class IndexDescriptor {
  private String name;
  private boolean unique;
  private final List<String> indexColumns = new ArrayList<>();

  void setName(String name) { this.name = name; }
  void setUnique(boolean unique) { this.unique = unique; }
  List<String> getIndexColumns() { return indexColumns; }

  @Override
  public String toString() {
    return "IndexDescriptor[name=" + name + ", unique=" + unique + ", columns=" + indexColumns + "]";
  }
}



abstract class ProcedureDescriptor {
  final ClassDescriptor classDescriptor;
  final String name;
  final boolean includeAllFields;
  private String returnValueFieldRef;
  final List<ArgumentDescriptor> arguments = new ArrayList<>();

  ProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAllFields) {
    this.classDescriptor = cld;
    this.name = name;
    this.includeAllFields = includeAllFields;
  }

  void setReturnValueFieldRef(String ref) { this.returnValueFieldRef = ref; }
  void addArgument(ArgumentDescriptor arg) { arguments.add(arg); }

  @Override
  public String toString() {
    return getClass().getSimpleName() + "[name=" + name + ", returnFieldRef=" + returnValueFieldRef
        + ", args=" + arguments + "]";
  }
}


class InsertProcedureDescriptor extends ProcedureDescriptor {
  InsertProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAllFields) {
    super(cld, name, includeAllFields);
  }
}


class UpdateProcedureDescriptor extends ProcedureDescriptor {
  UpdateProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAllFields) {
    super(cld, name, includeAllFields);
  }
}



class DeleteProcedureDescriptor extends ProcedureDescriptor {
  DeleteProcedureDescriptor(ClassDescriptor cld, String name, boolean includePkFieldsOnly) {
    super(cld, name, includePkFieldsOnly);
  }
}


class ArgumentDescriptor {
  final ProcedureDescriptor procedure;
  private String value;
  private boolean isFieldRef;
  private boolean returnValue;

  ArgumentDescriptor(ProcedureDescriptor procedure) { this.procedure = procedure; }

  void setValue(String value) {
    this.value = value;
    this.isFieldRef = false;
  }

  void setValue(String fieldRefName, boolean returnValue) {
    this.value = fieldRefName;
    this.isFieldRef = true;
    this.returnValue = returnValue;
  }

  @Override
  public String toString() {
    return (isFieldRef ? "fieldRef:" : "const:") + value + (returnValue ? "(return)" : "");
  }
}



class ClassHelper {
  static Class<?> getClass(String className) throws ClassNotFoundException {
    if (className == null) return null;
    switch (className) {
      case "java.lang.String": return String.class;
      case "java.lang.Integer": return Integer.class;
      default: return Class.forName(className);
    }
  }

  static Object newInstance(String className) {
    try {
      return Class.forName(className).getDeclaredConstructor().newInstance();
    } catch (Exception e) {
      throw new MetadataException("Could not instantiate " + className, e);
    }
  }
}




class LockHelper {
  static final int IL_READ_UNCOMMITTED = 0;
  static final int IL_READ_COMMITTED = 1;
  static final int IL_REPEATABLE_READ = 2;
  static final int IL_SERIALIZABLE = 3;
  static final int IL_OPTIMISTIC = 4;

  static int getIsolationLevelFor(String levelName) {
    if (levelName == null) return IL_READ_UNCOMMITTED;
    switch (levelName.trim().toLowerCase()) {
      case "read-uncommitted": return IL_READ_UNCOMMITTED;
      case "read-committed": return IL_READ_COMMITTED;
      case "repeatable-read": return IL_REPEATABLE_READ;
      case "serializable": return IL_SERIALIZABLE;
      case "optimistic": return IL_OPTIMISTIC;
      default: return IL_READ_UNCOMMITTED;
    }
  }
}



class RepositoryElements {
  static final String TAG_ACCESS_ANONYMOUS = "anonymous";
}


class JdbcConnectionDescriptor extends DescriptorBase {
  private String jcdAlias;
  private boolean defaultConnection;
  private String dbms;
  private String jdbcLevel;
  private String driver;
  private String protocol;
  private String subProtocol;
  private String dbAlias;
  private String datasourceName;
  private String userName;
  private String passWord;
  private boolean eagerRelease;
  private boolean batchMode;
  private int useAutoCommit;
  private boolean ignoreAutoCommitExceptions;
  private final ConnectionPoolDescriptor connectionPoolDescriptor = new ConnectionPoolDescriptor();
  private ObjectCacheDescriptor objectCacheDescriptor = new ObjectCacheDescriptor();
  private SequenceDescriptor sequenceDescriptor;

  String getJcdAlias() { return jcdAlias; }
  void setJcdAlias(String jcdAlias) { this.jcdAlias = jcdAlias; }
  boolean isDefaultConnection() { return defaultConnection; }
  void setDefaultConnection(boolean defaultConnection) { this.defaultConnection = defaultConnection; }
  void setDbms(String dbms) { this.dbms = dbms; }
  void setJdbcLevel(String jdbcLevel) { this.jdbcLevel = jdbcLevel; }
  void setDriver(String driver) { this.driver = driver; }
  void setProtocol(String protocol) { this.protocol = protocol; }
  void setSubProtocol(String subProtocol) { this.subProtocol = subProtocol; }
  void setDbAlias(String dbAlias) { this.dbAlias = dbAlias; }
  void setDatasourceName(String datasourceName) { this.datasourceName = datasourceName; }
  void setUserName(String userName) { this.userName = userName; }
  void setPassWord(String passWord) { this.passWord = passWord; }
  void setEagerRelease(boolean eagerRelease) { this.eagerRelease = eagerRelease; }
  void setBatchMode(boolean batchMode) { this.batchMode = batchMode; }
  void setUseAutoCommit(int useAutoCommit) { this.useAutoCommit = useAutoCommit; }
  void setIgnoreAutoCommitExceptions(boolean b) { this.ignoreAutoCommitExceptions = b; }
  ConnectionPoolDescriptor getConnectionPoolDescriptor() { return connectionPoolDescriptor; }
  void setObjectCacheDescriptor(ObjectCacheDescriptor ocd) { this.objectCacheDescriptor = ocd; }
  ObjectCacheDescriptor getObjectCacheDescriptor() { return objectCacheDescriptor; }
  void setSequenceDescriptor(SequenceDescriptor sd) { this.sequenceDescriptor = sd; }
  SequenceDescriptor getSequenceDescriptor() { return sequenceDescriptor; }

  @Override
  public String toString() {
    return "JdbcConnectionDescriptor[alias=" + jcdAlias + ", default=" + defaultConnection
        + ", dbms=" + dbms + ", driver=" + driver + ", user=" + userName
        + ", useAutoCommit=" + useAutoCommit + ", pool=" + connectionPoolDescriptor
        + ", attributes=" + attributes + "]";
  }
}


class ConnectionPoolDescriptor extends DescriptorBase {
  private int maxActive;
  private int maxIdle;
  private int maxWait;
  private long minEvictableIdleTimeMillis;
  private int numTestsPerEvictionRun;
  private boolean testOnBorrow;
  private boolean testOnReturn;
  private boolean testWhileIdle;
  private long timeBetweenEvictionRunsMillis;
  private byte whenExhaustedAction;
  private Class<?> connectionFactory;
  private String validationQuery;
  private boolean logAbandoned;
  private boolean removeAbandoned;
  private int removeAbandonedTimeout;

  void setMaxActive(int v) { this.maxActive = v; }
  void setMaxIdle(int v) { this.maxIdle = v; }
  void setMaxWait(int v) { this.maxWait = v; }
  void setMinEvictableIdleTimeMillis(long v) { this.minEvictableIdleTimeMillis = v; }
  void setNumTestsPerEvictionRun(int v) { this.numTestsPerEvictionRun = v; }
  void setTestOnBorrow(boolean v) { this.testOnBorrow = v; }
  void setTestOnReturn(boolean v) { this.testOnReturn = v; }
  void setTestWhileIdle(boolean v) { this.testWhileIdle = v; }
  void setTimeBetweenEvictionRunsMillis(long v) { this.timeBetweenEvictionRunsMillis = v; }
  void setWhenExhaustedAction(byte v) { this.whenExhaustedAction = v; }
  void setConnectionFactory(Class<?> v) { this.connectionFactory = v; }
  void setValidationQuery(String v) { this.validationQuery = v; }
  void setLogAbandoned(boolean v) { this.logAbandoned = v; }
  void setRemoveAbandoned(boolean v) { this.removeAbandoned = v; }
  void setRemoveAbandonedTimeout(int v) { this.removeAbandonedTimeout = v; }

  @Override
  public String toString() {
    return "Pool[maxActive=" + maxActive + ", maxIdle=" + maxIdle + ", maxWait=" + maxWait
        + ", testOnBorrow=" + testOnBorrow + ", validationQuery=" + validationQuery + "]";
  }
}


class SequenceDescriptor extends DescriptorBase {
  final JdbcConnectionDescriptor jcd;
  private Class<?> sequenceManagerClass;

  SequenceDescriptor(JdbcConnectionDescriptor jcd) { this.jcd = jcd; }

  void setSequenceManagerClass(Class<?> clazz) { this.sequenceManagerClass = clazz; }
  Class<?> getSequenceManagerClass() { return sequenceManagerClass; }

  @Override
  public String toString() {
    return "SequenceDescriptor[class=" + sequenceManagerClass + "]";
  }
}




class PersistenceBrokerException extends RuntimeException {
  PersistenceBrokerException(Throwable cause) { super(cause); }
  PersistenceBrokerException(String message) { super(message); }
}

interface TagIds {
  String TAG_SUPER = "super";

  static final int MAPPING_REPOSITORY = 1;
  static final int CLASS_DESCRIPTOR = 2;
  static final int OBJECT_CACHE = 3;
  static final int CLASS_EXTENT = 4;
  static final int FIELD_DESCRIPTOR = 5;
  static final int REFERENCE_DESCRIPTOR = 6;
  static final int FOREIGN_KEY = 7;
  static final int COLLECTION_DESCRIPTOR = 8;
  static final int ORDERBY = 9;
  static final int INVERSE_FK = 10;
  static final int FK_POINTING_TO_THIS_CLASS = 11;
  static final int FK_POINTING_TO_ITEMS_CLASS = 12;
  static final int ATTRIBUTE = 13;
  static final int QUERY_CUSTOMIZER = 14;
  static final int INDEX_DESCRIPTOR = 15;
  static final int INDEX_COLUMN = 16;
  static final int INSERT_PROCEDURE = 17;
  static final int UPDATE_PROCEDURE = 18;
  static final int DELETE_PROCEDURE = 19;
  static final int CONSTANT_ARGUMENT = 20;
  static final int RUNTIME_ARGUMENT = 21;
  static final int JDBC_CONNECTION_DESCRIPTOR = 22;
  static final int CONNECTION_POOL = 23;
  static final int SEQUENCE_MANAGER = 24;

  
  static final int ISOLATION_LEVEL = 100;
  static final int PROXY_PREFETCHING_LIMIT = 101;
  static final int REPOSITORY_VERSION = 102;
  static final int CLASS_NAME = 103;
  static final int SCHEMA_NAME = 104;
  static final int CLASS_PROXY = 105;
  static final int TABLE_NAME = 106;
  static final int ROW_READER = 107;
  static final int EXTENDS = 108;
  static final int ACCEPT_LOCKS = 109;
  static final int INITIALIZATION_METHOD = 110;
  static final int FACTORY_CLASS = 111;
  static final int FACTORY_METHOD = 112;
  static final int REFRESH = 113;
  static final int ID = 114;
  static final int ACCESS = 115;
  static final int FIELD_NAME = 116;
  static final int COLUMN_NAME = 117;
  static final int JDBC_TYPE = 118;
  static final int PRIMARY_KEY = 119;
  static final int NULLABLE = 120;
  static final int INDEXED = 121;
  static final int AUTO_INCREMENT = 122;
  static final int SEQUENCE_NAME = 123;
  static final int LOCKING = 124;
  static final int UPDATE_LOCK = 125;
  static final int FIELD_CONVERSION = 126;
  static final int LENGTH = 127;
  static final int PRECISION = 128;
  static final int SCALE = 129;
  static final int REFERENCED_CLASS = 130;
  static final int PROXY_REFERENCE = 131;
  static final int AUTO_RETRIEVE = 132;
  static final int AUTO_UPDATE = 133;
  static final int AUTO_DELETE = 134;
  static final int OTM_DEPENDENT = 135;
  static final int FIELD_ID_REF = 136;
  static final int FIELD_REF = 137;
  static final int COLLECTION_CLASS = 138;
  static final int ITEMS_CLASS = 139;
  static final int SORT = 140;
  static final int INDIRECTION_TABLE = 141;
  static final int ATTRIBUTE_NAME = 142;
  static final int ATTRIBUTE_VALUE = 143;
  static final int NAME = 144;
  static final int UNIQUE = 145;
  static final int INCLUDE_ALL_FIELDS = 146;
  static final int RETURN_FIELD_REF = 147;
  static final int VALUE = 148;
  static final int RETURN = 149;
  static final int INCLUDE_PK_FIELDS_ONLY = 150;
  static final int JCD_ALIAS = 151;
  static final int DEFAULT_CONNECTION = 152;
  static final int DBMS_NAME = 153;
  static final int JDBC_LEVEL = 154;
  static final int DRIVER_NAME = 155;
  static final int URL_PROTOCOL = 156;
  static final int URL_SUBPROTOCOL = 157;
  static final int URL_DBALIAS = 158;
  static final int DATASOURCE_NAME = 159;
  static final int USER_NAME = 160;
  static final int USER_PASSWD = 161;
  static final int EAGER_RELEASE = 162;
  static final int BATCH_MODE = 163;
  static final int USE_AUTOCOMMIT = 164;
  static final int IGNORE_AUTOCOMMIT_EXCEPTION = 165;
  static final int CON_MAX_ACTIVE = 166;
  static final int CON_MAX_IDLE = 167;
  static final int CON_MAX_WAIT = 168;
  static final int CON_MIN_EVICTABLE_IDLE_TIME_MILLIS = 169;
  static final int CON_NUM_TESTS_PER_EVICTION_RUN = 170;
  static final int CON_TEST_ON_BORROW = 171;
  static final int CON_TEST_ON_RETURN = 172;
  static final int CON_TEST_WHILE_IDLE = 173;
  static final int CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS = 174;
  static final int CON_WHEN_EXHAUSTED_ACTION = 175;
  static final int CONNECTION_FACTORY = 176;
  static final int VALIDATION_QUERY = 177;
  static final int CON_LOG_ABANDONED = 178;
  static final int CON_REMOVE_ABANDONED = 179;
  static final int CON_REMOVE_ABANDONED_TIMEOUT = 180;
  static final int SEQUENCE_MANAGER_CLASS = 181;

  }








class Tags implements TagIds {
  private static final Map<String, Integer> TAG_IDS_BY_ELEMENT_NAME = new HashMap<>();
  static {
    TAG_IDS_BY_ELEMENT_NAME.put("repository", MAPPING_REPOSITORY);
    TAG_IDS_BY_ELEMENT_NAME.put("class-descriptor", CLASS_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("object-cache", OBJECT_CACHE);
    TAG_IDS_BY_ELEMENT_NAME.put("class-extent", CLASS_EXTENT);
    TAG_IDS_BY_ELEMENT_NAME.put("field-descriptor", FIELD_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("reference-descriptor", REFERENCE_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("foreignkey", FOREIGN_KEY);
    TAG_IDS_BY_ELEMENT_NAME.put("collection-descriptor", COLLECTION_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("orderby", ORDERBY);
    TAG_IDS_BY_ELEMENT_NAME.put("inverse-foreignkey", INVERSE_FK);
    TAG_IDS_BY_ELEMENT_NAME.put("fk-pointing-to-this-class", FK_POINTING_TO_THIS_CLASS);
    TAG_IDS_BY_ELEMENT_NAME.put("fk-pointing-to-items-class", FK_POINTING_TO_ITEMS_CLASS);
    TAG_IDS_BY_ELEMENT_NAME.put("attribute", ATTRIBUTE);
    TAG_IDS_BY_ELEMENT_NAME.put("query-customizer", QUERY_CUSTOMIZER);
    TAG_IDS_BY_ELEMENT_NAME.put("index-descriptor", INDEX_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("index-column", INDEX_COLUMN);
    TAG_IDS_BY_ELEMENT_NAME.put("insert-procedure", INSERT_PROCEDURE);
    TAG_IDS_BY_ELEMENT_NAME.put("update-procedure", UPDATE_PROCEDURE);
    TAG_IDS_BY_ELEMENT_NAME.put("delete-procedure", DELETE_PROCEDURE);
    TAG_IDS_BY_ELEMENT_NAME.put("constant-argument", CONSTANT_ARGUMENT);
    TAG_IDS_BY_ELEMENT_NAME.put("runtime-argument", RUNTIME_ARGUMENT);
    TAG_IDS_BY_ELEMENT_NAME.put("jdbc-connection-descriptor", JDBC_CONNECTION_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("connection-pool", CONNECTION_POOL);
    TAG_IDS_BY_ELEMENT_NAME.put("sequence-manager", SEQUENCE_MANAGER);
    TAG_IDS_BY_ELEMENT_NAME.put("jdbc-connection-descriptor", JDBC_CONNECTION_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("connection-pool", CONNECTION_POOL);
    TAG_IDS_BY_ELEMENT_NAME.put("sequence-manager", SEQUENCE_MANAGER);
  }

  static int getLiteralId(String elementName) {
    Integer id = TAG_IDS_BY_ELEMENT_NAME.get(elementName);
    return id == null ? -1 : id;
  }

  private static final Map<Integer, String> ATTR_NAMES_BY_ID = new HashMap<>();
  static {
    ATTR_NAMES_BY_ID.put(ISOLATION_LEVEL, "isolation-level");
    ATTR_NAMES_BY_ID.put(PROXY_PREFETCHING_LIMIT, "proxy-prefetching-limit");
    ATTR_NAMES_BY_ID.put(REPOSITORY_VERSION, "version");
    ATTR_NAMES_BY_ID.put(CLASS_NAME, "class");
    ATTR_NAMES_BY_ID.put(SCHEMA_NAME, "schema");
    ATTR_NAMES_BY_ID.put(CLASS_PROXY, "proxy");
    ATTR_NAMES_BY_ID.put(TABLE_NAME, "table");
    ATTR_NAMES_BY_ID.put(ROW_READER, "row-reader");
    ATTR_NAMES_BY_ID.put(EXTENDS, "extends");
    ATTR_NAMES_BY_ID.put(ACCEPT_LOCKS, "accept-locks");
    ATTR_NAMES_BY_ID.put(INITIALIZATION_METHOD, "initialization-method");
    ATTR_NAMES_BY_ID.put(FACTORY_CLASS, "factory-class");
    ATTR_NAMES_BY_ID.put(FACTORY_METHOD, "factory-method");
    ATTR_NAMES_BY_ID.put(REFRESH, "refresh");
    ATTR_NAMES_BY_ID.put(ID, "id");
    ATTR_NAMES_BY_ID.put(ACCESS, "access");
    ATTR_NAMES_BY_ID.put(FIELD_NAME, "name");
    ATTR_NAMES_BY_ID.put(COLUMN_NAME, "column");
    ATTR_NAMES_BY_ID.put(JDBC_TYPE, "jdbc-type");
    ATTR_NAMES_BY_ID.put(PRIMARY_KEY, "primarykey");
    ATTR_NAMES_BY_ID.put(NULLABLE, "nullable");
    ATTR_NAMES_BY_ID.put(INDEXED, "indexed");
    ATTR_NAMES_BY_ID.put(AUTO_INCREMENT, "autoincrement");
    ATTR_NAMES_BY_ID.put(SEQUENCE_NAME, "sequence-name");
    ATTR_NAMES_BY_ID.put(LOCKING, "locking");
    ATTR_NAMES_BY_ID.put(UPDATE_LOCK, "update-lock");
    ATTR_NAMES_BY_ID.put(FIELD_CONVERSION, "conversion");
    ATTR_NAMES_BY_ID.put(LENGTH, "length");
    ATTR_NAMES_BY_ID.put(PRECISION, "precision");
    ATTR_NAMES_BY_ID.put(SCALE, "scale");
    ATTR_NAMES_BY_ID.put(REFERENCED_CLASS, "class-ref");
    ATTR_NAMES_BY_ID.put(PROXY_REFERENCE, "proxy");
    ATTR_NAMES_BY_ID.put(AUTO_RETRIEVE, "auto-retrieve");
    ATTR_NAMES_BY_ID.put(AUTO_UPDATE, "auto-update");
    ATTR_NAMES_BY_ID.put(AUTO_DELETE, "auto-delete");
    ATTR_NAMES_BY_ID.put(OTM_DEPENDENT, "otm-dependent");
    ATTR_NAMES_BY_ID.put(FIELD_ID_REF, "field-id-ref");
    ATTR_NAMES_BY_ID.put(FIELD_REF, "field-ref");
    ATTR_NAMES_BY_ID.put(COLLECTION_CLASS, "collection-class");
    ATTR_NAMES_BY_ID.put(ITEMS_CLASS, "element-class-ref");
    ATTR_NAMES_BY_ID.put(SORT, "sort");
    ATTR_NAMES_BY_ID.put(ORDERBY, "orderby");
    ATTR_NAMES_BY_ID.put(INDIRECTION_TABLE, "indirection-table");
    ATTR_NAMES_BY_ID.put(ATTRIBUTE_NAME, "attribute-name");
    ATTR_NAMES_BY_ID.put(ATTRIBUTE_VALUE, "attribute-value");
    ATTR_NAMES_BY_ID.put(NAME, "name");
    ATTR_NAMES_BY_ID.put(UNIQUE, "unique");
    ATTR_NAMES_BY_ID.put(INCLUDE_ALL_FIELDS, "include-all-fields");
    ATTR_NAMES_BY_ID.put(RETURN_FIELD_REF, "return-field-ref");
    ATTR_NAMES_BY_ID.put(VALUE, "value");
    ATTR_NAMES_BY_ID.put(RETURN, "return");
    ATTR_NAMES_BY_ID.put(INCLUDE_PK_FIELDS_ONLY, "include-pk-fields-only");
    ATTR_NAMES_BY_ID.put(JCD_ALIAS, "jcd-alias");
    ATTR_NAMES_BY_ID.put(DEFAULT_CONNECTION, "default-connection");
    ATTR_NAMES_BY_ID.put(DBMS_NAME, "platform");
    ATTR_NAMES_BY_ID.put(JDBC_LEVEL, "jdbc-level");
    ATTR_NAMES_BY_ID.put(DRIVER_NAME, "driver");
    ATTR_NAMES_BY_ID.put(URL_PROTOCOL, "protocol");
    ATTR_NAMES_BY_ID.put(URL_SUBPROTOCOL, "subprotocol");
    ATTR_NAMES_BY_ID.put(URL_DBALIAS, "dbalias");
    ATTR_NAMES_BY_ID.put(DATASOURCE_NAME, "datasource");
    ATTR_NAMES_BY_ID.put(USER_NAME, "username");
    ATTR_NAMES_BY_ID.put(USER_PASSWD, "password");
    ATTR_NAMES_BY_ID.put(EAGER_RELEASE, "eager-release");
    ATTR_NAMES_BY_ID.put(BATCH_MODE, "batch-mode");
    ATTR_NAMES_BY_ID.put(USE_AUTOCOMMIT, "useAutoCommit");
    ATTR_NAMES_BY_ID.put(IGNORE_AUTOCOMMIT_EXCEPTION, "ignoreAutoCommitExceptions");
    ATTR_NAMES_BY_ID.put(CON_MAX_ACTIVE, "maxActive");
    ATTR_NAMES_BY_ID.put(CON_MAX_IDLE, "maxIdle");
    ATTR_NAMES_BY_ID.put(CON_MAX_WAIT, "maxWait");
    ATTR_NAMES_BY_ID.put(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS, "minEvictableIdleTimeMillis");
    ATTR_NAMES_BY_ID.put(CON_NUM_TESTS_PER_EVICTION_RUN, "numTestsPerEvictionRun");
    ATTR_NAMES_BY_ID.put(CON_TEST_ON_BORROW, "testOnBorrow");
    ATTR_NAMES_BY_ID.put(CON_TEST_ON_RETURN, "testOnReturn");
    ATTR_NAMES_BY_ID.put(CON_TEST_WHILE_IDLE, "testWhileIdle");
    ATTR_NAMES_BY_ID.put(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS, "timeBetweenEvictionRunsMillis");
    ATTR_NAMES_BY_ID.put(CON_WHEN_EXHAUSTED_ACTION, "whenExhaustedAction");
    ATTR_NAMES_BY_ID.put(CONNECTION_FACTORY, "connectionFactory");
    ATTR_NAMES_BY_ID.put(VALIDATION_QUERY, "validationQuery");
    ATTR_NAMES_BY_ID.put(CON_LOG_ABANDONED, "logAbandoned");
    ATTR_NAMES_BY_ID.put(CON_REMOVE_ABANDONED, "removeAbandoned");
    ATTR_NAMES_BY_ID.put(CON_REMOVE_ABANDONED_TIMEOUT, "removeAbandonedTimeout");
    ATTR_NAMES_BY_ID.put(SEQUENCE_MANAGER_CLASS, "className");
    ATTR_NAMES_BY_ID.put(JCD_ALIAS, "jcd-alias");
    ATTR_NAMES_BY_ID.put(DEFAULT_CONNECTION, "default-connection");
    ATTR_NAMES_BY_ID.put(DBMS_NAME, "platform");
    ATTR_NAMES_BY_ID.put(JDBC_LEVEL, "jdbc-level");
    ATTR_NAMES_BY_ID.put(DRIVER_NAME, "driver");
    ATTR_NAMES_BY_ID.put(URL_PROTOCOL, "protocol");
    ATTR_NAMES_BY_ID.put(URL_SUBPROTOCOL, "subprotocol");
    ATTR_NAMES_BY_ID.put(URL_DBALIAS, "dbalias");
    ATTR_NAMES_BY_ID.put(DATASOURCE_NAME, "datasource");
    ATTR_NAMES_BY_ID.put(USER_NAME, "username");
    ATTR_NAMES_BY_ID.put(USER_PASSWD, "password");
    ATTR_NAMES_BY_ID.put(EAGER_RELEASE, "eager-release");
    ATTR_NAMES_BY_ID.put(BATCH_MODE, "batch-mode");
    ATTR_NAMES_BY_ID.put(USE_AUTOCOMMIT, "useAutoCommit");
    ATTR_NAMES_BY_ID.put(IGNORE_AUTOCOMMIT_EXCEPTION, "ignoreAutoCommitExceptions");
    ATTR_NAMES_BY_ID.put(CON_MAX_ACTIVE, "maxActive");
    ATTR_NAMES_BY_ID.put(CON_MAX_IDLE, "maxIdle");
    ATTR_NAMES_BY_ID.put(CON_MAX_WAIT, "maxWait");
    ATTR_NAMES_BY_ID.put(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS, "minEvictableIdleTimeMillis");
    ATTR_NAMES_BY_ID.put(CON_NUM_TESTS_PER_EVICTION_RUN, "numTestsPerEvictionRun");
    ATTR_NAMES_BY_ID.put(CON_TEST_ON_BORROW, "testOnBorrow");
    ATTR_NAMES_BY_ID.put(CON_TEST_ON_RETURN, "testOnReturn");
    ATTR_NAMES_BY_ID.put(CON_TEST_WHILE_IDLE, "testWhileIdle");
    ATTR_NAMES_BY_ID.put(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS, "timeBetweenEvictionRunsMillis");
    ATTR_NAMES_BY_ID.put(CON_WHEN_EXHAUSTED_ACTION, "whenExhaustedAction");
    ATTR_NAMES_BY_ID.put(CONNECTION_FACTORY, "connectionFactory");
    ATTR_NAMES_BY_ID.put(VALIDATION_QUERY, "validationQuery");
    ATTR_NAMES_BY_ID.put(CON_LOG_ABANDONED, "logAbandoned");
    ATTR_NAMES_BY_ID.put(CON_REMOVE_ABANDONED, "removeAbandoned");
    ATTR_NAMES_BY_ID.put(CON_REMOVE_ABANDONED_TIMEOUT, "removeAbandonedTimeout");
    ATTR_NAMES_BY_ID.put(SEQUENCE_MANAGER_CLASS, "className");
  }

  String getTagById(int id) {
    return ATTR_NAMES_BY_ID.get(id);
  }
}
