










































import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public class method_1_ojb_1_0_4_claude extends DefaultHandler implements TagIds {

  private final Log logger = new Log(method_1_ojb_1_0_4_claude.class.getName());
  private final Tags tags = new Tags();

  private final DescriptorRepository m_repository;
  private int defProxyPrefetchingLimit = 50;

  private DescriptorBase m_CurrentAttrContainer;
  private ClassDescriptor m_CurrentCLD;
  private FieldDescriptor m_CurrentFLD;
  private ObjectReferenceDescriptor m_CurrentORD;
  private CollectionDescriptor m_CurrentCOD;
  private IndexDescriptor m_CurrentIndexDescriptor;
  private ProcedureDescriptor m_CurrentProcedure;
  private int m_lastId;
  private String m_CurrentString;

  public method_1_ojb_1_0_4_claude(DescriptorRepository repository) {
    this.m_repository = repository;
  }

  private int getLiteralId(String qName) {
    return Tags.getLiteralId(qName);
  }

  private boolean checkString(String s) {
    return s != null && !s.trim().isEmpty();
  }

  
  public void startElement(String uri, String name, String qName, Attributes atts)
    {
        boolean isDebug = logger.isDebugEnabled();

        m_CurrentString = null;
        try
        {
            switch (getLiteralId(qName))
            {
                case MAPPING_REPOSITORY:
                    {
                        if (isDebug) logger.debug(" > " + tags.getTagById(MAPPING_REPOSITORY));
                        this.m_CurrentAttrContainer = m_repository;

                        String defIso = atts.getValue(tags.getTagById(ISOLATION_LEVEL));
                        this.m_repository.setDefaultIsolationLevel(LockHelper.getIsolationLevelFor(defIso));
                        if (isDebug) logger.debug("     " + tags.getTagById(ISOLATION_LEVEL) + ": " + defIso);


                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit != null)
                        {
                            defProxyPrefetchingLimit = Integer.parseInt(proxyPrefetchingLimit);
                        }

                        
                        String version = atts.getValue(tags.getTagById(REPOSITORY_VERSION));
                        if (DescriptorRepository.getVersion().equals(version))
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(REPOSITORY_VERSION) + ": " + version);
                        }
                        else
                        {
                            throw new MetadataException("Repository version does not match. expected " +
                                    DescriptorRepository.getVersion() + " but found: " +
                                    version+". Please update your repository.dtd and your repository.xml"+
                                    " version attribute entry");
                        }
                        break;
                    }
                case CLASS_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("  > " + tags.getTagById(CLASS_DESCRIPTOR));
                        m_CurrentCLD = new ClassDescriptor(m_repository);

                        
                        this.m_CurrentAttrContainer = this.m_CurrentCLD;

                        
                        String isoLevel = atts.getValue(tags.getTagById(ISOLATION_LEVEL));
                        if (isDebug) logger.debug("     " + tags.getTagById(ISOLATION_LEVEL) + ": " + isoLevel);
                        




                        if(checkString(isoLevel)) m_CurrentCLD.setIsolationLevel(LockHelper.getIsolationLevelFor(isoLevel));

                        
                        String classname = atts.getValue(tags.getTagById(CLASS_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + classname);
                        try
                        {
                            m_CurrentCLD.setClassOfObject(ClassHelper.getClass(classname));
                        }
                        catch (ClassNotFoundException e)
                        {
                            m_CurrentCLD = null;
                            throw new MetadataException("Class "+classname+" could not be found"
                                    +" in the classpath. This could cause unexpected behaviour of OJB,"+
                                    " please remove or comment out this class descriptor" +
                                    " in the repository.xml file.", e);
                        }

                        
                        String schema = atts.getValue(tags.getTagById(SCHEMA_NAME));
                        if (schema != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(SCHEMA_NAME) + ": " + schema);
                            m_CurrentCLD.setSchema(schema);
                        }

                        
                        String proxy = atts.getValue(tags.getTagById(CLASS_PROXY));
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_PROXY) + ": " + proxy);
                        if (checkString(proxy))
                        {
                            if (proxy.equalsIgnoreCase(ClassDescriptor.DYNAMIC_STR))
                            {
                                m_CurrentCLD.setProxyClassName(ClassDescriptor.DYNAMIC_STR);
                            }
                            else
                            {
                                m_CurrentCLD.setProxyClassName(proxy);
                            }
                        }

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentCLD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentCLD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String table = atts.getValue(tags.getTagById(TABLE_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(TABLE_NAME) + ": " + table);
                        m_CurrentCLD.setTableName(table);
                        if (table == null)
                        {
                            m_CurrentCLD.setIsInterface(true);
                        }

                        
                        String rowreader = atts.getValue(tags.getTagById(ROW_READER));
                        if (isDebug) logger.debug("     " + tags.getTagById(ROW_READER) + ": " + rowreader);
                        if (rowreader != null)
                        {
                            m_CurrentCLD.setRowReader(rowreader);
                        }

                        

                        String extendsAtt = atts.getValue(tags.getTagById(EXTENDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(EXTENDS) + ": " + extendsAtt);
                        if (checkString(extendsAtt))
                        {
                            m_CurrentCLD.setSuperClass(extendsAtt);
                        }

                        
                        String acceptLocks = atts.getValue(tags.getTagById(ACCEPT_LOCKS));
                        if (acceptLocks==null)
                            acceptLocks="true"; 
                        logger.debug("     " + tags.getTagById(ACCEPT_LOCKS) + ": " + acceptLocks);
                        if (isDebug) logger.debug("     " + tags.getTagById(ACCEPT_LOCKS) + ": " + acceptLocks);
                        boolean b = (Boolean.valueOf(acceptLocks)).booleanValue();
                        m_CurrentCLD.setAcceptLocks(b);

                        
                        String initializationMethod = atts.getValue(tags.getTagById(INITIALIZATION_METHOD));
                        if (isDebug) logger.debug("     " + tags.getTagById(INITIALIZATION_METHOD) + ": " + initializationMethod);
                        if (initializationMethod != null)
                        {
                            m_CurrentCLD.setInitializationMethod(initializationMethod);
                        }

                        
                        String factoryClass = atts.getValue(tags.getTagById(FACTORY_CLASS));
                        if (isDebug)
                            logger.debug("     " + tags.getTagById(FACTORY_CLASS) + ": " + factoryClass);
                        if (factoryClass != null)
                        {
                            m_CurrentCLD.setFactoryClass(factoryClass);
                        }

                        
                        String factoryMethod = atts.getValue(tags.getTagById(FACTORY_METHOD));
                        if (isDebug)
                            logger.debug("     " + tags.getTagById(FACTORY_METHOD) + ": " + factoryMethod);
                        if (factoryMethod != null)
                        {
                            m_CurrentCLD.setFactoryMethod(factoryMethod);
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentCLD.setAlwaysRefresh(b);

                        
                        
						String pfClassName = atts.getValue("persistent-field-class");
						if (isDebug) logger.debug("     persistent-field-class: " + pfClassName);
						m_CurrentCLD.setPersistentFieldClassName(pfClassName);

                        
                        m_repository.put(classname, m_CurrentCLD);
                        break;
                    }
                case OBJECT_CACHE:
                    {
                        
                        
                        if(m_CurrentCLD != null)
                        {
                            String className = atts.getValue(tags.getTagById(CLASS_NAME));
                            if(checkString(className))
                            {
                                if (isDebug) logger.debug("     > " + tags.getTagById(OBJECT_CACHE));
                                ObjectCacheDescriptor ocd = new ObjectCacheDescriptor();
                                this.m_CurrentAttrContainer = ocd;
                                ocd.setObjectCache(ClassHelper.getClass(className));
                                if(m_CurrentCLD != null)
                                {
                                    m_CurrentCLD.setObjectCacheDescriptor(ocd);
                                }
                                if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + className);
                            }
                        }
                        break;
                    }
                case CLASS_EXTENT:
                    {
                        String classname = atts.getValue("class-ref");
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_EXTENT) + ": " + classname);
                        m_CurrentCLD.addExtentClass(classname);
                        break;
                    }

                case FIELD_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FIELD_DESCRIPTOR));

                        String strId = atts.getValue(tags.getTagById(ID));
                        m_lastId = (strId == null ? m_lastId + 1 : Integer.parseInt(strId));

                        String strAccess = atts.getValue(tags.getTagById(ACCESS));

                        if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                        {
                            m_CurrentFLD = new AnonymousFieldDescriptor(m_CurrentCLD, m_lastId);
                        }
                        else
                        {
                            m_CurrentFLD = new FieldDescriptor(m_CurrentCLD, m_lastId);
                        }
                        m_CurrentFLD.setAccess(strAccess);
                        m_CurrentCLD.addFieldDescriptor(m_CurrentFLD);

                        
                        this.m_CurrentAttrContainer = this.m_CurrentFLD;

                        String fieldName = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + fieldName);

                        if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                        {
							AnonymousFieldDescriptor anonymous = (AnonymousFieldDescriptor) m_CurrentFLD;
                            anonymous.setPersistentField(null,fieldName);
                        }
                        else
                        {
                            String classname = m_CurrentCLD.getClassNameOfObject();
							PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),ClassHelper.getClass(classname),fieldName);
                            m_CurrentFLD.setPersistentField(pf);
                        }

                        String columnName = atts.getValue(tags.getTagById(COLUMN_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(COLUMN_NAME) + ": " + columnName);
                        m_CurrentFLD.setColumnName(columnName);

                        String jdbcType = atts.getValue(tags.getTagById(JDBC_TYPE));
                        if (isDebug) logger.debug("     " + tags.getTagById(JDBC_TYPE) + ": " + jdbcType);
                        m_CurrentFLD.setColumnType(jdbcType);

                        String primaryKey = atts.getValue(tags.getTagById(PRIMARY_KEY));
                        if (isDebug) logger.debug("     " + tags.getTagById(PRIMARY_KEY) + ": " + primaryKey);
                        boolean b = (Boolean.valueOf(primaryKey)).booleanValue();
                        m_CurrentFLD.setPrimaryKey(b);

                        String nullable = atts.getValue(tags.getTagById(NULLABLE));
                        if (nullable != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(NULLABLE) + ": " + nullable);
                            b = !(Boolean.valueOf(nullable)).booleanValue();
                            m_CurrentFLD.setRequired(b);
                        }

                        String indexed = atts.getValue(tags.getTagById(INDEXED));
                        if (isDebug) logger.debug("     " + tags.getTagById(INDEXED) + ": " + indexed);
                        b = (Boolean.valueOf(indexed)).booleanValue();
                        m_CurrentFLD.setIndexed(b);

                        String autoincrement = atts.getValue(tags.getTagById(AUTO_INCREMENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_INCREMENT) + ": " + autoincrement);
                        b = (Boolean.valueOf(autoincrement)).booleanValue();
                        m_CurrentFLD.setAutoIncrement(b);

                        String sequenceName = atts.getValue(tags.getTagById(SEQUENCE_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(SEQUENCE_NAME) + ": " + sequenceName);
                        m_CurrentFLD.setSequenceName(sequenceName);

                        String locking = atts.getValue(tags.getTagById(LOCKING));
                        if (isDebug) logger.debug("     " + tags.getTagById(LOCKING) + ": " + locking);
                        b = (Boolean.valueOf(locking)).booleanValue();
                        m_CurrentFLD.setLocking(b);

                        String updateLock = atts.getValue(tags.getTagById(UPDATE_LOCK));
                        if (isDebug) logger.debug("     " + tags.getTagById(UPDATE_LOCK) + ": " + updateLock);
                        if(checkString(updateLock))
                        {
                            b = (Boolean.valueOf(updateLock)).booleanValue();
                            m_CurrentFLD.setUpdateLock(b);
                        }

                        String fieldConversion = atts.getValue(tags.getTagById(FIELD_CONVERSION));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_CONVERSION) + ": " + fieldConversion);
                        if (fieldConversion != null)
                        {
                            m_CurrentFLD.setFieldConversionClassName(fieldConversion);
                        }

                        
                        String length = atts.getValue(tags.getTagById(LENGTH));
                        if (length != null)
                        {
                            int i = Integer.parseInt(length);
                            if (isDebug) logger.debug("     " + tags.getTagById(LENGTH) + ": " + i);
                            m_CurrentFLD.setLength(i);
                            m_CurrentFLD.setLengthSpecified(true);
                        }

                        
                        String precision = atts.getValue(tags.getTagById(PRECISION));
                        if (precision != null)
                        {
                            int i = Integer.parseInt(precision);
                            if (isDebug) logger.debug("     " + tags.getTagById(PRECISION) + ": " + i);
                            m_CurrentFLD.setPrecision(i);
                            m_CurrentFLD.setPrecisionSpecified(true);
                        }

                        
                        String scale = atts.getValue(tags.getTagById(SCALE));
                        if (scale != null)
                        {
                            int i = Integer.parseInt(scale);
                            if (isDebug) logger.debug("     " + tags.getTagById(SCALE) + ": " + i);
                            m_CurrentFLD.setScale(i);
                            m_CurrentFLD.setScaleSpecified(true);
                        }

                        break;
                    }

                case REFERENCE_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(REFERENCE_DESCRIPTOR));
                        
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);

                        
                        String classRef = atts.getValue(tags.getTagById(REFERENCED_CLASS));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFERENCED_CLASS) + ": " + classRef);

                        ObjectReferenceDescriptor ord;
                        if (name.equals(TAG_SUPER))
                        {
                            






                            ord = new SuperReferenceDescriptor(m_CurrentCLD);
                        }
                        else
                        {
                            ord = new ObjectReferenceDescriptor(m_CurrentCLD);
                            PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                            ord.setPersistentField(pf);
                        }
                        m_CurrentORD = ord;

                        
                        m_CurrentCLD.addObjectReferenceDescriptor(m_CurrentORD);
                        m_CurrentORD.setItemClass(ClassHelper.getClass(classRef));

                        
                        this.m_CurrentAttrContainer = m_CurrentORD;

                        
                        String proxy = atts.getValue(tags.getTagById(PROXY_REFERENCE));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_REFERENCE) + ": " + proxy);
                        boolean b = (Boolean.valueOf(proxy)).booleanValue();
                        m_CurrentORD.setLazy(b);

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentORD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentORD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentORD.setRefresh(b);

                        
                        String autoRetrieve = atts.getValue(tags.getTagById(AUTO_RETRIEVE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_RETRIEVE) + ": " + autoRetrieve);
                        b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                        m_CurrentORD.setCascadeRetrieve(b);

                        
                        String autoUpdate = atts.getValue(tags.getTagById(AUTO_UPDATE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_UPDATE) + ": " + autoUpdate);
                        if(autoUpdate != null)
                        {
                            m_CurrentORD.setCascadingStore(autoUpdate);
                        }

                        
                        String autoDelete = atts.getValue(tags.getTagById(AUTO_DELETE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_DELETE) + ": " + autoDelete);

                        if(autoDelete != null)
                        {
                            m_CurrentORD.setCascadingDelete(autoDelete);
                        }

                        
                        String otmDependent = atts.getValue(tags.getTagById(OTM_DEPENDENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(OTM_DEPENDENT) + ": " + otmDependent);
                        b = (Boolean.valueOf(otmDependent)).booleanValue();
                        m_CurrentORD.setOtmDependent(b);

                        break;
                    }

                case FOREIGN_KEY:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FOREIGN_KEY));
                        String fieldIdRef = atts.getValue(tags.getTagById(FIELD_ID_REF));

                        if (fieldIdRef != null)
                        {
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_ID_REF) + ": " + fieldIdRef);

                            try
                            {
                                int fieldId;
                                fieldId = Integer.parseInt(fieldIdRef);
                                m_CurrentORD.addForeignKeyField(fieldId);
                            }
                            catch (NumberFormatException rex)
                            {
                                throw new MetadataException(tags.getTagById(FIELD_ID_REF)
                                        + " attribute must be an int. Found: "
                                        + fieldIdRef + ". Please check your repository file.", rex);
                            }
                        }
                        else
                        {
                            String fieldRef = atts.getValue(tags.getTagById(FIELD_REF));
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_REF) + ": " + fieldRef);
                            m_CurrentORD.addForeignKeyField(fieldRef);
                        }
                        break;
                    }

                case COLLECTION_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(COLLECTION_DESCRIPTOR));
                        m_CurrentCOD = new CollectionDescriptor(m_CurrentCLD);


                        
                        this.m_CurrentAttrContainer = m_CurrentCOD;

                        
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);
						PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                        m_CurrentCOD.setPersistentField(pf);

                        
                        String collectionClassName = atts.getValue(tags.getTagById(COLLECTION_CLASS));
                        if (collectionClassName != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(COLLECTION_CLASS) + ": " + collectionClassName);
                            m_CurrentCOD.setCollectionClass(ClassHelper.getClass(collectionClassName));
                        }
                        
                        String elementClassRef = atts.getValue(tags.getTagById(ITEMS_CLASS));
                        if (isDebug) logger.debug("     " + tags.getTagById(ITEMS_CLASS) + ": " + elementClassRef);
                        if (elementClassRef != null)
                        {
                            m_CurrentCOD.setItemClass(ClassHelper.getClass(elementClassRef));
                        }

                        
                        String orderby = atts.getValue(tags.getTagById(ORDERBY));
                        String sort = atts.getValue(tags.getTagById(SORT));
                        if (isDebug) logger.debug("     " + tags.getTagById(SORT) + ": " + orderby + ", " + sort);
                        if (orderby != null)
                        {
                            m_CurrentCOD.addOrderBy(orderby, "ASC".equalsIgnoreCase(sort));
                        }

                        
                        String indirectionTable = atts.getValue(tags.getTagById(INDIRECTION_TABLE));
                        if (isDebug) logger.debug("     " + tags.getTagById(INDIRECTION_TABLE) + ": " + indirectionTable);
                        m_CurrentCOD.setIndirectionTable(indirectionTable);

                        
                        String proxy = atts.getValue(tags.getTagById(PROXY_REFERENCE));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_REFERENCE) + ": " + proxy);
                        boolean b = (Boolean.valueOf(proxy)).booleanValue();
                        m_CurrentCOD.setLazy(b);

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentCOD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentCOD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentCOD.setRefresh(b);

                        
                        String autoRetrieve = atts.getValue(tags.getTagById(AUTO_RETRIEVE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_RETRIEVE) + ": " + autoRetrieve);
                        b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                        m_CurrentCOD.setCascadeRetrieve(b);

                        
                        String autoUpdate = atts.getValue(tags.getTagById(AUTO_UPDATE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_UPDATE) + ": " + autoUpdate);
                        if(autoUpdate != null)
                        {
                            m_CurrentCOD.setCascadingStore(autoUpdate);
                        }

                        
                        String autoDelete = atts.getValue(tags.getTagById(AUTO_DELETE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_DELETE) + ": " + autoDelete);
                        if(autoDelete != null)
                        {
                            m_CurrentCOD.setCascadingDelete(autoDelete);
                        }

                        
                        String otmDependent = atts.getValue(tags.getTagById(OTM_DEPENDENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(OTM_DEPENDENT) + ": " + otmDependent);
                        b = (Boolean.valueOf(otmDependent)).booleanValue();
                        m_CurrentCOD.setOtmDependent(b);

                        m_CurrentCLD.addCollectionDescriptor(m_CurrentCOD);

                        break;
                    }
                case ORDERBY :
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(ORDERBY));
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);
                        String sort = atts.getValue(tags.getTagById(SORT));
                        if (isDebug) logger.debug("     " + tags.getTagById(SORT) + ": " + name + ", " + sort);

                        m_CurrentCOD.addOrderBy(name, "ASC".equalsIgnoreCase(sort));
                        break;
                    }
                case INVERSE_FK:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(INVERSE_FK));
                        String fieldIdRef = atts.getValue(tags.getTagById(FIELD_ID_REF));

                        if (fieldIdRef != null)
                        {
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_ID_REF) + ": " + fieldIdRef);

                            try
                            {
                                int fieldId;
                                fieldId = Integer.parseInt(fieldIdRef);
                                m_CurrentCOD.addForeignKeyField(fieldId);
                            }
                            catch (NumberFormatException rex)
                            {
                                throw new MetadataException(tags.getTagById(FIELD_ID_REF)
                                        + " attribute must be an int. Found: "
                                        + fieldIdRef + " Please check your repository file.", rex);
                            }
                        }
                        else
                        {
                            String fieldRef = atts.getValue(tags.getTagById(FIELD_REF));
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_REF) + ": " + fieldRef);
                            m_CurrentCOD.addForeignKeyField(fieldRef);
                        }
                        break;
                    }

                case FK_POINTING_TO_THIS_CLASS:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FK_POINTING_TO_THIS_CLASS));
                        String column = atts.getValue("column");
                        if (isDebug) logger.debug("      " + "column" + ": " + column);
                        m_CurrentCOD.addFkToThisClass(column);
                        break;
                    }

                case FK_POINTING_TO_ITEMS_CLASS:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FK_POINTING_TO_ITEMS_CLASS));
                        String column = atts.getValue("column");
                        if (isDebug) logger.debug("      " + "column" + ": " + column);
                        m_CurrentCOD.addFkToItemClass(column);
                        break;
                    }
                case ATTRIBUTE:
                    {
                        
                        String attributeName = atts.getValue(tags.getTagById(ATTRIBUTE_NAME));
                        String attributeValue = atts.getValue(tags.getTagById(ATTRIBUTE_VALUE));
                        
                        if (this.m_CurrentAttrContainer != null)
                        {
                            if (isDebug) logger.debug("      > " + tags.getTagById(ATTRIBUTE));
                            if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_NAME) + ": " + attributeName);
                            if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_VALUE) + ": " + attributeValue);
                            this.m_CurrentAttrContainer.addAttribute(attributeName, attributeValue);
                        }
                        else
                        {


                        }
                        break;
                    }









                    case QUERY_CUSTOMIZER:
                        {
                            
                            String className = atts.getValue("class");
                            QueryCustomizer queryCust;

                            if (className != null)
                            {
                                if (isDebug) logger.debug("     " + "class" + ": " + className);
                                queryCust = (QueryCustomizer)ClassHelper.newInstance(className);
                                m_CurrentAttrContainer = queryCust instanceof DescriptorBase ? (DescriptorBase) queryCust : m_CurrentAttrContainer;
                                m_CurrentCOD.setQueryCustomizer(queryCust);
                            }
                            break;
                        }
                    case INDEX_DESCRIPTOR:
                        {
                            m_CurrentIndexDescriptor = new IndexDescriptor();
                            m_CurrentIndexDescriptor.setName(atts.getValue(tags.getTagById(NAME)));
                            m_CurrentIndexDescriptor.setUnique(Boolean.valueOf(atts.getValue(tags.getTagById(UNIQUE))).booleanValue());
                            break;
                        }
                    case INDEX_COLUMN:
                        {
                            m_CurrentIndexDescriptor.getIndexColumns().add(atts.getValue(tags.getTagById(NAME)));
                            break;
                        }
                    case INSERT_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(INSERT_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllFields = atts.getValue(tags.getTagById(INCLUDE_ALL_FIELDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_ALL_FIELDS) +
                                                  ": " + includeAllFields);

                        
                        InsertProcedureDescriptor proc =
                            new InsertProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;
                    }
                case UPDATE_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(UPDATE_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllFields = atts.getValue(tags.getTagById(INCLUDE_ALL_FIELDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_ALL_FIELDS) +
                                                  ": " + includeAllFields);

                        
                        UpdateProcedureDescriptor proc =
                            new UpdateProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;
                    }
                case DELETE_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(DELETE_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllPkFields = atts.getValue(tags.getTagById(INCLUDE_PK_FIELDS_ONLY));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_PK_FIELDS_ONLY) +
                                                  ": " + includeAllPkFields);

                        
                        DeleteProcedureDescriptor proc =
                            new DeleteProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllPkFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;

                    }
                case CONSTANT_ARGUMENT:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(CONSTANT_ARGUMENT));
                        ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                        
                        String value = atts.getValue(tags.getTagById(VALUE));
                        if (isDebug) logger.debug("     " + tags.getTagById(VALUE) + ": " + value);

                        
                        arg.setValue(value);

                        
                        m_CurrentProcedure.addArgument(arg);
                        break;
                    }
                case RUNTIME_ARGUMENT:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(RUNTIME_ARGUMENT));
                        ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                        
                        String fieldRefName = atts.getValue(tags.getTagById(FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_REF) +
                                                  ": " + fieldRefName);

                        
                        String returnValue = atts.getValue(tags.getTagById(RETURN));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN) +
                                                  ": " + returnValue);

                        
                        if ((fieldRefName != null) && (fieldRefName.trim().length() != 0)) {
                            arg.setValue(fieldRefName,
                                         Boolean.valueOf(returnValue).booleanValue());
                        }

                        
                        m_CurrentProcedure.addArgument(arg);
                        break;
                    }

                default :
                    {
                        
                    }
            }
        }
        catch (Exception ex)
        {
            logger.error("Exception while read metadata", ex);
            if(ex instanceof MetadataException) throw (MetadataException)ex;
            else throw new MetadataException("Exception when reading metadata information,"+
                    " please check your repository.xml file", ex);
        }
    }
  

  









  public static void main(String[] args) {
    DescriptorRepository repo = new DescriptorRepository();
    method_1_ojb_1_0_4_claude handler = new method_1_ojb_1_0_4_claude(repo);

    System.out.println("=== Scenario 1: repository root + class-descriptor + fields + reference + collection ===");
    handler.startElement(null, "repository", "repository", attrs(
        "isolation-level", "read-committed",
        "proxy-prefetching-limit", "10",
        "version", DescriptorRepository.getVersion()));

    handler.startElement(null, "class-descriptor", "class-descriptor", attrs(
        "class", "java.lang.String",
        "table", "EXAMPLE_TABLE",
        "accept-locks", "true",
        "refresh", "false"));

    handler.startElement(null, "field-descriptor", "field-descriptor", attrs(
        "id", "1",
        "name", "value",
        "column", "VALUE_COL",
        "jdbc-type", "VARCHAR",
        "primarykey", "true",
        "indexed", "true",
        "length", "255"));

    handler.startElement(null, "field-descriptor", "field-descriptor", attrs(
        "access", "anonymous",
        "name", "hashValue",
        "column", "HASH_COL",
        "jdbc-type", "INTEGER"));

    handler.startElement(null, "reference-descriptor", "reference-descriptor", attrs(
        "name", "super",
        "proxy", "false",
        "refresh", "false"));

    handler.startElement(null, "foreignkey", "foreignkey", attrs("field-ref", "value"));

    handler.startElement(null, "collection-descriptor", "collection-descriptor", attrs(
        "name", "children",
        "collection-class", "java.util.ArrayList",
        "element-class-ref", "java.lang.String",
        "orderby", "name", "sort", "ASC"));

    handler.startElement(null, "inverse-foreignkey", "inverse-foreignkey", attrs("field-ref", "value"));

    handler.startElement(null, "attribute", "attribute", attrs(
        "attribute-name", "custom.marker", "attribute-value", "yes"));

    ClassDescriptor cld = repo.get("java.lang.String");
    System.out.println("  " + cld);
    for (FieldDescriptor fd : cld.getFieldDescriptors()) System.out.println("    " + fd);
    for (ObjectReferenceDescriptor ord : cld.getObjectReferenceDescriptors()) System.out.println("    " + ord);
    for (CollectionDescriptor cod : cld.getCollectionDescriptors()) System.out.println("    " + cod);

    System.out.println();
    System.out.println("=== Scenario 2: index-descriptor + index-column ===");
    handler.startElement(null, "index-descriptor", "index-descriptor", attrs("name", "IDX_VALUE", "unique", "true"));
    handler.startElement(null, "index-column", "index-column", attrs("name", "VALUE_COL"));
    System.out.println("  " + handler.m_CurrentIndexDescriptor);

    System.out.println();
    System.out.println("=== Scenario 3: insert-procedure + constant-argument + runtime-argument ===");
    handler.startElement(null, "insert-procedure", "insert-procedure", attrs(
        "name", "sp_insert_example", "include-all-fields", "true", "return-field-ref", "value"));
    handler.startElement(null, "constant-argument", "constant-argument", attrs("value", "42"));
    handler.startElement(null, "runtime-argument", "runtime-argument", attrs("field-ref", "value", "return", "false"));
    System.out.println("  " + handler.m_CurrentProcedure);

    System.out.println();
    System.out.println("=== Scenario 4: repository version mismatch (MetadataException expected) ===");
    try {
      handler.startElement(null, "repository", "repository", attrs("version", "999.0"));
      System.out.println("  ERROR: expected MetadataException was not thrown");
    } catch (MetadataException e) {
      System.out.println("  Caught expected MetadataException: " + e.getMessage());
    }
  }

  

  private static Attributes attrs(String... kv) {
    org.xml.sax.helpers.AttributesImpl impl = new org.xml.sax.helpers.AttributesImpl();
    for (int i = 0; i < kv.length; i += 2) {
      impl.addAttribute("", kv[i], kv[i], "CDATA", kv[i + 1]);
    }
    return impl;
  }
}




class MetadataException extends RuntimeException {
  MetadataException(String message) { super(message); }
  MetadataException(String message, Throwable cause) { super(message, cause); }
}



class Log {
  private final String name;
  Log(String name) { this.name = name; }
  boolean isDebugEnabled() { return false; }
  void debug(String msg) { System.out.println("[DEBUG] " + name + " - " + msg); }
  void error(String msg, Throwable t) {
    System.out.println("[ERROR] " + name + " - " + msg + ": " + t);
  }
  void error(Throwable t) {
    System.out.println("[ERROR] " + name + " - " + t);
  }
  void info(String msg) {
    System.out.println("[INFO] " + name + " - " + msg);
  }
}




abstract class DescriptorBase {
  final Map<String, String> attributes = new HashMap<>();
  void addAttribute(String name, String value) {
    attributes.put(name, value);
  }
}



class DescriptorRepository extends DescriptorBase {
  private int defaultIsolationLevel;
  private final Map<String, ClassDescriptor> classDescriptors = new HashMap<>();

  static String getVersion() { return "1.0"; }
  void setDefaultIsolationLevel(int level) { this.defaultIsolationLevel = level; }
  int getDefaultIsolationLevel() { return defaultIsolationLevel; }
  void put(String className, ClassDescriptor cld) { classDescriptors.put(className, cld); }
  ClassDescriptor get(String className) { return classDescriptors.get(className); }
}


class ClassDescriptor extends DescriptorBase {
  static final String DYNAMIC_STR = "dynamic";

  final DescriptorRepository repository;
  private int isolationLevel = -1;
  private Class<?> classOfObject;
  private String schema;
  private String proxyClassName;
  private int proxyPrefetchingLimit;
  private String tableName;
  private boolean isInterface;
  private String rowReader;
  private String superClass;
  private boolean acceptLocks;
  private String initializationMethod;
  private String factoryClass;
  private String factoryMethod;
  private boolean alwaysRefresh;
  private String persistentFieldClassName;
  private ObjectCacheDescriptor objectCacheDescriptor;
  private final List<String> extentClasses = new ArrayList<>();
  private final List<FieldDescriptor> fieldDescriptors = new ArrayList<>();
  private final List<ObjectReferenceDescriptor> referenceDescriptors = new ArrayList<>();
  private final List<CollectionDescriptor> collectionDescriptors = new ArrayList<>();

  ClassDescriptor(DescriptorRepository repository) { this.repository = repository; }

  void setIsolationLevel(int level) { this.isolationLevel = level; }
  int getIsolationLevel() { return isolationLevel; }
  void setClassOfObject(Class<?> clazz) { this.classOfObject = clazz; }
  Class<?> getClassOfObject() { return classOfObject; }
  String getClassNameOfObject() { return classOfObject == null ? null : classOfObject.getName(); }
  void setSchema(String schema) { this.schema = schema; }
  void setProxyClassName(String proxyClassName) { this.proxyClassName = proxyClassName; }
  String getProxyClassName() { return proxyClassName; }
  void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
  int getProxyPrefetchingLimit() { return proxyPrefetchingLimit; }
  void setTableName(String tableName) { this.tableName = tableName; }
  String getTableName() { return tableName; }
  void setIsInterface(boolean isInterface) { this.isInterface = isInterface; }
  void setRowReader(String rowReader) { this.rowReader = rowReader; }
  void setSuperClass(String superClass) { this.superClass = superClass; }
  void setAcceptLocks(boolean acceptLocks) { this.acceptLocks = acceptLocks; }
  void setInitializationMethod(String m) { this.initializationMethod = m; }
  void setFactoryClass(String factoryClass) { this.factoryClass = factoryClass; }
  void setFactoryMethod(String factoryMethod) { this.factoryMethod = factoryMethod; }
  void setAlwaysRefresh(boolean alwaysRefresh) { this.alwaysRefresh = alwaysRefresh; }
  void setPersistentFieldClassName(String name) { this.persistentFieldClassName = name; }
  String getPersistentFieldClassName() { return persistentFieldClassName; }
  void setObjectCacheDescriptor(ObjectCacheDescriptor ocd) { this.objectCacheDescriptor = ocd; }
  ObjectCacheDescriptor getObjectCacheDescriptor() { return objectCacheDescriptor; }
  void addExtentClass(String className) { extentClasses.add(className); }
  void addFieldDescriptor(FieldDescriptor fd) { fieldDescriptors.add(fd); }
  List<FieldDescriptor> getFieldDescriptors() { return fieldDescriptors; }
  void addObjectReferenceDescriptor(ObjectReferenceDescriptor ord) { referenceDescriptors.add(ord); }
  List<ObjectReferenceDescriptor> getObjectReferenceDescriptors() { return referenceDescriptors; }
  void addCollectionDescriptor(CollectionDescriptor cod) { collectionDescriptors.add(cod); }
  List<CollectionDescriptor> getCollectionDescriptors() { return collectionDescriptors; }

  @Override
  public String toString() {
    return "ClassDescriptor[" + getClassNameOfObject() + ", table=" + tableName
        + ", fields=" + fieldDescriptors.size() + ", refs=" + referenceDescriptors.size()
        + ", collections=" + collectionDescriptors.size() + ", extents=" + extentClasses
        + ", attributes=" + attributes + "]";
  }
}


class ObjectCacheDescriptor extends DescriptorBase {
  private Class<?> objectCache;
  void setObjectCache(Class<?> clazz) { this.objectCache = clazz; }
  Class<?> getObjectCache() { return objectCache; }
}



class PersistentField {
  final Class<?> declaringClass;
  final String fieldName;
  PersistentField(Class<?> declaringClass, String fieldName) {
    this.declaringClass = declaringClass;
    this.fieldName = fieldName;
  }
  @Override
  public String toString() {
    return (declaringClass == null ? "?" : declaringClass.getSimpleName()) + "." + fieldName;
  }
}



class PersistentFieldFactory {
  static PersistentField createPersistentField(String persistentFieldClassName, Class<?> clazz, String fieldName) {
    return new PersistentField(clazz, fieldName);
  }
}


class FieldDescriptor extends DescriptorBase {
  final ClassDescriptor classDescriptor;
  final int id;
  private String access;
  private PersistentField persistentField;
  private String columnName;
  private String columnType;
  private boolean primaryKey;
  private boolean required;
  private boolean indexed;
  private boolean autoIncrement;
  private String sequenceName;
  private boolean locking;
  private boolean updateLock;
  private String fieldConversionClassName;
  private int length;
  private boolean lengthSpecified;
  private int precision;
  private boolean precisionSpecified;
  private int scale;
  private boolean scaleSpecified;

  FieldDescriptor(ClassDescriptor classDescriptor, int id) {
    this.classDescriptor = classDescriptor;
    this.id = id;
  }

  void setAccess(String access) { this.access = access; }
  void setPersistentField(PersistentField pf) { this.persistentField = pf; }
  PersistentField getPersistentField() { return persistentField; }
  void setColumnName(String columnName) { this.columnName = columnName; }
  void setColumnType(String columnType) { this.columnType = columnType; }
  void setPrimaryKey(boolean primaryKey) { this.primaryKey = primaryKey; }
  void setRequired(boolean required) { this.required = required; }
  void setIndexed(boolean indexed) { this.indexed = indexed; }
  void setAutoIncrement(boolean autoIncrement) { this.autoIncrement = autoIncrement; }
  void setSequenceName(String sequenceName) { this.sequenceName = sequenceName; }
  void setLocking(boolean locking) { this.locking = locking; }
  void setUpdateLock(boolean updateLock) { this.updateLock = updateLock; }
  void setFieldConversionClassName(String c) { this.fieldConversionClassName = c; }
  void setLength(int length) { this.length = length; }
  void setLengthSpecified(boolean b) { this.lengthSpecified = b; }
  void setPrecision(int precision) { this.precision = precision; }
  void setPrecisionSpecified(boolean b) { this.precisionSpecified = b; }
  void setScale(int scale) { this.scale = scale; }
  void setScaleSpecified(boolean b) { this.scaleSpecified = b; }

  @Override
  public String toString() {
    return "FieldDescriptor[id=" + id + ", field=" + persistentField + ", column=" + columnName
        + ", type=" + columnType + ", pk=" + primaryKey + ", required=" + required
        + ", indexed=" + indexed + ", length=" + (lengthSpecified ? length : "-") + "]";
  }
}


class AnonymousFieldDescriptor extends FieldDescriptor {
  private String anonymousFieldName;

  AnonymousFieldDescriptor(ClassDescriptor cld, int id) { super(cld, id); }

  


  void setPersistentField(PersistentField pf, String fieldName) {
    this.anonymousFieldName = fieldName;
    if (pf != null) {
      setPersistentField(pf);
    }
  }

  String getAnonymousFieldName() { return anonymousFieldName; }
}


class ObjectReferenceDescriptor extends DescriptorBase {
  final ClassDescriptor classDescriptor;
  private PersistentField persistentField;
  private Class<?> itemClass;
  private boolean lazy;
  private int proxyPrefetchingLimit;
  private boolean refresh;
  private boolean cascadeRetrieve;
  private String cascadingStore;
  private String cascadingDelete;
  private boolean otmDependent;
  private final List<Object> foreignKeyFields = new ArrayList<>();

  ObjectReferenceDescriptor(ClassDescriptor classDescriptor) { this.classDescriptor = classDescriptor; }

  void setPersistentField(PersistentField pf) { this.persistentField = pf; }
  void setItemClass(Class<?> clazz) { this.itemClass = clazz; }
  Class<?> getItemClass() { return itemClass; }
  void setLazy(boolean lazy) { this.lazy = lazy; }
  void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
  void setRefresh(boolean refresh) { this.refresh = refresh; }
  void setCascadeRetrieve(boolean b) { this.cascadeRetrieve = b; }
  void setCascadingStore(String s) { this.cascadingStore = s; }
  void setCascadingDelete(String s) { this.cascadingDelete = s; }
  void setOtmDependent(boolean b) { this.otmDependent = b; }
  void addForeignKeyField(int fieldId) { foreignKeyFields.add(fieldId); }
  void addForeignKeyField(String fieldRef) { foreignKeyFields.add(fieldRef); }
  List<Object> getForeignKeyFields() { return foreignKeyFields; }

  @Override
  public String toString() {
    return "ObjectReferenceDescriptor[field=" + persistentField + ", itemClass=" + itemClass
        + ", lazy=" + lazy + ", fks=" + foreignKeyFields + "]";
  }
}


class SuperReferenceDescriptor extends ObjectReferenceDescriptor {
  static final String TAG_SUPER = "super";
  SuperReferenceDescriptor(ClassDescriptor cld) { super(cld); }
}


class CollectionDescriptor extends DescriptorBase {
  final ClassDescriptor classDescriptor;
  private PersistentField persistentField;
  private Class<?> collectionClass;
  private Class<?> itemClass;
  private String indirectionTable;
  private boolean lazy;
  private int proxyPrefetchingLimit;
  private boolean refresh;
  private boolean cascadeRetrieve;
  private String cascadingStore;
  private String cascadingDelete;
  private boolean otmDependent;
  private QueryCustomizer queryCustomizer;
  private final List<String[]> orderBy = new ArrayList<>();
  private final List<Object> foreignKeyFields = new ArrayList<>();
  private final List<String> fksToThisClass = new ArrayList<>();
  private final List<String> fksToItemClass = new ArrayList<>();

  CollectionDescriptor(ClassDescriptor classDescriptor) { this.classDescriptor = classDescriptor; }

  void setPersistentField(PersistentField pf) { this.persistentField = pf; }
  void setCollectionClass(Class<?> clazz) { this.collectionClass = clazz; }
  void setItemClass(Class<?> clazz) { this.itemClass = clazz; }
  void addOrderBy(String fieldName, boolean ascending) {
    orderBy.add(new String[] { fieldName, String.valueOf(ascending) });
  }
  void setIndirectionTable(String t) { this.indirectionTable = t; }
  void setLazy(boolean lazy) { this.lazy = lazy; }
  void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
  void setRefresh(boolean refresh) { this.refresh = refresh; }
  void setCascadeRetrieve(boolean b) { this.cascadeRetrieve = b; }
  void setCascadingStore(String s) { this.cascadingStore = s; }
  void setCascadingDelete(String s) { this.cascadingDelete = s; }
  void setOtmDependent(boolean b) { this.otmDependent = b; }
  void setQueryCustomizer(QueryCustomizer qc) { this.queryCustomizer = qc; }
  void addForeignKeyField(int fieldId) { foreignKeyFields.add(fieldId); }
  void addForeignKeyField(String fieldRef) { foreignKeyFields.add(fieldRef); }
  void addFkToThisClass(String column) { fksToThisClass.add(column); }
  void addFkToItemClass(String column) { fksToItemClass.add(column); }

  @Override
  public String toString() {
    return "CollectionDescriptor[field=" + persistentField + ", itemClass=" + itemClass
        + ", orderBy=" + orderBy + ", fks=" + foreignKeyFields
        + ", fksToThisClass=" + fksToThisClass + ", fksToItemClass=" + fksToItemClass + "]";
  }
}



interface QueryCustomizer {
}


class IndexDescriptor {
  private String name;
  private boolean unique;
  private final List<String> indexColumns = new ArrayList<>();

  void setName(String name) { this.name = name; }
  void setUnique(boolean unique) { this.unique = unique; }
  List<String> getIndexColumns() { return indexColumns; }

  @Override
  public String toString() {
    return "IndexDescriptor[name=" + name + ", unique=" + unique + ", columns=" + indexColumns + "]";
  }
}



abstract class ProcedureDescriptor {
  final ClassDescriptor classDescriptor;
  final String name;
  final boolean includeAllFields;
  private String returnValueFieldRef;
  final List<ArgumentDescriptor> arguments = new ArrayList<>();

  ProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAllFields) {
    this.classDescriptor = cld;
    this.name = name;
    this.includeAllFields = includeAllFields;
  }

  void setReturnValueFieldRef(String ref) { this.returnValueFieldRef = ref; }
  void addArgument(ArgumentDescriptor arg) { arguments.add(arg); }

  @Override
  public String toString() {
    return getClass().getSimpleName() + "[name=" + name + ", returnFieldRef=" + returnValueFieldRef
        + ", args=" + arguments + "]";
  }
}


class InsertProcedureDescriptor extends ProcedureDescriptor {
  InsertProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAllFields) {
    super(cld, name, includeAllFields);
  }
}


class UpdateProcedureDescriptor extends ProcedureDescriptor {
  UpdateProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAllFields) {
    super(cld, name, includeAllFields);
  }
}



class DeleteProcedureDescriptor extends ProcedureDescriptor {
  DeleteProcedureDescriptor(ClassDescriptor cld, String name, boolean includePkFieldsOnly) {
    super(cld, name, includePkFieldsOnly);
  }
}


class ArgumentDescriptor {
  final ProcedureDescriptor procedure;
  private String value;
  private boolean isFieldRef;
  private boolean returnValue;

  ArgumentDescriptor(ProcedureDescriptor procedure) { this.procedure = procedure; }

  void setValue(String value) {
    this.value = value;
    this.isFieldRef = false;
  }

  void setValue(String fieldRefName, boolean returnValue) {
    this.value = fieldRefName;
    this.isFieldRef = true;
    this.returnValue = returnValue;
  }

  @Override
  public String toString() {
    return (isFieldRef ? "fieldRef:" : "const:") + value + (returnValue ? "(return)" : "");
  }
}



class ClassHelper {
  static Class<?> getClass(String className) throws ClassNotFoundException {
    if (className == null) return null;
    switch (className) {
      case "java.lang.String": return String.class;
      case "java.lang.Integer": return Integer.class;
      default: return Class.forName(className);
    }
  }

  static Object newInstance(String className) {
    try {
      return Class.forName(className).getDeclaredConstructor().newInstance();
    } catch (Exception e) {
      throw new MetadataException("Could not instantiate " + className, e);
    }
  }
}




class LockHelper {
  static final int IL_READ_UNCOMMITTED = 0;
  static final int IL_READ_COMMITTED = 1;
  static final int IL_REPEATABLE_READ = 2;
  static final int IL_SERIALIZABLE = 3;
  static final int IL_OPTIMISTIC = 4;

  static int getIsolationLevelFor(String levelName) {
    if (levelName == null) return IL_READ_UNCOMMITTED;
    switch (levelName.trim().toLowerCase()) {
      case "read-uncommitted": return IL_READ_UNCOMMITTED;
      case "read-committed": return IL_READ_COMMITTED;
      case "repeatable-read": return IL_REPEATABLE_READ;
      case "serializable": return IL_SERIALIZABLE;
      case "optimistic": return IL_OPTIMISTIC;
      default: return IL_READ_UNCOMMITTED;
    }
  }
}



class RepositoryElements {
  static final String TAG_ACCESS_ANONYMOUS = "anonymous";
}


class JdbcConnectionDescriptor extends DescriptorBase {
  private String jcdAlias;
  private boolean defaultConnection;
  private String dbms;
  private String jdbcLevel;
  private String driver;
  private String protocol;
  private String subProtocol;
  private String dbAlias;
  private String datasourceName;
  private String userName;
  private String passWord;
  private boolean eagerRelease;
  private boolean batchMode;
  private int useAutoCommit;
  private boolean ignoreAutoCommitExceptions;
  private final ConnectionPoolDescriptor connectionPoolDescriptor = new ConnectionPoolDescriptor();
  private ObjectCacheDescriptor objectCacheDescriptor = new ObjectCacheDescriptor();
  private SequenceDescriptor sequenceDescriptor;

  String getJcdAlias() { return jcdAlias; }
  void setJcdAlias(String jcdAlias) { this.jcdAlias = jcdAlias; }
  boolean isDefaultConnection() { return defaultConnection; }
  void setDefaultConnection(boolean defaultConnection) { this.defaultConnection = defaultConnection; }
  void setDbms(String dbms) { this.dbms = dbms; }
  void setJdbcLevel(String jdbcLevel) { this.jdbcLevel = jdbcLevel; }
  void setDriver(String driver) { this.driver = driver; }
  void setProtocol(String protocol) { this.protocol = protocol; }
  void setSubProtocol(String subProtocol) { this.subProtocol = subProtocol; }
  void setDbAlias(String dbAlias) { this.dbAlias = dbAlias; }
  void setDatasourceName(String datasourceName) { this.datasourceName = datasourceName; }
  void setUserName(String userName) { this.userName = userName; }
  void setPassWord(String passWord) { this.passWord = passWord; }
  void setEagerRelease(boolean eagerRelease) { this.eagerRelease = eagerRelease; }
  void setBatchMode(boolean batchMode) { this.batchMode = batchMode; }
  void setUseAutoCommit(int useAutoCommit) { this.useAutoCommit = useAutoCommit; }
  void setIgnoreAutoCommitExceptions(boolean b) { this.ignoreAutoCommitExceptions = b; }
  ConnectionPoolDescriptor getConnectionPoolDescriptor() { return connectionPoolDescriptor; }
  void setObjectCacheDescriptor(ObjectCacheDescriptor ocd) { this.objectCacheDescriptor = ocd; }
  ObjectCacheDescriptor getObjectCacheDescriptor() { return objectCacheDescriptor; }
  void setSequenceDescriptor(SequenceDescriptor sd) { this.sequenceDescriptor = sd; }
  SequenceDescriptor getSequenceDescriptor() { return sequenceDescriptor; }

  @Override
  public String toString() {
    return "JdbcConnectionDescriptor[alias=" + jcdAlias + ", default=" + defaultConnection
        + ", dbms=" + dbms + ", driver=" + driver + ", user=" + userName
        + ", useAutoCommit=" + useAutoCommit + ", pool=" + connectionPoolDescriptor
        + ", attributes=" + attributes + "]";
  }
}


class ConnectionPoolDescriptor extends DescriptorBase {
  private int maxActive;
  private int maxIdle;
  private int maxWait;
  private long minEvictableIdleTimeMillis;
  private int numTestsPerEvictionRun;
  private boolean testOnBorrow;
  private boolean testOnReturn;
  private boolean testWhileIdle;
  private long timeBetweenEvictionRunsMillis;
  private byte whenExhaustedAction;
  private Class<?> connectionFactory;
  private String validationQuery;
  private boolean logAbandoned;
  private boolean removeAbandoned;
  private int removeAbandonedTimeout;

  void setMaxActive(int v) { this.maxActive = v; }
  void setMaxIdle(int v) { this.maxIdle = v; }
  void setMaxWait(int v) { this.maxWait = v; }
  void setMinEvictableIdleTimeMillis(long v) { this.minEvictableIdleTimeMillis = v; }
  void setNumTestsPerEvictionRun(int v) { this.numTestsPerEvictionRun = v; }
  void setTestOnBorrow(boolean v) { this.testOnBorrow = v; }
  void setTestOnReturn(boolean v) { this.testOnReturn = v; }
  void setTestWhileIdle(boolean v) { this.testWhileIdle = v; }
  void setTimeBetweenEvictionRunsMillis(long v) { this.timeBetweenEvictionRunsMillis = v; }
  void setWhenExhaustedAction(byte v) { this.whenExhaustedAction = v; }
  void setConnectionFactory(Class<?> v) { this.connectionFactory = v; }
  void setValidationQuery(String v) { this.validationQuery = v; }
  void setLogAbandoned(boolean v) { this.logAbandoned = v; }
  void setRemoveAbandoned(boolean v) { this.removeAbandoned = v; }
  void setRemoveAbandonedTimeout(int v) { this.removeAbandonedTimeout = v; }

  @Override
  public String toString() {
    return "Pool[maxActive=" + maxActive + ", maxIdle=" + maxIdle + ", maxWait=" + maxWait
        + ", testOnBorrow=" + testOnBorrow + ", validationQuery=" + validationQuery + "]";
  }
}


class SequenceDescriptor extends DescriptorBase {
  final JdbcConnectionDescriptor jcd;
  private Class<?> sequenceManagerClass;

  SequenceDescriptor(JdbcConnectionDescriptor jcd) { this.jcd = jcd; }

  void setSequenceManagerClass(Class<?> clazz) { this.sequenceManagerClass = clazz; }
  Class<?> getSequenceManagerClass() { return sequenceManagerClass; }

  @Override
  public String toString() {
    return "SequenceDescriptor[class=" + sequenceManagerClass + "]";
  }
}




class PersistenceBrokerException extends RuntimeException {
  PersistenceBrokerException(Throwable cause) { super(cause); }
  PersistenceBrokerException(String message) { super(message); }
}

interface TagIds {
  String TAG_SUPER = "super";

  static final int MAPPING_REPOSITORY = 1;
  static final int CLASS_DESCRIPTOR = 2;
  static final int OBJECT_CACHE = 3;
  static final int CLASS_EXTENT = 4;
  static final int FIELD_DESCRIPTOR = 5;
  static final int REFERENCE_DESCRIPTOR = 6;
  static final int FOREIGN_KEY = 7;
  static final int COLLECTION_DESCRIPTOR = 8;
  static final int ORDERBY = 9;
  static final int INVERSE_FK = 10;
  static final int FK_POINTING_TO_THIS_CLASS = 11;
  static final int FK_POINTING_TO_ITEMS_CLASS = 12;
  static final int ATTRIBUTE = 13;
  static final int QUERY_CUSTOMIZER = 14;
  static final int INDEX_DESCRIPTOR = 15;
  static final int INDEX_COLUMN = 16;
  static final int INSERT_PROCEDURE = 17;
  static final int UPDATE_PROCEDURE = 18;
  static final int DELETE_PROCEDURE = 19;
  static final int CONSTANT_ARGUMENT = 20;
  static final int RUNTIME_ARGUMENT = 21;
  static final int JDBC_CONNECTION_DESCRIPTOR = 22;
  static final int CONNECTION_POOL = 23;
  static final int SEQUENCE_MANAGER = 24;

  
  static final int ISOLATION_LEVEL = 100;
  static final int PROXY_PREFETCHING_LIMIT = 101;
  static final int REPOSITORY_VERSION = 102;
  static final int CLASS_NAME = 103;
  static final int SCHEMA_NAME = 104;
  static final int CLASS_PROXY = 105;
  static final int TABLE_NAME = 106;
  static final int ROW_READER = 107;
  static final int EXTENDS = 108;
  static final int ACCEPT_LOCKS = 109;
  static final int INITIALIZATION_METHOD = 110;
  static final int FACTORY_CLASS = 111;
  static final int FACTORY_METHOD = 112;
  static final int REFRESH = 113;
  static final int ID = 114;
  static final int ACCESS = 115;
  static final int FIELD_NAME = 116;
  static final int COLUMN_NAME = 117;
  static final int JDBC_TYPE = 118;
  static final int PRIMARY_KEY = 119;
  static final int NULLABLE = 120;
  static final int INDEXED = 121;
  static final int AUTO_INCREMENT = 122;
  static final int SEQUENCE_NAME = 123;
  static final int LOCKING = 124;
  static final int UPDATE_LOCK = 125;
  static final int FIELD_CONVERSION = 126;
  static final int LENGTH = 127;
  static final int PRECISION = 128;
  static final int SCALE = 129;
  static final int REFERENCED_CLASS = 130;
  static final int PROXY_REFERENCE = 131;
  static final int AUTO_RETRIEVE = 132;
  static final int AUTO_UPDATE = 133;
  static final int AUTO_DELETE = 134;
  static final int OTM_DEPENDENT = 135;
  static final int FIELD_ID_REF = 136;
  static final int FIELD_REF = 137;
  static final int COLLECTION_CLASS = 138;
  static final int ITEMS_CLASS = 139;
  static final int SORT = 140;
  static final int INDIRECTION_TABLE = 141;
  static final int ATTRIBUTE_NAME = 142;
  static final int ATTRIBUTE_VALUE = 143;
  static final int NAME = 144;
  static final int UNIQUE = 145;
  static final int INCLUDE_ALL_FIELDS = 146;
  static final int RETURN_FIELD_REF = 147;
  static final int VALUE = 148;
  static final int RETURN = 149;
  static final int INCLUDE_PK_FIELDS_ONLY = 150;
  static final int JCD_ALIAS = 151;
  static final int DEFAULT_CONNECTION = 152;
  static final int DBMS_NAME = 153;
  static final int JDBC_LEVEL = 154;
  static final int DRIVER_NAME = 155;
  static final int URL_PROTOCOL = 156;
  static final int URL_SUBPROTOCOL = 157;
  static final int URL_DBALIAS = 158;
  static final int DATASOURCE_NAME = 159;
  static final int USER_NAME = 160;
  static final int USER_PASSWD = 161;
  static final int EAGER_RELEASE = 162;
  static final int BATCH_MODE = 163;
  static final int USE_AUTOCOMMIT = 164;
  static final int IGNORE_AUTOCOMMIT_EXCEPTION = 165;
  static final int CON_MAX_ACTIVE = 166;
  static final int CON_MAX_IDLE = 167;
  static final int CON_MAX_WAIT = 168;
  static final int CON_MIN_EVICTABLE_IDLE_TIME_MILLIS = 169;
  static final int CON_NUM_TESTS_PER_EVICTION_RUN = 170;
  static final int CON_TEST_ON_BORROW = 171;
  static final int CON_TEST_ON_RETURN = 172;
  static final int CON_TEST_WHILE_IDLE = 173;
  static final int CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS = 174;
  static final int CON_WHEN_EXHAUSTED_ACTION = 175;
  static final int CONNECTION_FACTORY = 176;
  static final int VALIDATION_QUERY = 177;
  static final int CON_LOG_ABANDONED = 178;
  static final int CON_REMOVE_ABANDONED = 179;
  static final int CON_REMOVE_ABANDONED_TIMEOUT = 180;
  static final int SEQUENCE_MANAGER_CLASS = 181;

  }








class Tags implements TagIds {
  private static final Map<String, Integer> TAG_IDS_BY_ELEMENT_NAME = new HashMap<>();
  static {
    TAG_IDS_BY_ELEMENT_NAME.put("repository", MAPPING_REPOSITORY);
    TAG_IDS_BY_ELEMENT_NAME.put("class-descriptor", CLASS_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("object-cache", OBJECT_CACHE);
    TAG_IDS_BY_ELEMENT_NAME.put("class-extent", CLASS_EXTENT);
    TAG_IDS_BY_ELEMENT_NAME.put("field-descriptor", FIELD_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("reference-descriptor", REFERENCE_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("foreignkey", FOREIGN_KEY);
    TAG_IDS_BY_ELEMENT_NAME.put("collection-descriptor", COLLECTION_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("orderby", ORDERBY);
    TAG_IDS_BY_ELEMENT_NAME.put("inverse-foreignkey", INVERSE_FK);
    TAG_IDS_BY_ELEMENT_NAME.put("fk-pointing-to-this-class", FK_POINTING_TO_THIS_CLASS);
    TAG_IDS_BY_ELEMENT_NAME.put("fk-pointing-to-items-class", FK_POINTING_TO_ITEMS_CLASS);
    TAG_IDS_BY_ELEMENT_NAME.put("attribute", ATTRIBUTE);
    TAG_IDS_BY_ELEMENT_NAME.put("query-customizer", QUERY_CUSTOMIZER);
    TAG_IDS_BY_ELEMENT_NAME.put("index-descriptor", INDEX_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("index-column", INDEX_COLUMN);
    TAG_IDS_BY_ELEMENT_NAME.put("insert-procedure", INSERT_PROCEDURE);
    TAG_IDS_BY_ELEMENT_NAME.put("update-procedure", UPDATE_PROCEDURE);
    TAG_IDS_BY_ELEMENT_NAME.put("delete-procedure", DELETE_PROCEDURE);
    TAG_IDS_BY_ELEMENT_NAME.put("constant-argument", CONSTANT_ARGUMENT);
    TAG_IDS_BY_ELEMENT_NAME.put("runtime-argument", RUNTIME_ARGUMENT);
    TAG_IDS_BY_ELEMENT_NAME.put("jdbc-connection-descriptor", JDBC_CONNECTION_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("connection-pool", CONNECTION_POOL);
    TAG_IDS_BY_ELEMENT_NAME.put("sequence-manager", SEQUENCE_MANAGER);
    TAG_IDS_BY_ELEMENT_NAME.put("jdbc-connection-descriptor", JDBC_CONNECTION_DESCRIPTOR);
    TAG_IDS_BY_ELEMENT_NAME.put("connection-pool", CONNECTION_POOL);
    TAG_IDS_BY_ELEMENT_NAME.put("sequence-manager", SEQUENCE_MANAGER);
  }

  static int getLiteralId(String elementName) {
    Integer id = TAG_IDS_BY_ELEMENT_NAME.get(elementName);
    return id == null ? -1 : id;
  }

  private static final Map<Integer, String> ATTR_NAMES_BY_ID = new HashMap<>();
  static {
    ATTR_NAMES_BY_ID.put(ISOLATION_LEVEL, "isolation-level");
    ATTR_NAMES_BY_ID.put(PROXY_PREFETCHING_LIMIT, "proxy-prefetching-limit");
    ATTR_NAMES_BY_ID.put(REPOSITORY_VERSION, "version");
    ATTR_NAMES_BY_ID.put(CLASS_NAME, "class");
    ATTR_NAMES_BY_ID.put(SCHEMA_NAME, "schema");
    ATTR_NAMES_BY_ID.put(CLASS_PROXY, "proxy");
    ATTR_NAMES_BY_ID.put(TABLE_NAME, "table");
    ATTR_NAMES_BY_ID.put(ROW_READER, "row-reader");
    ATTR_NAMES_BY_ID.put(EXTENDS, "extends");
    ATTR_NAMES_BY_ID.put(ACCEPT_LOCKS, "accept-locks");
    ATTR_NAMES_BY_ID.put(INITIALIZATION_METHOD, "initialization-method");
    ATTR_NAMES_BY_ID.put(FACTORY_CLASS, "factory-class");
    ATTR_NAMES_BY_ID.put(FACTORY_METHOD, "factory-method");
    ATTR_NAMES_BY_ID.put(REFRESH, "refresh");
    ATTR_NAMES_BY_ID.put(ID, "id");
    ATTR_NAMES_BY_ID.put(ACCESS, "access");
    ATTR_NAMES_BY_ID.put(FIELD_NAME, "name");
    ATTR_NAMES_BY_ID.put(COLUMN_NAME, "column");
    ATTR_NAMES_BY_ID.put(JDBC_TYPE, "jdbc-type");
    ATTR_NAMES_BY_ID.put(PRIMARY_KEY, "primarykey");
    ATTR_NAMES_BY_ID.put(NULLABLE, "nullable");
    ATTR_NAMES_BY_ID.put(INDEXED, "indexed");
    ATTR_NAMES_BY_ID.put(AUTO_INCREMENT, "autoincrement");
    ATTR_NAMES_BY_ID.put(SEQUENCE_NAME, "sequence-name");
    ATTR_NAMES_BY_ID.put(LOCKING, "locking");
    ATTR_NAMES_BY_ID.put(UPDATE_LOCK, "update-lock");
    ATTR_NAMES_BY_ID.put(FIELD_CONVERSION, "conversion");
    ATTR_NAMES_BY_ID.put(LENGTH, "length");
    ATTR_NAMES_BY_ID.put(PRECISION, "precision");
    ATTR_NAMES_BY_ID.put(SCALE, "scale");
    ATTR_NAMES_BY_ID.put(REFERENCED_CLASS, "class-ref");
    ATTR_NAMES_BY_ID.put(PROXY_REFERENCE, "proxy");
    ATTR_NAMES_BY_ID.put(AUTO_RETRIEVE, "auto-retrieve");
    ATTR_NAMES_BY_ID.put(AUTO_UPDATE, "auto-update");
    ATTR_NAMES_BY_ID.put(AUTO_DELETE, "auto-delete");
    ATTR_NAMES_BY_ID.put(OTM_DEPENDENT, "otm-dependent");
    ATTR_NAMES_BY_ID.put(FIELD_ID_REF, "field-id-ref");
    ATTR_NAMES_BY_ID.put(FIELD_REF, "field-ref");
    ATTR_NAMES_BY_ID.put(COLLECTION_CLASS, "collection-class");
    ATTR_NAMES_BY_ID.put(ITEMS_CLASS, "element-class-ref");
    ATTR_NAMES_BY_ID.put(SORT, "sort");
    ATTR_NAMES_BY_ID.put(ORDERBY, "orderby");
    ATTR_NAMES_BY_ID.put(INDIRECTION_TABLE, "indirection-table");
    ATTR_NAMES_BY_ID.put(ATTRIBUTE_NAME, "attribute-name");
    ATTR_NAMES_BY_ID.put(ATTRIBUTE_VALUE, "attribute-value");
    ATTR_NAMES_BY_ID.put(NAME, "name");
    ATTR_NAMES_BY_ID.put(UNIQUE, "unique");
    ATTR_NAMES_BY_ID.put(INCLUDE_ALL_FIELDS, "include-all-fields");
    ATTR_NAMES_BY_ID.put(RETURN_FIELD_REF, "return-field-ref");
    ATTR_NAMES_BY_ID.put(VALUE, "value");
    ATTR_NAMES_BY_ID.put(RETURN, "return");
    ATTR_NAMES_BY_ID.put(INCLUDE_PK_FIELDS_ONLY, "include-pk-fields-only");
    ATTR_NAMES_BY_ID.put(JCD_ALIAS, "jcd-alias");
    ATTR_NAMES_BY_ID.put(DEFAULT_CONNECTION, "default-connection");
    ATTR_NAMES_BY_ID.put(DBMS_NAME, "platform");
    ATTR_NAMES_BY_ID.put(JDBC_LEVEL, "jdbc-level");
    ATTR_NAMES_BY_ID.put(DRIVER_NAME, "driver");
    ATTR_NAMES_BY_ID.put(URL_PROTOCOL, "protocol");
    ATTR_NAMES_BY_ID.put(URL_SUBPROTOCOL, "subprotocol");
    ATTR_NAMES_BY_ID.put(URL_DBALIAS, "dbalias");
    ATTR_NAMES_BY_ID.put(DATASOURCE_NAME, "datasource");
    ATTR_NAMES_BY_ID.put(USER_NAME, "username");
    ATTR_NAMES_BY_ID.put(USER_PASSWD, "password");
    ATTR_NAMES_BY_ID.put(EAGER_RELEASE, "eager-release");
    ATTR_NAMES_BY_ID.put(BATCH_MODE, "batch-mode");
    ATTR_NAMES_BY_ID.put(USE_AUTOCOMMIT, "useAutoCommit");
    ATTR_NAMES_BY_ID.put(IGNORE_AUTOCOMMIT_EXCEPTION, "ignoreAutoCommitExceptions");
    ATTR_NAMES_BY_ID.put(CON_MAX_ACTIVE, "maxActive");
    ATTR_NAMES_BY_ID.put(CON_MAX_IDLE, "maxIdle");
    ATTR_NAMES_BY_ID.put(CON_MAX_WAIT, "maxWait");
    ATTR_NAMES_BY_ID.put(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS, "minEvictableIdleTimeMillis");
    ATTR_NAMES_BY_ID.put(CON_NUM_TESTS_PER_EVICTION_RUN, "numTestsPerEvictionRun");
    ATTR_NAMES_BY_ID.put(CON_TEST_ON_BORROW, "testOnBorrow");
    ATTR_NAMES_BY_ID.put(CON_TEST_ON_RETURN, "testOnReturn");
    ATTR_NAMES_BY_ID.put(CON_TEST_WHILE_IDLE, "testWhileIdle");
    ATTR_NAMES_BY_ID.put(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS, "timeBetweenEvictionRunsMillis");
    ATTR_NAMES_BY_ID.put(CON_WHEN_EXHAUSTED_ACTION, "whenExhaustedAction");
    ATTR_NAMES_BY_ID.put(CONNECTION_FACTORY, "connectionFactory");
    ATTR_NAMES_BY_ID.put(VALIDATION_QUERY, "validationQuery");
    ATTR_NAMES_BY_ID.put(CON_LOG_ABANDONED, "logAbandoned");
    ATTR_NAMES_BY_ID.put(CON_REMOVE_ABANDONED, "removeAbandoned");
    ATTR_NAMES_BY_ID.put(CON_REMOVE_ABANDONED_TIMEOUT, "removeAbandonedTimeout");
    ATTR_NAMES_BY_ID.put(SEQUENCE_MANAGER_CLASS, "className");
    ATTR_NAMES_BY_ID.put(JCD_ALIAS, "jcd-alias");
    ATTR_NAMES_BY_ID.put(DEFAULT_CONNECTION, "default-connection");
    ATTR_NAMES_BY_ID.put(DBMS_NAME, "platform");
    ATTR_NAMES_BY_ID.put(JDBC_LEVEL, "jdbc-level");
    ATTR_NAMES_BY_ID.put(DRIVER_NAME, "driver");
    ATTR_NAMES_BY_ID.put(URL_PROTOCOL, "protocol");
    ATTR_NAMES_BY_ID.put(URL_SUBPROTOCOL, "subprotocol");
    ATTR_NAMES_BY_ID.put(URL_DBALIAS, "dbalias");
    ATTR_NAMES_BY_ID.put(DATASOURCE_NAME, "datasource");
    ATTR_NAMES_BY_ID.put(USER_NAME, "username");
    ATTR_NAMES_BY_ID.put(USER_PASSWD, "password");
    ATTR_NAMES_BY_ID.put(EAGER_RELEASE, "eager-release");
    ATTR_NAMES_BY_ID.put(BATCH_MODE, "batch-mode");
    ATTR_NAMES_BY_ID.put(USE_AUTOCOMMIT, "useAutoCommit");
    ATTR_NAMES_BY_ID.put(IGNORE_AUTOCOMMIT_EXCEPTION, "ignoreAutoCommitExceptions");
    ATTR_NAMES_BY_ID.put(CON_MAX_ACTIVE, "maxActive");
    ATTR_NAMES_BY_ID.put(CON_MAX_IDLE, "maxIdle");
    ATTR_NAMES_BY_ID.put(CON_MAX_WAIT, "maxWait");
    ATTR_NAMES_BY_ID.put(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS, "minEvictableIdleTimeMillis");
    ATTR_NAMES_BY_ID.put(CON_NUM_TESTS_PER_EVICTION_RUN, "numTestsPerEvictionRun");
    ATTR_NAMES_BY_ID.put(CON_TEST_ON_BORROW, "testOnBorrow");
    ATTR_NAMES_BY_ID.put(CON_TEST_ON_RETURN, "testOnReturn");
    ATTR_NAMES_BY_ID.put(CON_TEST_WHILE_IDLE, "testWhileIdle");
    ATTR_NAMES_BY_ID.put(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS, "timeBetweenEvictionRunsMillis");
    ATTR_NAMES_BY_ID.put(CON_WHEN_EXHAUSTED_ACTION, "whenExhaustedAction");
    ATTR_NAMES_BY_ID.put(CONNECTION_FACTORY, "connectionFactory");
    ATTR_NAMES_BY_ID.put(VALIDATION_QUERY, "validationQuery");
    ATTR_NAMES_BY_ID.put(CON_LOG_ABANDONED, "logAbandoned");
    ATTR_NAMES_BY_ID.put(CON_REMOVE_ABANDONED, "removeAbandoned");
    ATTR_NAMES_BY_ID.put(CON_REMOVE_ABANDONED_TIMEOUT, "removeAbandonedTimeout");
    ATTR_NAMES_BY_ID.put(SEQUENCE_MANAGER_CLASS, "className");
  }

  String getTagById(int id) {
    return ATTR_NAMES_BY_ID.get(id);
  }
}
