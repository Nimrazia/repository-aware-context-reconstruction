































import java.io.File;
import java.io.IOException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

public class method_2_jettybootstrap_claude {

  
  
  
  
  static class Log {
    void trace(String msg) {
      System.out.println("[TRACE] " + msg);
    }

    void trace(String msg, Object arg) {
      System.out.println("[TRACE] " + msg.replace("{}", String.valueOf(arg)));
    }

    void debug(String msg) {
      System.out.println("[DEBUG] " + msg);
    }
  }

  static final Log LOG = new Log();

  
  
  
  static class FileUtils {
    static void deleteDirectory(File dir) throws IOException {
      if (dir == null || !dir.exists()) {
        return;
      }
      File[] children = dir.listFiles();
      if (children != null) {
        for (File child : children) {
          if (child.isDirectory()) {
            deleteDirectory(child);
          } else if (!child.delete()) {
            throw new IOException("Could not delete file " + child);
          }
        }
      }
      if (!dir.delete()) {
        throw new IOException("Could not delete directory " + dir);
      }
    }
  }

  
  
  
  
  
  enum JettyConnector {
    HTTP, HTTPS
  }

  static class JettyBootstrapException extends Exception {
    JettyBootstrapException(String msg) {
      super(msg);
    }

    JettyBootstrapException(String msg, Throwable cause) {
      super(msg, cause);
    }
  }

  static class JettyKeystoreException extends Exception {
    JettyKeystoreException(String msg) {
      super(msg);
    }
  }

  static class JettyKeystoreGeneratorBuilder {
    String algorithm;
    String signatureAlgorithm;
    String rdnOuValue;
    String rdnOValue;
    int dateNotBeforeNumberOfDays;
    int dateNotAfterNumberOfDays;

    void setAlgorithm(String v) {
      algorithm = v;
    }

    void setSignatureAlgorithm(String v) {
      signatureAlgorithm = v;
    }

    void setRdnOuValue(String v) {
      rdnOuValue = v;
    }

    void setRdnOValue(String v) {
      rdnOValue = v;
    }

    void setDateNotBeforeNumberOfDays(int v) {
      dateNotBeforeNumberOfDays = v;
    }

    void setDateNotAfterNumberOfDays(int v) {
      dateNotAfterNumberOfDays = v;
    }

    
    
    
    KeyStore build(String domainName, String alias, String password) throws JettyKeystoreException {
      try {
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        ks.load(null, password == null ? null : password.toCharArray());
        return ks;
      } catch (Exception e) {
        throw new JettyKeystoreException("Could not generate keystore: " + e.getMessage());
      }
    }

    static void saveKeyStore(KeyStore keyStore, File file, String password) throws JettyKeystoreException {
      try (java.io.OutputStream os = new java.io.FileOutputStream(file)) {
        keyStore.store(os, password == null ? null : password.toCharArray());
      } catch (Exception e) {
        throw new JettyKeystoreException("Could not save keystore: " + e.getMessage());
      }
    }
  }

  interface IJettyConfiguration {
    boolean hasJettyConnector(JettyConnector connector);

    File getTempDirectory();

    void setTempDirectory(File dir);

    boolean isCleanTempDir();

    String getHost();

    KeyStore getSslKeyStore();

    String getSslPrivateKeyPath();

    String getSslCertificatePath();

    String getSslKeyStorePath();

    void setSslKeyStorePath(String path);

    String getSslKeyStoreAlgorithm();

    String getSslKeyStoreSignatureAlgorithm();

    String getSslKeyStoreRdnOuValue();

    String getSslKeyStoreRdnOValue();

    int getSslKeyStoreDateNotBeforeNumberOfDays();

    int getSslKeyStoreDateNotAfterNumberOfDays();

    String getSslKeyStoreDomainName();

    String getSslKeyStoreAlias();

    String getSslKeyStorePassword();

    boolean isRedirectWebAppsOnHttpsConnector();

    @Override
    String toString();
  }

  static class SimpleJettyConfiguration implements IJettyConfiguration {
    List<JettyConnector> connectors = new ArrayList<>();
    File tempDirectory;
    boolean cleanTempDir = false;
    String host = "0.0.0.0";
    KeyStore sslKeyStore;
    String sslPrivateKeyPath;
    String sslCertificatePath;
    String sslKeyStorePath;
    String sslKeyStoreAlgorithm = "RSA";
    String sslKeyStoreSignatureAlgorithm = "SHA256withRSA";
    String sslKeyStoreRdnOuValue = "dev";
    String sslKeyStoreRdnOValue = "demo";
    int sslKeyStoreDateNotBeforeNumberOfDays = 0;
    int sslKeyStoreDateNotAfterNumberOfDays = 365;
    String sslKeyStoreDomainName = "localhost";
    String sslKeyStoreAlias = "jetty";
    String sslKeyStorePassword = "changeit";
    boolean redirectWebAppsOnHttpsConnector = false;

    @Override
    public boolean hasJettyConnector(JettyConnector connector) {
      return connectors.contains(connector);
    }

    @Override
    public File getTempDirectory() {
      return tempDirectory;
    }

    @Override
    public void setTempDirectory(File dir) {
      tempDirectory = dir;
    }

    @Override
    public boolean isCleanTempDir() {
      return cleanTempDir;
    }

    @Override
    public String getHost() {
      return host;
    }

    @Override
    public KeyStore getSslKeyStore() {
      return sslKeyStore;
    }

    @Override
    public String getSslPrivateKeyPath() {
      return sslPrivateKeyPath;
    }

    @Override
    public String getSslCertificatePath() {
      return sslCertificatePath;
    }

    @Override
    public String getSslKeyStorePath() {
      return sslKeyStorePath;
    }

    @Override
    public void setSslKeyStorePath(String path) {
      sslKeyStorePath = path;
    }

    @Override
    public String getSslKeyStoreAlgorithm() {
      return sslKeyStoreAlgorithm;
    }

    @Override
    public String getSslKeyStoreSignatureAlgorithm() {
      return sslKeyStoreSignatureAlgorithm;
    }

    @Override
    public String getSslKeyStoreRdnOuValue() {
      return sslKeyStoreRdnOuValue;
    }

    @Override
    public String getSslKeyStoreRdnOValue() {
      return sslKeyStoreRdnOValue;
    }

    @Override
    public int getSslKeyStoreDateNotBeforeNumberOfDays() {
      return sslKeyStoreDateNotBeforeNumberOfDays;
    }

    @Override
    public int getSslKeyStoreDateNotAfterNumberOfDays() {
      return sslKeyStoreDateNotAfterNumberOfDays;
    }

    @Override
    public String getSslKeyStoreDomainName() {
      return sslKeyStoreDomainName;
    }

    @Override
    public String getSslKeyStoreAlias() {
      return sslKeyStoreAlias;
    }

    @Override
    public String getSslKeyStorePassword() {
      return sslKeyStorePassword;
    }

    @Override
    public boolean isRedirectWebAppsOnHttpsConnector() {
      return redirectWebAppsOnHttpsConnector;
    }

    @Override
    public String toString() {
      return "SimpleJettyConfiguration{host=" + host + ", connectors=" + connectors
          + ", tempDirectory=" + tempDirectory + "}";
    }
  }

  
  
  
  
  static final File TEMP_DIRECTORY_DEFAULT = new File(System.getProperty("java.io.tmpdir"), "jetty-bootstrap-demo");
  static final String DEFAULT_KEYSTORE_FILENAME = "keystore.jks";

  boolean isInitializedConfiguration = false;
  IJettyConfiguration iJettyConfiguration;

  method_2_jettybootstrap_claude(IJettyConfiguration cfg) {
    this.iJettyConfiguration = cfg;
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  protected IJettyConfiguration getInitializedConfiguration() throws JettyBootstrapException {
        if (!isInitializedConfiguration) {
            LOG.debug("Init Configuration...");

            LOG.trace("Check Temp Directory...");
            if (iJettyConfiguration.getTempDirectory() == null) {
                iJettyConfiguration.setTempDirectory(TEMP_DIRECTORY_DEFAULT);
            }

            if (iJettyConfiguration.getTempDirectory().exists() && iJettyConfiguration.isCleanTempDir()) {
                LOG.trace("Clean Temp Directory...");

                try {
                    FileUtils.deleteDirectory(iJettyConfiguration.getTempDirectory());
                } catch (IOException e) {
                    throw new JettyBootstrapException("Can't clean temporary directory");
                }
            }
            if (!iJettyConfiguration.getTempDirectory().exists() && !iJettyConfiguration.getTempDirectory().mkdirs()) {
                throw new JettyBootstrapException("Can't create temporary directory");
            }

            LOG.trace("Check required properties...");
            if (iJettyConfiguration.getHost() == null || iJettyConfiguration.getHost().isEmpty()) {
                throw new JettyBootstrapException("Host not specified");
            }

            LOG.trace("Check connectors...");
            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {

                
                if (iJettyConfiguration.getSslKeyStore() == null &&
                    (iJettyConfiguration.getSslPrivateKeyPath() == null || iJettyConfiguration.getSslPrivateKeyPath().isEmpty() ||
                        iJettyConfiguration.getSslCertificatePath() == null || iJettyConfiguration.getSslCertificatePath().isEmpty())) {

                    
                    if (iJettyConfiguration.getSslKeyStorePath() == null || iJettyConfiguration.getSslKeyStorePath().isEmpty()) {
                        iJettyConfiguration.setSslKeyStorePath(iJettyConfiguration.getTempDirectory().getPath() + File.separator + DEFAULT_KEYSTORE_FILENAME);
                    }

                    
                    File keystoreFile = new File(iJettyConfiguration.getSslKeyStorePath());
                    if (!keystoreFile.exists()) {
                        try {
                            JettyKeystoreGeneratorBuilder jettyKeystoreGeneratorBuilder = new JettyKeystoreGeneratorBuilder();
                            jettyKeystoreGeneratorBuilder.setAlgorithm(iJettyConfiguration.getSslKeyStoreAlgorithm());
                            jettyKeystoreGeneratorBuilder.setSignatureAlgorithm(iJettyConfiguration.getSslKeyStoreSignatureAlgorithm());
                            jettyKeystoreGeneratorBuilder.setRdnOuValue(iJettyConfiguration.getSslKeyStoreRdnOuValue());
                            jettyKeystoreGeneratorBuilder.setRdnOValue(iJettyConfiguration.getSslKeyStoreRdnOValue());
                            jettyKeystoreGeneratorBuilder.setDateNotBeforeNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotBeforeNumberOfDays());
                            jettyKeystoreGeneratorBuilder.setDateNotAfterNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotAfterNumberOfDays());

                            KeyStore keyStore = jettyKeystoreGeneratorBuilder.build(iJettyConfiguration.getSslKeyStoreDomainName(), iJettyConfiguration.getSslKeyStoreAlias(),
                                    iJettyConfiguration.getSslKeyStorePassword());
                            JettyKeystoreGeneratorBuilder.saveKeyStore(keyStore, keystoreFile, iJettyConfiguration.getSslKeyStorePassword());
                        } catch (JettyKeystoreException e) {
                            throw new JettyBootstrapException("Can't generate keyStore", e);
                        }
                    }
                }
            }

            if (iJettyConfiguration.isRedirectWebAppsOnHttpsConnector() &&
                (!iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP) || !iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS))) {
                throw new JettyBootstrapException("You can't redirect all from HTTP to HTTPS Connector if both connectors are not setted");
            }

            isInitializedConfiguration = true;

            LOG.trace("Configuration : {}", iJettyConfiguration);
        }

        return iJettyConfiguration;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: JettyBootstrap.getInitializedConfiguration ===");

    
    SimpleJettyConfiguration cfgA = new SimpleJettyConfiguration();
    cfgA.connectors.add(JettyConnector.HTTP);
    cfgA.connectors.add(JettyConnector.HTTPS);
    method_2_jettybootstrap_claude bootstrapA = new method_2_jettybootstrap_claude(cfgA);

    IJettyConfiguration resultA = bootstrapA.getInitializedConfiguration();
    System.out.println("\n-- Scenario A (HTTP+HTTPS, auto-generated keystore) --");
    System.out.println("  tempDirectory: " + resultA.getTempDirectory());
    System.out.println("  sslKeyStorePath: " + resultA.getSslKeyStorePath());
    System.out.println("  keystore file exists: " + new File(resultA.getSslKeyStorePath()).exists());
    System.out.println("  isInitializedConfiguration: " + bootstrapA.isInitializedConfiguration);

    
    bootstrapA.getInitializedConfiguration();
    System.out.println("  second call still isInitializedConfiguration: " + bootstrapA.isInitializedConfiguration);

    
    SimpleJettyConfiguration cfgB = new SimpleJettyConfiguration();
    cfgB.connectors.add(JettyConnector.HTTP);
    cfgB.tempDirectory = new File(System.getProperty("java.io.tmpdir"), "jetty-bootstrap-demo-B");
    cfgB.tempDirectory.mkdirs();
    new File(cfgB.tempDirectory, "stale-file.txt").createNewFile();
    cfgB.cleanTempDir = true;
    method_2_jettybootstrap_claude bootstrapB = new method_2_jettybootstrap_claude(cfgB);
    IJettyConfiguration resultB = bootstrapB.getInitializedConfiguration();
    System.out.println("\n-- Scenario B (HTTP-only, pre-existing temp dir cleaned) --");
    System.out.println("  tempDirectory: " + resultB.getTempDirectory());
    System.out.println("  tempDirectory exists after clean+recreate: " + resultB.getTempDirectory().exists());

    
    SimpleJettyConfiguration cfgC = new SimpleJettyConfiguration();
    cfgC.connectors.add(JettyConnector.HTTP);
    cfgC.redirectWebAppsOnHttpsConnector = true;
    method_2_jettybootstrap_claude bootstrapC = new method_2_jettybootstrap_claude(cfgC);
    System.out.println("\n-- Scenario C (invalid redirect config) --");
    try {
      bootstrapC.getInitializedConfiguration();
      System.out.println("  (unexpectedly did not throw)");
    } catch (JettyBootstrapException e) {
      System.out.println("  caught expected JettyBootstrapException: " + e.getMessage());
    }

    System.out.println("\n=== Demo complete: method exercised temp-directory creation/cleanup, "
        + "keystore auto-generation, the idempotent re-init guard, and the "
        + "redirectWebAppsOnHttpsConnector validation branch. ===");
  }
}
