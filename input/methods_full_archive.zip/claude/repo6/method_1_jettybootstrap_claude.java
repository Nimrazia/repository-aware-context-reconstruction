


































import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

public class method_1_jettybootstrap_claude {

  
  
  
  static class Log {
    void trace(String msg) {
      System.out.println("[TRACE] " + msg);
    }

    void debug(String msg) {
      System.out.println("[DEBUG] " + msg);
    }
  }

  static final Log LOG = new Log();

  
  
  
  
  
  interface Connector {
  }

  interface ConnectionFactory {
  }

  static class HttpConfiguration {
    int securePort;
    String secureScheme;
    long idleTimeout;
    long blockingTimeout;

    void setSecurePort(int p) {
      securePort = p;
    }

    void setSecureScheme(String s) {
      secureScheme = s;
    }

    void setIdleTimeout(long t) {
      idleTimeout = t;
    }

    void setBlockingTimeout(long t) {
      blockingTimeout = t;
    }
  }

  static class HttpConnectionFactory implements ConnectionFactory {
    private final HttpConfiguration httpConfiguration;

    HttpConnectionFactory(HttpConfiguration httpConfiguration) {
      this.httpConfiguration = httpConfiguration;
    }

    HttpConfiguration getHttpConfiguration() {
      return httpConfiguration;
    }
  }

  enum HttpScheme {
    HTTP, HTTPS;

    String asString() {
      return name().toLowerCase();
    }
  }

  static class Server {
  }

  static class SslContextFactory {
    KeyStore keyStore;
    String keyStorePath;
    String keyStorePassword;

    void setKeyStore(KeyStore ks) {
      keyStore = ks;
    }

    void setKeyStorePath(String p) {
      keyStorePath = p;
    }

    void setKeyStorePassword(String p) {
      keyStorePassword = p;
    }
  }

  static class ServerConnector implements Connector {
    final List<ConnectionFactory> factories = new ArrayList<>();
    long idleTimeout;
    String host;
    int port;

    ServerConnector(Server server) {
      factories.add(new HttpConnectionFactory(new HttpConfiguration()));
    }

    ServerConnector(Server server, HttpConnectionFactory hcf) {
      factories.add(hcf);
    }

    ServerConnector(Server server, SslContextFactory sslContextFactory) {
      factories.add(new HttpConnectionFactory(new HttpConfiguration()));
    }

    List<ConnectionFactory> getConnectionFactories() {
      return factories;
    }

    void setIdleTimeout(long t) {
      idleTimeout = t;
    }

    void setHost(String h) {
      host = h;
    }

    void setPort(int p) {
      port = p;
    }

    @Override
    public String toString() {
      return "ServerConnector{host=" + host + ", port=" + port + ", idleTimeout=" + idleTimeout + "}";
    }
  }

  
  
  
  
  
  enum JettyConnector {
    HTTP, HTTPS
  }

  enum CertificateFormat {
    PKCS8, PKCS12, UNKNOWN
  }

  static class JettyBootstrapException extends Exception {
    JettyBootstrapException(String msg) {
      super(msg);
    }

    JettyBootstrapException(String msg, Throwable cause) {
      super(msg, cause);
    }
  }

  static class JettyKeystoreException extends Exception {
    JettyKeystoreException(String msg) {
      super(msg);
    }
  }

  static class JettyKeystoreConvertorBuilder {
    void setCertificateFromPKCS8(InputStream in) throws JettyKeystoreException {
    }

    void setCertificateFromPKCS12(InputStream in, String password) throws JettyKeystoreException {
    }

    void setPrivateKeyFromPKCS8(InputStream in) throws JettyKeystoreException {
    }

    void setPrivateKeyFromPKCS12(InputStream in, String password) throws JettyKeystoreException {
    }

    
    
    
    KeyStore build(String alias, String password) throws JettyKeystoreException {
      try {
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        ks.load(null, password == null ? null : password.toCharArray());
        return ks;
      } catch (Exception e) {
        throw new JettyKeystoreException("Could not build keystore: " + e.getMessage());
      }
    }
  }

  interface IJettyConfiguration {
    boolean hasJettyConnector(JettyConnector connector);

    int getSslPort();

    long getIdleTimeout();

    long getBlockingTimeout();

    String getHost();

    int getPort();

    KeyStore getSslKeyStore();

    String getSslPrivateKeyPath();

    String getSslCertificatePath();

    CertificateFormat getSslCertificateFormat();

    CertificateFormat getSslPrivateKeyFormat();

    String getSslCertificatePassword();

    String getSslPrivateKeyPassword();

    String getSslKeyStoreAlias();

    String getSslKeyStorePassword();

    String getSslKeyStorePath();
  }

  
  static class SimpleJettyConfiguration implements IJettyConfiguration {
    List<JettyConnector> connectors = new ArrayList<>();
    int sslPort = 8443;
    long idleTimeout = 30000;
    long blockingTimeout = 0;
    String host = "0.0.0.0";
    int port = 8080;
    KeyStore sslKeyStore;
    String sslPrivateKeyPath;
    String sslCertificatePath;
    CertificateFormat sslCertificateFormat = CertificateFormat.UNKNOWN;
    CertificateFormat sslPrivateKeyFormat = CertificateFormat.UNKNOWN;
    String sslCertificatePassword;
    String sslPrivateKeyPassword;
    String sslKeyStoreAlias = "jetty";
    String sslKeyStorePassword = "changeit";
    String sslKeyStorePath;

    @Override
    public boolean hasJettyConnector(JettyConnector connector) {
      return connectors.contains(connector);
    }

    @Override
    public int getSslPort() {
      return sslPort;
    }

    @Override
    public long getIdleTimeout() {
      return idleTimeout;
    }

    @Override
    public long getBlockingTimeout() {
      return blockingTimeout;
    }

    @Override
    public String getHost() {
      return host;
    }

    @Override
    public int getPort() {
      return port;
    }

    @Override
    public KeyStore getSslKeyStore() {
      return sslKeyStore;
    }

    @Override
    public String getSslPrivateKeyPath() {
      return sslPrivateKeyPath;
    }

    @Override
    public String getSslCertificatePath() {
      return sslCertificatePath;
    }

    @Override
    public CertificateFormat getSslCertificateFormat() {
      return sslCertificateFormat;
    }

    @Override
    public CertificateFormat getSslPrivateKeyFormat() {
      return sslPrivateKeyFormat;
    }

    @Override
    public String getSslCertificatePassword() {
      return sslCertificatePassword;
    }

    @Override
    public String getSslPrivateKeyPassword() {
      return sslPrivateKeyPassword;
    }

    @Override
    public String getSslKeyStoreAlias() {
      return sslKeyStoreAlias;
    }

    @Override
    public String getSslKeyStorePassword() {
      return sslKeyStorePassword;
    }

    @Override
    public String getSslKeyStorePath() {
      return sslKeyStorePath;
    }
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  protected Connector[] createConnectors(IJettyConfiguration iJettyConfiguration, Server server) throws JettyBootstrapException {
        LOG.trace("Creating Jetty Connectors...");

        List<Connector> connectors = new ArrayList<>();

        if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP)) {
            LOG.trace("Adding HTTP Connector...");

            ServerConnector serverConnector;

            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
                HttpConfiguration httpConfiguration = new HttpConfiguration();
                httpConfiguration.setSecurePort(iJettyConfiguration.getSslPort());
                httpConfiguration.setSecureScheme(HttpScheme.HTTPS.asString());
                httpConfiguration.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
                httpConfiguration.setBlockingTimeout(iJettyConfiguration.getBlockingTimeout());

                HttpConnectionFactory httpConnectionFactory = new HttpConnectionFactory(httpConfiguration);

                serverConnector = new ServerConnector(server, httpConnectionFactory);
            } else {
                serverConnector = new ServerConnector(server);

                serverConnector.getConnectionFactories().stream()
                        .filter(HttpConnectionFactory.class::isInstance)
                        .map(HttpConnectionFactory.class::cast)
                        .forEach(httpConnectionFactory -> httpConnectionFactory.getHttpConfiguration().setBlockingTimeout(iJettyConfiguration.getBlockingTimeout()));
            }

            serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
            serverConnector.setHost(iJettyConfiguration.getHost());
            serverConnector.setPort(iJettyConfiguration.getPort());

            connectors.add(serverConnector);
        }
        if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
            LOG.trace("Adding HTTPS Connector...");

            SslContextFactory sslContextFactory = new SslContextFactory();

            if (iJettyConfiguration.getSslKeyStore() != null) { 
                sslContextFactory.setKeyStore(iJettyConfiguration.getSslKeyStore());
            } else if (iJettyConfiguration.getSslPrivateKeyPath() != null && !iJettyConfiguration.getSslPrivateKeyPath().isEmpty() &&
                iJettyConfiguration.getSslCertificatePath() != null && !iJettyConfiguration.getSslCertificatePath().isEmpty()) { 

                JettyKeystoreConvertorBuilder jettyKeystoreConvertorBuilder = new JettyKeystoreConvertorBuilder();
                try {
                    File sslPrivateKeyFile = new File(iJettyConfiguration.getSslPrivateKeyPath());
                    if (!sslPrivateKeyFile.exists() || !sslPrivateKeyFile.canRead()) {
                        throw new JettyBootstrapException("Private key not exists or unreadable");
                    }

                    File sslCertificateFile = new File(iJettyConfiguration.getSslCertificatePath());
                    if (!sslCertificateFile.exists() || !sslCertificateFile.canRead()) {
                        throw new JettyBootstrapException("Certificate not exists or unreadable");
                    }

                    try (InputStream sslPrivateKeyInputStream = new FileInputStream(sslPrivateKeyFile);
                            InputStream sslCertificateInputStream = new FileInputStream(sslCertificateFile)) {

                        switch (iJettyConfiguration.getSslCertificateFormat()) {
                            case PKCS8:
                                jettyKeystoreConvertorBuilder.setCertificateFromPKCS8(sslCertificateInputStream);
                                break;
                            case PKCS12:
                                jettyKeystoreConvertorBuilder.setCertificateFromPKCS12(sslCertificateInputStream, iJettyConfiguration.getSslCertificatePassword());
                                break;
                            case UNKNOWN:
                                throw new JettyBootstrapException("Unknown Certificate Format");
                            default:
                                throw new JettyBootstrapException("Certificate Format not setted");
                        }

                        switch (iJettyConfiguration.getSslPrivateKeyFormat()) {
                            case PKCS8:
                                jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS8(sslPrivateKeyInputStream);
                                break;
                            case PKCS12:
                                jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS12(sslPrivateKeyInputStream, iJettyConfiguration.getSslPrivateKeyPassword());
                                break;
                            case UNKNOWN:
                                throw new JettyBootstrapException("Unknown Private key Format");
                            default:
                                throw new JettyBootstrapException("Private key Format not setted");
                        }
                    }

                    KeyStore keyStore = jettyKeystoreConvertorBuilder.build(iJettyConfiguration.getSslKeyStoreAlias(), iJettyConfiguration.getSslKeyStorePassword());

                    sslContextFactory.setKeyStore(keyStore);
                } catch (JettyKeystoreException | IOException e) {
                    throw new JettyBootstrapException("Can not load SSL private key or SSL certificate", e);
                }
            } else { 
                sslContextFactory.setKeyStorePath(iJettyConfiguration.getSslKeyStorePath());
            }
            sslContextFactory.setKeyStorePassword(iJettyConfiguration.getSslKeyStorePassword());
            ServerConnector serverConnector = new ServerConnector(server, sslContextFactory);

            serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
            serverConnector.setHost(iJettyConfiguration.getHost());
            serverConnector.setPort(iJettyConfiguration.getSslPort());

            connectors.add(serverConnector);
        }

        return connectors.toArray(new Connector[connectors.size()]);
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: JettyBootstrap.createConnectors ===");

    method_1_jettybootstrap_claude bootstrap = new method_1_jettybootstrap_claude();
    Server server = new Server();

    
    SimpleJettyConfiguration cfgHttpOnly = new SimpleJettyConfiguration();
    cfgHttpOnly.connectors.add(JettyConnector.HTTP);
    Connector[] connectorsA = bootstrap.createConnectors(cfgHttpOnly, server);
    System.out.println("\n-- Scenario A (HTTP only) --");
    for (Connector c : connectorsA) {
      System.out.println("  " + c);
    }

    
    SimpleJettyConfiguration cfgBoth = new SimpleJettyConfiguration();
    cfgBoth.connectors.add(JettyConnector.HTTP);
    cfgBoth.connectors.add(JettyConnector.HTTPS);
    cfgBoth.sslKeyStorePath = "/tmp/demo-keystore.jks";
    Connector[] connectorsB = bootstrap.createConnectors(cfgBoth, server);
    System.out.println("\n-- Scenario B (HTTP + HTTPS via keystore path) --");
    for (Connector c : connectorsB) {
      System.out.println("  " + c);
    }

    
    SimpleJettyConfiguration cfgKeyStoreObj = new SimpleJettyConfiguration();
    cfgKeyStoreObj.connectors.add(JettyConnector.HTTPS);
    KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
    ks.load(null, "changeit".toCharArray());
    cfgKeyStoreObj.sslKeyStore = ks;
    Connector[] connectorsC = bootstrap.createConnectors(cfgKeyStoreObj, server);
    System.out.println("\n-- Scenario C (HTTPS only, in-memory KeyStore object) --");
    for (Connector c : connectorsC) {
      System.out.println("  " + c);
    }

    System.out.println("\n=== Demo complete: method exercised the HTTP-only, HTTP+HTTPS "
        + "(HttpConnectionFactory wiring branch and stream-based blockingTimeout branch), "
        + "keystore-path, and in-memory-KeyStore branches. ===");
  }
}
