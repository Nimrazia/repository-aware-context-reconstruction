









































import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class method_2_stanfordnlp_claude {

  
  
  
  
  interface Filter<T> {
    boolean accept(T t);
  }

  
  
  
  interface Label {
    String value();

    void setValue(String value);
  }

  static class StringLabel implements Label {
    private String value;

    StringLabel(String value) {
      this.value = value;
    }

    @Override
    public String value() {
      return value;
    }

    @Override
    public void setValue(String value) {
      this.value = value;
    }

    @Override
    public String toString() {
      return value;
    }
  }

  interface LabelFactory {
    Label newLabel(String value);
  }

  
  
  
  
  interface CoreAnnotation<V> {
  }

  interface CoreMap {
    <V> V get(Class<? extends CoreAnnotation<V>> key);

    <V> void set(Class<? extends CoreAnnotation<V>> key, V value);
  }

  static class CoreAnnotations {
    static class IndexAnnotation implements CoreAnnotation<Integer> {
    }
  }

  static class CoreLabel implements Label, CoreMap {
    private String value;
    private String tag;
    private final Map<Class<?>, Object> store = new HashMap<>();

    @Override
    public String value() {
      return value;
    }

    @Override
    public void setValue(String value) {
      this.value = value;
    }

    String word() {
      return value;
    }

    void setWord(String w) {
      this.value = w;
    }

    String tag() {
      return tag;
    }

    void setTag(String t) {
      this.tag = t;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <V> V get(Class<? extends CoreAnnotation<V>> key) {
      return (V) store.get(key);
    }

    @Override
    public <V> void set(Class<? extends CoreAnnotation<V>> key, V value) {
      store.put(key, value);
    }

    @Override
    public String toString() {
      return value;
    }

    static LabelFactory factory() {
      return v -> {
        CoreLabel l = new CoreLabel();
        l.setValue(v);
        return l;
      };
    }
  }

  static class CyclicCoreLabel extends CoreLabel {
    static LabelFactory factory() {
      return v -> {
        CyclicCoreLabel l = new CyclicCoreLabel();
        l.setValue(v);
        return l;
      };
    }
  }

  
  
  
  static class TaggedWord {
    private final String word;
    private final String tag;

    TaggedWord(String word, String tag) {
      this.word = word;
      this.tag = tag;
    }

    String word() {
      return word;
    }

    String tag() {
      return tag;
    }

    @Override
    public String toString() {
      return word + "/" + tag;
    }
  }

  
  
  
  interface TreeFactory {
    Tree newTreeNode(Label label, List<Tree> children);
  }

  static class SimpleTreeFactory implements TreeFactory {
    @Override
    public Tree newTreeNode(Label label, List<Tree> children) {
      return new Tree(label, children);
    }
  }

  static class Tree implements Iterable<Tree> {
    private Label label;
    private final List<Tree> children = new ArrayList<>();
    private Tree parentRef;

    Tree(Label label) {
      this.label = label;
    }

    Tree(Label label, List<Tree> children) {
      this.label = label;
      if (children != null) {
        for (Tree c : children) {
          addChild(c);
        }
      }
    }

    void addChild(Tree c) {
      children.add(c);
      c.parentRef = this;
    }

    Label label() {
      return label;
    }

    void setLabel(Label l) {
      this.label = l;
    }

    boolean isLeaf() {
      return children.isEmpty();
    }

    List<Tree> children() {
      return children;
    }

    Tree firstChild() {
      return children.get(0);
    }

    boolean isUnaryRewrite() {
      return children.size() == 1;
    }

    TreeFactory treeFactory() {
      return new SimpleTreeFactory();
    }

    Tree parent(Tree root) {
      return parentRef;
    }

    
    
    
    Tree prune(Filter<Tree> filter) {
      if (isLeaf()) {
        return filter.accept(this) ? null : new Tree(label);
      }
      List<Tree> newChildren = new ArrayList<>();
      for (Tree c : children) {
        Tree pruned = c.prune(filter);
        if (pruned != null) {
          newChildren.add(pruned);
        }
      }
      if (newChildren.isEmpty()) {
        return null;
      }
      return new Tree(label, newChildren);
    }

    ArrayList<Label> yield() {
      ArrayList<Label> result = new ArrayList<>();
      collectYield(result);
      return result;
    }

    private void collectYield(List<Label> acc) {
      if (isLeaf()) {
        acc.add(label);
      } else {
        for (Tree c : children) {
          c.collectYield(acc);
        }
      }
    }

    ArrayList<TaggedWord> taggedYield() {
      ArrayList<TaggedWord> result = new ArrayList<>();
      collectTaggedYield(result);
      return result;
    }

    private void collectTaggedYield(List<TaggedWord> acc) {
      if (isLeaf()) {
        String tag = (parentRef != null && parentRef.label != null) ? parentRef.label.value() : "XX";
        acc.add(new TaggedWord(label.value(), tag));
      } else {
        for (Tree c : children) {
          c.collectTaggedYield(acc);
        }
      }
    }

    
    
    List<CoreLabel> taggedLabeledYield() {
      List<CoreLabel> result = new ArrayList<>();
      collectTaggedLabeled(result);
      return result;
    }

    private void collectTaggedLabeled(List<CoreLabel> acc) {
      if (isLeaf()) {
        CoreLabel cl = new CoreLabel();
        cl.setValue(label.value());
        cl.setWord(label.value());
        cl.setTag(parentRef != null && parentRef.label != null ? parentRef.label.value() : "XX");
        if (label instanceof CoreLabel) {
          Integer idx = ((CoreLabel) label).get(CoreAnnotations.IndexAnnotation.class);
          if (idx != null) {
            cl.set(CoreAnnotations.IndexAnnotation.class, idx);
          }
        }
        acc.add(cl);
      } else {
        for (Tree c : children) {
          c.collectTaggedLabeled(acc);
        }
      }
    }

    List<Tree> getLeaves() {
      List<Tree> result = new ArrayList<>();
      collectLeaves(result);
      return result;
    }

    private void collectLeaves(List<Tree> acc) {
      if (isLeaf()) {
        acc.add(this);
      } else {
        for (Tree c : children) {
          c.collectLeaves(acc);
        }
      }
    }

    void indexLeaves() {
      int[] counter = { 1 };
      indexLeaves(counter);
    }

    private void indexLeaves(int[] counter) {
      if (isLeaf()) {
        if (label instanceof CoreLabel) {
          ((CoreLabel) label).set(CoreAnnotations.IndexAnnotation.class, counter[0]);
        }
        counter[0]++;
      } else {
        for (Tree c : children) {
          c.indexLeaves(counter);
        }
      }
    }

    Tree deepCopy(TreeFactory tf, LabelFactory lf) {
      Label newLabel = lf.newLabel(label.value());
      if (isLeaf()) {
        return tf.newTreeNode(newLabel, new ArrayList<>());
      }
      List<Tree> newChildren = new ArrayList<>();
      for (Tree c : children) {
        newChildren.add(c.deepCopy(tf, lf));
      }
      return tf.newTreeNode(newLabel, newChildren);
    }

    Tree treeSkeletonCopy() {
      List<Tree> newChildren = new ArrayList<>();
      for (Tree c : children) {
        newChildren.add(c.treeSkeletonCopy());
      }
      return new Tree(new StringLabel(label.value()), newChildren);
    }

    
    
    
    
    Set<Dependency<Label, Label, Object>> mapDependencies(Filter<Dependency<Label, Label, Object>> filter,
        HeadFinder hf) {
      return new HashSet<>();
    }

    Set<Dependency<Label, Label, Object>> mapDependencies(Filter<Dependency<Label, Label, Object>> filter,
        HeadFinder hf, String rootName) {
      return new HashSet<>();
    }

    void pennPrint(PrintWriter pw) {
      pennPrint(pw, 0);
    }

    private void pennPrint(PrintWriter pw, int depth) {
      if (isLeaf()) {
        pw.print(label.value());
        return;
      }
      pw.print("(" + label.value() + " ");
      for (int i = 0; i < children.size(); i++) {
        if (i > 0) {
          pw.print(" ");
        }
        children.get(i).pennPrint(pw, depth + 1);
      }
      pw.print(")");
    }

    void indentedListPrint(PrintWriter pw, boolean b) {
      indentedListPrint(pw, 0);
    }

    private void indentedListPrint(PrintWriter pw, int depth) {
      StringBuilder indent = new StringBuilder();
      for (int i = 0; i < depth; i++) {
        indent.append("  ");
      }
      pw.println(indent + label.value());
      for (Tree c : children) {
        c.indentedListPrint(pw, depth + 1);
      }
    }

    @Override
    public Iterator<Tree> iterator() {
      List<Tree> preorder = new ArrayList<>();
      collectPreorder(preorder);
      return preorder.iterator();
    }

    private void collectPreorder(List<Tree> acc) {
      acc.add(this);
      for (Tree c : children) {
        c.collectPreorder(acc);
      }
    }

    @Override
    public String toString() {
      StringWriter sw = new StringWriter();
      pennPrint(new PrintWriter(sw));
      return sw.toString();
    }
  }

  
  
  
  
  interface HeadFinder {
  }

  interface TreebankLanguagePack {
    boolean isStartSymbol(String s);
  }

  interface TreeVisitor {
    void visitTree(Tree t);
  }

  interface TreeTransformer {
    Tree transformTree(Tree t);
  }

  
  
  
  static class Trees {
    static Tree lexicalize(Tree t, HeadFinder hf) {
      
      
      
      return t;
    }
  }

  static class TreeFunctions {
    static Function<Tree, Tree> getLabeledToDescriptiveCoreLabelTreeFunction() {
      return t -> t;
    }

    static Function<Tree, Tree> getLabeledTreeToStringLabeledTreeFunction() {
      return t -> t;
    }
  }

  
  
  
  static class BobChrisTreeNormalizer {
    static class EmptyFilter implements Filter<Tree> {
      @Override
      public boolean accept(Tree t) {
        return t.isLeaf() && (t.label().value() == null || t.label().value().equals("-NONE-"));
      }
    }

    Tree normalizeWholeTree(Tree t, TreeFactory tf) {
      
      
      
      return t.deepCopy(tf, CoreLabel.factory());
    }
  }

  
  
  
  
  static class ChineseEnglishWordMap {
    private static final ChineseEnglishWordMap INSTANCE = new ChineseEnglishWordMap();

    static ChineseEnglishWordMap getInstance() {
      return INSTANCE;
    }

    String getFirstTranslation(String chinese) {
      
      
      return null;
    }
  }

  
  
  
  
  static class XMLUtils {
    static String escapeXML(String s) {
      if (s == null) {
        return "";
      }
      return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
  }

  static class Sentence {
    static String listToString(List<?> words, boolean b) {
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < words.size(); i++) {
        if (i > 0) {
          sb.append(' ');
        }
        Object item = words.get(i);
        sb.append(item instanceof Label ? ((Label) item).value() : String.valueOf(item));
      }
      return sb.toString();
    }

    static String listToString(List<TaggedWord> words) {
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < words.size(); i++) {
        if (i > 0) {
          sb.append(' ');
        }
        sb.append(words.get(i).toString());
      }
      return sb.toString();
    }
  }

  static class PTBTokenizer {
    static String ptb2Text(String s) {
      
      
      return s;
    }

    static String ptbToken2Text(String s) {
      return s;
    }
  }

  
  
  
  
  interface Dependency<G, D, N> {
    G governor();

    D dependent();

    String toString(String format);
  }

  static class UnnamedDependency implements Dependency<Label, Label, Object> {
    private final Label gov;
    private final Label dep;

    UnnamedDependency(Label gov, Label dep) {
      this.gov = gov;
      this.dep = dep;
    }

    @Override
    public Label governor() {
      return gov;
    }

    @Override
    public Label dependent() {
      return dep;
    }

    @Override
    public String toString(String format) {
      return "(" + format + ") " + governor().value() + " -> " + dependent().value();
    }

    @Override
    public String toString() {
      return toString("default");
    }
  }

  static class Dependencies {
    static <G, D, N> Comparator<Dependency<G, D, N>> dependencyIndexComparator() {
      
      
      
      return (d1, d2) -> 0;
    }
  }

  static class TypedDependency {
    private final String description;

    TypedDependency(String description) {
      this.description = description;
    }

    String toString(String format) {
      return "(" + format + ") " + description;
    }

    @Override
    public String toString() {
      return description;
    }
  }

  interface GrammaticalStructureFactory {
    GrammaticalStructure newGrammaticalStructure(Tree t);
  }

  static class GrammaticalStructure {
    
    
    
    java.util.Collection<TypedDependency> typedDependencies() {
      return new ArrayList<>();
    }

    java.util.Collection<TypedDependency> allTypedDependencies() {
      return new ArrayList<>();
    }

    java.util.Collection<TypedDependency> typedDependenciesCollapsed(boolean cc) {
      return new ArrayList<>();
    }

    java.util.Collection<TypedDependency> typedDependenciesCCprocessed(boolean cc) {
      return new ArrayList<>();
    }

    java.util.Collection<TypedDependency> typedDependenciesCollapsedTree() {
      return new ArrayList<>();
    }
  }

  
  
  
  Map<String, Object> formats = new HashMap<>();
  boolean removeEmpty = false;
  Properties options = new Properties();
  TreebankLanguagePack tlp = s -> s.equals("ROOT");
  TreeVisitor stemmer = null;
  boolean lexicalize = false;
  HeadFinder hf = new HeadFinder() {
  };
  boolean markHeadNodes = false;
  boolean transChinese = false;
  GrammaticalStructureFactory gsf = null;
  boolean basicDependencies = true;
  boolean nonCollapsedDependencies = false;
  boolean nonCollapsedDependenciesSeparated = false;
  boolean collapsedDependencies = false;
  boolean CCPropagatedDependencies = false;
  boolean treeDependencies = false;
  boolean ptb2text = false;
  String rootLabelOnlyFormat = "rootLabelOnly";
  Filter<Dependency<Label, Label, Object>> dependencyWordFilter = d -> true;
  Filter<Dependency<Label, Label, Object>> dependencyFilter = d -> true;

  boolean propertyToBoolean(Properties props, String key) {
    return Boolean.parseBoolean(props.getProperty(key, "false"));
  }

  
  
  
  Tree getCollocationProcessedTree(Tree t, HeadFinder hf) {
    return t;
  }

  
  
  Tree markHeadNodes(Tree t) {
    return t;
  }

  void print(java.util.Collection<TypedDependency> deps, String format, PrintWriter pw) {
    for (TypedDependency d : deps) {
      pw.println(d.toString(format));
    }
  }

  void print(java.util.Collection<TypedDependency> deps, PrintWriter pw) {
    for (TypedDependency d : deps) {
      pw.println(d.toString());
    }
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  private void printTreeInternal(final Tree t, final PrintWriter pw, final boolean inXml) {
    Tree outputTree = t;

    if (formats.containsKey("conll2007") || removeEmpty) {
      outputTree = outputTree.prune(new BobChrisTreeNormalizer.EmptyFilter());
    }

    if (formats.containsKey("words")) {
      if (inXml) {
        ArrayList<Label> sentUnstemmed = outputTree.yield();
        pw.println("  <words>");
        int i = 1;
        for (Label w : sentUnstemmed) {
          pw.println("    <word ind=\"" + i + "\">" + XMLUtils.escapeXML(w.value()) + "</word>");
          i++;
        }
        pw.println("  </words>");
      } else {
        String sent = Sentence.listToString(outputTree.yield(), false);
        if(ptb2text) {
          pw.println(PTBTokenizer.ptb2Text(sent));
        } else {
          pw.println(sent);
          pw.println();
        }
      }
    }

    if (propertyToBoolean(options, "removeTopBracket")) {
      String s = outputTree.label().value();
      if (tlp.isStartSymbol(s)) {
        if (outputTree.isUnaryRewrite()) {
          outputTree = outputTree.firstChild();
        } else {
          
          
          
          System.err.println("TreePrint: can't remove top bracket: not unary");
        }
      }
      
      
      
      
    }
    if (stemmer != null) {
      stemmer.visitTree(outputTree);
    }
    if (lexicalize) {
      outputTree = Trees.lexicalize(outputTree, hf);
      Function<Tree, Tree> a =
        TreeFunctions.getLabeledToDescriptiveCoreLabelTreeFunction();
      outputTree = a.apply(outputTree);
    }

    if (formats.containsKey("collocations")) {
      outputTree = getCollocationProcessedTree(outputTree, hf);
    }

    if (!lexicalize) { 
      Function<Tree, Tree> a =
        TreeFunctions.getLabeledTreeToStringLabeledTreeFunction();
      outputTree = a.apply(outputTree);
    }

    Tree outputPSTree = outputTree;  

    if (markHeadNodes) {
      outputPSTree = markHeadNodes(outputPSTree);
    }

    if (transChinese) {
      TreeTransformer tt = new TreeTransformer() {
        public Tree transformTree(Tree t) {
          t = t.treeSkeletonCopy();
          for (Tree subtree : t) {
            if (subtree.isLeaf()) {
              Label oldLabel = subtree.label();
              String translation = ChineseEnglishWordMap.getInstance().getFirstTranslation(oldLabel.value());
              if (translation == null) translation = "[UNK]";
              Label newLabel = new StringLabel(oldLabel.value() + ':' + translation);
              subtree.setLabel(newLabel);
            }
          }
          return t;
        }
      };
      outputPSTree = tt.transformTree(outputPSTree);
    }

    if (propertyToBoolean(options, "xml")) {
      if (formats.containsKey("wordsAndTags")) {
        ArrayList<TaggedWord> sent = outputTree.taggedYield();
        pw.println("  <words pos=\"true\">");
        int i = 1;
        for (TaggedWord tw : sent) {
          pw.println("    <word ind=\"" + i + "\" pos=\"" + XMLUtils.escapeXML(tw.tag()) + "\">" + XMLUtils.escapeXML(tw.word()) + "</word>");
          i++;
        }
        pw.println("  </words>");
      }
      if (formats.containsKey("penn")) {
        pw.println("  <tree style=\"penn\">");
        StringWriter sw = new StringWriter();
        PrintWriter psw = new PrintWriter(sw);
        outputPSTree.pennPrint(psw);
        pw.print(XMLUtils.escapeXML(sw.toString()));
        pw.println("  </tree>");
      }
      if (formats.containsKey("latexTree")) {
        pw.println("    <tree style=\"latexTrees\">");
        pw.println(".[");
        StringWriter sw = new StringWriter();
        PrintWriter psw = new PrintWriter(sw);
        outputTree.indentedListPrint(psw,false);
        pw.print(XMLUtils.escapeXML(sw.toString()));
        pw.println(".]");
        pw.println("  </tree>");
      }
      if (formats.containsKey("dependencies")) {
        Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                 CoreLabel.factory());
        indexedTree.indexLeaves();
        Set<Dependency<Label, Label, Object>> depsSet = indexedTree.mapDependencies(dependencyWordFilter, hf);
        List<Dependency<Label, Label, Object>> sortedDeps = new ArrayList<Dependency<Label, Label, Object>>(depsSet);
        Collections.sort(sortedDeps, Dependencies.dependencyIndexComparator());
        pw.println("<dependencies style=\"untyped\">");
        for (Dependency<Label, Label, Object> d : sortedDeps) {
          pw.println(d.toString("xml"));
        }
        pw.println("</dependencies>");
      }
      if (formats.containsKey("conll2007") || formats.containsKey("conllStyleDependencies")) {
        System.err.println("The \"conll2007\" and \"conllStyleDependencies\" formats are ignored in xml.");
      }
      if (formats.containsKey("typedDependencies")) {
        GrammaticalStructure gs = gsf.newGrammaticalStructure(outputTree);
        if (basicDependencies) {
          print(gs.typedDependencies(), "xml", pw);
        }
        if (nonCollapsedDependencies || nonCollapsedDependenciesSeparated) {
          print(gs.allTypedDependencies(), "xml", pw);
        }
        if (collapsedDependencies) {
          print(gs.typedDependenciesCollapsed(true), "xml", pw);
        }
        if (CCPropagatedDependencies) {
          print(gs.typedDependenciesCCprocessed(true), "xml", pw);
        }
        if(treeDependencies) {
          print(gs.typedDependenciesCollapsedTree(), "xml", pw);
        }
      }
      if (formats.containsKey("typedDependenciesCollapsed")) {
        GrammaticalStructure gs = gsf.newGrammaticalStructure(outputTree);
        print(gs.typedDependenciesCCprocessed(true), "xml", pw);
      }

      
      
      
      
      
    } else {
      
      if (formats.containsKey("wordsAndTags")) {
        pw.println(Sentence.listToString(outputTree.taggedYield(), false));
        pw.println();
      }
      if (formats.containsKey("oneline")) {
        pw.println(outputPSTree.toString());
      }
      if (formats.containsKey("penn")) {
        outputPSTree.pennPrint(pw);
        pw.println();
      }
      if (formats.containsKey(rootLabelOnlyFormat)) {
        pw.println(outputTree.label());
      }
      if (formats.containsKey("latexTree")) {
        pw.println(".[");
        outputTree.indentedListPrint(pw,false);
        pw.println(".]");
      }
      if (formats.containsKey("dependencies")) {
        
        Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                 CyclicCoreLabel.factory());
        indexedTree.indexLeaves();
        Set<Dependency<Label, Label, Object>> depsSet = indexedTree.mapDependencies(dependencyWordFilter, hf);
        List<Dependency<Label, Label, Object>> sortedDeps = new ArrayList<Dependency<Label, Label, Object>>(depsSet);
        Collections.sort(sortedDeps, Dependencies.dependencyIndexComparator());
        for (Dependency<Label, Label, Object> d : sortedDeps) {
          pw.println(d.toString("predicate"));
        }
        pw.println();
      }
      if (formats.containsKey("conll2007")) {
        
        
        
        
        

        Tree it = outputTree.deepCopy(outputTree.treeFactory(), CoreLabel.factory());
        it.indexLeaves();

        List<CoreLabel> tagged = it.taggedLabeledYield();
        Set<Dependency<Label, Label, Object>> depsSet = it.mapDependencies(dependencyFilter, hf, "root");
        List<Dependency<Label, Label, Object>> sortedDeps = new ArrayList<Dependency<Label, Label, Object>>(depsSet);
        Collections.sort(sortedDeps, Dependencies.dependencyIndexComparator());

        for (int i = 0; i < tagged.size(); i++) {
          CoreLabel w = tagged.get(i);
          Dependency<Label, Label, Object> d = sortedDeps.get(i);
          CoreMap dep = (CoreMap) d.dependent();
          CoreMap gov = (CoreMap) d.governor();

          Integer depi = dep.get(CoreAnnotations.IndexAnnotation.class);
          Integer govi = gov.get(CoreAnnotations.IndexAnnotation.class);

          
          String tag = PTBTokenizer.ptbToken2Text(w.tag());

          String word = PTBTokenizer.ptbToken2Text(w.word());
          String lemma = "_";
          String feats = "_";
          String pHead = "_";
          String pDepRel = "_";
          String depRel = (govi == 0) ? "ROOT" : "NULL";

          
          pw.printf("%d\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\t%s%n", depi,word,lemma,tag,tag,feats,govi,depRel,pHead,pDepRel);
        }
        pw.println();
      }
      if (formats.containsKey("conllStyleDependencies")) {
        
        BobChrisTreeNormalizer tn = new BobChrisTreeNormalizer();
        Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                 CoreLabel.factory());
        
        for (Tree node : indexedTree) {
          if (node.label().value().startsWith("NML")) {
            node.label().setValue("NP");
          }
        }

        indexedTree = tn.normalizeWholeTree(indexedTree, outputTree.treeFactory());
        indexedTree.indexLeaves();
        Set<Dependency<Label, Label, Object>> depsSet = null;
        boolean failed = false;
        try {
          depsSet = indexedTree.mapDependencies(dependencyFilter, hf);
        } catch (Exception e) {
          failed = true;
        }
        if (failed) {
          System.err.println("failed: ");
          System.err.println(t);
          System.err.println();
        } else {
          Map<Integer,Integer> deps = new HashMap<Integer, Integer>();
          for (Dependency<Label, Label, Object> dep : depsSet) {
            CoreLabel child = (CoreLabel)dep.dependent();
            CoreLabel parent = (CoreLabel)dep.governor();
            Integer childIndex =
              child.get(CoreAnnotations.IndexAnnotation.class);
            Integer parentIndex =
              parent.get(CoreAnnotations.IndexAnnotation.class);

            deps.put(childIndex, parentIndex);
          }
          boolean foundRoot = false;
          int index = 1;
          for (Tree node : indexedTree.getLeaves()) {
            String word = node.label().value();
            String tag = node.parent(indexedTree).label().value();
            int parent = 0;
            if (deps.containsKey(index)) {
              parent = deps.get(index);
            } else {
              if (foundRoot) { throw new RuntimeException(); }
              foundRoot = true;
            }
            pw.println(index+"\t"+word+"\t"+tag+"\t"+parent);
            index++;
          }
          pw.println();
        }
      }
      if (formats.containsKey("typedDependencies")) {
        GrammaticalStructure gs = gsf.newGrammaticalStructure(outputTree);
        if (basicDependencies) {
          print(gs.typedDependencies(), pw);
        }
        if (nonCollapsedDependencies) {
          print(gs.allTypedDependencies(), pw);
        }
        if (nonCollapsedDependenciesSeparated) {
          print(gs.allTypedDependencies(), "separator", pw);
        }
        if (collapsedDependencies) {
          print(gs.typedDependenciesCollapsed(true), pw);
        }
        if (CCPropagatedDependencies) {
          print(gs.typedDependenciesCCprocessed(true), pw);
        }
        if (treeDependencies) {
          print(gs.typedDependenciesCollapsedTree(), pw);
        }
      }
      if (formats.containsKey("typedDependenciesCollapsed")) {
        GrammaticalStructure gs = gsf.newGrammaticalStructure(outputTree);
        print(gs.typedDependenciesCCprocessed(true), pw);
      }
      
      
      
      
      
    }

    
    pw.flush();
  }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  interface Function<T, R> extends java.util.function.Function<T, R> {
  }

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: TreePrint.printTreeInternal ===");

    method_2_stanfordnlp_claude printer = new method_2_stanfordnlp_claude();

    
    Tree det = new Tree(new StringLabel("DT"), java.util.Collections.singletonList(new Tree(new StringLabel("The"))));
    Tree noun = new Tree(new StringLabel("NN"), java.util.Collections.singletonList(new Tree(new StringLabel("fox"))));
    Tree np = new Tree(new StringLabel("NP"), java.util.Arrays.asList(det, noun));
    Tree verb = new Tree(new StringLabel("VBZ"), java.util.Collections.singletonList(new Tree(new StringLabel("jumps"))));
    Tree vp = new Tree(new StringLabel("VP"), java.util.Collections.singletonList(verb));
    Tree s = new Tree(new StringLabel("S"), java.util.Arrays.asList(np, vp));
    Tree root = new Tree(new StringLabel("ROOT"), java.util.Collections.singletonList(s));

    
    printer.formats.put("penn", Boolean.TRUE);
    printer.formats.put("wordsAndTags", Boolean.TRUE);
    printer.formats.put("oneline", Boolean.TRUE);
    printer.options.setProperty("xml", "false");
    printer.options.setProperty("removeTopBracket", "false");

    StringWriter out = new StringWriter();
    PrintWriter pw = new PrintWriter(out);

    java.lang.reflect.Method target = method_2_stanfordnlp_claude.class.getDeclaredMethod(
        "printTreeInternal", Tree.class, PrintWriter.class, boolean.class);
    target.setAccessible(true);
    target.invoke(printer, root, pw, false);

    System.out.println("\n-- Scenario A output (non-XML: penn, wordsAndTags, oneline) --");
    System.out.println(out.toString());

    
    method_2_stanfordnlp_claude printerXml = new method_2_stanfordnlp_claude();
    printerXml.formats.put("penn", Boolean.TRUE);
    printerXml.formats.put("words", Boolean.TRUE);
    printerXml.options.setProperty("xml", "true");

    StringWriter outXml = new StringWriter();
    PrintWriter pwXml = new PrintWriter(outXml);
    target.invoke(printerXml, root, pwXml, true);

    System.out.println("-- Scenario B output (XML: penn, words) --");
    System.out.println(outXml.toString());

    System.out.println("=== Demo complete: method exercised the words/wordsAndTags/penn/oneline "
        + "formats in both XML and non-XML modes, the removeTopBracket/lexicalize/markHeadNodes "
        + "pass-through branches, and the reflection-driven call into the private target method. ===");
  }
}
