










































import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.zip.GZIPInputStream;

public class method_3_stanfordnlp_claude<IN> {

  
  
  
  
  interface AbstractSequenceClassifier<IN> {
    void train(Collection<List<IN>> docs, DocumentReaderAndWriter<IN> readerAndWriter);
  }

  
  
  
  static class Timing {
    private long startMs;

    void start() {
      startMs = System.currentTimeMillis();
    }

    long stop() {
      return System.currentTimeMillis() - startMs;
    }

    static String toSecondsString(long ms) {
      return String.format("%.3f", ms / 1000.0);
    }
  }

  
  
  
  interface DocumentReaderAndWriter<IN> {
  }

  
  
  
  static class Pair<A, B> {
    private final A a;
    private final B b;

    Pair(A a, B b) {
      this.a = a;
      this.b = b;
    }

    A first() {
      return a;
    }

    B second() {
      return b;
    }
  }

  
  
  
  
  interface Evaluator {
  }

  static class MemoryEvaluator implements Evaluator {
  }

  static class CRFClassifierEvaluator<IN> implements Evaluator {
    private final String name;
    private final method_3_stanfordnlp_claude<IN> classifier;
    private Object helperFunction;

    CRFClassifierEvaluator(String name, method_3_stanfordnlp_claude<IN> classifier) {
      this.name = name;
      this.classifier = classifier;
    }

    void setTestData(Object docs, List<Pair<int[][][], int[]>> dataAndLabels) {
      
      
    }

    void setEvalCmd(String cmd) {
    }

    void setHelperFunction(CRFLogConditionalObjectiveFunction func) {
      this.helperFunction = func;
    }
  }

  static class CRFFeatureExporter<IN> {
    private final method_3_stanfordnlp_claude<IN> classifier;

    CRFFeatureExporter(method_3_stanfordnlp_claude<IN> classifier) {
      this.classifier = classifier;
    }

    void printFeatures(String path, Collection<List<IN>> docs) {
      
      
      System.out.println("[CRFFeatureExporter] would export features for " + docs.size()
          + " document(s) to " + path);
    }
  }

  
  
  
  
  static class ObjectBank<T> extends ArrayList<T> {
  }

  
  
  
  static class IOUtils {
    static File writeObjectToTempFile(Object o, String suffix) throws IOException {
      File f = File.createTempFile("crf-feature-index", suffix);
      f.deleteOnExit();
      try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
        oos.writeObject(o);
      }
      return f;
    }

    static Object readObjectFromFile(File f) throws Exception {
      try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
        return ois.readObject();
      }
    }
  }

  
  
  
  interface Index<E> extends java.io.Serializable {
    int indexOf(E e);

    int size();
  }

  static class ArrayIndex<E> implements Index<E> {
    private static final long serialVersionUID = 1L;
    private final List<E> items = new ArrayList<>();

    @Override
    public int indexOf(E e) {
      int i = items.indexOf(e);
      if (i < 0) {
        items.add(e);
        return items.size() - 1;
      }
      return i;
    }

    @Override
    public int size() {
      return items.size();
    }

    @Override
    public String toString() {
      return items.toString();
    }
  }

  
  
  
  
  
  
  interface Minimizer {
    double[] minimize(CRFLogConditionalObjectiveFunction func, double tolerance, double[] initial);
  }

  interface FloatFunction {
  }

  static class ResultStoringFloatMonitor implements FloatFunction {
    ResultStoringFloatMonitor(int freq, String serializeTo) {
    }
  }

  static class CRFLogConditionalObjectiveFunction {
    int crfType;
    private final int[][][][] data;
    private final int[][] labels;

    CRFLogConditionalObjectiveFunction(int[][][][] data, int[][] labels, Index<String> featureIndex,
        int windowSize, Index<String> classIndex, Object labelIndices, Object map, String backgroundSymbol,
        double sigma) {
      this.data = data;
      this.labels = labels;
    }

    
    
    
    double[] initial() {
      int n = 0;
      for (int[][][] doc : data) {
        for (int[][] clique : doc) {
          for (int[] feats : clique) {
            n += feats.length;
          }
        }
      }
      return new double[Math.max(n, 1)];
    }

    double[][] to2D(double[] weights) {
      double[][] out = new double[weights.length][1];
      for (int i = 0; i < weights.length; i++) {
        out[i][0] = weights[i];
      }
      return out;
    }
  }

  static class CRFLogConditionalObjectiveFloatFunction {
    int crfType;
    private final int[][][][] data;

    CRFLogConditionalObjectiveFloatFunction(int[][][][] data, int[][] labels, Index<String> featureIndex,
        int windowSize, Index<String> classIndex, Object labelIndices, Object map, String backgroundSymbol,
        double sigma) {
      this.data = data;
    }

    float[] initial() {
      int n = 0;
      for (int[][][] doc : data) {
        for (int[][] clique : doc) {
          for (int[] feats : clique) {
            n += feats.length;
          }
        }
      }
      return new float[Math.max(n, 1)];
    }

    float[][] to2D(float[] weights) {
      float[][] out = new float[weights.length][1];
      for (int i = 0; i < weights.length; i++) {
        out[i][0] = weights[i];
      }
      return out;
    }
  }

  static class QNMinimizer {
    QNMinimizer() {
    }

    QNMinimizer(FloatFunction monitor) {
    }

    void setM(int m) {
    }

    
    
    
    float[] minimize(CRFLogConditionalObjectiveFloatFunction func, float tolerance, float[] initial) {
      return initial;
    }
  }

  static class StochasticDiffFunctionTester {
    StochasticDiffFunctionTester(CRFLogConditionalObjectiveFunction func) {
    }

    boolean testSumOfBatches(double[] initial, double tol) {
      return true;
    }
  }

  static class ArrayMath {
    static double[][] floatArrayToDoubleArray(float[][] in) {
      double[][] out = new double[in.length][];
      for (int i = 0; i < in.length; i++) {
        out[i] = new double[in[i].length];
        for (int j = 0; j < in[i].length; j++) {
          out[i][j] = in[i][j];
        }
      }
      return out;
    }
  }

  static class Convert {
    static float[] readFloatArr(DataInputStream dis) throws IOException {
      List<Float> vals = new ArrayList<>();
      try {
        while (true) {
          vals.add(dis.readFloat());
        }
      } catch (IOException eof) {
        
      }
      float[] out = new float[vals.size()];
      for (int i = 0; i < out.length; i++) {
        out[i] = vals.get(i);
      }
      return out;
    }

    static double[] readDoubleArr(DataInputStream dis) throws IOException {
      List<Double> vals = new ArrayList<>();
      try {
        while (true) {
          vals.add(dis.readDouble());
        }
      } catch (IOException eof) {
        
      }
      double[] out = new double[vals.size()];
      for (int i = 0; i < out.length; i++) {
        out[i] = vals.get(i);
      }
      return out;
    }
  }

  
  
  
  
  static class Flags {
    String exportFeatures = null;
    int numTimesPruneFeatures = 0;
    int evaluateIters = 0;
    boolean evaluateTrain = false;
    String testFile = null;
    String testFiles = null;
    String evalCmd = null;
    boolean saveFeatureIndexToDisk = false;
    String loadProcessedData = null;
    boolean useFloat = false;
    int crfType = 0;
    String backgroundSymbol = "O";
    double sigma = 1.0;
    int interimOutputFreq = 0;
    String serializeTo = null;
    int QNsize = 15;
    int QNsize2 = 15;
    String initialWeights = null;
    double tolerance = 1e-4;
    boolean testObjFunction = false;
    double featureDiffThresh = 0.0;
  }

  Flags flags = new Flags();
  Index<String> featureIndex = new ArrayIndex<>();
  int windowSize = 2;
  Index<String> classIndex = new ArrayIndex<>();
  Object labelIndices = new Object();
  Object map = new Object();
  double[][] weights;

  
  
  
  void makeAnswerArraysAndTagIndex(Collection<List<IN>> docs) {
    for (List<IN> doc : docs) {
      for (IN tok : doc) {
        classIndex.indexOf(String.valueOf(tok));
      }
    }
  }

  
  
  
  Pair<int[][][][], int[][]> documentsToDataAndLabels(Collection<List<IN>> docs) {
    List<int[][][]> dataList = new ArrayList<>();
    List<int[]> labelList = new ArrayList<>();
    for (List<IN> doc : docs) {
      int[][] clique = new int[doc.size()][];
      int[] docLabels = new int[doc.size()];
      for (int i = 0; i < doc.size(); i++) {
        int featIdx = featureIndex.indexOf(String.valueOf(doc.get(i)));
        clique[i] = new int[] { featIdx };
        docLabels[i] = classIndex.indexOf(String.valueOf(doc.get(i)));
      }
      dataList.add(new int[][][] { clique });
      labelList.add(docLabels);
    }
    return new Pair<>(dataList.toArray(new int[0][][][]), labelList.toArray(new int[0][]));
  }

  List<Pair<int[][][], int[]>> documentsToDataAndLabelsList(ObjectBank<List<IN>> docs) {
    List<Pair<int[][][], int[]>> result = new ArrayList<>();
    Pair<int[][][][], int[][]> dl = documentsToDataAndLabels(docs);
    for (int i = 0; i < dl.first().length; i++) {
      result.add(new Pair<>(dl.first()[i], dl.second()[i]));
    }
    return result;
  }

  ObjectBank<List<IN>> makeObjectBankFromFile(String file, DocumentReaderAndWriter<IN> readerAndWriter) {
    
    
    return new ObjectBank<>();
  }

  @SuppressWarnings("rawtypes")
  List loadProcessedData(String path) {
    return null;
  }

  @SuppressWarnings("rawtypes")
  void addProcessedData(List processedData, int[][][][] allData, int[][] allLabels, int offset) {
  }

  void dropFeaturesBelowThreshold(double thresh) {
    
    
  }

  Minimizer getMinimizer(int i, Evaluator[] evaluators) {
    
    
    return (func, tol, initial) -> initial;
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  @SuppressWarnings("unchecked")
  public void train(Collection<List<IN>> docs, DocumentReaderAndWriter<IN> readerAndWriter) {
    Timing timer = new Timing();
    timer.start();
    makeAnswerArraysAndTagIndex(docs);
    long elapsedMs = timer.stop();
    System.err.println("Time to convert docs to feature indices: " + Timing.toSecondsString(elapsedMs) + " seconds");
    if (flags.exportFeatures != null) {
      timer.start();
      CRFFeatureExporter<IN> featureExporter = new CRFFeatureExporter<IN>(this);
      featureExporter.printFeatures(flags.exportFeatures, docs);
      elapsedMs = timer.stop();
      System.err.println("Time to export features: " + Timing.toSecondsString(elapsedMs) + " seconds");
    }
    for (int i = 0; i <= flags.numTimesPruneFeatures; i++) {
      timer.start();
      Pair<int[][][][], int[][]> dataAndLabels = documentsToDataAndLabels(docs);
      elapsedMs = timer.stop();
      System.err.println("Time to convert docs to data/labels: " + Timing.toSecondsString(elapsedMs) + " seconds");

      Evaluator[] evaluators = null;
      if (flags.evaluateIters > 0) {
        List<Evaluator> evaluatorList = new ArrayList<Evaluator>();
        evaluatorList.add(new MemoryEvaluator());
        if (flags.evaluateTrain) {
          CRFClassifierEvaluator<IN> crfEvaluator = new CRFClassifierEvaluator<IN>("Train set", this);
          List<Pair<int[][][], int[]>> trainDataAndLabels = new ArrayList<Pair<int[][][], int[]>>();
          for (int j = 0; j < dataAndLabels.first().length; j++) {
            Pair<int[][][], int[]> p = new Pair<int[][][], int[]>(dataAndLabels.first()[j], dataAndLabels.second()[j]);
            trainDataAndLabels.add(p);
          }
          crfEvaluator.setTestData(docs, trainDataAndLabels);
          crfEvaluator.setEvalCmd(flags.evalCmd);
          evaluatorList.add(crfEvaluator);
        }
        if (flags.testFile != null) {
          CRFClassifierEvaluator<IN> crfEvaluator = new CRFClassifierEvaluator<IN>("Test set (" + flags.testFile + ")",
              this);
          ObjectBank<List<IN>> testObjBank = makeObjectBankFromFile(flags.testFile, readerAndWriter);
          List<Pair<int[][][], int[]>> testDataAndLabels = documentsToDataAndLabelsList(testObjBank);
          crfEvaluator.setTestData(testObjBank, testDataAndLabels);
          crfEvaluator.setEvalCmd(flags.evalCmd);
          evaluatorList.add(crfEvaluator);
        }
        if (flags.testFiles != null) {
          String[] testFiles = flags.testFiles.split(",");
          for (String testFile : testFiles) {
            CRFClassifierEvaluator<IN> crfEvaluator = new CRFClassifierEvaluator<IN>("Test set ("
                + testFile + ")", this);
            ObjectBank<List<IN>> testObjBank = makeObjectBankFromFile(testFile, readerAndWriter);
            List<Pair<int[][][], int[]>> testDataAndLabels = documentsToDataAndLabelsList(testObjBank);
            crfEvaluator.setTestData(testObjBank, testDataAndLabels);
            crfEvaluator.setEvalCmd(flags.evalCmd);
            evaluatorList.add(crfEvaluator);
          }
        }
        evaluators = new Evaluator[evaluatorList.size()];
        evaluatorList.toArray(evaluators);
      }

      if (flags.numTimesPruneFeatures == i) {
        docs = null; 
      }
      
      File featIndexFile = null;

      if (flags.saveFeatureIndexToDisk) {
        try {
          System.err.println("Writing feature index to temporary file.");
          featIndexFile = IOUtils.writeObjectToTempFile(featureIndex, "featIndex" + i + ".tmp");
          featureIndex = null;
        } catch (IOException e) {
          throw new RuntimeException("Could not open temporary feature index file for writing.");
        }
      }

      
      
      
      
      
      
      
      
      int[][][][] data = dataAndLabels.first();
      
      
      
      
      int[][] labels = dataAndLabels.second();

      if (flags.loadProcessedData != null) {
        List processedData = loadProcessedData(flags.loadProcessedData);
        if (processedData != null) {
          
          int[][][][] allData = new int[data.length + processedData.size()][][][];
          int[][] allLabels = new int[labels.length + processedData.size()][];
          System.arraycopy(data, 0, allData, 0, data.length);
          System.arraycopy(labels, 0, allLabels, 0, labels.length);
          
          addProcessedData(processedData, allData, allLabels, data.length);
          data = allData;
          labels = allLabels;
        }
      }

      if (flags.useFloat) {
        CRFLogConditionalObjectiveFloatFunction func = new CRFLogConditionalObjectiveFloatFunction(data, labels,
            featureIndex, windowSize, classIndex, labelIndices, map, flags.backgroundSymbol, flags.sigma);
        func.crfType = flags.crfType;

        QNMinimizer minimizer;
        if (flags.interimOutputFreq != 0) {
          FloatFunction monitor = new ResultStoringFloatMonitor(flags.interimOutputFreq, flags.serializeTo);
          minimizer = new QNMinimizer(monitor);
        } else {
          minimizer = new QNMinimizer();
        }

        if (i == 0) {
          minimizer.setM(flags.QNsize);
        } else {
          minimizer.setM(flags.QNsize2);
        }

        float[] initialWeights;
        if (flags.initialWeights == null) {
          initialWeights = func.initial();
        } else {
          try {
            System.err.println("Reading initial weights from file " + flags.initialWeights);
            DataInputStream dis = new DataInputStream(new BufferedInputStream(new GZIPInputStream(new FileInputStream(
                flags.initialWeights))));
            initialWeights = Convert.readFloatArr(dis);
          } catch (IOException e) {
            throw new RuntimeException("Could not read from float initial weight file " + flags.initialWeights);
          }
        }
        System.err.println("numWeights: " + initialWeights.length);
        float[] weights = minimizer.minimize(func, (float) flags.tolerance, initialWeights);
        this.weights = ArrayMath.floatArrayToDoubleArray(func.to2D(weights));

      } else {

        
































        CRFLogConditionalObjectiveFunction func = new CRFLogConditionalObjectiveFunction(data, labels, featureIndex,
            windowSize, classIndex, labelIndices, map, flags.backgroundSymbol, flags.sigma);
        func.crfType = flags.crfType;
        if (evaluators != null) {
          for (Evaluator eval : evaluators) {
            if (eval instanceof CRFClassifierEvaluator) {
              ((CRFClassifierEvaluator) eval).setHelperFunction(func);
            }
          }
        }
        Minimizer minimizer = getMinimizer(i, evaluators);

        double[] initialWeights;
        if (flags.initialWeights == null) {
          initialWeights = func.initial();
        } else {
          try {
            System.err.println("Reading initial weights from file " + flags.initialWeights);
            DataInputStream dis = new DataInputStream(new BufferedInputStream(new GZIPInputStream(new FileInputStream(
                flags.initialWeights))));
            initialWeights = Convert.readDoubleArr(dis);
          } catch (IOException e) {
            throw new RuntimeException("Could not read from double initial weight file " + flags.initialWeights);
          }
        }
        System.err.println("numWeights: " + initialWeights.length);

        if (flags.testObjFunction) {
          StochasticDiffFunctionTester tester = new StochasticDiffFunctionTester(func);
          if (tester.testSumOfBatches(initialWeights, 1e-4)) {
            System.err.println("Testing complete... exiting");
            System.exit(1);
          } else {
            System.err.println("Testing failed....exiting");
            System.exit(1);
          }

        }
        double[] weights = minimizer.minimize(func, flags.tolerance, initialWeights);
        this.weights = func.to2D(weights);
      }

      
      if (flags.saveFeatureIndexToDisk) {
        try {
          System.err.println("Reading temporary feature index file.");
          featureIndex = (Index<String>) IOUtils.readObjectFromFile(featIndexFile);
        } catch (Exception e) {
          throw new RuntimeException("Could not open temporary feature index file for reading.");
        }
      }

      if (i != flags.numTimesPruneFeatures) {
        dropFeaturesBelowThreshold(flags.featureDiffThresh);
        System.err.println("Removing features with weight below " + flags.featureDiffThresh + " and retraining...");
      }

    }
  }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: CRFClassifier.train ===");

    method_3_stanfordnlp_claude<String> classifier = new method_3_stanfordnlp_claude<>();

    
    Collection<List<String>> docs = new ArrayList<>();
    docs.add(new ArrayList<>(List.of("The", "fox", "jumps")));
    docs.add(new ArrayList<>(List.of("A", "dog", "barks")));
    docs.add(new ArrayList<>(List.of("The", "cat", "sleeps")));

    
    classifier.flags.numTimesPruneFeatures = 0;
    classifier.flags.evaluateIters = 0;
    classifier.flags.saveFeatureIndexToDisk = false;
    classifier.flags.useFloat = false;

    DocumentReaderAndWriter<String> rw = new DocumentReaderAndWriter<String>() {
    };

    classifier.train(docs, rw);

    System.out.println("\n-- After training (double / non-float path) --");
    System.out.println("featureIndex size: " + classifier.featureIndex.size());
    System.out.println("classIndex size:   " + classifier.classIndex.size());
    System.out.println("weights shape:     " + classifier.weights.length + " x "
        + (classifier.weights.length > 0 ? classifier.weights[0].length : 0));

    
    method_3_stanfordnlp_claude<String> classifier2 = new method_3_stanfordnlp_claude<>();
    classifier2.flags.useFloat = true;
    classifier2.flags.saveFeatureIndexToDisk = true;
    classifier2.flags.numTimesPruneFeatures = 0;
    classifier2.train(docs, rw);

    System.out.println("\n-- After training (float path + feature-index disk round-trip) --");
    System.out.println("featureIndex size: " + classifier2.featureIndex.size());
    System.out.println("weights shape:     " + classifier2.weights.length + " x "
        + (classifier2.weights.length > 0 ? classifier2.weights[0].length : 0));

    System.out.println("\n=== Demo complete: method exercised makeAnswerArraysAndTagIndex, "
        + "documentsToDataAndLabels, both the useFloat and non-float minimizer branches, and the "
        + "saveFeatureIndexToDisk write/read round-trip. ===");
  }
}
