











































import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class method_3_openengsb_claude {

    
    
    

    
    public abstract static class AbstractModel implements OpenEngSBModel {

        private static final long serialVersionUID = 1L;

        private final String id;
        private final List<OpenEngSBModelEntry> tail = new ArrayList<OpenEngSBModelEntry>();

        protected AbstractModel(String id) {
            this.id = id;
        }

        public List<OpenEngSBModelEntry> toOpenEngSBModelValues() {
            return new ArrayList<OpenEngSBModelEntry>();
        }

        public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
            return new ArrayList<OpenEngSBModelEntry>();
        }

        public Object retrieveInternalModelId() {
            return id;
        }

        public String retrieveInternalModelIdName() {
            return "id";
        }

        public Long retrieveInternalModelTimestamp() {
            return 0L;
        }

        public Integer retrieveInternalModelVersion() {
            return 1;
        }

        public void addOpenEngSBModelEntry(OpenEngSBModelEntry entry) {
            tail.add(entry);
        }

        public void removeOpenEngSBModelEntry(String key) {
        }

        public List<OpenEngSBModelEntry> getOpenEngSBModelTail() {
            return tail;
        }

        public void setOpenEngSBModelTail(List<OpenEngSBModelEntry> entries) {
            tail.clear();
            tail.addAll(entries);
        }

        public String retrieveModelName() {
            return getClass().getName();
        }

        public String retrieveModelVersion() {
            return "1.0.0";
        }

        @Override
        public String toString() {
            return getClass().getSimpleName() + "#" + id;
        }
    }

    public static class PersonModel extends AbstractModel {
        private static final long serialVersionUID = 1L;

        public PersonModel(String id) {
            super(id);
        }
    }

    public static class ProjectModel extends AbstractModel {
        private static final long serialVersionUID = 1L;

        public ProjectModel(String id) {
            super(id);
        }
    }

    public static class TaskModel extends AbstractModel {
        private static final long serialVersionUID = 1L;

        public TaskModel(String id) {
            super(id);
        }
    }

    
    
    

    public static void main(String[] args) {
        title("METHOD 3  |  CommitConverter.convert(EKBCommit)");

        ContextHolder.get().setCurrentContextId("testcontext");

        section("1. a full commit - inserts, updates and deletes of several model types");
        final CommitConverter converter =
                new CommitConverter(new SimpleAuthenticationContext("alice"), ContextHolder.get());

        final UUID revision = UUID.fromString("11111111-2222-3333-4444-555555555555");
        final UUID parentRevision = UUID.fromString("00000000-1111-2222-3333-444444444444");

        final EKBCommit ekbCommit = new EKBCommit()
                .addInsert(new PersonModel("person-1"))
                .addInsert(new PersonModel("person-2"))
                .addInsert(new ProjectModel("project-1"))
                .addUpdate(new ProjectModel("project-1"))
                .addUpdate(new TaskModel("task-7"))
                .addDelete(new TaskModel("task-9"));
        ekbCommit.setRevisionNumber(revision);
        ekbCommit.setParentRevisionNumber(parentRevision);
        ekbCommit.setDomainId("example-domain");
        ekbCommit.setConnectorId("example-connector");
        ekbCommit.setInstanceId("instance-1");

        final long before = System.currentTimeMillis();
        final IndexCommit commit = converter.convert(ekbCommit);
        final long after = System.currentTimeMillis();
        dump(commit);
        System.out.println("      timestamp was created inside the method : "
                + (commit.getTimestamp().getTime() >= before && commit.getTimestamp().getTime() <= after));

        section("2. the model classes and the per class grouping produced by the method");
        System.out.println("      modelClasses (a Set, so each type appears once):");
        for (Class<?> type : sorted(commit.getModelClasses())) {
            System.out.println("        " + type.getSimpleName());
        }
        System.out.println("      inserts grouped by class:");
        dumpGroups(commit.getInserts());
        System.out.println("      updates grouped by class:");
        dumpGroups(commit.getUpdates());
        System.out.println("      deletes grouped by class:");
        dumpGroups(commit.getDeletes());

        section("3. an empty commit - the three lists are empty, so the maps are empty too");
        final EKBCommit empty = new EKBCommit();
        empty.setRevisionNumber(UUID.fromString("99999999-8888-7777-6666-555555555555"));
        empty.setDomainId("empty-domain");
        empty.setConnectorId("empty-connector");
        empty.setInstanceId("instance-0");
        final IndexCommit emptyCommit = converter.convert(empty);
        dump(emptyCommit);
        System.out.println("      parentCommitId is null because the EKBCommit had no parent revision");

        section("4. no AuthenticationContext - getUser() logs and returns an empty user");
        final IndexCommit noUser = new CommitConverter(null, ContextHolder.get()).convert(ekbCommit);
        System.out.println("      user       = \"" + noUser.getUser() + "\"");
        System.out.println("      contextId  = \"" + noUser.getContextId() + "\"");

        section("5. an AuthenticationContext with no authenticated principal");
        final IndexCommit anonymous =
                new CommitConverter(new SimpleAuthenticationContext(null), ContextHolder.get()).convert(ekbCommit);
        System.out.println("      user       = \"" + anonymous.getUser() + "\"");

        section("6. no ContextHolder, and an empty contextId - both getContextId() guards");
        final IndexCommit noContext =
                new CommitConverter(new SimpleAuthenticationContext("alice"), null).convert(ekbCommit);
        System.out.println("      contextId  = \"" + noContext.getContextId() + "\"");
        ContextHolder.get().setCurrentContextId("");
        final IndexCommit emptyContext = converter.convert(ekbCommit);
        System.out.println("      contextId  = \"" + emptyContext.getContextId() + "\"");
        ContextHolder.get().setCurrentContextId("testcontext");

        section("7. a principal that is neither a String nor null - the UnsupportedOperationException");
        try {
            new CommitConverter(new SimpleAuthenticationContext(Integer.valueOf(7)), ContextHolder.get())
                    .convert(ekbCommit);
            System.out.println("      !! the expected exception was not thrown");
        } catch (final UnsupportedOperationException e) {
            System.out.println("      expected UnsupportedOperationException: " + e.getMessage());
        }

        section("8. branch coverage summary");
        System.out.println("      every statement of the target method ran in scenario 1: all eleven setters,");
        System.out.println("      extractTypes over the three lists, and mapByClass three times.");
        System.out.println("      The branches live in the helpers the method calls, and each was driven:");
        System.out.println("        getUser: authenticationContext == null           -> scenario 4");
        System.out.println("        getUser: principal == null                       -> scenario 5");
        System.out.println("        getUser: principal instanceof String             -> scenario 1");
        System.out.println("        getUser: any other principal type                -> scenario 7");
        System.out.println("        getContextId: contextHolder == null              -> scenario 6");
        System.out.println("        getContextId: StringUtils.isEmpty(contextId)     -> scenario 6");
        System.out.println("        getContextId: a real contextId                   -> scenario 1");
        System.out.println("        extractTypes / mapByClass over empty collections -> scenario 3");

        title("END OF METHOD 3 SCENARIOS");
    }

    static void dump(IndexCommit commit) {
        System.out.println("      commitId         = " + commit.getCommitId());
        System.out.println("      parentCommitId   = " + commit.getParentCommitId());
        System.out.println("      connectorId      = " + commit.getConnectorId());
        System.out.println("      domainId         = " + commit.getDomainId());
        System.out.println("      instanceId       = " + commit.getInstanceId());
        System.out.println("      timestamp        = " + commit.getTimestamp());
        System.out.println("      user             = \"" + commit.getUser() + "\"");
        System.out.println("      contextId        = \"" + commit.getContextId() + "\"");
        System.out.println("      modelClasses     = " + commit.getModelClasses().size() + " type(s)");
        System.out.println("      inserts/updates/deletes groups = " + commit.getInserts().size() + " / "
                + commit.getUpdates().size() + " / " + commit.getDeletes().size());
    }

    static void dumpGroups(Map<Class<?>, List<OpenEngSBModel>> groups) {
        if (groups.isEmpty()) {
            System.out.println("        (none)");
            return;
        }
        for (Class<?> type : sorted(groups.keySet())) {
            System.out.println("        " + type.getSimpleName() + " -> " + groups.get(type));
        }
    }

    static List<Class<?>> sorted(Set<Class<?>> types) {
        final List<Class<?>> list = new ArrayList<Class<?>>(types);
        java.util.Collections.sort(list, new java.util.Comparator<Class<?>>() {
            public int compare(Class<?> a, Class<?> b) {
                return a.getSimpleName().compareTo(b.getSimpleName());
            }
        });
        return list;
    }

    
    static final class SimpleAuthenticationContext implements AuthenticationContext {

        private Object principal;

        SimpleAuthenticationContext(Object principal) {
            this.principal = principal;
        }

        public void login(String username, Object credentials) {
            this.principal = username;
        }

        public void logout() {
            this.principal = null;
        }

        public Object getAuthenticatedPrincipal() {
            return principal;
        }

        public List<Object> getAllAuthenticatedPrincipals() {
            final List<Object> all = new ArrayList<Object>();
            if (principal != null) {
                all.add(principal);
            }
            return all;
        }
    }

    static void title(String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}





class OpenEngSBModelEntry implements Serializable {

    private static final long serialVersionUID = 1L;

    private String key;
    private Object value;
    private Class<?> type;

    public OpenEngSBModelEntry() {
    }

    public OpenEngSBModelEntry(String key, Object value, Class<?> type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public Object getValue() {
        return value;
    }

    public Class<?> getType() {
        return type;
    }

    @Override
    public String toString() {
        return String.format("%s: %s (%s)", key, value, type);
    }
}





interface OpenEngSBModel extends Serializable {

    List<OpenEngSBModelEntry> toOpenEngSBModelValues();

    List<OpenEngSBModelEntry> toOpenEngSBModelEntries();

    Object retrieveInternalModelId();

    String retrieveInternalModelIdName();

    Long retrieveInternalModelTimestamp();

    Integer retrieveInternalModelVersion();

    void addOpenEngSBModelEntry(OpenEngSBModelEntry entry);

    void removeOpenEngSBModelEntry(String key);

    List<OpenEngSBModelEntry> getOpenEngSBModelTail();

    void setOpenEngSBModelTail(List<OpenEngSBModelEntry> entries);

    String retrieveModelName();

    String retrieveModelVersion();
}





final class ContextHolder {

    private static ContextHolder instance = new ContextHolder();

    private ThreadLocal<String> currentContextId = new InheritableThreadLocal<String>();

    public static ContextHolder get() {
        return instance;
    }

    public void setCurrentContextId(String value) {
        currentContextId.set(value);
    }

    public String getCurrentContextId() {
        return currentContextId.get();
    }

    private ContextHolder() {
    }
}






interface AuthenticationContext {

    void login(String username, Object credentials);

    void logout();

    Object getAuthenticatedPrincipal();

    List<Object> getAllAuthenticatedPrincipals();
}







class EKBCommit {

    private UUID revisionNumber;
    private UUID parentRevisionNumber;

    private List<OpenEngSBModel> inserts = new ArrayList<OpenEngSBModel>();
    private List<OpenEngSBModel> updates = new ArrayList<OpenEngSBModel>();
    private List<OpenEngSBModel> deletes = new ArrayList<OpenEngSBModel>();

    private String domainId;
    private String connectorId;
    private String instanceId;
    private String comment;

    public EKBCommit addInsert(Object insert) {
        if (insert != null) {
            inserts.add((OpenEngSBModel) insert);
        }
        return this;
    }

    public EKBCommit addUpdate(Object update) {
        if (update != null) {
            updates.add((OpenEngSBModel) update);
        }
        return this;
    }

    public EKBCommit addDelete(Object delete) {
        if (delete != null) {
            deletes.add((OpenEngSBModel) delete);
        }
        return this;
    }

    public List<OpenEngSBModel> getInserts() {
        return inserts;
    }

    public List<OpenEngSBModel> getUpdates() {
        return updates;
    }

    public List<OpenEngSBModel> getDeletes() {
        return deletes;
    }

    public String getDomainId() {
        return domainId;
    }

    public EKBCommit setDomainId(String domainId) {
        this.domainId = domainId;
        return this;
    }

    public String getConnectorId() {
        return connectorId;
    }

    public EKBCommit setConnectorId(String connectorId) {
        this.connectorId = connectorId;
        return this;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public EKBCommit setInstanceId(String instanceId) {
        this.instanceId = instanceId;
        return this;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public UUID getParentRevisionNumber() {
        return parentRevisionNumber;
    }

    public void setParentRevisionNumber(UUID parentRevisionNumber) {
        this.parentRevisionNumber = parentRevisionNumber;
    }

    public UUID getRevisionNumber() {
        return revisionNumber;
    }

    public void setRevisionNumber(UUID revisionNumber) {
        this.revisionNumber = revisionNumber;
    }
}






class IndexCommit {

    private UUID commitId;
    private UUID parentCommitId;
    private Date timestamp;

    private String user;
    private String contextId;

    private String connectorId;
    private String domainId;
    private String instanceId;

    private Set<Class<?>> modelClasses;

    private Map<Class<?>, List<OpenEngSBModel>> inserts;
    private Map<Class<?>, List<OpenEngSBModel>> updates;
    private Map<Class<?>, List<OpenEngSBModel>> deletes;

    public UUID getCommitId() {
        return commitId;
    }

    public void setCommitId(UUID commitId) {
        this.commitId = commitId;
    }

    public UUID getParentCommitId() {
        return parentCommitId;
    }

    public void setParentCommitId(UUID parentCommitId) {
        this.parentCommitId = parentCommitId;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getContextId() {
        return contextId;
    }

    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    public String getConnectorId() {
        return connectorId;
    }

    public void setConnectorId(String connectorId) {
        this.connectorId = connectorId;
    }

    public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public Set<Class<?>> getModelClasses() {
        return modelClasses;
    }

    public void setModelClasses(Set<Class<?>> modelClasses) {
        this.modelClasses = modelClasses;
    }

    public Map<Class<?>, List<OpenEngSBModel>> getInserts() {
        return inserts;
    }

    public void setInserts(Map<Class<?>, List<OpenEngSBModel>> inserts) {
        this.inserts = inserts;
    }

    public Map<Class<?>, List<OpenEngSBModel>> getUpdates() {
        return updates;
    }

    public void setUpdates(Map<Class<?>, List<OpenEngSBModel>> updates) {
        this.updates = updates;
    }

    public Map<Class<?>, List<OpenEngSBModel>> getDeletes() {
        return deletes;
    }

    public void setDeletes(Map<Class<?>, List<OpenEngSBModel>> deletes) {
        this.deletes = deletes;
    }
}






final class CollectionUtilsExtended {

    private CollectionUtilsExtended() {
    }

    public static <K, V> Map<K, List<V>> group(Collection<V> collection, Function<V, K> keyFn) {
        Map<K, List<V>> map = new HashMap<>();

        for (V value : collection) {
            K key = keyFn.apply(value);

            if (map.get(key) == null) {
                map.put(key, new ArrayList<V>());
            }

            map.get(key).add(value);
        }

        return map;
    }
}









interface Function<F, T> {

    T apply(F input);
}


final class StringUtils {

    private StringUtils() {
    }

    public static boolean isEmpty(final CharSequence cs) {
        return cs == null || cs.length() == 0;
    }

    public static boolean isNotEmpty(final CharSequence cs) {
        return !isEmpty(cs);
    }
}


interface Logger {

    void debug(String format, Object... arguments);

    void info(String format, Object... arguments);

    void warn(String msg);

    void warn(String format, Object... arguments);

    void error(String format, Object... arguments);
}


final class LoggerFactory {

    private LoggerFactory() {
    }

    static Logger getLogger(final Class<?> clazz) {
        final String name = clazz.getSimpleName();
        return new Logger() {
            private void print(final String level, final String format, final Object[] args) {
                System.out.println("      [" + level + "] " + name + " - " + expand(format, args));
            }

            private String expand(final String format, final Object[] args) {
                if (format == null || args == null || args.length == 0) {
                    return String.valueOf(format);
                }
                final StringBuilder sb = new StringBuilder();
                int from = 0;
                int arg = 0;
                while (arg < args.length) {
                    final int at = format.indexOf("{}", from);
                    if (at < 0) {
                        break;
                    }
                    sb.append(format, from, at).append(args[arg++]);
                    from = at + 2;
                }
                return sb.append(format.substring(from)).toString();
            }

            public void debug(String format, Object... arguments) {
                print("DEBUG", format, arguments);
            }

            public void info(String format, Object... arguments) {
                print("INFO ", format, arguments);
            }

            public void warn(String msg) {
                print("WARN ", msg, null);
            }

            public void warn(String format, Object... arguments) {
                print("WARN ", format, arguments);
            }

            public void error(String format, Object... arguments) {
                print("ERROR", format, arguments);
            }
        };
    }
}








class CommitConverter {

    private static final Logger LOG = LoggerFactory.getLogger(CommitConverter.class);

    private AuthenticationContext authenticationContext;
    private ContextHolder contextHolder;

    public CommitConverter(AuthenticationContext authenticationContext, ContextHolder contextHolder) {
        this.authenticationContext = authenticationContext;
        this.contextHolder = contextHolder;
    }

    
    public IndexCommit convert(EKBCommit ekbCommit) {
        IndexCommit commit = new IndexCommit();

        commit.setCommitId(ekbCommit.getRevisionNumber());
        commit.setParentCommitId(ekbCommit.getParentRevisionNumber());
        commit.setConnectorId(ekbCommit.getConnectorId());
        commit.setDomainId(ekbCommit.getDomainId());
        commit.setInstanceId(ekbCommit.getInstanceId());
        commit.setTimestamp(new Date());

        commit.setUser(getUser());
        commit.setContextId(getContextId());

        List<OpenEngSBModel> inserts = ekbCommit.getInserts();
        List<OpenEngSBModel> updates = ekbCommit.getUpdates();
        List<OpenEngSBModel> deletes = ekbCommit.getDeletes();

        Set<Class<?>> modelClasses = extractTypes(inserts, updates, deletes);

        commit.setModelClasses(modelClasses);

        commit.setInserts(mapByClass(inserts));
        commit.setUpdates(mapByClass(updates));
        commit.setDeletes(mapByClass(deletes));

        return commit;
    }
    

    protected Map<Class<?>, List<OpenEngSBModel>> mapByClass(Collection<OpenEngSBModel> models) {
        return CollectionUtilsExtended.group(models, new Function<OpenEngSBModel, Class<?>>() {
            @Override
            public Class<?> apply(OpenEngSBModel input) {
                return input.getClass();
            }
        });
    }

    protected Set<Class<?>> extractTypes(Collection<OpenEngSBModel> inserts, Collection<OpenEngSBModel> updates,
            Collection<OpenEngSBModel> deletes) {
        Set<Class<?>> types = new HashSet<>();

        extractTypesInto(inserts, types);
        extractTypesInto(updates, types);
        extractTypesInto(deletes, types);

        return types;
    }

    private void extractTypesInto(Collection<OpenEngSBModel> models, Set<Class<?>> types) {
        for (OpenEngSBModel model : models) {
            types.add(model.getClass());
        }
    }

    protected String getUser() {
        if (authenticationContext == null) {
            LOG.warn("AuthenticationContext not available, unable to retrieve current user");
            return "";
        }

        Object principal = authenticationContext.getAuthenticatedPrincipal();

        if (principal == null) {
            LOG.warn("AuthenticationContext did not return an authenticated principal");
            return "";
        } else if (principal instanceof String) {
            return (String) principal;
        } else {
            throw new UnsupportedOperationException("Can not handle principles of type " + principal.getClass());
        }
    }

    protected String getContextId() {
        if (contextHolder == null) {
            LOG.warn("ContextHolder not available, unable to retrieve current contextId");
            return "";
        }

        String contextId = contextHolder.getCurrentContextId();

        if (StringUtils.isEmpty(contextId)) {
            LOG.warn("ContextHolder returned empty contextId");
            return "";
        }

        return contextId;
    }
}
