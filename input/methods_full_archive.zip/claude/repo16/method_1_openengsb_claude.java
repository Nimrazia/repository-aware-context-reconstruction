











































import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class method_1_openengsb_claude {

    
    
    
    
    

    public static class SimpleModel implements OpenEngSBModel {

        private static final long serialVersionUID = 1L;

        private final String id;
        private final String modelName;
        private final String modelVersion;
        private final Map<String, OpenEngSBModelEntry> entries = new LinkedHashMap<String, OpenEngSBModelEntry>();
        private final List<OpenEngSBModelEntry> tail = new ArrayList<OpenEngSBModelEntry>();

        public SimpleModel(String id) {
            this(id, "org.openengsb.example.SimpleModel", "1.0.0");
        }

        public SimpleModel(String id, String modelName, String modelVersion) {
            this.id = id;
            this.modelName = modelName;
            this.modelVersion = modelVersion;
        }

        public SimpleModel set(String key, Object value, Class<?> type) {
            entries.put(key, new OpenEngSBModelEntry(key, value, type));
            return this;
        }

        public List<OpenEngSBModelEntry> toOpenEngSBModelValues() {
            return new ArrayList<OpenEngSBModelEntry>(entries.values());
        }

        public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
            return new ArrayList<OpenEngSBModelEntry>(entries.values());
        }

        public Object retrieveInternalModelId() {
            return id;
        }

        public String retrieveInternalModelIdName() {
            return "id";
        }

        public Long retrieveInternalModelTimestamp() {
            return 0L;
        }

        public Integer retrieveInternalModelVersion() {
            return 1;
        }

        public void addOpenEngSBModelEntry(OpenEngSBModelEntry entry) {
            entries.put(entry.getKey(), entry);
        }

        public void removeOpenEngSBModelEntry(String key) {
            entries.remove(key);
        }

        public List<OpenEngSBModelEntry> getOpenEngSBModelTail() {
            return tail;
        }

        public void setOpenEngSBModelTail(List<OpenEngSBModelEntry> newEntries) {
            tail.clear();
            tail.addAll(newEntries);
        }

        public String retrieveModelName() {
            return modelName;
        }

        public String retrieveModelVersion() {
            return modelVersion;
        }

        @Override
        public String toString() {
            return modelName + "#" + id;
        }
    }

    




    public static class EngineeringObjectModel extends SimpleModel {

        private static final long serialVersionUID = 1L;

        @OpenEngSBForeignKey(modelType = SimpleModel.class, modelVersion = "1.0.0")
        private String sourceReference;

        @OpenEngSBForeignKey(modelType = SimpleModel.class, modelVersion = "2.0.0")
        private String targetReference;

        private String notAReference;

        public EngineeringObjectModel(String id, String sourceReference, String targetReference) {
            super(id, "org.openengsb.example.EngineeringObjectModel", "1.0.0");
            this.sourceReference = sourceReference;
            this.targetReference = targetReference;
            this.notAReference = "ignored by the EO scan";
        }
    }

    public enum Priority {
        LOW, HIGH
    }

    
    
    

    public static void main(String[] args) throws Exception {
        title("METHOD 1  |  EDBConverter.convertSubModel(OpenEngSBModel, List<EDBObject>, ConnectorInformation)");

        ContextHolder.get().setCurrentContextId("testcontext");
        final ConnectorInformation info = new ConnectorInformation("example-domain", "example-connector", "instance-1");
        final EDBConverter converter = new EDBConverter(new InMemoryEngineeringDatabaseService());

        section("1. a flat model - the plain 'else' branch plus the six trailing entries");
        SimpleModel flat = new SimpleModel("flat-1")
                .set("name", "flat model", String.class)
                .set("count", Integer.valueOf(7), Integer.class)
                .set("active", Boolean.TRUE, Boolean.class)
                .set("missing", null, String.class);
        dump(converter.convertModelToEDBObject(flat, info));
        System.out.println("      the entry with a null value was skipped by the first branch");

        section("2. a nested sub model - the recursive OpenEngSBModel branch");
        SimpleModel child = new SimpleModel("child-1").set("name", "child", String.class);
        SimpleModel parent = new SimpleModel("parent-1")
                .set("name", "parent", String.class)
                .set("child", child, SimpleModel.class);
        dump(converter.convertModelToEDBObject(parent, info));
        System.out.println("      two EDBObjects were produced: the child was converted first and the");
        System.out.println("      parent stores only its OID, which is what convertSubModel returns");

        section("3. a List of plain values and a List of models");
        SimpleModel listModel = new SimpleModel("list-1")
                .set("tags", Arrays.asList("alpha", "beta", "gamma"), List.class)
                .set("children", Arrays.asList(new SimpleModel("kid-1"), new SimpleModel("kid-2")), List.class)
                .set("empty", new ArrayList<String>(), List.class);
        dump(converter.convertModelToEDBObject(listModel, info));
        System.out.println("      the empty list hit the 'list.size() == 0' continue branch");

        section("4. an array of plain values and an array of models");
        SimpleModel arrayModel = new SimpleModel("array-1")
                .set("codes", new String[] { "A", "B" }, String[].class)
                .set("models", new SimpleModel[] { new SimpleModel("arr-1") }, SimpleModel[].class)
                .set("emptyArray", new String[0], String[].class);
        dump(converter.convertModelToEDBObject(arrayModel, info));
        System.out.println("      the empty array hit the 'array.length == 0' continue branch");

        section("5. a Map with plain keys and values, and a Map whose values are models");
        Map<String, String> plainMap = new LinkedHashMap<String, String>();
        plainMap.put("env", "production");
        plainMap.put("region", "eu");
        Map<String, SimpleModel> modelMap = new LinkedHashMap<String, SimpleModel>();
        modelMap.put("primary", new SimpleModel("map-1"));
        SimpleModel mapModel = new SimpleModel("map-owner")
                .set("labels", plainMap, Map.class)
                .set("linked", modelMap, Map.class)
                .set("emptyMap", new HashMap<String, String>(), Map.class);
        dump(converter.convertModelToEDBObject(mapModel, info));
        System.out.println("      the empty map hit the 'map.size() == 0' continue branch");

        section("6. a FileWrapper property - Base64 encoding plus the .filename companion entry");
        FileWrapper wrapper = new FileWrapper("openengsb reconstruction payload".getBytes("UTF-8"),
                "payload.txt");
        SimpleModel fileModel = new SimpleModel("file-1").set("attachment", wrapper, FileWrapper.class);
        List<EDBObject> fileObjects = converter.convertModelToEDBObject(fileModel, info);
        dump(fileObjects);
        String encoded = (String) fileObjects.get(0).getObject("attachment");
        System.out.println("      decoded again : \"" + new String(Base64.decodeBase64(encoded), "UTF-8") + "\"");

        section("7. an Engineering Object - fillEDBObjectWithEngineeringObjectInformation runs");
        EngineeringObjectModel eo = new EngineeringObjectModel("eo-1", "source/42", "target/99");
        dump(converter.convertModelToEDBObject(eo, info));
        System.out.println("      both refersTo_ entries were written by the helper, and the field that");
        System.out.println("      carries no @OpenEngSBForeignKey was skipped");

        section("8. a deeply nested graph - the recursion goes three levels down");
        SimpleModel level3 = new SimpleModel("l3").set("name", "leaf", String.class);
        SimpleModel level2 = new SimpleModel("l2").set("next", level3, SimpleModel.class);
        SimpleModel level1 = new SimpleModel("l1").set("next", level2, SimpleModel.class);
        List<EDBObject> deep = converter.convertModelToEDBObject(level1, info);
        System.out.println("      EDBObjects produced : " + deep.size() + "   (one per level, deepest first)");
        for (EDBObject o : deep) {
            System.out.println("        " + o.getOID());
        }

        section("9. branches not exercised, and why");
        System.out.println("      * the IOException catch around the FileWrapper branch needs a FileWrapper");
        System.out.println("        whose file can not be read; the wrappers above already hold their bytes,");
        System.out.println("        so getContent() never touches the disk.");
        System.out.println("      * the IllegalAccessException catch that rethrows EKBException needs");
        System.out.println("        FieldUtils.readField to fail; it is called with forceAccess = true, so a");
        System.out.println("        private field is made accessible and the call succeeds.");
        System.out.println("      Both code paths are present and unchanged inside the markers.");

        title("END OF METHOD 1 SCENARIOS");
    }

    
    static final class InMemoryEngineeringDatabaseService implements EngineeringDatabaseService {

        private final Map<String, EDBObject> store = new LinkedHashMap<String, EDBObject>();

        public EDBObject getObject(String oid) {
            final EDBObject found = store.get(oid);
            if (found == null) {
                throw new EDBException("No object with the oid " + oid + " was found");
            }
            return found;
        }

        public EDBObject getObject(String oid, Long timestamp) {
            return getObject(oid);
        }

        public List<EDBObject> getObjects(List<String> oids) {
            final List<EDBObject> result = new ArrayList<EDBObject>();
            for (String oid : oids) {
                result.add(getObject(oid));
            }
            return result;
        }

        void put(EDBObject object) {
            store.put(object.getOID(), object);
        }
    }

    static void dump(List<EDBObject> objects) {
        System.out.println("      EDBObjects produced : " + objects.size());
        for (EDBObject object : objects) {
            System.out.println("      --- " + object.getOID() + " ---");
            final List<String> keys = new ArrayList<String>(object.keySet());
            java.util.Collections.sort(keys);
            for (String key : keys) {
                final EDBObjectEntry entry = object.get(key);
                String value = String.valueOf(entry.getValue());
                if (value.length() > 60) {
                    value = value.substring(0, 57) + "...";
                }
                System.out.println("          " + pad(key) + " = " + pad2(value) + "  [" + entry.getType() + "]");
            }
        }
    }

    static String pad(String s) {
        final StringBuilder sb = new StringBuilder(s);
        while (sb.length() < 26) {
            sb.append(' ');
        }
        return sb.toString();
    }

    static String pad2(String s) {
        final StringBuilder sb = new StringBuilder(s);
        while (sb.length() < 34) {
            sb.append(' ');
        }
        return sb.toString();
    }

    static void title(String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}








class EDBConverter {

    private static final Logger LOGGER = LoggerFactory.getLogger(EDBConverter.class);

    public static final String FILEWRAPPER_FILENAME_SUFFIX = ".filename";
    public static final String REFERENCE_PREFIX = "refersTo_";

    private EngineeringDatabaseService edbService;

    public EDBConverter(EngineeringDatabaseService edbService) {
        this.edbService = edbService;
    }

    


    public List<EDBObject> convertModelsToEDBObjects(List<OpenEngSBModel> models, ConnectorInformation info) {
        List<EDBObject> result = new ArrayList<>();
        if (models != null) {
            for (Object model : models) {
                result.addAll(convertModelToEDBObject(model, info));
            }
        }
        return result;
    }

    



    public List<EDBObject> convertModelToEDBObject(Object model, ConnectorInformation info) {
        if (!OpenEngSBModel.class.isAssignableFrom(model.getClass())) {
            throw new IllegalArgumentException("This function need to get a model passed");
        }
        List<EDBObject> objects = new ArrayList<>();
        if (model != null) {
            convertSubModel((OpenEngSBModel) model, objects, info);
        }
        return objects;
    }

    


    
    private String convertSubModel(OpenEngSBModel model, List<EDBObject> objects, ConnectorInformation info) {
        String contextId = ContextHolder.get().getCurrentContextId();
        String oid = ModelWrapper.wrap(model).getCompleteModelOID();
        EDBObject object = new EDBObject(oid);
        try {
            fillEDBObjectWithEngineeringObjectInformation(object, model);
        } catch (IllegalAccessException e) {
            LOGGER.warn("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
            throw new EKBException("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
        }
        for (OpenEngSBModelEntry entry : model.toOpenEngSBModelEntries()) {
            if (entry.getValue() == null) {
                continue;
            } else if (entry.getType().equals(FileWrapper.class)) {
                try {
                    FileWrapper wrapper = (FileWrapper) entry.getValue();
                    String content = Base64.encodeBase64String(wrapper.getContent());
                    object.putEDBObjectEntry(entry.getKey(), content, String.class);
                    object.putEDBObjectEntry(entry.getKey() + FILEWRAPPER_FILENAME_SUFFIX,
                        wrapper.getFilename(), String.class);
                } catch (IOException e) {
                    LOGGER.error(e.getMessage());
                }
            } else if (OpenEngSBModel.class.isAssignableFrom(entry.getType())) {
                OpenEngSBModel temp = (OpenEngSBModel) entry.getValue();
                String subOid = convertSubModel(temp, objects, info);
                object.putEDBObjectEntry(entry.getKey(), subOid, String.class);
            } else if (List.class.isAssignableFrom(entry.getType())) {
                List<?> list = (List<?>) entry.getValue();
                if (list == null || list.size() == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < list.size(); i++) {
                    Object item = list.get(i);
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (entry.getType().isArray()) {
                Object[] array = (Object[]) entry.getValue();
                if (array == null || array.length == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < array.length; i++) {
                    Object item = array[i];
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (Map.class.isAssignableFrom(entry.getType())) {
                Map<?, ?> map = (Map<?, ?>) entry.getValue();
                if (map == null || map.size() == 0) {
                    continue;
                }
                Boolean keyIsModel = null;
                Boolean valueIsModel = null;
                int i = 0;
                for (Map.Entry<?, ?> ent : map.entrySet()) {
                    if (keyIsModel == null) {
                        keyIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getKey().getClass());
                    }
                    if (valueIsModel == null) {
                        valueIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getValue().getClass());
                    }
                    Object key = ent.getKey();
                    Object value = ent.getValue();
                    if (keyIsModel) {
                        key = convertSubModel((OpenEngSBModel) key, objects, info);
                    }
                    if (valueIsModel) {
                        value = convertSubModel((OpenEngSBModel) value, objects, info);
                    }
                    object.putEDBObjectEntry(getEntryNameForMapKey(entry.getKey(), i), key);
                    object.putEDBObjectEntry(getEntryNameForMapValue(entry.getKey(), i), value);
                    i++;
                }
            } else {
                object.putEDBObjectEntry(entry.getKey(), entry.getValue(), entry.getType());
            }
        }
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE, model.retrieveModelName());
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, model.retrieveModelVersion());
        object.putEDBObjectEntry("domainId", info.getDomainId());
        object.putEDBObjectEntry("connectorId", info.getConnectorId());
        object.putEDBObjectEntry("instanceId", info.getInstanceId());
        object.putEDBObjectEntry("contextId", contextId);
        objects.add(object);
        return oid;
    }
    

    


    private void fillEDBObjectWithEngineeringObjectInformation(EDBObject object, OpenEngSBModel model)
        throws IllegalAccessException {
        if (!new AdvancedModelWrapper(model).isEngineeringObject()) {
            return;
        }
        for (Field field : model.getClass().getDeclaredFields()) {
            OpenEngSBForeignKey annotation = field.getAnnotation(OpenEngSBForeignKey.class);
            if (annotation == null) {
                continue;
            }
            String value = (String) FieldUtils.readField(field, model, true);
            if (value == null) {
                continue;
            }
            value = String.format("%s/%s", ContextHolder.get().getCurrentContextId(), value);
            String key = getEOReferenceStringFromAnnotation(annotation);
            object.put(key, new EDBObjectEntry(key, value, String.class));
        }
    }

    public static String getEntryNameForMapKey(String property, Integer index) {
        return getEntryNameForMap(property, true, index);
    }

    public static String getEntryNameForMapValue(String property, Integer index) {
        return getEntryNameForMap(property, false, index);
    }

    private static String getEntryNameForMap(String property, Boolean key, Integer index) {
        return String.format("%s.%d.%s", property, index, key ? "key" : "value");
    }

    public static String getEntryNameForList(String property, Integer index) {
        return String.format("%s.%d", property, index);
    }

    public static String getEOReferenceStringFromAnnotation(OpenEngSBForeignKey key) {
        return String.format("%s%s:%s", REFERENCE_PREFIX, key.modelType(), key.modelVersion().toString());
    }
}





class OpenEngSBModelEntry implements Serializable {

    private static final long serialVersionUID = 1L;

    private String key;
    private Object value;
    private Class<?> type;

    public OpenEngSBModelEntry() {
    }

    public OpenEngSBModelEntry(String key, Object value, Class<?> type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public Class<?> getType() {
        return type;
    }

    public void setType(Class<?> type) {
        this.type = type;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[] { key, type, value });
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        OpenEngSBModelEntry other = (OpenEngSBModelEntry) obj;
        return eq(key, other.key) && eq(type, other.type) && eq(value, other.value);
    }

    private static boolean eq(Object a, Object b) {
        return a == null ? b == null : a.equals(b);
    }

    @Override
    public String toString() {
        return String.format("%s: %s (%s)", key, value, type);
    }
}





interface OpenEngSBModel extends Serializable {

    List<OpenEngSBModelEntry> toOpenEngSBModelValues();

    List<OpenEngSBModelEntry> toOpenEngSBModelEntries();

    Object retrieveInternalModelId();

    String retrieveInternalModelIdName();

    Long retrieveInternalModelTimestamp();

    Integer retrieveInternalModelVersion();

    void addOpenEngSBModelEntry(OpenEngSBModelEntry entry);

    void removeOpenEngSBModelEntry(String key);

    List<OpenEngSBModelEntry> getOpenEngSBModelTail();

    void setOpenEngSBModelTail(List<OpenEngSBModelEntry> entries);

    String retrieveModelName();

    String retrieveModelVersion();
}






@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface OpenEngSBForeignKey {

    Class<?> modelType();

    String modelVersion();
}





final class ContextHolder {

    private static ContextHolder instance = new ContextHolder();

    private ThreadLocal<String> currentContextId = new InheritableThreadLocal<String>();

    public static ContextHolder get() {
        return instance;
    }

    public void setCurrentContextId(String value) {
        currentContextId.set(value);
    }

    public String getCurrentContextId() {
        return currentContextId.get();
    }

    private ContextHolder() {
    }
}





class ModelDescription {

    private final String modelClassName;
    private final String versionString;

    public ModelDescription(String modelClassName, String versionString) {
        this.modelClassName = modelClassName;
        this.versionString = versionString;
    }

    public String getModelClassName() {
        return modelClassName;
    }

    public String getVersionString() {
        return versionString;
    }

    @Override
    public String toString() {
        return modelClassName + ":" + versionString;
    }
}







class ModelWrapper implements OpenEngSBModel {

    private static final long serialVersionUID = 1L;

    protected OpenEngSBModel model;

    protected ModelWrapper(OpenEngSBModel model) {
        this.model = model;
    }

    public static ModelWrapper wrap(Object model) {
        if (!(isModel(model.getClass()))) {
            throw new IllegalArgumentException("The given object is no model");
        }
        return new ModelWrapper((OpenEngSBModel) model);
    }

    public static boolean isModel(Class<?> clazz) {
        return OpenEngSBModel.class.isAssignableFrom(clazz);
    }

    public OpenEngSBModel getUnderlyingModel() {
        return model;
    }

    public ModelDescription getModelDescription() {
        String modelName = retrieveModelName();
        String modelVersion = retrieveModelVersion();
        if (modelName == null || modelVersion == null) {
            throw new IllegalArgumentException("Unsufficient information to create model description.");
        }
        return new ModelDescription(modelName, modelVersion);
    }

    @Override
    public List<OpenEngSBModelEntry> toOpenEngSBModelValues() {
        return model.toOpenEngSBModelValues();
    }

    @Override
    public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
        return model.toOpenEngSBModelEntries();
    }

    @Override
    public Object retrieveInternalModelId() {
        return model.retrieveInternalModelId();
    }

    @Override
    public String retrieveInternalModelIdName() {
        return model.retrieveInternalModelIdName();
    }

    @Override
    public Long retrieveInternalModelTimestamp() {
        return model.retrieveInternalModelTimestamp();
    }

    @Override
    public Integer retrieveInternalModelVersion() {
        return model.retrieveInternalModelVersion();
    }

    @Override
    public void addOpenEngSBModelEntry(OpenEngSBModelEntry entry) {
        model.addOpenEngSBModelEntry(entry);
    }

    @Override
    public void removeOpenEngSBModelEntry(String key) {
        model.removeOpenEngSBModelEntry(key);
    }

    @Override
    public List<OpenEngSBModelEntry> getOpenEngSBModelTail() {
        return model.getOpenEngSBModelTail();
    }

    @Override
    public void setOpenEngSBModelTail(List<OpenEngSBModelEntry> entries) {
        model.setOpenEngSBModelTail(entries);
    }

    @Override
    public String retrieveModelName() {
        return model.retrieveModelName();
    }

    @Override
    public String retrieveModelVersion() {
        return model.retrieveModelVersion();
    }

    public String getCompleteModelOID() {
        return appendContextId(model.retrieveInternalModelId());
    }

    protected String appendContextId(Object modelId) {
        String contextId = ContextHolder.get().getCurrentContextId();
        return String.format("%s/%s", contextId, modelId);
    }
}







class AdvancedModelWrapper extends ModelWrapper {

    private static final long serialVersionUID = 1L;

    public AdvancedModelWrapper(OpenEngSBModel model) {
        super(model);
    }

    public Boolean isEngineeringObject() {
        return isEngineeringObjectClass(model.getClass());
    }

    public static Boolean isEngineeringObjectClass(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            if (field.isAnnotationPresent(OpenEngSBForeignKey.class)) {
                return true;
            }
        }
        return false;
    }
}





class FileWrapper {

    private File file;
    private byte[] content;
    private String filename;
    private int buffer = 2048;
    private String tempDir = System.getProperty("java.io.tmpdir") + File.separator + "OpenEngSBModelTemp";

    public FileWrapper() {
    }

    public FileWrapper(File file) {
        this.file = file;
    }

    public FileWrapper(byte[] content, String filename) {
        this.content = content;
        this.filename = filename;
    }

    public File returnFile() throws IOException {
        if (file == null) {
            deserialize();
        }
        return file;
    }

    public void setFile(File file) {
        this.file = file;
        content = null;
        filename = null;
    }

    public byte[] getContent() throws IOException {
        if (content == null) {
            serialize();
        }
        return content;
    }

    public void setContent(byte[] content) {
        this.content = content;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilename() throws IOException {
        if (filename == null) {
            serialize();
        }
        return filename;
    }

    
    private void serialize() throws IOException {
        if (file == null) {
            throw new IOException("No file and no content set in this FileWrapper");
        }
        filename = file.getName();
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final FileInputStream in = new FileInputStream(file);
        try {
            final byte[] chunk = new byte[buffer];
            int read;
            while ((read = in.read(chunk)) != -1) {
                out.write(chunk, 0, read);
            }
        } finally {
            in.close();
        }
        content = out.toByteArray();
    }

    
    private void deserialize() throws IOException {
        if (content == null || filename == null) {
            throw new IOException("No content and no filename set in this FileWrapper");
        }
        final File dir = new File(tempDir);
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Unable to create the temp directory " + tempDir);
        }
        file = new File(dir, filename);
        final FileOutputStream out = new FileOutputStream(file);
        try {
            out.write(content);
        } finally {
            out.close();
        }
    }

    @Override
    public String toString() {
        return "FileWrapper[filename=" + filename + ", contentLength="
                + (content == null ? "n/a" : String.valueOf(content.length)) + "]";
    }
}





class EDBObjectEntry implements Serializable {

    private static final long serialVersionUID = 1L;

    private String key;
    private Object value;
    private String type;

    public EDBObjectEntry() {
    }

    public EDBObjectEntry(String key, Object value, Class<?> type) {
        this(key, value, type.getName());
    }

    public EDBObjectEntry(String key, Object value, String type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "EDBObjectEntry{key=" + key + ", value=" + value + ", type=" + type + "}";
    }
}





final class EDBConstants {

    private EDBConstants() {
        
    }

    public static final String MODEL_OID = "edbId";
    public static final String MODEL_VERSION = "edbVersion";
    public static final String MODEL_TIMESTAMP = "edbTimestamp";
    public static final String MODEL_TYPE = "modelType";
    public static final String MODEL_TYPE_VERSION = "modelTypeVersion";
}







class EDBObject extends HashMap<String, EDBObjectEntry> {

    private static final long serialVersionUID = 1L;

    private static final String OID_CONST = "oid";
    private static final String DELETED_CONST = "isDeleted";

    public EDBObject(String oid) {
        super();
        setOID(oid);
    }

    public EDBObject(String oid, Map<String, EDBObjectEntry> data) {
        super(data);
        setOID(oid);
    }

    public final Long getTimestamp() {
        return getLong(EDBConstants.MODEL_TIMESTAMP);
    }

    public void updateTimestamp(Long timestamp) {
        putEDBObjectEntry(EDBConstants.MODEL_TIMESTAMP, timestamp);
    }

    public String getOID() {
        return getString(OID_CONST);
    }

    public void setOID(String oid) {
        putEDBObjectEntry(OID_CONST, oid);
    }

    public String getString(String key) {
        return getObject(key, String.class);
    }

    public Boolean getBoolean(String key) {
        return getObject(key, Boolean.class);
    }

    public Short getShort(String key) {
        return getObject(key, Short.class);
    }

    public Integer getInteger(String key) {
        return getObject(key, Integer.class);
    }

    public Long getLong(String key) {
        return getObject(key, Long.class);
    }

    public Float getFloat(String key) {
        return getObject(key, Float.class);
    }

    public Double getDouble(String key) {
        return getObject(key, Double.class);
    }

    public Character getChar(String key) {
        return getObject(key, Character.class);
    }

    public Object getObject(String key) {
        return getObject(key, Object.class);
    }

    @SuppressWarnings("unchecked")
    public <T> T getObject(String key, Class<T> clazz) {
        EDBObjectEntry entry = get(key);
        return entry == null ? null : (T) entry.getValue();
    }

    public final Boolean isDeleted() {
        Boolean deleted = getObject(DELETED_CONST, Boolean.class);
        return deleted != null ? deleted : false;
    }

    public void setDeleted(Boolean deleted) {
        putEDBObjectEntry(DELETED_CONST, deleted);
    }

    public void putEDBObjectEntry(String key, Object value, String type) {
        put(key, new EDBObjectEntry(key, value, type));
    }

    public void putEDBObjectEntry(String key, Object value, Class<?> type) {
        putEDBObjectEntry(key, value, type.getName());
    }

    public void putEDBObjectEntry(String key, Object value) {
        putEDBObjectEntry(key, value, value == null ? Object.class.getName() : value.getClass().getName());
    }
}





class ConnectorInformation {

    private String domainId;
    private String connectorId;
    private String instanceId;

    public ConnectorInformation(String domainId, String connectorId, String instanceId) {
        this.domainId = domainId;
        this.connectorId = connectorId;
        this.instanceId = instanceId;
    }

    public String getDomainId() {
        return domainId;
    }

    public String getConnectorId() {
        return connectorId;
    }

    public String getInstanceId() {
        return instanceId;
    }
}





class EKBException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public EKBException() {
        super();
    }

    public EKBException(String message) {
        super(message);
    }

    public EKBException(Throwable cause) {
        super(cause);
    }

    public EKBException(String message, Throwable cause) {
        super(message, cause);
    }
}


class EDBException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public EDBException(String message) {
        super(message);
    }

    public EDBException(String message, Throwable cause) {
        super(message, cause);
    }
}





interface EngineeringDatabaseService {

    EDBObject getObject(String oid) throws EDBException;

    EDBObject getObject(String oid, Long timestamp) throws EDBException;

    List<EDBObject> getObjects(List<String> oids) throws EDBException;
}











final class Base64 {

    private Base64() {
    }

    public static String encodeBase64String(final byte[] binaryData) {
        if (binaryData == null) {
            return null;
        }
        return java.util.Base64.getEncoder().encodeToString(binaryData);
    }

    public static byte[] decodeBase64(final String base64String) {
        if (base64String == null) {
            return null;
        }
        return java.util.Base64.getDecoder().decode(base64String);
    }
}


final class FieldUtils {

    private FieldUtils() {
    }

    public static Object readField(final Field field, final Object target, final boolean forceAccess)
            throws IllegalAccessException {
        if (forceAccess && !field.isAccessible()) {
            field.setAccessible(true);
        }
        return field.get(target);
    }
}


final class ClassUtils {

    private ClassUtils() {
    }

    public static Class<?> primitiveToWrapper(final Class<?> cls) {
        if (cls == null || !cls.isPrimitive()) {
            return cls;
        }
        if (cls == Integer.TYPE) {
            return Integer.class;
        }
        if (cls == Long.TYPE) {
            return Long.class;
        }
        if (cls == Boolean.TYPE) {
            return Boolean.class;
        }
        if (cls == Double.TYPE) {
            return Double.class;
        }
        if (cls == Float.TYPE) {
            return Float.class;
        }
        if (cls == Short.TYPE) {
            return Short.class;
        }
        if (cls == Byte.TYPE) {
            return Byte.class;
        }
        if (cls == Character.TYPE) {
            return Character.class;
        }
        return cls;
    }
}


interface Logger {

    void trace(String msg);

    void debug(String format, Object... arguments);

    void info(String format, Object... arguments);

    void warn(String msg);

    void warn(String format, Object... arguments);

    void warn(String msg, Throwable t);

    void error(String msg);

    void error(String format, Object... arguments);
}


final class LoggerFactory {

    private LoggerFactory() {
    }

    static Logger getLogger(final Class<?> clazz) {
        final String name = clazz.getSimpleName();
        return new Logger() {
            private void print(final String level, final String format, final Object[] args, final Throwable t) {
                System.out.println("      [" + level + "] " + name + " - " + expand(format, args)
                        + (t == null ? "" : " (" + t.getClass().getSimpleName() + ": " + t.getMessage() + ")"));
            }

            private String expand(final String format, final Object[] args) {
                if (format == null || args == null || args.length == 0) {
                    return String.valueOf(format);
                }
                final StringBuilder sb = new StringBuilder();
                int from = 0;
                int arg = 0;
                while (arg < args.length) {
                    final int at = format.indexOf("{}", from);
                    if (at < 0) {
                        break;
                    }
                    sb.append(format, from, at).append(args[arg++]);
                    from = at + 2;
                }
                return sb.append(format.substring(from)).toString();
            }

            public void trace(String msg) {
                print("TRACE", msg, null, null);
            }

            public void debug(String format, Object... arguments) {
                print("DEBUG", format, arguments, null);
            }

            public void info(String format, Object... arguments) {
                print("INFO ", format, arguments, null);
            }

            public void warn(String msg) {
                print("WARN ", msg, null, null);
            }

            public void warn(String format, Object... arguments) {
                print("WARN ", format, arguments, null);
            }

            public void warn(String msg, Throwable t) {
                print("WARN ", msg, null, t);
            }

            public void error(String msg) {
                print("ERROR", msg, null, null);
            }

            public void error(String format, Object... arguments) {
                print("ERROR", format, arguments, null);
            }
        };
    }
}
