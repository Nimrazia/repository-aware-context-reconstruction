
















































import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class method_2_openengsb_claude {

    public enum Priority {
        LOW, MEDIUM, HIGH
    }

    
    public static class TaskModel implements OpenEngSBModel {

        private static final long serialVersionUID = 1L;

        private String id;
        private String title;
        private Integer weight;
        private Priority priority;
        private List<String> tags;
        private String[] codes;
        private Map<String, String> labels;
        private SubTaskModel subTask;
        private FileWrapper attachment;
        private File localFile;
        private final List<OpenEngSBModelEntry> tail = new ArrayList<OpenEngSBModelEntry>();

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public Integer getWeight() {
            return weight;
        }

        public void setWeight(Integer weight) {
            this.weight = weight;
        }

        public Priority getPriority() {
            return priority;
        }

        public void setPriority(Priority priority) {
            this.priority = priority;
        }

        public List<String> getTags() {
            return tags;
        }

        public void setTags(List<String> tags) {
            this.tags = tags;
        }

        public String[] getCodes() {
            return codes;
        }

        public void setCodes(String[] codes) {
            this.codes = codes;
        }

        public Map<String, String> getLabels() {
            return labels;
        }

        public void setLabels(Map<String, String> labels) {
            this.labels = labels;
        }

        public SubTaskModel getSubTask() {
            return subTask;
        }

        public void setSubTask(SubTaskModel subTask) {
            this.subTask = subTask;
        }

        public FileWrapper getAttachment() {
            return attachment;
        }

        public void setAttachment(FileWrapper attachment) {
            this.attachment = attachment;
        }

        public File getLocalFile() {
            return localFile;
        }

        public void setLocalFile(File localFile) {
            this.localFile = localFile;
        }

        public List<OpenEngSBModelEntry> toOpenEngSBModelValues() {
            return new ArrayList<OpenEngSBModelEntry>();
        }

        public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
            return new ArrayList<OpenEngSBModelEntry>();
        }

        public Object retrieveInternalModelId() {
            return id;
        }

        public String retrieveInternalModelIdName() {
            return "id";
        }

        public Long retrieveInternalModelTimestamp() {
            return 0L;
        }

        public Integer retrieveInternalModelVersion() {
            return 1;
        }

        public void addOpenEngSBModelEntry(OpenEngSBModelEntry entry) {
            tail.add(entry);
        }

        public void removeOpenEngSBModelEntry(String key) {
        }

        public List<OpenEngSBModelEntry> getOpenEngSBModelTail() {
            return tail;
        }

        public void setOpenEngSBModelTail(List<OpenEngSBModelEntry> entries) {
            tail.clear();
            tail.addAll(entries);
        }

        public String retrieveModelName() {
            return TaskModel.class.getName();
        }

        public String retrieveModelVersion() {
            return "1.0.0";
        }

        @Override
        public String toString() {
            return "TaskModel[id=" + id + ", title=" + title + ", weight=" + weight + ", priority=" + priority
                    + ", tags=" + tags + ", codes=" + Arrays.toString(codes) + ", labels=" + labels
                    + ", subTask=" + subTask + ", attachment=" + attachment + ", localFile=" + localFile + "]";
        }
    }

    public static class SubTaskModel implements OpenEngSBModel {

        private static final long serialVersionUID = 1L;

        private String id;
        private String name;
        private final List<OpenEngSBModelEntry> tail = new ArrayList<OpenEngSBModelEntry>();

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<OpenEngSBModelEntry> toOpenEngSBModelValues() {
            return new ArrayList<OpenEngSBModelEntry>();
        }

        public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
            return new ArrayList<OpenEngSBModelEntry>();
        }

        public Object retrieveInternalModelId() {
            return id;
        }

        public String retrieveInternalModelIdName() {
            return "id";
        }

        public Long retrieveInternalModelTimestamp() {
            return 0L;
        }

        public Integer retrieveInternalModelVersion() {
            return 1;
        }

        public void addOpenEngSBModelEntry(OpenEngSBModelEntry entry) {
            tail.add(entry);
        }

        public void removeOpenEngSBModelEntry(String key) {
        }

        public List<OpenEngSBModelEntry> getOpenEngSBModelTail() {
            return tail;
        }

        public void setOpenEngSBModelTail(List<OpenEngSBModelEntry> entries) {
            tail.clear();
            tail.addAll(entries);
        }

        public String retrieveModelName() {
            return SubTaskModel.class.getName();
        }

        public String retrieveModelVersion() {
            return "1.0.0";
        }

        @Override
        public String toString() {
            return "SubTaskModel[id=" + id + ", name=" + name + "]";
        }
    }

    
    
    

    public static void main(String[] args) throws Exception {
        title("METHOD 2  |  EDBConverter.getValueForProperty(PropertyDescriptor, EDBObject)");

        ContextHolder.get().setCurrentContextId("testcontext");
        final InMemoryEngineeringDatabaseService edb = new InMemoryEngineeringDatabaseService();
        final EDBConverter converter = new EDBConverter(edb);

        
        final EDBObject subObject = new EDBObject("testcontext/sub-1");
        subObject.putEDBObjectEntry("id", "sub-1", String.class);
        subObject.putEDBObjectEntry("name", "nested sub task", String.class);
        subObject.putEDBObjectEntry(EDBConstants.MODEL_TYPE, SubTaskModel.class.getName(), String.class);
        subObject.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, "1.0.0", String.class);
        edb.put(subObject);

        section("1. every branch driven at once through the public entry point");
        final EDBObject object = new EDBObject("testcontext/task-1");
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE, TaskModel.class.getName(), String.class);
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, "1.0.0", String.class);
        object.putEDBObjectEntry(EDBConstants.MODEL_TIMESTAMP, Long.valueOf(1234567890L), Long.class);
        object.putEDBObjectEntry("id", "task-1", String.class);
        object.putEDBObjectEntry("title", "reconstruct the method", String.class);
        object.putEDBObjectEntry("weight", Integer.valueOf(42), Integer.class);
        object.putEDBObjectEntry("priority", "HIGH", String.class);
        object.putEDBObjectEntry("tags.0", "alpha", String.class);
        object.putEDBObjectEntry("tags.1", "beta", String.class);
        object.putEDBObjectEntry("codes.0", "C-1", String.class);
        object.putEDBObjectEntry("codes.1", "C-2", String.class);
        object.putEDBObjectEntry("labels.0.key", "env", String.class);
        object.putEDBObjectEntry("labels.0.value", "production", String.class);
        object.putEDBObjectEntry("labels.1.key", "region", String.class);
        object.putEDBObjectEntry("labels.1.value", "eu", String.class);
        object.putEDBObjectEntry("subTask", "testcontext/sub-1", String.class);
        object.putEDBObjectEntry("attachment",
                Base64.encodeBase64String("openengsb payload".getBytes("UTF-8")), String.class);
        object.putEDBObjectEntry("attachment.filename", "payload.txt", String.class);
        object.putEDBObjectEntry("customTailEntry", "kept in the model tail", String.class);

        final TaskModel model = converter.convertEDBObjectToModel(TaskModel.class, object);
        System.out.println("      converted model : " + model);
        System.out.println("      attachment bytes: \"" + new String(model.getAttachment().getContent(), "UTF-8") + "\"");
        System.out.println();
        System.out.println("      branch -> result");
        System.out.println("        Map parameter          labels     = " + model.getLabels());
        System.out.println("        List parameter         tags       = " + model.getTags());
        System.out.println("        array parameter        codes      = " + Arrays.toString(model.getCodes()));
        System.out.println("        OpenEngSBModel         subTask    = " + model.getSubTask()
                + "   (resolved through edbService.getObject with the model timestamp)");
        System.out.println("        FileWrapper            attachment = " + model.getAttachment());
        System.out.println("        File parameter         localFile  = " + model.getLocalFile()
                + "   (the File branch always returns null)");
        System.out.println("        enum parameter         priority   = " + model.getPriority()
                + "   (" + model.getPriority().getClass().getName() + ")");
        System.out.println("        plain value            title      = " + model.getTitle());
        System.out.println("      remaining entries in the EDBObject after every property was consumed:");
        final List<String> left = new ArrayList<String>(object.keySet());
        java.util.Collections.sort(left);
        System.out.println("        " + left + "   (the model tail)");

        section("2. a property that is absent from the EDBObject - the 'value == null' branch");
        final EDBObject sparse = new EDBObject("testcontext/task-2");
        sparse.putEDBObjectEntry(EDBConstants.MODEL_TYPE, TaskModel.class.getName(), String.class);
        sparse.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, "1.0.0", String.class);
        sparse.putEDBObjectEntry("id", "task-2", String.class);
        final TaskModel sparseModel = converter.convertEDBObjectToModel(TaskModel.class, sparse);
        System.out.println("      converted model : " + sparseModel);
        System.out.println("      title, weight, priority and subTask were all null in the EDBObject, so the");
        System.out.println("      target method returned null for each of them without touching the EDB");
        System.out.println("      tags / codes / labels still produced empty containers, because the Map,");
        System.out.println("      List and array branches run before the null check");

        section("3. an invalid timestamp - the NumberFormatException warning branch");
        final EDBObject badTimestamp = new EDBObject("testcontext/task-3");
        badTimestamp.putEDBObjectEntry(EDBConstants.MODEL_TYPE, TaskModel.class.getName(), String.class);
        badTimestamp.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, "1.0.0", String.class);
        badTimestamp.putEDBObjectEntry(EDBConstants.MODEL_TIMESTAMP, "not-a-number", String.class);
        badTimestamp.putEDBObjectEntry("id", "task-3", String.class);
        badTimestamp.putEDBObjectEntry("subTask", "testcontext/sub-1", String.class);
        final TaskModel warned = converter.convertEDBObjectToModel(TaskModel.class, badTimestamp);
        System.out.println("      the warning above came from the target method, and the sub model was still");
        System.out.println("      resolved with System.currentTimeMillis() as the fallback timestamp:");
        System.out.println("      subTask = " + warned.getSubTask());

        section("4. an enum value that matches no constant - getEnumValue leaves the raw value");
        final EDBObject unknownEnum = new EDBObject("testcontext/task-4");
        unknownEnum.putEDBObjectEntry(EDBConstants.MODEL_TYPE, TaskModel.class.getName(), String.class);
        unknownEnum.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, "1.0.0", String.class);
        unknownEnum.putEDBObjectEntry("id", "task-4", String.class);
        unknownEnum.putEDBObjectEntry("priority", "URGENT", String.class);
        final PropertyDescriptor priorityDescriptor = descriptorFor(TaskModel.class, "priority");
        final Object rawEnum = converter.exposeGetValueForProperty(priorityDescriptor, unknownEnum);
        System.out.println("      returned value  : " + rawEnum + "   (" + rawEnum.getClass().getName() + ")");
        System.out.println("      no constant matched, so the original String is returned unchanged");

        section("5. branch coverage summary");
        System.out.println("      Map.class.isAssignableFrom(parameterType)        -> labels");
        System.out.println("      List.class.isAssignableFrom(parameterType)       -> tags");
        System.out.println("      parameterType.isArray()                          -> codes");
        System.out.println("      value == null                                    -> scenario 2");
        System.out.println("      OpenEngSBModel.class.isAssignableFrom(...)        -> subTask");
        System.out.println("        with a valid timestamp                         -> scenario 1");
        System.out.println("        with an invalid timestamp (NumberFormatException) -> scenario 3");
        System.out.println("      parameterType.equals(FileWrapper.class)          -> attachment");
        System.out.println("      parameterType.equals(File.class)                 -> localFile (returns null)");
        System.out.println("      object.containsKey(...) and isEnum()             -> priority");
        System.out.println("        with an unmatched constant                     -> scenario 4");
        System.out.println("      plain value, no branch matched                   -> title, weight, id");

        title("END OF METHOD 2 SCENARIOS");
    }

    static PropertyDescriptor descriptorFor(Class<?> clazz, String name) throws IntrospectionException {
        for (PropertyDescriptor d : Introspector.getBeanInfo(clazz).getPropertyDescriptors()) {
            if (d.getName().equals(name)) {
                return d;
            }
        }
        throw new IllegalArgumentException("no property " + name + " on " + clazz);
    }

    
    static final class InMemoryEngineeringDatabaseService implements EngineeringDatabaseService {

        private final Map<String, EDBObject> store = new LinkedHashMap<String, EDBObject>();

        public EDBObject getObject(String oid) {
            final EDBObject found = store.get(oid);
            if (found == null) {
                throw new EDBException("No object with the oid " + oid + " was found");
            }
            
            
            return new EDBObject(oid, new HashMap<String, EDBObjectEntry>(found));
        }

        public EDBObject getObject(String oid, Long timestamp) {
            System.out.println("      [edb] getObject(\"" + oid + "\", " + timestamp + ")");
            return getObject(oid);
        }

        public List<EDBObject> getObjects(List<String> oids) {
            final List<EDBObject> result = new ArrayList<EDBObject>();
            for (String oid : oids) {
                result.add(getObject(oid));
            }
            return result;
        }

        void put(EDBObject object) {
            store.put(object.getOID(), object);
        }
    }

    static void title(String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}








class EDBConverter {

    private static final Logger LOGGER = LoggerFactory.getLogger(EDBConverter.class);

    public static final String FILEWRAPPER_FILENAME_SUFFIX = ".filename";
    public static final String REFERENCE_PREFIX = "refersTo_";

    private EngineeringDatabaseService edbService;

    public EDBConverter(EngineeringDatabaseService edbService) {
        this.edbService = edbService;
    }

    


    public <T> T convertEDBObjectToModel(Class<T> model, EDBObject object) {
        return model.cast(convertEDBObjectToUncheckedModel(model, object));
    }

    


    public <T> List<T> convertEDBObjectsToModelObjects(Class<T> model, List<EDBObject> objects) {
        List<T> models = new ArrayList<>();
        for (EDBObject object : objects) {
            T instance = convertEDBObjectToModel(model, object);
            if (instance != null) {
                models.add(instance);
            }
        }
        return models;
    }

    


    private boolean checkEDBObjectModelType(EDBObject object, Class<?> model) {
        String modelName = object.getString(EDBConstants.MODEL_TYPE);
        if (modelName == null) {
            LOGGER.warn("The EDBObject has no model type defined.");
            return false;
        }
        if (!model.getName().equals(modelName)) {
            LOGGER.warn("The EDBObject is of the type {} but should be of the type {}", modelName, model.getName());
            return false;
        }
        return true;
    }

    


    private Object convertEDBObjectToUncheckedModel(Class<?> model, EDBObject object) {
        if (!checkEDBObjectModelType(object, model)) {
            return null;
        }
        filterEngineeringObjectInformation(object, model);
        List<OpenEngSBModelEntry> entries = new ArrayList<>();
        for (PropertyDescriptor propertyDescriptor : getPropertyDescriptorsForClass(model)) {
            if (propertyDescriptor.getWriteMethod() == null
                    || propertyDescriptor.getName().equals(ModelUtils.MODEL_TAIL_FIELD_NAME)) {
                continue;
            }
            Object value = getValueForProperty(propertyDescriptor, object);
            Class<?> propertyClass = propertyDescriptor.getPropertyType();
            if (propertyClass.isPrimitive()) {
                entries.add(new OpenEngSBModelEntry(propertyDescriptor.getName(), value, ClassUtils
                    .primitiveToWrapper(propertyClass)));
            } else {
                entries.add(new OpenEngSBModelEntry(propertyDescriptor.getName(), value, propertyClass));
            }
        }

        for (Map.Entry<String, EDBObjectEntry> objectEntry : object.entrySet()) {
            EDBObjectEntry entry = objectEntry.getValue();
            Class<?> entryType;
            try {
                entryType = model.getClassLoader().loadClass(entry.getType());
                entries.add(new OpenEngSBModelEntry(entry.getKey(), entry.getValue(), entryType));
            } catch (ClassNotFoundException e) {
                LOGGER.error("Unable to load class {} of the model tail", entry.getType());
            }
        }
        return ModelUtils.createModel(model, entries);
    }

    


    private List<PropertyDescriptor> getPropertyDescriptorsForClass(Class<?> clasz) {
        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(clasz);
            return Arrays.asList(beanInfo.getPropertyDescriptors());
        } catch (IntrospectionException e) {
            LOGGER.error("instantiation exception while trying to create instance of class {}", clasz.getName());
        }
        return new ArrayList<PropertyDescriptor>();
    }

    


    
    private Object getValueForProperty(PropertyDescriptor propertyDescriptor, EDBObject object) {
        Method setterMethod = propertyDescriptor.getWriteMethod();
        String propertyName = propertyDescriptor.getName();
        Object value = object.getObject(propertyName);
        Class<?> parameterType = setterMethod.getParameterTypes()[0];

        
        if (Map.class.isAssignableFrom(parameterType)) {
            List<Class<?>> classes = getGenericMapParameterClasses(setterMethod);
            value = getMapValue(classes.get(0), classes.get(1), propertyName, object);
        } else if (List.class.isAssignableFrom(parameterType)) {
            Class<?> clazz = getGenericListParameterClass(setterMethod);
            value = getListValue(clazz, propertyName, object);
        } else if (parameterType.isArray()) {
            Class<?> clazz = parameterType.getComponentType();
            value = getArrayValue(clazz, propertyName, object);
        } else if (value == null) {
            return null;
        } else if (OpenEngSBModel.class.isAssignableFrom(parameterType)) {
            Object timestamp = object.getObject(EDBConstants.MODEL_TIMESTAMP);
            Long time = System.currentTimeMillis();
            if (timestamp != null) {
                try {
                    time = Long.parseLong(timestamp.toString());
                } catch (NumberFormatException e) {
                    LOGGER.warn("The model with the oid {} has an invalid timestamp.", object.getOID());
                }
            }
            EDBObject obj = edbService.getObject((String) value, time);
            value = convertEDBObjectToUncheckedModel(parameterType, obj);
            object.remove(propertyName);
        } else if (parameterType.equals(FileWrapper.class)) {
            FileWrapper wrapper = new FileWrapper();
            String filename = object.getString(propertyName + FILEWRAPPER_FILENAME_SUFFIX);
            String content = (String) value;
            wrapper.setFilename(filename);
            wrapper.setContent(Base64.decodeBase64(content));
            value = wrapper;
            object.remove(propertyName + FILEWRAPPER_FILENAME_SUFFIX);
        } else if (parameterType.equals(File.class)) {
            return null;
        } else if (object.containsKey(propertyName)) {
            if (parameterType.isEnum()) {
                value = getEnumValue(parameterType, value);
            }
        }
        object.remove(propertyName);
        return value;
    }
    

    





    Object exposeGetValueForProperty(PropertyDescriptor propertyDescriptor, EDBObject object) {
        return getValueForProperty(propertyDescriptor, object);
    }

    


    private Class<?> getGenericListParameterClass(Method setterMethod) {
        return getGenericParameterClasses(setterMethod, 1).get(0);
    }

    


    private List<Class<?>> getGenericMapParameterClasses(Method setterMethod) {
        return getGenericParameterClasses(setterMethod, 2);
    }

    


    private List<Class<?>> getGenericParameterClasses(Method setterMethod, int depth) {
        Type t = setterMethod.getGenericParameterTypes()[0];
        ParameterizedType pType = (ParameterizedType) t;
        List<Class<?>> classes = new ArrayList<>();
        for (int i = 0; i < depth; i++) {
            classes.add((Class<?>) pType.getActualTypeArguments()[i]);
        }
        return classes;
    }

    


    @SuppressWarnings("unchecked")
    private <T> List<T> getListValue(Class<T> type, String propertyName, EDBObject object) {
        List<T> temp = new ArrayList<>();
        for (int i = 0;; i++) {
            String property = getEntryNameForList(propertyName, i);
            Object obj = object.getObject(property);
            if (obj == null) {
                break;
            }
            if (OpenEngSBModel.class.isAssignableFrom(type)) {
                obj = convertEDBObjectToUncheckedModel(type, edbService.getObject(object.getString(property)));
            }
            temp.add((T) obj);
            object.remove(property);
        }
        return temp;
    }

    


    @SuppressWarnings("unchecked")
    private <T> T[] getArrayValue(Class<T> type, String propertyName, EDBObject object) {
        List<T> elements = getListValue(type, propertyName, object);
        T[] ar = (T[]) Array.newInstance(type, elements.size());
        return elements.toArray(ar);
    }

    


    private Object getMapValue(Class<?> keyType, Class<?> valueType, String propertyName, EDBObject object) {
        Map<Object, Object> temp = new HashMap<>();
        for (int i = 0;; i++) {
            String keyProperty = getEntryNameForMapKey(propertyName, i);
            String valueProperty = getEntryNameForMapValue(propertyName, i);
            if (!object.containsKey(keyProperty)) {
                break;
            }
            Object key = object.getObject(keyProperty);
            Object value = object.getObject(valueProperty);
            if (OpenEngSBModel.class.isAssignableFrom(keyType)) {
                key = convertEDBObjectToUncheckedModel(keyType, edbService.getObject(key.toString()));
            }
            if (OpenEngSBModel.class.isAssignableFrom(valueType)) {
                value = convertEDBObjectToUncheckedModel(valueType, edbService.getObject(value.toString()));
            }
            temp.put(key, value);
            object.remove(keyProperty);
            object.remove(valueProperty);
        }
        return temp;
    }

    


    private Object getEnumValue(Class<?> type, Object value) {
        Object[] enumValues = type.getEnumConstants();
        for (Object enumValue : enumValues) {
            if (enumValue.toString().equals(value.toString())) {
                value = enumValue;
                break;
            }
        }
        return value;
    }

    private void filterEngineeringObjectInformation(EDBObject object, Class<?> model) {
        if (!AdvancedModelWrapper.isEngineeringObjectClass(model)) {
            return;
        }
        Iterator<String> keys = object.keySet().iterator();
        while (keys.hasNext()) {
            if (keys.next().startsWith(REFERENCE_PREFIX)) {
                keys.remove();
            }
        }
    }

    public static String getEntryNameForMapKey(String property, Integer index) {
        return getEntryNameForMap(property, true, index);
    }

    public static String getEntryNameForMapValue(String property, Integer index) {
        return getEntryNameForMap(property, false, index);
    }

    private static String getEntryNameForMap(String property, Boolean key, Integer index) {
        return String.format("%s.%d.%s", property, index, key ? "key" : "value");
    }

    public static String getEntryNameForList(String property, Integer index) {
        return String.format("%s.%d", property, index);
    }

    public static String getEOReferenceStringFromAnnotation(OpenEngSBForeignKey key) {
        return String.format("%s%s:%s", REFERENCE_PREFIX, key.modelType(), key.modelVersion().toString());
    }
}












final class ModelUtils {

    public static final String MODEL_TAIL_FIELD_NAME = "openEngSBModelTail";

    private ModelUtils() {
    }

    public static Object createModel(Class<?> model, List<OpenEngSBModelEntry> entries) {
        final Object instance;
        try {
            instance = model.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            throw new EKBException("Unable to instantiate the model " + model.getName(), e);
        }
        final Map<String, PropertyDescriptor> descriptors = new HashMap<String, PropertyDescriptor>();
        try {
            for (PropertyDescriptor descriptor : Introspector.getBeanInfo(model).getPropertyDescriptors()) {
                descriptors.put(descriptor.getName(), descriptor);
            }
        } catch (IntrospectionException e) {
            throw new EKBException("Unable to introspect the model " + model.getName(), e);
        }
        final List<OpenEngSBModelEntry> tail = new ArrayList<OpenEngSBModelEntry>();
        for (OpenEngSBModelEntry entry : entries) {
            final PropertyDescriptor descriptor = descriptors.get(entry.getKey());
            if (descriptor == null || descriptor.getWriteMethod() == null) {
                tail.add(entry);
                continue;
            }
            if (entry.getValue() == null) {
                continue;
            }
            try {
                descriptor.getWriteMethod().invoke(instance, entry.getValue());
            } catch (Exception e) {
                tail.add(entry);
            }
        }
        if (instance instanceof OpenEngSBModel) {
            ((OpenEngSBModel) instance).setOpenEngSBModelTail(tail);
        }
        return instance;
    }
}





class OpenEngSBModelEntry implements Serializable {

    private static final long serialVersionUID = 1L;

    private String key;
    private Object value;
    private Class<?> type;

    public OpenEngSBModelEntry() {
    }

    public OpenEngSBModelEntry(String key, Object value, Class<?> type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public Class<?> getType() {
        return type;
    }

    public void setType(Class<?> type) {
        this.type = type;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[] { key, type, value });
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        OpenEngSBModelEntry other = (OpenEngSBModelEntry) obj;
        return eq(key, other.key) && eq(type, other.type) && eq(value, other.value);
    }

    private static boolean eq(Object a, Object b) {
        return a == null ? b == null : a.equals(b);
    }

    @Override
    public String toString() {
        return String.format("%s: %s (%s)", key, value, type);
    }
}





interface OpenEngSBModel extends Serializable {

    List<OpenEngSBModelEntry> toOpenEngSBModelValues();

    List<OpenEngSBModelEntry> toOpenEngSBModelEntries();

    Object retrieveInternalModelId();

    String retrieveInternalModelIdName();

    Long retrieveInternalModelTimestamp();

    Integer retrieveInternalModelVersion();

    void addOpenEngSBModelEntry(OpenEngSBModelEntry entry);

    void removeOpenEngSBModelEntry(String key);

    List<OpenEngSBModelEntry> getOpenEngSBModelTail();

    void setOpenEngSBModelTail(List<OpenEngSBModelEntry> entries);

    String retrieveModelName();

    String retrieveModelVersion();
}






@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface OpenEngSBForeignKey {

    Class<?> modelType();

    String modelVersion();
}





final class ContextHolder {

    private static ContextHolder instance = new ContextHolder();

    private ThreadLocal<String> currentContextId = new InheritableThreadLocal<String>();

    public static ContextHolder get() {
        return instance;
    }

    public void setCurrentContextId(String value) {
        currentContextId.set(value);
    }

    public String getCurrentContextId() {
        return currentContextId.get();
    }

    private ContextHolder() {
    }
}





class ModelDescription {

    private final String modelClassName;
    private final String versionString;

    public ModelDescription(String modelClassName, String versionString) {
        this.modelClassName = modelClassName;
        this.versionString = versionString;
    }

    public String getModelClassName() {
        return modelClassName;
    }

    public String getVersionString() {
        return versionString;
    }

    @Override
    public String toString() {
        return modelClassName + ":" + versionString;
    }
}







class ModelWrapper implements OpenEngSBModel {

    private static final long serialVersionUID = 1L;

    protected OpenEngSBModel model;

    protected ModelWrapper(OpenEngSBModel model) {
        this.model = model;
    }

    public static ModelWrapper wrap(Object model) {
        if (!(isModel(model.getClass()))) {
            throw new IllegalArgumentException("The given object is no model");
        }
        return new ModelWrapper((OpenEngSBModel) model);
    }

    public static boolean isModel(Class<?> clazz) {
        return OpenEngSBModel.class.isAssignableFrom(clazz);
    }

    public OpenEngSBModel getUnderlyingModel() {
        return model;
    }

    public ModelDescription getModelDescription() {
        String modelName = retrieveModelName();
        String modelVersion = retrieveModelVersion();
        if (modelName == null || modelVersion == null) {
            throw new IllegalArgumentException("Unsufficient information to create model description.");
        }
        return new ModelDescription(modelName, modelVersion);
    }

    @Override
    public List<OpenEngSBModelEntry> toOpenEngSBModelValues() {
        return model.toOpenEngSBModelValues();
    }

    @Override
    public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
        return model.toOpenEngSBModelEntries();
    }

    @Override
    public Object retrieveInternalModelId() {
        return model.retrieveInternalModelId();
    }

    @Override
    public String retrieveInternalModelIdName() {
        return model.retrieveInternalModelIdName();
    }

    @Override
    public Long retrieveInternalModelTimestamp() {
        return model.retrieveInternalModelTimestamp();
    }

    @Override
    public Integer retrieveInternalModelVersion() {
        return model.retrieveInternalModelVersion();
    }

    @Override
    public void addOpenEngSBModelEntry(OpenEngSBModelEntry entry) {
        model.addOpenEngSBModelEntry(entry);
    }

    @Override
    public void removeOpenEngSBModelEntry(String key) {
        model.removeOpenEngSBModelEntry(key);
    }

    @Override
    public List<OpenEngSBModelEntry> getOpenEngSBModelTail() {
        return model.getOpenEngSBModelTail();
    }

    @Override
    public void setOpenEngSBModelTail(List<OpenEngSBModelEntry> entries) {
        model.setOpenEngSBModelTail(entries);
    }

    @Override
    public String retrieveModelName() {
        return model.retrieveModelName();
    }

    @Override
    public String retrieveModelVersion() {
        return model.retrieveModelVersion();
    }

    public String getCompleteModelOID() {
        return appendContextId(model.retrieveInternalModelId());
    }

    protected String appendContextId(Object modelId) {
        String contextId = ContextHolder.get().getCurrentContextId();
        return String.format("%s/%s", contextId, modelId);
    }
}







class AdvancedModelWrapper extends ModelWrapper {

    private static final long serialVersionUID = 1L;

    public AdvancedModelWrapper(OpenEngSBModel model) {
        super(model);
    }

    public Boolean isEngineeringObject() {
        return isEngineeringObjectClass(model.getClass());
    }

    public static Boolean isEngineeringObjectClass(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            if (field.isAnnotationPresent(OpenEngSBForeignKey.class)) {
                return true;
            }
        }
        return false;
    }
}





class FileWrapper {

    private File file;
    private byte[] content;
    private String filename;
    private int buffer = 2048;
    private String tempDir = System.getProperty("java.io.tmpdir") + File.separator + "OpenEngSBModelTemp";

    public FileWrapper() {
    }

    public FileWrapper(File file) {
        this.file = file;
    }

    public FileWrapper(byte[] content, String filename) {
        this.content = content;
        this.filename = filename;
    }

    public File returnFile() throws IOException {
        if (file == null) {
            deserialize();
        }
        return file;
    }

    public void setFile(File file) {
        this.file = file;
        content = null;
        filename = null;
    }

    public byte[] getContent() throws IOException {
        if (content == null) {
            serialize();
        }
        return content;
    }

    public void setContent(byte[] content) {
        this.content = content;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilename() throws IOException {
        if (filename == null) {
            serialize();
        }
        return filename;
    }

    
    private void serialize() throws IOException {
        if (file == null) {
            throw new IOException("No file and no content set in this FileWrapper");
        }
        filename = file.getName();
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final FileInputStream in = new FileInputStream(file);
        try {
            final byte[] chunk = new byte[buffer];
            int read;
            while ((read = in.read(chunk)) != -1) {
                out.write(chunk, 0, read);
            }
        } finally {
            in.close();
        }
        content = out.toByteArray();
    }

    
    private void deserialize() throws IOException {
        if (content == null || filename == null) {
            throw new IOException("No content and no filename set in this FileWrapper");
        }
        final File dir = new File(tempDir);
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Unable to create the temp directory " + tempDir);
        }
        file = new File(dir, filename);
        final FileOutputStream out = new FileOutputStream(file);
        try {
            out.write(content);
        } finally {
            out.close();
        }
    }

    @Override
    public String toString() {
        return "FileWrapper[filename=" + filename + ", contentLength="
                + (content == null ? "n/a" : String.valueOf(content.length)) + "]";
    }
}





class EDBObjectEntry implements Serializable {

    private static final long serialVersionUID = 1L;

    private String key;
    private Object value;
    private String type;

    public EDBObjectEntry() {
    }

    public EDBObjectEntry(String key, Object value, Class<?> type) {
        this(key, value, type.getName());
    }

    public EDBObjectEntry(String key, Object value, String type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "EDBObjectEntry{key=" + key + ", value=" + value + ", type=" + type + "}";
    }
}





final class EDBConstants {

    private EDBConstants() {
        
    }

    public static final String MODEL_OID = "edbId";
    public static final String MODEL_VERSION = "edbVersion";
    public static final String MODEL_TIMESTAMP = "edbTimestamp";
    public static final String MODEL_TYPE = "modelType";
    public static final String MODEL_TYPE_VERSION = "modelTypeVersion";
}







class EDBObject extends HashMap<String, EDBObjectEntry> {

    private static final long serialVersionUID = 1L;

    private static final String OID_CONST = "oid";
    private static final String DELETED_CONST = "isDeleted";

    public EDBObject(String oid) {
        super();
        setOID(oid);
    }

    public EDBObject(String oid, Map<String, EDBObjectEntry> data) {
        super(data);
        setOID(oid);
    }

    public final Long getTimestamp() {
        return getLong(EDBConstants.MODEL_TIMESTAMP);
    }

    public void updateTimestamp(Long timestamp) {
        putEDBObjectEntry(EDBConstants.MODEL_TIMESTAMP, timestamp);
    }

    public String getOID() {
        return getString(OID_CONST);
    }

    public void setOID(String oid) {
        putEDBObjectEntry(OID_CONST, oid);
    }

    public String getString(String key) {
        return getObject(key, String.class);
    }

    public Boolean getBoolean(String key) {
        return getObject(key, Boolean.class);
    }

    public Short getShort(String key) {
        return getObject(key, Short.class);
    }

    public Integer getInteger(String key) {
        return getObject(key, Integer.class);
    }

    public Long getLong(String key) {
        return getObject(key, Long.class);
    }

    public Float getFloat(String key) {
        return getObject(key, Float.class);
    }

    public Double getDouble(String key) {
        return getObject(key, Double.class);
    }

    public Character getChar(String key) {
        return getObject(key, Character.class);
    }

    public Object getObject(String key) {
        return getObject(key, Object.class);
    }

    @SuppressWarnings("unchecked")
    public <T> T getObject(String key, Class<T> clazz) {
        EDBObjectEntry entry = get(key);
        return entry == null ? null : (T) entry.getValue();
    }

    public final Boolean isDeleted() {
        Boolean deleted = getObject(DELETED_CONST, Boolean.class);
        return deleted != null ? deleted : false;
    }

    public void setDeleted(Boolean deleted) {
        putEDBObjectEntry(DELETED_CONST, deleted);
    }

    public void putEDBObjectEntry(String key, Object value, String type) {
        put(key, new EDBObjectEntry(key, value, type));
    }

    public void putEDBObjectEntry(String key, Object value, Class<?> type) {
        putEDBObjectEntry(key, value, type.getName());
    }

    public void putEDBObjectEntry(String key, Object value) {
        putEDBObjectEntry(key, value, value == null ? Object.class.getName() : value.getClass().getName());
    }
}





class ConnectorInformation {

    private String domainId;
    private String connectorId;
    private String instanceId;

    public ConnectorInformation(String domainId, String connectorId, String instanceId) {
        this.domainId = domainId;
        this.connectorId = connectorId;
        this.instanceId = instanceId;
    }

    public String getDomainId() {
        return domainId;
    }

    public String getConnectorId() {
        return connectorId;
    }

    public String getInstanceId() {
        return instanceId;
    }
}





class EKBException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public EKBException() {
        super();
    }

    public EKBException(String message) {
        super(message);
    }

    public EKBException(Throwable cause) {
        super(cause);
    }

    public EKBException(String message, Throwable cause) {
        super(message, cause);
    }
}


class EDBException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public EDBException(String message) {
        super(message);
    }

    public EDBException(String message, Throwable cause) {
        super(message, cause);
    }
}





interface EngineeringDatabaseService {

    EDBObject getObject(String oid) throws EDBException;

    EDBObject getObject(String oid, Long timestamp) throws EDBException;

    List<EDBObject> getObjects(List<String> oids) throws EDBException;
}











final class Base64 {

    private Base64() {
    }

    public static String encodeBase64String(final byte[] binaryData) {
        if (binaryData == null) {
            return null;
        }
        return java.util.Base64.getEncoder().encodeToString(binaryData);
    }

    public static byte[] decodeBase64(final String base64String) {
        if (base64String == null) {
            return null;
        }
        return java.util.Base64.getDecoder().decode(base64String);
    }
}


final class FieldUtils {

    private FieldUtils() {
    }

    public static Object readField(final Field field, final Object target, final boolean forceAccess)
            throws IllegalAccessException {
        if (forceAccess && !field.isAccessible()) {
            field.setAccessible(true);
        }
        return field.get(target);
    }
}


final class ClassUtils {

    private ClassUtils() {
    }

    public static Class<?> primitiveToWrapper(final Class<?> cls) {
        if (cls == null || !cls.isPrimitive()) {
            return cls;
        }
        if (cls == Integer.TYPE) {
            return Integer.class;
        }
        if (cls == Long.TYPE) {
            return Long.class;
        }
        if (cls == Boolean.TYPE) {
            return Boolean.class;
        }
        if (cls == Double.TYPE) {
            return Double.class;
        }
        if (cls == Float.TYPE) {
            return Float.class;
        }
        if (cls == Short.TYPE) {
            return Short.class;
        }
        if (cls == Byte.TYPE) {
            return Byte.class;
        }
        if (cls == Character.TYPE) {
            return Character.class;
        }
        return cls;
    }
}


interface Logger {

    void trace(String msg);

    void debug(String format, Object... arguments);

    void info(String format, Object... arguments);

    void warn(String msg);

    void warn(String format, Object... arguments);

    void warn(String msg, Throwable t);

    void error(String msg);

    void error(String format, Object... arguments);
}


final class LoggerFactory {

    private LoggerFactory() {
    }

    static Logger getLogger(final Class<?> clazz) {
        final String name = clazz.getSimpleName();
        return new Logger() {
            private void print(final String level, final String format, final Object[] args, final Throwable t) {
                System.out.println("      [" + level + "] " + name + " - " + expand(format, args)
                        + (t == null ? "" : " (" + t.getClass().getSimpleName() + ": " + t.getMessage() + ")"));
            }

            private String expand(final String format, final Object[] args) {
                if (format == null || args == null || args.length == 0) {
                    return String.valueOf(format);
                }
                final StringBuilder sb = new StringBuilder();
                int from = 0;
                int arg = 0;
                while (arg < args.length) {
                    final int at = format.indexOf("{}", from);
                    if (at < 0) {
                        break;
                    }
                    sb.append(format, from, at).append(args[arg++]);
                    from = at + 2;
                }
                return sb.append(format.substring(from)).toString();
            }

            public void trace(String msg) {
                print("TRACE", msg, null, null);
            }

            public void debug(String format, Object... arguments) {
                print("DEBUG", format, arguments, null);
            }

            public void info(String format, Object... arguments) {
                print("INFO ", format, arguments, null);
            }

            public void warn(String msg) {
                print("WARN ", msg, null, null);
            }

            public void warn(String format, Object... arguments) {
                print("WARN ", format, arguments, null);
            }

            public void warn(String msg, Throwable t) {
                print("WARN ", msg, null, t);
            }

            public void error(String msg) {
                print("ERROR", msg, null, null);
            }

            public void error(String format, Object... arguments) {
                print("ERROR", format, arguments, null);
            }
        };
    }
}
