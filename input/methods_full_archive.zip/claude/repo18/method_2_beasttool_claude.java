







































import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class method_2_beasttool_claude {

    public static void main(String[] args) {
        title("METHOD 2  |  SetupPlan.body()");

        section("1. a mock agent registers its DF service");
        run("call-recorder-service", new AgentBehaviour());

        section("2. a second mock agent with a different service name and its own behaviour");
        run("report-service", new AuditingBehaviour());

        section("3. the registered services can be found again through the directory facilitator");
        final SimpleServiceProvider container = new SimpleServiceProvider();
        final DirectoryFacilitatorService df = new DirectoryFacilitatorService(container);
        container.registerService(IDF.class, df);
        setup(container, df, "helpdesk-service", new AgentBehaviour());
        setup(container, df, "billing-service", new AgentBehaviour());
        final IDFComponentDescription template = df.createDFComponentDescription(null,
                df.createDFServiceDescription("billing-service", null, null));
        final IDFComponentDescription[] found = df.search(template, df.createSearchConstraints(-1, 0));
        System.out.println("      registrations held by the DF : " + df.getRegistrations().size());
        System.out.println("      search for billing-service   : " + found.length + " hit(s)");
        for (final IDFComponentDescription hit : found) {
            System.out.println("        " + hit);
        }

        section("4. what the target method does, statement by statement");
        System.out.println("      reads the MockConfiguration out of the triggering IMessageEvent content");
        System.out.println("      stores configuration.getBehaviour() as the agent_behaviour belief fact");
        System.out.println("      builds a DFServiceDescription whose name AND type are the service name,");
        System.out.println("        with the fixed ownership string \"Universidad Politecnica de Madrid\"");
        System.out.println("      wraps it in an IDFComponentDescription");
        System.out.println("      waits WAIT_FOR_TIME (1000 ms) before registering");
        System.out.println("      dispatches the dfcap.df_keep_registered goal with LEASE_TIME (60000 ms)");
        System.out.println("      logs \"<service> registered\"");
        System.out.println("      The method has no conditional branch at all, so every scenario above runs");
        System.out.println("      the same single path with different data; there is nothing left unexercised.");

        title("END OF METHOD 2 SCENARIOS");
    }

    static void run(final String serviceName, final AgentBehaviour behaviour) {
        final SimpleServiceProvider container = new SimpleServiceProvider();
        final DirectoryFacilitatorService df = new DirectoryFacilitatorService(container);
        container.registerService(IDF.class, df);
        final SetupPlan plan = setup(container, df, serviceName, behaviour);
        System.out.println("      agent_behaviour belief fact : "
                + plan.getBeliefbase().getBelief("agent_behaviour").getFact());
        System.out.println("      DF registrations            : " + df.getRegistrations().size());
        for (final IDFComponentDescription registered : df.getRegistrations()) {
            System.out.println("        " + registered.getServices()[0]);
        }
    }

    static SetupPlan setup(final SimpleServiceProvider container, final DirectoryFacilitatorService df,
            final String serviceName, final AgentBehaviour behaviour) {
        final SetupPlan plan = new SetupPlan();
        plan.setServiceContainer(container);

        
        final IMessageEvent trigger = new IMessageEvent("setup_mock");
        trigger.getParameter(SFipa.CONTENT).setValue(new MockConfiguration(serviceName, behaviour));
        plan.setReason(trigger);

        plan.body();
        return plan;
    }

    
    static class AuditingBehaviour extends AgentBehaviour {
        @Override
        public Object processMessage(final String messageType, final Object content) {
            return "audited:" + content;
        }

        @Override
        public String toString() {
            return "AuditingBehaviour";
        }
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}






class AgentBehaviour {

    public Object processMessage(String message_type, String sender_id, Object content) {
        return null;
    }

    public Object processMessage(String message_type, Object content) {
        return null;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}






class MockConfiguration {

    private String dfServiceName;
    private AgentBehaviour behaviour;

    public MockConfiguration(String newDFServiceName, AgentBehaviour newBehaviour) {
        this.dfServiceName = newDFServiceName;
        this.behaviour = newBehaviour;
    }

    public MockConfiguration() {
    }

    public String getDFservice() {
        return this.dfServiceName;
    }

    public AgentBehaviour getBehaviour() {
        return this.behaviour;
    }

    public void setDFServiceName(String dfService) {
        this.dfServiceName = dfService;
    }

    public void setBehaviour(AgentBehaviour behaviour) {
        this.behaviour = behaviour;
    }
}







class SetupPlan extends Plan {

    
    private static final long serialVersionUID = 112334545L;

    private static final int LEASE_TIME = 60000;
    private static final int WAIT_FOR_TIME = 1000;

    
    public void body() {

        MockConfiguration configuration = (MockConfiguration) ((IMessageEvent) getReason())
                .getParameter(SFipa.CONTENT).getValue();
        getBeliefbase().getBelief("agent_behaviour").setFact(
                configuration.getBehaviour());

        
        IServiceProvider iserviceprovider = getScope().getServiceContainer();
        DirectoryFacilitatorService idfservice = new DirectoryFacilitatorService(
                iserviceprovider);
        DFServiceDescription dfaux = (DFServiceDescription) idfservice
                .createDFServiceDescription(configuration.getDFservice(),
                        configuration.getDFservice(),
                        "Universidad Politécnica de Madrid");

        IDFComponentDescription df_description = idfservice
                .createDFComponentDescription(null, dfaux);
        waitFor(WAIT_FOR_TIME);

        IGoal keep = createGoal("dfcap.df_keep_registered");
        keep.getParameter("description").setValue(df_description);
        keep.getParameter("leasetime").setValue(new Long(LEASE_TIME));
        dispatchSubgoalAndWait(keep);

        Logger logger = Logger.getLogger(this.getClass().toString());
        logger.info(configuration.getDFservice() + " registered");
    }
    
}

















class IComponentIdentifier {

    private final String name;
    private final String localName;

    IComponentIdentifier(final String localName, final String platform) {
        this.localName = localName;
        this.name = localName + "@" + platform;
    }

    public String getName() {
        return name;
    }

    public String getLocalName() {
        return localName;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(final Object o) {
        return o instanceof IComponentIdentifier && ((IComponentIdentifier) o).name.equals(name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }
}


interface IDFServiceDescription {

    String getName();

    String getType();

    String getOwnership();
}


class DFServiceDescription implements IDFServiceDescription {

    private String name;
    private String type;
    private String ownership;

    public DFServiceDescription() {
    }

    public DFServiceDescription(final String name, final String type, final String ownership) {
        this.name = name;
        this.type = type;
        this.ownership = ownership;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public String getOwnership() {
        return ownership;
    }

    public void setOwnership(final String ownership) {
        this.ownership = ownership;
    }

    @Override
    public String toString() {
        return "DFServiceDescription[name=" + name + ", type=" + type + ", ownership=" + ownership + "]";
    }
}


interface IDFComponentDescription {

    IComponentIdentifier getName();

    IDFServiceDescription[] getServices();
}


class DFComponentDescription implements IDFComponentDescription {

    private IComponentIdentifier name;
    private final List<IDFServiceDescription> services = new ArrayList<IDFServiceDescription>();

    DFComponentDescription(final IComponentIdentifier name, final IDFServiceDescription service) {
        this.name = name;
        if (service != null) {
            services.add(service);
        }
    }

    public IComponentIdentifier getName() {
        return name;
    }

    public void setName(final IComponentIdentifier name) {
        this.name = name;
    }

    public IDFServiceDescription[] getServices() {
        return services.toArray(new IDFServiceDescription[services.size()]);
    }

    @Override
    public String toString() {
        return "DFComponentDescription[" + name + ", services=" + services + "]";
    }
}


interface ISearchConstraints {

    int getMaxResults();

    int getMaxDepth();
}

class SearchConstraints implements ISearchConstraints {

    private final int maxResults;
    private final int maxDepth;

    SearchConstraints(final int maxResults, final int maxDepth) {
        this.maxResults = maxResults;
        this.maxDepth = maxDepth;
    }

    public int getMaxResults() {
        return maxResults;
    }

    public int getMaxDepth() {
        return maxDepth;
    }

    @Override
    public String toString() {
        return "SearchConstraints[maxResults=" + maxResults + ", maxDepth=" + maxDepth + "]";
    }
}


interface IServiceProvider {

    Object getService(Class<?> type);

    void registerService(Class<?> type, Object service);
}






interface IDF {

    IDFServiceDescription createDFServiceDescription(String name, String type, String ownership);

    IDFComponentDescription createDFComponentDescription(IComponentIdentifier component,
            IDFServiceDescription service);

    ISearchConstraints createSearchConstraints(int maxResults, int maxDepth);

    IDFComponentDescription[] search(IDFComponentDescription template, ISearchConstraints constraints);

    void register(IDFComponentDescription description, long leaseTime);
}

class DirectoryFacilitatorService implements IDF {

    private final IServiceProvider provider;
    private final List<IDFComponentDescription> registrations = new ArrayList<IDFComponentDescription>();

    public DirectoryFacilitatorService(final IServiceProvider provider) {
        this.provider = provider;
    }

    public IServiceProvider getServiceProvider() {
        return provider;
    }

    public IDFServiceDescription createDFServiceDescription(final String name, final String type,
            final String ownership) {
        return new DFServiceDescription(name, type, ownership);
    }

    public IDFComponentDescription createDFComponentDescription(final IComponentIdentifier component,
            final IDFServiceDescription service) {
        return new DFComponentDescription(component, service);
    }

    public ISearchConstraints createSearchConstraints(final int maxResults, final int maxDepth) {
        return new SearchConstraints(maxResults, maxDepth);
    }

    
    public IDFComponentDescription[] search(final IDFComponentDescription template,
            final ISearchConstraints constraints) {
        final List<IDFComponentDescription> hits = new ArrayList<IDFComponentDescription>();
        String wanted = null;
        if (template != null && template.getServices().length > 0) {
            wanted = template.getServices()[0].getName();
        }
        for (final IDFComponentDescription registered : registrations) {
            for (final IDFServiceDescription service : registered.getServices()) {
                if (wanted == null || wanted.equals(service.getName())) {
                    hits.add(registered);
                    break;
                }
            }
            if (constraints != null && constraints.getMaxResults() > 0
                    && hits.size() >= constraints.getMaxResults()) {
                break;
            }
        }
        return hits.toArray(new IDFComponentDescription[hits.size()]);
    }

    public void register(final IDFComponentDescription description, final long leaseTime) {
        registrations.add(description);
        System.out.println("        [df] registered " + description.getName() + " for "
                + leaseTime + " ms");
    }

    public List<IDFComponentDescription> getRegistrations() {
        return registrations;
    }
}


final class RequiredServiceInfo {

    public static final String SCOPE_PLATFORM = "platform";
    public static final String SCOPE_APPLICATION = "application";
    public static final String SCOPE_COMPONENT = "component";
    public static final String SCOPE_GLOBAL = "global";

    private RequiredServiceInfo() {
    }
}





class IFuture {

    private final Object result;

    IFuture(final Object result) {
        this.result = result;
    }

    public Object get(final Object caller) {
        return result;
    }
}


final class SServiceProvider {

    private SServiceProvider() {
    }

    public static IFuture getService(final IServiceProvider provider, final Class<?> type,
            final String scope) {
        System.out.println("        [platform] service lookup " + type.getSimpleName()
                + " with scope " + scope);
        return new IFuture(provider.getService(type));
    }
}


final class SFipa {

    public static final String CONTENT = "content";
    public static final String RECEIVERS = "receivers";
    public static final String SENDER = "sender";
    public static final String PERFORMATIVE = "performative";

    private SFipa() {
    }
}


class IParameter {

    private final String name;
    private Object value;

    IParameter(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setValue(final Object value) {
        this.value = value;
    }

    public Object getValue() {
        return value;
    }
}


class IParameterSet {

    private final String name;
    private final List<Object> values = new ArrayList<Object>();
    private Class<?> componentType = Object.class;

    IParameterSet(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void addValue(final Object value) {
        values.add(value);
        if (value != null && componentType == Object.class) {
            componentType = value.getClass();
        }
    }

    






    public Object[] getValues() {
        final Object[] array = (Object[]) java.lang.reflect.Array.newInstance(componentType, values.size());
        return values.toArray(array);
    }

    public void setValues(final Object[] newValues) {
        values.clear();
        values.addAll(Arrays.asList(newValues));
        componentType = newValues.getClass().getComponentType();
    }
}


class ParameterElement {

    protected final String type;
    protected final Map<String, IParameter> parameters = new LinkedHashMap<String, IParameter>();
    protected final Map<String, IParameterSet> parameterSets = new LinkedHashMap<String, IParameterSet>();

    ParameterElement(final String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public IParameter getParameter(final String name) {
        IParameter parameter = parameters.get(name);
        if (parameter == null) {
            parameter = new IParameter(name);
            parameters.put(name, parameter);
        }
        return parameter;
    }

    public IParameterSet getParameterSet(final String name) {
        IParameterSet set = parameterSets.get(name);
        if (set == null) {
            set = new IParameterSet(name);
            parameterSets.put(name, set);
        }
        return set;
    }
}


class IGoal extends ParameterElement {

    IGoal(final String type) {
        super(type);
    }

    @Override
    public String toString() {
        return "IGoal[" + type + "]";
    }
}


class IMessageEvent extends ParameterElement {

    IMessageEvent(final String type) {
        super(type);
    }

    @Override
    public String toString() {
        return "IMessageEvent[" + type + ", content=" + getParameter(SFipa.CONTENT).getValue()
                + ", receivers=" + Arrays.toString(getParameterSet(SFipa.RECEIVERS).getValues()) + "]";
    }
}


class IBelief {

    private final String name;
    private Object fact;

    IBelief(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Object getFact() {
        return fact;
    }

    public void setFact(final Object fact) {
        this.fact = fact;
        System.out.println("        [beliefbase] " + name + " = " + fact);
    }
}


class IBeliefbase {

    private final Map<String, IBelief> beliefs = new LinkedHashMap<String, IBelief>();

    public IBelief getBelief(final String name) {
        IBelief belief = beliefs.get(name);
        if (belief == null) {
            belief = new IBelief(name);
            beliefs.put(name, belief);
        }
        return belief;
    }

    public boolean containsBelief(final String name) {
        return beliefs.containsKey(name);
    }
}


class AgentScope {

    private final IServiceProvider container;

    AgentScope(final IServiceProvider container) {
        this.container = container;
    }

    public IServiceProvider getServiceContainer() {
        return container;
    }
}








abstract class Plan implements Serializable {

    private static final long serialVersionUID = 1L;

    private final IBeliefbase beliefbase = new IBeliefbase();
    private IServiceProvider container;
    private AgentScope scope;
    private Object reason;
    private final List<IMessageEvent> sent = new ArrayList<IMessageEvent>();

    public abstract void body();

    public IBeliefbase getBeliefbase() {
        return beliefbase;
    }

    public IServiceProvider getServiceContainer() {
        return container;
    }

    public void setServiceContainer(final IServiceProvider container) {
        this.container = container;
        this.scope = new AgentScope(container);
    }

    public AgentScope getScope() {
        return scope;
    }

    public Object getReason() {
        return reason;
    }

    public void setReason(final Object reason) {
        this.reason = reason;
    }

    public IGoal createGoal(final String type) {
        return new IGoal(type);
    }

    public IMessageEvent createMessageEvent(final String type) {
        return new IMessageEvent(type);
    }

    





    public void dispatchSubgoalAndWait(final IGoal goal) {
        final IDF df = (IDF) container.getService(IDF.class);
        if ("dfcap.df_search".equals(goal.getType())) {
            final IDFComponentDescription template =
                    (IDFComponentDescription) goal.getParameter("description").getValue();
            final ISearchConstraints constraints =
                    (ISearchConstraints) goal.getParameter("constraints").getValue();
            final IDFComponentDescription[] hits = df.search(template, constraints);
            goal.getParameterSet("result").setValues(hits);
            System.out.println("        [goal] dfcap.df_search found " + hits.length + " agent(s)");
        } else if ("dfcap.df_keep_registered".equals(goal.getType())) {
            final IDFComponentDescription description =
                    (IDFComponentDescription) goal.getParameter("description").getValue();
            final Long leaseTime = (Long) goal.getParameter("leasetime").getValue();
            df.register(description, leaseTime == null ? 0L : leaseTime.longValue());
            System.out.println("        [goal] dfcap.df_keep_registered completed");
        } else {
            System.out.println("        [goal] " + goal.getType() + " dispatched");
        }
    }

    public void sendMessage(final IMessageEvent message) {
        sent.add(message);
        System.out.println("        [message] " + message.getType() + " sent -> "
                + Arrays.toString(message.getParameterSet(SFipa.RECEIVERS).getValues())
                + "  content=" + message.getParameter(SFipa.CONTENT).getValue());
    }

    public List<IMessageEvent> getSentMessages() {
        return sent;
    }

    public void waitFor(final long millis) {
        System.out.println("        [plan] waitFor(" + millis + " ms)");
    }
}


class SimpleServiceProvider implements IServiceProvider {

    private final Map<Class<?>, Object> services = new LinkedHashMap<Class<?>, Object>();

    public Object getService(final Class<?> type) {
        return services.get(type);
    }

    public void registerService(final Class<?> type, final Object service) {
        services.put(type, service);
    }
}
