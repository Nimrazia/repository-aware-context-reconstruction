









































import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class method_1_beasttool_claude {

    public static void main(String[] args) {
        title("METHOD 1  |  ReceiveCallPlan.body()");

        section("1. an English call, with a report-service agent registered");
        run("English", true, "report-service", "reporter-agent");

        section("2. an English call, but no report-service agent is registered");
        run("English", false, "report-service", null);

        section("3. a non English call, with a helpdesk-service agent registered");
        run("Spanish", true, "helpdesk-service", "helpdesk-agent");

        section("4. a non English call with NO helpdesk agent - the real repository defect");
        System.out.println("      The else branch prints and logs 'Service not found', then falls through");
        System.out.println("      to logger.info(\"Message sent to: \" + agents[0].getName()) OUTSIDE the");
        System.out.println("      length check, so it indexes an empty array. The method is unchanged, so");
        System.out.println("      the ArrayIndexOutOfBoundsException below is the genuine behaviour:");
        try {
            run("Spanish", false, "helpdesk-service", null);
            System.out.println("      !! the expected exception was not thrown");
        } catch (final ArrayIndexOutOfBoundsException e) {
            System.out.println("      ArrayIndexOutOfBoundsException: " + e.getMessage());
        }

        section("5. case insensitive language match - 'english' also takes the first branch");
        run("english", true, "report-service", "reporter-agent");

        section("6. branch coverage summary");
        System.out.println("      language equalsIgnoreCase English, agents found     -> scenarios 1, 5");
        System.out.println("      language equalsIgnoreCase English, no agent found   -> scenario 2");
        System.out.println("      other language, agents found                        -> scenario 3");
        System.out.println("      other language, no agent found                      -> scenario 4");
        System.out.println("      Both branches build their own IDF lookup, DF service description,");
        System.out.println("      component description and search constraints, dispatch the");
        System.out.println("      dfcap.df_search subgoal and read its 'result' parameter set - every one");
        System.out.println("      of those calls really executed against the reconstructed runtime.");

        title("END OF METHOD 1 SCENARIOS");
    }

    static void run(final String language, final boolean registerAgent, final String serviceName,
            final String agentName) {
        final SimpleServiceProvider container = new SimpleServiceProvider();
        final DirectoryFacilitatorService df = new DirectoryFacilitatorService(container);
        container.registerService(IDF.class, df);
        if (registerAgent) {
            df.register(df.createDFComponentDescription(
                    new IComponentIdentifier(agentName, "beast-platform"),
                    df.createDFServiceDescription(serviceName, null, null)), 60000L);
        }

        final CallQueue queue = new CallQueue();
        queue.addCall(new Call(new Customer("Ada Lovelace", language)));

        final ReceiveCallPlan plan = new ReceiveCallPlan();
        plan.setServiceContainer(container);
        plan.getBeliefbase().getBelief("queue").setFact(queue);

        plan.body();

        System.out.println("      messages actually sent : " + plan.getSentMessages().size());
        for (final IMessageEvent message : plan.getSentMessages()) {
            System.out.println("        " + message);
        }
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}









class Customer implements Serializable {

    private static final long serialVersionUID = -5007634153696293397L;

    private final String name;
    private final String language;

    public Customer(final String name, final String language) {
        this.name = name;
        this.language = language;
    }

    public String getName() {
        return name;
    }

    public String getLanguage() {
        return language;
    }

    @Override
    public String toString() {
        return name + " (" + language + ")";
    }
}

class Call implements Serializable {

    private static final long serialVersionUID = -3685095693750125111L;

    private final Customer customer;

    public Call(final Customer customer) {
        this.customer = customer;
    }

    
    public Customer getCustormer() {
        return customer;
    }

    @Override
    public String toString() {
        return "Call from " + customer;
    }
}

class CallQueue {

    private final List<Call> pending = new ArrayList<Call>();

    public CallQueue() {
    }

    public void addCall(final Call call) {
        pending.add(call);
    }

    public Call getPendingCall() {
        return pending.isEmpty() ? null : pending.get(0);
    }
}







class ListenPlan extends Plan {

    private static final long serialVersionUID = 1L;

    @Override
    public void body() {
        
    }
}







class ReceiveCallPlan extends Plan {

	private static final long serialVersionUID = 4357742910363913150L;

	private Logger logger = Logger.getLogger(ListenPlan.class.getName());

	
	@Override
	public void body() {

		CallQueue queue = (CallQueue) getBeliefbase().getBelief("queue")
				.getFact();

		Call call = queue.getPendingCall();
		if (call.getCustormer().getLanguage().equalsIgnoreCase("English")) {

			String target_service = "report-service";
			String msgContent = "NewRecordedCall";

			
			IDF df = (IDF) SServiceProvider.getService(getServiceContainer(),
					IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
			IDFServiceDescription sd = df.createDFServiceDescription(
					target_service, null, null);
			IDFComponentDescription dfadesc = df.createDFComponentDescription(
					null, sd);

			ISearchConstraints constraints = df.createSearchConstraints(-1, 0);

			
			IGoal ft = createGoal("dfcap.df_search");
			ft.getParameter("description").setValue(dfadesc);
			ft.getParameter("constraints").setValue(constraints);

			dispatchSubgoalAndWait(ft);
			IDFComponentDescription[] agents = (IDFComponentDescription[]) ft
					.getParameterSet("result").getValues();

			if (agents.length > 0) {
				IMessageEvent msg = createMessageEvent("send_inform");
				msg.getParameter(SFipa.CONTENT).setValue(msgContent);
				msg.getParameterSet(SFipa.RECEIVERS).addValue(
						agents[0].getName());
				sendMessage(msg);
				logger.info("Message sent to: "
						+ agents[0].getName().getLocalName());
			} else {
				logger.severe("Service " + target_service + " not found.");
			}

		} else {

			System.out.println("Language: " + call.getCustormer().getLanguage());
			String target_service = "helpdesk-service";
			String msgContent = "UnknownLanguageCall";

			
			IDF df = (IDF) SServiceProvider.getService(getServiceContainer(),
					IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
			IDFServiceDescription sd = df.createDFServiceDescription(
					target_service, null, null);
			IDFComponentDescription dfadesc = df.createDFComponentDescription(
					null, sd);

			ISearchConstraints constraints = df.createSearchConstraints(-1, 0);

			
			IGoal ft = createGoal("dfcap.df_search");
			ft.getParameter("description").setValue(dfadesc);
			ft.getParameter("constraints").setValue(constraints);

			dispatchSubgoalAndWait(ft);
			IDFComponentDescription[] agents = (IDFComponentDescription[]) ft
					.getParameterSet("result").getValues();

			IMessageEvent msg = createMessageEvent("helpdesk-request");
			msg.getParameter(SFipa.CONTENT).setValue(msgContent);
			if (agents.length > 0) {
				msg.getParameterSet(SFipa.RECEIVERS).addValue(
						agents[0].getName());
				sendMessage(msg);
				System.out.println("Enviado");
			} else {
				System.out.println("Service " + target_service + " not found.");
				logger.severe("Service " + target_service + " not found.");
			}

			logger.info("Message sent to: " + agents[0].getName());

		}
	}
	
}

















class IComponentIdentifier {

    private final String name;
    private final String localName;

    IComponentIdentifier(final String localName, final String platform) {
        this.localName = localName;
        this.name = localName + "@" + platform;
    }

    public String getName() {
        return name;
    }

    public String getLocalName() {
        return localName;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(final Object o) {
        return o instanceof IComponentIdentifier && ((IComponentIdentifier) o).name.equals(name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }
}


interface IDFServiceDescription {

    String getName();

    String getType();

    String getOwnership();
}


class DFServiceDescription implements IDFServiceDescription {

    private String name;
    private String type;
    private String ownership;

    public DFServiceDescription() {
    }

    public DFServiceDescription(final String name, final String type, final String ownership) {
        this.name = name;
        this.type = type;
        this.ownership = ownership;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public String getOwnership() {
        return ownership;
    }

    public void setOwnership(final String ownership) {
        this.ownership = ownership;
    }

    @Override
    public String toString() {
        return "DFServiceDescription[name=" + name + ", type=" + type + ", ownership=" + ownership + "]";
    }
}


interface IDFComponentDescription {

    IComponentIdentifier getName();

    IDFServiceDescription[] getServices();
}


class DFComponentDescription implements IDFComponentDescription {

    private IComponentIdentifier name;
    private final List<IDFServiceDescription> services = new ArrayList<IDFServiceDescription>();

    DFComponentDescription(final IComponentIdentifier name, final IDFServiceDescription service) {
        this.name = name;
        if (service != null) {
            services.add(service);
        }
    }

    public IComponentIdentifier getName() {
        return name;
    }

    public void setName(final IComponentIdentifier name) {
        this.name = name;
    }

    public IDFServiceDescription[] getServices() {
        return services.toArray(new IDFServiceDescription[services.size()]);
    }

    @Override
    public String toString() {
        return "DFComponentDescription[" + name + ", services=" + services + "]";
    }
}


interface ISearchConstraints {

    int getMaxResults();

    int getMaxDepth();
}

class SearchConstraints implements ISearchConstraints {

    private final int maxResults;
    private final int maxDepth;

    SearchConstraints(final int maxResults, final int maxDepth) {
        this.maxResults = maxResults;
        this.maxDepth = maxDepth;
    }

    public int getMaxResults() {
        return maxResults;
    }

    public int getMaxDepth() {
        return maxDepth;
    }

    @Override
    public String toString() {
        return "SearchConstraints[maxResults=" + maxResults + ", maxDepth=" + maxDepth + "]";
    }
}


interface IServiceProvider {

    Object getService(Class<?> type);

    void registerService(Class<?> type, Object service);
}






interface IDF {

    IDFServiceDescription createDFServiceDescription(String name, String type, String ownership);

    IDFComponentDescription createDFComponentDescription(IComponentIdentifier component,
            IDFServiceDescription service);

    ISearchConstraints createSearchConstraints(int maxResults, int maxDepth);

    IDFComponentDescription[] search(IDFComponentDescription template, ISearchConstraints constraints);

    void register(IDFComponentDescription description, long leaseTime);
}

class DirectoryFacilitatorService implements IDF {

    private final IServiceProvider provider;
    private final List<IDFComponentDescription> registrations = new ArrayList<IDFComponentDescription>();

    public DirectoryFacilitatorService(final IServiceProvider provider) {
        this.provider = provider;
    }

    public IServiceProvider getServiceProvider() {
        return provider;
    }

    public IDFServiceDescription createDFServiceDescription(final String name, final String type,
            final String ownership) {
        return new DFServiceDescription(name, type, ownership);
    }

    public IDFComponentDescription createDFComponentDescription(final IComponentIdentifier component,
            final IDFServiceDescription service) {
        return new DFComponentDescription(component, service);
    }

    public ISearchConstraints createSearchConstraints(final int maxResults, final int maxDepth) {
        return new SearchConstraints(maxResults, maxDepth);
    }

    
    public IDFComponentDescription[] search(final IDFComponentDescription template,
            final ISearchConstraints constraints) {
        final List<IDFComponentDescription> hits = new ArrayList<IDFComponentDescription>();
        String wanted = null;
        if (template != null && template.getServices().length > 0) {
            wanted = template.getServices()[0].getName();
        }
        for (final IDFComponentDescription registered : registrations) {
            for (final IDFServiceDescription service : registered.getServices()) {
                if (wanted == null || wanted.equals(service.getName())) {
                    hits.add(registered);
                    break;
                }
            }
            if (constraints != null && constraints.getMaxResults() > 0
                    && hits.size() >= constraints.getMaxResults()) {
                break;
            }
        }
        return hits.toArray(new IDFComponentDescription[hits.size()]);
    }

    public void register(final IDFComponentDescription description, final long leaseTime) {
        registrations.add(description);
        System.out.println("        [df] registered " + description.getName() + " for "
                + leaseTime + " ms");
    }

    public List<IDFComponentDescription> getRegistrations() {
        return registrations;
    }
}


final class RequiredServiceInfo {

    public static final String SCOPE_PLATFORM = "platform";
    public static final String SCOPE_APPLICATION = "application";
    public static final String SCOPE_COMPONENT = "component";
    public static final String SCOPE_GLOBAL = "global";

    private RequiredServiceInfo() {
    }
}





class IFuture {

    private final Object result;

    IFuture(final Object result) {
        this.result = result;
    }

    public Object get(final Object caller) {
        return result;
    }
}


final class SServiceProvider {

    private SServiceProvider() {
    }

    public static IFuture getService(final IServiceProvider provider, final Class<?> type,
            final String scope) {
        System.out.println("        [platform] service lookup " + type.getSimpleName()
                + " with scope " + scope);
        return new IFuture(provider.getService(type));
    }
}


final class SFipa {

    public static final String CONTENT = "content";
    public static final String RECEIVERS = "receivers";
    public static final String SENDER = "sender";
    public static final String PERFORMATIVE = "performative";

    private SFipa() {
    }
}


class IParameter {

    private final String name;
    private Object value;

    IParameter(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setValue(final Object value) {
        this.value = value;
    }

    public Object getValue() {
        return value;
    }
}


class IParameterSet {

    private final String name;
    private final List<Object> values = new ArrayList<Object>();
    private Class<?> componentType = Object.class;

    IParameterSet(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void addValue(final Object value) {
        values.add(value);
        if (value != null && componentType == Object.class) {
            componentType = value.getClass();
        }
    }

    






    public Object[] getValues() {
        final Object[] array = (Object[]) java.lang.reflect.Array.newInstance(componentType, values.size());
        return values.toArray(array);
    }

    public void setValues(final Object[] newValues) {
        values.clear();
        values.addAll(Arrays.asList(newValues));
        componentType = newValues.getClass().getComponentType();
    }
}


class ParameterElement {

    protected final String type;
    protected final Map<String, IParameter> parameters = new LinkedHashMap<String, IParameter>();
    protected final Map<String, IParameterSet> parameterSets = new LinkedHashMap<String, IParameterSet>();

    ParameterElement(final String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public IParameter getParameter(final String name) {
        IParameter parameter = parameters.get(name);
        if (parameter == null) {
            parameter = new IParameter(name);
            parameters.put(name, parameter);
        }
        return parameter;
    }

    public IParameterSet getParameterSet(final String name) {
        IParameterSet set = parameterSets.get(name);
        if (set == null) {
            set = new IParameterSet(name);
            parameterSets.put(name, set);
        }
        return set;
    }
}


class IGoal extends ParameterElement {

    IGoal(final String type) {
        super(type);
    }

    @Override
    public String toString() {
        return "IGoal[" + type + "]";
    }
}


class IMessageEvent extends ParameterElement {

    IMessageEvent(final String type) {
        super(type);
    }

    @Override
    public String toString() {
        return "IMessageEvent[" + type + ", content=" + getParameter(SFipa.CONTENT).getValue()
                + ", receivers=" + Arrays.toString(getParameterSet(SFipa.RECEIVERS).getValues()) + "]";
    }
}


class IBelief {

    private final String name;
    private Object fact;

    IBelief(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Object getFact() {
        return fact;
    }

    public void setFact(final Object fact) {
        this.fact = fact;
        System.out.println("        [beliefbase] " + name + " = " + fact);
    }
}


class IBeliefbase {

    private final Map<String, IBelief> beliefs = new LinkedHashMap<String, IBelief>();

    public IBelief getBelief(final String name) {
        IBelief belief = beliefs.get(name);
        if (belief == null) {
            belief = new IBelief(name);
            beliefs.put(name, belief);
        }
        return belief;
    }

    public boolean containsBelief(final String name) {
        return beliefs.containsKey(name);
    }
}


class AgentScope {

    private final IServiceProvider container;

    AgentScope(final IServiceProvider container) {
        this.container = container;
    }

    public IServiceProvider getServiceContainer() {
        return container;
    }
}








abstract class Plan implements Serializable {

    private static final long serialVersionUID = 1L;

    private final IBeliefbase beliefbase = new IBeliefbase();
    private IServiceProvider container;
    private AgentScope scope;
    private Object reason;
    private final List<IMessageEvent> sent = new ArrayList<IMessageEvent>();

    public abstract void body();

    public IBeliefbase getBeliefbase() {
        return beliefbase;
    }

    public IServiceProvider getServiceContainer() {
        return container;
    }

    public void setServiceContainer(final IServiceProvider container) {
        this.container = container;
        this.scope = new AgentScope(container);
    }

    public AgentScope getScope() {
        return scope;
    }

    public Object getReason() {
        return reason;
    }

    public void setReason(final Object reason) {
        this.reason = reason;
    }

    public IGoal createGoal(final String type) {
        return new IGoal(type);
    }

    public IMessageEvent createMessageEvent(final String type) {
        return new IMessageEvent(type);
    }

    





    public void dispatchSubgoalAndWait(final IGoal goal) {
        final IDF df = (IDF) container.getService(IDF.class);
        if ("dfcap.df_search".equals(goal.getType())) {
            final IDFComponentDescription template =
                    (IDFComponentDescription) goal.getParameter("description").getValue();
            final ISearchConstraints constraints =
                    (ISearchConstraints) goal.getParameter("constraints").getValue();
            final IDFComponentDescription[] hits = df.search(template, constraints);
            goal.getParameterSet("result").setValues(hits);
            System.out.println("        [goal] dfcap.df_search found " + hits.length + " agent(s)");
        } else if ("dfcap.df_keep_registered".equals(goal.getType())) {
            final IDFComponentDescription description =
                    (IDFComponentDescription) goal.getParameter("description").getValue();
            final Long leaseTime = (Long) goal.getParameter("leasetime").getValue();
            df.register(description, leaseTime == null ? 0L : leaseTime.longValue());
            System.out.println("        [goal] dfcap.df_keep_registered completed");
        } else {
            System.out.println("        [goal] " + goal.getType() + " dispatched");
        }
    }

    public void sendMessage(final IMessageEvent message) {
        sent.add(message);
        System.out.println("        [message] " + message.getType() + " sent -> "
                + Arrays.toString(message.getParameterSet(SFipa.RECEIVERS).getValues())
                + "  content=" + message.getParameter(SFipa.CONTENT).getValue());
    }

    public List<IMessageEvent> getSentMessages() {
        return sent;
    }

    public void waitFor(final long millis) {
        System.out.println("        [plan] waitFor(" + millis + " ms)");
    }
}


class SimpleServiceProvider implements IServiceProvider {

    private final Map<Class<?>, Object> services = new LinkedHashMap<Class<?>, Object>();

    public Object getService(final Class<?> type) {
        return services.get(type);
    }

    public void registerService(final Class<?> type, final Object service) {
        services.put(type, service);
    }
}
