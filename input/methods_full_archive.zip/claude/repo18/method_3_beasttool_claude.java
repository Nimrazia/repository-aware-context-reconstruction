

















































import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

public class method_3_beasttool_claude {

    public static void main(String[] args) throws Exception {
        title("METHOD 3  |  SystemReader.generateJavaFilesForOneStory(String, String, String, String, String, String)");

        final Path work = Files.createTempDirectory("beast-reader");
        final Path stories = work.resolve("stories");
        final Path out = work.resolve("src-test");
        Files.createDirectories(stories);
        Files.createDirectories(out);

        section("1. a complete story with two scenarios, And continuation lines everywhere");
        final Path complete = stories.resolve("recorded_calls.story");
        write(complete, join(
                "Story: Record incoming calls",
                "As a call centre supervisor",
                "And as a quality auditor",
                "I want to record every incoming call",
                "And store the customer language",
                "So that I can audit the service later",
                "And prove compliance",
                "",
                "Scenario: English call is reported",
                "Given a call centre with one pending call",
                "And the customer speaks English",
                "When the receive call plan runs",
                "And the reporter agent is registered",
                "Then a NewRecordedCall message is sent",
                "And the reporter agent receives it",
                "",
                "Scenario: Unknown language goes to helpdesk",
                "Given a call centre with one pending call",
                "When the receive call plan runs",
                "Then an UnknownLanguageCall message is sent"));
        SystemReader.generateJavaFilesForOneStory(complete.toString(), "\"JADEX\"",
                out.toString(), "com.example.stories", "com.example.manager", null);
        report(out, "com/example/stories/RecordIncomingCalls.java");
        report(out, "com/example/manager/UserStoriesManager.java");

        section("2. a second story - the case manager is reopened and appended to, not overwritten");
        final Path second = stories.resolve("billing.story");
        write(second, join(
                "Story - Monthly billing",
                "As a finance officer",
                "I want to generate monthly invoices",
                "So that customers are billed on time",
                "",
                "Scenario - Invoice is generated",
                "Given a customer with three calls",
                "When the billing run executes",
                "Then one invoice is produced"));
        SystemReader.generateJavaFilesForOneStory(second.toString(), "\"JADEX\"",
                out.toString(), "com.example.stories", "com.example.manager", null);
        report(out, "com/example/stories/MonthlyBilling.java");
        report(out, "com/example/manager/UserStoriesManager.java");
        System.out.println("      the manager now holds BOTH stories, because startSystemCaseManager");
        System.out.println("      reopened the existing file and stripped its closing brace");

        section("3. the same story again - fileDoesNotExist() suppresses the test suite rewrite");
        final long before = Files.getLastModifiedTime(
                out.resolve("com/example/stories/MonthlyBilling.java")).toMillis();
        Thread.sleep(20);
        SystemReader.generateJavaFilesForOneStory(second.toString(), "\"JADEX\"",
                out.toString(), "com.example.stories", "com.example.manager", null);
        final long after = Files.getLastModifiedTime(
                out.resolve("com/example/stories/MonthlyBilling.java")).toMillis();
        System.out.println("      test suite file rewritten : " + (after != before)
                + "   (fileDoesNotExist returned false, so createSystemTestSuite was skipped)");
        System.out.println("      addStory was still called, and detected the story is already listed:");
        report(out, "com/example/manager/UserStoriesManager.java");

        section("4. a logging properties file is supplied - the generated constructor differs");
        final Path logged = stories.resolve("logged.story");
        write(logged, join(
                "Story: Logged story",
                "As a developer",
                "I want logging configured",
                "So that I can debug",
                "",
                "Scenario: Something happens",
                "Given a precondition",
                "When an action occurs",
                "Then a result appears"));
        final Path logProps = work.resolve("logging.properties");
        write(logProps, "handlers=java.util.logging.ConsoleHandler");
        SystemReader.generateJavaFilesForOneStory(logged.toString(), "\"JADEX\"",
                out.toString(), "com.example.logged", "com.example.manager2", logProps.toString());
        report(out, "com/example/logged/LoggedStory.java");

        section("5. a file with no Story line - the 'No Story found' branch");
        final Path noStory = stories.resolve("no_story.story");
        write(noStory, join(
                "Scenario: Orphan scenario",
                "Given a precondition",
                "When an action occurs",
                "Then a result appears"));
        SystemReader.generateJavaFilesForOneStory(noStory.toString(), "\"JADEX\"",
                out.toString(), "com.example.orphan", "com.example.manager3", null);
        System.out.println("      no story class was written : "
                + !new File(out.toFile(), "com/example/orphan").exists());

        section("6. a line that matches no keyword - the 'cannot be handed' branch");
        final Path junk = stories.resolve("junk.story");
        write(junk, join(
                "Story: Story with junk",
                "As a user",
                "I want something",
                "So that I benefit",
                "This line matches no keyword at all",
                "",
                "Scenario: Fine scenario",
                "Given a precondition",
                "When an action occurs",
                "Then a result appears"));
        SystemReader.generateJavaFilesForOneStory(junk.toString(), "\"JADEX\"",
                out.toString(), "com.example.junk", "com.example.manager4", null);
        System.out.println("      the two severe log lines above came from the unrecognised line,");
        System.out.println("      and the story was still generated:");
        System.out.println("      generated : "
                + new File(out.toFile(), "com/example/junk/StoryWithJunk.java").exists());

        section("7. the file cannot be read - createFileReader throws BeastException");
        try {
            SystemReader.generateJavaFilesForOneStory(
                    work.resolve("does_not_exist.story").toString(), "\"JADEX\"",
                    out.toString(), "com.example.missing", "com.example.manager5", null);
            System.out.println("      !! the expected exception was not thrown");
        } catch (final BeastException e) {
            System.out.println("      expected BeastException: " + e.getMessage());
            System.out.println("      NOTE: the target method guards with 'if (fileReader == null)', but the");
            System.out.println("      inherited createFileReader(...) throws instead of returning null, so the");
            System.out.println("      'ERROR Reading the file' branch inside the method is unreachable.");
        }

        section("8. branch coverage summary");
        System.out.println("      Story / As a / I want to / So that lines        -> scenarios 1, 2");
        System.out.println("      And continuation for lineType 1, 2 and 3        -> scenario 1");
        System.out.println("      And continuation inside Given, When and Then    -> scenario 1");
        System.out.println("      Scenario line with ':' and with '-' separator   -> scenarios 1, 2");
        System.out.println("      several scenarios in one story                  -> scenario 1");
        System.out.println("      storyName != null, file does not exist yet      -> scenarios 1, 2");
        System.out.println("      storyName != null, file already exists          -> scenario 3");
        System.out.println("      storyName == null                               -> scenario 5");
        System.out.println("      unrecognised non empty line                     -> scenario 6");
        System.out.println("      empty line, ignored                             -> every scenario");
        System.out.println("      loggingPropFile == null and != null             -> scenarios 1 and 4");
        System.out.println("      fileReader == null                              -> unreachable, see scenario 7");

        title("END OF METHOD 3 SCENARIOS");
    }

    static String join(final String... lines) {
        final StringBuilder sb = new StringBuilder();
        for (final String line : lines) {
            sb.append(line).append('\n');
        }
        return sb.toString();
    }

    static void write(final Path path, final String content) throws IOException {
        Files.write(path, content.getBytes(StandardCharsets.UTF_8));
    }

    static void report(final Path root, final String relative) throws IOException {
        final Path file = root.resolve(relative);
        System.out.println("      ---- " + relative + " ----");
        if (!Files.exists(file)) {
            System.out.println("          <not generated>");
            return;
        }
        for (final String line : Files.readAllLines(file)) {
            if (!line.trim().isEmpty()) {
                System.out.println("          " + line);
            }
        }
    }

    static void title(final String s) {
        System.out.println();
        System.out.println("################################################################################");
        System.out.println("# " + s);
        System.out.println("################################################################################");
    }

    static void section(final String s) {
        System.out.println();
        System.out.println("--- " + s + " ---");
    }
}





class BeastException extends Exception {

    private static final long serialVersionUID = -2996699933056365412L;

    public BeastException(String message) {
        super(message);
    }

    public BeastException(Throwable cause) {
        super(cause);
    }

    public BeastException(String message, Throwable cause) {
        super(message, cause);
    }
}









class Reader {

    public static final String MAS = "MAS";
    public static final String SYSTEM = "SYSTEM";

    private static Logger logger = Logger.getLogger(Reader.class.getName());

    public static String changeFirstLetterToCapital(String word) {
        char[] letras = word.toCharArray();
        char a = letras[0];
        letras[0] = Character.toUpperCase(a);
        return new String(letras);
    }

    public static String changeFirstLetterToLowerCase(String word) {
        char[] letras = word.toCharArray();
        char a = letras[0];
        letras[0] = Character.toLowerCase(a);
        return new String(letras);
    }

    public static String createClassName(String scenarioDescription) {
        String[] words = scenarioDescription.trim().split(" ");
        String name = "";
        for (int i = 0; i < words.length; i++) {
            name += changeFirstLetterToCapital(words[i]);
        }
        return name;
    }

    public static String createFirstLowCaseName(String scenarioDescription) {
        String[] words = scenarioDescription.trim().split(" ");
        String name = "";
        for (int i = 0; i < words.length; i++) {
            name += changeFirstLetterToCapital(words[i]);
        }
        return changeFirstLetterToLowerCase(name);
    }

    protected static boolean fileDoesNotExist(String file, String path, String dest_dir) {
        File f = new File(dest_dir);
        if (!f.isDirectory())
            return false;
        String folderPath = createFolderPath(path);
        f = new File(f, folderPath);
        File javaFile = new File(f, file);
        boolean result = !javaFile.exists();
        return result;
    }

    public static File createFolder(String path, String dest_dir) throws BeastException {
        File f = new File(dest_dir);
        if (!f.isDirectory()) {
            try {
                f.mkdirs();
            } catch (Exception e) {
                logger.severe("Problem creating directory: " + path + File.separator + dest_dir);
            }
        }
        String folderPath = createFolderPath(path);
        f = new File(f, folderPath);
        if (!f.isDirectory()) {
            try {
                f.mkdirs();
            } catch (Exception e) {
                String message = "Problem creating directory: " + path + File.separator + dest_dir;
                logger.severe(message);
                throw new BeastException(message, e);
            }
        }
        return f;
    }

    public static String createFolderPath(String path) {
        String[] pathParts = path.split("\\.");
        String path2 = "";
        for (String part : pathParts) {
            if (path2.equals("")) {
                path2 = part;
            } else {
                path2 = path2 + File.separator + changeFirstLetterToLowerCase(createClassName(part));
            }
        }
        return path2;
    }

    protected static String createTestPath(String aux_package_path, String scenarioName) {
        return aux_package_path + "." + scenarioName;
    }

    protected static BufferedReader createFileReader(String file_name) throws BeastException {
        try {
            return new BufferedReader(new FileReader(file_name));
        } catch (FileNotFoundException e) {
            Logger logger = Logger.getLogger(Reader.class.getName());
            logger.severe("ERROR: " + e.toString());
            throw new BeastException("ERROR: " + e.toString(), e);
        }
    }
}







class CreateSystemCaseManager {

    public static File startSystemCaseManager(String package_path,
            String dest_dir) throws BeastException {

        Logger logger = Logger
                .getLogger("CreateSystemCaseManager.startSystemCaseManager");

        File folder = SystemReader.createFolder(package_path, dest_dir);
        File caseManager = new File(folder, "UserStoriesManager.java");
        FileWriter caseManagerWriter;
        try {
            if (!caseManager.exists()) {
                caseManagerWriter = new FileWriter(caseManager);
                caseManagerWriter.write("package " + package_path + ";\n");
                caseManagerWriter.write("\n");
                caseManagerWriter.write("import org.junit.Assert;\n");
                caseManagerWriter.write("import org.junit.Test;\n");
                caseManagerWriter.write("import org.junit.runner.JUnitCore;\n");
                caseManagerWriter.write("import org.junit.runner.Result;\n");
                
                caseManagerWriter.write("\n");
                caseManagerWriter.write("/**\n");
                caseManagerWriter
                        .write(" * Main class to launch all tests in a single run\n");
                caseManagerWriter.write(" *\n");
                caseManagerWriter.write(" * @author es.upm.dit.gsi.beast\n");
                caseManagerWriter.write(" */\n");
                caseManagerWriter.write("public class UserStoriesManager {\n");
                caseManagerWriter.write("\n");
                caseManagerWriter.flush();
                caseManagerWriter.close();
                
            } else {
                List<String> lines = new ArrayList<String>();

                
                BufferedReader r = new BufferedReader(new FileReader(
                        caseManager));
                String in;
                while ((in = r.readLine()) != null) {
                    lines.add(in);
                }
                r.close();

                lines.remove(lines.size() - 1);

                
                PrintWriter w = new PrintWriter(new FileWriter(caseManager));
                for (String line : lines) {
                    w.println(line);
                }
                w.close();
            }
        } catch (IOException e) {
            logger.severe("ERROR writing Case Manager file");
            throw new BeastException("ERROR writing Case Manager file", e);
        }

        return caseManager;
    }

    public static void addStory(File caseManager, String storyName,
            String testPath, String user, String feature, String benefit) throws BeastException {
        FileWriter caseManagerWriter;

        String storyClass = SystemReader.createClassName(storyName);
        try {
            BufferedReader reader = new BufferedReader(new FileReader(
                    caseManager));
            String targetLine1 = "  public void " + storyClass + "() {";
            String targetLine2 = "     Result result = JUnitCore.runClasses(" + testPath
                    + "." + storyClass + ".class);";
            String in;
            while ((in = reader.readLine()) != null) {
                if (in.equals(targetLine1)) {
                    while ((in = reader.readLine()) != null) {
                        if (in.equals(targetLine2)) {
                            reader.close();
                            
                            return;
                        }
                    }
                    reader.close();
                    throw new BeastException("Two different stories with the same name (same method name) are being created in the same CaseManager file. That is not possible. Please, change the name of the story: " + testPath + "."
                            + storyClass + ".java");
                }
            }
            reader.close();
            
            caseManagerWriter = new FileWriter(caseManager, true);
            caseManagerWriter.write("  /**\n");
            caseManagerWriter.write("   * This is the story: " + storyName
                    + "\n");
            caseManagerWriter.write("   * requested by: " + user + "\n");
            caseManagerWriter.write("   * providing the feature: " + feature
                    + "\n");
            caseManagerWriter.write("   * so the user gets the benefit: "
                    + benefit + "\n");
            caseManagerWriter.write("   */\n");
            caseManagerWriter.write("  @Test\n");

            caseManagerWriter.write("  public void " + storyClass + "() {\n");
            caseManagerWriter.write("     Result result = JUnitCore.runClasses(" + testPath
                    + "." + storyClass + ".class);\n");
            caseManagerWriter.write("     Assert.assertTrue(result.wasSuccessful());\n");
            caseManagerWriter.write("  }\n");
            caseManagerWriter.write("\n");
            caseManagerWriter.flush();
            caseManagerWriter.close();
        } catch (IOException e) {
            Logger logger = Logger.getLogger("CreateMASCaseManager.createTest");
            logger.info("ERROR writing the file");
        }

    }

    public static void closeSystemCaseManager(File caseManager) {

        FileWriter caseManagerWriter;
        try {
            caseManagerWriter = new FileWriter(caseManager, true);
            caseManagerWriter.write("}\n");
            caseManagerWriter.flush();
            caseManagerWriter.close();
        } catch (IOException e) {
            Logger logger = Logger
                    .getLogger("CreateSystemCaseManager.closeSystemCaseManager");
            logger.info("ERROR: There is a mistake closing caseManager file.\n");
        }

    }
}







class CreateSystemTestSuite {

    public static void createSystemTestSuite(String story_name,
            String platform_name, String package_path, String dest_dir,
            String loggingPropFile, String storyUser, String userFeature,
            String userBenefit, HashMap<String, String[]> scenarios)
            throws BeastException {

        Logger logger = Logger.getLogger(CreateSystemTestSuite.class.getName());

        File f = SystemReader.createFolder(package_path, dest_dir);

        String storyClass = SystemReader.createClassName(story_name);
        File javaFile = new File(f, storyClass + ".java");

        try {
            FileWriter fw = new FileWriter(javaFile);
            fw.write("package " + package_path + ";\n");
            fw.write("\n");

            
            fw.write("import es.upm.dit.gsi.beast.story.logging.LogActivator;\n");
            fw.write("import es.upm.dit.gsi.beast.story.BeastTestCaseRunner;\n");
            fw.write("import java.io.FileInputStream;\n");
            fw.write("import java.io.IOException;\n");
            fw.write("import java.util.logging.Logger;\n");
            fw.write("import java.util.logging.Level;\n");
            fw.write("import java.util.logging.LogManager;\n");
            fw.write("import java.util.Properties;\n");
            fw.write("import org.junit.Assert;\n");
            fw.write("import org.junit.Test;\n");
            fw.write("import org.junit.runner.JUnitCore;\n");
            fw.write("import org.junit.runner.Result;\n");
            fw.write("\n");

            
            fw.write("/**\n");
            fw.write(" * Main class to translate plain text into code, following the Given-When-Then\n");
            fw.write(" * language. In the GIVEN part it launchs the platform In the WHEN part it\n");
            fw.write(" * configures the state of its agents. In the THEN part it checks the correct\n");
            fw.write(" * behaviour. The main purpose of it consists of knowing agents' state/properties\n");
            fw.write(" * without changing its code.\n");
            fw.write(" * \n");
            fw.write(" * \n");
            fw.write(" * This \"UserStory\" is described as follows:\n");
            fw.write(" * Story: " + story_name + "\n");
            fw.write(" * As a " + storyUser + "\n");
            fw.write(" * I want to " + userFeature + "\n");
            fw.write(" * So that " + userBenefit + "\n");
            fw.write(" * \n");
            fw.write(" * @author es.upm.dit.gsi.beast\n");
            fw.write(" */\n");
            fw.write("public class " + storyClass + "{\n");
            fw.write("\n");
            fw.write("    public Logger logger = Logger.getLogger("
                    + storyClass + ".class.getName());\n");
            fw.write("\n");

            
            fw.write("    /**\n");
            fw.write("     * Constructor to configure logging\n");
            fw.write("     */\n");
            fw.write("    public " + storyClass + "() {\n");
            if (loggingPropFile == null) {
                
                fw.write("         LogActivator.logToFile(logger, "
                        + storyClass + ".class.getName(), Level.ALL);\n");
            } else {
                fw.write("         Properties preferences = new Properties();\n");
                fw.write("         try {\n");
                fw.write("              FileInputStream configFile = new FileInputStream(\""
                        + loggingPropFile + "\");\n");
                fw.write("              preferences.load(configFile);\n");
                fw.write("              LogManager.getLogManager().readConfiguration(configFile);\n");
                fw.write("              LogActivator.logToFile(logger, "
                        + storyClass + ".class.getName(), Level.ALL);\n");
                fw.write("         } catch (IOException ex) {\n");
                fw.write("              logger.severe(\"WARNING: Could not open configuration file\");\n");
                fw.write("         }\n");
            }
            fw.write("    }\n");
            fw.write("\n");

            
            
            
            
            for (String scenario : scenarios.keySet()) {
                fw.write("  /**\n");
                fw.write("   * This is the scenario: " + scenario + "\n");
                fw.write("   * where the GIVEN is described as: "
                        + scenarios.get(scenario)[0] + "\n");
                fw.write("   * the WHEN is described as: "
                        + scenarios.get(scenario)[1] + "\n");
                fw.write("   * and the THEN is described as: "
                        + scenarios.get(scenario)[2] + "\n");
                fw.write("   */\n");
                fw.write("    @Test\n");
                fw.write("    public void "
                        + SystemReader.changeFirstLetterToLowerCase(scenario)
                        + "() {\n");
                
                
                
                

                fw.write("        // Here you must call the MAS tests for this scenario\n");
                fw.write("        // or the scenarios themselves\n");
                fw.write("        // EXAMPLE 1:\n");
                fw.write("        // BeastTestCaseRunner.executeBeastTestCase("
                        + "\"es.upm.dit.gsi.beast.reader.mas.test.MASTestScenario\");\n");
                fw.write("\n");
                fw.write("        // EXAMPLE 2:\n");
                fw.write("        // Result result = JUnitCore.runClasses(es.upm.dit.gsi.beast.reader.mas.test.MASTestStory.class\");\n");
                fw.write("        // Assert.assertTrue(result.wasSuccessful());\n");
                fw.write("         logger.warning(\"Implement this method in "
                        + package_path
                        + scenario
                        + ".java -> Auto-generated stub by Beast -> es.upm.dit.gsi.beast-tool\");\n");
                fw.write("         System.out.println(\"IMPORTANT!! -> Not implemented Test. Auto-generated stub by Beast -> es.upm.dit.gsi.beast-tool in class\"+ this.getClass().getName());\n");
                fw.write("         Assert.fail(\"Not implemented Test. Auto-generated stub by Beast -> es.upm.dit.gsi.beast-tool\");\n");

                fw.write("    }\n");
                fw.write("\n");
            }

            
            
            fw.write("}\n");
            fw.write("\n");
            fw.flush();
            fw.close();

            

        } catch (IOException e) {

            logger.severe("ERROR: The file " + story_name
                    + ".java can not be writed");
        }
    }
}







class SystemReader extends Reader {

    private static Logger logger = Logger.getLogger(SystemReader.class.getName());

    public static void generateJavaFiles(String requirementsFolder, String platformName,
            String src_test_dir, String tests_package, String casemanager_package,
            String loggingPropFile) throws Exception {

        File reqFolder = new File(requirementsFolder);
        if (reqFolder.isDirectory()) {
            for (File f : reqFolder.listFiles()) {
                if (f.getName().endsWith(".story")) {
                    try {
                        SystemReader.generateJavaFilesForOneStory(f.getCanonicalPath(), platformName,
                                src_test_dir, tests_package, casemanager_package, loggingPropFile);
                    } catch (IOException e) {
                        String message = "ERROR: " + e.getMessage();
                        logger.severe(message);
                        throw new BeastException(message, e);
                    }
                }
            }
            for (File f : reqFolder.listFiles()) {
                if (f.isDirectory()) {
                    SystemReader.generateJavaFiles(requirementsFolder + File.separator + f.getName(),
                            platformName, src_test_dir, tests_package + "." + f.getName(),
                            casemanager_package, loggingPropFile);
                }
            }
        } else if (reqFolder.getName().endsWith(".story")) {
            SystemReader.generateJavaFilesForOneStory(requirementsFolder, platformName, src_test_dir,
                    tests_package, casemanager_package, loggingPropFile);
        } else {
            String message = "No story file found in " + requirementsFolder;
            logger.severe(message);
            throw new BeastException(message);
        }
    }

    
    public static void generateJavaFilesForOneStory(String storyFilePath,
            String platformName, String src_test_dir, String tests_package,
            String casemanager_package, String loggingPropFile)
            throws Exception {

        




        HashMap<String, String[]> scenarios = new HashMap<String, String[]>();
        String storyName = null;
        String story_user = null;
        String user_feature = null;
        String user_benefit = null;
        BufferedReader fileReader = createFileReader(storyFilePath);
        if (fileReader == null) {
            logger.severe("ERROR Reading the file " + storyFilePath);
        } else {
            
            
            
            File caseManager = CreateSystemCaseManager.startSystemCaseManager(
                    casemanager_package, src_test_dir);
            try {
                String nextLine = null;
                
                
                
                
                int lineType = 0;
                while ((nextLine = fileReader.readLine()) != null) {

                    
                    

                    if (nextLine.startsWith("Story")) {
                        String aux = nextLine.replaceFirst("Story", "").trim();
                        if (aux.startsWith(":") || aux.startsWith("-")) {
                            aux = aux.substring(1).trim();
                        }
                        storyName = aux;
                    } else if (nextLine.startsWith("As a")) {
                        story_user = nextLine.replaceFirst("As a", "").trim();
                        lineType = 1;
                    } else if (nextLine.startsWith("I want to")) {
                        user_feature = nextLine.replaceFirst("I want to", "")
                                .trim();
                        lineType = 2;
                    } else if (nextLine.startsWith("So that")) {
                        user_benefit = nextLine.replaceFirst("So that", "")
                                .trim();
                        lineType = 3;
                    } else if (nextLine.startsWith("And")) {
                        switch (lineType) {
                        case 1:
                            story_user= story_user + " and " + nextLine.replaceFirst("And", "").trim();
                            break;
                        case 2:
                            user_feature= user_feature + " and " + nextLine.replaceFirst("And", "").trim();                            
                            break;
                        case 3:
                            user_benefit= user_benefit + " and " + nextLine.replaceFirst("And", "").trim();                            
                            break;
                        default:
                            break;
                        }
                    } else if (nextLine.startsWith("Scenario")) {

                        
                        

                        String aux = nextLine.replaceFirst("Scenario", "").trim();
                        if (aux.startsWith(":") || aux.startsWith("-")) {
                            aux = aux.substring(1).trim();
                        }
                        aux.toLowerCase();
                        String scenarioID = createClassName(aux);
                        while (!fileReader.ready()) {
                            Thread.yield();
                        }
                        nextLine = fileReader.readLine();
                        String givenDescription = nextLine.replaceFirst(
                                "Given", "").trim();

                        while (!fileReader.ready()) {
                            Thread.yield();
                        }
                        nextLine = fileReader.readLine();
                        while (nextLine.startsWith("And")) {
                            givenDescription = givenDescription + " and " + nextLine.replaceFirst("And", "").trim();
                            while (!fileReader.ready()) {
                                Thread.yield();
                            }
                            nextLine = fileReader.readLine();
                        }
                        String whenDescription = nextLine.replaceFirst("When",
                                "").trim();

                        while (!fileReader.ready()) {
                            Thread.yield();
                        }
                        nextLine = fileReader.readLine();
                        while (nextLine.startsWith("And")) {
                            whenDescription = whenDescription + " and " + nextLine.replaceFirst("And", "").trim();
                            while (!fileReader.ready()) {
                                Thread.yield();
                            }
                            nextLine = fileReader.readLine();
                        }
                        String thenDescription = nextLine.replaceFirst("Then",
                                "").trim();
                        
                        nextLine = fileReader.readLine();
                        
                        while (nextLine!=null && nextLine.startsWith("And")) {
                            thenDescription = thenDescription +  " and " + nextLine.replaceFirst("And", "").trim();
                            nextLine = fileReader.readLine();
                        }

                        String[] scenarioData = new String[3];
                        scenarioData[0] = givenDescription;
                        scenarioData[1] = whenDescription;
                        scenarioData[2] = thenDescription;

                        scenarios.put(scenarioID, scenarioData);
                    } else if (!nextLine.trim().isEmpty()) {
                        
                        logger.severe("ERROR: The test writen in the plain text can not be handed");
                        logger.severe("Try again whit the following key-words: {Story -,"
                                + " As a, I want to, So that, Scenario:, Given, When, Then}");
                    } 
                      
                }

                fileReader.close();

                

                if (storyName != null) {
                    
                    if (fileDoesNotExist(createClassName(storyName) + ".java", tests_package,
                            src_test_dir)) {
                        CreateSystemTestSuite.createSystemTestSuite(storyName,
                                platformName, tests_package, src_test_dir,
                                loggingPropFile, story_user, user_feature,
                                user_benefit, scenarios);
                    }
                    CreateSystemCaseManager.addStory(caseManager, storyName,
                            tests_package, story_user, user_feature,
                            user_benefit);

                } else {

                    
                    
                    
                    

                    logger.severe("ERROR: No Story found in :" + storyFilePath);

                }

                CreateSystemCaseManager.closeSystemCaseManager(caseManager);

            } catch (Exception e) {
                logger.severe("ERROR: " + e.getMessage());
                throw e;
            }
        }
    }
    
}
