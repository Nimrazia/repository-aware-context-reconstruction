

































import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class method_1_isisexcel_claude {

  
  
  
  
  
  enum SemanticsOf {
    SAFE, IDEMPOTENT, NON_IDEMPOTENT
  }

  enum InvokeOn {
    OBJECT_ONLY, COLLECTION_ONLY, OBJECT_AND_COLLECTION
  }

  
  
  enum InvokedOn {
    OBJECT, COLLECTION;

    boolean isCollection() {
      return this == COLLECTION;
    }
  }

  @Retention(RetentionPolicy.RUNTIME)
  @Target(ElementType.METHOD)
  @interface Action {
    SemanticsOf semantics() default SemanticsOf.NON_IDEMPOTENT;

    InvokeOn invokeOn() default InvokeOn.OBJECT_ONLY;
  }

  static class ActionInvocationContext {
    private InvokedOn invokedOn;

    InvokedOn getInvokedOn() {
      return invokedOn;
    }

    void setInvokedOn(InvokedOn invokedOn) {
      this.invokedOn = invokedOn;
    }
  }

  interface DomainObjectContainer {
    void warnUser(String message);
  }

  static class SimpleDomainObjectContainer implements DomainObjectContainer {
    final List<String> warnings = new ArrayList<>();

    @Override
    public void warnUser(String message) {
      warnings.add(message);
      System.out.println("[warnUser] " + message);
    }
  }

  
  
  
  
  
  static class ExcelModuleDemoToDoItem {
    String description;
    String category;
    String subcategory;
    LocalDate dueBy;
    BigDecimal cost;
    String notes;
    String ownedBy;
    boolean complete;

    void setDescription(String d) {
      description = d;
    }

    void setCategory(String c) {
      category = c;
    }

    void setSubcategory(String s) {
      subcategory = s;
    }

    void setDueBy(LocalDate d) {
      dueBy = d;
    }

    void setCost(BigDecimal c) {
      cost = c;
    }

    void setNotes(String n) {
      notes = n;
    }

    void setOwnedBy(String o) {
      ownedBy = o;
    }

    void setComplete(boolean c) {
      complete = c;
    }

    @Override
    public String toString() {
      return "ExcelModuleDemoToDoItem{description=" + description + ", category=" + category + ", subcategory="
          + subcategory + ", dueBy=" + dueBy + ", cost=" + cost + ", notes=" + notes + ", ownedBy=" + ownedBy
          + ", complete=" + complete + "}";
    }
  }

  static class ExcelModuleDemoToDoItems {
    final List<ExcelModuleDemoToDoItem> items = new ArrayList<>();

    ExcelModuleDemoToDoItem findByDescription(String description) {
      for (ExcelModuleDemoToDoItem item : items) {
        if (item.description != null && item.description.equals(description)) {
          return item;
        }
      }
      return null;
    }

    
    
    
    ExcelModuleDemoToDoItem newToDo(String description, String category, String subcategory, LocalDate dueBy,
        BigDecimal cost) {
      ExcelModuleDemoToDoItem item = new ExcelModuleDemoToDoItem();
      item.description = description;
      item.category = category;
      item.subcategory = subcategory;
      item.dueBy = dueBy;
      item.cost = cost;
      items.add(item);
      return item;
    }
  }

  
  
  
  
  
  ExcelModuleDemoToDoItems toDoItems;
  ActionInvocationContext actionInvocationContext;
  DomainObjectContainer container;

  private ExcelModuleDemoToDoItem toDoItem; 
  private String description;
  private String category;
  private String subcategory;
  private LocalDate dueBy;
  private BigDecimal cost;
  private String notes;
  private String ownedBy;
  private boolean complete;

  ExcelModuleDemoToDoItem getToDoItem() {
    return toDoItem;
  }

  String getDescription() {
    return description;
  }

  String getCategory() {
    return category;
  }

  String getSubcategory() {
    return subcategory;
  }

  LocalDate getDueBy() {
    return dueBy;
  }

  BigDecimal getCost() {
    return cost;
  }

  String getNotes() {
    return notes;
  }

  String getOwnedBy() {
    return ownedBy;
  }

  boolean isComplete() {
    return complete;
  }

  DomainObjectContainer getContainer() {
    return container;
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  @Action(
            semantics = SemanticsOf.IDEMPOTENT,
            invokeOn = InvokeOn.OBJECT_AND_COLLECTION
    )
    public ExcelModuleDemoToDoItem apply() {
        ExcelModuleDemoToDoItem item = getToDoItem();
        if(item == null) {
            
            item = toDoItems.findByDescription(getDescription());
            if(item != null) {
                getContainer().warnUser("Item already exists with description '" + getDescription() + "'");
            } else {
                
                
                item = toDoItems.newToDo(getDescription(), getCategory(), getSubcategory(), getDueBy(), getCost());
                item.setNotes(getNotes());
                item.setOwnedBy(getOwnedBy());
                item.setComplete(isComplete());
            }
        } else {
            
            
            item.setDescription(getDescription());
            item.setCategory(getCategory());
            item.setSubcategory(getSubcategory());
            item.setDueBy(getDueBy());
            item.setCost(getCost());
            item.setNotes(getNotes());
            item.setOwnedBy(getOwnedBy());
            item.setComplete(isComplete());
        }
        return actionInvocationContext.getInvokedOn().isCollection()? null: item;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: ExcelModuleDemoToDoItemBulkUpdateLineItem.apply ===");

    ExcelModuleDemoToDoItems repo = new ExcelModuleDemoToDoItems();
    SimpleDomainObjectContainer container = new SimpleDomainObjectContainer();

    
    method_1_isisexcel_claude lineA = new method_1_isisexcel_claude();
    lineA.toDoItems = repo;
    lineA.container = container;
    lineA.actionInvocationContext = new ActionInvocationContext();
    lineA.actionInvocationContext.setInvokedOn(InvokedOn.OBJECT);
    lineA.description = "Buy milk";
    lineA.category = "Household";
    lineA.subcategory = "Shopping";
    lineA.dueBy = LocalDate.now().plusDays(1);
    lineA.cost = new BigDecimal("3.50");
    lineA.notes = "2 litres";
    lineA.ownedBy = "alice";
    lineA.complete = false;

    ExcelModuleDemoToDoItem resultA = lineA.apply();
    System.out.println("\n-- Scenario A (new item, single-object invocation) --");
    System.out.println("  returned: " + resultA);
    System.out.println("  repo size: " + repo.items.size());

    
    method_1_isisexcel_claude lineB = new method_1_isisexcel_claude();
    lineB.toDoItems = repo;
    lineB.container = container;
    lineB.actionInvocationContext = new ActionInvocationContext();
    lineB.actionInvocationContext.setInvokedOn(InvokedOn.COLLECTION);
    lineB.description = "Buy milk"; 
    lineB.category = "Household";
    lineB.subcategory = "Shopping";
    lineB.dueBy = LocalDate.now().plusDays(2);
    lineB.cost = new BigDecimal("4.00");
    lineB.notes = "3 litres";
    lineB.ownedBy = "bob";
    lineB.complete = false;

    ExcelModuleDemoToDoItem resultB = lineB.apply();
    System.out.println("\n-- Scenario B (duplicate description, bulk/collection invocation) --");
    System.out.println("  returned: " + resultB + " (expected null: collection invocation)");
    System.out.println("  warnings recorded: " + container.warnings);
    System.out.println("  repo size unchanged: " + repo.items.size());

    
    method_1_isisexcel_claude lineC = new method_1_isisexcel_claude();
    lineC.toDoItems = repo;
    lineC.container = container;
    lineC.actionInvocationContext = new ActionInvocationContext();
    lineC.actionInvocationContext.setInvokedOn(InvokedOn.OBJECT);
    lineC.toDoItem = resultA; 
    lineC.description = "Buy oat milk";
    lineC.category = "Household";
    lineC.subcategory = "Shopping";
    lineC.dueBy = LocalDate.now().plusDays(3);
    lineC.cost = new BigDecimal("4.20");
    lineC.notes = "oat milk, 2 litres";
    lineC.ownedBy = "alice";
    lineC.complete = true;

    ExcelModuleDemoToDoItem resultC = lineC.apply();
    System.out.println("\n-- Scenario C (update existing item) --");
    System.out.println("  returned (same instance, updated): " + resultC);

    System.out.println("\n=== Demo complete: method exercised the new-item/no-duplicate branch, "
        + "the duplicate-description warnUser branch, the update-existing-item branch, and both "
        + "the single-object and collection InvokedOn return-value branches. ===");
  }
}
