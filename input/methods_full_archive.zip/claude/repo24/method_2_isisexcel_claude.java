

































import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.UUID;

public class method_2_isisexcel_claude {

  
  
  
  
  
  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
  @interface Nullable {
  }

  interface Function<F, T> {
    T apply(@Nullable F input);
  }

  static class ImmutableSet<E> implements Iterable<E> {
    private final LinkedHashSet<E> delegate;

    private ImmutableSet(LinkedHashSet<E> delegate) {
      this.delegate = delegate;
    }

    static <E> ImmutableSet<E> copyOf(Iterable<E> elements) {
      LinkedHashSet<E> set = new LinkedHashSet<>();
      for (E e : elements) {
        set.add(e);
      }
      return new ImmutableSet<>(set);
    }

    int size() {
      return delegate.size();
    }

    public java.util.Iterator<E> iterator() {
      return delegate.iterator();
    }
  }

  static class FluentIterable<E> implements Iterable<E> {
    private final Iterable<E> delegate;

    private FluentIterable(Iterable<E> delegate) {
      this.delegate = delegate;
    }

    static <E> FluentIterable<E> from(Iterable<E> iterable) {
      return new FluentIterable<>(iterable);
    }

    <T> FluentIterable<T> transform(Function<? super E, T> function) {
      List<T> out = new ArrayList<>();
      for (E e : delegate) {
        out.add(function.apply(e));
      }
      return new FluentIterable<>(out);
    }

    ImmutableSet<E> toSet() {
      return ImmutableSet.copyOf(delegate);
    }

    @Override
    public java.util.Iterator<E> iterator() {
      return delegate.iterator();
    }
  }

  
  
  
  
  static class Cell {
    Object value;

    void setCellValue(String s) {
      value = s;
    }

    void setCellValue(double d) {
      value = d;
    }
  }

  static class Row {
    final int rowNum;
    final List<Cell> cells = new ArrayList<>();

    Row(int rowNum) {
      this.rowNum = rowNum;
    }

    Cell createCell(int col) {
      while (cells.size() <= col) {
        cells.add(null);
      }
      Cell c = new Cell();
      cells.set(col, c);
      return c;
    }
  }

  static class Sheet {
    final String name;
    final List<Row> rows = new ArrayList<>();

    Sheet(String name) {
      this.name = name;
    }

    Row createRow(int rowNum) {
      Row r = new Row(rowNum);
      rows.add(r);
      return r;
    }
  }

  static class XSSFWorkbook {
    final List<Sheet> sheets = new ArrayList<>();

    Sheet createSheet(String sheetName) {
      Sheet s = new Sheet(sheetName);
      sheets.add(s);
      return s;
    }

    
    
    
    
    void write(java.io.OutputStream os) throws IOException {
      StringBuilder sb = new StringBuilder();
      sb.append("XSSFWorkbook[").append(sheets.size()).append(" sheet(s)]\n");
      for (Sheet s : sheets) {
        sb.append("  Sheet '").append(s.name).append("' (").append(s.rows.size()).append(" rows)\n");
        for (Row r : s.rows) {
          sb.append("    row ").append(r.rowNum).append(": ");
          for (Cell c : r.cells) {
            sb.append(c == null ? "" : c.value).append(" | ");
          }
          sb.append('\n');
        }
      }
      os.write(sb.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
  }

  
  
  
  
  
  interface RowFactory<T> {
    List<String> header();

    List<Object> toRowValues(T domainObject);
  }

  static class WorksheetSpec<T> {
    private final RowFactory<T> factory;
    private final String sheetName;

    WorksheetSpec(RowFactory<T> factory, String sheetName) {
      this.factory = factory;
      this.sheetName = sheetName;
    }

    RowFactory<T> getFactory() {
      return factory;
    }

    String getSheetName() {
      return sheetName;
    }
  }

  static class WorksheetContent {
    private final List<?> domainObjects;
    private final WorksheetSpec spec;

    WorksheetContent(List<?> domainObjects, WorksheetSpec spec) {
      this.domainObjects = domainObjects;
      this.spec = spec;
    }

    List<?> getDomainObjects() {
      return domainObjects;
    }

    WorksheetSpec getSpec() {
      return spec;
    }
  }

  
  
  
  
  static final String XLSX_SUFFIX = ".xlsx";

  
  
  
  
  @SuppressWarnings("unchecked")
  private void appendSheet(XSSFWorkbook workbook, List<?> domainObjects, RowFactory factory, String sheetName) {
    Sheet sheet = workbook.createSheet(sheetName);
    List<String> header = factory.header();
    Row headerRow = sheet.createRow(0);
    for (int col = 0; col < header.size(); col++) {
      headerRow.createCell(col).setCellValue(header.get(col));
    }
    int rowIdx = 1;
    for (Object domainObject : domainObjects) {
      List<Object> values = factory.toRowValues(domainObject);
      Row row = sheet.createRow(rowIdx++);
      for (int col = 0; col < values.size(); col++) {
        Object v = values.get(col);
        if (v instanceof Number) {
          row.createCell(col).setCellValue(((Number) v).doubleValue());
        } else {
          row.createCell(col).setCellValue(String.valueOf(v));
        }
      }
    }
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  File appendSheet(final List<WorksheetContent> worksheetContents) throws IOException {
        final ImmutableSet<String> worksheetNames = FluentIterable.from(worksheetContents)
                .transform(new Function<WorksheetContent, String>() {
                    @Nullable @Override public String apply(@Nullable final WorksheetContent worksheetContent) {
                        return worksheetContent.getSpec().getSheetName();
                    }
                }).toSet();
        if(worksheetNames.size() < worksheetContents.size()) {
            throw new IllegalArgumentException("Sheet names must have distinct names");
        }
        for (final String worksheetName : worksheetNames) {
            if(worksheetName.length() > 30) {
                throw new IllegalArgumentException(
                        String.format("Sheet name cannot exceed 30 characters (invalid name: '%s')",
                                worksheetName));
            }
        }

        final XSSFWorkbook workbook = new XSSFWorkbook();
        final File tempFile =
                File.createTempFile(ExcelConverter.class.getName(), UUID.randomUUID().toString() + XLSX_SUFFIX);
        final FileOutputStream fos = new FileOutputStream(tempFile);

        for (WorksheetContent worksheetContent : worksheetContents) {
            final WorksheetSpec spec = worksheetContent.getSpec();
            appendSheet(workbook, worksheetContent.getDomainObjects(), spec.getFactory(), spec.getSheetName());
        }
        workbook.write(fos);
        fos.close();
        return tempFile;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  

  static class ExcelConverter {
    
  }

  
  
  
  public static void main(String[] args) throws Exception {
    System.out.println("=== Reconstruction demo: ExcelConverter.appendSheet(List<WorksheetContent>) ===");

    method_2_isisexcel_claude converter = new method_2_isisexcel_claude();

    RowFactory<String> personFactory = new RowFactory<String>() {
      @Override
      public List<String> header() {
        return java.util.Arrays.asList("Name", "Length");
      }

      @Override
      public List<Object> toRowValues(String domainObject) {
        return java.util.Arrays.asList(domainObject, domainObject.length());
      }
    };

    WorksheetSpec<String> peopleSpec = new WorksheetSpec<>(personFactory, "People");
    WorksheetContent peopleContent = new WorksheetContent(java.util.Arrays.asList("Alice", "Bob", "Carol"), peopleSpec);

    WorksheetSpec<String> citiesSpec = new WorksheetSpec<>(personFactory, "Cities");
    WorksheetContent citiesContent = new WorksheetContent(java.util.Arrays.asList("Paris", "Berlin"), citiesSpec);

    List<WorksheetContent> contents = new ArrayList<>();
    contents.add(peopleContent);
    contents.add(citiesContent);

    File result = converter.appendSheet(contents);
    System.out.println("\n-- Scenario A (two distinct sheets: People, Cities) --");
    System.out.println("  temp file: " + result.getAbsolutePath());
    System.out.println("  file contents:\n" + java.nio.file.Files.readString(result.toPath()));
    result.deleteOnExit();

    
    WorksheetContent duplicate = new WorksheetContent(java.util.Arrays.asList("Dave"),
        new WorksheetSpec<>(personFactory, "People"));
    List<WorksheetContent> dupContents = new ArrayList<>();
    dupContents.add(peopleContent);
    dupContents.add(duplicate);
    System.out.println("\n-- Scenario B (duplicate sheet names) --");
    try {
      converter.appendSheet(dupContents);
      System.out.println("  (unexpectedly did not throw)");
    } catch (IllegalArgumentException e) {
      System.out.println("  caught expected IllegalArgumentException: " + e.getMessage());
    }

    
    WorksheetContent longName = new WorksheetContent(java.util.Arrays.asList("Eve"),
        new WorksheetSpec<>(personFactory, "ThisSheetNameIsWayTooLongForExcel"));
    List<WorksheetContent> longNameContents = new ArrayList<>();
    longNameContents.add(longName);
    System.out.println("\n-- Scenario C (sheet name > 30 characters) --");
    try {
      converter.appendSheet(longNameContents);
      System.out.println("  (unexpectedly did not throw)");
    } catch (IllegalArgumentException e) {
      System.out.println("  caught expected IllegalArgumentException: " + e.getMessage());
    }

    System.out.println("\n=== Demo complete: method exercised the happy-path multi-sheet write, "
        + "the duplicate-sheet-name validation, and the sheet-name-length validation branches. ===");
  }
}
