





































import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class method_3_isisexcel_claude {

  
  
  
  static class Cell {
    Object value;

    Object getValue() {
      return value;
    }

    void setCellValue(String s) {
      value = s;
    }

    void setCellValue(double d) {
      value = d;
    }

    String getStringValue() {
      return value == null ? null : String.valueOf(value);
    }

    double getNumericValue() {
      return value instanceof Number ? ((Number) value).doubleValue() : 0;
    }
  }

  static class Row {
    final int rowNum;
    final Map<Integer, Cell> cells = new LinkedHashMap<>();

    Row(int rowNum) {
      this.rowNum = rowNum;
    }

    Cell getCell(int col) {
      return cells.get(col);
    }

    Cell createCell(int col) {
      Cell c = new Cell();
      cells.put(col, c);
      return c;
    }

    int lastCellIndex() {
      int max = -1;
      for (int c : cells.keySet()) {
        max = Math.max(max, c);
      }
      return max;
    }
  }

  static class Sheet {
    final String name;
    final Map<Integer, Row> rows = new LinkedHashMap<>();

    Sheet(String name) {
      this.name = name;
    }

    Row getRow(int rowNum) {
      return rows.get(rowNum);
    }

    Row createRow(int rowNum) {
      Row r = new Row(rowNum);
      rows.put(rowNum, r);
      return r;
    }

    int lastRowIndex() {
      int max = -1;
      for (int r : rows.keySet()) {
        max = Math.max(max, r);
      }
      return max;
    }
  }

  
  
  
  
  
  
  
  enum PivotRole {
    KEY, PIVOT, VALUE
  }

  static class AnnotationTriplet {
    final int sourceColumn;
    final PivotRole role;
    final String label;

    AnnotationTriplet(int sourceColumn, PivotRole role, String label) {
      this.sourceColumn = sourceColumn;
      this.role = role;
      this.label = label;
    }
  }

  static class AnnotationList {
    final List<AnnotationTriplet> triplets;

    AnnotationList(List<AnnotationTriplet> triplets) {
      this.triplets = triplets;
    }

    void add(AnnotationTriplet t) {
      triplets.add(t);
    }

    List<AnnotationTriplet> forRole(PivotRole role) {
      List<AnnotationTriplet> result = new ArrayList<>();
      for (AnnotationTriplet t : triplets) {
        if (t.role == role) {
          result.add(t);
        }
      }
      return result;
    }
  }

  
  
  
  
  Sheet sourceSheet;
  Sheet targetSheet;
  AnnotationList annotations;

  private int headerRowOffset;
  private int dataRowOffset;
  private List<Object> pivotColumnValues;
  private final Map<String, Integer> targetColumnIndexForPivotValue = new LinkedHashMap<>();

  
  
  
  
  void getAnnotationsFromSource() {
    Row roleRow = sourceSheet.getRow(0);
    Row labelRow = sourceSheet.getRow(1);
    int lastCol = roleRow.lastCellIndex();
    for (int col = 0; col <= lastCol; col++) {
      Cell roleCell = roleRow.getCell(col);
      if (roleCell == null) {
        continue;
      }
      String roleStr = roleCell.getStringValue();
      if (roleStr == null) {
        continue;
      }
      PivotRole role = PivotRole.valueOf(roleStr);
      Cell labelCell = labelRow.getCell(col);
      String label = labelCell == null ? ("col" + col) : labelCell.getStringValue();
      annotations.add(new AnnotationTriplet(col, role, label));
    }
  }

  
  
  
  void setOffsets() {
    headerRowOffset = 2;
    dataRowOffset = headerRowOffset;

    List<AnnotationTriplet> pivotCols = annotations.forRole(PivotRole.PIVOT);
    LinkedHashMap<Object, Boolean> distinctValues = new LinkedHashMap<>();
    if (!pivotCols.isEmpty()) {
      int pivotCol = pivotCols.get(0).sourceColumn;
      int lastRow = sourceSheet.lastRowIndex();
      for (int r = dataRowOffset; r <= lastRow; r++) {
        Row row = sourceSheet.getRow(r);
        if (row == null) {
          continue;
        }
        Cell c = row.getCell(pivotCol);
        if (c != null && c.getValue() != null) {
          distinctValues.put(c.getValue(), Boolean.TRUE);
        }
      }
    }
    pivotColumnValues = new ArrayList<>(distinctValues.keySet());
  }

  
  
  
  
  void validateAndAdaptSourceDataIfNeeded() {
    if (annotations.forRole(PivotRole.VALUE).isEmpty()) {
      throw new IllegalStateException("SheetPivoter: no VALUE column annotated in source sheet");
    }
  }

  
  
  
  void defineSomeCellStyles() {
  }

  
  
  void createEmptyHeaderRowsAndCells() {
    targetSheet.createRow(0);
    List<AnnotationTriplet> keyCols = annotations.forRole(PivotRole.KEY);
    int col = 0;
    for (AnnotationTriplet ignored : keyCols) {
      col++;
    }
    for (Object pivotValue : pivotColumnValues) {
      targetColumnIndexForPivotValue.put(String.valueOf(pivotValue), col);
      col++;
    }
  }

  
  
  void fillInHeaderRows() {
    Row headerRow = targetSheet.getRow(0);
    List<AnnotationTriplet> keyCols = annotations.forRole(PivotRole.KEY);
    int col = 0;
    for (AnnotationTriplet keyCol : keyCols) {
      headerRow.createCell(col).setCellValue(keyCol.label);
      col++;
    }
    for (Object pivotValue : pivotColumnValues) {
      headerRow.createCell(targetColumnIndexForPivotValue.get(String.valueOf(pivotValue)))
          .setCellValue(String.valueOf(pivotValue));
    }
  }

  
  
  void pivotSourceRows() {
    List<AnnotationTriplet> keyCols = annotations.forRole(PivotRole.KEY);
    List<AnnotationTriplet> pivotCols = annotations.forRole(PivotRole.PIVOT);
    List<AnnotationTriplet> valueCols = annotations.forRole(PivotRole.VALUE);
    if (pivotCols.isEmpty() || valueCols.isEmpty()) {
      return;
    }
    int pivotCol = pivotCols.get(0).sourceColumn;
    int valueCol = valueCols.get(0).sourceColumn;

    Map<String, Integer> targetRowForKey = new LinkedHashMap<>();
    int lastRow = sourceSheet.lastRowIndex();
    int nextTargetRow = 1;
    for (int r = dataRowOffset; r <= lastRow; r++) {
      Row sourceRow = sourceSheet.getRow(r);
      if (sourceRow == null) {
        continue;
      }
      StringBuilder keyBuilder = new StringBuilder();
      for (AnnotationTriplet keyCol : keyCols) {
        Cell c = sourceRow.getCell(keyCol.sourceColumn);
        keyBuilder.append(c == null ? "" : c.getValue()).append('|');
      }
      String key = keyBuilder.toString();

      Integer targetRowIdx = targetRowForKey.get(key);
      Row targetRow;
      if (targetRowIdx == null) {
        targetRowIdx = nextTargetRow++;
        targetRowForKey.put(key, targetRowIdx);
        targetRow = targetSheet.createRow(targetRowIdx);
        int col = 0;
        for (AnnotationTriplet keyCol : keyCols) {
          Cell c = sourceRow.getCell(keyCol.sourceColumn);
          targetRow.createCell(col).setCellValue(c == null ? "" : String.valueOf(c.getValue()));
          col++;
        }
      } else {
        targetRow = targetSheet.getRow(targetRowIdx);
      }

      Cell pivotCell = sourceRow.getCell(pivotCol);
      Cell valueCell = sourceRow.getCell(valueCol);
      if (pivotCell != null && valueCell != null) {
        Integer targetCol = targetColumnIndexForPivotValue.get(String.valueOf(pivotCell.getValue()));
        if (targetCol != null) {
          Cell existing = targetRow.getCell(targetCol);
          double newValue = valueCell.getNumericValue() + (existing == null ? 0 : existing.getNumericValue());
          targetRow.createCell(targetCol).setCellValue(newValue);
        }
      }
    }
  }

  
  void addSummations() {
    int lastRow = targetSheet.lastRowIndex();
    if (lastRow < 1) {
      return;
    }
    Row totalsRow = targetSheet.createRow(lastRow + 1);
    totalsRow.createCell(0).setCellValue("TOTAL");
    for (Object pivotValue : pivotColumnValues) {
      int col = targetColumnIndexForPivotValue.get(String.valueOf(pivotValue));
      double sum = 0;
      for (int r = 1; r <= lastRow; r++) {
        Row row = targetSheet.getRow(r);
        if (row == null) {
          continue;
        }
        Cell c = row.getCell(col);
        if (c != null) {
          sum += c.getNumericValue();
        }
      }
      totalsRow.createCell(col).setCellValue(sum);
    }
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public void pivot(final Sheet pivotSourceSheet, final Sheet pivotTargetSheet) {

        sourceSheet = pivotSourceSheet;
        targetSheet = pivotTargetSheet;
        annotations = new AnnotationList(new ArrayList<AnnotationTriplet>());

        getAnnotationsFromSource();
        setOffsets();
        validateAndAdaptSourceDataIfNeeded();
        defineSomeCellStyles();
        createEmptyHeaderRowsAndCells();
        fillInHeaderRows();
        pivotSourceRows();
        addSummations();
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: SheetPivoter.pivot ===");

    
    Sheet source = new Sheet("SalesRaw");
    Row roleRow = source.createRow(0);
    roleRow.createCell(0).setCellValue("KEY");
    roleRow.createCell(1).setCellValue("PIVOT");
    roleRow.createCell(2).setCellValue("VALUE");

    Row labelRow = source.createRow(1);
    labelRow.createCell(0).setCellValue("Region");
    labelRow.createCell(1).setCellValue("Quarter");
    labelRow.createCell(2).setCellValue("Sales");

    Object[][] data = {
        { "North", "Q1", 100.0 },
        { "North", "Q2", 150.0 },
        { "South", "Q1", 80.0 },
        { "South", "Q2", 90.0 },
        { "North", "Q1", 20.0 }, 
    };
    int rowIdx = 2;
    for (Object[] rowData : data) {
      Row r = source.createRow(rowIdx++);
      r.createCell(0).setCellValue((String) rowData[0]);
      r.createCell(1).setCellValue((String) rowData[1]);
      r.createCell(2).setCellValue((Double) rowData[2]);
    }

    Sheet target = new Sheet("SalesPivot");

    method_3_isisexcel_claude pivoter = new method_3_isisexcel_claude();
    pivoter.pivot(source, target);

    System.out.println("\n-- Pivoted target sheet ('" + target.name + "') --");
    int lastRow = target.lastRowIndex();
    for (int r = 0; r <= lastRow; r++) {
      Row row = target.getRow(r);
      if (row == null) {
        continue;
      }
      StringBuilder sb = new StringBuilder("  row " + r + ": ");
      int lastCol = row.lastCellIndex();
      for (int c = 0; c <= lastCol; c++) {
        Cell cell = row.getCell(c);
        sb.append(cell == null ? "" : cell.getValue()).append(" | ");
      }
      System.out.println(sb);
    }

    System.out.println("\n=== Demo complete: method exercised annotation reading from the source "
        + "header, offset computation, header creation for the two distinct pivot values (Q1/Q2), "
        + "row grouping/summation by KEY (North/Q1 appears twice and was summed to 120), and the "
        + "final TOTAL row across all pivoted columns. ===");
  }
}
