
































import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.List;

public class method_4_isisexcel_claude {

  
  
  
  interface Predicate<T> {
    boolean apply(T input);
  }

  static class Predicates {
    @SafeVarargs
    static <T> Predicate<T> and(final Predicate<? super T>... predicates) {
      return input -> {
        for (Predicate<? super T> p : predicates) {
          if (!p.apply(input)) {
            return false;
          }
        }
        return true;
      };
    }
  }

  
  
  
  
  @Retention(RetentionPolicy.RUNTIME)
  @Target(ElementType.METHOD)
  @interface Collection {
  }

  interface DomainObjectContainer {
    @SuppressWarnings("unchecked")
    <T> List<T> allMatches(Class<T> cls, Predicate<T> predicate);
  }

  static class SimpleDomainObjectContainer implements DomainObjectContainer {
    final List<ExcelModuleDemoToDoItem> allItems;

    SimpleDomainObjectContainer(List<ExcelModuleDemoToDoItem> allItems) {
      this.allItems = allItems;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> List<T> allMatches(Class<T> cls, Predicate<T> predicate) {
      List<T> result = new ArrayList<>();
      if (cls == ExcelModuleDemoToDoItem.class) {
        for (ExcelModuleDemoToDoItem item : allItems) {
          if (predicate.apply((T) item)) {
            result.add((T) item);
          }
        }
      }
      return result;
    }
  }

  
  
  
  
  
  static class ExcelModuleDemoToDoItem {
    String description;
    String ownedBy;
    boolean complete;
    String category;
    String subcategory;

    ExcelModuleDemoToDoItem(String description, String ownedBy, boolean complete, String category,
        String subcategory) {
      this.description = description;
      this.ownedBy = ownedBy;
      this.complete = complete;
      this.category = category;
      this.subcategory = subcategory;
    }

    @Override
    public String toString() {
      return "ExcelModuleDemoToDoItem{description=" + description + ", ownedBy=" + ownedBy + ", complete="
          + complete + ", category=" + category + ", subcategory=" + subcategory + "}";
    }

    static class Predicates {
      static Predicate<ExcelModuleDemoToDoItem> thoseOwnedBy(final String ownedBy) {
        return item -> item.ownedBy != null && item.ownedBy.equals(ownedBy);
      }

      static Predicate<ExcelModuleDemoToDoItem> thoseCompleted(final boolean complete) {
        return item -> item.complete == complete;
      }

      
      
      static Predicate<ExcelModuleDemoToDoItem> thoseCategorised(final String category, final String subcategory) {
        return item -> (category == null || category.isEmpty() || category.equals(item.category))
            && (subcategory == null || subcategory.isEmpty() || subcategory.equals(item.subcategory));
      }
    }
  }

  
  
  
  
  
  DomainObjectContainer container;

  private String category;
  private String subcategory;
  private boolean complete;
  private String currentUser = "alice";

  String getCategory() {
    return category;
  }

  String getSubcategory() {
    return subcategory;
  }

  boolean isComplete() {
    return complete;
  }

  
  
  String currentUserName() {
    return currentUser;
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  @SuppressWarnings("unchecked")
    @Collection
    public List<ExcelModuleDemoToDoItem> getToDoItems() {
        return container.allMatches(ExcelModuleDemoToDoItem.class,
                Predicates.and(
                    ExcelModuleDemoToDoItem.Predicates.thoseOwnedBy(currentUserName()),
                    ExcelModuleDemoToDoItem.Predicates.thoseCompleted(isComplete()),
                    ExcelModuleDemoToDoItem.Predicates.thoseCategorised(getCategory(), getSubcategory())));
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: ExcelModuleDemoToDoItemBulkUpdateManager.getToDoItems ===");

    List<ExcelModuleDemoToDoItem> allItems = new ArrayList<>();
    allItems.add(new ExcelModuleDemoToDoItem("Buy milk", "alice", false, "Household", "Shopping"));
    allItems.add(new ExcelModuleDemoToDoItem("Buy bread", "alice", true, "Household", "Shopping"));
    allItems.add(new ExcelModuleDemoToDoItem("Fix bike", "alice", false, "Household", "Repairs"));
    allItems.add(new ExcelModuleDemoToDoItem("Write report", "bob", false, "Work", "Reports"));

    
    method_4_isisexcel_claude managerA = new method_4_isisexcel_claude();
    managerA.container = new SimpleDomainObjectContainer(allItems);
    managerA.currentUser = "alice";
    managerA.complete = false;
    managerA.category = "Household";
    managerA.subcategory = "Shopping";

    List<ExcelModuleDemoToDoItem> resultA = managerA.getToDoItems();
    System.out.println("\n-- Scenario A (alice, incomplete, Household/Shopping) --");
    for (ExcelModuleDemoToDoItem item : resultA) {
      System.out.println("  " + item);
    }

    
    method_4_isisexcel_claude managerB = new method_4_isisexcel_claude();
    managerB.container = new SimpleDomainObjectContainer(allItems);
    managerB.currentUser = "alice";
    managerB.complete = false;
    managerB.category = "";
    managerB.subcategory = "";

    List<ExcelModuleDemoToDoItem> resultB = managerB.getToDoItems();
    System.out.println("\n-- Scenario B (alice, incomplete, no category filter) --");
    for (ExcelModuleDemoToDoItem item : resultB) {
      System.out.println("  " + item);
    }

    
    method_4_isisexcel_claude managerC = new method_4_isisexcel_claude();
    managerC.container = new SimpleDomainObjectContainer(allItems);
    managerC.currentUser = "bob";
    managerC.complete = false;
    managerC.category = "";
    managerC.subcategory = "";

    List<ExcelModuleDemoToDoItem> resultC = managerC.getToDoItems();
    System.out.println("\n-- Scenario C (bob, incomplete) --");
    for (ExcelModuleDemoToDoItem item : resultC) {
      System.out.println("  " + item);
    }

    System.out.println("\n=== Demo complete: method exercised the combined ownedBy+completed+ "
        + "categorised AND-predicate filter, both narrow and blank-category-filter cases, and "
        + "per-user filtering via currentUserName(). ===");
  }
}
