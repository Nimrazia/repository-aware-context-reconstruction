

































import java.util.HashMap;
import java.util.Map;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class method_3_util_claude {

  
  
  
  static class Log {
    void warn(String msg) {
      System.out.println("[WARN] " + msg);
    }
  }

  static final Log LOG = new Log();

  
  
  
  
  static class Validate {
    static void notBlank(CharSequence s, String message) {
      if (s == null || s.toString().trim().isEmpty()) {
        throw new IllegalArgumentException(message);
      }
    }
  }

  
  
  
  static class FactoryException extends Exception {
    FactoryException(String message) {
      super(message);
    }

    FactoryException(String message, Throwable cause) {
      super(message, cause);
    }
  }

  
  
  
  
  
  
  
  
  static class SimpleDataSource implements DataSource {
    final String name;

    SimpleDataSource(String name) {
      this.name = name;
    }

    @Override
    public java.sql.Connection getConnection() {
      return null;
    }

    @Override
    public java.sql.Connection getConnection(String username, String password) {
      return null;
    }

    @Override
    public java.io.PrintWriter getLogWriter() {
      return null;
    }

    @Override
    public void setLogWriter(java.io.PrintWriter out) {
    }

    @Override
    public void setLoginTimeout(int seconds) {
    }

    @Override
    public int getLoginTimeout() {
      return 0;
    }

    @Override
    public java.util.logging.Logger getParentLogger() {
      return null;
    }

    @Override
    public <T> T unwrap(Class<T> iface) {
      return null;
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) {
      return false;
    }

    @Override
    public String toString() {
      return "SimpleDataSource{" + name + "}";
    }
  }

  
  
  

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  public static DataSource getDataSource(final String jndiName)
            throws FactoryException {

        Validate.notBlank(jndiName, "The validated character sequence 'jndiName' is null or empty");

        

        try {
            
            final Context context = new InitialContext();

            
            final Object namedObject = context.lookup(jndiName);
            if (DataSource.class.isInstance(namedObject)) {
                final DataSource dataSource = (DataSource) context.lookup(jndiName);
                context.close();

                return dataSource;
            } else {
                final String error = "The JNDI name '" + jndiName + "' does not reference a SQL DataSource."
                        + " This is a configuration issue.";
                LOG.warn(error);
                throw new FactoryException(error);
            }
        } catch (NamingException e) {
            final String error = "Error retrieving JDBC date source from JNDI: " + jndiName;
            LOG.warn(error);
            throw new FactoryException(error, e);
        }
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: DataSourceFactory.getDataSource ===");

    
    System.out.println("\n-- Scenario A (blank jndiName) --");
    try {
      getDataSource("   ");
      System.out.println("  (unexpectedly did not throw)");
    } catch (IllegalArgumentException e) {
      System.out.println("  caught expected IllegalArgumentException: " + e.getMessage());
    } catch (FactoryException e) {
      System.out.println("  caught unexpected FactoryException: " + e.getMessage());
    }

    
    
    System.out.println("\n-- Scenario B (no JNDI provider available, real NamingException) --");
    try {
      getDataSource("java:comp/env/jdbc/DemoDS");
      System.out.println("  (unexpectedly did not throw -- a JNDI provider is configured in this "
          + "environment)");
    } catch (FactoryException e) {
      System.out.println("  caught expected FactoryException: " + e.getMessage());
      System.out.println("  cause: " + (e.getCause() == null ? "none" : e.getCause().getClass().getName()));
    } catch (IllegalArgumentException e) {
      System.out.println("  caught unexpected IllegalArgumentException: " + e.getMessage());
    }

    System.out.println("\n=== Demo complete: method exercised the blank-jndiName validation "
        + "branch and the real NamingException -> FactoryException wrapping branch (this "
        + "sandbox genuinely has no JNDI provider configured, so `new InitialContext()` itself "
        + "fails exactly as it would in any environment lacking JNDI configuration -- this is "
        + "not a fabricated outcome). The non-DataSource-object and successful-lookup branches "
        + "require a real, configured JNDI provider to exercise and are documented here rather "
        + "than faked. ===");
  }
}
