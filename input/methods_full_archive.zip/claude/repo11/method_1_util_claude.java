




































import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class method_1_util_claude {

  
  
  
  static class Log {
    void debug(String msg) {
      System.out.println("[DEBUG] " + msg);
    }
  }

  static final Log LOG = new Log();

  
  
  
  
  static class ConnectionProperties {
    int maxTotal = 8;
    int maxIdle = 8;
    int minIdle = 0;
    long maxWaitMillis = -1L;
    boolean testOnCreate = false;
    boolean testOnBorrow = false;
    boolean testOnReturn = false;
    boolean testWhileIdle = false;
    long timeBetweenEvictionRunsMillis = -1L;
    int numTestsPerEvictionRun = 3;
    long minEvictableIdleTimeMillis = 1_800_000L;
    long softMinEvictableIdleTimeMillis = -1L;
    boolean lifo = true;
    boolean defaultAutoCommit = true;
    boolean defaultReadOnly = false;
    int defaultTransactionIsolation = -1;
    boolean cacheState = true;
    String validationQuery;
    long maxConnLifetimeMillis = -1L;

    int getMaxTotal() {
      return maxTotal;
    }

    int getMaxIdle() {
      return maxIdle;
    }

    int getMinIdle() {
      return minIdle;
    }

    long getMaxWaitMillis() {
      return maxWaitMillis;
    }

    boolean isTestOnCreate() {
      return testOnCreate;
    }

    boolean isTestOnBorrow() {
      return testOnBorrow;
    }

    boolean isTestOnReturn() {
      return testOnReturn;
    }

    boolean isTestWhileIdle() {
      return testWhileIdle;
    }

    long getTimeBetweenEvictionRunsMillis() {
      return timeBetweenEvictionRunsMillis;
    }

    int getNumTestsPerEvictionRun() {
      return numTestsPerEvictionRun;
    }

    long getMinEvictableIdleTimeMillis() {
      return minEvictableIdleTimeMillis;
    }

    long getSoftMinEvictableIdleTimeMillis() {
      return softMinEvictableIdleTimeMillis;
    }

    boolean isLifo() {
      return lifo;
    }

    boolean isDefaultAutoCommit() {
      return defaultAutoCommit;
    }

    boolean isDefaultReadOnly() {
      return defaultReadOnly;
    }

    int getDefaultTransactionIsolation() {
      return defaultTransactionIsolation;
    }

    boolean isCacheState() {
      return cacheState;
    }

    String getValidationQuery() {
      return validationQuery;
    }

    long getMaxConnLifetimeMillis() {
      return maxConnLifetimeMillis;
    }
  }

  
  
  
  
  static class GenericObjectPoolConfig {
    int maxTotal;
    int maxIdle;
    int minIdle;
    long maxWaitMillis;
    boolean testOnCreate;
    boolean testOnBorrow;
    boolean testOnReturn;
    boolean testWhileIdle;
    long timeBetweenEvictionRunsMillis;
    int numTestsPerEvictionRun;
    long minEvictableIdleTimeMillis;
    long softMinEvictableIdleTimeMillis;
    boolean lifo;

    void setMaxTotal(int v) {
      maxTotal = v;
    }

    void setMaxIdle(int v) {
      maxIdle = v;
    }

    void setMinIdle(int v) {
      minIdle = v;
    }

    void setMaxWaitMillis(long v) {
      maxWaitMillis = v;
    }

    void setTestOnCreate(boolean v) {
      testOnCreate = v;
    }

    void setTestOnBorrow(boolean v) {
      testOnBorrow = v;
    }

    void setTestOnReturn(boolean v) {
      testOnReturn = v;
    }

    void setTestWhileIdle(boolean v) {
      testWhileIdle = v;
    }

    void setTimeBetweenEvictionRunsMillis(long v) {
      timeBetweenEvictionRunsMillis = v;
    }

    void setNumTestsPerEvictionRun(int v) {
      numTestsPerEvictionRun = v;
    }

    void setMinEvictableIdleTimeMillis(long v) {
      minEvictableIdleTimeMillis = v;
    }

    void setSoftMinEvictableIdleTimeMillis(long v) {
      softMinEvictableIdleTimeMillis = v;
    }

    void setLifo(boolean v) {
      lifo = v;
    }
  }

  
  
  
  
  
  
  
  
  static class PoolableConnection {
  }

  interface ConnectionFactory {
    java.sql.Connection createConnection() throws java.sql.SQLException;
  }

  static class DriverManagerConnectionFactory implements ConnectionFactory {
    final String url;
    final Properties props;

    DriverManagerConnectionFactory(String url, Properties props) {
      this.url = url;
      this.props = props;
    }

    
    
    
    
    @Override
    public java.sql.Connection createConnection() throws java.sql.SQLException {
      return java.sql.DriverManager.getConnection(url, props);
    }
  }

  static class PoolableConnectionFactory {
    final ConnectionFactory connFactory;
    boolean defaultAutoCommit;
    boolean defaultReadOnly;
    int defaultTransactionIsolation;
    boolean cacheState;
    String validationQuery;
    long maxConnLifetimeMillis;
    GenericObjectPool<PoolableConnection> pool;

    PoolableConnectionFactory(ConnectionFactory connFactory, Object dataSourceUnused) {
      this.connFactory = connFactory;
    }

    void setDefaultAutoCommit(boolean v) {
      defaultAutoCommit = v;
    }

    void setDefaultReadOnly(boolean v) {
      defaultReadOnly = v;
    }

    void setDefaultTransactionIsolation(int v) {
      defaultTransactionIsolation = v;
    }

    void setCacheState(boolean v) {
      cacheState = v;
    }

    void setValidationQuery(String v) {
      validationQuery = v;
    }

    void setMaxConnLifetimeMillis(long v) {
      maxConnLifetimeMillis = v;
    }

    void setPool(GenericObjectPool<PoolableConnection> pool) {
      this.pool = pool;
    }
  }

  static class GenericObjectPool<T> {
    final PoolableConnectionFactory factory;
    final GenericObjectPoolConfig config;

    GenericObjectPool(PoolableConnectionFactory factory, GenericObjectPoolConfig config) {
      this.factory = factory;
      this.config = config;
    }
  }

  static class PoolingDataSource<T> {
    final GenericObjectPool<T> pool;

    PoolingDataSource(GenericObjectPool<T> pool) {
      this.pool = pool;
    }
  }

  
  
  

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  private static PoolingDataSource<PoolableConnection> getPoolingDataSource(final String url,
                                                                              final ConcurrentMap<String, String> properties,
                                                                              final ConnectionProperties poolSpec) {

        
        assert url != null : "The url cannot be null";
        assert properties != null : "The properties cannot be null";
        assert poolSpec != null : "The pol spec cannot be null";

        LOG.debug("Creating new pooled data source for '" + url + "'");

        
        final Properties props = new Properties();
        props.putAll(properties);

        
        final GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
        poolConfig.setMaxTotal(poolSpec.getMaxTotal());
        poolConfig.setMaxIdle(poolSpec.getMaxIdle());
        poolConfig.setMinIdle(poolSpec.getMinIdle());
        poolConfig.setMaxWaitMillis(poolSpec.getMaxWaitMillis());
        poolConfig.setTestOnCreate(poolSpec.isTestOnCreate());
        poolConfig.setTestOnBorrow(poolSpec.isTestOnBorrow());
        poolConfig.setTestOnReturn(poolSpec.isTestOnReturn());
        poolConfig.setTestWhileIdle(poolSpec.isTestWhileIdle());
        poolConfig.setTimeBetweenEvictionRunsMillis(poolSpec.getTimeBetweenEvictionRunsMillis());
        poolConfig.setNumTestsPerEvictionRun(poolSpec.getNumTestsPerEvictionRun());
        poolConfig.setMinEvictableIdleTimeMillis(poolSpec.getMinEvictableIdleTimeMillis());
        poolConfig.setSoftMinEvictableIdleTimeMillis(poolSpec.getSoftMinEvictableIdleTimeMillis());
        poolConfig.setLifo(poolSpec.isLifo());


        
        final ConnectionFactory connFactory = new DriverManagerConnectionFactory(url, props);
        final PoolableConnectionFactory poolConnFactory = new PoolableConnectionFactory(connFactory, null);
        poolConnFactory.setDefaultAutoCommit(poolSpec.isDefaultAutoCommit());
        poolConnFactory.setDefaultReadOnly(poolSpec.isDefaultReadOnly());
        poolConnFactory.setDefaultTransactionIsolation(poolSpec.getDefaultTransactionIsolation());
        poolConnFactory.setCacheState(poolSpec.isCacheState());
        poolConnFactory.setValidationQuery(poolSpec.getValidationQuery());
        poolConnFactory.setMaxConnLifetimeMillis(poolSpec.getMaxConnLifetimeMillis());
        final GenericObjectPool<PoolableConnection> connPool = new GenericObjectPool<>(poolConnFactory, poolConfig);
        poolConnFactory.setPool(connPool);

        
        return new PoolingDataSource<>(connPool);
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: DataSourceFactory.getPoolingDataSource ===");

    ConcurrentMap<String, String> jdbcProps = new ConcurrentHashMap<>();
    jdbcProps.put("user", "demo");
    jdbcProps.put("password", "secret");

    ConnectionProperties poolSpec = new ConnectionProperties();
    poolSpec.maxTotal = 20;
    poolSpec.maxIdle = 10;
    poolSpec.minIdle = 2;
    poolSpec.maxWaitMillis = 5000;
    poolSpec.testOnBorrow = true;
    poolSpec.validationQuery = "SELECT 1";
    poolSpec.maxConnLifetimeMillis = 3_600_000L;

    PoolingDataSource<PoolableConnection> dataSource =
        getPoolingDataSource("jdbc:h2:mem:demo", jdbcProps, poolSpec);

    System.out.println("\n-- Resulting pool configuration --");
    GenericObjectPoolConfig cfg = dataSource.pool.config;
    System.out.println("  maxTotal: " + cfg.maxTotal);
    System.out.println("  maxIdle: " + cfg.maxIdle);
    System.out.println("  minIdle: " + cfg.minIdle);
    System.out.println("  maxWaitMillis: " + cfg.maxWaitMillis);
    System.out.println("  testOnBorrow: " + cfg.testOnBorrow);
    PoolableConnectionFactory pcf = dataSource.pool.factory;
    System.out.println("  validationQuery: " + pcf.validationQuery);
    System.out.println("  maxConnLifetimeMillis: " + pcf.maxConnLifetimeMillis);
    System.out.println("  factory's pool reference set correctly: " + (pcf.pool == dataSource.pool));
    DriverManagerConnectionFactory dmcf = (DriverManagerConnectionFactory) pcf.connFactory;
    System.out.println("  underlying JDBC url: " + dmcf.url);
    System.out.println("  underlying JDBC props: " + dmcf.props);

    System.out.println("\n=== Demo complete: method exercised the full pool-config field "
        + "mapping from ConnectionProperties to GenericObjectPoolConfig, the Properties "
        + "conversion from the ConcurrentMap, the PoolableConnectionFactory configuration, and "
        + "the circular pool<->factory wiring (poolConnFactory.setPool(connPool)). ===");
  }
}
