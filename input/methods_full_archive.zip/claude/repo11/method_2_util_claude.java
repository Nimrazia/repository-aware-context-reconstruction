
































import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class method_2_util_claude {

  
  
  
  static class Log {
    void debug(String msg) {
      System.out.println("[DEBUG] " + msg);
    }
  }

  static final Log LOG = new Log();

  
  
  
  
  static class Validate {
    static void notNull(Object o, String message) {
      if (o == null) {
        throw new NullPointerException(message);
      }
    }
  }

  static class StringUtils {
    static boolean isNotEmpty(String s) {
      return s != null && !s.isEmpty();
    }

    static boolean isNumeric(String s) {
      if (s == null || s.isEmpty()) {
        return false;
      }
      for (int i = 0; i < s.length(); i++) {
        if (!Character.isDigit(s.charAt(i))) {
          return false;
        }
      }
      return true;
    }
  }

  
  
  
  
  
  static class ConnectionProperties {
    String driver;
    String url;
    String username;
    String password;
    int maxTotal;
    int maxIdle;
    int minIdle;
    long maxWaitMillis;
    boolean testOnCreate;
    boolean testOnBorrow;
    boolean testOnReturn;
    boolean testWhileIdle;
    long timeBetweenEvictionRunsMillis;
    int numTestsPerEvictionRun;
    long minEvictableIdleTimeMillis;
    long softMinEvictableIdleTimeMillis;
    boolean lifo;
    boolean defaultAutoCommit;
    boolean defaultReadOnly;
    int defaultTransactionIsolation;
    boolean cacheState;
    String validationQuery;
    long maxConnLifetimeMillis;
    Map<String, String> additionalProperties;

    void setDriver(String v) {
      driver = v;
    }

    void setUrl(String v) {
      url = v;
    }

    void setUsername(String v) {
      username = v;
    }

    void setPassword(String v) {
      password = v;
    }

    void setMaxTotal(int v) {
      maxTotal = v;
    }

    void setMaxIdle(int v) {
      maxIdle = v;
    }

    void setMinIdle(int v) {
      minIdle = v;
    }

    void setMaxWaitMillis(long v) {
      maxWaitMillis = v;
    }

    void setTestOnCreate(boolean v) {
      testOnCreate = v;
    }

    void setTestOnBorrow(boolean v) {
      testOnBorrow = v;
    }

    void setTestOnReturn(boolean v) {
      testOnReturn = v;
    }

    void setTestWhileIdle(boolean v) {
      testWhileIdle = v;
    }

    void setTimeBetweenEvictionRunsMillis(long v) {
      timeBetweenEvictionRunsMillis = v;
    }

    void setNumTestsPerEvictionRun(int v) {
      numTestsPerEvictionRun = v;
    }

    void setMinEvictableIdleTimeMillis(long v) {
      minEvictableIdleTimeMillis = v;
    }

    void setSoftMinEvictableIdleTimeMillis(long v) {
      softMinEvictableIdleTimeMillis = v;
    }

    void setLifo(boolean v) {
      lifo = v;
    }

    void setDefaultAutoCommit(boolean v) {
      defaultAutoCommit = v;
    }

    void setDefaultReadOnly(boolean v) {
      defaultReadOnly = v;
    }

    void setDefaultTransactionIsolation(int v) {
      defaultTransactionIsolation = v;
    }

    void setCacheState(boolean v) {
      cacheState = v;
    }

    void setValidationQuery(String v) {
      validationQuery = v;
    }

    void setMaxConnLifetimeMillis(long v) {
      maxConnLifetimeMillis = v;
    }

    void setAdditionalProperties(Map<String, String> v) {
      additionalProperties = v;
    }

    @Override
    public String toString() {
      return "ConnectionProperties{driver=" + driver + ", url=" + url + ", username=" + username
          + ", password=" + (password == null ? null : "***") + ", maxTotal=" + maxTotal + ", maxIdle=" + maxIdle
          + ", minIdle=" + minIdle + ", maxWaitMillis=" + maxWaitMillis + ", testOnCreate=" + testOnCreate
          + ", testOnBorrow=" + testOnBorrow + ", testOnReturn=" + testOnReturn + ", testWhileIdle=" + testWhileIdle
          + ", timeBetweenEvictionRunsMillis=" + timeBetweenEvictionRunsMillis + ", numTestsPerEvictionRun="
          + numTestsPerEvictionRun + ", minEvictableIdleTimeMillis=" + minEvictableIdleTimeMillis
          + ", softMinEvictableIdleTimeMillis=" + softMinEvictableIdleTimeMillis + ", lifo=" + lifo
          + ", defaultAutoCommit=" + defaultAutoCommit + ", defaultReadOnly=" + defaultReadOnly
          + ", defaultTransactionIsolation=" + defaultTransactionIsolation + ", cacheState=" + cacheState
          + ", validationQuery=" + validationQuery + ", maxConnLifetimeMillis=" + maxConnLifetimeMillis
          + ", additionalProperties=" + additionalProperties + "}";
    }
  }

  
  static final String KEY_DRIVER = "driver";
  static final String KEY_URL = "url";
  static final String KEY_USERNAME = "username";
  static final String KEY_PASSWORD = "password";
  static final String KEY_MAX_TOTAL = "maxTotal";
  static final String KEY_MAX_IDLE = "maxIdle";
  static final String KEY_MIN_IDLE = "minIdle";
  static final String KEY_MAX_WAIT_MILLIS = "maxWaitMillis";
  static final String KEY_TEST_ON_CREATE = "testOnCreate";
  static final String KEY_TEST_ON_BORROW = "testOnBorrow";
  static final String KEY_TEST_ON_RETURN = "testOnReturn";
  static final String KEY_TEST_WHILE_IDLE = "testWhileIdle";
  static final String KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS = "timeBetweenEvictionRunsMillis";
  static final String KEY_NUM_TESTS_PER_EVICTION_RUN = "numTestsPerEvictionRun";
  static final String KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS = "minEvictableIdleTimeMillis";
  static final String KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS = "softMinEvictableIdleTimeMillis";
  static final String KEY_LIFO = "lifo";
  static final String KEY_AUTO_COMMIT = "defaultAutoCommit";
  static final String KEY_READ_ONLY = "defaultReadOnly";
  static final String KEY_TRANSACTION_ISOLATION = "defaultTransactionIsolation";
  static final String KEY_CACHE_STATE = "cacheState";
  static final String KEY_VALIDATION_QUERY = "validationQuery";
  static final String KEY_MAX_CONN_LIFETIME_MILLIS = "maxConnLifetimeMillis";

  
  static final String DEFAULT_DRIVER = "org.h2.Driver";
  static final String DEFAULT_URL = "jdbc:h2:mem:default";
  static final String DEFAULT_USERNAME = "";
  static final String DEFAULT_PASSWORD = "";
  static final int DEFAULT_MAX_TOTAL = 8;
  static final int DEFAULT_MAX_IDLE = 8;
  static final int DEFAULT_MIN_IDLE = 0;
  static final long DEFAULT_MAX_WAIT_MILLIS = -1L;
  static final boolean DEFAULT_TEST_ON_CREATE = false;
  static final boolean DEFAULT_TEST_ON_BORROW = false;
  static final boolean DEFAULT_TEST_ON_RETURN = false;
  static final boolean DEFAULT_TEST_WHILE_IDLE = false;
  static final long DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS = -1L;
  static final int DEFAULT_NUM_TESTS_PER_EVICITON_RUN = 3;
  static final long DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS = 1_800_000L;
  static final long DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS = -1L;
  static final boolean DEFAULT_LIFO = true;
  static final boolean DEFAULT_AUTO_COMMIT = true;
  static final boolean DEFAULT_READ_ONLY = false;
  static final int DEFAULT_TRANSACTION_ISOLATION = -1;
  static final boolean DEFAULT_CACHE_STATE = true;
  static final String DEFAULT_VALIDATION_QUERY = null;
  static final long DEFAULT_MAX_CONN_LIFETIME_MILLIS = -1L;

  static void logValue(String key, String value) {
    LOG.debug("Using configured value for '" + key + "': " + value);
  }

  static void logDefault(String key, String defaultValue) {
    LOG.debug("Using default value for '" + key + "': " + defaultValue);
  }

  static void logDefault(String key, String providedValue, String reason, String defaultValue) {
    LOG.debug("Configured value for '" + key + "' ('" + providedValue + "') is " + reason
        + ", using default value: " + defaultValue);
  }

  
  
  

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
  @SuppressWarnings({"PMD.ExcessiveMethodLength", "PMD.NPathComplexity", "PMD.NcssMethodCount", "PMD.CyclomaticComplexity", "PMD.StdCyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity"})
    
    public static ConnectionProperties build(final Map<String, String> properties) {

        Validate.notNull(properties, "The validated object 'properties' is null");

        final ConnectionProperties connProps = new ConnectionProperties();
        String tmp = properties.get(KEY_DRIVER);
        if (StringUtils.isNotEmpty(tmp)) { 
            connProps.setDriver(tmp);
            logValue(KEY_DRIVER, tmp);
        } else {
            connProps.setDriver(DEFAULT_DRIVER);
            logDefault(KEY_DRIVER, DEFAULT_DRIVER);
        }

        tmp = properties.get(KEY_URL);
        if (StringUtils.isNotEmpty(tmp)) { 
            connProps.setUrl(tmp);
            logValue(KEY_URL, tmp);
        } else {
            connProps.setUrl(DEFAULT_URL);
            logDefault(KEY_URL, DEFAULT_URL);
        }

        tmp = properties.get(KEY_USERNAME);
        if (tmp == null) { 
            connProps.setUsername(DEFAULT_USERNAME);
            logDefault(KEY_USERNAME, DEFAULT_USERNAME);
        } else {
            connProps.setUsername(tmp);
            logValue(KEY_USERNAME, tmp);
        }

        tmp = properties.get(KEY_PASSWORD);
        if (tmp == null) { 
            connProps.setPassword(DEFAULT_PASSWORD);
            logDefault(KEY_PASSWORD, DEFAULT_PASSWORD);
        } else {
            connProps.setPassword(tmp);
            logValue(KEY_PASSWORD, tmp);
        }

        tmp = properties.get(KEY_MAX_TOTAL);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMaxTotal(Integer.decode(tmp));
                logValue(KEY_MAX_TOTAL, tmp);
            } else {
                connProps.setMaxTotal(DEFAULT_MAX_TOTAL);
                logDefault(KEY_MAX_TOTAL, tmp, "not numeric", String.valueOf(DEFAULT_MAX_TOTAL));
            }
        } else {
            connProps.setMaxTotal(DEFAULT_MAX_TOTAL);
            logDefault(KEY_MAX_TOTAL, String.valueOf(DEFAULT_MAX_TOTAL));
        }

        tmp = properties.get(KEY_MAX_IDLE);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMaxIdle(Integer.decode(tmp));
                logValue(KEY_MAX_IDLE, tmp);
            } else {
                connProps.setMaxIdle(DEFAULT_MAX_IDLE);
                logDefault(KEY_MAX_IDLE, tmp, "not numeric", String.valueOf(DEFAULT_MAX_IDLE));
            }
        } else {
            connProps.setMaxIdle(DEFAULT_MAX_IDLE);
            logDefault(KEY_MAX_IDLE, String.valueOf(DEFAULT_MAX_IDLE));
        }

        tmp = properties.get(KEY_MIN_IDLE);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMinIdle(Integer.decode(tmp));
                logValue(KEY_MIN_IDLE, tmp);
            } else {
                connProps.setMinIdle(DEFAULT_MIN_IDLE);
                logDefault(KEY_MIN_IDLE, tmp, "not numeric", String.valueOf(DEFAULT_MIN_IDLE));
            }
        } else {
            connProps.setMinIdle(DEFAULT_MIN_IDLE);
            logDefault(KEY_MIN_IDLE, String.valueOf(DEFAULT_MIN_IDLE));
        }

        tmp = properties.get(KEY_MAX_WAIT_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMaxWaitMillis(Long.decode(tmp));
                logValue(KEY_MAX_WAIT_MILLIS, tmp);
            } else {
                connProps.setMaxWaitMillis(DEFAULT_MAX_WAIT_MILLIS);
                logDefault(KEY_MAX_WAIT_MILLIS, tmp, "not numeric", String.valueOf(DEFAULT_MAX_WAIT_MILLIS));
            }
        } else {
            connProps.setMaxWaitMillis(DEFAULT_MAX_WAIT_MILLIS);
            logDefault(KEY_MAX_WAIT_MILLIS, String.valueOf(DEFAULT_MAX_WAIT_MILLIS));
        }

        tmp = properties.get(KEY_TEST_ON_CREATE);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setTestOnCreate(Boolean.parseBoolean(tmp));
            logValue(KEY_TEST_ON_CREATE, tmp);
        } else {
            connProps.setTestOnCreate(DEFAULT_TEST_ON_CREATE);
            logDefault(KEY_TEST_ON_CREATE, String.valueOf(DEFAULT_TEST_ON_CREATE));
        }

        tmp = properties.get(KEY_TEST_ON_BORROW);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setTestOnBorrow(Boolean.parseBoolean(tmp));
            logValue(KEY_TEST_ON_BORROW, tmp);
        } else {
            connProps.setTestOnBorrow(DEFAULT_TEST_ON_BORROW);
            logDefault(KEY_TEST_ON_BORROW, String.valueOf(DEFAULT_TEST_ON_BORROW));
        }

        tmp = properties.get(KEY_TEST_ON_RETURN);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setTestOnReturn(Boolean.parseBoolean(tmp));
            logValue(KEY_TEST_ON_RETURN, tmp);
        } else {
            connProps.setTestOnReturn(DEFAULT_TEST_ON_RETURN);
            logDefault(KEY_TEST_ON_RETURN, String.valueOf(DEFAULT_TEST_ON_RETURN));
        }

        tmp = properties.get(KEY_TEST_WHILE_IDLE);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setTestWhileIdle(Boolean.parseBoolean(tmp));
            logValue(KEY_TEST_WHILE_IDLE, tmp);
        } else {
            connProps.setTestWhileIdle(DEFAULT_TEST_WHILE_IDLE);
            logDefault(KEY_TEST_WHILE_IDLE, String.valueOf(DEFAULT_TEST_WHILE_IDLE));
        }

        tmp = properties.get(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setTimeBetweenEvictionRunsMillis(Long.decode(tmp));
                logValue(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS, tmp);
            } else {
                connProps.setTimeBetweenEvictionRunsMillis(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
                logDefault(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS, tmp, "not numeric",
                        String.valueOf(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
            }
        } else {
            connProps.setTimeBetweenEvictionRunsMillis(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
            logDefault(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS,
                    String.valueOf(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
        }

        tmp = properties.get(KEY_NUM_TESTS_PER_EVICTION_RUN);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setNumTestsPerEvictionRun(Integer.decode(tmp));
                logValue(KEY_NUM_TESTS_PER_EVICTION_RUN, tmp);
            } else {
                connProps.setNumTestsPerEvictionRun(DEFAULT_NUM_TESTS_PER_EVICITON_RUN);
                logDefault(KEY_NUM_TESTS_PER_EVICTION_RUN, tmp, "not numeric",
                        String.valueOf(DEFAULT_NUM_TESTS_PER_EVICITON_RUN));
            }
        } else {
            connProps.setNumTestsPerEvictionRun(DEFAULT_NUM_TESTS_PER_EVICITON_RUN);
            logDefault(KEY_NUM_TESTS_PER_EVICTION_RUN, String.valueOf(DEFAULT_NUM_TESTS_PER_EVICITON_RUN));
        }

        tmp = properties.get(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMinEvictableIdleTimeMillis(Long.decode(tmp));
                logValue(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp);
            } else {
                connProps.setMinEvictableIdleTimeMillis(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
                logDefault(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp, "not numeric",
                        String.valueOf(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
            }
        } else {
            connProps.setMinEvictableIdleTimeMillis(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
            logDefault(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, String.valueOf(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
        }

        tmp = properties.get(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setSoftMinEvictableIdleTimeMillis(Long.decode(tmp));
                logValue(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp);
            } else {
                connProps.setSoftMinEvictableIdleTimeMillis(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
                logDefault(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp, "not numeric",
                        String.valueOf(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
            }
        } else {
            connProps.setSoftMinEvictableIdleTimeMillis(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
            logDefault(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS,
                    String.valueOf(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
        }

        tmp = properties.get(KEY_LIFO);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setLifo(Boolean.parseBoolean(tmp));
            logValue(KEY_LIFO, tmp);
        } else {
            connProps.setLifo(DEFAULT_LIFO);
            logDefault(KEY_LIFO, String.valueOf(DEFAULT_LIFO));
        }

        tmp = properties.get(KEY_AUTO_COMMIT);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setDefaultAutoCommit(Boolean.parseBoolean(tmp));
            logValue(KEY_AUTO_COMMIT, tmp);
        } else {
            connProps.setDefaultAutoCommit(DEFAULT_AUTO_COMMIT);
            logDefault(KEY_AUTO_COMMIT, String.valueOf(DEFAULT_AUTO_COMMIT));
        }

        tmp = properties.get(KEY_READ_ONLY);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setDefaultReadOnly(Boolean.parseBoolean(tmp));
            logValue(KEY_READ_ONLY, tmp);
        } else {
            connProps.setDefaultReadOnly(DEFAULT_READ_ONLY);
            logDefault(KEY_READ_ONLY, String.valueOf(DEFAULT_READ_ONLY));
        }

        tmp = properties.get(KEY_TRANSACTION_ISOLATION);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setDefaultTransactionIsolation(Integer.decode(tmp));
                logValue(KEY_TRANSACTION_ISOLATION, tmp);
            } else {
                connProps.setDefaultTransactionIsolation(DEFAULT_TRANSACTION_ISOLATION);
                logDefault(KEY_TRANSACTION_ISOLATION, tmp, "not numeric",
                        String.valueOf(DEFAULT_TRANSACTION_ISOLATION));
            }
        } else {
            connProps.setDefaultTransactionIsolation(DEFAULT_TRANSACTION_ISOLATION);
            logDefault(KEY_TRANSACTION_ISOLATION, String.valueOf(DEFAULT_TRANSACTION_ISOLATION));
        }

        tmp = properties.get(KEY_CACHE_STATE);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setCacheState(Boolean.parseBoolean(tmp));
            logValue(KEY_CACHE_STATE, tmp);
        } else {
            connProps.setCacheState(DEFAULT_CACHE_STATE);
            logDefault(KEY_CACHE_STATE, String.valueOf(DEFAULT_CACHE_STATE));
        }

        tmp = properties.get(KEY_VALIDATION_QUERY);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setValidationQuery(tmp);
            logValue(KEY_VALIDATION_QUERY, tmp);
        } else {
            connProps.setValidationQuery(DEFAULT_VALIDATION_QUERY);
            logDefault(KEY_VALIDATION_QUERY, DEFAULT_VALIDATION_QUERY);
        }

        tmp = properties.get(KEY_MAX_CONN_LIFETIME_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMaxConnLifetimeMillis(Long.decode(tmp));
                logValue(KEY_MAX_CONN_LIFETIME_MILLIS, tmp);
            } else {
                connProps.setMaxConnLifetimeMillis(DEFAULT_MAX_CONN_LIFETIME_MILLIS);
                logDefault(KEY_MAX_CONN_LIFETIME_MILLIS, tmp, "not numeric",
                        String.valueOf(DEFAULT_MAX_CONN_LIFETIME_MILLIS));
            }
        } else {
            connProps.setMaxConnLifetimeMillis(DEFAULT_MAX_CONN_LIFETIME_MILLIS);
            logDefault(KEY_MAX_CONN_LIFETIME_MILLIS, String.valueOf(DEFAULT_MAX_CONN_LIFETIME_MILLIS));
        }

        
        
        
        
        
        final Map<String, String> tempMap = new ConcurrentHashMap<>();
        for (final Map.Entry<String, String> entry : properties.entrySet()) {
            final String key = entry.getKey();
            final String value = entry.getValue();

            if (value != null) {
                tempMap.put(key, value);
            }
        }
        connProps.setAdditionalProperties(tempMap);

        return connProps;
    }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  
  
  
  public static void main(String[] args) {
    System.out.println("=== Reconstruction demo: MapBasedConnPropsBuilder.build ===");

    
    
    
    
    Map<String, String> props = new HashMap<>();
    props.put(KEY_DRIVER, "org.postgresql.Driver");
    props.put(KEY_URL, "jdbc:postgresql://localhost/demo");
    props.put(KEY_USERNAME, "");
    props.put(KEY_MAX_TOTAL, "25");
    props.put(KEY_MAX_IDLE, "notanumber"); 
    props.put(KEY_TEST_ON_BORROW, "true");
    props.put(KEY_VALIDATION_QUERY, "SELECT 1");
    props.put("someUnrelatedExtraKey", "extraValue"); 
    props.put("keyWithNullValue", null); 
    

    ConnectionProperties result = build(props);

    System.out.println("\n-- Built ConnectionProperties --");
    System.out.println("  " + result);

    System.out.println("\n=== Demo complete: method exercised the explicit-value branch, the "
        + "non-numeric-falls-back-to-default branch (maxIdle), the missing-key-defaults-applied "
        + "branch (password, minIdle, and others), the null-vs-blank-username/password distinct "
        + "handling, and the defensive-copy loop that filters out a null-valued entry while "
        + "preserving an unrelated extra key in additionalProperties. ===");
  }
}
