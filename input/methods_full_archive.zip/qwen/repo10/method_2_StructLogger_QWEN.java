import javax.lang.model.element.*;
import javax.lang.model.type.*;
import javax.lang.model.util.Types;
import javax.lang.model.util.Elements;
import javax.tools.Diagnostic;
import javax.annotation.processing.Messager;
import java.lang.annotation.*;
import java.util.*;
import java.util.stream.Collectors;




@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface VarContextProvider {
    boolean parametrization() default false;
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface Var {}

interface VariableContext {}

class LoggingEvent {
    public String timestamp;
    public String level;
    public String message;
}

enum LogLevel {
    INFO("info", "Info", "infoEvent"),
    DEBUG("debug", "Debug", "debugEvent"),
    ERROR("error", "Error", "errorEvent");
    
    private final String levelMethodName;
    private final String levelName;
    private final String logEventMethodName;
    
    LogLevel(String levelMethodName, String levelName, String logEventMethodName) {
        this.levelMethodName = levelMethodName;
        this.levelName = levelName;
        this.logEventMethodName = logEventMethodName;
    }
    public String getLevelMethodName() { return levelMethodName; }
    public String getLevelName() { return levelName; }
    public String getLogEventMethodName() { return logEventMethodName; }
}

class Variable {
    private final Name name;
    private final TypeMirror type;
    public Variable(Name name, TypeMirror type) { this.name = name; this.type = type; }
    public Name getName() { return name; }
    public TypeMirror getType() { return type; }
}

class VariableContextProvider {
    private final TypeMirror typeMirror;
    private final List<Variable> variables;
    private final boolean parametrization;
    public VariableContextProvider(TypeMirror typeMirror, List<Variable> variables, boolean parametrization) {
        this.typeMirror = typeMirror; 
        this.variables = variables; 
        this.parametrization = parametrization;
    }
    public TypeMirror getTypeMirror() { return typeMirror; }
    public List<Variable> getVariables() { return variables; }
    public boolean isParametrization() { return parametrization; }
}




class MockName implements Name {
    private final String value;
    public MockName(String value) { this.value = value; }
    public boolean contentEquals(CharSequence cs) { return value.contentEquals(cs); }
    public String toString() { return value; }
    public int length() { return value.length(); }
    public char charAt(int index) { return value.charAt(index); }
    public CharSequence subSequence(int start, int end) { return value.subSequence(start, end); }
}

class MockTypeMirror implements TypeMirror {
    private final String name;
    public MockTypeMirror(String name) { this.name = name; }
    public TypeKind getKind() { return TypeKind.DECLARED; }
    public String toString() { return name; }
    public <R, P> R accept(TypeVisitor<R, P> v, P p) { return null; }
    public List<? extends AnnotationMirror> getAnnotationMirrors() { return Collections.emptyList(); }
    public <A extends Annotation> A getAnnotation(Class<A> annotationType) { return null; }
    public <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationType) { return null; }
}


class MockExecutableType implements ExecutableType {
    private final TypeMirror returnType;
    private final List<TypeMirror> parameterTypes;
    MockExecutableType(TypeMirror returnType, List<TypeMirror> parameterTypes) { this.returnType = returnType; this.parameterTypes = parameterTypes; }
    public TypeKind getKind() { return TypeKind.EXECUTABLE; }
    public List<? extends TypeVariable> getTypeVariables() { return Collections.emptyList(); }
    public TypeMirror getReturnType() { return returnType; }
    public List<? extends TypeMirror> getParameterTypes() { return parameterTypes; }
    public TypeMirror getReceiverType() { return new MockTypeMirror("none"); }
    public List<? extends TypeMirror> getThrownTypes() { return Collections.emptyList(); }
    public <R,P> R accept(TypeVisitor<R,P> v, P p) { return null; }
    public List<? extends AnnotationMirror> getAnnotationMirrors() { return Collections.emptyList(); }
    public <A extends Annotation> A getAnnotation(Class<A> annotationType) { return null; }
    public <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationType) { return null; }
}

class MockExecutableElement implements ExecutableElement {
    private final Name simpleName;
    private final TypeMirror returnType;
    private final List<TypeMirror> parameterTypes;
    private final boolean hasVarAnnotation;

    public MockExecutableElement(String name, TypeMirror returnType, List<TypeMirror> parameterTypes, boolean hasVarAnnotation) {
        this.simpleName = new MockName(name);
        this.returnType = returnType;
        this.parameterTypes = parameterTypes;
        this.hasVarAnnotation = hasVarAnnotation;
    }

    public Name getSimpleName() { return simpleName; }
    public TypeMirror asType() { return new MockExecutableType(returnType, parameterTypes); }
    public TypeMirror getReturnType() { return returnType; }
    public List<? extends VariableElement> getParameters() { return Collections.emptyList(); }
    public ElementKind getKind() { return ElementKind.METHOD; }
    public <A extends Annotation> A getAnnotation(Class<A> annotationType) { 
        if (hasVarAnnotation && annotationType == Var.class) {
            return (A) new Var() { public Class<? extends Annotation> annotationType() { return Var.class; } };
        }
        return null; 
    }
    public <R, P> R accept(ElementVisitor<R, P> v, P p) { return null; }
    public List<? extends Element> getEnclosedElements() { return Collections.emptyList(); }
    public Element getEnclosingElement() { return null; }
    public List<? extends AnnotationMirror> getAnnotationMirrors() { return Collections.emptyList(); }
    public <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationType) { return null; }
    public Set<Modifier> getModifiers() { return EnumSet.of(Modifier.PUBLIC, Modifier.ABSTRACT); }
    public Name getQualifiedName() { return simpleName; }
    public TypeElement getEnclosingElementAsType() { return null; }
    public List<? extends TypeParameterElement> getTypeParameters() { return Collections.emptyList(); }
    public TypeMirror getReceiverType() { return null; }
    public boolean isVarArgs() { return false; }
    public boolean isDefault() { return false; }
    public List<? extends TypeMirror> getThrownTypes() { return Collections.emptyList(); }
    public AnnotationValue getDefaultValue() { return null; }
}

class MockTypeElement implements TypeElement {
    private final Name simpleName;
    private final Name qualifiedName;
    private final ElementKind kind;
    private final List<? extends Element> enclosedElements;
    private final List<? extends TypeMirror> interfaces;

    public MockTypeElement(String simpleName, String qualifiedName, ElementKind kind, List<? extends Element> enclosedElements, List<? extends TypeMirror> interfaces) {
        this.simpleName = new MockName(simpleName);
        this.qualifiedName = new MockName(qualifiedName);
        this.kind = kind;
        this.enclosedElements = enclosedElements;
        this.interfaces = interfaces;
    }

    public Name getSimpleName() { return simpleName; }
    public Name getQualifiedName() { return qualifiedName; }
    public ElementKind getKind() { return kind; }
    public Set<Modifier> getModifiers() { return EnumSet.of(Modifier.PUBLIC); }
    public TypeMirror asType() { return new MockTypeMirror(qualifiedName.toString()); }
    public Element getEnclosingElement() { return null; }
    public List<? extends Element> getEnclosedElements() { return enclosedElements; }
    public List<? extends TypeMirror> getInterfaces() { return interfaces; }
    public List<? extends TypeParameterElement> getTypeParameters() { return Collections.emptyList(); }
    public NestingKind getNestingKind() { return NestingKind.TOP_LEVEL; }
    public <A extends Annotation> A getAnnotation(Class<A> annotationType) { 
        if (annotationType == VarContextProvider.class) {
            return (A) new VarContextProvider() { 
                public boolean parametrization() { return true; } 
                public Class<? extends Annotation> annotationType() { return VarContextProvider.class; } 
            };
        }
        return null; 
    }
    public <R, P> R accept(ElementVisitor<R, P> v, P p) { return null; }
    public List<? extends AnnotationMirror> getAnnotationMirrors() { return Collections.emptyList(); }
    public <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationType) { return null; }
    public TypeMirror getSuperclass() { return new MockTypeMirror("java.lang.Object"); }
}

class MockTypes implements Types {
    public Element asElement(TypeMirror t) { 
        if (t.toString().equals("com.example.MyContext")) {
            List<TypeMirror> interfaces = Arrays.asList(new MockTypeMirror("com.github.structlogging.VariableContext"));
            List<Element> methods = Arrays.asList(
                new MockExecutableElement("userId", new MockTypeMirror("com.example.MyContext"), Arrays.asList(new MockTypeMirror("java.lang.String")), true),
                new MockExecutableElement("sessionId", new MockTypeMirror("com.example.MyContext"), Arrays.asList(new MockTypeMirror("java.lang.String")), true)
            );
            return new MockTypeElement("MyContext", "com.example.MyContext", ElementKind.INTERFACE, methods, interfaces);
        }
        return null; 
    }
    public boolean isSubtype(TypeMirror t1, TypeMirror t2) { return true; }
    public boolean isAssignable(TypeMirror t1, TypeMirror t2) { return isSubtype(t1, t2); }
    public boolean contains(TypeMirror t1, TypeMirror t2) { return isSameType(t1, t2); }
    public boolean isSubsignature(ExecutableType m1, ExecutableType m2) { return true; }
    public boolean isSameType(TypeMirror t1, TypeMirror t2) { return t1.toString().equals(t2.toString()); }
    public TypeMirror erasure(TypeMirror t) { return t; }
    public List<? extends TypeMirror> directSupertypes(TypeMirror t) { return Collections.emptyList(); }
    public TypeElement boxedClass(PrimitiveType t) { return null; }
    public PrimitiveType unboxedType(TypeMirror t) { return null; }
    public TypeMirror capture(TypeMirror t) { return t; }
    public ArrayType getArrayType(TypeMirror componentType) { return null; }
    public WildcardType getWildcardType(TypeMirror extendsBound, TypeMirror superBound) { return null; }
    public DeclaredType getDeclaredType(TypeElement typeElem, TypeMirror... typeArgs) { return null; }
    public DeclaredType getDeclaredType(DeclaredType containing, TypeElement typeElem, TypeMirror... typeArgs) { return null; }
    public NoType getNoType(TypeKind kind) { return null; }
    public NullType getNullType() { return null; }
    public PrimitiveType getPrimitiveType(TypeKind kind) { return null; }
        public TypeMirror asMemberOf(DeclaredType containing, Element element) { return null; }
}

class MockMessager implements Messager {
    public void printMessage(Diagnostic.Kind kind, CharSequence msg) { 
        System.out.println("  [" + kind + "] " + msg); 
    }
    public void printMessage(Diagnostic.Kind kind, CharSequence msg, Element e) { 
        System.out.println("  [" + kind + "] " + msg + " at " + (e != null ? e.getSimpleName() : "null")); 
    }
    public void printMessage(Diagnostic.Kind kind, CharSequence msg, Element e, AnnotationMirror a) { printMessage(kind, msg, e); }
    public void printMessage(Diagnostic.Kind kind, CharSequence msg, Element e, AnnotationMirror a, AnnotationValue v) { printMessage(kind, msg, e); }
}




public class method_2_StructLogger_QWEN {

    private final Types types = new MockTypes();
    private final Messager messager = new MockMessager();
    private final Map<TypeMirror, VariableContextProvider> varsHashMap = new HashMap<>();
    private final Set<TypeMirror> varContextProviders = new HashSet<>();

    private String format(String format, Object... args) { 
        return String.format(format, args); 
    }

    private boolean extendsVariableContext(TypeElement element) {
        for (TypeMirror iface : element.getInterfaces()) {
            if (iface.toString().contains("VariableContext")) {
                return true;
            }
        }
        return false;
    }


// ORIGINAL CODESEARCHNET METHOD — START

private boolean checkVarContextProvider(final TypeMirror typeMirror) {
        final TypeElement element = (TypeElement) types.asElement(typeMirror);
        if (varContextProviders.contains(typeMirror)) { 
            return true;
        }

        if (!element.getKind().isInterface()) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be interface",
                            element
                    ),
                    element
            );
            return false;
        }

        boolean extendsVariableContext = extendsVariableContext(element);

        if (!extendsVariableContext) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be extending %s",
                            element,
                            VariableContext.class.getName()
                    ),
                    element
            );
            return false;
        }

        final List<Variable> elements = new ArrayList<>();
        final VarContextProvider varContextProvider = element.getAnnotation(VarContextProvider.class);

        if (varContextProvider == null) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be annotated with @VarContextProvider",
                            element
                    ),
                    element
            );
            return false;
        }

        
        for (Element enclosed : element.getEnclosedElements()) {
            final Var annotation = enclosed.getAnnotation(Var.class);
            if (annotation != null) {
                final ExecutableType executableType = (ExecutableType) enclosed.asType();
                final Name simpleName = enclosed.getSimpleName();
                

                
                final List<String> logLevelsMethodNames = Arrays.stream(
                        LogLevel.values()
                )
                        .map(
                                LogLevel::getLevelMethodName
                        )
                        .collect(
                                Collectors.toList()
                        );

                
                final List<String> logEventMethodNames = Arrays.stream(
                        LogLevel.values()
                )
                        .map(
                                LogLevel::getLogEventMethodName
                        )
                        .collect(
                                Collectors.toList()
                        );

                List<String> loggingEventFieldNames =
                        Arrays.stream(LoggingEvent.class.getDeclaredFields()).map(e -> e.getName()).collect(Collectors.toList());
                if (
                        simpleName.contentEquals("log") || 
                        logLevelsMethodNames.stream().anyMatch(simpleName::contentEquals) ||
                        logEventMethodNames.stream().anyMatch(simpleName::contentEquals) ||
                        loggingEventFieldNames.stream().anyMatch(simpleName::contentEquals)
                   )
                {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s interface cannot have method named %s",
                                    element,
                                    simpleName
                            ),
                            element
                    );
                    return false;
                }
                if (!executableType.getReturnType().toString().equals(typeMirror.toString())) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method must have return type %s",
                                    element,
                                    simpleName,
                                    element
                            ),
                            element
                    );
                    return false;
                }
                if (executableType.getParameterTypes().size() != 1) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method must have exactly one argument",
                                    element,
                                    simpleName
                            ),
                            element);
                    return false;
                }
                if (elements.stream().map(Variable::getName).anyMatch(e -> e.contentEquals(simpleName))) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method cannot be overloaded",
                                    element,
                                    simpleName
                            ),
                            element
                    );
                    return false;
                }
                elements.add(new Variable(simpleName, executableType.getParameterTypes().get(0)));
            }
        }
        if (elements.isEmpty()) { 
            messager.printMessage(
                    Diagnostic.Kind.WARNING,
                    format(
                            "%s has no @Var annotated methods",
                            element
                    ),
                    element
            );
        }
        varsHashMap.put(typeMirror, new VariableContextProvider(typeMirror, elements, varContextProvider.parametrization()));
        varContextProviders.add(typeMirror);
        return true;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 2: checkVarContextProvider - Context Validation      ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            method_2_StructLogger_QWEN processor = new method_2_StructLogger_QWEN();
            
            TypeMirror mockType = new MockTypeMirror("com.example.MyContext");
            
            System.out.println("┌─ VALIDATING VARIABLE CONTEXT PROVIDER ─────────────────────┐");
            System.out.println("│ Target Type: " + mockType);
            System.out.println("│");
            
            boolean isValid = processor.checkVarContextProvider(mockType);
            
            System.out.println("│");
            if (isValid) {
                System.out.println("│ ✓ Interface validation passed (isInterface == true)");
                System.out.println("│ ✓ Extends VariableContext verified");
                System.out.println("│ ✓ @VarContextProvider annotation present");
                System.out.println("│ ✓ Method 'userId' validated: correct return type, 1 param, not reserved");
                System.out.println("│ ✓ Method 'sessionId' validated: correct return type, 1 param, not reserved");
                System.out.println("│ ✓ Registered in varsHashMap with parametrization=true");
            } else {
                System.out.println("│ ✗ Validation failed. Check error messages above.");
            }
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            System.out.println("\nSUCCESS: Context provider validated: " + isValid);
            
            System.out.println("\n[Cache Check] Calling checkVarContextProvider again...");
            boolean isCached = processor.checkVarContextProvider(mockType);
            System.out.println("Returned immediately from cache: " + isCached);
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}