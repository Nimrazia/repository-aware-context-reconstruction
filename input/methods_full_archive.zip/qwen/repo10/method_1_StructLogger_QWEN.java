import javax.lang.model.element.Name;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeVisitor;
import javax.tools.Diagnostic;
import javax.annotation.processing.Messager;
import java.util.*;
import java.util.regex.Pattern;




enum LogLevel {
    INFO("info", "Info", "infoEvent"),
    DEBUG("debug", "Debug", "debugEvent"),
    ERROR("error", "Error", "errorEvent");
    
    private final String levelMethodName;
    private final String levelName;
    private final String logEventMethodName;
    
    LogLevel(String levelMethodName, String levelName, String logEventMethodName) {
        this.levelMethodName = levelMethodName;
        this.levelName = levelName;
        this.logEventMethodName = logEventMethodName;
    }
    public String getLevelMethodName() { return levelMethodName; }
    public String getLevelName() { return levelName; }
    public String getLogEventMethodName() { return logEventMethodName; }
}




class Variable {
    private final Name name;
    private final TypeMirror type;
    public Variable(Name name, TypeMirror type) { this.name = name; this.type = type; }
    public Name getName() { return name; }
    public TypeMirror getType() { return type; }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Variable variable = (Variable) o;
        return name != null ? name.toString().equals(variable.name.toString()) : variable.name == null;
    }
    @Override public int hashCode() { return name != null ? name.toString().hashCode() : 0; }
}

class VariableAndValue implements Comparable<VariableAndValue> {
    private final Variable variable;
    private final Object value;
    public VariableAndValue(Variable variable, Object value) { this.variable = variable; this.value = value; }
    public Variable getVariable() { return variable; }
    public Object getValue() { return value; }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VariableAndValue that = (VariableAndValue) o;
        return variable != null ? variable.equals(that.variable) : that.variable == null;
    }
    @Override public int hashCode() { return variable != null ? variable.hashCode() : 0; }
    @Override public int compareTo(VariableAndValue o) { 
        return this.variable.getName().toString().compareTo(o.getVariable().getName().toString()); 
    }
}

class MethodAndParameter {
    private final Name methodName;
    private final Object parameter;
    public MethodAndParameter(Name methodName, Object parameter) { 
        this.methodName = methodName; this.parameter = parameter; 
    }
    public Name getMethodName() { return methodName; }
    public Object getParameter() { return parameter; }
}

class StatementInfo {
    private final long lineNumber;
    private final String sourceFileName;
    private final Object statement;
    public StatementInfo(long lineNumber, String sourceFileName, Object statement) {
        this.lineNumber = lineNumber; this.sourceFileName = sourceFileName; this.statement = statement;
    }
    public long getLineNumber() { return lineNumber; }
    public String getSourceFileName() { return sourceFileName; }
    public Object getStatement() { return statement; }
}

class StructLoggerFieldContext {
    private final TypeMirror contextProvider;
    public StructLoggerFieldContext(TypeMirror contextProvider) { this.contextProvider = contextProvider; }
    public TypeMirror getContextProvider() { return contextProvider; }
}

class VariableContextProvider {
    private final TypeMirror typeMirror;
    private final List<Variable> variables;
    private final boolean parametrization;
    public VariableContextProvider(TypeMirror typeMirror, List<Variable> variables, boolean parametrization) {
        this.typeMirror = typeMirror; this.variables = variables; this.parametrization = parametrization;
    }
    public TypeMirror getTypeMirror() { return typeMirror; }
    public List<Variable> getVariables() { return variables; }
    public boolean shouldParametrize() { return parametrization; }
}

class GeneratedClassInfo {
    private final String qualifiedName;
    private final String simpleName;
    private final String description;
    private final List<VariableAndValue> usedVariables;
    private final String packageName;
    public GeneratedClassInfo(String qualifiedName, String simpleName, String description, List<VariableAndValue> usedVariables, String packageName) {
        this.qualifiedName = qualifiedName; this.simpleName = simpleName; this.description = description;
        this.usedVariables = usedVariables; this.packageName = packageName;
    }
    public String getQualifiedName() { return qualifiedName; }
    public String getSimpleName() { return simpleName; }
    public List<VariableAndValue> getUsedVariables() { return usedVariables; }
    public String getPackageName() { return packageName; }
}

class PackageNameException extends Exception {
    public PackageNameException(String message) { super(message); }
}




class JavaFileStub {
    public final String packageName;
    public final TypeSpecStub typeSpec;
    public JavaFileStub(String packageName, String className) {
        this.packageName = packageName;
        this.typeSpec = new TypeSpecStub(className);
    }
}
class TypeSpecStub {
    public final String name;
    public TypeSpecStub(String name) { this.name = name; }
}

class POJOService {
    public JavaFileStub createPojo(String name, JCTree.JCLiteral literal, List<VariableAndValue> usedVariables) throws PackageNameException {
        return new JavaFileStub("com.example.generated", "GeneratedEvent");
    }
    public void writeJavaFile(JavaFileStub javaFile) {  }
}

class StringUtils {
    public static int countMatches(String str, String sub) {
        if (str == null || sub == null || sub.isEmpty()) return 0;
        int count = 0, idx = 0;
        while ((idx = str.indexOf(sub, idx)) != -1) { count++; idx += sub.length(); }
        return count;
    }
    public static boolean isBlank(String str) { return str == null || str.trim().isEmpty(); }
}

interface MethodInvocationTree {
    List<Object> getArguments();
}

class JCTree {
    static class JCLiteral {
        private final String value;
        public JCLiteral(String value) { this.value = value; }
        public String getValue() { return value; }
    }
}




public class method_1_StructLogger_QWEN {

    private Messager messager = new Messager() {
        public void printMessage(Diagnostic.Kind kind, CharSequence msg) { System.out.println("  [" + kind + "] " + msg); }
        public void printMessage(Diagnostic.Kind kind, CharSequence msg, javax.lang.model.element.Element e) { printMessage(kind, msg); }
        public void printMessage(Diagnostic.Kind kind, CharSequence msg, javax.lang.model.element.Element e, javax.lang.model.element.AnnotationMirror a) { printMessage(kind, msg); }
        public void printMessage(Diagnostic.Kind kind, CharSequence msg, javax.lang.model.element.Element e, javax.lang.model.element.AnnotationMirror a, javax.lang.model.element.AnnotationValue v) { printMessage(kind, msg); }
    };

    private String formatWithStatementLocation(String format, StatementInfo statementInfo, Object... args) {
        return String.format(format, args) + String.format(" [%s:%d]", statementInfo.getSourceFileName(), statementInfo.getLineNumber());
    }

    private void printStatementMustHaveStringLiteralError(StatementInfo statementInfo, Name topMethodName) {
        messager.printMessage(Diagnostic.Kind.ERROR, formatWithStatementLocation("method %s in %s statement must have String literal as argument", statementInfo, topMethodName, statementInfo.getStatement()));
    }

    private void addToUsedVariables(List<VariableAndValue> usedVariables, MethodAndParameter top, Variable variable) {
        VariableAndValue variableAndValue = new VariableAndValue(variable, top.getParameter());
        if (!usedVariables.contains(variableAndValue)) {
            usedVariables.add(variableAndValue);
        } else {
            int i = 0;
            do {
                i++;
                variableAndValue = new VariableAndValue(new Variable(createName(variable.getName().toString() + i), variable.getType()), top.getParameter());
            } while (usedVariables.contains(variableAndValue));
            usedVariables.add(variableAndValue);
        }
    }

    private Name createName(String s) { 
        return new Name() { 
            public boolean contentEquals(CharSequence cs) { return s.contentEquals(cs); } 
            public String toString() { return s; } 
            public int length() { return s.length(); } 
            public char charAt(int index) { return s.charAt(index); } 
            public CharSequence subSequence(int start, int end) { return s.subSequence(start, end); } 
        }; 
    }

    private void replaceInCode(String loggerName, GeneratedClassInfo generatedClassInfo, StatementInfo statementInfo, List<VariableAndValue> usedVariables, JCTree.JCLiteral literal, String level, VariableContextProvider variableContextProvider) {
        System.out.println("      → Replaced statement with: " + loggerName + "." + level.toLowerCase() + "Event(new " + generatedClassInfo.getQualifiedName() + "(...))");
    }


// ORIGINAL CODESEARCHNET METHOD — START

private void handleStructLogExpression(final Stack<MethodAndParameter> stack,
                                           final MethodInvocationTree node,
                                           final Name name,
                                           final StatementInfo statementInfo,
                                           final ScannerParams scannerParams) {
        final java.util.List<VariableAndValue> usedVariables = new ArrayList<>();
        JCTree.JCLiteral literal = null;
        String level = null;
        String eventName = null;

        
        final StructLoggerFieldContext structLoggerFieldContext = scannerParams.getFields().get(name);
        final TypeMirror typeMirror = structLoggerFieldContext.getContextProvider();
        final VariableContextProvider variableContextProvider = scannerParams.getVarsHashMap().get(typeMirror);

        
        
        while (!stack.empty()) {
            
            boolean matched = false;
            final MethodAndParameter top = stack.pop();
            
            for (Variable variable : variableContextProvider.getVariables()) {
                final Name topMethodName = top.getMethodName();

                if (variable.getName().contentEquals(topMethodName)) {
                    addToUsedVariables(usedVariables, top, variable);
                    matched = true;
                    break;
                }
                else {
                    for (LogLevel logLevel : LogLevel.values()) {
                        if (topMethodName.contentEquals(logLevel.getLevelMethodName())) {
                            if (!(node.getArguments().get(0) instanceof JCTree.JCLiteral)) {
                                printStatementMustHaveStringLiteralError(statementInfo, topMethodName);
                                return;
                            }
                            literal = (JCTree.JCLiteral) node.getArguments().get(0);
                            level = logLevel.getLevelName();
                            matched = true;
                            break;
                        }
                        else if (topMethodName.contentEquals(logLevel.getLogEventMethodName())) {
                            return; 
                        }
                    }
                }
            }

            if (top.getMethodName().contentEquals("log") && top.getParameter() != null) {
                if (!(top.getParameter() instanceof JCTree.JCLiteral)) {
                    printStatementMustHaveStringLiteralError(statementInfo, top.getMethodName());
                    return;
                }
                eventName = ((JCTree.JCLiteral) top.getParameter()).getValue().toString();
                if (!Pattern.compile("^(\\w+(\\.\\w+)*)+$").matcher(eventName).matches()) {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            formatWithStatementLocation(
                                    "qualified event name %s specified by %s statement is not valid",
                                    statementInfo,
                                    eventName,
                                    statementInfo.getStatement()
                            )
                    );
                    return;
                }
                matched = true;
            } else if (top.getMethodName().contentEquals("log") && top.getParameter() == null) {
                matched = true;
            }
            if (stack.empty() && !top.getMethodName().contentEquals("log")) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "statement %s must be ended by calling log() method",
                                statementInfo,
                                statementInfo.getStatement()
                        )
                );
                return;
            }
            if (!matched) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "variable %s in statement %s is not specified by variable context %s",
                                statementInfo,
                                top.getMethodName(),
                                statementInfo.getStatement(),
                                variableContextProvider.getTypeMirror()
                        )
                );
                return;
            }
        }

        
        if (variableContextProvider.shouldParametrize()) {
            final int countOfStringVariables = StringUtils.countMatches(literal.getValue().toString(), "{}");
            if (countOfStringVariables != usedVariables.size()) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "literal %s contains %d variables, but statement %s uses %d variables",
                                statementInfo,
                                literal.getValue().toString(),
                                countOfStringVariables,
                                statementInfo.getStatement(),
                                usedVariables.size()
                        )
                );
                return;
            }
        }

        
        JavaFileStub javaFile;
        try {
            POJOService pojoService = new POJOService();
            javaFile = pojoService.createPojo(eventName != null ? eventName : "defaultEvent", literal, usedVariables);
        } catch (PackageNameException e) {
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    formatWithStatementLocation(
                            "qualified event name %s generated by statement %s is not valid, please check specified event name and package does not contain java keyword or no subpackage or class name starts with number",
                            statementInfo,
                            eventName,
                            statementInfo.getStatement()
                    )
            );
            return;
        }
        final String className = javaFile.typeSpec.name;
        final String qualifiedName = StringUtils.isBlank(javaFile.packageName) ? className : javaFile.packageName + "." + className;
        final GeneratedClassInfo generatedClassInfo = new GeneratedClassInfo(qualifiedName, className, (String) literal.getValue(), usedVariables, javaFile.packageName);
        for (GeneratedClassInfo info : scannerParams.getGeneratedClassesInfo()) {
            if (info.getQualifiedName().equals(generatedClassInfo.getQualifiedName())
                    && !info.getUsedVariables().equals(generatedClassInfo.getUsedVariables())
                    ) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "Statement %s generates different event structure for same event name",
                                statementInfo,
                                statementInfo.getStatement()
                        )
                );
                return;
            }
        }
        scannerParams.getGeneratedClassesInfo().add(generatedClassInfo);

        new POJOService().writeJavaFile(javaFile);

        
        replaceInCode(name.toString(), generatedClassInfo, statementInfo, usedVariables, literal, level, variableContextProvider);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 1: handleStructLogExpression - AST Log Parsing       ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            method_1_StructLogger_QWEN scanner = new method_1_StructLogger_QWEN();
            
            Name fieldName = scanner.createName("logger");
            Name varName = scanner.createName("userId");
            
            TypeMirror mockType = new TypeMirror() { 
                public TypeKind getKind() { return null; } 
                public String toString() { return "MockContext"; } 
                public <R, P> R accept(TypeVisitor<R, P> v, P p) { return null; }
                public java.util.List<? extends javax.lang.model.element.AnnotationMirror> getAnnotationMirrors() { return java.util.Collections.emptyList(); }
                public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType) { return null; }
                public <A extends java.lang.annotation.Annotation> A[] getAnnotationsByType(Class<A> annotationType) { return null; }
            };
            
            VariableContextProvider vcp = new VariableContextProvider(mockType, Arrays.asList(new Variable(varName, mockType)), true);
            StructLoggerFieldContext sfc = new StructLoggerFieldContext(mockType);
            
            Map<Name, StructLoggerFieldContext> fields = new HashMap<>();
            fields.put(fieldName, sfc);
            
            Map<TypeMirror, VariableContextProvider> varsMap = new HashMap<>();
            varsMap.put(mockType, vcp);
            
            Set<GeneratedClassInfo> generatedClasses = new HashSet<>();
            ScannerParams params = new ScannerParams(null, null, varsMap, fields, generatedClasses);
            
            Stack<MethodAndParameter> stack = new Stack<>();
            stack.push(new MethodAndParameter(scanner.createName("log"), null));
            stack.push(new MethodAndParameter(scanner.createName("info"), null));
            stack.push(new MethodAndParameter(scanner.createName("userId"), "12345"));
            
            StatementInfo stmtInfo = new StatementInfo(42, "MyClass.java", "logger.userId(\"12345\").info().log()");
            
            MethodInvocationTree mockNode = new MethodInvocationTree() {
                public List<Object> getArguments() {
                    return Arrays.asList(new JCTree.JCLiteral("User {} logged in"));
                }
            };
            
            System.out.println("┌─ STRUCTURED LOG STATEMENT ANALYSIS ────────────────────────┐");
            System.out.println("│ Statement: " + stmtInfo.getStatement());
            System.out.println("│ Location: " + stmtInfo.getSourceFileName() + ":" + stmtInfo.getLineNumber());
            System.out.println("│");
            
            scanner.handleStructLogExpression(stack, mockNode, fieldName, stmtInfo, params);
            
            System.out.println("│");
            System.out.println("│ ✓ Variables matched and tracked: " + generatedClasses.iterator().next().getUsedVariables().size());
            System.out.println("│ ✓ Event class generated: " + generatedClasses.iterator().next().getQualifiedName());
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            System.out.println("\nSUCCESS: Log expression handled and transformed successfully.");
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

class ScannerParams {
    private final Map<TypeMirror, VariableContextProvider> varsHashMap;
    private final Map<Name, StructLoggerFieldContext> fields;
    private final Set<GeneratedClassInfo> generatedClassesInfo;
    public ScannerParams(Object typeElement, Object compilationUnitTree, Map<TypeMirror, VariableContextProvider> varsHashMap, Map<Name, StructLoggerFieldContext> fields, Set<GeneratedClassInfo> generatedClassesInfo) {
        this.varsHashMap = varsHashMap; this.fields = fields; this.generatedClassesInfo = generatedClassesInfo;
    }
    public Map<TypeMirror, VariableContextProvider> getVarsHashMap() { return varsHashMap; }
    public Map<Name, StructLoggerFieldContext> getFields() { return fields; }
    public Set<GeneratedClassInfo> getGeneratedClassesInfo() { return generatedClassesInfo; }
}