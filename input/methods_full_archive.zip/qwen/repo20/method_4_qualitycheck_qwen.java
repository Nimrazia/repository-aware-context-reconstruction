import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class method_4_qualitycheck_qwen {

    private static final Pattern PATTERN = Pattern.compile("([A-Za-z][A-Za-z0-9]*)");

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public static String determineAccessorName(final AccessorPrefix prefix, final String fieldName) {
        Check.notNull(prefix, "prefix");
        Check.notEmpty(fieldName, "fieldName");
        final Matcher m = PATTERN.matcher(fieldName);
        Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
        final String name = m.group();
        return prefix.getPrefix() + name.substring(0, 1).toUpperCase() + name.substring(1);
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== QualityCheck MethodUtil.determineAccessorName Test ===");
        
        try {
            System.out.println("Testing 'GET' prefix with 'userName'...");
            String accessor1 = determineAccessorName(AccessorPrefix.GET, "userName");
            System.out.println("Result: " + accessor1);
            assert "getUserName".equals(accessor1) : "Expected 'getUserName'";

            System.out.println("Testing 'IS' prefix with 'active'...");
            String accessor2 = determineAccessorName(AccessorPrefix.IS, "active");
            System.out.println("Result: " + accessor2);
            assert "isActive".equals(accessor2) : "Expected 'isActive'";

            System.out.println("Testing 'HAS' prefix with 'children'...");
            String accessor3 = determineAccessorName(AccessorPrefix.HAS, "children");
            System.out.println("Result: " + accessor3);
            assert "hasChildren".equals(accessor3) : "Expected 'hasChildren'";

            System.out.println("SUCCESS: All assertions passed. Method executed without throwing exceptions.");
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    

    


    public static final class MethodUtil {
        private static final String METHOD_SET_PREFIX = "set";
        private static final Pattern PATTERN = Pattern.compile("([A-Za-z][A-Za-z0-9]*)");

        private MethodUtil() {
            
        }

        public static String determineMutatorName(final String fieldName) {
            Check.notEmpty(fieldName, "fieldName");
            final Matcher m = PATTERN.matcher(fieldName);
            Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
            final String name = m.group();
            return METHOD_SET_PREFIX + name.substring(0, 1).toUpperCase() + name.substring(1);
        }
    }

    


    public static final class Check {
        private Check() {}

        public static <T> T notNull(final T object, final String name) {
            if (object == null) {
                throw new IllegalArgumentException(name + " must not be null");
            }
            return object;
        }

                public static String notEmpty(final String string, final String name) {
            notNull(string, name);
            if (string.trim().isEmpty()) {
                throw new IllegalArgumentException(name + " must not be empty");
            }
            return string;
        }

        public static void stateIsTrue(final boolean expression, final String message, final Object... args) {
            if (!expression) {
                throw new IllegalStateException(String.format(message, args));
            }
        }
    }

    


    public static final class AccessorPrefix {
        private static final String METHOD_GET_PREFIX = "get";
        private static final String METHOD_HAS_PREFIX = "has";
        private static final String METHOD_IS_PREFIX = "is";

        public static final AccessorPrefix NOT_NEEDED = new AccessorPrefix();
        public static final AccessorPrefix GET = new AccessorPrefix(METHOD_GET_PREFIX);
        public static final AccessorPrefix HAS = new AccessorPrefix(METHOD_HAS_PREFIX);
        public static final AccessorPrefix IS = new AccessorPrefix(METHOD_IS_PREFIX);

                private final String prefix;

        private AccessorPrefix() {
            this.prefix = "";
        }

        public AccessorPrefix(final String prefix) {
            this.prefix = Check.notEmpty(prefix.trim(), "prefix");
        }

        public String getPrefix() {
            return prefix;
        }

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            final AccessorPrefix other = (AccessorPrefix) obj;
            return prefix.equals(other.prefix);
        }

        @Override
        public int hashCode() {
            return 31 * 1 + prefix.hashCode();
        }

        @Override
        public String toString() {
            return "AccessorPrefix{prefix='" + prefix + "'}";
        }
    }
}