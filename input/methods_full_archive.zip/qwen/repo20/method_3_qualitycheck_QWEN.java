import java.math.BigDecimal;
import java.math.BigInteger;

public class method_3_qualitycheck_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private static <T> Number checkNumberInRange(final String value, final Class<T> type) {
        final Number ret;
        if (type.equals(Byte.class)) {
            final Number number = new BigInteger(value);
            NumberInRange.checkByte(number);
            ret = Byte.valueOf(number.byteValue());
        } else if (type.equals(Double.class)) {
            final Number number = new BigDecimal(value);
            NumberInRange.checkDouble(number);
            ret = Double.valueOf(number.doubleValue());
        } else if (type.equals(Float.class)) {
            final Number number = new BigDecimal(value);
            NumberInRange.checkFloat(number);
            ret = Float.valueOf(number.floatValue());
        } else if (type.equals(Integer.class)) {
            final Number number = new BigInteger(value);
            NumberInRange.checkInteger(number);
            ret = Integer.valueOf(number.intValue());
        } else if (type.equals(Long.class)) {
            final Number number = new BigInteger(value);
            NumberInRange.checkLong(number);
            ret = Long.valueOf(number.longValue());
        } else if (type.equals(Short.class)) {
            final Number number = new BigInteger(value);
            NumberInRange.checkShort(number);
            ret = Short.valueOf(number.shortValue());
        } else if (type.equals(BigInteger.class)) {
            ret = new BigInteger(value);
        } else if (type.equals(BigDecimal.class)) {
            ret = new BigDecimal(value);
        } else {
            throw new IllegalNumberArgumentException("Return value is no known subclass of 'java.lang.Number': " + type.getName());
        }
        return ret;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== QualityCheck Check.checkNumberInRange Test ===");
        try {
            System.out.println("Testing Integer range check...");
            Number intResult = checkNumberInRange("42", Integer.class);
            System.out.println("SUCCESS: Integer result = " + intResult);
            
            System.out.println("Testing BigDecimal range check...");
            Number bdResult = checkNumberInRange("3.14159", BigDecimal.class);
            System.out.println("SUCCESS: BigDecimal result = " + bdResult);
            
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    public static class IllegalNumberArgumentException extends IllegalArgumentException {
        public IllegalNumberArgumentException(String msg) { super(msg); }
    }

    public static class NumberInRange {
        public static byte checkByte(Number number) { return number.byteValue(); }
        public static double checkDouble(Number number) { return number.doubleValue(); }
        public static float checkFloat(Number number) { return number.floatValue(); }
        public static int checkInteger(Number number) { return number.intValue(); }
        public static int checkLong(Number number) { return number.intValue(); } 
        public static short checkShort(Number number) { return number.shortValue(); }
    }
}