import java.util.ArrayList;
import java.util.List;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@interface Nonnull {}

public class method_1_qualitycheck_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Nonnull
    public static InterfaceAnalysis analyze(@Nonnull final String code) {
        Check.notNull(code, "code");

        final CompilationUnit unit = Check.notNull(SourceCodeReader.parse(code), "compilationUnit");
        final List<TypeDeclaration> types = Check.notEmpty(unit.getTypes(), "typeDeclarations");
        Check.stateIsTrue(types.size() == 1, "only one interface declaration per analysis is supported");

        final ClassOrInterfaceDeclaration type = (ClassOrInterfaceDeclaration) types.get(0);

        final Imports imports = SourceCodeReader.findImports(unit.getImports());
        final Package pkg = unit.getPackage() != null ? new Package(unit.getPackage().getName().toString()) : Package.UNDEFINED;
        final List<Annotation> annotations = SourceCodeReader.findAnnotations(type.getAnnotations(), imports);
        final List<Method> methods = SourceCodeReader.findMethods(type.getMembers(), imports);
        Check.stateIsTrue(!hasPossibleMutatingMethods(methods), "The passed interface '%s' seems to have mutating methods", type.getName());
        final List<Interface> extendsInterfaces = SourceCodeReader.findExtends(type);
        final String interfaceName = type.getName();
        return new ImmutableInterfaceAnalysis(annotations, extendsInterfaces, imports.asList(), interfaceName, methods, pkg);
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== QualityCheck InterfaceAnalyzer.analyze Test ===");
        String mockCode = "package com.example;\n" +
                          "import java.util.List;\n" +
                          "public interface MyInterface {\n" +
                          "    String getName();\n" +
                          "}";
        try {
            System.out.println("Invoking analyze...");
            InterfaceAnalysis analysis = method_1_qualitycheck_QWEN.analyze(mockCode);
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Interface Name: " + analysis.getInterfaceName());
            System.out.println("Package: " + analysis.getPackage().getName());
            System.out.println("Methods count: " + analysis.getMethods().size());
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    private static boolean hasPossibleMutatingMethods(@Nonnull final List<Method> methods) {
        for (final Method method : methods) {
            if (!method.getAttributes().isEmpty()) {
                return true;
            }
        }
        return false;
    }

    
    public static class Check {
        public static <T> T notNull(T obj, String name) {
            if (obj == null) throw new IllegalArgumentException(name + " must not be null");
            return obj;
        }
        public static <T> List<T> notEmpty(List<T> list, String name) {
            if (list == null || list.isEmpty()) throw new IllegalArgumentException(name + " must not be empty");
            return list;
        }
        public static void stateIsTrue(boolean condition, String msg, Object... args) {
            if (!condition) throw new IllegalStateException(String.format(msg, args));
        }
    }

    
    public static class CompilationUnit {
        private PackageDeclaration pkg;
        private List<ImportDeclaration> imports = new ArrayList<>();
        private List<TypeDeclaration> types = new ArrayList<>();
        public PackageDeclaration getPackage() { return pkg; }
        public void setPackage(PackageDeclaration pkg) { this.pkg = pkg; }
        public List<ImportDeclaration> getImports() { return imports; }
        public List<TypeDeclaration> getTypes() { return types; }
    }
    public static class PackageDeclaration {
        private NameExpr name;
        public NameExpr getName() { return name; }
        public void setName(NameExpr name) { this.name = name; }
    }
    public static class NameExpr {
        private String name;
        public NameExpr(String name) { this.name = name; }
        public String toString() { return name; }
    }
    public static class ImportDeclaration {
        private NameExpr name;
        public NameExpr getName() { return name; }
    }
    public static class TypeDeclaration {
        private String name;
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
    }
    public static class ClassOrInterfaceDeclaration extends TypeDeclaration {
        private List<AnnotationExpr> annotations = new ArrayList<>();
        private List<BodyDeclaration> members = new ArrayList<>();
        private List<ClassOrInterfaceType> extendsList = new ArrayList<>();
        public List<AnnotationExpr> getAnnotations() { return annotations; }
        public List<BodyDeclaration> getMembers() { return members; }
        public List<ClassOrInterfaceType> getExtends() { return extendsList; }
    }
    public static class AnnotationExpr {
        private NameExpr name;
        public NameExpr getName() { return name; }
    }
    public static class BodyDeclaration {}
    public static class MethodDeclaration extends BodyDeclaration {
        private String name;
        private ParserAstType type;
        private List<Parameter> parameters = new ArrayList<>();
        private List<AnnotationExpr> annotations = new ArrayList<>();
        public String getName() { return name; }
        public ParserAstType getType() { return type; }
        public List<Parameter> getParameters() { return parameters; }
        public List<AnnotationExpr> getAnnotations() { return annotations; }
    }
    public static class Parameter {
        private ParserAstType type;
        private VariableDeclaratorId id;
        private List<AnnotationExpr> annotations = new ArrayList<>();
        public ParserAstType getType() { return type; }
        public VariableDeclaratorId getId() { return id; }
        public List<AnnotationExpr> getAnnotations() { return annotations; }
    }
    public static class VariableDeclaratorId {
        private String name;
        public String getName() { return name; }
    }
    public static class ParserAstType {
        private final String name;
        public ParserAstType(String name) { this.name = name; }
        public String getName() { return name; }
    }
    public static class ClassOrInterfaceType extends ParserAstType {
        public ClassOrInterfaceType(String name) { super(name); }
    }

    
    public static class Package {
        public static final Package UNDEFINED = new Package("undefined");
        private String name;
        public Package(String name) { this.name = name; }
        public String getName() { return name; }
    }
    public static class Import {
        private Type type;
        public Import(Type type) { this.type = type; }
        public Type getType() { return type; }
    }
    public static class Imports {
        private List<Import> imports;
        public Imports(List<Import> imports) { this.imports = imports; }
        public List<Import> asList() { return imports; }
        public Import find(String name) { return null; }
        public static Imports copyOf(List<Import> list) { return new Imports(list); }
    }
    public static class Type {
        private String name;
        public Type(String name) { this.name = name; }
        public String getName() { return name; }
        public Package getPackage() { return Package.UNDEFINED; }
        public Object getGenericDeclaration() { return null; }
    }
    public static class Annotation {
        private Type type;
        public Annotation(Type type) { this.type = type; }
    }
    public static class Attribute {
        private String name;
        public Attribute(String name, Type type, Object fin, List<Annotation> ann) { this.name = name; }
    }
    public static class ReturnType {
        private Type type;
        public static ReturnType of(Type t) { ReturnType r = new ReturnType(); r.type = t; return r; }
    }
    public static class Method {
        private String name;
        private ReturnType returnType;
        private List<Attribute> attributes;
        public Method(String name, ReturnType returnType, List<Attribute> attributes, Object vis, Object fin, Object stat, List<Annotation> ann) {
            this.name = name; this.returnType = returnType; this.attributes = attributes;
        }
        public List<Attribute> getAttributes() { return attributes; }
    }
    public static class Interface {
        private Type type;
        public Interface(Type type) { this.type = type; }
        public static Interface of(String name) { return new Interface(new Type(name)); }
    }

    public interface InterfaceAnalysis {
        List<Annotation> getAnnotations();
        List<Interface> getExtends();
        List<Import> getImports();
        String getInterfaceName();
        List<Method> getMethods();
        Package getPackage();
    }

    public static class ImmutableInterfaceAnalysis implements InterfaceAnalysis {
        private List<Annotation> annotations;
        private List<Interface> extends1;
        private List<Import> imports;
        private String interfaceName;
        private List<Method> methods;
        private Package package1;

        public ImmutableInterfaceAnalysis(List<Annotation> annotations, List<Interface> extends1, List<Import> imports, String interfaceName, List<Method> methods, Package package1) {
            this.annotations = annotations; this.extends1 = extends1; this.imports = imports;
            this.interfaceName = interfaceName; this.methods = methods; this.package1 = package1;
        }
        public List<Annotation> getAnnotations() { return annotations; }
        public List<Interface> getExtends() { return extends1; }
        public List<Import> getImports() { return imports; }
        public String getInterfaceName() { return interfaceName; }
        public List<Method> getMethods() { return methods; }
        public Package getPackage() { return package1; }
    }

    
    public static class SourceCodeReader {
        public static CompilationUnit parse(String code) {
            CompilationUnit unit = new CompilationUnit();
            unit.setPackage(new PackageDeclaration() {{ setName(new NameExpr("com.example")); }});
            ClassOrInterfaceDeclaration type = new ClassOrInterfaceDeclaration();
            type.setName("MyInterface");
            unit.getTypes().add(type);
            return unit;
        }
        public static Imports findImports(List<ImportDeclaration> decls) { return new Imports(new ArrayList<>()); }
        public static List<Annotation> findAnnotations(List<AnnotationExpr> exprs, Imports imports) { return new ArrayList<>(); }
        public static List<Method> findMethods(List<BodyDeclaration> members, Imports imports) { return new ArrayList<>(); }
        public static List<Interface> findExtends(ClassOrInterfaceDeclaration type) { return new ArrayList<>(); }
    }
}