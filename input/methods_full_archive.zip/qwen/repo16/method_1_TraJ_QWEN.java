import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;




class Trajectory {
    private List<Point2D.Double> points = new ArrayList<>();
    public int size() { return points.size(); }
    public Point2D.Double get(int i) { return points.get(i); }
    public void add(double x, double y, double z) { points.add(new Point2D.Double(x, y)); }
    public int getDimension() { return 2; }
}

class Array2DRowRealMatrix {
    private double[][] data;
    public Array2DRowRealMatrix(double[][] data) { this.data = data; }
    public double getEntry(int row, int col) { return data[row][col]; }
}

class RealVector {
    private double[] data;
    public RealVector(double[] data) { this.data = data; }
    public double getEntry(int i) { return data[i]; }
}

class EigenDecomposition {
    public EigenDecomposition(Array2DRowRealMatrix matrix) {}
    public RealVector getEigenvector(int i) {
        return new RealVector(new double[]{1.0, 0.0}); 
    }
}

class RadiusGyrationTensor2D {
    public static Array2DRowRealMatrix getRadiusOfGyrationTensor(Trajectory t) {
        return new Array2DRowRealMatrix(new double[][]{{1.0, 0.0}, {0.0, 1.0}});
    }
}

class CenterOfGravityFeature {
    private Trajectory t;
    public CenterOfGravityFeature(Trajectory t) { this.t = t; }
    public double[] evaluate() {
        double cx = 0, cy = 0;
        for(int i = 0; i < t.size(); i++) { cx += t.get(i).x; cy += t.get(i).y; }
        return new double[]{cx / t.size(), cy / t.size()};
    }
}

class StandardDeviation {
    private double[] data;
    public void setData(double[] data) { this.data = data; }
    public double evaluate() {
        if (data == null || data.length == 0) return 0;
        double mean = 0;
        for (double v : data) mean += v;
        mean /= data.length;
        double var = 0;
        for (double v : data) var += (v - mean) * (v - mean);
        return Math.sqrt(var / data.length);
    }
}

class KeySizeException extends Exception {}
class KeyDuplicateException extends Exception {}

class KDTree<T> {
    private List<T> items = new ArrayList<>();
    public KDTree(int dim) {}
    public void insert(double[] key, T value) throws KeySizeException, KeyDuplicateException {
        items.add(value);
    }
    public List<T> nearestEuclidean(double[] center, double radius) throws KeySizeException {
        return new ArrayList<>(items); 
    }
}

class Vector2d {
    public double x, y;
    public Vector2d(double x, double y) { this.x = x; this.y = y; }
    public void normalize() {
        double len = Math.sqrt(x * x + y * y);
        if (len > 0) { x /= len; y /= len; }
    }
    public void scale(double s) { x *= s; y *= s; }
}

class SplineInterpolator {
    public PolynomialSplineFunction interpolate(double[] x, double[] y) {
        return new PolynomialSplineFunction(x, y);
    }
}

class PolynomialSplineFunction {
    private double[] knots;
    private double[] yVals;
    public PolynomialSplineFunction(double[] knots, double[] yVals) {
        this.knots = knots;
        this.yVals = yVals;
    }
    public int getN() { return Math.max(0, knots.length - 1); }
    public double[] getKnots() { return knots; }
    public double value(double x) {
        for(int i = 0; i < knots.length - 1; i++) {
            if (x >= knots[i] && x <= knots[i + 1]) {
                double t = (x - knots[i]) / (knots[i + 1] - knots[i]);
                return yVals[i] + t * (yVals[i + 1] - yVals[i]);
            }
        }
        return yVals[yVals.length - 1];
    }
}




public class method_1_TraJ_QWEN {
    private Trajectory t;
    private Trajectory rotatedTrajectory;
    private int nSegments = 5;
    private double angleRotated = 0;
    private boolean successfull = false;
    private List<Point2D.Double> splineSupportPoints;
    private PolynomialSplineFunction spline;

    public method_1_TraJ_QWEN(Trajectory t) {
        this.t = t;
        this.rotatedTrajectory = new Trajectory();
    }

    private boolean isLeft(Point2D.Double p1, Point2D.Double p2, Point2D.Double p3) {
        return ((p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x)) > 0;
    }

    private double distancePointLine(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        double num = Math.abs((p2.y - p1.y) * p.x - (p2.x - p1.x) * p.y + p2.x * p1.y - p2.y * p1.x);
        double den = Math.sqrt(Math.pow(p2.y - p1.y, 2) + Math.pow(p2.x - p1.x, 2));
        return den == 0 ? 0 : num / den;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public PolynomialSplineFunction calculateSpline(){
		
		successfull= false;
		


		ArrayList<Point2D.Double> points = new ArrayList<Point2D.Double>();
		for(int i = 0; i < t.size(); i++){
			Point2D.Double p = new Point2D.Double();
			p.setLocation(t.get(i).x, t.get(i).y);
			points.add(p);
		}
		
		


		
		Array2DRowRealMatrix gyr = RadiusGyrationTensor2D.getRadiusOfGyrationTensor(t);
		EigenDecomposition eigdec = new EigenDecomposition(gyr);
		
		double inRad = -1*Math.atan2(eigdec.getEigenvector(0).getEntry(1), eigdec.getEigenvector(0).getEntry(0));
		boolean doTransform = (Math.abs(Math.abs(inRad)-Math.PI)>0.001);
		
		if(doTransform)
		{
			angleRotated = inRad;
			for(int i = 0; i < t.size(); i++){
				double x = t.get(i).x;
				double y = t.get(i).y;
				double newX = x*Math.cos(inRad)-y*Math.sin(inRad);
				double newY = x*Math.sin(inRad)+y*Math.cos(inRad);
				rotatedTrajectory.add(newX, newY, 0);
				points.get(i).setLocation(newX, newY);
			}
		}
		else{
			angleRotated = 0;
			rotatedTrajectory = t;
		}
		
		
		


		List<List<Point2D.Double>> pointsInSegments =null;
		boolean allSegmentsContainingAtLeastTwoPoints = true;
		int indexSmallestX = 0;
		
		double segmentWidth = 0;
		do{
			double smallestX = Double.MAX_VALUE;
			double largestX = Double.MIN_VALUE;
			
			for(int i = 0; i < points.size(); i++){
				if(points.get(i).x< smallestX){
					smallestX = points.get(i).x;
					indexSmallestX = i;
				}
				if(points.get(i).x>largestX){
					largestX = points.get(i).x;
				}
			}
			
			allSegmentsContainingAtLeastTwoPoints = true;
			segmentWidth = (largestX-smallestX)/nSegments;
			pointsInSegments = new ArrayList<List<Point2D.Double>>(nSegments);
			for(int i = 0; i < nSegments; i++){
				pointsInSegments.add(new ArrayList<Point2D.Double>());
			}
			for(int i = 0; i < points.size(); i++){
	
				int index = (int)Math.abs((points.get(i).x/segmentWidth));
				
				if(index>(nSegments-1)){
					index = (nSegments-1);
				}
				pointsInSegments.get(index).add(points.get(i));
			}
			
			for(int i = 0; i < pointsInSegments.size(); i++){
				if(pointsInSegments.get(i).size()<2){
					if(nSegments>2){
						nSegments--;
						i = pointsInSegments.size();
						allSegmentsContainingAtLeastTwoPoints = false;
				
					}
				}
			}
			
		}while(allSegmentsContainingAtLeastTwoPoints==false);
		
		
		


		double sumSDOrthogonal=0;
		int Nsum = 0;
		CenterOfGravityFeature cogf = new CenterOfGravityFeature(rotatedTrajectory);
		Point2D.Double cog = new  Point2D.Double(cogf.evaluate()[0], cogf.evaluate()[1]) ;
		Point2D.Double eMajorP1 = cog;
		Point2D.Double eMajorP2 = new Point2D.Double(cog.getX()+1, cog.getY());
		for(int i = 0; i < nSegments; i++){
			StandardDeviation sd = new StandardDeviation();
			double[] distances = new double[pointsInSegments.get(i).size()];
			for(int j = 0; j < pointsInSegments.get(i).size(); j++){
				int factor = 1;
				if(isLeft(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j))){
					factor = -1;
				}
				distances[j] = factor*distancePointLine(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j));
			}
			if(distances.length >0){
				sd.setData(distances);
	
				sumSDOrthogonal += sd.evaluate();
				Nsum++;
			}
		}
		double s = sumSDOrthogonal/Nsum;
		if(segmentWidth<Math.pow(10, -15)){
			return null;
		}
		if(s<Math.pow(10, -15)){
			s=segmentWidth/2;
		}
		
		


		KDTree<Point2D.Double> kdtree = new KDTree<Point2D.Double>(2);
		
		for(int i = 0; i< points.size(); i++){
			try {
				kdtree.insert(new double[]{points.get(i).x,points.get(i).y}, points.get(i));
			} catch (KeySizeException e) {
				e.printStackTrace();
			} catch (KeyDuplicateException e) {
				
			}
		}
		
		


		List<Point2D.Double> near = null;
		
		Point2D.Double first = points.get(indexSmallestX);
		double r1 = 3*s;
		try {
			near = kdtree.nearestEuclidean(new double[]{first.x ,first.y}, r1);
		} catch (KeySizeException e) {
			e.printStackTrace();
		} 

		double cx = 0;
		double cy = 0;
		for(int i = 0; i < near.size(); i++){
			cx += near.get(i).x;
			cy += near.get(i).y;
		}
		cx /= near.size();
		cy /= near.size();

		splineSupportPoints = new ArrayList<Point2D.Double>();
		splineSupportPoints.add(new Point2D.Double(cx, cy));
		
		



		int nCircleSegments = 100;
		double deltaRad = 2*Math.PI/nCircleSegments;
		boolean stop = false;
		int minN = 7;
		double tempr1 = r1;
		double allowedDeltaDirection = 0.5*Math.PI;
				
		while(stop==false){
			List<Point2D.Double> nearestr1 = null;
			List<Point2D.Double> nearest2xr1 = null;
			try {
				nearestr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},tempr1);
				nearest2xr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},2*tempr1);
			} catch (KeySizeException e) {
				e.printStackTrace();
			}
			nearest2xr1.removeAll(nearestr1);
			
			double lThreshRad = 0;
			double hThreshRad = Math.PI/2;
			double stopThresh = 2*Math.PI;
			if(splineSupportPoints.size()>1){
				double directionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				lThreshRad = directionInRad - allowedDeltaDirection/2 - Math.PI/4; 
				if(lThreshRad<0){ lThreshRad = 2*Math.PI+lThreshRad; }
				if(lThreshRad>2*Math.PI){ lThreshRad = lThreshRad - 2*Math.PI; }
				hThreshRad = directionInRad + allowedDeltaDirection/2 + Math.PI/4; 
				if(hThreshRad<0){ hThreshRad = 2*Math.PI+hThreshRad; }
				if(hThreshRad>2*Math.PI){ hThreshRad = hThreshRad - 2*Math.PI; }
				stopThresh = directionInRad + allowedDeltaDirection/2 - Math.PI/4; 
				if(stopThresh>2*Math.PI){ stopThresh = stopThresh - 2*Math.PI; }
			}
			
			double newCx=0;
			double newCy=0;
			int newCN = 0;
			int candN = 0;
			
			double lastDist = 0;
			double newDist = 0;
			do{ 
				lastDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));
				candN=0;
				double candCx =0;
				double candCy =0;
			
				for(int i = 0; i < nearest2xr1.size(); i++){
					Point2D.Double centerOfCircle = splineSupportPoints.get(splineSupportPoints.size()-1);
					Vector2d relativeToCircle = new Vector2d(nearest2xr1.get(i).x-centerOfCircle.x,nearest2xr1.get(i).y-centerOfCircle.y);
					relativeToCircle.normalize();
					double angleInRadians = Math.atan2(relativeToCircle.y, relativeToCircle.x)+Math.PI;

					if(lThreshRad<hThreshRad){
						if(angleInRadians>lThreshRad && angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}	
					}
					else{
						if(angleInRadians>lThreshRad || angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}
					}
				}
				
				if(candN>0 && candN > newCN ){
					candCx /= candN;
					candCy /= candN;
					newCx = candCx;
					newCy = candCy;
					newCN = candN;
				}
				lThreshRad += deltaRad;
				hThreshRad += deltaRad;
				if(lThreshRad>2*Math.PI){ lThreshRad = lThreshRad - 2*Math.PI; }
				if(hThreshRad>2*Math.PI){ hThreshRad = hThreshRad - 2*Math.PI; }
				newDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));
			
			}while((newDist-lastDist)>0);
			
			if(splineSupportPoints.size()>1){
				double currentDirectionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				double candDirectionInRad = Math.atan2(newCy-splineSupportPoints.get(splineSupportPoints.size()-1).y,
						newCx-splineSupportPoints.get(splineSupportPoints.size()-1).x)+Math.PI;
				double dDir = Math.max(currentDirectionInRad, candDirectionInRad)-Math.min(currentDirectionInRad, candDirectionInRad);
				if(dDir>2*Math.PI){ dDir = 2*Math.PI-dDir; }
				if(dDir>allowedDeltaDirection){ stop = true; }
			}
			boolean enoughPoints = (newCN<minN);
			boolean isNormalRadius = Math.abs(tempr1-r1)<Math.pow(10, -18);
			boolean isExtendedRadius = Math.abs(tempr1-3*r1)<Math.pow(10, -18);
			
			if(enoughPoints&& isNormalRadius){
				tempr1 = 3*r1;
			}
			else if(enoughPoints && isExtendedRadius){
				stop = true;
			}
			else if(stop==false){
				splineSupportPoints.add(new Point2D.Double(newCx,newCy));
				tempr1 = r1;
			}
		}

		
		Collections.sort(splineSupportPoints, new Comparator<Point2D.Double>() {
			public int compare(Point2D.Double o1, Point2D.Double o2) {
				if(o1.x<o2.x) return -1;
				if(o1.x>o2.x) return 1;
				return 0;
			}
		});
		
		
		if(splineSupportPoints.size()>1){
			Vector2d start = new Vector2d(splineSupportPoints.get(0).x-splineSupportPoints.get(1).x, splineSupportPoints.get(0).y-splineSupportPoints.get(1).y);
			start.normalize();
			start.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+start.x, splineSupportPoints.get(0).y+start.y));
			
			Vector2d end = new Vector2d(splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x, 
					splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y);
			end.normalize();
			end.scale(r1*6);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+end.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+end.y));
		}
		else{
			Vector2d majordir = new Vector2d(-1, 0);
			majordir.normalize();
			majordir.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+majordir.x, splineSupportPoints.get(0).y+majordir.y));
			majordir.scale(-1);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+majordir.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+majordir.y));
		}
		
		
		double[] supX = new double[splineSupportPoints.size()];
		double[] supY = new double[splineSupportPoints.size()];
		for(int i = 0; i < splineSupportPoints.size(); i++){
			supX[i] = splineSupportPoints.get(i).x;
			supY[i] = splineSupportPoints.get(i).y;
		}
		
		SplineInterpolator sIinter = new SplineInterpolator();
		spline = sIinter.interpolate(supX, supY);
		successfull = true;
		return spline;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 1: TrajectorySplineFit.calculateSpline               ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            Trajectory mockTraj = new Trajectory();
            mockTraj.add(0, 0, 0);
            mockTraj.add(2, 1, 0);
            mockTraj.add(4, 3, 0);
            mockTraj.add(6, 2, 0);
            mockTraj.add(8, 5, 0);

            method_1_TraJ_QWEN fit = new method_1_TraJ_QWEN(mockTraj);

            System.out.println("┌─ SPLINE FITTING PROCESS ───────────────────────────────────┐");
            System.out.println("│ 1. Calculating Radius of Gyration Tensor & EigenDecomposition");
            System.out.println("│ 2. Rotating trajectory to align major axis with X-axis");
            System.out.println("│ 3. Dividing bounding rectangle into " + fit.nSegments + " segments");
            System.out.println("│ 4. Calculating mean standard deviation orthogonal to major axis");
            System.out.println("│ 5. Building KD-Tree for nearest-neighbor queries");
            System.out.println("│ 6. Iteratively finding center-of-mass in annular sectors...");
            System.out.println("│ 7. Sorting support points and extrapolating endpoints");
            System.out.println("│ 8. Interpolating final PolynomialSplineFunction");
            
            PolynomialSplineFunction result = fit.calculateSpline();
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");

            System.out.println("┌─ SPLINE FITTING RESULT ────────────────────────────────────┐");
            System.out.println("│ ✓ Success: " + fit.successfull);
            System.out.println("│ ✓ Rotation Angle Applied: " + fit.angleRotated + " rad");
            System.out.println("│ ✓ Support Points Generated: " + fit.splineSupportPoints.size());
            System.out.println("│ ✓ Spline Segments (N): " + result.getN());
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}