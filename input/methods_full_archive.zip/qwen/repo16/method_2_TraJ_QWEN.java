import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EmptyStackException;
import java.util.List;




class TrajectoryLegacy {
    private List<Point2D.Double> points = new ArrayList<>();
    public int size() { return points.size(); }
    public Point2D.Double get(int i) { return points.get(i); }
    public void add(double x, double y, double z) { points.add(new Point2D.Double(x, y)); }
}

class StandardDeviationLegacy {
    private double[] data;
    public void setData(double[] data) { this.data = data; }
    public double evaluate() {
        if (data == null || data.length == 0) return 0;
        double mean = 0;
        for (double v : data) mean += v;
        mean /= data.length;
        double var = 0;
        for (double v : data) var += (v - mean) * (v - mean);
        return Math.sqrt(var / data.length);
    }
}

class KeySizeExceptionLegacy extends Exception {}
class KeyDuplicateExceptionLegacy extends Exception {}

class KDTreeLegacy<T> {
    private List<T> items = new ArrayList<>();
    public KDTreeLegacy(int dim) {}
    public void insert(double[] key, T value) throws KeySizeExceptionLegacy, KeyDuplicateExceptionLegacy {
        items.add(value);
    }
    public List<T> nearestEuclidean(double[] center, double radius) throws KeySizeExceptionLegacy {
        return new ArrayList<>(items);
    }
}

class Vector2dLegacy {
    public double x, y;
    public Vector2dLegacy(double x, double y) { this.x = x; this.y = y; }
    public void normalize() {
        double len = Math.sqrt(x * x + y * y);
        if (len > 0) { x /= len; y /= len; }
    }
    public void scale(double s) { x *= s; y *= s; }
}

class SplineInterpolatorLegacy {
    public PolynomialSplineFunctionLegacy interpolate(double[] x, double[] y) {
        return new PolynomialSplineFunctionLegacy(x, y);
    }
}

class PolynomialSplineFunctionLegacy {
    private double[] knots;
    private double[] yVals;
    public PolynomialSplineFunctionLegacy(double[] knots, double[] yVals) {
        this.knots = knots; this.yVals = yVals;
    }
    public int getN() { return Math.max(0, knots.length - 1); }
    public double[] getKnots() { return knots; }
    public double value(double x) {
        for(int i = 0; i < knots.length - 1; i++) {
            if (x >= knots[i] && x <= knots[i + 1]) {
                double t = (x - knots[i]) / (knots[i + 1] - knots[i]);
                return yVals[i] + t * (yVals[i + 1] - yVals[i]);
            }
        }
        return yVals[yVals.length - 1];
    }
}

class RotatingCalipers {
    public static Point2D.Double[] getMinimumBoundingRectangle(List<Point2D.Double> points) {
        
        return new Point2D.Double[]{
            new Point2D.Double(0, 0),
            new Point2D.Double(10, 0),
            new Point2D.Double(10, 10),
            new Point2D.Double(0, 10)
        };
    }
}




public class method_2_TraJ_QWEN {
    private TrajectoryLegacy t;
    private TrajectoryLegacy rotatedTrajectory;
    private int nSegments = 5;
    private double angleRotated = 0;
    private List<Point2D.Double> splineSupportPoints;
    private PolynomialSplineFunctionLegacy spline;

    public method_2_TraJ_QWEN(TrajectoryLegacy t) {
        this.t = t;
        this.rotatedTrajectory = new TrajectoryLegacy();
    }

    private boolean isLeft(Point2D.Double p1, Point2D.Double p2, Point2D.Double p3) {
        return ((p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x)) > 0;
    }

    private double distancePointLine(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        double num = Math.abs((p2.y - p1.y) * p.x - (p2.x - p1.x) * p.y + p2.x * p1.y - p2.y * p1.x);
        double den = Math.sqrt(Math.pow(p2.y - p1.y, 2) + Math.pow(p2.x - p1.x, 2));
        return den == 0 ? 0 : num / den;
    }

    private Point2D.Double projectPointToLine(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        double dx = p2.x - p1.x;
        double dy = p2.y - p1.y;
        double t = ((p.x - p1.x) * dx + (p.y - p1.y) * dy) / (dx * dx + dy * dy);
        return new Point2D.Double(p1.x + t * dx, p1.y + t * dy);
    }

    private Point2D.Double minDistancePointToLine(Point2D.Double p1, Point2D.Double p2, List<Point2D.Double> points) {
        Point2D.Double minP = points.get(0);
        double minDist = Double.MAX_VALUE;
        for (Point2D.Double p : points) {
            double d = distancePointLine(p1, p2, p);
            if (d < minDist) { minDist = d; minP = p; }
        }
        return minP;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public PolynomialSplineFunctionLegacy calculateSpline(){
		
		


		ArrayList<Point2D.Double> points = new ArrayList<Point2D.Double>();
		for(int i = 0; i < t.size(); i++){
			Point2D.Double p = new Point2D.Double();
			p.setLocation(t.get(i).x, t.get(i).y);
			points.add(p);
		}
		Point2D.Double[] rect = null;
		try{
			rect = RotatingCalipers.getMinimumBoundingRectangle(points);
		}
		catch(IllegalArgumentException e) {}
		catch(EmptyStackException e){}
		
		


		
		Point2D.Double majorDirection = null;
		
		Point2D.Double p1 = rect[2]; 
		Point2D.Double p2 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[1] : rect[3]; 
		Point2D.Double p3 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[3] : rect[1]; 
		majorDirection = new Point2D.Double(p2.x-p1.x, p2.y-p1.y);
		double width = p1.distance(p2);
		double inRad = -1*Math.atan2(majorDirection.y, majorDirection.x);

		boolean doTransform = (Math.abs(Math.abs(inRad)-Math.PI)>0.001);

		if(doTransform)
		{
			angleRotated = inRad;
			for(int i = 0; i < t.size(); i++){
				double x = t.get(i).x;
				double y = t.get(i).y;
				double newX = x*Math.cos(inRad)-y*Math.sin(inRad);
				double newY = x*Math.sin(inRad)+y*Math.cos(inRad);
				rotatedTrajectory.add(newX, newY, 0);
				points.get(i).setLocation(newX, newY);
			}
			for(int i = 0; i < rect.length; i++){
				rect[i].setLocation(rect[i].x*Math.cos(inRad)-rect[i].y*Math.sin(inRad), rect[i].x*Math.sin(inRad)+rect[i].y*Math.cos(inRad));
			}

			p1 = rect[2]; 
			p2 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[1] : rect[3]; 
			p3 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[3] : rect[1]; 
		}
		else{
			angleRotated = 0;
			rotatedTrajectory = t;
		}
		
		


		List<List<Point2D.Double>> pointsInSegments =null;
		boolean allSegmentsContainingAtLeastTwoPoints = true;
		do{
			
			allSegmentsContainingAtLeastTwoPoints = true;
			double segmentWidth = p1.distance(p2)/nSegments;
			pointsInSegments = new ArrayList<List<Point2D.Double>>(nSegments);
			for(int i = 0; i < nSegments; i++){
				pointsInSegments.add(new ArrayList<Point2D.Double>());
			}
			for(int i = 0; i < points.size(); i++){
				Point2D.Double projPoint  = projectPointToLine(p1, p2, points.get(i));
				int index = (int)(p1.distance(projPoint)/segmentWidth);
				
				if(index>(nSegments-1)){
					index = (nSegments-1);
				}
				pointsInSegments.get(index).add(points.get(i));
			}
			
			for(int i = 0; i < pointsInSegments.size(); i++){
				if(pointsInSegments.get(i).size()<2){
					if(nSegments>2){
						nSegments--;
						i = pointsInSegments.size();
						allSegmentsContainingAtLeastTwoPoints = false;
				
					}
				}
			}
		}while(allSegmentsContainingAtLeastTwoPoints==false);
		
		
		


		
		Point2D.Double eMajorP1 = new Point2D.Double(p1.x - (p3.x-p1.x)/2.0,p1.y - (p3.y-p1.y)/2.0); 
		Point2D.Double eMajorP2 = new Point2D.Double(p2.x - (p3.x-p1.x)/2.0,p2.y - (p3.y-p1.y)/2.0); 
		double sumMean=0;
		int Nsum = 0;
		for(int i = 0; i < nSegments; i++){
			StandardDeviationLegacy sd = new StandardDeviationLegacy();
			double[] distances = new double[pointsInSegments.get(i).size()];
			for(int j = 0; j < pointsInSegments.get(i).size(); j++){
				int factor = 1;
				if(isLeft(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j))){
					factor = -1;
				}
				distances[j] = factor*distancePointLine(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j));
			}
			if(distances.length >0){
				sd.setData(distances);
	
				sumMean += sd.evaluate();
			
				Nsum++;
			}
		}
		double s = sumMean/Nsum;
		if(s<0.000000000001){
			s = width/nSegments;
		}
	
		


		KDTreeLegacy<Point2D.Double> kdtree = new KDTreeLegacy<Point2D.Double>(2);
		
		for(int i = 0; i< points.size(); i++){
			try {
				kdtree.insert(new double[]{points.get(i).x,points.get(i).y}, points.get(i));
			} catch (KeySizeExceptionLegacy e) {
				e.printStackTrace();
			} catch (KeyDuplicateExceptionLegacy e) {
				
			}
		}
		
		


		List<Point2D.Double> near = null;
		
		Point2D.Double first = minDistancePointToLine(p1, p3, points);
		double r1 = 3*s;
		try {
			near = kdtree.nearestEuclidean(new double[]{first.x ,first.y}, r1);
		} catch (KeySizeExceptionLegacy e) {
			e.printStackTrace();
		} 

		double cx = 0;
		double cy = 0;
		for(int i = 0; i < near.size(); i++){
			cx += near.get(i).x;
			cy += near.get(i).y;
		}
		cx /= near.size();
		cy /= near.size();

		splineSupportPoints = new ArrayList<Point2D.Double>();
		splineSupportPoints.add(new Point2D.Double(cx, cy));
		
		



		int nCircleSegments = 100;
		double deltaRad = 2*Math.PI/nCircleSegments;
		boolean stop = false;
		int minN = 7;
		double tempr1 = r1;
		double allowedDeltaDirection = 0.5*Math.PI;
				
		while(stop==false){
			List<Point2D.Double> nearestr1 = null;
			List<Point2D.Double> nearest2xr1 = null;
			try {
				nearestr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},tempr1);
				nearest2xr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},2*tempr1);
			} catch (KeySizeExceptionLegacy e) {
				e.printStackTrace();
			}
			nearest2xr1.removeAll(nearestr1);
			
			double lThreshRad = 0;
			double hThreshRad = Math.PI/2;
			double stopThresh = 2*Math.PI;
			if(splineSupportPoints.size()>1){
				double directionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				lThreshRad = directionInRad - allowedDeltaDirection/2 - Math.PI/4; 
				if(lThreshRad<0){ lThreshRad = 2*Math.PI+lThreshRad; }
				if(lThreshRad>2*Math.PI){ lThreshRad = lThreshRad - 2*Math.PI; }
				hThreshRad = directionInRad + allowedDeltaDirection/2 + Math.PI/4; 
				if(hThreshRad<0){ hThreshRad = 2*Math.PI+hThreshRad; }
				if(hThreshRad>2*Math.PI){ hThreshRad = hThreshRad - 2*Math.PI; }
				stopThresh = directionInRad + allowedDeltaDirection/2 - Math.PI/4; 
				if(stopThresh>2*Math.PI){ stopThresh = stopThresh - 2*Math.PI; }
			}
			
			double newCx=0;
			double newCy=0;
			int newCN = 0;
			int candN = 0;
			
			double lastDist = 0;
			double newDist = 0;
			do{ 
				lastDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));
				candN=0;
				double candCx =0;
				double candCy =0;
			
				for(int i = 0; i < nearest2xr1.size(); i++){
					Point2D.Double centerOfCircle = splineSupportPoints.get(splineSupportPoints.size()-1);
					Vector2dLegacy relativeToCircle = new Vector2dLegacy(nearest2xr1.get(i).x-centerOfCircle.x,nearest2xr1.get(i).y-centerOfCircle.y);
					relativeToCircle.normalize();
					double angleInRadians = Math.atan2(relativeToCircle.y, relativeToCircle.x)+Math.PI;

					if(lThreshRad<hThreshRad){
						if(angleInRadians>lThreshRad && angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}	
					}
					else{
						if(angleInRadians>lThreshRad || angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}
					}
				}
				
				if(candN>0 && candN > newCN ){
					candCx /= candN;
					candCy /= candN;
					newCx = candCx;
					newCy = candCy;
					newCN = candN;
				}
				lThreshRad += deltaRad;
				hThreshRad += deltaRad;
				if(lThreshRad>2*Math.PI){ lThreshRad = lThreshRad - 2*Math.PI; }
				if(hThreshRad>2*Math.PI){ hThreshRad = hThreshRad - 2*Math.PI; }
				newDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));
			
			}while((newDist-lastDist)>0);
			
			if(splineSupportPoints.size()>1){
				double currentDirectionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				double candDirectionInRad = Math.atan2(newCy-splineSupportPoints.get(splineSupportPoints.size()-1).y,
						newCx-splineSupportPoints.get(splineSupportPoints.size()-1).x)+Math.PI;
				double dDir = Math.max(currentDirectionInRad, candDirectionInRad)-Math.min(currentDirectionInRad, candDirectionInRad);
				if(dDir>2*Math.PI){ dDir = 2*Math.PI-dDir; }
				if(dDir>allowedDeltaDirection){ stop = true; }
			}
			boolean enoughPoints = (newCN<minN);
			boolean isNormalRadius = Math.abs(tempr1-r1)<Math.pow(10, -18);
			boolean isExtendedRadius = Math.abs(tempr1-3*r1)<Math.pow(10, -18);
			
			if(enoughPoints&& isNormalRadius){
				tempr1 = 3*r1;
			}
			else if(enoughPoints && isExtendedRadius){
				stop = true;
			}
			else if(stop==false){
				splineSupportPoints.add(new Point2D.Double(newCx,newCy));
				tempr1 = r1;
			}
		}

		
		Collections.sort(splineSupportPoints, new Comparator<Point2D.Double>() {
			public int compare(Point2D.Double o1, Point2D.Double o2) {
				if(o1.x<o2.x) return -1;
				if(o1.x>o2.x) return 1;
				return 0;
			}
		});
		
		
		if(splineSupportPoints.size()>1){
			Vector2dLegacy start = new Vector2dLegacy(splineSupportPoints.get(0).x-splineSupportPoints.get(1).x, splineSupportPoints.get(0).y-splineSupportPoints.get(1).y);
			start.normalize();
			start.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+start.x, splineSupportPoints.get(0).y+start.y));
			
			Vector2dLegacy end = new Vector2dLegacy(splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x, 
					splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y);
			end.normalize();
			end.scale(r1*6);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+end.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+end.y));
		}
		else{
			Vector2dLegacy majordir = new Vector2dLegacy(-1, 0);
			majordir.normalize();
			majordir.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+majordir.x, splineSupportPoints.get(0).y+majordir.y));
			majordir.scale(-1);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+majordir.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+majordir.y));
		}
		
		
		double[] supX = new double[splineSupportPoints.size()];
		double[] supY = new double[splineSupportPoints.size()];
		for(int i = 0; i < splineSupportPoints.size(); i++){
			supX[i] = splineSupportPoints.get(i).x;
			supY[i] = splineSupportPoints.get(i).y;
		}
		
		SplineInterpolatorLegacy sIinter = new SplineInterpolatorLegacy();
		spline = sIinter.interpolate(supX, supY);
		
		return spline;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 2: TrajectorySplineFitLegacy.calculateSpline         ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            TrajectoryLegacy mockTraj = new TrajectoryLegacy();
            mockTraj.add(0, 0, 0);
            mockTraj.add(2, 1, 0);
            mockTraj.add(4, 3, 0);
            mockTraj.add(6, 2, 0);
            mockTraj.add(8, 5, 0);

            method_2_TraJ_QWEN fit = new method_2_TraJ_QWEN(mockTraj);

            System.out.println("┌─ LEGACY SPLINE FITTING PROCESS ────────────────────────────┐");
            System.out.println("│ 1. Calculating Minimum Bounding Rectangle via Rotating Calipers");
            System.out.println("│ 2. Rotating trajectory to align major axis with X-axis");
            System.out.println("│ 3. Projecting points onto major axis and segmenting");
            System.out.println("│ 4. Calculating mean standard deviation orthogonal to major axis");
            System.out.println("│ 5. Building KD-Tree for nearest-neighbor queries");
            System.out.println("│ 6. Iteratively finding center-of-mass in annular sectors...");
            System.out.println("│ 7. Sorting support points and extrapolating endpoints");
            System.out.println("│ 8. Interpolating final PolynomialSplineFunction");
            
            PolynomialSplineFunctionLegacy result = fit.calculateSpline();
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");

            System.out.println("┌─ SPLINE FITTING RESULT ────────────────────────────────────┐");
            System.out.println("│ ✓ Rotation Angle Applied: " + fit.angleRotated + " rad");
            System.out.println("│ ✓ Support Points Generated: " + fit.splineSupportPoints.size());
            System.out.println("│ ✓ Spline Segments (N): " + result.getN());
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}