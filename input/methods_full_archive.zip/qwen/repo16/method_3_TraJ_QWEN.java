import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;




enum SeriesLineStyle { NONE, DASH_DASH, SOLID }
enum SeriesType { Line, Scatter }
enum SeriesMarker { NONE, CIRCLE }

class Series {
    public void setLineStyle(SeriesLineStyle style) {}
    public void setSeriesType(SeriesType type) {}
    public void setMarker(SeriesMarker marker) {}
}

class Chart {
    public Series addSeries(String name, double[] x, double[] y) { 
        System.out.println("      → Added series: '" + name + "' with " + x.length + " points");
        return new Series(); 
    }
}

class QuickChart {
    public static Chart getChart(String title, String xTitle, String yTitle, String seriesName, double[] x, double[] y) {
        System.out.println("  [INFO] Created chart: '" + title + "'");
        return new Chart();
    }
}

class SwingWrapper {
    private Chart chart;
    public SwingWrapper(Chart chart) { this.chart = chart; }
    public void displayChart() { 
        System.out.println("  [INFO] SwingWrapper.displayChart() invoked (UI rendering stubbed)."); 
    }
}




class TrajectoryShow {
    private List<Point2D.Double> points = new ArrayList<>();
    public int size() { return points.size(); }
    public Point2D.Double get(int i) { return points.get(i); }
    public void add(double x, double y, double z) { points.add(new Point2D.Double(x, y)); }
    public int getDimension() { return 2; }
}

class PolynomialSplineFunctionShow {
    private double[] knots;
    private double[] yVals;
    public PolynomialSplineFunctionShow(double[] knots, double[] yVals) {
        this.knots = knots; this.yVals = yVals;
    }
    public int getN() { return Math.max(0, knots.length - 1); }
    public double[] getKnots() { return knots; }
    public double value(double x) {
        for(int i = 0; i < knots.length - 1; i++) {
            if (x >= knots[i] && x <= knots[i + 1]) {
                double t = (x - knots[i]) / (knots[i + 1] - knots[i]);
                return yVals[i] + t * (yVals[i + 1] - yVals[i]);
            }
        }
        return yVals[yVals.length - 1];
    }
}




public class method_3_TraJ_QWEN {
    private TrajectoryShow t;
    private TrajectoryShow rotatedTrajectory;
    private List<Point2D.Double> splineSupportPoints;
    private PolynomialSplineFunctionShow spline;

    public method_3_TraJ_QWEN(TrajectoryShow t, TrajectoryShow rotatedTrajectory, 
                                                List<Point2D.Double> splineSupportPoints, PolynomialSplineFunctionShow spline) {
        this.t = t;
        this.rotatedTrajectory = rotatedTrajectory;
        this.splineSupportPoints = splineSupportPoints;
        this.spline = spline;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public void showTrajectoryAndSpline(){
		
		if(t.getDimension()==2){
		 	double[] xData = new double[rotatedTrajectory.size()];
		    double[] yData = new double[rotatedTrajectory.size()];
		    for(int i = 0; i < rotatedTrajectory.size(); i++){
		    	xData[i] = rotatedTrajectory.get(i).x;
		    	yData[i] = rotatedTrajectory.get(i).y;		    	
		    }
		    
		    Chart chart = QuickChart.getChart("Spline+Track", "X", "Y", "y(x)", xData, yData);
		    
		    
		    double[] subxData  = new double[splineSupportPoints.size()];
		    double[] subyData  = new double[splineSupportPoints.size()];
		    
		    for(int i = 0; i < splineSupportPoints.size(); i++){
		    	subxData[i] = splineSupportPoints.get(i).x;
		    	subyData[i] = splineSupportPoints.get(i).y;
		    }
		    Series s = chart.addSeries("Spline Support Points", subxData, subyData);
		    s.setLineStyle(SeriesLineStyle.NONE);
		    s.setSeriesType(SeriesType.Line);
		    
		    
		    int numberInterpolatedPointsPerSegment = 20;
		    int numberOfSplines = spline.getN();
		    double[] sxData = new double[numberInterpolatedPointsPerSegment*numberOfSplines];
		    
		    double[] syData = new double[numberInterpolatedPointsPerSegment*numberOfSplines];
		    double[] knots = spline.getKnots();
		    for(int i = 0; i < numberOfSplines; i++){
		    	double x = knots[i];
		   
		    	double stopx = knots[i+1];
		    	double dx = (stopx-x)/numberInterpolatedPointsPerSegment;
		    	
		    	for(int j = 0; j < numberInterpolatedPointsPerSegment; j++){

		    		sxData[i*numberInterpolatedPointsPerSegment+j] = x;
		    		syData[i*numberInterpolatedPointsPerSegment+j] = spline.value(x);
		    		x += dx;
		    	}
		    	
		    }
		    s = chart.addSeries("Spline", sxData, syData);
		    s.setLineStyle(SeriesLineStyle.DASH_DASH);
		    s.setMarker(SeriesMarker.NONE);
		    s.setSeriesType(SeriesType.Line);
		 
		    
		    
		    new SwingWrapper(chart).displayChart();
		} 
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 3: TrajectorySplineFit.showTrajectoryAndSpline       ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            TrajectoryShow mockTraj = new TrajectoryShow();
            mockTraj.add(0, 0, 0);
            mockTraj.add(2, 1, 0);
            mockTraj.add(4, 3, 0);
            
            TrajectoryShow mockRotated = new TrajectoryShow();
            mockRotated.add(0, 0, 0);
            mockRotated.add(2, 1, 0);
            mockRotated.add(4, 3, 0);

            List<Point2D.Double> supportPoints = new ArrayList<>();
            supportPoints.add(new Point2D.Double(0, 0));
            supportPoints.add(new Point2D.Double(2, 1));
            supportPoints.add(new Point2D.Double(4, 3));

            double[] knots = {0.0, 2.0, 4.0};
            double[] yVals = {0.0, 1.0, 3.0};
            PolynomialSplineFunctionShow mockSpline = new PolynomialSplineFunctionShow(knots, yVals);

            method_3_TraJ_QWEN visualizer = new method_3_TraJ_QWEN(
                mockTraj, mockRotated, supportPoints, mockSpline
            );

            System.out.println("┌─ CHART GENERATION PROCESS ─────────────────────────────────┐");
            visualizer.showTrajectoryAndSpline();
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");

            System.out.println("┌─ VISUALIZATION RESULT ─────────────────────────────────────┐");
            System.out.println("│ ✓ Trajectory dimension verified as 2D");
            System.out.println("│ ✓ Original track data extracted (" + mockRotated.size() + " points)");
            System.out.println("│ ✓ Spline support points extracted (" + supportPoints.size() + " points)");
            System.out.println("│ ✓ Spline interpolated at " + (20 * mockSpline.getN()) + " points across " + mockSpline.getN() + " segments");
            System.out.println("│ ✓ Chart series configured (LineStyle: DASH_DASH, Marker: NONE)");
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}