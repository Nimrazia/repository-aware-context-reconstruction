import java.io.Reader;
import java.io.StringReader;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

interface TokenCollectionCreator {
    method_2_mtas_QWEN.MtasTokenCollection createTokenCollection(Reader reader)
        throws method_2_mtas_QWEN.MtasParserException,
               method_2_mtas_QWEN.MtasConfigException;
}

public class method_2_mtas_QWEN implements TokenCollectionCreator {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Override
    public MtasTokenCollection createTokenCollection(Reader reader)
        throws MtasParserException, MtasConfigException {
      Boolean hasRoot = rootTag == null ? true : false;
      Boolean parsingContent = contentTag == null ? true : false;
      String textContent = null;
      Integer unknownAncestors = 0;
      Integer lastOffset = 0;

      AtomicInteger position = new AtomicInteger(0);
      Map<String, Set<Integer>> idPositions = new HashMap<>();
      Map<String, Integer[]> idOffsets = new HashMap<>();

      Map<String, Map<Integer, Set<String>>> updateList = createUpdateList();
      Map<String, List<MtasParserObject>> currentList = createCurrentList();
      Map<String, Map<String, String>> variables = createVariables();

      tokenCollection = new MtasTokenCollection();
      MtasTokenIdFactory mtasTokenIdFactory = new MtasTokenIdFactory();
      XMLInputFactory factory = XMLInputFactory.newInstance();
      try {      
        XMLStreamReader streamReader = factory.createXMLStreamReader(reader);
        QName qname;
        try {
          int event = streamReader.getEventType();
          MtasParserType<?> currentType;
          MtasParserType<?> tmpCurrentType;
          MtasParserType<?> tmpVariableType;
          MtasParserObject currentObject = null;
          MtasParserObject variableObject = null;
          while (true) {
            switch (event) {
            case XMLStreamConstants.START_DOCUMENT:
              log.debug("start of document");
              String encodingScheme = streamReader.getCharacterEncodingScheme();
              if (encodingScheme == null) {
                
                log.info("No encodingScheme found, assume utf-8");
                
              } else if (!encodingScheme.equalsIgnoreCase("utf-8")) {
                throw new MtasParserException(
                    "XML not UTF-8 encoded but '" + encodingScheme + "'");
              }
              break;
            case XMLStreamConstants.END_DOCUMENT:
              log.debug("end of document");
              break;
            case XMLStreamConstants.SPACE:
              
              lastOffset = streamReader.getLocation().getCharacterOffset();
              break;
            case XMLStreamConstants.START_ELEMENT:
              
              qname = streamReader.getName();
              
              if (!hasRoot) {
                if (qname.equals(getQName(rootTag))) {
                  hasRoot = true;
                } else {
                  throw new MtasParserException("No " + rootTag);
                }
                
              } else {
                if ((tmpVariableType = variableTypes.get(qname)) != null) {
                  variableObject = new MtasParserObject(tmpVariableType);
                  collectAttributes(variableObject, streamReader);
                  computeVariablesFromObject(variableObject, currentList,
                      variables);
                }
                if (parsingContent) {
                  
                  
                  if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty())
                      && (tmpCurrentType = relationTypes.get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_RELATION).add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (!currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (tmpCurrentType = relationAnnotationTypes
                          .get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                          .add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty())
                      && (tmpCurrentType = groupTypes.get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_GROUP).add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (!currentList.get(MAPPING_TYPE_GROUP).isEmpty())
                      && (tmpCurrentType = groupAnnotationTypes
                          .get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty())
                      && (currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (currentList.get(MAPPING_TYPE_WORD_ANNOTATION).isEmpty())
                      && (tmpCurrentType = wordTypes.get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setOffsetStart(lastOffset);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentObject.addPosition(position.getAndIncrement());
                      currentList.get(MAPPING_TYPE_WORD).add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty())
                      && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (tmpCurrentType = wordAnnotationTypes
                          .get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.addPositions(currentList.get(MAPPING_TYPE_WORD)
                        .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                        .getPositions());
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                          .add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                  } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()
                      && (tmpCurrentType = refTypes.get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_REF).add(currentObject);
                      unknownAncestors = 0;
                      
                      for (MtasParserObject currentRelation : currentList
                          .get(MAPPING_TYPE_RELATION)) {
                        currentRelation.addRefId(currentObject
                            .getAttribute(currentType.getRefAttributeName()));
                        
                        SortedSet<String> keyMapList;
                        if (currentRelation.getId() != null) {
                          if (relationKeyMap
                              .containsKey(currentRelation.getId())) {
                            keyMapList = relationKeyMap
                                .get(currentRelation.getId());
                          } else {
                            keyMapList = new TreeSet<>();
                            relationKeyMap.put(currentRelation.getId(),
                                keyMapList);
                          }
                          keyMapList.add(currentObject
                              .getAttribute(currentType.getRefAttributeName()));
                        }
                      }
                    }
                  } else {
                    unknownAncestors++;
                  }
                  
                } else if (qname.equals(getQName(contentTag))) {
                  parsingContent = true;
                  
                } else if (!allowNonContent) {
                  throw new MtasParserException(
                      "Unexpected " + qname.getLocalPart() + " in document");
                }
              }
              
              lastOffset = streamReader.getLocation().getCharacterOffset();
              break;
            case XMLStreamConstants.END_ELEMENT:
              
              lastOffset = streamReader.getLocation().getCharacterOffset();
              
              qname = streamReader.getName();
              
              if (parsingContent) {
                if (unknownAncestors > 0) {
                  unknownAncestors--;
                  
                  
                } else if (!currentList.get(MAPPING_TYPE_REF).isEmpty()) {
                  if ((currentType = refTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_REF)
                        .remove(currentList.get(MAPPING_TYPE_REF).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                  
                } else if (!currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                    .isEmpty()) {
                  if ((currentType = wordAnnotationTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                        .remove(
                            currentList.get(MAPPING_TYPE_WORD_ANNOTATION).size()
                                - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    
                    
                    if ((currentObject.getId() != null)
                        && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())) {
                      currentList.get(MAPPING_TYPE_WORD)
                          .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                          .addUpdateableIdWithOffset(currentObject.getId());
                    }
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                  
                } else if (!currentList.get(MAPPING_TYPE_WORD).isEmpty()) {
                  if ((currentType = wordTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_WORD)
                        .remove(currentList.get(MAPPING_TYPE_WORD).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    currentObject.setOffsetEnd(lastOffset);
                    currentObject.setRealOffsetEnd(lastOffset);
                    
                    for (MtasParserObject currentGroup : currentList
                        .get(MAPPING_TYPE_GROUP)) {
                      currentGroup.addPositions(currentObject.getPositions());
                      currentGroup.addOffsetStart(currentObject.getOffsetStart());
                      currentGroup.addOffsetEnd(currentObject.getOffsetEnd());
                    }
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                  
                } else if (!currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                    .isEmpty()) {
                  if ((currentType = groupAnnotationTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .remove(
                            currentList.get(MAPPING_TYPE_GROUP_ANNOTATION).size()
                                - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                } else if (!currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                    .isEmpty()) {
                  if ((currentType = relationAnnotationTypes
                      .get(qname)) != null) {
                    currentObject = currentList
                        .get(MAPPING_TYPE_RELATION_ANNOTATION).remove(currentList
                            .get(MAPPING_TYPE_RELATION_ANNOTATION).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()) {
                  if ((currentType = relationTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_RELATION).remove(
                        currentList.get(MAPPING_TYPE_RELATION).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                } else if (!currentList.get(MAPPING_TYPE_GROUP).isEmpty()) {
                  if ((currentType = groupTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_GROUP)
                        .remove(currentList.get(MAPPING_TYPE_GROUP).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    unknownAncestors--;
                  }
                } else if (qname.equals(getQName("text"))) {
                  parsingContent = false;
                  assert unknownAncestors == 0 : "error in administration unknownAncestors";
                  assert currentList.get(MAPPING_TYPE_REF)
                      .isEmpty() : "error in administration references";
                  assert currentList.get(MAPPING_TYPE_GROUP)
                      .isEmpty() : "error in administration groups";
                  assert currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                      .isEmpty() : "error in administration groupAnnotations";
                  assert currentList.get(MAPPING_TYPE_WORD)
                      .isEmpty() : "error in administration words";
                  assert currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                      .isEmpty() : "error in administration wordAnnotations";
                  assert currentList.get(MAPPING_TYPE_RELATION)
                      .isEmpty() : "error in administration relations";
                  assert currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                      .isEmpty() : "error in administration relationAnnotations";
                }
              }
              
              textContent = null;
              break;
            case XMLStreamConstants.CHARACTERS:
              
              lastOffset = streamReader.getLocation().getCharacterOffset();
              
              if (streamReader.hasText()) {
                textContent = streamReader.getText();
              }
              if (currentObject != null && unknownAncestors.equals(0)) {
                currentObject.addText(textContent);
              }
              break;
            default:
              break;
            }
            if (!streamReader.hasNext()) {
              break;
            }
            event = streamReader.next();
          }
        } finally {
          streamReader.close();
        }
        
        assert unknownAncestors == 0 : "error in administration unknownAncestors";
        assert hasRoot : "no " + rootTag;
      } catch (XMLStreamException e) {
        log.debug(e);      
        throw new MtasParserException("No valid XML: " + e.getMessage());
      }

      
      for (Entry<Integer, Set<String>> updateItem : updateList
          .get(UPDATE_TYPE_VARIABLE).entrySet()) {
        MtasToken token = tokenCollection.get(updateItem.getKey());
        String encodedPrefix = token.getPrefix();
        String encodedPostfix = token.getPostfix();
        token.setValue(decodeAndUpdateWithVariables(encodedPrefix, encodedPostfix,
            variables));
      }
      
      for (Entry<Integer, Set<String>> updateItem : updateList
          .get(UPDATE_TYPE_OFFSET).entrySet()) {
        Set<String> refIdList = new HashSet<>();
        for (String refId : updateItem.getValue()) {
          if (idPositions.containsKey(refId)) {
            refIdList.add(refId);
          }
          if (relationKeyMap.containsKey(refId)) {
            refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
          }
        }
        for (String refId : refIdList) {
          Integer[] refOffset = idOffsets.get(refId);
          Integer tokenId = updateItem.getKey();
          if (tokenId != null && refOffset != null) {
            MtasToken token = tokenCollection.get(tokenId);
            token.addOffset(refOffset[0], refOffset[1]);
          }
        }
      }
      
      for (Entry<Integer, Set<String>> updateItem : updateList
          .get(UPDATE_TYPE_POSITION).entrySet()) {
        HashSet<String> refIdList = new HashSet<>();
        for (String refId : updateItem.getValue()) {
          if (idPositions.containsKey(refId)) {
            refIdList.add(refId);
          }
          if (relationKeyMap.containsKey(refId)) {
            refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
          }
        }
        for (String refId : refIdList) {
          Set<Integer> refPositions = idPositions.get(refId);
          Integer tokenId = updateItem.getKey();
          if (tokenId != null && refPositions != null) {
            MtasToken token = tokenCollection.get(tokenId);
            token.addPositions(refPositions);
          }
        }
      }
      
      tokenCollection.check(autorepair, makeunique);
      return tokenCollection;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    
    
    public static void main(String[] args) {
        System.out.println("=== MTAS XML Parser Reconstruction Test ===");
        method_2_mtas_QWEN parser = new method_2_mtas_QWEN();
        parser.rootTag = "document";
        parser.contentTag = "content";
        parser.allowNonContent = true;
        parser.autorepair = false;
        parser.makeunique = true;
        
        String mockXml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><document><content><word id=\"w1\">hello</word></content></document>";
        Reader reader = new StringReader(mockXml);
        
        try {
            System.out.println("Invoking createTokenCollection...");
            MtasTokenCollection result = parser.createTokenCollection(reader);
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Token collection created successfully.");
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    static Log log = new Log();
    String rootTag;
    String contentTag;
    boolean allowNonContent;
    boolean autorepair;
    boolean makeunique;
    Map<String, SortedSet<String>> relationKeyMap = new HashMap<>();
    Map<String, QName> qNames = new HashMap<>();
    Map<QName, MtasParserType<?>> relationTypes = new HashMap<>();
    Map<QName, MtasParserType<?>> relationAnnotationTypes = new HashMap<>();
    Map<QName, MtasParserType<?>> refTypes = new HashMap<>();
    Map<QName, MtasParserType<?>> groupTypes = new HashMap<>();
    Map<QName, MtasParserType<?>> groupAnnotationTypes = new HashMap<>();
    Map<QName, MtasParserType<?>> wordTypes = new HashMap<>();
    Map<QName, MtasParserType<?>> wordAnnotationTypes = new HashMap<>();
    Map<QName, MtasParserType<?>> variableTypes = new HashMap<>();
    MtasTokenCollection tokenCollection;

    static final String MAPPING_TYPE_REF = "ref";
    static final String MAPPING_TYPE_RELATION = "relation";
    static final String MAPPING_TYPE_RELATION_ANNOTATION = "relationAnnotation";
    static final String MAPPING_TYPE_GROUP = "group";
    static final String MAPPING_TYPE_GROUP_ANNOTATION = "groupAnnotation";
    static final String MAPPING_TYPE_WORD = "word";
    static final String MAPPING_TYPE_WORD_ANNOTATION = "wordAnnotation";
    static final String UPDATE_TYPE_VARIABLE = "variableUpdate";
    static final String UPDATE_TYPE_OFFSET = "offsetUpdate";
    static final String UPDATE_TYPE_POSITION = "positionUpdate";

    static class Log {
        public void debug(Object msg) {}
        public void info(String msg) {}
        public void error(Object msg) {}
    }

    static class MtasTokenCollection {
        public void add(MtasToken token) {}
        public MtasToken get(int id) { return new MtasToken(); }
        public void check(boolean autorepair, boolean makeunique) {}
    }

    static class MtasTokenIdFactory {
        public int createTokenId() { return 1; }
    }

    static class MtasToken {
        public static final String DELIMITER = "|";
        public String getPrefix() { return "pre"; }
        public String getPostfix() { return "post"; }
        public void setValue(String v) {}
        public void addOffset(int start, int end) {}
        public void addPositions(Set<Integer> positions) {}
        public void addOffsetStart(Integer start) {}
        public void addOffsetEnd(Integer end) {}
        public int getId() { return 1; }
    }

    static class MtasParserException extends Exception {
        public MtasParserException(String msg) { super(msg); }
    }

    static class MtasConfigException extends Exception {
        public MtasConfigException(String msg) { super(msg); }
    }

    static class MtasParserType<T> {
        public String getName() { return "type"; }
        public String getRefAttributeName() { return "ref"; }
        public List<T> getItems() { return new ArrayList<>(); }
    }

    static class MtasParserObject {
        MtasParserType<?> objectType;
        public MtasParserObject(MtasParserType<?> type) { this.objectType = type; }
        public void setUnknownAncestorNumber(Integer i) {}
        public void setRealOffsetStart(Integer start) {}
        public void setOffsetStart(Integer start) {}
        public void setOffsetEnd(Integer end) {}
        public Integer getOffsetStart() { return 0; }
        public Integer getOffsetEnd() { return 0; }
        public void setRealOffsetEnd(Integer end) {}
        public void addPosition(Integer position) {}
        public void addPositions(Set<Integer> positions) {}
        public void addOffsetStart(Integer start) {}
        public void addOffsetEnd(Integer end) {}
        public void addText(String text) {}
        public String getId() { return "id1"; }
        public MtasParserType<?> getType() { return objectType; }
        public SortedSet<Integer> getPositions() { return new TreeSet<>(); }
        public Integer[] getOffset() { return new Integer[]{0, 0}; }
        public void updateMappings(Map<String, Set<Integer>> idPositions, Map<String, Integer[]> idOffsets) {}
        public Integer getUnknownAncestorNumber() { return 0; }
        public String getAttribute(String name) { return "attr"; }
        public void addRefId(String id) {}
        public void addUpdateableIdWithOffset(String id) {}
    }

    static class MtasParserMapping {
        public List<?> getTokens() { return new ArrayList<>(); }
        public List<?> getConditions() { return new ArrayList<>(); }
    }

    private QName getQName(String key) { return new QName(key); }
    private Map<String, Map<Integer, Set<String>>> createUpdateList() {
        Map<String, Map<Integer, Set<String>>> map = new HashMap<>();
        map.put(UPDATE_TYPE_VARIABLE, new HashMap<>());
        map.put(UPDATE_TYPE_OFFSET, new HashMap<>());
        map.put(UPDATE_TYPE_POSITION, new HashMap<>());
        return map;
    }
    private Map<String, List<MtasParserObject>> createCurrentList() {
        Map<String, List<MtasParserObject>> map = new HashMap<>();
        map.put(MAPPING_TYPE_REF, new ArrayList<>());
        map.put(MAPPING_TYPE_RELATION, new ArrayList<>());
        map.put(MAPPING_TYPE_RELATION_ANNOTATION, new ArrayList<>());
        map.put(MAPPING_TYPE_GROUP, new ArrayList<>());
        map.put(MAPPING_TYPE_GROUP_ANNOTATION, new ArrayList<>());
        map.put(MAPPING_TYPE_WORD, new ArrayList<>());
        map.put(MAPPING_TYPE_WORD_ANNOTATION, new ArrayList<>());
        return map;
    }
    private Map<String, Map<String, String>> createVariables() { return new HashMap<>(); }
    private void collectAttributes(MtasParserObject obj, XMLStreamReader reader) {}
    private boolean prevalidateObject(MtasParserObject obj, Map<String, List<MtasParserObject>> list) { return true; }
    private void computeVariablesFromObject(MtasParserObject obj, Map<String, List<MtasParserObject>> list, Map<String, Map<String, String>> vars) {}
    private void computeMappingsFromObject(MtasTokenIdFactory factory, MtasParserObject obj, Map<String, List<MtasParserObject>> list, Map<String, Map<Integer, Set<String>>> updateList) throws MtasParserException, MtasConfigException {}
    private String decodeAndUpdateWithVariables(String prefix, String postfix, Map<String, Map<String, String>> vars) { return "decoded"; }
    private Collection<String> recursiveCollect(String refId, Map<String, SortedSet<String>> map, int max) { return new HashSet<>(); }
}