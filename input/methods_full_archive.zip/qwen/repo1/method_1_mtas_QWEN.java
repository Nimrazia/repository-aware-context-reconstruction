import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TimeZone;
import java.util.TreeMap;

public class method_1_mtas_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private static void collectSpansPositionsAndTokens(
          Map<MtasSpanQuery, SpanWeight> spansQueryWeight, IndexSearcher searcher,
          CodecInfo mtasCodecInfo, LeafReader r, LeafReaderContext lrc,
          String field, Terms t, List<Integer> docSet, List<Integer> docList,
          ComponentField fieldInfo, FieldInfos fieldInfos, Status status)
          throws IOException {

        boolean needSpans = false;
        boolean needPositions = false;
        boolean needTokens = false;

        
        Map<Integer, Integer> positionsData = null;
        Map<Integer, Integer> tokensData = null;
        Set<MtasSpanQuery> spansNumberByPositions = null;
        Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData = null;
        Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData = null;
        Map<String, SortedMap<String, int[]>> facetData = null;
        Map<String, String> facetDataType = null;

        
        if (!fieldInfo.statsPositionList.isEmpty()) {
          needPositions = true;
        }
        
        if (!fieldInfo.statsTokenList.isEmpty()) {
          needTokens = true;
        }
        if (!fieldInfo.termVectorList.isEmpty()) {
          for (ComponentTermVector ctv : fieldInfo.termVectorList) {
            if (!needPositions) {
              needPositions = (ctv.functions == null
                  ? ctv.subComponentFunction.parserFunction.needPositions()
                  : ctv.functionNeedPositions());
            }
          }
        }

        
        if (!fieldInfo.spanQueryList.isEmpty()) {
          
          spansNumberByPositions = new HashSet<>();
          spansNumberData = new HashMap<>();
          spansMatchData = new HashMap<>();
          facetData = new HashMap<>();
          facetDataType = new HashMap<>();
          
          if (!fieldInfo.statsSpanList.isEmpty()) {
            for (ComponentSpan cs : fieldInfo.statsSpanList) {
              needPositions = (!needPositions) ? cs.parser.needPositions()
                  : needPositions;
              needPositions = (!needPositions) ? cs.functionNeedPositions()
                  : needPositions;
              needSpans = (!needSpans) ? cs.parser.needArgumentsNumber() > 0
                  : needSpans;
              HashSet<Integer> arguments = cs.parser.needArgument();
              arguments.addAll(cs.functionNeedArguments());
              for (int a : arguments) {
                if (cs.queries.length > a) {
                  MtasSpanQuery q = cs.queries[a];
                  if (!spansNumberData.containsKey(q)) {
                    spansNumberData.put(q, new HashMap<Integer, Integer>());
                  }
                }
              }
            }
          }
          
          if (!fieldInfo.kwicList.isEmpty()) {
            needSpans = true;
            for (ComponentKwic ck : fieldInfo.kwicList) {
              if (!spansMatchData.containsKey(ck.query)) {
                spansMatchData.put(ck.query, new HashMap<Integer, List<Match>>());
              }
            }
          }
          
          if (!fieldInfo.listList.isEmpty()) {
            needSpans = true;
            for (ComponentList cl : fieldInfo.listList) {
              if (!spansMatchData.containsKey(cl.spanQuery)) {
                if (cl.number > 0) {
                  
                  if (cl.position < (cl.start + cl.number)) {
                    spansMatchData.put(cl.spanQuery,
                        new HashMap<Integer, List<Match>>());
                  } else {
                    spansNumberData.put(cl.spanQuery,
                        new HashMap<Integer, Integer>());
                  }
                } else if (!spansNumberData.containsKey(cl.spanQuery)) {
                  spansNumberData.put(cl.spanQuery,
                      new HashMap<Integer, Integer>());
                }
              }
            }
          }
          
          if (!fieldInfo.groupList.isEmpty()) {
            needSpans = true;
            for (ComponentGroup cg : fieldInfo.groupList) {
              if (!spansMatchData.containsKey(cg.spanQuery)) {
                spansMatchData.put(cg.spanQuery,
                    new HashMap<Integer, List<Match>>());
              }
            }
          }
          
          if (!fieldInfo.facetList.isEmpty()) {
            for (ComponentFacet cf : fieldInfo.facetList) {
              needPositions = !needPositions ? cf.baseParserNeedPositions()
                  : needPositions;
              needPositions = !needPositions ? cf.functionNeedPositions()
                  : needPositions;
              for (int i = 0; i < cf.baseFields.length; i++) {
                needSpans = !needSpans ? cf.baseParsers[i].needArgumentsNumber() > 0
                    : needSpans;
                HashSet<Integer> arguments = cf.baseParsers[i].needArgument();
                for (int a : arguments) {
                  if (cf.spanQueries.length > a) {
                    MtasSpanQuery q = cf.spanQueries[a];
                    if (!spansNumberData.containsKey(q)) {
                      spansNumberData.put(q, new HashMap<Integer, Integer>());
                    }
                  }
                }
                for (MtasFunctionParserFunction function : cf.baseFunctionParserFunctions[i]) {
                  needSpans = !needSpans ? function.needArgumentsNumber() > 0
                      : needSpans;
                  arguments = function.needArgument();
                  for (int a : arguments) {
                    if (cf.spanQueries.length > a) {
                      MtasSpanQuery q = cf.spanQueries[a];
                      if (!spansNumberData.containsKey(q)) {
                        spansNumberData.put(q, new HashMap<Integer, Integer>());
                      }
                    }
                  }
                }
                if (!facetData.containsKey(cf.baseFields[i])) {
                  facetData.put(cf.baseFields[i], new TreeMap<String, int[]>());
                  facetDataType.put(cf.baseFields[i], cf.baseFieldTypes[i]);
                }
              }
            }
          }
          
          if (!fieldInfo.termVectorList.isEmpty()) {
            for (ComponentTermVector ctv : fieldInfo.termVectorList) {
              if ((ctv.subComponentFunction.parserFunction != null
                  && ctv.subComponentFunction.parserFunction.needPositions())
                  || (ctv.functions != null && ctv.functionNeedPositions())) {
                needPositions = true;
              }
            }
          }
        }

        if (needSpans) {
          Map<Integer, Integer> numberData;
          Map<Integer, List<Match>> matchData;
          
          for (Entry<String, SortedMap<String, int[]>> entry : facetData
              .entrySet()) {
            FieldInfo fi = fieldInfos.fieldInfo(entry.getKey());
            if (fi != null) {
              
              if (!fi.getDocValuesType().equals(DocValuesType.NONE)) {
                Iterator<Integer> docIterator = docSet.iterator();
                
                if (fi.getDocValuesType().equals(DocValuesType.NUMERIC)
                    || fi.getDocValuesType().equals(DocValuesType.SORTED)
                    || fi.getDocValuesType().equals(DocValuesType.SORTED_SET)
                    || fi.getDocValuesType().equals(DocValuesType.SORTED_NUMERIC)
                    || fi.getDocValuesType().equals(DocValuesType.BINARY)) {
                  
                  Map<Object, List<Integer>> facetDataSubList = new HashMap<>();
                  
                  if (fi.getDocValuesType().equals(DocValuesType.NUMERIC)) {
                    NumericDocValues docValues = r.getContext().reader()
                        .getNumericDocValues(entry.getKey());
                    int docId;
                    while (docIterator.hasNext()) {
                      docId = docIterator.next() - lrc.docBase;
                      if (docValues.advanceExact(docId)) {
                        long value = docValues.longValue();
                        if (!facetDataSubList.containsKey(value)) {
                          List<Integer> facetDataSubListItem = new ArrayList<>();
                          facetDataSubListItem.add(docId + lrc.docBase);
                          facetDataSubList.put(value, facetDataSubListItem);
                        } else {
                          facetDataSubList.get(value).add(docId + lrc.docBase);
                        }
                      }
                    }
                  
                  } else if (fi.getDocValuesType().equals(DocValuesType.SORTED_NUMERIC)) {
                    SortedNumericDocValues docValues = r.getContext().reader()
                        .getSortedNumericDocValues(entry.getKey());
                    int docId;
                    while (docIterator.hasNext()) {
                      docId = docIterator.next() - lrc.docBase;
                      if (docValues.advanceExact(docId)) {
                        int n = docValues.docValueCount();
                        for(int i =0; i<n; i++) {
                          long value = docValues.nextValue();
                          if (!facetDataSubList.containsKey(value)) {
                            List<Integer> facetDataSubListItem = new ArrayList<>();
                            facetDataSubListItem.add(docId + lrc.docBase);
                            facetDataSubList.put(value, facetDataSubListItem);
                          } else {
                            facetDataSubList.get(value).add(docId + lrc.docBase);
                          }  
                        }                    
                      }
                    }
                 
                  } else if (fi.getDocValuesType().equals(DocValuesType.SORTED_SET)) {
                    SortedSetDocValues docValues = r.getContext().reader()
                        .getSortedSetDocValues(entry.getKey());
                    int docId;
                    Map<Long, String> dictionary = new HashMap<>();
                    while (docIterator.hasNext()) {
                      docId = docIterator.next() - lrc.docBase;
                      if (docValues.advanceExact(docId)) {
                        long tmpValue;
                        String value;
                        while((tmpValue=docValues.nextOrd()) != SortedSetDocValues.NO_MORE_ORDS) {
                          if(!dictionary.containsKey(tmpValue)) {
                            value = docValues.lookupOrd(tmpValue).utf8ToString();
                            dictionary.put(tmpValue, value);
                          } else {
                            value = dictionary.get(tmpValue);
                          }
                          if (!facetDataSubList.containsKey(value)) {
                            List<Integer> facetDataSubListItem = new ArrayList<>();
                            facetDataSubListItem.add(docId + lrc.docBase);
                            facetDataSubList.put(value, facetDataSubListItem);
                          } else {
                            facetDataSubList.get(value).add(docId + lrc.docBase);
                          }
                        }
                      }
                    }
                  
                  } else if (fi.getDocValuesType().equals(DocValuesType.SORTED)) {
                    SortedDocValues docValues = r.getContext().reader()
                        .getSortedDocValues(entry.getKey());
                    int docId;
                    while (docIterator.hasNext()) {
                      docId = docIterator.next() - lrc.docBase;
                      if (docValues.advanceExact(docId)) {
                        String value = docValues.binaryValue().utf8ToString();
                        if (!facetDataSubList.containsKey(value)) {
                          List<Integer> facetDataSubListItem = new ArrayList<>();
                          facetDataSubListItem.add(docId + lrc.docBase);
                          facetDataSubList.put(value, facetDataSubListItem);
                        } else {
                          facetDataSubList.get(value).add(docId + lrc.docBase);
                        }
                      }
                    }
                  }
                  if (!facetDataSubList.isEmpty()) {
                    SortedMap<String, int[]> facetDataList = entry.getValue();
                    SimpleDateFormat sdf = new SimpleDateFormat(
                        "yyyy-MM-dd'T'HH:mm:ss'Z'");
                    sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
                    for (Entry<Object, List<Integer>> facetEntry : facetDataSubList
                        .entrySet()) {
                      int[] docIdList = facetEntry.getValue().stream()
                          .mapToInt(i -> i).toArray();
                      String termValue;
                      if (facetDataType.get(entry.getKey())
                          .equals(NumberType.DATE.name())) {
                        Date date = new Date((Long) facetEntry.getKey());
                        termValue = sdf.format(date);
                      } else {
                        termValue = facetEntry.getKey().toString();
                      }
                      if (!facetDataList.containsKey(termValue)) {
                        facetDataList.put(termValue, docIdList);
                      } else {
                        int[] oldList = facetDataList.get(termValue);
                        int[] newList = new int[oldList.length + docIdList.length];
                        System.arraycopy(oldList, 0, newList, 0, oldList.length);
                        System.arraycopy(docIdList, 0, newList, oldList.length,
                            docIdList.length);
                        facetDataList.put(termValue, newList);
                      }
                    }
                  }
                } else {
                  throw new IOException("facets for docValues of type "
                      + fi.getDocValuesType() + " not implemented");
                }
              } else if (!docSet.isEmpty()) {
                if (facetDataType.get(entry.getKey())
                    .equals(ComponentFacet.TYPE_POINTFIELD_WITHOUT_DOCVALUES)) {
                  throw new IOException(
                      "can't create facets for pointField without docValues");
                }
                Terms fft = r.terms(entry.getKey());
                if (fft != null) {
                  TermsEnum termsEnum = fft.iterator();
                  BytesRef term = null;
                  PostingsEnum postingsEnum = null;
                  SortedMap<String, int[]> facetDataList = entry.getValue();
                  while ((term = termsEnum.next()) != null) {
                    int docId;
                    int termDocId = -1;
                    int[] facetDataSublist = new int[docSet.size()];
                    int facetDataSublistCounter = 0;
                    Iterator<Integer> docIterator = docSet.iterator();
                    postingsEnum = termsEnum.postings(postingsEnum);
                    while (docIterator.hasNext()) {
                      docId = docIterator.next() - lrc.docBase;
                      if (docId >= termDocId
                          && ((docId == termDocId) || ((termDocId = postingsEnum
                              .advance(docId)) == docId))) {
                        facetDataSublist[facetDataSublistCounter] = docId
                            + lrc.docBase;
                        facetDataSublistCounter++;
                      }
                    }
                    if (facetDataSublistCounter > 0) {
                      String termValue = null;
                      if (facetDataType.get(entry.getKey())
                          .equals(NumberType.INTEGER.name())) {
                        
                        if (term.bytes[term.offset] == LegacyNumericUtils.SHIFT_START_INT) {
                          termValue = Integer
                              .toString(LegacyNumericUtils.prefixCodedToInt(term));
                        } else {
                          continue;
                        }
                      } else if (facetDataType.get(entry.getKey())
                          .equals(NumberType.LONG.name())) {
                        if (term.bytes[term.offset] == LegacyNumericUtils.SHIFT_START_LONG) {
                          termValue = Long
                              .toString(LegacyNumericUtils.prefixCodedToLong(term));
                        } else {
                          continue;
                        }
                      } else {
                        termValue = term.utf8ToString();
                      }
                      if (!facetDataList.containsKey(termValue)) {
                        facetDataList.put(termValue, Arrays.copyOf(facetDataSublist,
                            facetDataSublistCounter));
                      } else {
                        int[] oldList = facetDataList.get(termValue);
                        int[] newList = new int[oldList.length
                            + facetDataSublistCounter];
                        System.arraycopy(oldList, 0, newList, 0, oldList.length);
                        System.arraycopy(facetDataSublist, 0, newList,
                            oldList.length, facetDataSublistCounter);
                        facetDataList.put(termValue, newList);
                      }
                    }
                  }
                }
              }
            }
          }

          
          for (MtasSpanQuery sq : fieldInfo.spanQueryList) {
            
            if (spansNumberData.containsKey(sq)) {
              numberData = spansNumberData.get(sq);
            } else {
              numberData = null;
            }
            
            if (spansMatchData.containsKey(sq)) {
              matchData = spansMatchData.get(sq);
            } else {
              matchData = null;
            }
            boolean doNormalCollection = true;
            
            if ((numberData != null) && (matchData == null)) {
              if (sq.isMatchAllPositionsQuery()) {
                spansNumberByPositions.add(sq);
                needPositions = true;
                doNormalCollection = false;
              }
            }
            
            if (doNormalCollection
                && ((numberData != null) || (matchData != null))) {
              Spans spans = spansQueryWeight.get(sq).getSpans(lrc,
                  SpanWeight.Postings.POSITIONS);
              if (spans != null) {
                Iterator<Integer> it;
                if (docSet != null) {
                  it = docSet.iterator();
                } else {
                  it = docList.iterator();
                }
                if (it.hasNext()) {
                  int docId = it.next();
                  int number;
                  ArrayList<Match> matchDataList;
                  Integer spansDocId = null;
                  while (docId != DocIdSetIterator.NO_MORE_DOCS) {
                    if (spans.advance(
                        (docId - lrc.docBase)) == DocIdSetIterator.NO_MORE_DOCS) {
                      break;
                    }
                    spansDocId = spans.docID() + lrc.docBase;
                    while ((docId < spansDocId) && it.hasNext()) {
                      docId = it.next();
                    }
                    if (docId < spansDocId) {
                      break;
                    }
                    if (spansDocId.equals(docId)) {
                      number = 0;
                      matchDataList = new ArrayList<>();
                      int tmpStartPosition;
                      while ((tmpStartPosition = spans
                          .nextStartPosition()) != Spans.NO_MORE_POSITIONS) {
                        number++;
                        if (matchData != null) {
                          Match m = new Match(tmpStartPosition,
                              spans.endPosition());
                          matchDataList.add(m);
                        }
                      }
                      if ((numberData != null)) {
                        numberData.put(spansDocId, number);
                      }
                      if ((matchData != null)) {
                        matchData.put(spansDocId, matchDataList);
                      }
                      if (it.hasNext()) {
                        docId = it.next();
                      } else {
                        break;
                      }
                    }
                  }
                }
              }
            }
          }
        }

        
        if (needPositions) {
          if (mtasCodecInfo != null) {
            
            if (docSet.size() < Math.log(r.maxDoc())) {
              positionsData = new HashMap<>();
              for (int docId : docSet) {
                positionsData.put(docId, mtasCodecInfo.getNumberOfPositions(field,
                    (docId - lrc.docBase)));
              }
              
            } else {
              positionsData = mtasCodecInfo.getAllNumberOfPositions(field,
                  lrc.docBase);
              for (int docId : docSet) {
                if (!positionsData.containsKey(docId)) {
                  positionsData.put(docId, 0);
                }
              }
            }
          } else {
            positionsData = new HashMap<>();
            for (int docId : docSet) {
              positionsData.put(docId, 0);
            }
          }
          if (spansNumberByPositions != null && spansNumberData != null) {        
            for (MtasSpanQuery sq : spansNumberByPositions) {
              Map<Integer,Integer> numberData = spansNumberData.get(sq);
              positionsData.forEach((k,v) -> numberData.put(k,v!=null?v:0));          
            }
          }
        }

        
        if (needTokens) {
          if (mtasCodecInfo != null) {
            
            if (docSet.size() < Math.log(r.maxDoc())) {
              tokensData = new HashMap<>();
              for (int docId : docSet) {
                tokensData.put(docId,
                    mtasCodecInfo.getNumberOfTokens(field, (docId - lrc.docBase)));
              }
              
            } else {
              tokensData = mtasCodecInfo.getAllNumberOfTokens(field, lrc.docBase);
              for (int docId : docSet) {
                if (!tokensData.containsKey(docId)) {
                  tokensData.put(docId, 0);
                }
              }
            }
          } else {
            tokensData = new HashMap<>();
            for (int docId : docSet) {
              tokensData.put(docId, 0);
            }
          }
        }

        if (!fieldInfo.statsPositionList.isEmpty()) {
          createPositions(fieldInfo.statsPositionList, positionsData, docSet);
        }

        if (!fieldInfo.statsTokenList.isEmpty()) {
          createTokens(fieldInfo.statsTokenList, tokensData, docSet);
        }

        if (!fieldInfo.documentList.isEmpty()) {
          createDocument(fieldInfo.documentList, docList, fieldInfo.uniqueKeyField,
              searcher, t, lrc);
        }
        if (!fieldInfo.spanQueryList.isEmpty()) {
          if (!fieldInfo.statsSpanList.isEmpty()) {
            createStats(fieldInfo.statsSpanList, positionsData, spansNumberData,
                docSet.toArray(new Integer[docSet.size()]));
          }
          if (!fieldInfo.listList.isEmpty()) {
            createList(fieldInfo.listList, spansNumberData, spansMatchData, docSet,
                field, lrc.docBase, fieldInfo.uniqueKeyField, mtasCodecInfo,
                searcher);
          }
          if (!fieldInfo.groupList.isEmpty()) {
            createGroup(fieldInfo.groupList, spansMatchData, docSet,
                fieldInfos.fieldInfo(field), field, lrc.docBase, mtasCodecInfo,
                searcher, lrc, status);
          }
          if (!fieldInfo.kwicList.isEmpty()) {
            createKwic(fieldInfo.kwicList, spansMatchData, docList, field,
                lrc.docBase, fieldInfo.uniqueKeyField, mtasCodecInfo, searcher);
          }
          if (!fieldInfo.facetList.isEmpty()) {
            createFacet(fieldInfo.facetList, positionsData, spansNumberData,
                facetData, docSet);
          }
        }
        if (!fieldInfo.termVectorList.isEmpty()) {
          createTermvectorFull(fieldInfo.termVectorList, positionsData, docSet, t,
              r, lrc);
          createTermvectorFirstRound(fieldInfo.termVectorList, positionsData,
              docSet, t, r, lrc);
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    
    
    
    
    private static void createPositions(List<ComponentPosition> statsPositionList, Map<Integer, Integer> positionsData, List<Integer> docSet) {
        
    }
    private static void createTokens(List<ComponentToken> statsTokenList, Map<Integer, Integer> tokensData, List<Integer> docSet) {
        
    }
    private static void createDocument(List<ComponentDocument> documentList, List<Integer> docList, String uniqueKeyField, IndexSearcher searcher, Terms t, LeafReaderContext lrc) {
        
    }
    private static void createStats(List<ComponentSpan> statsSpanList, Map<Integer, Integer> positionsData, Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData, Integer[] docSetArray) {
        
    }
    private static void createList(List<ComponentList> listList, Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData, Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData, List<Integer> docSet, String field, int docBase, String uniqueKeyField, CodecInfo mtasCodecInfo, IndexSearcher searcher) {
        
    }
    private static void createGroup(List<ComponentGroup> groupList, Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData, List<Integer> docSet, FieldInfo fieldInfo, String field, int docBase, CodecInfo mtasCodecInfo, IndexSearcher searcher, LeafReaderContext lrc, Status status) {
        
    }
    private static void createKwic(List<ComponentKwic> kwicList, Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData, List<Integer> docList, String field, int docBase, String uniqueKeyField, CodecInfo mtasCodecInfo, IndexSearcher searcher) {
        
    }
    private static void createFacet(List<ComponentFacet> facetList, Map<Integer, Integer> positionsData, Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData, Map<String, SortedMap<String, int[]>> facetData, List<Integer> docSet) {
        
    }
    private static void createTermvectorFull(List<ComponentTermVector> termVectorList, Map<Integer, Integer> positionsData, List<Integer> docSet, Terms t, LeafReader r, LeafReaderContext lrc) {
        
    }
    private static void createTermvectorFirstRound(List<ComponentTermVector> termVectorList, Map<Integer, Integer> positionsData, List<Integer> docSet, Terms t, LeafReader r, LeafReaderContext lrc) {
        
    }

    
    
    
    public static void main(String[] args) {
        System.out.println("=== MTAS CodecCollector Reconstruction Test ===");
        
        Map<MtasSpanQuery, SpanWeight> spansQueryWeight = new HashMap<>();
        IndexSearcher searcher = new IndexSearcher();
        CodecInfo mtasCodecInfo = new CodecInfo();
        LeafReader r = new LeafReader();
        LeafReaderContext lrc = new LeafReaderContext();
        lrc.docBase = 0;
        String field = "content";
        Terms t = new Terms();
        
        List<Integer> docSet = new ArrayList<>();
        docSet.add(1);
        docSet.add(2);
        
        List<Integer> docList = new ArrayList<>();
        docList.add(1);
        
        ComponentField fieldInfo = new ComponentField();
        fieldInfo.uniqueKeyField = "id";
        
        ComponentTermVector ctv = new ComponentTermVector();
        fieldInfo.termVectorList.add(ctv);
        
        ComponentFacet cf = new ComponentFacet();
        cf.baseFields = new String[]{"category"};
        cf.baseFieldTypes = new String[]{NumberType.INTEGER.name()};
        cf.baseParsers = new FacetParser[]{new FacetParser()};
        cf.spanQueries = new MtasSpanQuery[]{new MtasSpanQuery()};
        cf.baseFunctionParserFunctions = new MtasFunctionParserFunction[][]{new MtasFunctionParserFunction[0]};
        fieldInfo.facetList.add(cf);
        
        FieldInfos fieldInfos = new FieldInfos();
        Status status = new Status();
        
        try {
            System.out.println("Invoking collectSpansPositionsAndTokens...");
            collectSpansPositionsAndTokens(
                spansQueryWeight, searcher, mtasCodecInfo, r, lrc,
                field, t, docSet, docList, fieldInfo, fieldInfos, status
            );
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("State verification:");
            System.out.println(" - docSet size: " + docSet.size());
            System.out.println(" - fieldInfo facetList size: " + fieldInfo.facetList.size());
            System.out.println(" - fieldInfo termVectorList size: " + fieldInfo.termVectorList.size());
            System.out.println("=== Test Completed Successfully ===");
        } catch (IOException e) {
            System.err.println("FAILURE: IOException during execution: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("FAILURE: Unexpected exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    
    
    enum DocValuesType { NONE, NUMERIC, SORTED, SORTED_SET, SORTED_NUMERIC, BINARY }
    enum NumberType { DATE, INTEGER, LONG }

    static class BytesRef {
        public byte[] bytes = new byte[0];
        public int offset = 0;
        public int length = 0;
        public String utf8ToString() { return "mock"; }
    }

    static class DocIdSetIterator {
        public static final int NO_MORE_DOCS = -1;
    }

    static class PostingsEnum {
        public int advance(int target) throws IOException { return DocIdSetIterator.NO_MORE_DOCS; }
    }

    static class TermsEnum {
        public BytesRef next() throws IOException { return null; }
        public PostingsEnum postings(PostingsEnum reuse) throws IOException { return new PostingsEnum(); }
    }

    static class Terms {
        public TermsEnum iterator() throws IOException { return new TermsEnum(); }
    }

    static class NumericDocValues {
        public boolean advanceExact(int doc) throws IOException { return false; }
        public long longValue() throws IOException { return 0L; }
    }

    static class SortedNumericDocValues {
        public boolean advanceExact(int doc) throws IOException { return false; }
        public int docValueCount() throws IOException { return 0; }
        public long nextValue() throws IOException { return 0L; }
    }

    static class SortedSetDocValues {
        public static final long NO_MORE_ORDS = -1L;
        public long nextOrd() throws IOException { return NO_MORE_ORDS; }
        public BytesRef lookupOrd(long ord) throws IOException { return new BytesRef(); }
        public boolean advanceExact(int doc) throws IOException { return false; }
    }

    static class SortedDocValues {
        public BytesRef binaryValue() throws IOException { return new BytesRef(); }
        public boolean advanceExact(int doc) throws IOException { return false; }
    }

    static class FieldInfo {
        private DocValuesType type;
        public FieldInfo(DocValuesType type) { this.type = type; }
        public DocValuesType getDocValuesType() { return type; }
    }

    static class FieldInfos {
        public FieldInfo fieldInfo(String fieldName) { return new FieldInfo(DocValuesType.NONE); }
    }

    static class MockIndexReader {
        public NumericDocValues getNumericDocValues(String field) { return new NumericDocValues(); }
        public SortedNumericDocValues getSortedNumericDocValues(String field) { return new SortedNumericDocValues(); }
        public SortedSetDocValues getSortedSetDocValues(String field) { return new SortedSetDocValues(); }
        public SortedDocValues getSortedDocValues(String field) { return new SortedDocValues(); }
    }

    static class LeafReaderContext {
        public int docBase = 0;
        public MockIndexReader reader() { return new MockIndexReader(); }
    }

    static class LeafReader {
        public int maxDoc() { return 10; }
        public LeafReaderContext getContext() { return new LeafReaderContext(); }
        public Terms terms(String field) throws IOException { return new Terms(); }
    }

    static class IndexSearcher {}

    static class SpanWeight {
        public enum Postings { POSITIONS }
        public Spans getSpans(LeafReaderContext context, Postings postings) throws IOException { return new Spans(); }
    }

    static class Spans {
        public static final int NO_MORE_POSITIONS = -1;
        public int advance(int target) throws IOException { return DocIdSetIterator.NO_MORE_DOCS; }
        public int docID() { return 0; }
        public int nextStartPosition() throws IOException { return NO_MORE_POSITIONS; }
        public int endPosition() { return 0; }
    }

    static class LegacyNumericUtils {
        public static final byte SHIFT_START_INT = 0x20;
        public static final byte SHIFT_START_LONG = 0x40;
        public static int prefixCodedToInt(BytesRef val) { return 0; }
        public static long prefixCodedToLong(BytesRef val) { return 0L; }
    }

    static class MtasSpanQuery {
        public boolean isMatchAllPositionsQuery() { return false; }
    }

    static class CodecInfo {
        public Integer getNumberOfPositions(String field, int docId) { return 0; }
        public Map<Integer, Integer> getAllNumberOfPositions(String field, int docBase) { return new HashMap<>(); }
        public Integer getNumberOfTokens(String field, int docId) { return 0; }
        public Map<Integer, Integer> getAllNumberOfTokens(String field, int docBase) { return new HashMap<>(); }
    }

    static class Status {
        public Integer numberDocumentsFound = 0;
    }

    static class MtasFunctionParserFunction {
        public boolean needPositions() { return false; }
        public int needArgumentsNumber() { return 0; }
        public HashSet<Integer> needArgument() { return new HashSet<>(); }
    }

    static class SubComponentFunction {
        public MtasFunctionParserFunction parserFunction = new MtasFunctionParserFunction();
    }

    static class ComponentTermVector {
        public List<MtasFunctionParserFunction> functions;
        public SubComponentFunction subComponentFunction = new SubComponentFunction();
        public boolean functionNeedPositions() { return false; }
    }

    static class ComponentPosition {}
    static class ComponentToken {}
    static class ComponentDocument {}

    static class ComponentSpan {
        public MtasFunctionParserFunction parser = new MtasFunctionParserFunction();
        public MtasSpanQuery[] queries = new MtasSpanQuery[0];
        public boolean functionNeedPositions() { return false; }
        public Set<Integer> functionNeedArguments() { return new HashSet<>(); }
    }

    static class ComponentKwic {
        public MtasSpanQuery query;
    }

    static class ComponentList {
        public MtasSpanQuery spanQuery;
        public int number = 0;
        public int position = 0;
        public int start = 0;
    }

    static class ComponentGroup {
        public MtasSpanQuery spanQuery;
    }

    static class FacetParser {
        public int needArgumentsNumber() { return 0; }
        public HashSet<Integer> needArgument() { return new HashSet<>(); }
    }

    static class ComponentFacet {
        public static final String TYPE_POINTFIELD_WITHOUT_DOCVALUES = "POINTFIELD_WITHOUT_DOCVALUES";
        public boolean baseParserNeedPositions() { return false; }
        public boolean functionNeedPositions() { return false; }
        public String[] baseFields = new String[0];
        public String[] baseFieldTypes = new String[0];
        public FacetParser[] baseParsers = new FacetParser[0];
        public MtasSpanQuery[] spanQueries = new MtasSpanQuery[0];
        public MtasFunctionParserFunction[][] baseFunctionParserFunctions = new MtasFunctionParserFunction[0][];
    }

    static class ComponentField {
        public String uniqueKeyField = "id";
        public List<ComponentPosition> statsPositionList = new ArrayList<>();
        public List<ComponentToken> statsTokenList = new ArrayList<>();
        public List<ComponentTermVector> termVectorList = new ArrayList<>();
        public List<ComponentSpan> statsSpanList = new ArrayList<>();
        public List<ComponentKwic> kwicList = new ArrayList<>();
        public List<ComponentList> listList = new ArrayList<>();
        public List<ComponentGroup> groupList = new ArrayList<>();
        public List<ComponentFacet> facetList = new ArrayList<>();
        public List<MtasSpanQuery> spanQueryList = new ArrayList<>();
        public List<ComponentDocument> documentList = new ArrayList<>();
    }

    static class Match {
        public int startPosition;
        public int endPosition;
        public Match(int startPosition, int endPosition) {
            this.startPosition = startPosition;
            this.endPosition = endPosition;
        }
    }
}