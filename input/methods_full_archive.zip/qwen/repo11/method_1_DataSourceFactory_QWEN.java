import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;




class ConnectionProperties {
    private int maxTotal = 8;
    private int maxIdle = 8;
    private int minIdle = 0;
    private long maxWaitMillis = -1L;
    private boolean testOnCreate = false;
    private boolean testOnBorrow = true;
    private boolean testOnReturn = false;
    private boolean testWhileIdle = false;
    private long timeBetweenEvictionRunsMillis = -1L;
    private int numTestsPerEvictionRun = 3;
    private long minEvictableIdleTimeMillis = 1000L * 60L * 30L;
    private long softMinEvictableIdleTimeMillis = -1L;
    private boolean lifo = true;
    private boolean defaultAutoCommit = true;
    private boolean defaultReadOnly = false;
    private int defaultTransactionIsolation = -1;
    private boolean cacheState = true;
    private String validationQuery = null;
    private long maxConnLifetimeMillis = -1L;

    public int getMaxTotal() { return maxTotal; }
    public void setMaxTotal(int maxTotal) { this.maxTotal = maxTotal; }
    public int getMaxIdle() { return maxIdle; }
    public void setMaxIdle(int maxIdle) { this.maxIdle = maxIdle; }
    public int getMinIdle() { return minIdle; }
    public void setMinIdle(int minIdle) { this.minIdle = minIdle; }
    public long getMaxWaitMillis() { return maxWaitMillis; }
    public void setMaxWaitMillis(long maxWaitMillis) { this.maxWaitMillis = maxWaitMillis; }
    public boolean isTestOnCreate() { return testOnCreate; }
    public void setTestOnCreate(boolean testOnCreate) { this.testOnCreate = testOnCreate; }
    public boolean isTestOnBorrow() { return testOnBorrow; }
    public void setTestOnBorrow(boolean testOnBorrow) { this.testOnBorrow = testOnBorrow; }
    public boolean isTestOnReturn() { return testOnReturn; }
    public void setTestOnReturn(boolean testOnReturn) { this.testOnReturn = testOnReturn; }
    public boolean isTestWhileIdle() { return testWhileIdle; }
    public void setTestWhileIdle(boolean testWhileIdle) { this.testWhileIdle = testWhileIdle; }
    public long getTimeBetweenEvictionRunsMillis() { return timeBetweenEvictionRunsMillis; }
    public void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis) { this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis; }
    public int getNumTestsPerEvictionRun() { return numTestsPerEvictionRun; }
    public void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) { this.numTestsPerEvictionRun = numTestsPerEvictionRun; }
    public long getMinEvictableIdleTimeMillis() { return minEvictableIdleTimeMillis; }
    public void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis) { this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis; }
    public long getSoftMinEvictableIdleTimeMillis() { return softMinEvictableIdleTimeMillis; }
    public void setSoftMinEvictableIdleTimeMillis(long softMinEvictableIdleTimeMillis) { this.softMinEvictableIdleTimeMillis = softMinEvictableIdleTimeMillis; }
    public boolean isLifo() { return lifo; }
    public void setLifo(boolean lifo) { this.lifo = lifo; }
    public boolean isDefaultAutoCommit() { return defaultAutoCommit; }
    public void setDefaultAutoCommit(boolean defaultAutoCommit) { this.defaultAutoCommit = defaultAutoCommit; }
    public boolean isDefaultReadOnly() { return defaultReadOnly; }
    public void setDefaultReadOnly(boolean defaultReadOnly) { this.defaultReadOnly = defaultReadOnly; }
    public int getDefaultTransactionIsolation() { return defaultTransactionIsolation; }
    public void setDefaultTransactionIsolation(int defaultTransactionIsolation) { this.defaultTransactionIsolation = defaultTransactionIsolation; }
    public boolean isCacheState() { return cacheState; }
    public void setCacheState(boolean cacheState) { this.cacheState = cacheState; }
    public String getValidationQuery() { return validationQuery; }
    public void setValidationQuery(String validationQuery) { this.validationQuery = validationQuery; }
    public long getMaxConnLifetimeMillis() { return maxConnLifetimeMillis; }
    public void setMaxConnLifetimeMillis(long maxConnLifetimeMillis) { this.maxConnLifetimeMillis = maxConnLifetimeMillis; }
}

class FactoryException extends Exception {
    public FactoryException(String message) { super(message); }
    public FactoryException(String message, Throwable cause) { super(message, cause); }
}




class GenericObjectPoolConfig {
    private int maxTotal, maxIdle, minIdle, numTestsPerEvictionRun;
    private long maxWaitMillis, timeBetweenEvictionRunsMillis, minEvictableIdleTimeMillis, softMinEvictableIdleTimeMillis;
    private boolean testOnCreate, testOnBorrow, testOnReturn, testWhileIdle, lifo;
    
    public void setMaxTotal(int maxTotal) { this.maxTotal = maxTotal; }
    public void setMaxIdle(int maxIdle) { this.maxIdle = maxIdle; }
    public void setMinIdle(int minIdle) { this.minIdle = minIdle; }
    public void setMaxWaitMillis(long maxWaitMillis) { this.maxWaitMillis = maxWaitMillis; }
    public void setTestOnCreate(boolean testOnCreate) { this.testOnCreate = testOnCreate; }
    public void setTestOnBorrow(boolean testOnBorrow) { this.testOnBorrow = testOnBorrow; }
    public void setTestOnReturn(boolean testOnReturn) { this.testOnReturn = testOnReturn; }
    public void setTestWhileIdle(boolean testWhileIdle) { this.testWhileIdle = testWhileIdle; }
    public void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis) { this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis; }
    public void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) { this.numTestsPerEvictionRun = numTestsPerEvictionRun; }
    public void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis) { this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis; }
    public void setSoftMinEvictableIdleTimeMillis(long softMinEvictableIdleTimeMillis) { this.softMinEvictableIdleTimeMillis = softMinEvictableIdleTimeMillis; }
    public void setLifo(boolean lifo) { this.lifo = lifo; }
    
    public int getMaxTotal() { return maxTotal; }
    public int getMaxIdle() { return maxIdle; }
    public int getMinIdle() { return minIdle; }
}

interface ConnectionFactory {}
class DriverManagerConnectionFactory implements ConnectionFactory {
    public DriverManagerConnectionFactory(String url, Properties props) {}
}

class PoolableConnection {}

class PoolableConnectionFactory {
    private boolean defaultAutoCommit, defaultReadOnly, cacheState;
    private int defaultTransactionIsolation;
    private String validationQuery;
    private long maxConnLifetimeMillis;
    
    public PoolableConnectionFactory(ConnectionFactory connFactory, Object pool) {}
    public void setDefaultAutoCommit(boolean defaultAutoCommit) { this.defaultAutoCommit = defaultAutoCommit; }
    public void setDefaultReadOnly(boolean defaultReadOnly) { this.defaultReadOnly = defaultReadOnly; }
    public void setDefaultTransactionIsolation(int defaultTransactionIsolation) { this.defaultTransactionIsolation = defaultTransactionIsolation; }
    public void setCacheState(boolean cacheState) { this.cacheState = cacheState; }
    public void setValidationQuery(String validationQuery) { this.validationQuery = validationQuery; }
    public void setMaxConnLifetimeMillis(long maxConnLifetimeMillis) { this.maxConnLifetimeMillis = maxConnLifetimeMillis; }
    public void setPool(Object pool) {}
    
    public boolean isDefaultAutoCommit() { return defaultAutoCommit; }
    public boolean isDefaultReadOnly() { return defaultReadOnly; }
    public int getDefaultTransactionIsolation() { return defaultTransactionIsolation; }
    public boolean isCacheState() { return cacheState; }
    public String getValidationQuery() { return validationQuery; }
    public long getMaxConnLifetimeMillis() { return maxConnLifetimeMillis; }
}

class GenericObjectPool<T> {
    public GenericObjectPool(PoolableConnectionFactory factory, GenericObjectPoolConfig config) {}
}

class PoolingDataSource<T> {
    private GenericObjectPool<T> pool;
    public PoolingDataSource(GenericObjectPool<T> pool) { this.pool = pool; }
    public GenericObjectPool<T> getPool() { return pool; }
}




public class method_1_DataSourceFactory_QWEN {

    private static class LOG {
        public static void debug(String msg) { System.out.println("[DEBUG] " + msg); }
    }


// ORIGINAL CODESEARCHNET METHOD — START

private static PoolingDataSource<PoolableConnection> getPoolingDataSource(final String url,
                                                                              final ConcurrentMap<String, String> properties,
                                                                              final ConnectionProperties poolSpec) {

        
        assert url != null : "The url cannot be null";
        assert properties != null : "The properties cannot be null";
        assert poolSpec != null : "The pol spec cannot be null";

        LOG.debug("Creating new pooled data source for '" + url + "'");

        
        final Properties props = new Properties();
        props.putAll(properties);

        
        final GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
        poolConfig.setMaxTotal(poolSpec.getMaxTotal());
        poolConfig.setMaxIdle(poolSpec.getMaxIdle());
        poolConfig.setMinIdle(poolSpec.getMinIdle());
        poolConfig.setMaxWaitMillis(poolSpec.getMaxWaitMillis());
        poolConfig.setTestOnCreate(poolSpec.isTestOnCreate());
        poolConfig.setTestOnBorrow(poolSpec.isTestOnBorrow());
        poolConfig.setTestOnReturn(poolSpec.isTestOnReturn());
        poolConfig.setTestWhileIdle(poolSpec.isTestWhileIdle());
        poolConfig.setTimeBetweenEvictionRunsMillis(poolSpec.getTimeBetweenEvictionRunsMillis());
        poolConfig.setNumTestsPerEvictionRun(poolSpec.getNumTestsPerEvictionRun());
        poolConfig.setMinEvictableIdleTimeMillis(poolSpec.getMinEvictableIdleTimeMillis());
        poolConfig.setSoftMinEvictableIdleTimeMillis(poolSpec.getSoftMinEvictableIdleTimeMillis());
        poolConfig.setLifo(poolSpec.isLifo());


        
        final ConnectionFactory connFactory = new DriverManagerConnectionFactory(url, props);
        final PoolableConnectionFactory poolConnFactory = new PoolableConnectionFactory(connFactory, null);
        poolConnFactory.setDefaultAutoCommit(poolSpec.isDefaultAutoCommit());
        poolConnFactory.setDefaultReadOnly(poolSpec.isDefaultReadOnly());
        poolConnFactory.setDefaultTransactionIsolation(poolSpec.getDefaultTransactionIsolation());
        poolConnFactory.setCacheState(poolSpec.isCacheState());
        poolConnFactory.setValidationQuery(poolSpec.getValidationQuery());
        poolConnFactory.setMaxConnLifetimeMillis(poolSpec.getMaxConnLifetimeMillis());
        final GenericObjectPool<PoolableConnection> connPool = new GenericObjectPool<>(poolConnFactory, poolConfig);
        poolConnFactory.setPool(connPool);

        
        return new PoolingDataSource<>(connPool);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 1: getPoolingDataSource - DBCP2 Pool Creation        ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            ConcurrentMap<String, String> props = new ConcurrentHashMap<>();
            props.put("user", "admin");
            props.put("password", "secret");

            ConnectionProperties poolSpec = new ConnectionProperties();
            poolSpec.setMaxTotal(20);
            poolSpec.setMaxIdle(10);
            poolSpec.setMinIdle(2);
            poolSpec.setMaxWaitMillis(5000L);
            poolSpec.setTestOnBorrow(true);
            poolSpec.setValidationQuery("SELECT 1");
            poolSpec.setDefaultAutoCommit(false);

            System.out.println("┌─ POOL CONFIGURATION INPUT ─────────────────────────────────┐");
            System.out.println("│ URL: jdbc:postgresql://localhost:5432/mydb");
            System.out.println("│ Max Total: " + poolSpec.getMaxTotal());
            System.out.println("│ Max Idle: " + poolSpec.getMaxIdle());
            System.out.println("│ Validation Query: " + poolSpec.getValidationQuery());
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");

            PoolingDataSource<PoolableConnection> dataSource = getPoolingDataSource(
                "jdbc:postgresql://localhost:5432/mydb", props, poolSpec
            );

            System.out.println("┌─ POOL CREATION RESULT ─────────────────────────────────────┐");
            System.out.println("│ ✓ PoolingDataSource successfully instantiated.");
            System.out.println("│ ✓ Underlying pool type: " + dataSource.getPool().getClass().getSimpleName());
            System.out.println("│ ✓ Pool configured with MaxTotal=" + poolSpec.getMaxTotal() + ", MaxIdle=" + poolSpec.getMaxIdle());
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}