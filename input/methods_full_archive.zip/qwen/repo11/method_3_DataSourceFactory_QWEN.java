import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;




class FactoryException3 extends Exception {
    public FactoryException3(String message) { super(message); }
    public FactoryException3(String message, Throwable cause) { super(message, cause); }
}




class MockContext implements Context {
    private final String jndiName;
    public MockContext(String jndiName) { this.jndiName = jndiName; }
    public Object lookup(String name) { 
        if (name.equals(jndiName)) {
            return new MockDataSource();
        }
        throw new RuntimeException("Name not found: " + name);
    }
    
    public Object lookup(javax.naming.Name name) { return null; }
    public void bind(javax.naming.Name name, Object obj) {}
    public void bind(String name, Object obj) {}
    public void rebind(javax.naming.Name name, Object obj) {}
    public void rebind(String name, Object obj) {}
    public void unbind(javax.naming.Name name) {}
    public void unbind(String name) {}
    public void rename(javax.naming.Name oldName, javax.naming.Name newName) {}
    public void rename(String oldName, String newName) {}
    public javax.naming.NamingEnumeration<javax.naming.NameClassPair> list(javax.naming.Name name) { return null; }
    public javax.naming.NamingEnumeration<javax.naming.NameClassPair> list(String name) { return null; }
    public javax.naming.NamingEnumeration<javax.naming.Binding> listBindings(javax.naming.Name name) { return null; }
    public javax.naming.NamingEnumeration<javax.naming.Binding> listBindings(String name) { return null; }
    public void destroySubcontext(javax.naming.Name name) {}
    public void destroySubcontext(String name) {}
    public Context createSubcontext(javax.naming.Name name) { return null; }
    public Context createSubcontext(String name) { return null; }
    public Object lookupLink(javax.naming.Name name) { return null; }
    public Object lookupLink(String name) { return null; }
    public javax.naming.NameParser getNameParser(javax.naming.Name name) { return null; }
    public javax.naming.NameParser getNameParser(String name) { return null; }
    public javax.naming.Name composeName(javax.naming.Name name, javax.naming.Name prefix) { return null; }
    public String composeName(String name, String prefix) { return null; }
    public Object addToEnvironment(String propName, Object propVal) { return null; }
    public Object removeFromEnvironment(String propName) { return null; }
    public java.util.Hashtable<?, ?> getEnvironment() { return null; }
    public String getNameInNamespace() { return ""; }
    public void close() throws javax.naming.NamingException { System.out.println("  [INFO] JNDI Context closed."); }
}

class MockDataSource implements DataSource {
    public java.sql.Connection getConnection() { return null; }
    public java.sql.Connection getConnection(String username, String password) { return null; }
    public java.io.PrintWriter getLogWriter() { return null; }
    public void setLogWriter(java.io.PrintWriter out) {}
    public void setLoginTimeout(int seconds) {}
    public int getLoginTimeout() { return 0; }
    public java.util.logging.Logger getParentLogger() { return null; }
    public <T> T unwrap(java.lang.Class<T> iface) { return null; }
    public boolean isWrapperFor(java.lang.Class<?> iface) { return false; }
}




public class method_3_DataSourceFactory_QWEN {

    private static class LOG {
        public static void warn(String msg) { System.out.println("[WARN] " + msg); }
    }


// ORIGINAL CODESEARCHNET METHOD — START

public static DataSource getDataSource(final String jndiName)
            throws FactoryException3 {

        Validate.notBlank(jndiName, "The validated character sequence 'jndiName' is null or empty");

        

        try {
            
            final Context context = new MockContext(jndiName); 

            
            final Object namedObject = context.lookup(jndiName);
            if (DataSource.class.isInstance(namedObject)) {
                final DataSource dataSource = (DataSource) context.lookup(jndiName);
                context.close();

                return dataSource;
            } else {
                final String error = "The JNDI name '" + jndiName + "' does not reference a SQL DataSource."
                        + " This is a configuration issue.";
                LOG.warn(error);
                throw new FactoryException3(error);
            }
        } catch (NamingException e) {
            final String error = "Error retrieving JDBC date source from JNDI: " + jndiName;
            LOG.warn(error);
            throw new FactoryException3(error, e);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    
    private static class Validate {
        public static void notBlank(String string, String message) {
            if (string == null || string.trim().isEmpty()) throw new IllegalArgumentException(message);
        }
    }

    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 3: getDataSource - JNDI DataSource Lookup            ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            String jndiName = "java:comp/env/jdbc/MyDataSource";
            
            System.out.println("┌─ JNDI LOOKUP PROCESS ──────────────────────────────────────┐");
            System.out.println("│ Target JNDI Name: " + jndiName);
            System.out.println("│ 1. Validating JNDI name (not blank)...");
            System.out.println("│ 2. Creating InitialContext...");
            
            DataSource dataSource = getDataSource(jndiName);
            
            System.out.println("│ 3. Looking up object in context...");
            System.out.println("│ 4. Verifying object is instance of javax.sql.DataSource...");
            System.out.println("│ 5. Closing context...");
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");

            System.out.println("┌─ LOOKUP RESULT ────────────────────────────────────────────┐");
            System.out.println("│ ✓ Successfully retrieved DataSource.");
            System.out.println("│ ✓ DataSource implementation: " + dataSource.getClass().getSimpleName());
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            System.out.println("\nSUCCESS: JNDI DataSource retrieved successfully.");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}