import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;




class BeanBox2 {
    private boolean singleton = true;
    private boolean pureValue = false;
    private Object target;
    private boolean required = true;
    private Class<?> type;
    private Class<?> beanClass;
    private java.lang.reflect.Constructor<?> constructor;
    private BeanBox2[] constructorParams;
    private Method postConstruct;
    private Map<Field, BeanBox2> fieldInjects;
    private Map<Method, BeanBox2[]> methodInjects;
    private Method createMethod;
    private Method configMethod;
    private Object singletonId;
    private Object[] aopRules;
    private Object[] methodAops;

    public boolean isSingleton() { return singleton; }
    public void setSingleton(boolean s) { singleton = s; }
    public boolean isPureValue() { return pureValue; }
    public void setPureValue(boolean p) { pureValue = p; }
    public Object getTarget() { return target; }
    public void setTarget(Object t) { target = t; }
    public boolean isRequired() { return required; }
    public void setRequired(boolean r) { required = r; }
    public Class<?> getType() { return type; }
    public void setType(Class<?> t) { type = t; }
    public Class<?> getBeanClass() { return beanClass; }
    public void setBeanClass(Class<?> c) { beanClass = c; }
    public java.lang.reflect.Constructor<?> getConstructor() { return constructor; }
    public void setConstructor(java.lang.reflect.Constructor<?> c) { constructor = c; }
    public BeanBox2[] getConstructorParams() { return constructorParams; }
    public void setConstructorParams(BeanBox2[] p) { constructorParams = p; }
    public Method getPostConstruct() { return postConstruct; }
    public void setPostConstruct(Method m) { postConstruct = m; }
    public Map<Field, BeanBox2> getFieldInjects() { return fieldInjects; }
    public void setFieldInjects(Map<Field, BeanBox2> f) { fieldInjects = f; }
    public Map<Method, BeanBox2[]> getMethodInjects() { return methodInjects; }
    public void setMethodInjects(Map<Method, BeanBox2[]> m) { methodInjects = m; }
    public Method getCreateMethod() { return createMethod; }
    public void setCreateMethod(Method m) { createMethod = m; }
    public Method getConfigMethod() { return configMethod; }
    public void setConfigMethod(Method m) { configMethod = m; }
    public Object getSingletonId() { return singletonId; }
    public void setSingletonId(Object id) { singletonId = id; }
    public Object[] getAopRules() { return aopRules; }
    public Object[] getMethodAops() { return methodAops; }
}

class BeanBoxException2 extends RuntimeException {
    public BeanBoxException2(String msg) { super(msg); }
    public BeanBoxException2(String msg, Throwable t) { super(msg, t); }
    public static Object throwEX(String msg) { throw new BeanBoxException2(msg); }
    public static Object throwEX(Throwable t) { throw new BeanBoxException2(t.getMessage(), t); }
    public static Object throwEX(String msg, Throwable t) { throw new BeanBoxException2(msg, t); }
    public static void assureNotNull(Object obj, String msg) { if (obj == null) throw new BeanBoxException2(msg); }
}

class EMPTY2 {}
class Caller { public Caller(Object ctx, boolean req, Set<Object> hist, Object bean) {} }

class ReflectionUtils2 {
    public static void invokeMethod(Method m, Object bean, Object... args) {
        System.out.println("      → Executing method: " + m.getName() + "()");
    }
    public static void setField(Field f, Object bean, Object value) {
        System.out.println("      → Injected field '" + f.getName() + "' with value: " + value);
    }
}

class ValueTranslator {
    public Object translate(String val, Class<?> type) { return "Translated_" + val; }
}

class AopUtils {
    public static Object createProxyBean(Class<?> clazz, BeanBox2 box, Object ctx) {
        System.out.println("      → Created AOP Proxy for: " + clazz.getSimpleName());
        return new Object();
    }
}




public class method_2_jBeanBox_QWEN {
    private Map<BeanBox2, Object> singletonCache = new HashMap<>();
    private ValueTranslator valueTranslator = new ValueTranslator();

    private Object getBean(Object target, boolean required, Set<Object> history) { return "MockDependency"; }
    private Object notfoundOrException(Object target, boolean required) {
        return required ? BeanBoxException2.throwEX("Not found") : EMPTY2.class;
    }
    
    
    private Object[] param2RealObjects(Object ctx, Set<Object> history, BeanBox2[] params) {
        Object[] res = new Object[params.length];
        for(int i = 0; i < params.length; i++) {
            BeanBox2 p = params[i];
            if (p.getType() == int.class || p.getType() == Integer.class) {
                res[i] = 10; 
            } else {
                res[i] = "InjectedParam";
            }
        }
        return res;
    }


// ORIGINAL CODESEARCHNET METHOD — START

private Object getBeanFromBox(BeanBox2 box, boolean required, Set<Object> history) {
		BeanBoxException2.assureNotNull(box, "Fail to build instance for a null beanBox");
		Object bean = null;
		if (box.isSingleton()) { 
			bean = singletonCache.get(box);
			if (bean != null)
				return bean;
		}

		if (box.isPureValue()) 
			return box.getTarget();
		if (box.getTarget() != null) {
			if (EMPTY2.class != box.getTarget())
				return getBean(box.getTarget(), box.isRequired(), history);
			if (box.getType() != null)
				return getBean(box.getType(), box.isRequired(), history);
			else
				return notfoundOrException(box.getTarget(), box.isRequired());
		}

		boolean aopFound = false;
		if (box.getAopRules() != null || box.getMethodAops() != null)
			aopFound = true;
		else if (this.getAopRules() != null && box.getBeanClass() != null)
			for (Object[] aops : this.getAopRules()) 
				if (BeanBoxUtils2.nameMatch((String) aops[1], box.getBeanClass().getName())) {
					aopFound = true;
					break;
				}
		if (aopFound)
			bean = AopUtils.createProxyBean(box.getBeanClass(), box, this);
		else if (box.getCreateMethod() != null) 
			try {
				Method m = box.getCreateMethod();
				if (m.getParameterTypes().length == 1) {
					bean = m.invoke(box, new Caller(this, required, history, null));
				} else if (m.getParameterTypes().length == 0)
					bean = m.invoke(box);
				else
					BeanBoxException2.throwEX("Create method can only have 0 or 1 parameter");
				BeanBoxException2.assureNotNull(bean, "Create method created a null object.");
			} catch (Exception e) {
				return BeanBoxException2.throwEX(e);
			}
		else if (box.getConstructor() != null) { 
			if (box.getConstructorParams() != null && box.getConstructorParams().length > 0) {
				Object[] initargs = param2RealObjects(this, history, box.getConstructorParams());
				try {
					bean = box.getConstructor().newInstance(initargs);
				} catch (Exception e) {
					return BeanBoxException2.throwEX(e);
				}
			} else 
				try {
					bean = box.getConstructor().newInstance();
				} catch (Exception e) {
					return BeanBoxException2.throwEX(e);
				}
		} else if (box.getBeanClass() != null) { 
			if (EMPTY2.class == box.getBeanClass())
				return notfoundOrException(EMPTY2.class, required);
			try {
				bean = box.getBeanClass().newInstance();
			} catch (Exception e) {
				BeanBoxException2.throwEX("Failed to call 0 parameter constructor of: " + box.getBeanClass(), e);
			}
		} else
			return notfoundOrException(null, required); 

		
		if (box.isSingleton()) {
			Object id = box.getSingletonId();
			if (id != null)
				singletonCache.put(box, bean);
		} 

		if (box.getConfigMethod() != null) {
			try {
				Method m = box.getConfigMethod();
				if (m.getParameterTypes().length == 2)
					m.invoke(box, bean, new Caller(this, required, history, bean));
				else if (m.getParameterTypes().length == 1)
					m.invoke(box, bean);
				else
					BeanBoxException2.throwEX("Config method can only have 1 or 2 parameters");
			} catch (Exception e) {
				return BeanBoxException2.throwEX(e);
			}
		}

		if (box.getPostConstruct() != null) 
			ReflectionUtils2.invokeMethod(box.getPostConstruct(), bean);

		if (box.getFieldInjects() != null) 
			for (Entry<Field, BeanBox2> entry : box.getFieldInjects().entrySet()) {
				Field f = entry.getKey();
				BeanBox2 b = entry.getValue();
				Object fieldValue = this.getBeanFromBox(b, false, history);
				if (EMPTY2.class == fieldValue) {
					if (b.isRequired())
						BeanBoxException2.throwEX("Not found required value for field: " + f.getName() + " in "
								+ f.getDeclaringClass().getName());
				} else {
					if (fieldValue != null && fieldValue instanceof String)
						fieldValue = this.valueTranslator.translate((String) fieldValue, b.getType());
					ReflectionUtils2.setField(f, bean, fieldValue);
				}
			}

		if (box.getMethodInjects() != null) { 
			for (Entry<Method, BeanBox2[]> methods : box.getMethodInjects().entrySet()) {
				Method m = methods.getKey();
				BeanBox2[] paramBoxs = methods.getValue();
				if (paramBoxs != null && paramBoxs.length > 0) {
					Object[] methodParams = param2RealObjects(this, history, paramBoxs);
					ReflectionUtils2.invokeMethod(m, bean, methodParams);
				} else 
					ReflectionUtils2.invokeMethod(m, bean);
			}
		}
		return bean;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public Object[][] getAopRules() { return null; }

    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 2: getBeanFromBox - Bean Lifecycle Instantiation     ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            method_2_jBeanBox_QWEN context = new method_2_jBeanBox_QWEN();
            
            BeanBox2 box = new BeanBox2();
            box.setBeanClass(java.util.ArrayList.class);
            box.setSingleton(true);
            box.setSingletonId("listBean");
            
            box.setConstructor(java.util.ArrayList.class.getConstructor(int.class));
            BeanBox2 paramBox = new BeanBox2();
            paramBox.setTarget(10);
            paramBox.setPureValue(true);
            paramBox.setType(int.class); 
            box.setConstructorParams(new BeanBox2[]{paramBox});

            System.out.println("┌─ BEAN INSTANTIATION LIFECYCLE ─────────────────────────────┐");
            System.out.println("│ 1. Checking singleton cache... (Miss)");
            System.out.println("│ 2. Instantiating via constructor: ArrayList(int)");
            
            Object bean = context.getBeanFromBox(box, true, new HashSet<>());
            
            System.out.println("│ 3. Caching singleton instance (ID: listBean)");
            System.out.println("│ 4. Executing lifecycle callbacks & injections...");
            System.out.println("│");
            System.out.println("│ ✓ Bean successfully created: " + bean.getClass().getSimpleName());
            System.out.println("│ ✓ Instance identity: " + System.identityHashCode(bean));
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
        }
    }
}

class BeanBoxUtils2 {
    public static boolean nameMatch(String rule, String name) { return true; }
}