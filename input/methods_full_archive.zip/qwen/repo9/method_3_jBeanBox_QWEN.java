import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




class Value {}

class Type {
    public static Type getReturnType(String desc) { return new Type(); }
    public static Type[] getArgumentTypes(String desc) { return new Type[0]; }
    public static Type getObjectType(String name) { return new Type(); }
    public int getSize() { return 1; }
}

class Interpreter<V extends Value> {
    public V newValue(Type type) { return null; }
}

class Frame<V extends Value> {
    public void setReturn(V v) {}
    public void setLocal(int i, V v) {}
    public Frame<V> init(Frame<V> f) { return this; }
    public void execute(AbstractInsnNode insn, Interpreter<V> interp) {}
    public void clearStack() {}
    public void push(V v) {}
}

class Subroutine {
    public LabelNode start;
    public boolean[] access;
    public List<JumpInsnNode> callers = new ArrayList<>();
    public Subroutine(LabelNode start, int maxLocals, JumpInsnNode caller) {
        this.start = start;
        this.access = new boolean[maxLocals];
        if (caller != null) callers.add(caller);
    }
    public Subroutine copy() { return this; }
}

class InsnList {
    private List<AbstractInsnNode> nodes = new ArrayList<>();
    public void add(AbstractInsnNode n) { nodes.add(n); }
    public int size() { return nodes.size(); }
    public AbstractInsnNode get(int i) { return nodes.get(i); }
    public int indexOf(AbstractInsnNode n) { return nodes.indexOf(n); }
}

class AbstractInsnNode {
    public static final int LABEL = 0, LINE = 1, FRAME = 2, INSN = 3, JUMP = 4;
    public int type;
    public AbstractInsnNode(int type) { this.type = type; }
    public int getOpcode() { return -1; }
    public int getType() { return type; }
}

class LabelNode extends AbstractInsnNode {
    public LabelNode() { super(LABEL); }
}

class JumpInsnNode extends AbstractInsnNode {
    public LabelNode label;
    public JumpInsnNode(int opcode, LabelNode label) { super(JUMP); this.label = label; }
}


class LookupSwitchInsnNode extends AbstractInsnNode {
    public LabelNode dflt;
    public List<LabelNode> labels = new ArrayList<>();
    public LookupSwitchInsnNode(LabelNode dflt) { super(INSN); this.dflt = dflt; }
}

class TableSwitchInsnNode extends AbstractInsnNode {
    public LabelNode dflt;
    public List<LabelNode> labels = new ArrayList<>();
    public TableSwitchInsnNode(LabelNode dflt) { super(INSN); this.dflt = dflt; }
}

class VarInsnNode extends AbstractInsnNode {
    public int var;
    public VarInsnNode(int opcode, int var) { super(INSN); this.var = var; }
}

class IincInsnNode extends AbstractInsnNode {
    public int var;
    public IincInsnNode(int var, int incr) { super(INSN); this.var = var; }
}

class TryCatchBlockNode {
    public LabelNode start, end, handler;
    public String type;
}

class MethodNode {
    public int access;
    public int maxLocals, maxStack;
    public String desc;
    public InsnList instructions = new InsnList();
    public List<TryCatchBlockNode> tryCatchBlocks = new ArrayList<>();
    public static final int ACC_ABSTRACT = 0x0400, ACC_NATIVE = 0x0100, ACC_STATIC = 0x0008;
}

class AnalyzerException extends Exception {
    public Object node;
    public AnalyzerException(Object node, String msg) { super(msg); this.node = node; }
    public AnalyzerException(Object node, String msg, Throwable t) { super(msg, t); this.node = node; }
}

class Opcodes {
    public static final int GOTO = 167, JSR = 168, RET = 169, ATHROW = 191;
    public static final int IRETURN = 172, RETURN = 177;
    public static final int LLOAD = 22, DLOAD = 24, LSTORE = 55, DSTORE = 57;
}




public class method_3_jBeanBox_QWEN<V extends Value> {
    int n;
    InsnList insns;
    List<TryCatchBlockNode>[] handlers;
    Frame<V>[] frames;
    Subroutine[] subroutines;
    boolean[] queued;
    int[] queue;
    int top;
    Interpreter<V> interpreter = new Interpreter<>();

    void findSubroutine(int i, Subroutine sub, List<AbstractInsnNode> calls) {}
    void init(String owner, MethodNode m) {}
    void merge(int i, Frame<V> f, Subroutine sub) {}
    void merge(int i, Frame<V> f, Frame<V> f2, Subroutine sub, boolean[] access) {}
    void newControlFlowEdge(int i, int j) {}
    boolean newControlFlowExceptionEdge(int i, TryCatchBlockNode tcb) { return true; }
    Frame<V> newFrame(int locals, int stack) { return new Frame<>(); }


// ORIGINAL CODESEARCHNET METHOD — START

public Frame<V>[] analyze(final String owner, final MethodNode m)
            throws AnalyzerException {
        if ((m.access & (MethodNode.ACC_ABSTRACT | MethodNode.ACC_NATIVE)) != 0) {
            frames = (Frame<V>[]) new Frame<?>[0];
            return frames;
        }
        n = m.instructions.size();
        insns = m.instructions;
        handlers = (List<TryCatchBlockNode>[]) new List<?>[n];
        frames = (Frame<V>[]) new Frame<?>[n];
        subroutines = new Subroutine[n];
        queued = new boolean[n];
        queue = new int[n];
        top = 0;

        
        for (int i = 0; i < m.tryCatchBlocks.size(); ++i) {
            TryCatchBlockNode tcb = m.tryCatchBlocks.get(i);
            int begin = insns.indexOf(tcb.start);
            int end = insns.indexOf(tcb.end);
            for (int j = begin; j < end; ++j) {
                List<TryCatchBlockNode> insnHandlers = handlers[j];
                if (insnHandlers == null) {
                    insnHandlers = new ArrayList<TryCatchBlockNode>();
                    handlers[j] = insnHandlers;
                }
                insnHandlers.add(tcb);
            }
        }

        
        Subroutine main = new Subroutine(null, m.maxLocals, null);
        List<AbstractInsnNode> subroutineCalls = new ArrayList<AbstractInsnNode>();
        Map<LabelNode, Subroutine> subroutineHeads = new HashMap<LabelNode, Subroutine>();
        findSubroutine(0, main, subroutineCalls);
        while (!subroutineCalls.isEmpty()) {
            JumpInsnNode jsr = (JumpInsnNode) subroutineCalls.remove(0);
            Subroutine sub = subroutineHeads.get(jsr.label);
            if (sub == null) {
                sub = new Subroutine(jsr.label, m.maxLocals, jsr);
                subroutineHeads.put(jsr.label, sub);
                findSubroutine(insns.indexOf(jsr.label), sub, subroutineCalls);
            } else {
                sub.callers.add(jsr);
            }
        }
        for (int i = 0; i < n; ++i) {
            if (subroutines[i] != null && subroutines[i].start == null) {
                subroutines[i] = null;
            }
        }

        
        Frame<V> current = newFrame(m.maxLocals, m.maxStack);
        Frame<V> handler = newFrame(m.maxLocals, m.maxStack);
        current.setReturn(interpreter.newValue(Type.getReturnType(m.desc)));
        Type[] args = Type.getArgumentTypes(m.desc);
        int local = 0;
        if ((m.access & MethodNode.ACC_STATIC) == 0) {
            Type ctype = Type.getObjectType(owner);
            current.setLocal(local++, interpreter.newValue(ctype));
        }
        for (int i = 0; i < args.length; ++i) {
            current.setLocal(local++, interpreter.newValue(args[i]));
            if (args[i].getSize() == 2) {
                current.setLocal(local++, interpreter.newValue(null));
            }
        }
        while (local < m.maxLocals) {
            current.setLocal(local++, interpreter.newValue(null));
        }
        merge(0, current, null);

        init(owner, m);

        
        while (top > 0) {
            int insn = queue[--top];
            Frame<V> f = frames[insn];
            Subroutine subroutine = subroutines[insn];
            queued[insn] = false;

            AbstractInsnNode insnNode = null;
            try {
                insnNode = m.instructions.get(insn);
                int insnOpcode = insnNode.getOpcode();
                int insnType = insnNode.getType();

                if (insnType == AbstractInsnNode.LABEL
                        || insnType == AbstractInsnNode.LINE
                        || insnType == AbstractInsnNode.FRAME) {
                    merge(insn + 1, f, subroutine);
                    newControlFlowEdge(insn, insn + 1);
                } else {
                    current.init(f).execute(insnNode, interpreter);
                    subroutine = subroutine == null ? null : subroutine.copy();

                    if (insnNode instanceof JumpInsnNode) {
                        JumpInsnNode j = (JumpInsnNode) insnNode;
                        if (insnOpcode != Opcodes.GOTO && insnOpcode != Opcodes.JSR) {
                            merge(insn + 1, current, subroutine);
                            newControlFlowEdge(insn, insn + 1);
                        }
                        int jump = insns.indexOf(j.label);
                        if (insnOpcode == Opcodes.JSR) {
                            merge(jump, current, new Subroutine(j.label,
                                    m.maxLocals, j));
                        } else {
                            merge(jump, current, subroutine);
                        }
                        newControlFlowEdge(insn, jump);
                    } else if (insnNode instanceof LookupSwitchInsnNode) {
                        LookupSwitchInsnNode lsi = (LookupSwitchInsnNode) insnNode;
                        int jump = insns.indexOf(lsi.dflt);
                        merge(jump, current, subroutine);
                        newControlFlowEdge(insn, jump);
                        for (int j = 0; j < lsi.labels.size(); ++j) {
                            LabelNode label = lsi.labels.get(j);
                            jump = insns.indexOf(label);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                        }
                    } else if (insnNode instanceof TableSwitchInsnNode) {
                        TableSwitchInsnNode tsi = (TableSwitchInsnNode) insnNode;
                        int jump = insns.indexOf(tsi.dflt);
                        merge(jump, current, subroutine);
                        newControlFlowEdge(insn, jump);
                        for (int j = 0; j < tsi.labels.size(); ++j) {
                            LabelNode label = tsi.labels.get(j);
                            jump = insns.indexOf(label);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
        }
                    } else if (insnOpcode == Opcodes.RET) {
                        if (subroutine == null) {
                            throw new AnalyzerException(insnNode,
                                    "RET instruction outside of a sub routine");
                        }
                        for (int i = 0; i < subroutine.callers.size(); ++i) {
                            JumpInsnNode caller = subroutine.callers.get(i);
                            int call = insns.indexOf(caller);
                            if (frames[call] != null) {
                                merge(call + 1, frames[call], current,
                                        subroutines[call], subroutine.access);
                                newControlFlowEdge(insn, call + 1);
                            }
                        }
                    } else if (insnOpcode != Opcodes.ATHROW
                            && (insnOpcode < Opcodes.IRETURN || insnOpcode > Opcodes.RETURN)) {
                        if (subroutine != null) {
                            if (insnNode instanceof VarInsnNode) {
                                int var = ((VarInsnNode) insnNode).var;
                                subroutine.access[var] = true;
                                if (insnOpcode == Opcodes.LLOAD || insnOpcode == Opcodes.DLOAD
                                        || insnOpcode == Opcodes.LSTORE
                                        || insnOpcode == Opcodes.DSTORE) {
                                    subroutine.access[var + 1] = true;
                                }
                            } else if (insnNode instanceof IincInsnNode) {
                                int var = ((IincInsnNode) insnNode).var;
                                subroutine.access[var] = true;
                            }
                        }
                        merge(insn + 1, current, subroutine);
                        newControlFlowEdge(insn, insn + 1);
                    }
                }

                List<TryCatchBlockNode> insnHandlers = handlers[insn];
                if (insnHandlers != null) {
                    for (int i = 0; i < insnHandlers.size(); ++i) {
                        TryCatchBlockNode tcb = insnHandlers.get(i);
                        Type type;
                        if (tcb.type == null) {
                            type = Type.getObjectType("java/lang/Throwable");
                        } else {
                            type = Type.getObjectType(tcb.type);
                        }
                        int jump = insns.indexOf(tcb.handler);
                        if (newControlFlowExceptionEdge(insn, tcb)) {
                            handler.init(f);
                            handler.clearStack();
                            handler.push(interpreter.newValue(type));
                            merge(jump, handler, subroutine);
                        }
                    }
                }
            } catch (AnalyzerException e) {
                throw new AnalyzerException(e.node, "Error at instruction "
                        + insn + ": " + e.getMessage(), e);
            } catch (Exception e) {
                throw new AnalyzerException(insnNode, "Error at instruction "
                        + insn + ": " + e.getMessage(), e);
            }
        }

        return frames;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 3: Analyzer.analyze - Bytecode Control Flow Analysis ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            method_3_jBeanBox_QWEN<Value> analyzer = new method_3_jBeanBox_QWEN<>();
            
            MethodNode mockMethod = new MethodNode();
            mockMethod.access = 0;
            mockMethod.maxLocals = 2;
            mockMethod.maxStack = 1;
            mockMethod.desc = "()V";
            
            mockMethod.instructions.add(new LabelNode());
            mockMethod.instructions.add(new LabelNode());
            mockMethod.instructions.add(new LabelNode());

            System.out.println("┌─ BYTECODE ANALYSIS PROCESS ────────────────────────────────┐");
            System.out.println("│ Target Method: mockMethod()V");
            System.out.println("│ Max Locals: " + mockMethod.maxLocals + " | Max Stack: " + mockMethod.maxStack);
            System.out.println("│ Instructions count: " + mockMethod.instructions.size());
            System.out.println("│");
            
            Frame<?>[] frames = analyzer.analyze("com/example/TargetClass", mockMethod);
            
            System.out.println("│ ✓ Exception handlers mapped: " + (analyzer.handlers != null ? "Yes" : "No"));
            System.out.println("│ ✓ Subroutine analysis completed: 0 JSR calls detected");
            System.out.println("│ ✓ Control flow frames generated: " + frames.length);
            System.out.println("│");
            System.out.println("│ SUCCESS: Method bytecode analyzed without AnalyzerException.");
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
        }
    }
}