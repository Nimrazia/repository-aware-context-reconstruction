import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;




@Retention(RetentionPolicy.RUNTIME) @interface PROTOTYPE {}
@Retention(RetentionPolicy.RUNTIME) @interface AOP { Class<?> value(); String method() default ""; }
@Retention(RetentionPolicy.RUNTIME) @interface POSTCONSTRUCT {}
@Retention(RetentionPolicy.RUNTIME) @interface PREDESTROY {}
@Retention(RetentionPolicy.RUNTIME) @interface INJECT { String value() default ""; boolean required() default true; }
@Retention(RetentionPolicy.RUNTIME) @interface PostConstruct {}
@Retention(RetentionPolicy.RUNTIME) @interface PreDestroy {}

class EMPTY {}

class BeanBoxException extends RuntimeException {
    public BeanBoxException(String msg) { super(msg); }
    public BeanBoxException(String msg, Throwable t) { super(msg, t); }
    public static void throwEX(String msg) { throw new BeanBoxException(msg); }
    public static void throwEX(Throwable t) { throw new BeanBoxException(t.getMessage(), t); }
    public static void assureNotNull(Object obj, String msg) { if (obj == null) throwEX(msg); }
}




class BeanBox {
    private Class<?> beanClass;
    private boolean singleton = true;
    private boolean pureValue = false;
    private Object target;
    private boolean required = true;
    private Class<?> type; 
    private Constructor<?> constructor;
    private BeanBox[] constructorParams;
    private Map<Field, BeanBox> fieldInjects;
    private Map<Method, BeanBox[]> methodInjects;
    private Method postConstruct;
    private Method preDestroy;
    private List<Object[]> beanAops = new ArrayList<>();
    private List<Object[]> methodAops = new ArrayList<>();

    public void setBeanClass(Class<?> c) { this.beanClass = c; }
    public Class<?> getBeanClass() { return beanClass; }
    public void setSingleton(boolean s) { this.singleton = s; }
    public boolean isSingleton() { return singleton; }
    public void setPureValue(boolean p) { this.pureValue = p; }
    public boolean isPureValue() { return pureValue; }
    public void setTarget(Object t) { this.target = t; }
    public Object getTarget() { return target; }
    public void setRequired(boolean r) { this.required = r; }
    public boolean isRequired() { return required; }
    public void setType(Class<?> t) { this.type = t; } 
    public Class<?> getType() { return type; } 
    public void setConstructor(Constructor<?> c) { this.constructor = c; }
    public Constructor<?> getConstructor() { return constructor; }
    public void setConstructorParams(BeanBox[] params) { this.constructorParams = params; }
    public BeanBox[] getConstructorParams() { return constructorParams; }
    public void checkOrCreateFieldInjects() { if (fieldInjects == null) fieldInjects = new HashMap<>(); }
    public Map<Field, BeanBox> getFieldInjects() { return fieldInjects; }
    public void checkOrCreateMethodInjects() { if (methodInjects == null) methodInjects = new HashMap<>(); }
    public Map<Method, BeanBox[]> getMethodInjects() { return methodInjects; }
    public void setPostConstruct(Method m) { this.postConstruct = m; }
    public Method getPostConstruct() { return postConstruct; }
    public void setPreDestroy(Method m) { this.preDestroy = m; }
    public Method getPreDestroy() { return preDestroy; }
    public void addBeanAop(Object aop, String rule) { beanAops.add(new Object[]{aop, rule}); }
    public void addMethodAop(Object aop, Method m) { methodAops.add(new Object[]{aop, m}); }
}

class BeanBoxContext {
    public boolean allowSpringJsrAnnotation = true;
    public boolean isAllowAnnotation() { return true; }
}

class ReflectionUtils {
    public static Field[] getSelfAndSuperClassFields(Class<?> clazz) { return clazz.getDeclaredFields(); }
    public static Method[] getAllDeclaredMethods(Class<?> clazz) { return clazz.getDeclaredMethods(); }
    public static void makeAccessible(Field f) {}
    public static void makeAccessible(Method m) {}
}




public class method_1_jBeanBox_QWEN {

    private static boolean checkAnnoExist(Class<?> clazz, Class<? extends Annotation> annoClass) {
        return clazz.isAnnotationPresent(annoClass);
    }
    private static Map<String, Object> getAnnoAsMap(Class<?> clazz, String annoName) { return null; }
    
    private static Object[] getInjectAnnotationAsArray(Object member, boolean allowSpring) {
        if (member instanceof Class && ((Class<?>) member).isAnnotationPresent(INJECT.class)) {
            return new Object[]{((Class<?>) member).getAnnotation(INJECT.class).value(), false, ((Class<?>) member).getAnnotation(INJECT.class).required()};
        }
        if (member instanceof Field && ((Field) member).isAnnotationPresent(INJECT.class)) {
            return new Object[]{((Field) member).getAnnotation(INJECT.class).value(), false, ((Field) member).getAnnotation(INJECT.class).required()};
        }
        if (member instanceof Method && ((Method) member).isAnnotationPresent(INJECT.class)) {
            return new Object[]{((Method) member).getAnnotation(INJECT.class).value(), false, ((Method) member).getAnnotation(INJECT.class).required()};
        }
        return null;
    }
    
    private static Map<String, Object> changeAnnotationValuesToMap(Annotation anno) {
        Map<String, Object> map = new HashMap<>();
        map.put("value", String.class);
        map.put("method", "execute*");
        return map;
    }
    
    private static BeanBox[] getParameterInjectAsBeanBoxArray(Object member, boolean allowSpring) {
        return new BeanBox[0];
    }


// ORIGINAL CODESEARCHNET METHOD — START

private static BeanBox doCreateBeanBox(BeanBoxContext ctx, Class<?> clazz) {
		BeanBox box = new BeanBox();
		box.setBeanClass(clazz);
		box.setSingleton(true);

		if (!ctx.isAllowAnnotation())
			return box;
		boolean allowSpringJsrAnno = ctx.allowSpringJsrAnnotation;

		
		if (checkAnnoExist(clazz, PROTOTYPE.class))
			box.setSingleton(false);
		else if (allowSpringJsrAnno) {
			Map<String, Object> m = getAnnoAsMap(clazz, "org.springframework.context.annotation.Scope");
			if (m != null)
				for (Entry<String, Object> entry : m.entrySet())
					if ("value".equals(entry.getKey())) {
						if ("prototype".equalsIgnoreCase(String.valueOf(entry.getValue())))
							box.setSingleton(false);
						else if ("singleton".equalsIgnoreCase(String.valueOf(entry.getValue())))
							box.setSingleton(true);
						else
							BeanBoxException.throwEX("'prototype' or 'singleton' required in @Scope annotation");
					}
		}

		
		Object[] v = getInjectAnnotationAsArray(clazz, allowSpringJsrAnno);
		if (v != null) {
			box.setTarget(v[0]);
			box.setPureValue((Boolean) v[1]);
			box.setRequired((Boolean) v[2]);
		}

		
		Annotation[] annos = clazz.getAnnotations();
		for (Annotation anno : annos) {
			if (anno.annotationType().isAnnotationPresent(AOP.class)) {
				Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
				Object aop = annoMap.get("value");
				String methodNameRule = (String) annoMap.get("method");
				if (methodNameRule != null && methodNameRule.length() > 0 && aop != null)
					box.addBeanAop(aop, methodNameRule);
			}
		}

		
		Constructor<?>[] constrs = clazz.getConstructors();
		for (Constructor<?> constr : constrs) {
			v = getInjectAnnotationAsArray(constr, allowSpringJsrAnno);
			if (v != null) {
				box.setBeanClass(clazz);
				if (v[0] != null && EMPTY.class != v[0]) {
					BeanBox inject = new BeanBox();
					inject.setTarget(v[0]);
					inject.setPureValue((Boolean) v[1]);
					inject.setRequired((Boolean) v[2]);
					inject.setType(constr.getParameterTypes()[0]);
					box.setConstructor(constr);
					box.setConstructorParams(new BeanBox[] { inject });
				} else { 
					BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(constr, allowSpringJsrAnno);
					box.setConstructor(constr);
					box.setConstructorParams(paramInjects);
				}
			}
		}

		
		
		for (Field f : ReflectionUtils.getSelfAndSuperClassFields(clazz)) {
			v = getInjectAnnotationAsArray(f, allowSpringJsrAnno);
			if (v != null) {
				box.checkOrCreateFieldInjects();
				BeanBox inject = new BeanBox();
				inject.setTarget(v[0]);
				inject.setPureValue((Boolean) v[1]);
				inject.setRequired((Boolean) v[2]);
				inject.setType(f.getType());
				ReflectionUtils.makeAccessible(f);
				box.getFieldInjects().put(f, inject);
			}
		}

		
		Method[] methods = ReflectionUtils.getAllDeclaredMethods(clazz); 
		for (Method m : methods) { 
			
			if (m.getAnnotation(POSTCONSTRUCT.class) != null || m.getAnnotation(PostConstruct.class) != null) {
				if (m.getParameterTypes().length > 0)
					BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
				ReflectionUtils.makeAccessible(m);
				box.setPostConstruct(m);
			}
			if (m.getAnnotation(PREDESTROY.class) != null || m.getAnnotation(PreDestroy.class) != null) {
				if (m.getParameterTypes().length > 0)
					BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
				ReflectionUtils.makeAccessible(m);
				box.setPreDestroy(m);
			}

			
			Annotation[] mtdAnnos = m.getAnnotations();
			for (Annotation anno : mtdAnnos)
				if (anno.annotationType().isAnnotationPresent(AOP.class)) {
					Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
					Object aop = annoMap.get("value");
					if (aop != null)
						box.addMethodAop(aop, m);
				}

			
			v = getInjectAnnotationAsArray(m, allowSpringJsrAnno);
			if (v != null) {
				ReflectionUtils.makeAccessible(m);
				BeanBox oneParam = new BeanBox();
				oneParam.setTarget(v[0]);
				oneParam.setPureValue((Boolean) v[1]);
				oneParam.setRequired((Boolean) v[2]);
				boolean haveOneParameter = v[0] != null && EMPTY.class != v[0];
				if (haveOneParameter)
					oneParam.setType(m.getParameterTypes()[0]); 
				
				box.checkOrCreateMethodInjects();
				if (haveOneParameter) 
					box.getMethodInjects().put(m, new BeanBox[] { oneParam });
				else { 
					BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(m, allowSpringJsrAnno);
					box.getMethodInjects().put(m, paramInjects);
				}
			}
		}
		return box;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 1: doCreateBeanBox - DI Metadata Parsing             ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        @AOP(value = String.class, method = "execute*")
        class MockService {
            @INJECT(value = "mockDb", required = true)
            private String database;
            public MockService(@INJECT(value = "defaultConfig") String config) {}
            @POSTCONSTRUCT
            public void init() {}
            @INJECT
            public void setDatabase(String db) {}
        }

        try {
            BeanBoxContext ctx = new BeanBoxContext();
            System.out.println("┌─ PARSING CLASS METADATA ─────────────────────────────────────┐");
            System.out.println("│ Target Class: " + MockService.class.getName());
            
            BeanBox box = doCreateBeanBox(ctx, MockService.class);
            
            System.out.println("│");
            System.out.println("│ ✓ Singleton: " + box.isSingleton());
            System.out.println("│ ✓ Constructor Injection: " + (box.getConstructor() != null ? "Yes (" + box.getConstructor().getParameterCount() + " params)" : "No"));
            System.out.println("│ ✓ Field Injections: " + (box.getFieldInjects() != null ? box.getFieldInjects().size() : 0));
            System.out.println("│ ✓ Method Injections: " + (box.getMethodInjects() != null ? box.getMethodInjects().size() : 0));
            System.out.println("│ ✓ PostConstruct Method: " + (box.getPostConstruct() != null ? box.getPostConstruct().getName() : "None"));
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            System.out.println("\nSUCCESS: BeanBox metadata extracted successfully.");
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
        }
    }
}