import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_3_jeppetto_QWEN {

    private String rangeKeyField = "rangeKey";
    private String hashKeyField = "hashKey";

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private Map<String, Map<String, IndexData>> processIndexes(TableDescription tableDescription,
                                                               ProjectionExpressionBuilder projectionExpressionBuilder,
                                                               IndexData baseIndexData) {
        
        Map<String, IndexData> localIndexes;
        List<LocalSecondaryIndexDescription> localSecondaryIndexes = tableDescription.getLocalSecondaryIndexes();
        if (localSecondaryIndexes != null) {
            localIndexes = new HashMap<>(localSecondaryIndexes.size() + 2);

            
            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);

            for (LocalSecondaryIndexDescription description : localSecondaryIndexes) {
                String indexField = getKeyAttributeNames(description.getKeySchema()).getSecond();
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>(baseIndexData.keyFields);
                keyFields.add(indexField);

                localIndexes.put(indexField, new IndexData(description.getIndexName(), keyFields, projectsOverEntity));
            }
        } else if (rangeKeyField != null) {
            localIndexes = new HashMap<>(2);

            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);
        } else {
            localIndexes = Collections.singletonMap(null, baseIndexData);
        }

        
        List<GlobalSecondaryIndexDescription> globalSecondaryIndexes = tableDescription.getGlobalSecondaryIndexes();
        if (globalSecondaryIndexes != null) {
            Map<String, Map<String, IndexData>> indexes = new HashMap<>(globalSecondaryIndexes.size() + 1);

            for (GlobalSecondaryIndexDescription description : globalSecondaryIndexes) {
                Pair<String, String> indexFields = getKeyAttributeNames(description.getKeySchema());
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>();
                keyFields.add(indexFields.getFirst());
                if (indexFields.getSecond() != null) {
                    keyFields.add(indexFields.getSecond());
                }
                keyFields.add(hashKeyField);
                if (rangeKeyField != null) {
                    keyFields.add(rangeKeyField);
                }

                IndexData indexData = new IndexData(description.getIndexName(), keyFields, projectsOverEntity);

                if (!indexes.containsKey(indexFields.getFirst())) {
                    indexes.put(indexFields.getFirst(), new HashMap<String, IndexData>());
                }

                indexes.get(indexFields.getFirst()).put(indexFields.getSecond(), indexData);

                
                
                IndexData noRangeKeyIndexData = indexes.get(indexFields.getFirst()).get(null);
                if (noRangeKeyIndexData == null || !noRangeKeyIndexData.projectsOverEntity) {
                    indexes.get(indexFields.getFirst()).put(null, indexData);
                }
            }

            indexes.put(hashKeyField, localIndexes);

            return indexes;
        } else {
            return Collections.singletonMap(hashKeyField, localIndexes);
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== Jeppetto DynamoDBQueryModelDAO.processIndexes Test ===");
        method_3_jeppetto_QWEN dao = new method_3_jeppetto_QWEN();
        
        TableDescription tableDesc = new TableDescription();
        ProjectionExpressionBuilder builder = new ProjectionExpressionBuilder();
        IndexData baseData = new IndexData("baseIndex", new ArrayList<>(), true);
        
        try {
            System.out.println("Invoking processIndexes...");
            Map<String, Map<String, IndexData>> result = dao.processIndexes(tableDesc, builder, baseData);
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Result map size: " + result.size());
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    

    private Pair<String, String> getKeyAttributeNames(List<KeySchemaElement> keySchema) {
        return new Pair<>("hashKey", "rangeKey");
    }

    
    public static class TableDescription {
        public List<LocalSecondaryIndexDescription> getLocalSecondaryIndexes() { 
            return new ArrayList<>(); 
        }
        public List<GlobalSecondaryIndexDescription> getGlobalSecondaryIndexes() { 
            return new ArrayList<>(); 
        }
    }

    public static class LocalSecondaryIndexDescription {
        public List<KeySchemaElement> getKeySchema() { 
            return new ArrayList<>(); 
        }
        public Projection getProjection() { 
            return new Projection(); 
        }
        public String getIndexName() { 
            return "localIndexName"; 
        }
    }

    public static class GlobalSecondaryIndexDescription extends LocalSecondaryIndexDescription {
        @Override
        public String getIndexName() { 
            return "globalIndexName"; 
        }
    }

    public static class KeySchemaElement {}

    public static class Projection {
        public String getProjectionType() { 
            return "ALL"; 
        }
    }

    public static class ProjectionExpressionBuilder {
        public boolean isCoveredBy(Projection projection) { 
            return false; 
        }
    }

    public static class IndexData {
        public List<String> keyFields;
        public boolean projectsOverEntity;
        private String indexName;

        public IndexData(String indexName, List<String> keyFields, boolean projectsOverEntity) {
            this.indexName = indexName;
            this.keyFields = keyFields;
            this.projectsOverEntity = projectsOverEntity;
        }
        
        public String getIndexName() { return indexName; }
    }

    
    public static class Pair<A, B> {
        private A first;
        private B second;

        public Pair(A first, B second) {
            this.first = first;
            this.second = second;
        }

        public A getFirst() { return first; }
        public B getSecond() { return second; }
    }
}