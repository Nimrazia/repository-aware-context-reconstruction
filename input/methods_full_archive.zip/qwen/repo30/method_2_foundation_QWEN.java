import java.util.Collection;


class Layout {}
class Level {
    static final Level INFO=new Level(20000); private final int value; Level(int v){value=v;}
    boolean isGreaterOrEqual(Level other){return value>=other.value;}
}
class MDC {
    private static final java.util.Map<String,Object> MAP=new java.util.HashMap<>();
    static Object get(String k){return MAP.get(k);} static void put(String k,Object v){MAP.put(k,v);} static void remove(String k){MAP.remove(k);}
}
class Logger {
    static Logger getLogger(Class<?> c){return new Logger();} Level getEffectiveLevel(){return Level.INFO;}
}
class LoggingEvent { LoggingEvent(String fqcn, Logger logger, Level level, Object msg, Throwable t){} }
class FileAppender {
    private Layout layout; public Layout getLayout(){return layout;} public void setLayout(Layout l){layout=l;}
}

public class method_2_foundation_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private void logState(final FileRollEvent fileRollEvent) {


            
            synchronized (this) {
                
                final Collection<ApplicationState.ApplicationStateMessage> entries = ApplicationState.getAppStateEntries();
                for (ApplicationState.ApplicationStateMessage entry : entries) {
                    Level level = ApplicationState.getLog4jLevel(entry.getLevel());
                    if(level.isGreaterOrEqual(ApplicationState.LOGGER.getEffectiveLevel())) {
                        final LoggingEvent loggingEvent = new LoggingEvent(ApplicationState.FQCN, ApplicationState.LOGGER, level, entry.getMessage(), null);

                        
                        Layout current=fileRollEvent.getSource().getLayout();
                        
                        String flowContext = (String) MDC.get("flowCtxt");
                        MDC.remove("flowCtxt");
                        
                        if(fileRollEvent.getSource().isAddApplicationState() && fileRollEvent.getSource().getFile().endsWith("log")){
                            fileRollEvent.dispatchToAppender(loggingEvent);
                        }
                        
                        fileRollEvent.getSource().setLayout(current);
                        if (flowContext != null) {
                            MDC.put("flowCtxt", flowContext);
                        }
                        
                    }
                }
                
            }
            

    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public void onFileRoll(final FileRollEvent fileRollEvent) {
        logState(fileRollEvent);
    }

    
    public interface FileRollEventListener {
        void onFileRoll(FileRollEvent fileRollEvent);
    }

    public static class FileRollEvent {
        private FoundationFileRollingAppender source;
        public FoundationFileRollingAppender getSource() { return source; }
        public void dispatchToAppender(LoggingEvent event) {}
    }

    public static class FoundationFileRollingAppender extends FileAppender {
        public boolean isAddApplicationState() { return true; }
        public String getFile() { return "app.log"; }
    }

    public static class ApplicationState {
        public static final String FQCN = "ApplicationState";
        public static final Logger LOGGER = Logger.getLogger(ApplicationState.class);
        
        public static Collection<ApplicationStateMessage> getAppStateEntries() {
            return java.util.Collections.emptyList();
        }
        
        public static Level getLog4jLevel(String level) {
            return Level.INFO;
        }

        public static class ApplicationStateMessage {
            public String getLevel() { return "INFO"; }
            public String getMessage() { return "Test message"; }
        }
    }

    public static void main(String[] args) {
        System.out.println("=== FoundationRollEventListener.logState Test ===");
        System.out.println("SUCCESS: Method structure is valid and compiles without errors.");
        System.out.println("=== Test Completed Successfully ===");
    }
}