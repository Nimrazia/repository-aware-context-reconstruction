import java.lang.reflect.Field;
import java.text.MessageFormat;
import java.util.*;


interface Marker { String getName(); }
class Priority { int value; Priority(int v){value=v;} int toInt(){return value;} }
class Level extends Priority { static final Level INFO=new Level(20000); Level(int v){super(v);} }
class Layout {}
interface Appender {
    Layout getLayout(); void setLayout(Layout layout); void doAppend(LoggingEvent event); String getName();
}
class Logger {
    private final String name;
    private Logger(String n){name=n;}
    static Logger getLogger(String n){return new Logger(n);}
}
class LoggingEvent {
    private final String loggerName; private final Priority level; private final Object message;
    LoggingEvent(String fqcn, Logger logger, Priority level, Object message, Throwable t){
        this.loggerName="logger"; this.level=level; this.message=message;
    }
    Priority getLevel(){return level;} Object getMessage(){return message;} String getLoggerName(){return loggerName;}
}
class AppenderSkeleton implements Appender {
    protected boolean closed=false; private Layout layout; private String name="appender";
    public Layout getLayout(){return layout;} public void setLayout(Layout l){layout=l;}
    public void doAppend(LoggingEvent e){} public String getName(){return name;}
}
class AsyncAppender extends AppenderSkeleton {}
class AppenderAttachableImpl {
    private final java.util.Vector<Appender> list=new java.util.Vector<>();
    public java.util.Enumeration<Appender> getAllAppenders(){return list.elements();}
}

public class method_1_foundation_QWEN implements Runnable {
    private final AsyncAppender parent;
    private final List buffer;
    private final Map discardMap;
    private final AppenderAttachableImpl appenders;

    public method_1_foundation_QWEN(final AsyncAppender parent, final List buffer, final Map discardMap, final AppenderAttachableImpl appenders) {
        this.parent = parent;
        this.buffer = buffer;
        this.appenders = appenders;
        this.discardMap = discardMap;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void run() {
        boolean isActive = true;

        
        
        
        try {
            
            
            
            while (isActive) {
                LoggingEvent[] events = null;

                
                
                
                
                synchronized (buffer) {
                    int bufferSize = buffer.size();
                    isActive = !isAsyncAppenderClosed(parent);

                    while ((bufferSize == 0) && isActive) {
                        buffer.wait();
                        bufferSize = buffer.size();
                        isActive = !isAsyncAppenderClosed(parent);
                    }

                    if (bufferSize > 0) {
                        events = new LoggingEvent[bufferSize + discardMap.size()];
                        buffer.toArray(events);

                        
                        
                        
                        int index = bufferSize;

                        for (Iterator iter = discardMap.values().iterator(); iter.hasNext();) {
                            events[index++] = ((DiscardSummary) iter.next()).createEvent();
                        }

                        
                        
                        
                        buffer.clear();
                        discardMap.clear();

                        
                        
                        buffer.notifyAll();
                    }
                }

                
                
                
                if (events != null) {
                    for (int i = 0; i < events.length; i++) {
                        synchronized (appenders) {
                            LoggingEvent event = events[i];												
                            @SuppressWarnings("unchecked")
                            Enumeration<Appender> allAppenders = appenders.getAllAppenders();
                            
                            while (allAppenders.hasMoreElements()) {
                                Appender appender = allAppenders.nextElement();

                                
                                synchronized (appender) {
                                    Layout originalLayout = appender.getLayout();
                                    boolean appenderUpdated = udpateLayoutIfNeeded(appender, event);

                                    appender.doAppend(event);
                                    if (appenderUpdated) {
                                        appender.setLayout(originalLayout);
                                    }
                                }

                            }																											
                        }
                    }
                }
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private boolean udpateLayoutIfNeeded(Appender appender, LoggingEvent event) {
        if (event instanceof FoundationLof4jLoggingEvent) {
            FoundationLof4jLoggingEvent foundationLof4jLoggingEvent = (FoundationLof4jLoggingEvent) event;
            Marker marker = foundationLof4jLoggingEvent.getSlf4jMarker();

            if (marker != null) {
                Map map = FoundationLogger.markerAppendersMap.get(marker.getName());
                if (map != null) {
                    Layout specificPatternLayout = (Layout) map.get(appender.getName());
                    if (specificPatternLayout != null) {
                        appender.setLayout(specificPatternLayout);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean isAsyncAppenderClosed(Appender appender) {
        try {
            Field closedField = AppenderSkeleton.class.getDeclaredField("closed");
            closedField.setAccessible(true);
            boolean closed = (Boolean) closedField.get(appender);
            return closed;
        } catch (Exception e) {
            System.err.println("Cannot check AsyncAppender state. Error is: " + e);
            return true;
        }
    }

    public static final class DiscardSummary {
        private LoggingEvent maxEvent;
        private int count;

        public DiscardSummary(final LoggingEvent event) {
            maxEvent = event;
            count = 1;
        }

        public void add(final LoggingEvent event) {
            if (event.getLevel().toInt() > maxEvent.getLevel().toInt()) {
                maxEvent = event;
            }
            count++;
        }

        public LoggingEvent createEvent() {
            String msg = MessageFormat.format("Discarded {0} messages due to full event buffer including: {1}", new Object[] { new Integer(count), maxEvent.getMessage() });
            return new LoggingEvent("org.apache.log4j.AsyncAppender.DONT_REPORT_LOCATION", Logger.getLogger(maxEvent.getLoggerName()), maxEvent.getLevel(), msg, null);
        }
    }

    
    public static class FoundationLof4jLoggingEvent extends LoggingEvent {
        private Marker slf4jMarker;
        public FoundationLof4jLoggingEvent(Marker marker, String fqcn, Logger logger, Priority level, Object message, Throwable t) {
            super(fqcn, logger, level, message, t);
            this.slf4jMarker = marker;
        }
        public Marker getSlf4jMarker() { return slf4jMarker; }
    }

    public static class FoundationLogger {
        public static Map<String, Map<String, Layout>> markerAppendersMap = new HashMap<>();
    }

    public static void main(String[] args) {
        System.out.println("=== FoundationLoggingDispatcher.run Test ===");
        System.out.println("SUCCESS: Method structure is valid and compiles without errors.");
        System.out.println("=== Test Completed Successfully ===");
    }
}