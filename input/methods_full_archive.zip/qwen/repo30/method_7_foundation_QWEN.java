import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class method_7_foundation_QWEN {

    protected static final String TOTAL_COMPONENT = "Total";

    private Map<String, Component> components = new HashMap<>();
    private ComponentsMultiThread componentsMultiThread;
    private Component total = new Component(TOTAL_COMPONENT);
    private Map<String, String> properties = new HashMap<>();

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    protected void addPropertiesProcessingTime() {

        HashMap<String, Long> mapComponentTimes			= new HashMap<>();
        HashMap<String, Long> mapComponentInvocations	= new HashMap<>();

        
        if (this.componentsMultiThread != null) {
          for (Component component : this.componentsMultiThread.getComponents()) {
            addTimePerComponent(mapComponentTimes, component);
            addInvocationPerComponent(mapComponentInvocations, component);
          }
        }

        for (Component component : this.components.values()) {
          addTimePerComponent(mapComponentTimes, component);
        }

        for (Entry<String, Long> entry : mapComponentTimes.entrySet()) {
          putProperty(entry.getKey(), addDuration(entry.getValue()));
        }

        for (Entry<String, Long> entry : mapComponentInvocations.entrySet()) {
          putProperty(entry.getKey(), entry.getValue().toString());
        }
        putProperty(TOTAL_COMPONENT, addDuration(this.total.getTime()));
      }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private String addDuration(Long duration) {
        return duration + "ms";
    }

    private static void addTimePerComponent(HashMap<String, Long> mapComponentTimes, Component component) {
        Long currentTimeOfComponent = 0L;
        String key = component.getComponentType();
        if (mapComponentTimes.containsKey(key)) {
            currentTimeOfComponent = mapComponentTimes.get(key);
        }
        Long maxTime = Math.max(component.getTime(), currentTimeOfComponent);
        mapComponentTimes.put(key, maxTime);
    }

    private static void addInvocationPerComponent(HashMap<String, Long> mapComponentInvocations, Component component) {
        Long invocationComponent = 0L;
        String key = component.getComponentType() + "_Invocations";
        if (mapComponentInvocations.containsKey(key)) {
            invocationComponent = mapComponentInvocations.get(key);
        }
        invocationComponent++;
        mapComponentInvocations.put(key, invocationComponent);
    }

    protected void putProperty(String key, String value) {
        this.properties.put(key, value);
    }

    
    public static class Component {
        private String type;
        private long time;
        public Component(String type) { this.type = type; }
        public String getComponentType() { return type; }
        public long getTime() { return time; }
    }

    public static class ComponentsMultiThread {
        public java.util.List<Component> getComponents() { return java.util.Collections.emptyList(); }
    }

    public static void main(String[] args) {
        System.out.println("=== TransactionLogger.addPropertiesProcessingTime Test ===");
        method_7_foundation_QWEN logger = new method_7_foundation_QWEN();
        logger.addPropertiesProcessingTime();
        System.out.println("SUCCESS: Method structure is valid and compiles without errors.");
        System.out.println("=== Test Completed Successfully ===");
    }
}