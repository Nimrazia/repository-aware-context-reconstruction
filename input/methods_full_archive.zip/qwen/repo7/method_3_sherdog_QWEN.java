import java.io.*;
import java.text.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

interface SherdogParser { Fighter parseDocument(Document doc) throws IOException; }
interface Document { Elements select(String cssQuery); }
interface Element { String html(); String attr(String key); Elements select(String cssQuery); Element first(); }
class Elements implements Iterable<Element> {
    private final List<Element> list;
    Elements() { this.list=new ArrayList<>(); }
    Elements(Collection<? extends Element> c) { this.list=new ArrayList<>(c); }
    public Element get(int i){ return list.get(i); } public int size(){return list.size();}
    public Element first(){return list.isEmpty()?null:list.get(0);}
    public void remove(int i){list.remove(i);}
    public Stream<Element> stream(){return list.stream();}
    public Iterator<Element> iterator(){return list.iterator();}
    public String html(){return list.stream().map(Element::html).collect(Collectors.joining());}
    public String attr(String key){return first()==null?"":first().attr(key);}
    public Elements select(String q){ List<Element> out=new ArrayList<>(); for(Element e:list) for(Element x:e.select(q)) out.add(x); return new Elements(out);}
}
class MockElement implements Element {
    private String html=""; private final Map<String,String> attrs=new HashMap<>();
    private final Map<String,List<Element>> children=new HashMap<>();
    MockElement(){} MockElement(String h){html=h;}
    MockElement attr(String k,String v){attrs.put(k,v);return this;}
    MockElement addInner(String q, Element... es){children.computeIfAbsent(q,k->new ArrayList<>()).addAll(Arrays.asList(es));return this;}
    MockElement addInner(String q,String h){return addInner(q,new MockElement(h));}
    public String html(){return html;} public String attr(String k){return attrs.getOrDefault(k,"");}
    public Elements select(String q){return new Elements(children.getOrDefault(q,Collections.emptyList()));}
    public Element first(){return this;}
}
class MockDocument implements Document {
    private final Map<String,List<Element>> map=new HashMap<>();
    void addSelectResult(String q,Element... es){map.put(q,new ArrayList<>(Arrays.asList(es)));}
    public Elements select(String q){return new Elements(map.getOrDefault(q,Collections.emptyList()));}
}
class SimpleLogger {
    void info(String s,Object... args){ String out=s; for(Object a:args) out=out.replaceFirst("\\{\\}",java.util.regex.Matcher.quoteReplacement(String.valueOf(a))); System.out.println(out); }
}
class SherdogBaseObject { private String name,url; public String getName(){return name;} public void setName(String v){name=v;} public String getSherdogUrl(){return url;} public void setSherdogUrl(String v){url=v;} }
enum FightResult { WIN, LOSS, DRAW, NC }
enum FightType { PROFESSIONAL, AMATEUR, EXHIBITION, UNKNOWN; static FightType fromString(String s){ if(s==null)return UNKNOWN; try{return valueOf(s.trim().toUpperCase().replace(' ','_'));}catch(Exception e){return UNKNOWN;} } }
class Fight {
 private SherdogBaseObject f1,f2,event; private ZonedDateTime date; private FightResult result; private String method,time; private int round; private FightType type;
 public void setFighter1(SherdogBaseObject v){f1=v;} public void setFighter2(SherdogBaseObject v){f2=v;} public void setEvent(SherdogBaseObject v){event=v;}
 public void setDate(ZonedDateTime v){date=v;} public ZonedDateTime getDate(){return date;} public void setResult(FightResult v){result=v;}
 public void setWinMethod(String v){method=v;} public void setWinRound(int v){round=v;} public void setWinTime(String v){time=v;} public void setType(FightType v){type=v;}
 public String toString(){return "Fight{"+(f1==null?"?":f1.getName())+" vs "+(f2==null?"?":f2.getName())+"}";}
}
class Fighter extends SherdogBaseObject {
 private String nickname,height,weight,picture; private Date birthday; private int wins,losses,winsKo,winsSub,winsDec,winsOther,lossesKo,lossesSub,lossesDec,lossesOther,draws,nc; private List<Fight> fights=new ArrayList<>();
 public void setNickname(String v){nickname=v;} public String getNickname(){return nickname;} public void setBirthday(Date v){birthday=v;} public void setHeight(String v){height=v;} public void setWeight(String v){weight=v;}
 public void setWins(int v){wins=v;} public int getWins(){return wins;} public void setLosses(int v){losses=v;} public int getLosses(){return losses;}
 public void setWinsKo(int v){winsKo=v;} public void setWinsSub(int v){winsSub=v;} public void setWinsDec(int v){winsDec=v;} public void setWinsOther(int v){winsOther=v;}
 public void setLossesKo(int v){lossesKo=v;} public void setLossesSub(int v){lossesSub=v;} public void setLossesDec(int v){lossesDec=v;} public void setLossesOther(int v){lossesOther=v;}
 public void setDraws(int v){draws=v;} public void setNc(int v){nc=v;} public List<Fight> getFights(){return fights;} public void setFights(List<Fight> v){fights=v;} public void setPicture(String v){picture=v;}
}
class Event extends SherdogBaseObject { private ZonedDateTime date; private List<Fight> fights=new ArrayList<>(); public ZonedDateTime getDate(){return date;} public void setDate(ZonedDateTime v){date=v;} public List<Fight> getFights(){return fights;} public void setFights(List<Fight> v){fights=v;} }
class PictureProcessor { String process(String url,Fighter f){return url;} }
class Constants { static final PictureProcessor DEFAULT_PICTURE_PROCESSOR=new PictureProcessor(); }
class ParserUtils {
 static String getSherdogPageUrl(Document d){return "https://www.sherdog.com/fighter/123";} static FightResult getFightResult(Element e){return FightResult.WIN;}
 static ZonedDateTime getDateFromStringToZoneId(String s,ZoneId z,DateTimeFormatter f){try{return LocalDate.parse(s,f).atStartOfDay(z);}catch(Exception e){return ZonedDateTime.now(z);}}
}
class DigestUtils { static String sha256Hex(String s){return Integer.toHexString(Objects.hashCode(s));} }

public class method_3_sherdog_QWEN implements SherdogParser {
 private final SimpleLogger logger=new SimpleLogger(); private final ZoneId ZONE_ID; private final int COLUMN_RESULT=0,COLUMN_OPPONENT=1,COLUMN_EVENT=2,COLUMN_METHOD=3,COLUMN_ROUND=4,COLUMN_TIME=5; public method_3_sherdog_QWEN(ZoneId z){ZONE_ID=z;} public Fighter parseDocument(Document d){return null;}
 
 // ORIGINAL CODESEARCHNET METHOD — START
 
    private List<Fight> getFights(Elements trs, Fighter fighter) throws ArrayIndexOutOfBoundsException {
        List<Fight> fights = new ArrayList<>();

        logger.info("{} TRs to parse through", trs.size());


        SherdogBaseObject sFighter = new SherdogBaseObject();
        sFighter.setName(fighter.getName());
        sFighter.setSherdogUrl(fighter.getSherdogUrl());


        
        if (trs.size() > 0) {
            trs.remove(0);

            trs.forEach(tr -> {
                Fight fight = new Fight();
                fight.setFighter1(sFighter);

                Elements tds = tr.select("td");
                fight.setResult(getFightResult(tds.get(COLUMN_RESULT)));
                fight.setFighter2(getOpponent(tds.get(COLUMN_OPPONENT)));
                fight.setEvent(getEvent(tds.get(COLUMN_EVENT)));
                fight.setDate(getDate(tds.get(COLUMN_EVENT)));
                fight.setWinMethod(getWinMethod(tds.get(COLUMN_METHOD)));
                fight.setWinRound(getWinRound(tds.get(COLUMN_ROUND)));
                fight.setWinTime(getWinTime(tds.get(COLUMN_TIME)));
                fights.add(fight);
                logger.info("{}", fight);
            });
        }

        return fights;
    }
 
 // ORIGINAL CODESEARCHNET METHOD — END
 
 private FightResult getFightResult(Element e){return ParserUtils.getFightResult(e);} private SherdogBaseObject getOpponent(Element td){Element a=td.select("a").get(0);SherdogBaseObject o=new SherdogBaseObject();o.setName(a.html());o.setSherdogUrl(a.attr("abs:href"));return o;} private SherdogBaseObject getEvent(Element td){return getOpponent(td);} private ZonedDateTime getDate(Element td){return ZonedDateTime.now(ZONE_ID);} private String getWinMethod(Element e){return e.html();} private int getWinRound(Element e){return Integer.parseInt(e.html());} private String getWinTime(Element e){return e.html();}
 public static void main(String[]a){MockElement row=new MockElement().addInner("td",new MockElement("Win"),new MockElement().addInner("a",new MockElement("Opponent").attr("abs:href","/f2")),new MockElement().addInner("a",new MockElement("UFC").attr("abs:href","/e")),new MockElement("KO"),new MockElement("1"),new MockElement("2:34")); Elements rows=new Elements(Arrays.asList(new MockElement(),row)); Fighter f=new Fighter();f.setName("F1");f.setSherdogUrl("/f1");System.out.println("SUCCESS: fights="+new method_3_sherdog_QWEN(ZoneId.systemDefault()).getFights(rows,f).size());}
}