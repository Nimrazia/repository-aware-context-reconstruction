import java.io.*;
import java.text.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

interface SherdogParser { Fighter parseDocument(Document doc) throws IOException; }
interface Document { Elements select(String cssQuery); }
interface Element { String html(); String attr(String key); Elements select(String cssQuery); Element first(); }
class Elements implements Iterable<Element> {
    private final List<Element> list;
    Elements() { this.list=new ArrayList<>(); }
    Elements(Collection<? extends Element> c) { this.list=new ArrayList<>(c); }
    public Element get(int i){ return list.get(i); } public int size(){return list.size();}
    public Element first(){return list.isEmpty()?null:list.get(0);}
    public void remove(int i){list.remove(i);}
    public Stream<Element> stream(){return list.stream();}
    public Iterator<Element> iterator(){return list.iterator();}
    public String html(){return list.stream().map(Element::html).collect(Collectors.joining());}
    public String attr(String key){return first()==null?"":first().attr(key);}
    public Elements select(String q){ List<Element> out=new ArrayList<>(); for(Element e:list) for(Element x:e.select(q)) out.add(x); return new Elements(out);}
}
class MockElement implements Element {
    private String html=""; private final Map<String,String> attrs=new HashMap<>();
    private final Map<String,List<Element>> children=new HashMap<>();
    MockElement(){} MockElement(String h){html=h;}
    MockElement attr(String k,String v){attrs.put(k,v);return this;}
    MockElement addInner(String q, Element... es){children.computeIfAbsent(q,k->new ArrayList<>()).addAll(Arrays.asList(es));return this;}
    MockElement addInner(String q,String h){return addInner(q,new MockElement(h));}
    public String html(){return html;} public String attr(String k){return attrs.getOrDefault(k,"");}
    public Elements select(String q){return new Elements(children.getOrDefault(q,Collections.emptyList()));}
    public Element first(){return this;}
}
class MockDocument implements Document {
    private final Map<String,List<Element>> map=new HashMap<>();
    void addSelectResult(String q,Element... es){map.put(q,new ArrayList<>(Arrays.asList(es)));}
    public Elements select(String q){return new Elements(map.getOrDefault(q,Collections.emptyList()));}
}
class SimpleLogger {
    void info(String s,Object... args){ String out=s; for(Object a:args) out=out.replaceFirst("\\{\\}",java.util.regex.Matcher.quoteReplacement(String.valueOf(a))); System.out.println(out); }
}
class SherdogBaseObject { private String name,url; public String getName(){return name;} public void setName(String v){name=v;} public String getSherdogUrl(){return url;} public void setSherdogUrl(String v){url=v;} }
enum FightResult { WIN, LOSS, DRAW, NC }
enum FightType { PROFESSIONAL, AMATEUR, EXHIBITION, UNKNOWN; static FightType fromString(String s){ if(s==null)return UNKNOWN; try{return valueOf(s.trim().toUpperCase().replace(' ','_'));}catch(Exception e){return UNKNOWN;} } }
class Fight {
 private SherdogBaseObject f1,f2,event; private ZonedDateTime date; private FightResult result; private String method,time; private int round; private FightType type;
 public void setFighter1(SherdogBaseObject v){f1=v;} public void setFighter2(SherdogBaseObject v){f2=v;} public void setEvent(SherdogBaseObject v){event=v;}
 public void setDate(ZonedDateTime v){date=v;} public ZonedDateTime getDate(){return date;} public void setResult(FightResult v){result=v;}
 public void setWinMethod(String v){method=v;} public void setWinRound(int v){round=v;} public void setWinTime(String v){time=v;} public void setType(FightType v){type=v;}
 public String toString(){return "Fight{"+(f1==null?"?":f1.getName())+" vs "+(f2==null?"?":f2.getName())+"}";}
}
class Fighter extends SherdogBaseObject {
 private String nickname,height,weight,picture; private Date birthday; private int wins,losses,winsKo,winsSub,winsDec,winsOther,lossesKo,lossesSub,lossesDec,lossesOther,draws,nc; private List<Fight> fights=new ArrayList<>();
 public void setNickname(String v){nickname=v;} public String getNickname(){return nickname;} public void setBirthday(Date v){birthday=v;} public void setHeight(String v){height=v;} public void setWeight(String v){weight=v;}
 public void setWins(int v){wins=v;} public int getWins(){return wins;} public void setLosses(int v){losses=v;} public int getLosses(){return losses;}
 public void setWinsKo(int v){winsKo=v;} public void setWinsSub(int v){winsSub=v;} public void setWinsDec(int v){winsDec=v;} public void setWinsOther(int v){winsOther=v;}
 public void setLossesKo(int v){lossesKo=v;} public void setLossesSub(int v){lossesSub=v;} public void setLossesDec(int v){lossesDec=v;} public void setLossesOther(int v){lossesOther=v;}
 public void setDraws(int v){draws=v;} public void setNc(int v){nc=v;} public List<Fight> getFights(){return fights;} public void setFights(List<Fight> v){fights=v;} public void setPicture(String v){picture=v;}
}
class Event extends SherdogBaseObject { private ZonedDateTime date; private List<Fight> fights=new ArrayList<>(); public ZonedDateTime getDate(){return date;} public void setDate(ZonedDateTime v){date=v;} public List<Fight> getFights(){return fights;} public void setFights(List<Fight> v){fights=v;} }
class PictureProcessor { String process(String url,Fighter f){return url;} }
class Constants { static final PictureProcessor DEFAULT_PICTURE_PROCESSOR=new PictureProcessor(); }
class ParserUtils {
 static String getSherdogPageUrl(Document d){return "https://www.sherdog.com/fighter/123";} static FightResult getFightResult(Element e){return FightResult.WIN;}
 static ZonedDateTime getDateFromStringToZoneId(String s,ZoneId z,DateTimeFormatter f){try{return LocalDate.parse(s,f).atStartOfDay(z);}catch(Exception e){return ZonedDateTime.now(z);}}
}
class DigestUtils { static String sha256Hex(String s){return Integer.toHexString(Objects.hashCode(s));} }

public class method_1_sherdog_QWEN implements SherdogParser {
 private final SimpleLogger logger=new SimpleLogger(); private final SimpleDateFormat df=new SimpleDateFormat("yyyy-dd-MM"); private final PictureProcessor PROCESSOR; private final ZoneId ZONE_ID;
 private final int COLUMN_RESULT=0,COLUMN_OPPONENT=1,COLUMN_EVENT=2,COLUMN_METHOD=3,COLUMN_ROUND=4,COLUMN_TIME=5; private final int METHOD_KO=0,METHOD_SUBMISSION=1,METHOD_DECISION=2,METHOD_OTHERS=3;
 public method_1_sherdog_QWEN(ZoneId z){PROCESSOR=Constants.DEFAULT_PICTURE_PROCESSOR;ZONE_ID=z;}
 
 // ORIGINAL CODESEARCHNET METHOD — START
 
    @Override
    public Fighter parseDocument(Document doc) throws IOException {
        Fighter fighter = new Fighter();
        fighter.setSherdogUrl(ParserUtils.getSherdogPageUrl(doc));

        logger.info("Refreshing fighter {}", fighter.getSherdogUrl());


        try {
            Elements name = doc.select(".bio_fighter h1 span.fn");
            fighter.setName(name.get(0).html());
        } catch (Exception e) {
            
        }

        
        try {
            Elements nickname = doc.select(".bio_fighter span.nickname em");
            fighter.setNickname(nickname.get(0).html());
        } catch (Exception e) {
            
        }

        
        try {
            Elements birthday = doc.select("span[itemprop=\"birthDate\"]");
            fighter.setBirthday(df.parse(birthday.get(0).html()));
        } catch (Exception e) {
            
        }
        
        try {
            Elements height = doc.select(".size_info .height strong");
            fighter.setHeight(height.get(0).html());
        } catch (Exception e) {
            
        }
        
        try {
            Elements weight = doc.select(".size_info .weight strong");
            fighter.setWeight(weight.get(0).html());
        } catch (Exception e) {
            
        }
        
        try {
            Elements wins = doc.select(".bio_graph .counter");
            fighter.setWins(Integer.parseInt(wins.get(0).html()));
        } catch (Exception e) {
            
        }
        Elements winsMethods = doc.select(".bio_graph:first-of-type .graph_tag");
        try {
            fighter.setWinsKo(Integer.parseInt(winsMethods.get(METHOD_KO).html().split(" ")[0]));
        } catch (Exception e) {
            
        }

        try {
            fighter.setWinsSub(Integer.parseInt(winsMethods.get(METHOD_SUBMISSION).html().split(" ")[0]));
        } catch (Exception e) {
            
        }

        try {
            fighter.setWinsDec(Integer.parseInt(winsMethods.get(METHOD_DECISION).html().split(" ")[0]));
        } catch (Exception e) {
            
        }


        try {
            fighter.setWinsOther(Integer.parseInt(winsMethods.get(METHOD_OTHERS).html().split(" ")[0]));
        } catch (Exception e) {
            
        }
        
        try {
            Elements losses = doc.select(".bio_graph.loser .counter");
            fighter.setLosses(Integer.parseInt(losses.get(0).html()));
        } catch (Exception e) {
            
        }

        Elements lossesMethods = doc.select(".bio_graph.loser .graph_tag");


        try {

            fighter.setLossesKo((Integer.parseInt(lossesMethods.get(METHOD_KO).html().split(" ")[0])));
        } catch (Exception e) {
            
        }

        try {
            fighter.setLossesSub(Integer.parseInt(lossesMethods.get(METHOD_SUBMISSION).html().split(" ")[0]));
        } catch (Exception e) {
            
        }

        try {
            fighter.setLossesDec(Integer.parseInt(lossesMethods.get(METHOD_DECISION).html().split(" ")[0]));
        } catch (Exception e) {
            
        }

        try {
            fighter.setLossesOther(Integer.parseInt(lossesMethods.get(METHOD_OTHERS).html().split(" ")[0]));
        } catch (Exception e) {
            
        }
        
        Elements drawsNc = doc.select(".right_side .bio_graph .card");
        for (Element element : drawsNc) {

            switch (element.select("span.result").html()) {
                case "Draws":
                    fighter.setDraws(Integer.parseInt(element.select("span.counter").html()));
                    break;

                case "N/C":
                    fighter.setNc(Integer.parseInt(element.select("span.counter").html()));
                    break;
            }

        }

        Elements picture = doc.select(".bio_fighter .content img[itemprop=\"image\"]");
        String pictureUrl = "https://www.sherdog.com" + picture.attr("src").trim();


        Elements fightTables = doc.select(".fight_history");
        logger.info("Found {} fight history tables", fightTables.size());


        fightTables.stream()
                
                .filter(div -> !div.select(".module_header h2").html().trim().contains("Upcoming"))
                .collect(Collectors.groupingBy(div -> {
                    String categoryName = div.select(".module_header h2").html().trim().replaceAll("(?i)FIGHT HISTORY - ", "").trim();

                    return FightType.fromString(categoryName);
                }))
                .forEach((key, div) -> div.stream()
                        .map(d -> d.select(".table table tr"))
                        .filter(tdList -> tdList.size() > 0)
                        .findFirst()
                        .ifPresent(tdList -> {
                                    List<Fight> f = getFights(tdList, fighter);

                                    f.forEach(fight -> fight.setType(key));

                                    fighter.getFights().addAll(f);
                                }
                        ));

        List<Fight> sorted = fighter.getFights()
                .stream()
                .sorted(Comparator.comparing(Fight::getDate, Comparator.nullsFirst(Comparator.naturalOrder())))
                .collect(Collectors.toList());

        fighter.setFights(sorted);


        logger.info("Found {} fights for {}", fighter.getFights().size(), fighter.getName());

        
        if (pictureUrl.length() > 0) {
            fighter.setPicture(PROCESSOR.process(pictureUrl, fighter));
        }

        return fighter;
    }
 
 // ORIGINAL CODESEARCHNET METHOD — END
 
 private List<Fight> getFights(Elements trs,Fighter fighter){return new ArrayList<>();}
 public static void main(String[] a)throws Exception{MockDocument d=new MockDocument(); d.addSelectResult(".bio_fighter h1 span.fn",new MockElement("Jon Jones")); d.addSelectResult(".bio_fighter span.nickname em",new MockElement("Bones")); d.addSelectResult("span[itemprop=\"birthDate\"]",new MockElement("1987-19-07")); d.addSelectResult(".size_info .height strong",new MockElement("6' 4\"")); d.addSelectResult(".size_info .weight strong",new MockElement("248 lbs")); d.addSelectResult(".bio_graph .counter",new MockElement("27")); d.addSelectResult(".bio_graph:first-of-type .graph_tag",new MockElement("10 KO"),new MockElement("6 Sub"),new MockElement("11 Dec"),new MockElement("0 Other")); d.addSelectResult(".bio_graph.loser .counter",new MockElement("1")); d.addSelectResult(".bio_graph.loser .graph_tag",new MockElement("0 KO"),new MockElement("0 Sub"),new MockElement("1 Dec"),new MockElement("0 Other")); d.addSelectResult(".bio_fighter .content img[itemprop=\"image\"]",new MockElement().attr("src","/img.jpg")); Fighter f=new method_1_sherdog_QWEN(ZoneId.systemDefault()).parseDocument(d); System.out.println("SUCCESS: "+f.getName()+", wins="+f.getWins());}
}