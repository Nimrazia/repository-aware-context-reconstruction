import java.io.*;
import java.text.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

interface SherdogParser { Fighter parseDocument(Document doc) throws IOException; }
interface Document { Elements select(String cssQuery); }
interface Element { String html(); String attr(String key); Elements select(String cssQuery); Element first(); }
class Elements implements Iterable<Element> {
    private final List<Element> list;
    Elements() { this.list=new ArrayList<>(); }
    Elements(Collection<? extends Element> c) { this.list=new ArrayList<>(c); }
    public Element get(int i){ return list.get(i); } public int size(){return list.size();}
    public Element first(){return list.isEmpty()?null:list.get(0);}
    public void remove(int i){list.remove(i);}
    public Stream<Element> stream(){return list.stream();}
    public Iterator<Element> iterator(){return list.iterator();}
    public String html(){return list.stream().map(Element::html).collect(Collectors.joining());}
    public String attr(String key){return first()==null?"":first().attr(key);}
    public Elements select(String q){ List<Element> out=new ArrayList<>(); for(Element e:list) for(Element x:e.select(q)) out.add(x); return new Elements(out);}
}
class MockElement implements Element {
    private String html=""; private final Map<String,String> attrs=new HashMap<>();
    private final Map<String,List<Element>> children=new HashMap<>();
    MockElement(){} MockElement(String h){html=h;}
    MockElement attr(String k,String v){attrs.put(k,v);return this;}
    MockElement addInner(String q, Element... es){children.computeIfAbsent(q,k->new ArrayList<>()).addAll(Arrays.asList(es));return this;}
    MockElement addInner(String q,String h){return addInner(q,new MockElement(h));}
    public String html(){return html;} public String attr(String k){return attrs.getOrDefault(k,"");}
    public Elements select(String q){return new Elements(children.getOrDefault(q,Collections.emptyList()));}
    public Element first(){return this;}
}
class MockDocument implements Document {
    private final Map<String,List<Element>> map=new HashMap<>();
    void addSelectResult(String q,Element... es){map.put(q,new ArrayList<>(Arrays.asList(es)));}
    public Elements select(String q){return new Elements(map.getOrDefault(q,Collections.emptyList()));}
}
class SimpleLogger {
    void info(String s,Object... args){ String out=s; for(Object a:args) out=out.replaceFirst("\\{\\}",java.util.regex.Matcher.quoteReplacement(String.valueOf(a))); System.out.println(out); }
}
class SherdogBaseObject { private String name,url; public String getName(){return name;} public void setName(String v){name=v;} public String getSherdogUrl(){return url;} public void setSherdogUrl(String v){url=v;} }
enum FightResult { WIN, LOSS, DRAW, NC }
enum FightType { PROFESSIONAL, AMATEUR, EXHIBITION, UNKNOWN; static FightType fromString(String s){ if(s==null)return UNKNOWN; try{return valueOf(s.trim().toUpperCase().replace(' ','_'));}catch(Exception e){return UNKNOWN;} } }
class Fight {
 private SherdogBaseObject f1,f2,event; private ZonedDateTime date; private FightResult result; private String method,time; private int round; private FightType type;
 public void setFighter1(SherdogBaseObject v){f1=v;} public void setFighter2(SherdogBaseObject v){f2=v;} public void setEvent(SherdogBaseObject v){event=v;}
 public void setDate(ZonedDateTime v){date=v;} public ZonedDateTime getDate(){return date;} public void setResult(FightResult v){result=v;}
 public void setWinMethod(String v){method=v;} public void setWinRound(int v){round=v;} public void setWinTime(String v){time=v;} public void setType(FightType v){type=v;}
 public String toString(){return "Fight{"+(f1==null?"?":f1.getName())+" vs "+(f2==null?"?":f2.getName())+"}";}
}
class Fighter extends SherdogBaseObject {
 private String nickname,height,weight,picture; private Date birthday; private int wins,losses,winsKo,winsSub,winsDec,winsOther,lossesKo,lossesSub,lossesDec,lossesOther,draws,nc; private List<Fight> fights=new ArrayList<>();
 public void setNickname(String v){nickname=v;} public String getNickname(){return nickname;} public void setBirthday(Date v){birthday=v;} public void setHeight(String v){height=v;} public void setWeight(String v){weight=v;}
 public void setWins(int v){wins=v;} public int getWins(){return wins;} public void setLosses(int v){losses=v;} public int getLosses(){return losses;}
 public void setWinsKo(int v){winsKo=v;} public void setWinsSub(int v){winsSub=v;} public void setWinsDec(int v){winsDec=v;} public void setWinsOther(int v){winsOther=v;}
 public void setLossesKo(int v){lossesKo=v;} public void setLossesSub(int v){lossesSub=v;} public void setLossesDec(int v){lossesDec=v;} public void setLossesOther(int v){lossesOther=v;}
 public void setDraws(int v){draws=v;} public void setNc(int v){nc=v;} public List<Fight> getFights(){return fights;} public void setFights(List<Fight> v){fights=v;} public void setPicture(String v){picture=v;}
}
class Event extends SherdogBaseObject { private ZonedDateTime date; private List<Fight> fights=new ArrayList<>(); public ZonedDateTime getDate(){return date;} public void setDate(ZonedDateTime v){date=v;} public List<Fight> getFights(){return fights;} public void setFights(List<Fight> v){fights=v;} }
class PictureProcessor { String process(String url,Fighter f){return url;} }
class Constants { static final PictureProcessor DEFAULT_PICTURE_PROCESSOR=new PictureProcessor(); }
class ParserUtils {
 static String getSherdogPageUrl(Document d){return "https://www.sherdog.com/fighter/123";} static FightResult getFightResult(Element e){return FightResult.WIN;}
 static ZonedDateTime getDateFromStringToZoneId(String s,ZoneId z,DateTimeFormatter f){try{return LocalDate.parse(s,f).atStartOfDay(z);}catch(Exception e){return ZonedDateTime.now(z);}}
}
class DigestUtils { static String sha256Hex(String s){return Integer.toHexString(Objects.hashCode(s));} }

public class method_2_sherdog_QWEN implements SherdogParser {
 private final SimpleLogger logger=new SimpleLogger(); private final ZoneId ZONE_ID; public method_2_sherdog_QWEN(ZoneId z){ZONE_ID=z;} public Fighter parseDocument(Document d){return null;}
 
 // ORIGINAL CODESEARCHNET METHOD — START
 
    private void getFights(Document doc, Event event) {
        logger.info("Getting fights for event #{}[{}]", event.getSherdogUrl(), event.getName());

        SherdogBaseObject sEvent = new SherdogBaseObject();
        sEvent.setName(event.getName());
        sEvent.setSherdogUrl(event.getSherdogUrl());

        List<Fight> fights = new ArrayList<>();

        
        Elements mainFightElement = doc.select(".content.event");

        Elements fighters = mainFightElement.select("h3 a");
        
        SherdogBaseObject mainFighter1 = new SherdogBaseObject();
        Element mainFighter1Element = fighters.get(0);
        mainFighter1.setSherdogUrl(mainFighter1Element.attr("abs:href"));
        mainFighter1.setName(mainFighter1Element.select("span[itemprop=\"name\"]").html());

        
        SherdogBaseObject mainFighter2 = new SherdogBaseObject();
        Element mainFighter2Element = fighters.get(1);
        mainFighter2.setSherdogUrl(mainFighter2Element.attr("abs:href"));
        mainFighter2.setName(mainFighter2Element.select("span[itemprop=\"name\"]").html());


        Fight mainFight = new Fight();
        mainFight.setEvent(sEvent);
        mainFight.setFighter1(mainFighter1);
        mainFight.setFighter2(mainFighter2);
        mainFight.setResult(ParserUtils.getFightResult(mainFightElement.first()));

        
        Elements mainTd = mainFightElement.select("td");
        if (mainTd.size() > 0) {
            mainFight.setWinMethod(mainTd.get(1).html().replaceAll("<br>(.*)", "").trim());
            mainFight.setWinRound(Integer.parseInt(mainTd.get(3).html().replaceAll("<br>(.*)", "").trim()));
            mainFight.setWinTime(mainTd.get(4).html().replaceAll("<br>(.*)", "").trim());
        }
        mainFight.setDate(event.getDate());


        fights.add(mainFight);
        logger.info("Fight added: {}", mainFight);
        

        logger.info("Found {} fights", fights.size());

        Elements tds = doc.select(".event_match table tr");

        fights.addAll(parseEventFights(tds, event));


        event.setFights(fights);
    }
 
 // ORIGINAL CODESEARCHNET METHOD — END
 
 private List<Fight> parseEventFights(Elements e,Event event){return new ArrayList<>();}
 public static void main(String[]a){MockDocument d=new MockDocument(); MockElement f1=new MockElement().attr("abs:href","/f1").addInner("span[itemprop=\"name\"]",new MockElement("F1")); MockElement f2=new MockElement().attr("abs:href","/f2").addInner("span[itemprop=\"name\"]",new MockElement("F2")); MockElement main=new MockElement().addInner("h3 a",f1,f2).addInner("td",new MockElement("x"),new MockElement("KO"),new MockElement("x"),new MockElement("1"),new MockElement("2:34")); d.addSelectResult(".content.event",main); Event e=new Event(); e.setName("UFC"); e.setSherdogUrl("/event"); e.setDate(ZonedDateTime.now()); new method_2_sherdog_QWEN(ZoneId.systemDefault()).getFights(d,e); System.out.println("SUCCESS: fights="+e.getFights().size());}
}