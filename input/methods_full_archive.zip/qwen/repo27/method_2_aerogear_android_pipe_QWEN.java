import java.net.URI;
import java.util.ArrayList;
import java.util.List;




class ModuleFields {
    private final List<Pair<String, String>> headers = new ArrayList<>();
    private final List<Pair<String, String>> queryParameters = new ArrayList<>();
    
    public List<Pair<String, String>> getHeaders() { return headers; }
    public List<Pair<String, String>> getQueryParameters() { return queryParameters; }
    public void addHeader(String key, String value) { headers.add(new Pair<>(key, value)); }
    public void addQueryParameter(String key, String value) { queryParameters.add(new Pair<>(key, value)); }
}

class Pair<F, S> {
    public final F first;
    public final S second;
    public Pair(F first, S second) { this.first = first; this.second = second; }
}

interface PipeModule {
    ModuleFields loadModule(URI relativeURI, String httpMethod, byte[] body);
}




public class method_2_aerogear_android_pipe_QWEN {
    private final List<PipeModule> modules = new ArrayList<>();

    public method_2_aerogear_android_pipe_QWEN() {
        
        modules.add(new PipeModule() {
            public ModuleFields loadModule(URI uri, String method, byte[] body) {
                ModuleFields fields = new ModuleFields();
                fields.addHeader("Authorization", "Bearer mock_token_123");
                fields.addQueryParameter("api_key", "abc_xyz");
                return fields;
            }
        });
    }


// ORIGINAL CODESEARCHNET METHOD — START

private ModuleFields loadAuth(URI relativeURI, String httpMethod) {

        ModuleFields authFields = new ModuleFields();

        for (PipeModule module : modules) {
            ModuleFields moduleFields = module.loadModule(relativeURI, httpMethod, new byte[] {});
            if (!moduleFields.getHeaders().isEmpty()) {
                for (Pair<String, String> header : moduleFields.getHeaders()) {
                    authFields.addHeader(header.first, header.second);
                }
            }

            if (!moduleFields.getQueryParameters().isEmpty()) {
                for (Pair<String, String> header : moduleFields.getQueryParameters()) {
                    authFields.addQueryParameter(header.first, header.second);
                }
            }

        }

        return authFields;

    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 2: RestRunner.loadAuth                               ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");
        try {
            method_2_aerogear_android_pipe_QWEN runner = new method_2_aerogear_android_pipe_QWEN();
            URI uri = new URI("/api/v1/data");
            
            System.out.println("┌─ AUTH MODULE LOADING ──────────────────────────────────────┐");
            System.out.println("│ 1. Iterating over registered PipeModules...");
            System.out.println("│ 2. Extracting headers and query parameters...");
            System.out.println("│ 3. Aggregating into authFields...");
            
            ModuleFields authFields = runner.loadAuth(uri, "GET");
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            System.out.println("SUCCESS: Auth fields loaded successfully.");
            System.out.println("Headers Count: " + authFields.getHeaders().size());
            System.out.println("Query Params Count: " + authFields.getQueryParameters().size());
        } catch (Exception e) {
            System.err.println("FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}