import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




class HeaderAndBody {}
class JSONObject {
    private final Map<String, Object> map;
    public JSONObject(Map<String, Object> map) { this.map = map; }
}
interface Pipe<T> {}

class PageConfig {
    public enum MetadataLocations { WEB_LINKING, HEADERS, BODY }
    private MetadataLocations location = MetadataLocations.WEB_LINKING;
    private final String nextIdentifier = "next";
    private final String previousIdentifier = "prev";
    private final PageParameterExtractor extractor = new PageParameterExtractor();
    
    public MetadataLocations getMetadataLocation() { return location; }
    public void setMetadataLocation(MetadataLocations l) { this.location = l; }
    public String getNextIdentifier() { return nextIdentifier; }
    public String getPreviousIdentifier() { return previousIdentifier; }
    public PageParameterExtractor getPageParameterExtractor() { return extractor; }
}

class PageParameterExtractor {
    public ReadFilter getNextFilter(HeaderAndBody response, PageConfig config) { return null; }
    public ReadFilter getPreviousFilter(HeaderAndBody response, PageConfig config) { return null; }
}

class ReadFilter {
    private URI linkUri;
    private JSONObject where;
    public void setLinkUri(URI uri) { this.linkUri = uri; }
    public void setWhere(JSONObject where) { this.where = where; }
}

class WebLink {
    String uri;
    final Map<String, String> parameters = new HashMap<>();
    public String getUri() { return uri; }
    public Map<String, String> getParameters() { return parameters; }
}

class WebLinkParser {
    public static List<WebLink> parse(String raw) throws ParseException {
        List<WebLink> links = new ArrayList<>();
        WebLink nextLink = new WebLink();
        nextLink.uri = "https://api.example.com/data?page=2";
        nextLink.parameters.put("rel", "next");
        links.add(nextLink);
        
        WebLink prevLink = new WebLink();
        prevLink.uri = "https://api.example.com/data?page=1";
        prevLink.parameters.put("rel", "prev");
        links.add(prevLink);
        return links;
    }
}

class Log {
    public static void e(String tag, String msg, Throwable t) { 
        System.err.println("[ERROR] " + tag + ": " + msg + " - " + t.getMessage()); 
    }
}

class WrappingPagedList<T> extends ArrayList<T> {
    public WrappingPagedList(Pipe<T> pipe, List<T> result, ReadFilter next, ReadFilter prev) {
        super(result);
    }
}




public class method_1_aerogear_android_pipe_QWEN {
    private static final String TAG = "RestAdapter";
    private final PageConfig pageConfig = new PageConfig();

    private String getWebLinkHeader(HeaderAndBody httpResponse) {
        return "<https://api.example.com/data?page=2>; rel=\"next\", <https://api.example.com/data?page=1>; rel=\"prev\"";
    }


// ORIGINAL CODESEARCHNET METHOD — START

private <T> List<T> computePagedList(List<T> result, HeaderAndBody httpResponse, JSONObject where, Pipe<T> requestingPipe) {
        ReadFilter previousRead = null;
        ReadFilter nextRead = null;

        if (PageConfig.MetadataLocations.WEB_LINKING.equals(pageConfig.getMetadataLocation())) {
            String webLinksRaw = "";
            final String relHeader = "rel";
            final String nextIdentifier = pageConfig.getNextIdentifier();
            final String prevIdentifier = pageConfig.getPreviousIdentifier();
            try {
                webLinksRaw = getWebLinkHeader(httpResponse);
                if (webLinksRaw == null) { 
                    return result;
                }
                List<WebLink> webLinksParsed = WebLinkParser.parse(webLinksRaw);
                for (WebLink link : webLinksParsed) {
                    if (nextIdentifier.equals(link.getParameters().get(relHeader))) {
                        nextRead = new ReadFilter();
                        nextRead.setLinkUri(new URI(link.getUri()));
                    } else if (prevIdentifier.equals(link.getParameters().get(relHeader))) {
                        previousRead = new ReadFilter();
                        previousRead.setLinkUri(new URI(link.getUri()));
                    }

                }
            } catch (URISyntaxException ex) {
                Log.e(TAG, webLinksRaw + " did not contain a valid context URI", ex);
                throw new RuntimeException(ex);
            } catch (ParseException ex) {
                Log.e(TAG, webLinksRaw + " could not be parsed as a web link header", ex);
                throw new RuntimeException(ex);
            }
        } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.HEADERS)) {
            nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, this.pageConfig);
            previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, this.pageConfig);
        } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.BODY)) {
            nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, this.pageConfig);
            previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, this.pageConfig);
        } else {
            throw new IllegalStateException("Not supported");
        }
        if (nextRead != null) {
            nextRead.setWhere(where);
        }

        if (previousRead != null) {
            previousRead.setWhere(where);
        }

        return new WrappingPagedList<T>(requestingPipe, result, nextRead, previousRead);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 1: RestAdapter.computePagedList                      ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");
        try {
            method_1_aerogear_android_pipe_QWEN adapter = new method_1_aerogear_android_pipe_QWEN();
            
            List<String> result = new ArrayList<>();
            result.add("item1");
            HeaderAndBody httpResponse = new HeaderAndBody();
            JSONObject where = new JSONObject(new HashMap<>());
            Pipe<String> pipe = new Pipe<String>() {};
            
            System.out.println("┌─ PAGED LIST COMPUTATION ───────────────────────────────────┐");
            System.out.println("│ 1. Parsing Web Link header for 'next' and 'prev'...");
            System.out.println("│ 2. Creating ReadFilter objects with URIs...");
            System.out.println("│ 3. Attaching 'where' clause to filters...");
            System.out.println("│ 4. Returning WrappingPagedList...");
            
            List<String> pagedList = adapter.computePagedList(result, httpResponse, where, pipe);
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            System.out.println("SUCCESS: Paged list computed successfully. Size: " + pagedList.size());
        } catch (Exception e) {
            System.err.println("FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}