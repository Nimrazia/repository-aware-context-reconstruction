import java.util.*;




interface OWLAxiom {}
class OWLClass {
    private final String name;
    public OWLClass(String name) { this.name = name; }
    public String toString() { return name; }
    public boolean equals(Object o) { return o instanceof OWLClass && ((OWLClass)o).name.equals(this.name); }
    public int hashCode() { return name.hashCode(); }
}
interface OWLOntology { Set<OWLAxiom> getLogicalAxioms(); Set<OWLOntology> getImportsClosure(); }
interface OWLReasoner { OWLOntology getRootOntology(); }
interface OWLOntologyManager { OWLDataFactory getOWLDataFactory(); }
interface OWLDataFactory { OWLAxiom getOWLSubClassOfAxiom(OWLClass sub, OWLClass sup); OWLClass getOWLNothing(); }
class ExplanationException extends Exception {}
class OWLException extends Exception {}

class Explanation<E> {
    private final Set<OWLAxiom> axioms;
    public Explanation(Set<OWLAxiom> axioms) { this.axioms = axioms; }
    public Set<OWLAxiom> getAxioms() { return axioms; }
}

interface ExplanationGenerator<E> { Set<Explanation<E>> getExplanations(E entailment); }
interface ExplanationGeneratorFactory<E> { ExplanationGenerator<E> createExplanationGenerator(Set<OWLAxiom> axioms); }

class ExplanationManager {
    public static <E> ExplanationGeneratorFactory<E> createExplanationGeneratorFactory(Object factory) {
        return new ExplanationGeneratorFactory<E>() {
            public ExplanationGenerator<E> createExplanationGenerator(Set<OWLAxiom> axioms) {
                return new ExplanationGenerator<E>() {
                    public Set<Explanation<E>> getExplanations(E entailment) {
                        return Collections.singleton(new Explanation<E>(Collections.emptySet()));
                    }
                };
            }
        };
    }
}




public class method_3_owlexplanation_qwen {
    private OWLOntologyManager manager;
    private OWLReasoner baseReasoner;
    private Object reasonerFactory;
    private Map<OWLClass, Set<Explanation<OWLAxiom>>> cls2JustificationMap;
    private Set<OWLClass> roots = new HashSet<>();

    public method_3_owlexplanation_qwen(OWLOntologyManager manager, OWLReasoner baseReasoner, Object reasonerFactory) {
        this.manager = manager; this.baseReasoner = baseReasoner; this.reasonerFactory = reasonerFactory;
    }
    
    private boolean isRootFor(Explanation<OWLAxiom> a, Explanation<OWLAxiom> b) {
        return a.getAxioms().containsAll(b.getAxioms()); 
    }


// ORIGINAL CODESEARCHNET METHOD — START

public Set<OWLClass> getRootUnsatisfiableClasses() throws ExplanationException {
        StructuralRootDerivedReasoner srd = new StructuralRootDerivedReasoner(manager, baseReasoner, reasonerFactory);
        Set<OWLClass> estimatedRoots = srd.getRootUnsatisfiableClasses();
        cls2JustificationMap = new HashMap<OWLClass, Set<Explanation<OWLAxiom>>>();
        Set<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
        for (OWLOntology ont : baseReasoner.getRootOntology().getImportsClosure()) {
            allAxioms.addAll(ont.getLogicalAxioms());
        }

        for (OWLClass cls : estimatedRoots) {
            cls2JustificationMap.put(cls, new HashSet<Explanation<OWLAxiom>>());
            System.out.println("POTENTIAL ROOT: " + cls);
        }
        System.out.println("Finding real roots from " + estimatedRoots.size() + " estimated roots");

        int done = 0;
        roots.addAll(estimatedRoots);
        for (final OWLClass estimatedRoot : estimatedRoots) {
            ExplanationGeneratorFactory<OWLAxiom> genFac = ExplanationManager.createExplanationGeneratorFactory(reasonerFactory);
            ExplanationGenerator<OWLAxiom> gen = genFac.createExplanationGenerator(allAxioms);
            OWLDataFactory df = manager.getOWLDataFactory();
            Set<Explanation<OWLAxiom>> expls = gen.getExplanations(df.getOWLSubClassOfAxiom(estimatedRoot, df.getOWLNothing()));
            cls2JustificationMap.get(estimatedRoot).addAll(expls);
            done++;
            System.out.println("Done " + done);
        }
        for(OWLClass clsA : estimatedRoots) {
            for(OWLClass clsB : estimatedRoots) {
                if (!clsA.equals(clsB)) {
                    Set<Explanation<OWLAxiom>> clsAExpls = cls2JustificationMap.get(clsA);
                    Set<Explanation<OWLAxiom>> clsBExpls = cls2JustificationMap.get(clsB);
                    boolean clsARootForClsB = false;
                    boolean clsBRootForClsA = false;
                    
                    for(Explanation<OWLAxiom> clsAExpl : clsAExpls) {
                        for(Explanation<OWLAxiom> clsBExpl : clsBExpls) {
                            if(isRootFor(clsAExpl, clsBExpl)) {
                                
                                clsARootForClsB = true;
                            }
                            else if(isRootFor(clsBExpl, clsAExpl)) {
                                
                                clsBRootForClsA = true;
                            }
                        }
                    }
                    if (!clsARootForClsB || !clsBRootForClsA) {
                        if(clsARootForClsB) {
                            roots.remove(clsB);
                        }
                        else if(clsBRootForClsA) {
                            roots.remove(clsA);
                        }
                    }
                }
            }
        }
        return roots;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    static class StructuralRootDerivedReasoner {
        private OWLOntologyManager manager; private OWLReasoner baseReasoner; private Object reasonerFactory;
        public StructuralRootDerivedReasoner(OWLOntologyManager m, OWLReasoner r, Object f) { this.manager = m; this.baseReasoner = r; this.reasonerFactory = f; }
        public Set<OWLClass> getRootUnsatisfiableClasses() {
            Set<OWLClass> roots = new HashSet<>();
            roots.add(new OWLClass("UnsatisfiableA"));
            roots.add(new OWLClass("UnsatisfiableB"));
            return roots;
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 3: CompleteRootDerivedReasoner.getRootUnsatisfiable  ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");
        
        OWLReasoner mockReasoner = new OWLReasoner() {
            public OWLOntology getRootOntology() {
                return new OWLOntology() {
                    public Set<OWLOntology> getImportsClosure() { return Collections.singleton(this); }
                    public Set<OWLAxiom> getLogicalAxioms() { return Collections.emptySet(); }
                };
            }
        };
        OWLOntologyManager mockManager = new OWLOntologyManager() {
            public OWLDataFactory getOWLDataFactory() {
                return new OWLDataFactory() {
                    public OWLAxiom getOWLSubClassOfAxiom(OWLClass sub, OWLClass sup) { return new OWLAxiom() {}; }
                    public OWLClass getOWLNothing() { return new OWLClass("Nothing"); }
                };
            }
        };

        method_3_owlexplanation_qwen reasoner = new method_3_owlexplanation_qwen(mockManager, mockReasoner, new Object());
        
        System.out.println("┌─ ROOT UNSATISFIABLE CLASS DETECTION ─────────────────────────┐");
        System.out.println("│ 1. Estimating potential roots via StructuralReasoner...");
        System.out.println("│ 2. Gathering all logical axioms from imports closure...");
        System.out.println("│ 3. Generating explanations for each estimated root...");
        System.out.println("│ 4. Filtering out non-root classes based on dependency...");
        
        Set<OWLClass> roots = reasoner.getRootUnsatisfiableClasses();
        
        System.out.println("└──────────────────────────────────────────────────────────────┘\n");
        System.out.println("SUCCESS: Found " + roots.size() + " root unsatisfiable class(es).");
    }
}