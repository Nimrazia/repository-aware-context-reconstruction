import java.util.*;




interface OWLAxiom {}
interface OWLClassExpression { boolean isAnonymous(); OWLClass asOWLClass(); }

class OWLClass implements OWLClassExpression {
    private final String name;
    public OWLClass(String name) { this.name = name; }
    public boolean isAnonymous() { return false; }
    public OWLClass asOWLClass() { return this; }
    public String toString() { return name; }
    public boolean equals(Object o) { return o instanceof OWLClass && ((OWLClass)o).name.equals(this.name); }
    public int hashCode() { return name.hashCode(); }
}

interface OWLSubClassOfAxiom extends OWLAxiom { OWLClassExpression getSubClass(); OWLClassExpression getSuperClass(); }
interface OWLObjectIntersectionOf extends OWLClassExpression {}

class OWLDataFactory {
    public OWLDataFactory getOWLDataFactory() { return this; }
    public OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClassExpression sub, OWLClassExpression sup) {
        return new OWLSubClassOfAxiom() {
            public OWLClassExpression getSubClass() { return sub; }
            public OWLClassExpression getSuperClass() { return sup; }
        };
    }
    public OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression> operands) {
        return new OWLObjectIntersectionOf() { public boolean isAnonymous() { return true; } public OWLClass asOWLClass() { return null; } };
    }
}

class OWLOntology { public boolean containsAxiom(OWLAxiom ax) { return true; } }

class Explanation<E> {
    private final E entailment;
    private final Set<OWLAxiom> axioms;
    public Explanation(E entailment, Set<OWLAxiom> axioms) { this.entailment = entailment; this.axioms = axioms; }
    public E getEntailment() { return entailment; }
    public Set<OWLAxiom> getAxioms() { return axioms; }
    public boolean equals(Object o) { return o instanceof Explanation && ((Explanation<?>)o).axioms.equals(this.axioms); }
    public int hashCode() { return axioms.hashCode(); }
}




public class method_2_owlexplanation_qwen<E> {
    private OWLOntology ont = new OWLOntology() {};
    private OWLDataFactory man = new OWLDataFactory();
    private Set<Explanation<E>> allPreviouslyFoundJustifications = new HashSet<>();
    private Set<Explanation<E>> foundLaconicJustifications = new HashSet<>();

    private Set<OWLAxiom> computeOPlus(Set<OWLAxiom> axioms) {
        return new HashSet<>(axioms); 
    }


// ORIGINAL CODESEARCHNET METHOD — START

private Set<Explanation<E>> getReconstitutedLaconicJustifications() {
        

        
        
        
        
        Map<OWLAxiom, Set<OWLAxiom>> sourceAxioms2OPlus = new HashMap<OWLAxiom, Set<OWLAxiom>>();

        for (Explanation<E> exp : allPreviouslyFoundJustifications) {
            for (OWLAxiom ax : exp.getAxioms()) {
                if (ont.containsAxiom(ax)) {
                    sourceAxioms2OPlus.put(ax, computeOPlus(Collections.singleton(ax)));
                }
            }
        }

        Set<Explanation<E>> reconstituedExplanations = new HashSet<Explanation<E>>();
        for (Explanation<E> laconicExp : foundLaconicJustifications) {
            
            Map<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>> lhs2SubClassAxiom = new HashMap<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>>();

            Set<OWLAxiom> reconstituedAxioms = new HashSet<OWLAxiom>();
            for (OWLAxiom laconicAx : laconicExp.getAxioms()) {
                if (laconicAx instanceof OWLSubClassOfAxiom) {
                    OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) laconicAx;
                    if (sca.getSubClass().isAnonymous()) {
                        
                        reconstituedAxioms.add(sca);
                        continue;
                    }
                    Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2AxiomMap = lhs2SubClassAxiom.get(sca.getSubClass().asOWLClass());
                    if (source2AxiomMap == null) {
                        source2AxiomMap = new HashMap<OWLAxiom, Set<OWLSubClassOfAxiom>>();
                        lhs2SubClassAxiom.put(sca.getSubClass().asOWLClass(), source2AxiomMap);
                    }
                    for (OWLAxiom sourceAx : sourceAxioms2OPlus.keySet()) {
                        if (sourceAxioms2OPlus.get(sourceAx).contains(sca)) {
                            Set<OWLSubClassOfAxiom> subClassAxioms = source2AxiomMap.get(sourceAx);
                            if (subClassAxioms == null) {
                                subClassAxioms = new HashSet<OWLSubClassOfAxiom>();
                                source2AxiomMap.put(sourceAx, subClassAxioms);
                            }
                            subClassAxioms.add(sca);
                        }
                    }
                }
                else {
                    reconstituedAxioms.add(laconicAx);
                }
            }
            
            Set<OWLSubClassOfAxiom> consumedAxioms = new HashSet<OWLSubClassOfAxiom>();
            for (OWLClass lhs : lhs2SubClassAxiom.keySet()) {
                Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2SubClassAxiom = lhs2SubClassAxiom.get(lhs);
                for (OWLAxiom source : source2SubClassAxiom.keySet()) {
                    Set<OWLClassExpression> rightHandSides = new HashSet<OWLClassExpression>();
                    for (OWLSubClassOfAxiom subClassAx : source2SubClassAxiom.get(source)) {
                        if (!consumedAxioms.contains(subClassAx)) {
                            rightHandSides.add(subClassAx.getSuperClass());
                            consumedAxioms.add(subClassAx);
                        }
                    }
                    if (rightHandSides.size() == 1) {
                        reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, rightHandSides.iterator().next()));
                    }
                    else if (rightHandSides.size() > 1) {
                        OWLObjectIntersectionOf conjunction = man.getOWLDataFactory().getOWLObjectIntersectionOf(rightHandSides);
                        reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, conjunction));
                    }
                }
            }
            Explanation<E> explanation = new Explanation<E>(laconicExp.getEntailment(), reconstituedAxioms);
            reconstituedExplanations.add(explanation);

        }
        return reconstituedExplanations;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 2: LaconicExplanationGenerator.getReconstituted...   ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");
        
        method_2_owlexplanation_qwen<String> gen = new method_2_owlexplanation_qwen<>();
        
        OWLClass lhs = new OWLClass("Person");
        OWLClass rhs1 = new OWLClass("Mortal");
        OWLClass rhs2 = new OWLClass("Animal");
        OWLSubClassOfAxiom ax1 = gen.man.getOWLSubClassOfAxiom(lhs, rhs1);
        OWLSubClassOfAxiom ax2 = gen.man.getOWLSubClassOfAxiom(lhs, rhs2);
        
        Explanation<String> exp = new Explanation<>("Entailment", new HashSet<>(Arrays.asList((OWLAxiom)ax1, (OWLAxiom)ax2)));
        gen.foundLaconicJustifications.add(exp);
        gen.allPreviouslyFoundJustifications.add(exp);
        
        System.out.println("┌─ RECONSTITUTION PROCESS ─────────────────────────────────────┐");
        System.out.println("│ 1. Computing O+ for source axioms...");
        System.out.println("│ 2. Grouping subclass axioms by LHS and source...");
        System.out.println("│ 3. Merging axioms with common LHS into conjunctions...");
        
        Set<Explanation<String>> result = gen.getReconstitutedLaconicJustifications();
        
        System.out.println("└──────────────────────────────────────────────────────────────┘\n");
        System.out.println("SUCCESS: Reconstituted " + result.size() + " explanation(s).");
    }
}