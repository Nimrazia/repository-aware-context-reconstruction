import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;



















public class method_2_geomajas_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public ClientLayerInfo securityClone(ClientLayerInfo original) {
        
        if (null == original) {
            return null;
        }
        ClientLayerInfo client = null;
        String layerId = original.getServerLayerId();
        if (securityContext.isLayerVisible(layerId)) {
            client = (ClientLayerInfo) SerializationUtils.clone(original);
            client.setWidgetInfo(securityClone(original.getWidgetInfo()));
            client.getLayerInfo().setExtraInfo(securityCloneLayerExtraInfo(original.getLayerInfo().getExtraInfo()));
            if (client instanceof ClientVectorLayerInfo) {
                ClientVectorLayerInfo vectorLayer = (ClientVectorLayerInfo) client;
                
                vectorLayer.setCreatable(securityContext.isLayerCreateAuthorized(layerId));
                vectorLayer.setUpdatable(securityContext.isLayerUpdateAuthorized(layerId));
                vectorLayer.setDeletable(securityContext.isLayerDeleteAuthorized(layerId));
                
                FeatureInfo featureInfo = vectorLayer.getFeatureInfo();
                List<AttributeInfo> originalAttr = featureInfo.getAttributes();
                List<AttributeInfo> filteredAttr = new ArrayList<AttributeInfo>();
                featureInfo.setAttributes(filteredAttr);
                for (AttributeInfo ai : originalAttr) {
                    if (securityContext.isAttributeReadable(layerId, null, ai.getName())) {
                        filteredAttr.add(ai);
                    }
                }
            }
        }
        return client;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== Geomajas GetMapConfigurationCommand.securityClone (Layer) Test ===");
        method_2_geomajas_QWEN command = new method_2_geomajas_QWEN();
        
        
        
        
        
        
        ClientVectorLayerInfo original = new ClientVectorLayerInfo();
        original.setServerLayerId("countries");
        original.setLayerType("vector");
        original.setNamedLayerId("countries-layer");
        original.setPanEditable(false);
        original.setSnappable(true);
        
        
        Map<String, ClientWidgetInfo> widgetMap = new HashMap<>();
        
        ClientWidgetInfo legendWidget = new ClientWidgetInfo();
        legendWidget.setId("layerLegend");
        legendWidget.setWidgetType("legend");
        legendWidget.setTitle("Layer Legend");
        legendWidget.setVisible(true);
        widgetMap.put("layerLegend", legendWidget);
        
        ClientWidgetInfo attributeWidget = new ClientWidgetInfo();
        attributeWidget.setId("attributeList");
        attributeWidget.setWidgetType("attribute-table");
        attributeWidget.setTitle("Feature Attributes");
        attributeWidget.setVisible(true);
        widgetMap.put("attributeList", attributeWidget);
        
        ServerSideOnlyInfo serverProcessor = new ServerSideOnlyInfo();
        serverProcessor.setId("serverProcessor");
        serverProcessor.setWidgetType("processor");
        serverProcessor.setServerSideHandler("org.geomajas.command.CommandService");
        widgetMap.put("serverProcessor", serverProcessor);
        
        ServerSideOnlyInfo cacheManager = new ServerSideOnlyInfo();
        cacheManager.setId("cacheManager");
        cacheManager.setWidgetType("cache-manager");
        cacheManager.setCacheable(true);
        widgetMap.put("cacheManager", cacheManager);
        
        original.setWidgetInfo(widgetMap);
        
        
        LayerInfo layerInfo = new LayerInfo();
        layerInfo.setId("countries-base");
        layerInfo.setLayerType("vector");
        
        Map<String, LayerExtraInfo> extraMap = new HashMap<>();
        
        LayerExtraInfo metadata = new LayerExtraInfo();
        metadata.setId("metadata");
        metadata.setType("description");
        metadata.setMetadata(Map.of("title", "Countries of the World", "source", "Natural Earth"));
        extraMap.put("metadata", metadata);
        
        LayerExtraInfo styling = new LayerExtraInfo();
        styling.setId("styling");
        styling.setType("style");
        styling.setMetadata(Map.of("fillColor", "#00FF00", "strokeColor", "#000000"));
        extraMap.put("styling", styling);
        
        ServerSideLayerExtraInfo serverConfig = new ServerSideLayerExtraInfo();
        serverConfig.setId("serverConfig");
        serverConfig.setType("config");
        serverConfig.setMetadata(Map.of("internal", "true"));
        extraMap.put("serverConfig", serverConfig);
        
        layerInfo.setExtraInfo(extraMap);
        original.setLayerInfo(layerInfo);
        
        
        FeatureInfo featureInfo = new FeatureInfo();
        
        GeometryType geometryType = new GeometryType();
        geometryType.setType("MultiPolygon");
        geometryType.setDimension(2);
        featureInfo.setGeometryType(geometryType);
        
        List<AttributeInfo> attrs = new ArrayList<>();
        
        AttributeInfo nameAttr = new AttributeInfo();
        nameAttr.setName("name");
        nameAttr.setType("string");
        nameAttr.setLabel("Country Name");
        nameAttr.setEditable(true);
        nameAttr.setIdentifier(true);
        attrs.add(nameAttr);
        
        AttributeInfo populationAttr = new AttributeInfo();
        populationAttr.setName("population");
        populationAttr.setType("integer");
        populationAttr.setLabel("Population");
        populationAttr.setEditable(false);
        attrs.add(populationAttr);
        
        AttributeInfo areaAttr = new AttributeInfo();
        areaAttr.setName("area");
        areaAttr.setType("double");
        areaAttr.setLabel("Area in km²");
        areaAttr.setEditable(false);
        attrs.add(areaAttr);
        
        AttributeInfo secretCodeAttr = new AttributeInfo();
        secretCodeAttr.setName("secret_code");
        secretCodeAttr.setType("string");
        secretCodeAttr.setLabel("Internal Code");
        secretCodeAttr.setHidden(true);
        attrs.add(secretCodeAttr);
        
        AttributeInfo internalIdAttr = new AttributeInfo();
        internalIdAttr.setName("internal_id");
        internalIdAttr.setType("integer");
        internalIdAttr.setLabel("Internal ID");
        internalIdAttr.setHidden(true);
        attrs.add(internalIdAttr);
        
        AttributeInfo gdpAttr = new AttributeInfo();
        gdpAttr.setName("gdp");
        gdpAttr.setType("double");
        gdpAttr.setLabel("GDP in USD");
        gdpAttr.setEditable(false);
        attrs.add(gdpAttr);
        
        featureInfo.setAttributes(attrs);
        original.setFeatureInfo(featureInfo);
        
        
        
        
        System.out.println("\n--- ORIGINAL LAYER STATE ---");
        System.out.println("Server Layer ID: " + original.getServerLayerId());
        System.out.println("Layer Type: " + original.getLayerType());
        System.out.println("Widgets count: " + original.getWidgetInfo().size());
        System.out.println("  - Client widgets: " + countClientWidgets(original.getWidgetInfo()));
        System.out.println("  - Server widgets: " + countServerWidgets(original.getWidgetInfo()));
        System.out.println("Extra info count: " + original.getLayerInfo().getExtraInfo().size());
        System.out.println("  - Client extra: " + countClientExtra(original.getLayerInfo().getExtraInfo()));
        System.out.println("  - Server extra: " + countServerExtra(original.getLayerInfo().getExtraInfo()));
        System.out.println("Attributes count: " + original.getFeatureInfo().getAttributes().size());
        System.out.println("Attribute names: " + getAttributeNames(original.getFeatureInfo().getAttributes()));
        
        
        
        
        try {
            System.out.println("\n--- INVOKING securityClone ---");
            ClientLayerInfo result = command.securityClone(original);
            
            System.out.println("\n--- CLONED LAYER STATE ---");
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            
            if (result == null) {
                System.out.println("Result is NULL (layer not visible)");
            } else if (result instanceof ClientVectorLayerInfo) {
                ClientVectorLayerInfo v = (ClientVectorLayerInfo) result;
                System.out.println("Server Layer ID: " + v.getServerLayerId());
                System.out.println("\nAuthorization flags:");
                System.out.println("  - Creatable: " + v.isCreatable());
                System.out.println("  - Updatable: " + v.isUpdatable());
                System.out.println("  - Deletable: " + v.isDeletable());
                
                System.out.println("\nFiltered widgets count: " + v.getWidgetInfo().size());
                System.out.println("  - Client widgets: " + countClientWidgets(v.getWidgetInfo()));
                System.out.println("  - Server widgets: " + countServerWidgets(v.getWidgetInfo()));
                System.out.println("  Widget IDs: " + v.getWidgetInfo().keySet());
                
                System.out.println("\nFiltered extra info count: " + v.getLayerInfo().getExtraInfo().size());
                System.out.println("  - Client extra: " + countClientExtra(v.getLayerInfo().getExtraInfo()));
                System.out.println("  - Server extra: " + countServerExtra(v.getLayerInfo().getExtraInfo()));
                System.out.println("  Extra IDs: " + v.getLayerInfo().getExtraInfo().keySet());
                
                System.out.println("\nFiltered attributes count: " + v.getFeatureInfo().getAttributes().size());
                System.out.println("Attribute names: " + getAttributeNames(v.getFeatureInfo().getAttributes()));
                
                
                
                
                System.out.println("\n--- VERIFICATION ---");
                boolean passed = true;
                
                
                if (v.getWidgetInfo().size() == 2 
                    && v.getWidgetInfo().containsKey("layerLegend")
                    && v.getWidgetInfo().containsKey("attributeList")) {
                    System.out.println("✓ Widgets correctly filtered (2 client, 0 server)");
                } else {
                    System.out.println("✗ Widget filtering failed");
                    passed = false;
                }
                
                
                if (v.getLayerInfo().getExtraInfo().size() == 2
                    && v.getLayerInfo().getExtraInfo().containsKey("metadata")
                    && v.getLayerInfo().getExtraInfo().containsKey("styling")) {
                    System.out.println("✓ Extra info correctly filtered (2 client, 0 server)");
                } else {
                    System.out.println("✗ Extra info filtering failed");
                    passed = false;
                }
                
                
                if (v.getFeatureInfo().getAttributes().size() == 4
                    && containsAttribute(v.getFeatureInfo().getAttributes(), "name")
                    && containsAttribute(v.getFeatureInfo().getAttributes(), "population")
                    && containsAttribute(v.getFeatureInfo().getAttributes(), "area")
                    && containsAttribute(v.getFeatureInfo().getAttributes(), "gdp")
                    && !containsAttribute(v.getFeatureInfo().getAttributes(), "secret_code")
                    && !containsAttribute(v.getFeatureInfo().getAttributes(), "internal_id")) {
                    System.out.println("✓ Attributes correctly filtered (4 readable, 2 hidden)");
                } else {
                    System.out.println("✗ Attribute filtering failed");
                    passed = false;
                }
                
                
                if (v.isCreatable() && v.isUpdatable() && !v.isDeletable()) {
                    System.out.println("✓ Authorization flags set correctly (create=T, update=T, delete=F)");
                } else {
                    System.out.println("✗ Authorization flags incorrect");
                    passed = false;
                }
                
                if (passed) {
                    System.out.println("\n=== ALL VERIFICATIONS PASSED ===");
                } else {
                    System.out.println("\n=== SOME VERIFICATIONS FAILED ===");
                }
            }
            System.out.println("\n=== Test Completed Successfully ===");
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    private static int countClientWidgets(Map<String, ClientWidgetInfo> map) {
        int count = 0;
        for (ClientWidgetInfo w : map.values()) {
            if (!(w instanceof ServerSideOnlyInfo)) count++;
        }
        return count;
    }
    
    private static int countServerWidgets(Map<String, ClientWidgetInfo> map) {
        int count = 0;
        for (ClientWidgetInfo w : map.values()) {
            if (w instanceof ServerSideOnlyInfo) count++;
        }
        return count;
    }
    
    private static int countClientExtra(Map<String, LayerExtraInfo> map) {
        int count = 0;
        for (LayerExtraInfo e : map.values()) {
            if (!(e instanceof ServerSideLayerExtraInfo)) count++;
        }
        return count;
    }
    
    private static int countServerExtra(Map<String, LayerExtraInfo> map) {
        int count = 0;
        for (LayerExtraInfo e : map.values()) {
            if (e instanceof ServerSideLayerExtraInfo) count++;
        }
        return count;
    }
    
    private static List<String> getAttributeNames(List<AttributeInfo> attrs) {
        List<String> names = new ArrayList<>();
        for (AttributeInfo ai : attrs) {
            names.add(ai.getName());
        }
        return names;
    }
    
    private static boolean containsAttribute(List<AttributeInfo> attrs, String name) {
        for (AttributeInfo ai : attrs) {
            if (ai.getName().equals(name)) return true;
        }
        return false;
    }

    
    
    
    
    private SecurityContext securityContext = new SecurityContext();

    public static class SecurityContext {
        
        private Set<String> nonReadableAttributes = new HashSet<>(
            Arrays.asList("secret_code", "internal_id")
        );
        
        public boolean isLayerVisible(String layerId) { 
            return true; 
        }
        
        public boolean isLayerCreateAuthorized(String layerId) { 
            return true; 
        }
        
        public boolean isLayerUpdateAuthorized(String layerId) { 
            return true; 
        }
        
        public boolean isLayerDeleteAuthorized(String layerId) { 
            return false; 
        }
        
        public boolean isAttributeReadable(String layerId, String featureId, String attributeName) { 
            return !nonReadableAttributes.contains(attributeName);
        }
    }

    
    
    
    
    
    


    public Map<String, ClientWidgetInfo> securityClone(Map<String, ClientWidgetInfo> widgetInfo) {
        Map<String, ClientWidgetInfo> res = new HashMap<>();
        if (widgetInfo == null) return res;
        for (Map.Entry<String, ClientWidgetInfo> entry : widgetInfo.entrySet()) {
            if (!(entry.getValue() instanceof ServerSideOnlyInfo)) {
                res.put(entry.getKey(), entry.getValue());
            }
        }
        return res;
    }

    


    public Map<String, LayerExtraInfo> securityCloneLayerExtraInfo(Map<String, LayerExtraInfo> extraInfoMap) {
        Map<String, LayerExtraInfo> res = new HashMap<>();
        if (extraInfoMap == null) return res;
        for (Map.Entry<String, LayerExtraInfo> entry : extraInfoMap.entrySet()) {
            if (!(entry.getValue() instanceof ServerSideLayerExtraInfo)) {
                res.put(entry.getKey(), entry.getValue());
            }
        }
        return res;
    }

    
    
    
    
    public static class SerializationUtils {
        



        public static Object clone(Object obj) {
            if (obj == null) return null;
            
            if (obj instanceof ClientVectorLayerInfo) {
                ClientVectorLayerInfo orig = (ClientVectorLayerInfo) obj;
                ClientVectorLayerInfo copy = new ClientVectorLayerInfo();
                copy.setServerLayerId(orig.getServerLayerId());
                copy.setLayerType(orig.getLayerType());
                copy.setNamedLayerId(orig.getNamedLayerId());
                copy.setPanEditable(orig.isPanEditable());
                copy.setSnappable(orig.isSnappable());
                copy.setWidgetInfo(orig.getWidgetInfo()); 
                copy.setLayerInfo(orig.getLayerInfo());   
                copy.setFeatureInfo(orig.getFeatureInfo()); 
                return copy;
            } else if (obj instanceof ClientLayerInfo) {
                ClientLayerInfo orig = (ClientLayerInfo) obj;
                ClientLayerInfo copy = new ClientLayerInfo();
                copy.setServerLayerId(orig.getServerLayerId());
                copy.setLayerType(orig.getLayerType());
                copy.setNamedLayerId(orig.getNamedLayerId());
                copy.setWidgetInfo(orig.getWidgetInfo());
                copy.setLayerInfo(orig.getLayerInfo());
                return copy;
            }
            return obj;
        }
    }

    
    
    
    
    
    


    public static class ClientWidgetInfo {
        private String id;
        private String widgetType;
        private String title;
        private String cssStyle;
        private String cssClass;
        private boolean visible = true;
        private int marginTop;
        private int marginRight;
        private int marginBottom;
        private int marginLeft;
        private Map<String, String> parameters = new HashMap<>();
        private List<ClientWidgetInfo> children = new ArrayList<>();
        private Object userData;
        
        public ClientWidgetInfo() {}
        public ClientWidgetInfo(String id, String widgetType) {
            this.id = id;
            this.widgetType = widgetType;
        }
        
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getWidgetType() { return widgetType; }
        public void setWidgetType(String widgetType) { this.widgetType = widgetType; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getCssStyle() { return cssStyle; }
        public void setCssStyle(String cssStyle) { this.cssStyle = cssStyle; }
        public String getCssClass() { return cssClass; }
        public void setCssClass(String cssClass) { this.cssClass = cssClass; }
        public boolean isVisible() { return visible; }
        public void setVisible(boolean visible) { this.visible = visible; }
        public Map<String, String> getParameters() { return parameters; }
        public void setParameters(Map<String, String> parameters) { this.parameters = parameters; }
        public List<ClientWidgetInfo> getChildren() { return children; }
        public void setChildren(List<ClientWidgetInfo> children) { this.children = children; }
        public Object getUserData() { return userData; }
        public void setUserData(Object userData) { this.userData = userData; }
        
        @Override
        public String toString() {
            return "ClientWidgetInfo{id='" + id + "', type='" + widgetType + "'}";
        }
    }

    



    public static class ServerSideOnlyInfo extends ClientWidgetInfo {
        private String serverSideHandler;
        private boolean cacheable = false;
        private Map<String, String> metadata = new HashMap<>();
        
        public ServerSideOnlyInfo() {
            super();
        }
        public ServerSideOnlyInfo(String id, String widgetType) {
            super(id, widgetType);
        }
        
        public String getServerSideHandler() { return serverSideHandler; }
        public void setServerSideHandler(String serverSideHandler) { 
            this.serverSideHandler = serverSideHandler; 
        }
        public boolean isCacheable() { return cacheable; }
        public void setCacheable(boolean cacheable) { this.cacheable = cacheable; }
        public Map<String, String> getMetadata() { return metadata; }
        public void setMetadata(Map<String, String> metadata) { this.metadata = metadata; }
        
        @Override
        public String toString() {
            return "ServerSideOnlyInfo{id='" + getId() + "', type='" + getWidgetType() + "'}";
        }
    }

    


    public static class LayerInfo {
        private String id;
        private String layerType;
        private Map<String, LayerExtraInfo> extraInfo = new HashMap<>();
        
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getLayerType() { return layerType; }
        public void setLayerType(String layerType) { this.layerType = layerType; }
        public Map<String, LayerExtraInfo> getExtraInfo() { return extraInfo; }
        public void setExtraInfo(Map<String, LayerExtraInfo> extraInfo) { this.extraInfo = extraInfo; }
    }

    


    public static class LayerExtraInfo {
        private String id;
        private String type;
        private Map<String, String> metadata = new HashMap<>();
        
        public LayerExtraInfo() {}
        public LayerExtraInfo(String id, String type) {
            this.id = id;
            this.type = type;
        }
        
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public Map<String, String> getMetadata() { return metadata; }
        public void setMetadata(Map<String, String> metadata) { this.metadata = metadata; }
    }

    



    public static class ServerSideLayerExtraInfo extends LayerExtraInfo {
        private boolean cacheable;
        public boolean isCacheable() { return cacheable; }
        public void setCacheable(boolean cacheable) { this.cacheable = cacheable; }
    }

    


    public static class ClientLayerInfo {
        private String serverLayerId;
        private String layerType;
        private String namedLayerId;
        private boolean panEditable;
        private boolean snappable;
        private Map<String, ClientWidgetInfo> widgetInfo = new HashMap<>();
        private LayerInfo layerInfo = new LayerInfo();
        
        public String getServerLayerId() { return serverLayerId; }
        public void setServerLayerId(String serverLayerId) { this.serverLayerId = serverLayerId; }
        public String getLayerType() { return layerType; }
        public void setLayerType(String layerType) { this.layerType = layerType; }
        public String getNamedLayerId() { return namedLayerId; }
        public void setNamedLayerId(String namedLayerId) { this.namedLayerId = namedLayerId; }
        public boolean isPanEditable() { return panEditable; }
        public void setPanEditable(boolean panEditable) { this.panEditable = panEditable; }
        public boolean isSnappable() { return snappable; }
        public void setSnappable(boolean snappable) { this.snappable = snappable; }
        public Map<String, ClientWidgetInfo> getWidgetInfo() { return widgetInfo; }
        public void setWidgetInfo(Map<String, ClientWidgetInfo> widgetInfo) { this.widgetInfo = widgetInfo; }
        public LayerInfo getLayerInfo() { return layerInfo; }
        public void setLayerInfo(LayerInfo layerInfo) { this.layerInfo = layerInfo; }
    }

    



    public static class ClientVectorLayerInfo extends ClientLayerInfo {
        private boolean creatable;
        private boolean updatable;
        private boolean deletable;
        private FeatureInfo featureInfo;
        
        public boolean isCreatable() { return creatable; }
        public void setCreatable(boolean creatable) { this.creatable = creatable; }
        public boolean isUpdatable() { return updatable; }
        public void setUpdatable(boolean updatable) { this.updatable = updatable; }
        public boolean isDeletable() { return deletable; }
        public void setDeletable(boolean deletable) { this.deletable = deletable; }
        public FeatureInfo getFeatureInfo() { return featureInfo; }
        public void setFeatureInfo(FeatureInfo featureInfo) { this.featureInfo = featureInfo; }
    }

    


    public static class FeatureInfo {
        private GeometryType geometryType;
        private List<AttributeInfo> attributes = new ArrayList<>();
        
        public GeometryType getGeometryType() { return geometryType; }
        public void setGeometryType(GeometryType geometryType) { this.geometryType = geometryType; }
        public List<AttributeInfo> getAttributes() { return attributes; }
        public void setAttributes(List<AttributeInfo> attributes) { this.attributes = attributes; }
    }

    


    public static class GeometryType {
        public static final int TYPE_POINT = 1;
        public static final int TYPE_LINESTRING = 2;
        public static final int TYPE_POLYGON = 3;
        public static final int TYPE_MULTIPOINT = 4;
        public static final int TYPE_MULTILINESTRING = 5;
        public static final int TYPE_MULTIPOLYGON = 6;
        
        private String type;
        private int dimension = 2;
        
        public GeometryType() {}
        public GeometryType(String type) { this.type = type; }
        public GeometryType(String type, int dimension) {
            this.type = type;
            this.dimension = dimension;
        }
        
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public String getName() { return type; }
        public int getDimension() { return dimension; }
        public void setDimension(int dimension) { this.dimension = dimension; }
    }

    


    public static class AttributeInfo {
        private String name;
        private String type;
        private String label;
        private boolean editable = true;
        private boolean identifier = false;
        private boolean hidden = false;
        private boolean nillable = true;
        private int precision = -1;
        private int scale = -1;
        private String defaultValue;
        private Map<String, String> metadata = new HashMap<>();
        
        public AttributeInfo() {}
        public AttributeInfo(String name, String type, String label) {
            this.name = name;
            this.type = type;
            this.label = label;
        }
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public String getLabel() { return label; }
        public void setLabel(String label) { this.label = label; }
        public boolean isEditable() { return editable; }
        public void setEditable(boolean editable) { this.editable = editable; }
        public boolean isIdentifier() { return identifier; }
        public void setIdentifier(boolean identifier) { this.identifier = identifier; }
        public boolean isHidden() { return hidden; }
        public void setHidden(boolean hidden) { this.hidden = hidden; }
        public boolean isNillable() { return nillable; }
        public void setNillable(boolean nillable) { this.nillable = nillable; }
        public int getPrecision() { return precision; }
        public void setPrecision(int precision) { this.precision = precision; }
        public int getScale() { return scale; }
        public void setScale(int scale) { this.scale = scale; }
        public String getDefaultValue() { return defaultValue; }
        public void setDefaultValue(String defaultValue) { this.defaultValue = defaultValue; }
        public Map<String, String> getMetadata() { return metadata; }
        public void setMetadata(Map<String, String> metadata) { this.metadata = metadata; }
        
        @Override
        public String toString() {
            return "AttributeInfo{name='" + name + "', type='" + type + "', label='" + label + "'}";
        }
    }
}