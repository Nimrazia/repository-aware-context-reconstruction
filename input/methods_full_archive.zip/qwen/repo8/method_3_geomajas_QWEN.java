import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Arrays;






















public class method_3_geomajas_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void execute(SearchByLocationRequest request, SearchByLocationResponse response) throws Exception {
        if (null == request.getLayerIds()) {
            throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, "layerIds");
        }
        String crsCode = request.getCrs();
        if (null == crsCode) {
            throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, "crs");
        }
        Geometry location = converter.toInternal(request.getLocation());
        int queryType = request.getQueryType();
        double ratio = request.getRatio();
        int searchType = request.getSearchType();
        Crs crs = geoService.getCrs2(request.getCrs());

        
        Geometry geometry = location;
        if (request.getBuffer() > 0) {
            geometry = location.buffer(request.getBuffer());
        }
        log.debug("search by location " + geometry);

        for (String clientLayerId : request.getLayerIds()) {
            String serverLayerId = request.getServerLayerId(clientLayerId);
            if (null == serverLayerId) {
                throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, 
                                "serverLayerId for clientLayerId " + clientLayerId);
            }
            if (securityContext.isLayerVisible(serverLayerId)) {
                VectorLayer vectorLayer = configurationService.getVectorLayer(serverLayerId);
                if (vectorLayer != null) {
                    String geomName = vectorLayer.getLayerInfo().getFeatureInfo().getGeometryType().getName();

                    
                    Geometry layerGeometry = geoService.transform(geometry, crs, layerService.getCrs(vectorLayer));
                    log.trace("on layer " + serverLayerId + " use " + layerGeometry);

                    
                    Filter f = null;
                    switch (queryType) {
                        case SearchByLocationRequest.QUERY_INTERSECTS:
                            f = filterCreator.createIntersectsFilter(layerGeometry, geomName);
                            break;
                        case SearchByLocationRequest.QUERY_CONTAINS:
                            f = filterCreator.createContainsFilter(layerGeometry, geomName);
                            break;
                        case SearchByLocationRequest.QUERY_TOUCHES:
                            f = filterCreator.createTouchesFilter(layerGeometry, geomName);
                            break;
                        case SearchByLocationRequest.QUERY_WITHIN:
                            f = filterCreator.createWithinFilter(layerGeometry, geomName);
                            break;
                        default:
                            throw new IllegalArgumentException("Unknown query type " + queryType);
                    }
                    
                    if (null != request.getFilter(clientLayerId)) {
                        if (null == f) {
                            f = filterCreator.parseFilter(request.getFilter(clientLayerId));
                        } else {
                            f = filterCreator.createAndFilter(
                                    filterCreator.parseFilter(request.getFilter(clientLayerId)), f);
                        }
                    }
                    
                    if (null != request.getFilter()) {
                        if (null == f) {
                            f = filterCreator.parseFilter(request.getFilter());
                        } else {
                            f = filterCreator.createAndFilter(filterCreator.parseFilter(request.getFilter()), f);
                        }
                    }

                    
                    List<InternalFeature> temp = layerService.getFeatures(serverLayerId, crs, f, null, request
                            .getFeatureIncludes());
                    if (temp.size() > 0) {
                        List<Feature> features = new ArrayList<Feature>();

                        
                        if (queryType == SearchByLocationRequest.QUERY_INTERSECTS && ratio >= 0 && ratio < 1) {
                            for (InternalFeature feature : temp) {
                                double minimalOverlap = feature.getGeometry().getArea() * ratio;
                                Geometry overlap = geometry.intersection(feature.getGeometry());
                                double effectiveOverlap = overlap.getArea();
                                if (minimalOverlap <= effectiveOverlap) {
                                    log.trace("found " + feature);
                                    Feature dto = converter.toDto(feature);
                                    dto.setCrs(crsCode);
                                    features.add(dto);
                                }
                            }
                        } else {
                            for (InternalFeature feature : temp) {
                                log.trace("found " + feature);
                                Feature dto = converter.toDto(feature);
                                dto.setCrs(crsCode);
                                features.add(dto);
                            }
                        }

                        
                        if (features.size() > 0) {
                            
                            response.addLayer(clientLayerId, features);

                            
                            if (searchType == SearchByLocationRequest.SEARCH_FIRST_LAYER) {
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== Geomajas SearchByLocationCommand.execute Test ===\n");
        method_3_geomajas_QWEN command = new method_3_geomajas_QWEN();
        
        
        
        
        System.out.println("--- TEST 1: INTERSECTS with ratio=0.5, SEARCH_ALL_LAYERS ---");
        
        
        command.layerService.setMockFeatureCount("countries", 3);
        command.layerService.setMockFeatureArea("countries", 100.0);
        command.layerService.setMockOverlapRatio("countries", 0.6); 
        
        command.layerService.setMockFeatureCount("cities", 2);
        command.layerService.setMockFeatureArea("cities", 50.0);
        command.layerService.setMockOverlapRatio("cities", 0.3); 
        
        SearchByLocationRequest request1 = new SearchByLocationRequest();
        request1.setLayerIds(Arrays.asList("countries", "cities"));
        request1.setCrs("EPSG:4326");
        request1.setQueryType(SearchByLocationRequest.QUERY_INTERSECTS);
        request1.setRatio(0.5); 
        request1.setSearchType(SearchByLocationRequest.SEARCH_ALL_LAYERS);
        request1.setBuffer(0);
        request1.setLocation(new GeometryDto("Polygon", new double[][]{{0,0},{10,0},{10,10},{0,10},{0,0}}));
        
        SearchByLocationResponse response1 = new SearchByLocationResponse();
        
        try {
            System.out.println("Request CRS: " + request1.getCrs());
            System.out.println("Query Type: INTERSECTS (ratio=" + request1.getRatio() + ")");
            System.out.println("Search Type: ALL_LAYERS");
            System.out.println("Layers: " + request1.getLayerIds());
            
            System.out.println("\nInvoking execute...");
            command.execute(request1, response1);
            
            System.out.println("\nResults per layer:");
            for (Map.Entry<String, List<Feature>> entry : response1.getLayerResults().entrySet()) {
                System.out.println("  Layer '" + entry.getKey() + "': " + entry.getValue().size() + " features");
                for (Feature f : entry.getValue()) {
                    System.out.println("    - Feature ID: " + f.getId() + ", CRS: " + f.getCrs());
                }
            }
            
            
            if (response1.getLayerResults().size() == 1 
                && response1.getLayerResults().containsKey("countries")
                && response1.getLayerResults().get("countries").size() == 3) {
                System.out.println("\n✓ VERIFICATION PASSED: Only 'countries' layer returned results (ratio filter worked)");
            } else {
                System.out.println("\n✗ VERIFICATION FAILED: Unexpected results");
            }
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
        
        
        
        
        System.out.println("\n\n--- TEST 2: CONTAINS query, SEARCH_FIRST_LAYER ---");
        
        command.layerService.setMockFeatureCount("countries", 2);
        command.layerService.setMockFeatureCount("cities", 5);
        
        SearchByLocationRequest request2 = new SearchByLocationRequest();
        request2.setLayerIds(Arrays.asList("countries", "cities"));
        request2.setCrs("EPSG:4326");
        request2.setQueryType(SearchByLocationRequest.QUERY_CONTAINS);
        request2.setSearchType(SearchByLocationRequest.SEARCH_FIRST_LAYER);
        request2.setLocation(new GeometryDto("Polygon", new double[][]{{0,0},{20,0},{20,20},{0,20},{0,0}}));
        
        SearchByLocationResponse response2 = new SearchByLocationResponse();
        
        try {
            System.out.println("Request CRS: " + request2.getCrs());
            System.out.println("Query Type: CONTAINS");
            System.out.println("Search Type: SEARCH_FIRST_LAYER");
            System.out.println("Layers: " + request2.getLayerIds());
            
            System.out.println("\nInvoking execute...");
            command.execute(request2, response2);
            
            System.out.println("\nResults per layer:");
            for (Map.Entry<String, List<Feature>> entry : response2.getLayerResults().entrySet()) {
                System.out.println("  Layer '" + entry.getKey() + "': " + entry.getValue().size() + " features");
            }
            
            
            if (response2.getLayerResults().size() == 1 
                && response2.getLayerResults().containsKey("countries")
                && response2.getLayerResults().get("countries").size() == 2) {
                System.out.println("\n✓ VERIFICATION PASSED: Only first layer searched (SEARCH_FIRST_LAYER worked)");
            } else {
                System.out.println("\n✗ VERIFICATION FAILED: Unexpected results");
            }
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
        
        
        
        
        System.out.println("\n\n--- TEST 3: WITHIN query with buffer=5.0 ---");
        
        command.layerService.setMockFeatureCount("countries", 4);
        
        SearchByLocationRequest request3 = new SearchByLocationRequest();
        request3.setLayerIds(Arrays.asList("countries"));
        request3.setCrs("EPSG:4326");
        request3.setQueryType(SearchByLocationRequest.QUERY_WITHIN);
        request3.setBuffer(5.0);
        request3.setLocation(new GeometryDto("Point", new double[][]{{5,5}}));
        
        SearchByLocationResponse response3 = new SearchByLocationResponse();
        
        try {
            System.out.println("Request CRS: " + request3.getCrs());
            System.out.println("Query Type: WITHIN");
            System.out.println("Buffer: " + request3.getBuffer());
            System.out.println("Layers: " + request3.getLayerIds());
            
            System.out.println("\nInvoking execute...");
            command.execute(request3, response3);
            
            System.out.println("\nResults per layer:");
            for (Map.Entry<String, List<Feature>> entry : response3.getLayerResults().entrySet()) {
                System.out.println("  Layer '" + entry.getKey() + "': " + entry.getValue().size() + " features");
            }
            
            if (response3.getLayerResults().size() == 1 
                && response3.getLayerResults().get("countries").size() == 4) {
                System.out.println("\n✓ VERIFICATION PASSED: Buffer applied and WITHIN query executed");
            } else {
                System.out.println("\n✗ VERIFICATION FAILED: Unexpected results");
            }
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
        
        
        
        
        System.out.println("\n\n--- TEST 4: Missing layerIds parameter ---");
        
        SearchByLocationRequest request4 = new SearchByLocationRequest();
        request4.setCrs("EPSG:4326");
        
        
        SearchByLocationResponse response4 = new SearchByLocationResponse();
        
        try {
            command.execute(request4, response4);
            System.out.println("✗ VERIFICATION FAILED: Should have thrown exception for missing layerIds");
        } catch (GeomajasException e) {
            System.out.println("✓ VERIFICATION PASSED: Correctly threw GeomajasException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("✗ VERIFICATION FAILED: Wrong exception type: " + e.getClass().getName());
        }
        
        System.out.println("\n=== All Tests Completed ===");
    }

    
    
    
    private Logger log = new Logger();
    private ConfigurationService configurationService = new ConfigurationService();
    private GeoService geoService = new GeoService();
    private DtoConverterService converter = new DtoConverterService();
    private FilterService filterCreator = new FilterService();
    public VectorLayerService layerService = new VectorLayerService();
    private SecurityContext securityContext = new SecurityContext();

    public static class Logger {
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void trace(String msg) { System.out.println("[TRACE] " + msg); }
        public void info(String msg) { System.out.println("[INFO] " + msg); }
    }

    
    
    
    
    
    public static class SearchByLocationRequest {
        public static final int QUERY_INTERSECTS = 1;
        public static final int QUERY_CONTAINS = 2;
        public static final int QUERY_TOUCHES = 3;
        public static final int QUERY_WITHIN = 4;
        public static final int SEARCH_ALL_LAYERS = 0;
        public static final int SEARCH_FIRST_LAYER = 1;
        
        private List<String> layerIds;
        private String crs;
        private int queryType;
        private double ratio = -1;
        private int searchType = SEARCH_ALL_LAYERS;
        private double buffer = 0;
        private GeometryDto location;
        private Map<String, String> perLayerFilters = new HashMap<>();
        private String globalFilter;
        private String[] featureIncludes = new String[0];
        private Map<String, String> clientToServerLayerMap = new HashMap<>();
        
        public List<String> getLayerIds() { return layerIds; }
        public void setLayerIds(List<String> l) { this.layerIds = l; }
        public String getCrs() { return crs; }
        public void setCrs(String c) { this.crs = c; }
        public int getQueryType() { return queryType; }
        public void setQueryType(int q) { this.queryType = q; }
        public double getRatio() { return ratio; }
        public void setRatio(double r) { this.ratio = r; }
        public int getSearchType() { return searchType; }
        public void setSearchType(int s) { this.searchType = s; }
        public double getBuffer() { return buffer; }
        public void setBuffer(double b) { this.buffer = b; }
        public GeometryDto getLocation() { return location; }
        public void setLocation(GeometryDto l) { this.location = l; }
        public String getServerLayerId(String clientLayerId) { 
            return clientToServerLayerMap.getOrDefault(clientLayerId, "server_" + clientLayerId); 
        }
        public String getFilter(String clientLayerId) { return perLayerFilters.get(clientLayerId); }
        public String getFilter() { return globalFilter; }
        public String[] getFeatureIncludes() { return featureIncludes; }
    }

    public static class SearchByLocationResponse {
        private Map<String, List<Feature>> layerResults = new HashMap<>();
        
        public void addLayer(String layerId, List<Feature> features) { 
            layerResults.put(layerId, features); 
        }
        
        public Map<String, List<Feature>> getLayerResults() { 
            return layerResults; 
        }
    }

    
    
    
    
    
    public static class ExceptionCode { 
        public static final String PARAMETER_MISSING = "PARAMETER_MISSING"; 
    }
    
    public static class GeomajasException extends Exception {
        public GeomajasException(String code, String param) { 
            super(code + ": " + param); 
        }
    }

    
    
    
    
    
    public static class GeometryDto {
        private String type;
        private double[][] coordinates;
        
        public GeometryDto() {}
        public GeometryDto(String type, double[][] coordinates) {
            this.type = type; 
            this.coordinates = coordinates;
        }
        
        public String getType() { return type; }
        public double[][] getCoordinates() { return coordinates; }
        
        @Override
        public String toString() { 
            return "GeometryDto[type=" + type + ", coords=" + coordinates.length + " points]"; 
        }
    }

    public static class Geometry {
        private double area = 100.0;
        private String type = "Polygon";
        
        public Geometry() {}
        public Geometry(String type) { this.type = type; }
        
        public Geometry buffer(double distance) { 
            Geometry buffered = new Geometry(this.type);
            buffered.setArea(this.area * 2); 
            return buffered; 
        }
        
        public double getArea() { return area; }
        public void setArea(double area) { this.area = area; }
        
        public Geometry intersection(Geometry other) { 
            Geometry result = new Geometry("Polygon");
            
            result.setArea(Math.min(this.area, other.area) * 0.6); 
            return result; 
        }
        
        public String getType() { return type; }
        
        @Override
        public String toString() { 
            return "Geometry[type=" + type + ", area=" + area + "]"; 
        }
    }

    
    
    
    
    public static class Crs {
        private String code;
        
        public Crs() {}
        public Crs(String code) { this.code = code; }
        
        public String getCode() { return code; }
        
        @Override
        public String toString() { return "CRS[" + code + "]"; }
    }

    
    
    
    
    
    
    
    public static class VectorLayer {
        private LayerInfo layerInfo = new LayerInfo();
        
        public LayerInfo getLayerInfo() { return layerInfo; }
    }

    public static class LayerInfo {
        private FeatureInfo featureInfo = new FeatureInfo();
        
        public FeatureInfo getFeatureInfo() { return featureInfo; }
    }

    public static class FeatureInfo {
        private GeometryType geometryType = new GeometryType("Polygon");
        
        public GeometryType getGeometryType() { return geometryType; }
    }

    public static class GeometryType {
        private String name;
        
        public GeometryType() {}
        public GeometryType(String name) { this.name = name; }
        
        public String getName() { return name; }
    }

    public static class Filter {
        private String description;
        
        public Filter() {}
        public Filter(String description) { this.description = description; }
        
        public String getDescription() { return description; }
        
        @Override
        public String toString() { return description; }
    }

    public static class InternalFeature {
        private String id;
        private Geometry geometry;
        
        public InternalFeature() { 
            this.id = "feature_" + System.currentTimeMillis();
            this.geometry = new Geometry(); 
        }
        
        public InternalFeature(String id) { 
            this.id = id; 
            this.geometry = new Geometry(); 
        }
        
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public Geometry getGeometry() { return geometry; }
        public void setGeometry(Geometry geometry) { this.geometry = geometry; }
        
        @Override
        public String toString() { return "InternalFeature[" + id + "]"; }
    }

    public static class Feature {
        private String id;
        private String crs;
        private Geometry geometry;
        private Map<String, Object> attributes = new HashMap<>();
        
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getCrs() { return crs; }
        public void setCrs(String crs) { this.crs = crs; }
        public Geometry getGeometry() { return geometry; }
        public void setGeometry(Geometry geometry) { this.geometry = geometry; }
        public Map<String, Object> getAttributes() { return attributes; }
        public void setAttributes(Map<String, Object> attributes) { this.attributes = attributes; }
    }

    
    
    
    
    public static class ConfigurationService {
        public VectorLayer getVectorLayer(String id) { 
            VectorLayer vl = new VectorLayer(); 
            vl.getLayerInfo().getFeatureInfo().geometryType = new GeometryType("Polygon");
            return vl; 
        }
    }
    
    public static class GeoService {
        public Crs getCrs2(String code) { 
            return new Crs(code); 
        }
        
        public Geometry transform(Geometry g, Crs from, Crs to) { 
            
            
            return g; 
        }
    }
    
    public static class DtoConverterService {
        public Geometry toInternal(GeometryDto dto) { 
            Geometry internal = new Geometry(dto.getType());
            
            return internal; 
        }
        
        public Feature toDto(InternalFeature f) { 
            Feature dto = new Feature();
            dto.setId(f.getId());
            dto.setGeometry(f.getGeometry());
            return dto; 
        }
    }
    
    public static class FilterService {
        public Filter createIntersectsFilter(Geometry g, String geomName) { 
            return new Filter("INTERSECTS(" + geomName + ", " + g + ")"); 
        }
        
        public Filter createContainsFilter(Geometry g, String geomName) { 
            return new Filter("CONTAINS(" + geomName + ", " + g + ")"); 
        }
        
        public Filter createTouchesFilter(Geometry g, String geomName) { 
            return new Filter("TOUCHES(" + geomName + ", " + g + ")"); 
        }
        
        public Filter createWithinFilter(Geometry g, String geomName) { 
            return new Filter("WITHIN(" + geomName + ", " + g + ")"); 
        }
        
        public Filter parseFilter(String f) { 
            return new Filter("ParsedFilter[" + f + "]"); 
        }
        
        public Filter createAndFilter(Filter f1, Filter f2) { 
            return new Filter("AND(" + f1.getDescription() + ", " + f2.getDescription() + ")"); 
        }
    }
    
    public static class VectorLayerService {
        private Map<String, Integer> mockFeatureCounts = new HashMap<>();
        private Map<String, Double> mockFeatureAreas = new HashMap<>();
        private Map<String, Double> mockOverlapRatios = new HashMap<>();
        
        public void setMockFeatureCount(String layerId, int count) { 
            mockFeatureCounts.put(layerId, count); 
        }
        
        public void setMockFeatureArea(String layerId, double area) { 
            mockFeatureAreas.put(layerId, area); 
        }
        
        public void setMockOverlapRatio(String layerId, double ratio) { 
            mockOverlapRatios.put(layerId, ratio); 
        }
        
        public Crs getCrs(VectorLayer layer) { 
            return new Crs("EPSG:4326"); 
        }
        
        public List<InternalFeature> getFeatures(String id, Crs crs, Filter f, String[] sort, String[] includes) {
            List<InternalFeature> list = new ArrayList<>();
            int count = mockFeatureCounts.getOrDefault(id, 3);
            double area = mockFeatureAreas.getOrDefault(id, 100.0);
            
            for (int i = 0; i < count; i++) {
                InternalFeature feature = new InternalFeature(id + "_feature_" + i);
                feature.getGeometry().setArea(area);
                list.add(feature);
            }
            return list;
        }
        
        public double getOverlapRatio(String layerId) {
            return mockOverlapRatios.getOrDefault(layerId, 1.0);
        }
    }
    
    public static class SecurityContext {
        public boolean isLayerVisible(String id) { 
            
            return true; 
        }
    }
}