import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;





public class method_1_geomajas_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public Map<String, ClientWidgetInfo> securityClone(Map<String, ClientWidgetInfo> widgetInfo) {
        Map<String, ClientWidgetInfo> res = new HashMap<String, ClientWidgetInfo>();
        for (Map.Entry<String, ClientWidgetInfo> entry : widgetInfo.entrySet()) {
            ClientWidgetInfo value = entry.getValue();
            if (!(value instanceof ServerSideOnlyInfo)) {
                res.put(entry.getKey(), value);
            }
        }
        return res;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== Geomajas GetMapConfigurationCommand.securityClone (Map) Test ===");
        method_1_geomajas_QWEN command = new method_1_geomajas_QWEN();
        
        
        Map<String, ClientWidgetInfo> inputWidgets = new HashMap<>();
        
        
        ClientWidgetInfo searchWidget = new ClientWidgetInfo();
        searchWidget.setId("searchWidget");
        searchWidget.setWidgetType("search");
        searchWidget.setTitle("Search Features");
        searchWidget.setCssStyle("widget-search");
        searchWidget.setVisible(true);
        inputWidgets.put("searchWidget", searchWidget);
        
        ClientWidgetInfo navWidget = new ClientWidgetInfo();
        navWidget.setId("navigationWidget");
        navWidget.setWidgetType("navigation");
        navWidget.setTitle("Map Navigation");
        navWidget.setCssStyle("widget-nav");
        navWidget.setVisible(true);
        inputWidgets.put("navigationWidget", navWidget);
        
        ClientWidgetInfo legendWidget = new ClientWidgetInfo();
        legendWidget.setId("legendWidget");
        legendWidget.setWidgetType("legend");
        legendWidget.setTitle("Map Legend");
        legendWidget.setVisible(true);
        inputWidgets.put("legendWidget", legendWidget);
        
        
        ServerSideOnlyInfo serverWidget = new ServerSideOnlyInfo();
        serverWidget.setId("serverOnlyWidget");
        serverWidget.setWidgetType("server-processor");
        serverWidget.setTitle("Internal Processor");
        inputWidgets.put("serverOnlyWidget", serverWidget);
        
        ServerSideOnlyInfo cacheManager = new ServerSideOnlyInfo();
        cacheManager.setId("cacheManager");
        cacheManager.setWidgetType("cache-manager");
        inputWidgets.put("cacheManager", cacheManager);

        System.out.println("Input map size: " + inputWidgets.size());
        System.out.println("Input keys: " + inputWidgets.keySet());
        
        int serverOnlyCount = 0;
        for (ClientWidgetInfo w : inputWidgets.values()) {
            if (w instanceof ServerSideOnlyInfo) serverOnlyCount++;
        }
        System.out.println("Server-side only widgets in input: " + serverOnlyCount);
        
        try {
            System.out.println("\nInvoking securityClone...");
            Map<String, ClientWidgetInfo> result = command.securityClone(inputWidgets);
            
            System.out.println("\nSUCCESS: Method executed without throwing exceptions.");
            System.out.println("Output map size: " + result.size());
            System.out.println("Output keys: " + result.keySet());
            
            boolean allClientSide = true;
            for (ClientWidgetInfo w : result.values()) {
                if (w instanceof ServerSideOnlyInfo) {
                    allClientSide = false;
                    break;
                }
            }
            
            if (result.size() == 3 && allClientSide) {
                System.out.println("\nVERIFICATION PASSED:");
                System.out.println("  - All " + serverOnlyCount + " server-side only widgets were filtered out");
                System.out.println("  - All " + result.size() + " client-side widgets were preserved");
                for (Map.Entry<String, ClientWidgetInfo> e : result.entrySet()) {
                    System.out.println("  - " + e.getKey() + " -> " + e.getValue().getWidgetType() 
                        + " (title: " + e.getValue().getTitle() + ")");
                }
            } else {
                System.out.println("VERIFICATION FAILED");
            }
            System.out.println("\n=== Test Completed Successfully ===");
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    public static class ClientWidgetInfo {
        private String id;
        private String widgetType;
        private String title;
        private String cssStyle;
        private String cssClass;
        private boolean visible = true;
        private int marginTop;
        private int marginRight;
        private int marginBottom;
        private int marginLeft;
        private Map<String, String> parameters = new HashMap<>();
        private List<ClientWidgetInfo> children = new ArrayList<>();
        private Object userData;
        
        public ClientWidgetInfo() {}
        public ClientWidgetInfo(String id, String widgetType) {
            this.id = id;
            this.widgetType = widgetType;
        }
        
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getWidgetType() { return widgetType; }
        public void setWidgetType(String widgetType) { this.widgetType = widgetType; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getCssStyle() { return cssStyle; }
        public void setCssStyle(String cssStyle) { this.cssStyle = cssStyle; }
        public String getCssClass() { return cssClass; }
        public void setCssClass(String cssClass) { this.cssClass = cssClass; }
        public boolean isVisible() { return visible; }
        public void setVisible(boolean visible) { this.visible = visible; }
        public int getMarginTop() { return marginTop; }
        public void setMarginTop(int marginTop) { this.marginTop = marginTop; }
        public int getMarginRight() { return marginRight; }
        public void setMarginRight(int marginRight) { this.marginRight = marginRight; }
        public int getMarginBottom() { return marginBottom; }
        public void setMarginBottom(int marginBottom) { this.marginBottom = marginBottom; }
        public int getMarginLeft() { return marginLeft; }
        public void setMarginLeft(int marginLeft) { this.marginLeft = marginLeft; }
        public Map<String, String> getParameters() { return parameters; }
        public void setParameters(Map<String, String> parameters) { this.parameters = parameters; }
        public List<ClientWidgetInfo> getChildren() { return children; }
        public void setChildren(List<ClientWidgetInfo> children) { this.children = children; }
        public Object getUserData() { return userData; }
        public void setUserData(Object userData) { this.userData = userData; }
        
        @Override
        public String toString() {
            return "ClientWidgetInfo{id='" + id + "', type='" + widgetType + "', title='" + title + "'}";
        }
    }

    
    
    
    public static class ServerSideOnlyInfo extends ClientWidgetInfo {
        private String serverSideHandler;
        private boolean cacheable = false;
        
        public ServerSideOnlyInfo() {
            super();
        }
        public ServerSideOnlyInfo(String id, String widgetType) {
            super(id, widgetType);
        }
        
        public String getServerSideHandler() { return serverSideHandler; }
        public void setServerSideHandler(String serverSideHandler) { 
            this.serverSideHandler = serverSideHandler; 
        }
        public boolean isCacheable() { return cacheable; }
        public void setCacheable(boolean cacheable) { this.cacheable = cacheable; }
        
        @Override
        public String toString() {
            return "ServerSideOnlyInfo{id='" + getId() + "', type='" + getWidgetType() + "'}";
        }
    }
}