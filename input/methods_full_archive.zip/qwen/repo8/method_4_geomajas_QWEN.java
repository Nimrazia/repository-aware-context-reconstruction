import java.util.ArrayList;
import java.util.List;




















public class method_4_geomajas_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public List<RasterTile> paint(CoordinateReferenceSystem targetCrs, Envelope bounds, double scale)
            throws GeomajasException {
        Envelope layerBounds = bounds;
        double layerScale = scale;
        CrsTransform layerToMap = null;
        boolean needTransform = !crs.equals(targetCrs);

        try {
            
            
            
            if (needTransform) {
                layerToMap = geoService.getCrsTransform(crs, targetCrs);
                CrsTransform mapToLayer = geoService.getCrsTransform(targetCrs, crs);

                
                layerBounds = geoService.transform(bounds, mapToLayer);
                layerScale = bounds.getWidth() * scale / layerBounds.getWidth();
            }
        } catch (MismatchedDimensionException e) {
            throw new GeomajasException(e, ExceptionCode.RENDER_DIMENSION_MISMATCH);
        }
        layerBounds = clipBounds(layerBounds);
        if (layerBounds.isNull()) {
            return new ArrayList<RasterTile>(0);
        }

        
        Resolution bestResolution = getResolutionForScale(layerScale);
        RasterGrid grid = getRasterGrid(layerBounds, bestResolution.getTileWidth(), bestResolution.getTileHeight());

        
        List<RasterTile> result = new ArrayList<RasterTile>();
        for (int i = grid.getXmin(); i < grid.getXmax(); i++) {
            for (int j = grid.getYmin(); j < grid.getYmax(); j++) {
                double x = grid.getLowerLeft().x + (i - grid.getXmin()) * grid.getTileWidth();
                double y = grid.getLowerLeft().y + (j - grid.getYmin()) * grid.getTileHeight();
                
                Bbox worldBox;
                Bbox layerBox;
                if (needTransform) {
                    layerBox = new Bbox(x, y, grid.getTileWidth(), grid.getTileHeight());
                    
                    
                    worldBox = geoService.transform(layerBox, layerToMap);
                } else {
                    worldBox = new Bbox(x, y, grid.getTileWidth(), grid.getTileHeight());
                    layerBox = worldBox;
                }
                
                Bbox screenBox = new Bbox(Math.round(scale * worldBox.getX()), -Math.round(scale * worldBox.getMaxY()),
                        Math.round(scale * worldBox.getMaxX()) - Math.round(scale * worldBox.getX()), Math.round(scale
                                * worldBox.getMaxY())
                                - Math.round(scale * worldBox.getY()));

                RasterTile image = new RasterTile(screenBox, getId() + "." + bestResolution.getLevel() + "." + i + ","
                        + j);

                image.setCode(new TileCode(bestResolution.getLevel(), i, j));
                String url = formatUrl(bestResolution.getTileWidthPx(), bestResolution.getTileHeightPx(), layerBox);
                image.setUrl(url);
                result.add(image);
            }
        }

        return result;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== Geomajas WmsLayer.paint Reconstruction Test ===\n");
        
        
        
        
        System.out.println("--- TEST 1: Same CRS (EPSG:4326 -> EPSG:4326), no transform ---");
        
        method_4_geomajas_QWEN layer1 = new method_4_geomajas_QWEN();
        layer1.setId("countries_wms");
        layer1.crs = new Crs("EPSG:4326");
        layer1.baseWmsUrl = "http://wms.example.com/geoserver/wms";
        layer1.wmsVersion = "1.1.1";
        layer1.layerName = "ne:countries";
        layer1.styleName = "countries_style";
        layer1.format = "image/png";
        layer1.transparent = true;
        layer1.maxExtent = new Envelope(-180, 180, -90, 90);
        
        CoordinateReferenceSystem targetCrs1 = new CoordinateReferenceSystem("EPSG:4326");
        Envelope bounds1 = new Envelope(-10, 30, 35, 60); 
        double scale1 = 0.01; 
        
        try {
            System.out.println("Layer ID: " + layer1.getId());
            System.out.println("Layer CRS: " + layer1.crs.getCode());
            System.out.println("Target CRS: " + targetCrs1.getCode());
            System.out.println("Bounds: " + bounds1);
            System.out.println("Scale: " + scale1);
            
            List<RasterTile> tiles1 = layer1.paint(targetCrs1, bounds1, scale1);
            
            System.out.println("\nSUCCESS: Method executed without throwing exceptions.");
            System.out.println("Generated " + tiles1.size() + " tiles");
            
            if (!tiles1.isEmpty()) {
                System.out.println("\nFirst 3 tiles:");
                int limit = Math.min(3, tiles1.size());
                for (int t = 0; t < limit; t++) {
                    RasterTile tile = tiles1.get(t);
                    System.out.println("  Tile " + t + ":");
                    System.out.println("    ID: " + tile.getId());
                    System.out.println("    Code: " + tile.getCode());
                    System.out.println("    Screen Box: " + tile.getScreenBox());
                    System.out.println("    URL: " + tile.getUrl());
                }
            }
            System.out.println("✓ VERIFICATION PASSED: Tiles generated for same-CRS case");
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
        
        
        
        
        System.out.println("\n\n--- TEST 2: Different CRS (EPSG:4326 -> EPSG:3857), transform needed ---");
        
        method_4_geomajas_QWEN layer2 = new method_4_geomajas_QWEN();
        layer2.setId("satellite_wms");
        layer2.crs = new Crs("EPSG:4326");
        layer2.baseWmsUrl = "http://wms.example.com/geoserver/wms";
        layer2.wmsVersion = "1.3.0";
        layer2.layerName = "satellite:imagery";
        layer2.styleName = "";
        layer2.format = "image/jpeg";
        layer2.transparent = false;
        layer2.maxExtent = new Envelope(-180, 180, -90, 90);
        
        CoordinateReferenceSystem targetCrs2 = new CoordinateReferenceSystem("EPSG:3857");
        Envelope bounds2 = new Envelope(0, 2000000, 5000000, 7000000); 
        double scale2 = 0.0001;
        
        try {
            System.out.println("Layer ID: " + layer2.getId());
            System.out.println("Layer CRS: " + layer2.crs.getCode());
            System.out.println("Target CRS: " + targetCrs2.getCode());
            System.out.println("Bounds: " + bounds2);
            System.out.println("Scale: " + scale2);
            
            List<RasterTile> tiles2 = layer2.paint(targetCrs2, bounds2, scale2);
            
            System.out.println("\nSUCCESS: Method executed without throwing exceptions.");
            System.out.println("Generated " + tiles2.size() + " tiles");
            
            if (!tiles2.isEmpty()) {
                System.out.println("\nFirst 3 tiles:");
                int limit = Math.min(3, tiles2.size());
                for (int t = 0; t < limit; t++) {
                    RasterTile tile = tiles2.get(t);
                    System.out.println("  Tile " + t + ":");
                    System.out.println("    ID: " + tile.getId());
                    System.out.println("    Code: " + tile.getCode());
                    System.out.println("    Screen Box: " + tile.getScreenBox());
                    System.out.println("    URL: " + tile.getUrl());
                }
                
                
                String firstUrl = tiles2.get(0).getUrl();
                boolean hasService = firstUrl.contains("SERVICE=WMS");
                boolean hasVersion = firstUrl.contains("VERSION=1.3.0");
                boolean hasLayers = firstUrl.contains("LAYERS=satellite:imagery");
                boolean hasCrs = firstUrl.contains("CRS=") || firstUrl.contains("SRS=");
                boolean hasBbox = firstUrl.contains("BBOX=");
                
                System.out.println("\nURL Parameter Verification:");
                System.out.println("  SERVICE=WMS: " + (hasService ? "✓" : "✗"));
                System.out.println("  VERSION=1.3.0: " + (hasVersion ? "✓" : "✗"));
                System.out.println("  LAYERS: " + (hasLayers ? "✓" : "✗"));
                System.out.println("  CRS/SRS: " + (hasCrs ? "✓" : "✗"));
                System.out.println("  BBOX: " + (hasBbox ? "✓" : "✗"));
            }
            System.out.println("✓ VERIFICATION PASSED: Tiles generated with CRS transform");
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
        
        
        
        
        System.out.println("\n\n--- TEST 3: Bounds outside max extent (should return empty) ---");
        
        method_4_geomajas_QWEN layer3 = new method_4_geomajas_QWEN();
        layer3.setId("local_wms");
        layer3.crs = new Crs("EPSG:4326");
        layer3.baseWmsUrl = "http://wms.example.com/local";
        layer3.wmsVersion = "1.1.1";
        layer3.layerName = "local:buildings";
        layer3.maxExtent = new Envelope(4, 6, 50, 52); 
        
        CoordinateReferenceSystem targetCrs3 = new CoordinateReferenceSystem("EPSG:4326");
        Envelope bounds3 = new Envelope(100, 110, 30, 40); 
        double scale3 = 0.01;
        
        try {
            System.out.println("Layer max extent: " + layer3.maxExtent);
            System.out.println("Requested bounds: " + bounds3);
            
            List<RasterTile> tiles3 = layer3.paint(targetCrs3, bounds3, scale3);
            
            System.out.println("\nSUCCESS: Method executed without throwing exceptions.");
            System.out.println("Generated " + tiles3.size() + " tiles");
            
            if (tiles3.isEmpty()) {
                System.out.println("✓ VERIFICATION PASSED: Empty result for out-of-bounds request");
            } else {
                System.out.println("✗ VERIFICATION FAILED: Expected empty result");
            }
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
        
        
        
        
        System.out.println("\n\n--- TEST 4: High zoom level (large tile grid) ---");
        
        method_4_geomajas_QWEN layer4 = new method_4_geomajas_QWEN();
        layer4.setId("osm_wms");
        layer4.crs = new Crs("EPSG:3857");
        layer4.baseWmsUrl = "http://wms.example.com/osm";
        layer4.wmsVersion = "1.1.1";
        layer4.layerName = "osm:streets";
        layer4.maxExtent = new Envelope(-20037508, 20037508, -20037508, 20037508);
        
        CoordinateReferenceSystem targetCrs4 = new CoordinateReferenceSystem("EPSG:3857");
        Envelope bounds4 = new Envelope(500000, 600000, 6800000, 6900000);
        double scale4 = 0.00001; 
        
        try {
            System.out.println("Layer CRS: " + layer4.crs.getCode());
            System.out.println("Bounds: " + bounds4);
            System.out.println("Scale: " + scale4);
            
            List<RasterTile> tiles4 = layer4.paint(targetCrs4, bounds4, scale4);
            
            System.out.println("\nSUCCESS: Method executed without throwing exceptions.");
            System.out.println("Generated " + tiles4.size() + " tiles");
            
            if (tiles4.size() > 0) {
                System.out.println("✓ VERIFICATION PASSED: Multiple tiles generated for high zoom");
            }
            
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("\n=== All Tests Completed ===");
    }

    
    
    
    
    private String id;
    private Crs crs;
    private String baseWmsUrl;
    private String wmsVersion = "1.1.1";
    private String layerName;
    private String styleName = "";
    private String format = "image/png";
    private boolean transparent = true;
    private String backgroundColor;
    private Envelope maxExtent;
    private GeoService geoService = new GeoService();
    
    
    private List<Resolution> resolutions = new ArrayList<>();

    public method_4_geomajas_QWEN() {
        
        resolutions.add(new Resolution(156543.0339, 0, 256, 256));
        resolutions.add(new Resolution(78271.51695, 1, 256, 256));
        resolutions.add(new Resolution(39135.75848, 2, 256, 256));
        resolutions.add(new Resolution(19567.87924, 3, 256, 256));
        resolutions.add(new Resolution(9783.93962, 4, 256, 256));
        resolutions.add(new Resolution(4891.96981, 5, 256, 256));
        resolutions.add(new Resolution(2445.98491, 6, 256, 256));
        resolutions.add(new Resolution(1222.99245, 7, 256, 256));
        resolutions.add(new Resolution(611.49623, 8, 256, 256));
        resolutions.add(new Resolution(305.74811, 9, 256, 256));
        resolutions.add(new Resolution(152.87406, 10, 256, 256));
        resolutions.add(new Resolution(76.43703, 11, 256, 256));
        resolutions.add(new Resolution(38.21851, 12, 256, 256));
        resolutions.add(new Resolution(19.10926, 13, 256, 256));
        resolutions.add(new Resolution(9.55463, 14, 256, 256));
        resolutions.add(new Resolution(4.77731, 15, 256, 256));
        resolutions.add(new Resolution(2.38866, 16, 256, 256));
        resolutions.add(new Resolution(1.19433, 17, 256, 256));
        resolutions.add(new Resolution(0.59716, 18, 256, 256));
    }

    public void setId(String id) { this.id = id; }
    public String getId() { return id; }

    
    
    
    
    



    private Envelope clipBounds(Envelope bounds) {
        if (maxExtent == null) {
            return bounds;
        }
        double minX = Math.max(bounds.getMinX(), maxExtent.getMinX());
        double maxX = Math.min(bounds.getMaxX(), maxExtent.getMaxX());
        double minY = Math.max(bounds.getMinY(), maxExtent.getMinY());
        double maxY = Math.min(bounds.getMaxY(), maxExtent.getMaxY());
        
        if (minX >= maxX || minY >= maxY) {
            return new Envelope(0, 0, 0, 0); 
        }
        return new Envelope(minX, maxX, minY, maxY);
    }
    
    



    private Resolution getResolutionForScale(double scale) {
        Resolution best = resolutions.get(resolutions.size() - 1);
        for (Resolution r : resolutions) {
            if (r.getResolution() <= scale) {
                best = r;
                break;
            }
        }
        return best;
    }
    
    



    private RasterGrid getRasterGrid(Envelope bounds, double tileWidth, double tileHeight) {
        if (tileWidth <= 0 || tileHeight <= 0) {
            return new RasterGrid(new Coordinate(0, 0), 0, 0, 1, 1, 256, 256);
        }
        double originX = bounds.getMinX();
        double originY = bounds.getMinY();
        int tilesX = Math.max(1, (int) Math.ceil((bounds.getMaxX() - originX) / tileWidth));
        int tilesY = Math.max(1, (int) Math.ceil((bounds.getMaxY() - originY) / tileHeight));
        return new RasterGrid(new Coordinate(originX, originY), 0, 0, tilesX, tilesY, tileWidth, tileHeight);
    }
    
    



    private String formatUrl(int width, int height, Bbox box) {
        StringBuilder sb = new StringBuilder();
        sb.append(baseWmsUrl != null ? baseWmsUrl : "http://wms.example.com/service");
        sb.append("?SERVICE=WMS");
        sb.append("&VERSION=").append(wmsVersion);
        sb.append("&REQUEST=GetMap");
        sb.append("&LAYERS=").append(layerName != null ? layerName : id);
        sb.append("&STYLES=").append(styleName != null ? styleName : "");
        sb.append("&FORMAT=").append(format);
        sb.append("&TRANSPARENT=").append(transparent ? "TRUE" : "FALSE");
        sb.append("&WIDTH=").append(width);
        sb.append("&HEIGHT=").append(height);
        
        if (backgroundColor != null) {
            sb.append("&BGCOLOR=").append(backgroundColor);
        }
        
        
        if ("1.3.0".equals(wmsVersion)) {
            sb.append("&CRS=").append(crs != null ? crs.getCode() : "EPSG:4326");
            
            if (crs != null && "EPSG:4326".equals(crs.getCode())) {
                sb.append("&BBOX=").append(box.getY()).append(",").append(box.getX())
                  .append(",").append(box.getMaxY()).append(",").append(box.getMaxX());
            } else {
                sb.append("&BBOX=").append(box.getX()).append(",").append(box.getY())
                  .append(",").append(box.getMaxX()).append(",").append(box.getMaxY());
            }
        } else {
            sb.append("&SRS=").append(crs != null ? crs.getCode() : "EPSG:4326");
            sb.append("&BBOX=").append(box.getX()).append(",").append(box.getY())
              .append(",").append(box.getMaxX()).append(",").append(box.getMaxY());
        }
        
        return sb.toString();
    }

    
    
    
    
    


    public static class CoordinateReferenceSystem {
        private String code;
        public CoordinateReferenceSystem(String code) { this.code = code; }
        public String getCode() { return code; }
        public boolean equals(Object o) { 
            return o instanceof CoordinateReferenceSystem 
                && code != null 
                && code.equals(((CoordinateReferenceSystem) o).code); 
        }
        public int hashCode() { return code != null ? code.hashCode() : 0; }
        @Override
        public String toString() { return "CRS[" + code + "]"; }
    }

    


    public static class Crs {
        private String code;
        public Crs() {}
        public Crs(String code) { this.code = code; }
        public String getCode() { return code; }
        public boolean equals(Object o) { 
            return o instanceof Crs && code != null && code.equals(((Crs) o).code); 
        }
        public int hashCode() { return code != null ? code.hashCode() : 0; }
        @Override
        public String toString() { return "Crs[" + code + "]"; }
    }

    


    public static class CrsTransform {
        private String sourceCrs;
        private String targetCrs;
        private double scaleFactorX;
        private double scaleFactorY;
        private double offsetX;
        private double offsetY;
        
        public CrsTransform() {
            this.scaleFactorX = 1.0;
            this.scaleFactorY = 1.0;
        }
        public CrsTransform(String sourceCrs, String targetCrs) {
            this.sourceCrs = sourceCrs;
            this.targetCrs = targetCrs;
            
            if ("EPSG:4326".equals(sourceCrs) && "EPSG:3857".equals(targetCrs)) {
                this.scaleFactorX = 111319.49;
                this.scaleFactorY = 111319.49;
            } else if ("EPSG:3857".equals(sourceCrs) && "EPSG:4326".equals(targetCrs)) {
                this.scaleFactorX = 1.0 / 111319.49;
                this.scaleFactorY = 1.0 / 111319.49;
            } else {
                this.scaleFactorX = 1.0;
                this.scaleFactorY = 1.0;
            }
        }
        public String getSourceCrs() { return sourceCrs; }
        public String getTargetCrs() { return targetCrs; }
    }

    
    
    
    
    
    
    
    public static class Envelope {
        private double minX, maxX, minY, maxY;
        
        public Envelope() {}
        public Envelope(double minX, double maxX, double minY, double maxY) {
            this.minX = minX; this.maxX = maxX; this.minY = minY; this.maxY = maxY;
        }
        
        public double getMinX() { return minX; }
        public double getMaxX() { return maxX; }
        public double getMinY() { return minY; }
        public double getMaxY() { return maxY; }
        public double getWidth() { return maxX - minX; }
        public double getHeight() { return maxY - minY; }
        public boolean isNull() { return getWidth() <= 0 || getHeight() <= 0; }
        
        @Override
        public String toString() { 
            return "Envelope[" + minX + ", " + maxX + ", " + minY + ", " + maxY + "]"; 
        }
    }

    public static class Bbox {
        private double x, y, width, height;
        
        public Bbox() {}
        public Bbox(double x, double y, double width, double height) {
            this.x = x; this.y = y; this.width = width; this.height = height;
        }
        
        public double getX() { return x; }
        public double getY() { return y; }
        public double getMaxX() { return x + width; }
        public double getMaxY() { return y + height; }
        public double getWidth() { return width; }
        public double getHeight() { return height; }
        
        @Override
        public String toString() { 
            return "Bbox[x=" + x + ", y=" + y + ", w=" + width + ", h=" + height + "]"; 
        }
    }

    public static class Coordinate {
        public double x, y;
        
        public Coordinate() {}
        public Coordinate(double x, double y) { this.x = x; this.y = y; }
        
        @Override
        public String toString() { return "Coordinate[" + x + ", " + y + "]"; }
    }

    
    
    
    
    
    
    public static class RasterTile {
        private Bbox screenBox;
        private Bbox worldBox;
        private String id;
        private TileCode code;
        private String url;
        private String mimeType = "image/png";
        private int width, height;
        
        public RasterTile() {}
        public RasterTile(Bbox screenBox, String id) { 
            this.screenBox = screenBox; 
            this.id = id; 
        }
        
        public Bbox getScreenBox() { return screenBox; }
        public void setScreenBox(Bbox b) { this.screenBox = b; }
        public Bbox getWorldBox() { return worldBox; }
        public void setWorldBox(Bbox b) { this.worldBox = b; }
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public TileCode getCode() { return code; }
        public void setCode(TileCode code) { this.code = code; }
        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }
        public String getMimeType() { return mimeType; }
        public void setMimeType(String m) { this.mimeType = m; }
        public int getWidth() { return width; }
        public void setWidth(int w) { this.width = w; }
        public int getHeight() { return height; }
        public void setHeight(int h) { this.height = h; }
        
        @Override
        public String toString() {
            return "RasterTile[id=" + id + ", code=" + code + "]";
        }
    }

    public static class TileCode {
        private int level, x, y;
        
        public TileCode() {}
        public TileCode(int level, int x, int y) { 
            this.level = level; this.x = x; this.y = y; 
        }
        
        public int getLevel() { return level; }
        public int getX() { return x; }
        public int getY() { return y; }
        
        @Override
        public String toString() { return "TileCode[L" + level + ":(" + x + "," + y + ")]"; }
    }

    
    
    
    
    public static class RasterGrid {
        private final Coordinate lowerLeft;
        private final int xmin, ymin, xmax, ymax;
        private final double tileWidth, tileHeight;
        
        RasterGrid(Coordinate lowerLeft, int xmin, int ymin, int xmax, int ymax, 
                   double tileWidth, double tileHeight) {
            this.lowerLeft = lowerLeft; 
            this.xmin = xmin; this.ymin = ymin; 
            this.xmax = xmax; this.ymax = ymax;
            this.tileWidth = tileWidth; 
            this.tileHeight = tileHeight;
        }
        
        public Coordinate getLowerLeft() { return lowerLeft; }
        public int getXmin() { return xmin; }
        public int getXmax() { return xmax; }
        public int getYmin() { return ymin; }
        public int getYmax() { return ymax; }
        public double getTileWidth() { return tileWidth; }
        public double getTileHeight() { return tileHeight; }
    }

    public static class Resolution {
        private final double resolution;
        private final int level;
        private final int tileWidthPx, tileHeightPx;
        
        Resolution(double resolution, int level, int tileWidthPx, int tileHeightPx) {
            this.resolution = resolution; 
            this.level = level; 
            this.tileWidthPx = tileWidthPx; 
            this.tileHeightPx = tileHeightPx;
        }
        
        public double getResolution() { return resolution; }
        public int getLevel() { return level; }
        public int getTileWidthPx() { return tileWidthPx; }
        public int getTileHeightPx() { return tileHeightPx; }
        public double getTileWidth() { return tileWidthPx * resolution; }
        public double getTileHeight() { return tileHeightPx * resolution; }
        
        @Override
        public String toString() { 
            return "Resolution[L" + level + ", res=" + resolution + ", tile=" + tileWidthPx + "x" + tileHeightPx + "]"; 
        }
    }

    
    
    
    
    
    
    
    public static class ExceptionCode {
        public static final String RENDER_DIMENSION_MISMATCH = "RENDER_DIMENSION_MISMATCH";
        public static final String LAYER_NOT_FOUND = "LAYER_NOT_FOUND";
        public static final String UNEXPECTED_PROBLEM = "UNEXPECTED_PROBLEM";
    }

    public static class GeomajasException extends Exception {
        private String code;
        
        public GeomajasException(Throwable cause, String code) { 
            super(code, cause); 
            this.code = code;
        }
        public GeomajasException(String code) { 
            super(code); 
            this.code = code;
        }
        public GeomajasException(String code, String message) { 
            super(code + ": " + message); 
            this.code = code;
        }
        
        public String getCode() { return code; }
    }

    public static class MismatchedDimensionException extends Exception {
        public MismatchedDimensionException(String msg) { super(msg); }
    }

    
    
    
    
    
    public static class GeoService {
        
        public CrsTransform getCrsTransform(Crs from, CoordinateReferenceSystem to) throws MismatchedDimensionException { 
            return new CrsTransform(from.getCode(), to.getCode()); 
        }
        
        public CrsTransform getCrsTransform(CoordinateReferenceSystem from, Crs to) throws MismatchedDimensionException { 
            return new CrsTransform(from.getCode(), to.getCode()); 
        }
        
        public Envelope transform(Envelope bounds, CrsTransform transform) { 
            
            double newMinX = bounds.getMinX() * transform.scaleFactorX + transform.offsetX;
            double newMaxX = bounds.getMaxX() * transform.scaleFactorX + transform.offsetX;
            double newMinY = bounds.getMinY() * transform.scaleFactorY + transform.offsetY;
            double newMaxY = bounds.getMaxY() * transform.scaleFactorY + transform.offsetY;
            return new Envelope(newMinX, newMaxX, newMinY, newMaxY);
        }
        
        public Bbox transform(Bbox box, CrsTransform transform) { 
            double newX = box.getX() * transform.scaleFactorX + transform.offsetX;
            double newY = box.getY() * transform.scaleFactorY + transform.offsetY;
            double newW = box.getWidth() * transform.scaleFactorX;
            double newH = box.getHeight() * transform.scaleFactorY;
            return new Bbox(newX, newY, newW, newH);
        }
    }
}