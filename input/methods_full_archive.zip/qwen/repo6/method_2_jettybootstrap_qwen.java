import java.io.File;
import java.io.IOException;
import java.security.KeyStore;




class JettyBootstrapException2 extends Exception {
    public JettyBootstrapException2(String message) { super(message); }
    public JettyBootstrapException2(String message, Throwable cause) { super(message, cause); }
}

enum JettyConnector2 { HTTP, HTTPS }

interface IJettyConfiguration2 {
    File getTempDirectory();
    void setTempDirectory(File dir);
    boolean isCleanTempDir();
    String getHost();
    boolean hasJettyConnector(JettyConnector2 connector);
    KeyStore getSslKeyStore();
    String getSslPrivateKeyPath();
    String getSslCertificatePath();
    String getSslKeyStorePath();
    void setSslKeyStorePath(String path);
    String getSslKeyStoreAlgorithm();
    String getSslKeyStoreSignatureAlgorithm();
    String getSslKeyStoreRdnOuValue();
    String getSslKeyStoreRdnOValue();
    int getSslKeyStoreDateNotBeforeNumberOfDays();
    int getSslKeyStoreDateNotAfterNumberOfDays();
    String getSslKeyStoreDomainName();
    String getSslKeyStoreAlias();
    String getSslKeyStorePassword();
    boolean isRedirectWebAppsOnHttpsConnector();
}

class JettyKeystoreException2 extends Exception {
    public JettyKeystoreException2(String message, Throwable cause) { super(message, cause); }
}

class JettyKeystoreGeneratorBuilder {
    public JettyKeystoreGeneratorBuilder setAlgorithm(String alg) { return this; }
    public JettyKeystoreGeneratorBuilder setSignatureAlgorithm(String alg) { return this; }
    public JettyKeystoreGeneratorBuilder setRdnOuValue(String val) { return this; }
    public JettyKeystoreGeneratorBuilder setRdnOValue(String val) { return this; }
    public JettyKeystoreGeneratorBuilder setDateNotBeforeNumberOfDays(int days) { return this; }
    public JettyKeystoreGeneratorBuilder setDateNotAfterNumberOfDays(int days) { return this; }
    public KeyStore build(String domain, String alias, String password) throws JettyKeystoreException2 {
        System.out.println("  -> Generated mock KeyStore for domain: " + domain);
        return null;
    }
    public static void saveKeyStore(KeyStore ks, File file, String password) throws JettyKeystoreException2 {
        System.out.println("  -> Saved mock KeyStore to: " + file.getAbsolutePath());
    }
}




class FileUtils2 {
    public static void deleteDirectory(File dir) throws IOException {
        System.out.println("  -> Deleted temporary directory: " + dir.getAbsolutePath());
    }
}

class Logger2 {
    public void trace(String msg, Object... args) { System.out.println("[TRACE] " + String.format(msg, args)); }
    public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
}




public class method_2_jettybootstrap_qwen {
    private static final Logger2 LOG = new Logger2();
    private static final String DEFAULT_KEYSTORE_FILENAME = "default.keystore";
    private static final File TEMP_DIRECTORY_DEFAULT = new File(System.getProperty("java.io.tmpdir") + File.separator + ".jetty_temp");
    
    private IJettyConfiguration2 iJettyConfiguration;
    private boolean isInitializedConfiguration = false;

    public method_2_jettybootstrap_qwen(IJettyConfiguration2 config) {
        this.iJettyConfiguration = config;
    }


// ORIGINAL CODESEARCHNET METHOD — START

protected IJettyConfiguration2 getInitializedConfiguration() throws JettyBootstrapException2 {
        if (!isInitializedConfiguration) {
            LOG.debug("Init Configuration...");

            LOG.trace("Check Temp Directory...");
            if (iJettyConfiguration.getTempDirectory() == null) {
                iJettyConfiguration.setTempDirectory(TEMP_DIRECTORY_DEFAULT);
            }

            if (iJettyConfiguration.getTempDirectory().exists() && iJettyConfiguration.isCleanTempDir()) {
                LOG.trace("Clean Temp Directory...");

                try {
                    FileUtils2.deleteDirectory(iJettyConfiguration.getTempDirectory());
                } catch (IOException e) {
                    throw new JettyBootstrapException2("Can't clean temporary directory");
                }
            }
            if (!iJettyConfiguration.getTempDirectory().exists() && !iJettyConfiguration.getTempDirectory().mkdirs()) {
                throw new JettyBootstrapException2("Can't create temporary directory");
            }

            LOG.trace("Check required properties...");
            if (iJettyConfiguration.getHost() == null || iJettyConfiguration.getHost().isEmpty()) {
                throw new JettyBootstrapException2("Host not specified");
            }

            LOG.trace("Check connectors...");
            if (iJettyConfiguration.hasJettyConnector(JettyConnector2.HTTPS)) {

                
                if (iJettyConfiguration.getSslKeyStore() == null &&
                    (iJettyConfiguration.getSslPrivateKeyPath() == null || iJettyConfiguration.getSslPrivateKeyPath().isEmpty() ||
                        iJettyConfiguration.getSslCertificatePath() == null || iJettyConfiguration.getSslCertificatePath().isEmpty())) {

                    
                    if (iJettyConfiguration.getSslKeyStorePath() == null || iJettyConfiguration.getSslKeyStorePath().isEmpty()) {
                        iJettyConfiguration.setSslKeyStorePath(iJettyConfiguration.getTempDirectory().getPath() + File.separator + DEFAULT_KEYSTORE_FILENAME);
                    }

                    
                    File keystoreFile = new File(iJettyConfiguration.getSslKeyStorePath());
                    if (!keystoreFile.exists()) {
                        try {
                            JettyKeystoreGeneratorBuilder jettyKeystoreGeneratorBuilder = new JettyKeystoreGeneratorBuilder();
                            jettyKeystoreGeneratorBuilder.setAlgorithm(iJettyConfiguration.getSslKeyStoreAlgorithm());
                            jettyKeystoreGeneratorBuilder.setSignatureAlgorithm(iJettyConfiguration.getSslKeyStoreSignatureAlgorithm());
                            jettyKeystoreGeneratorBuilder.setRdnOuValue(iJettyConfiguration.getSslKeyStoreRdnOuValue());
                            jettyKeystoreGeneratorBuilder.setRdnOValue(iJettyConfiguration.getSslKeyStoreRdnOValue());
                            jettyKeystoreGeneratorBuilder.setDateNotBeforeNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotBeforeNumberOfDays());
                            jettyKeystoreGeneratorBuilder.setDateNotAfterNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotAfterNumberOfDays());

                            KeyStore keyStore = jettyKeystoreGeneratorBuilder.build(iJettyConfiguration.getSslKeyStoreDomainName(), iJettyConfiguration.getSslKeyStoreAlias(),
                                    iJettyConfiguration.getSslKeyStorePassword());
                            JettyKeystoreGeneratorBuilder.saveKeyStore(keyStore, keystoreFile, iJettyConfiguration.getSslKeyStorePassword());
                        } catch (JettyKeystoreException2 e) {
                            throw new JettyBootstrapException2("Can't generate keyStore", e);
                        }
                    }
                }
            }

            if (iJettyConfiguration.isRedirectWebAppsOnHttpsConnector() &&
                (!iJettyConfiguration.hasJettyConnector(JettyConnector2.HTTP) || !iJettyConfiguration.hasJettyConnector(JettyConnector2.HTTPS))) {
                throw new JettyBootstrapException2("You can't redirect all from HTTP to HTTPS Connector if both connectors are not setted");
            }

            isInitializedConfiguration = true;

            LOG.trace("Configuration : {}", iJettyConfiguration);
        }

        return iJettyConfiguration;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 2: JettyBootstrap.getInitializedConfiguration        ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            File mockTempDir = new File(System.getProperty("java.io.tmpdir") + File.separator + "jetty_test_init");
            mockTempDir.mkdirs(); 
            
            IJettyConfiguration2 config = new IJettyConfiguration2() {
                private File tempDir = mockTempDir;
                private String sslKeyStorePath;
                public File getTempDirectory() { return tempDir; }
                public void setTempDirectory(File dir) { 
                    this.tempDir = dir; 
                    System.out.println("  -> Set temp directory to: " + dir.getAbsolutePath());
                }
                public boolean isCleanTempDir() { return true; }
                public String getHost() { return "127.0.0.1"; }
                public boolean hasJettyConnector(JettyConnector2 c) { return c == JettyConnector2.HTTPS; }
                public KeyStore getSslKeyStore() { return null; }
                public String getSslPrivateKeyPath() { return null; }
                public String getSslCertificatePath() { return null; }
                public String getSslKeyStorePath() { return sslKeyStorePath; }
                public void setSslKeyStorePath(String path) {
                    this.sslKeyStorePath = path;
                    System.out.println("  -> Set keystore path to: " + path);
                }
                public String getSslKeyStoreAlgorithm() { return "RSA"; }
                public String getSslKeyStoreSignatureAlgorithm() { return "SHA256WithRSA"; }
                public String getSslKeyStoreRdnOuValue() { return "IT"; }
                public String getSslKeyStoreRdnOValue() { return "Teknux"; }
                public int getSslKeyStoreDateNotBeforeNumberOfDays() { return 0; }
                public int getSslKeyStoreDateNotAfterNumberOfDays() { return 365; }
                public String getSslKeyStoreDomainName() { return "localhost"; }
                public String getSslKeyStoreAlias() { return "jetty"; }
                public String getSslKeyStorePassword() { return "changeit"; }
                public boolean isRedirectWebAppsOnHttpsConnector() { return false; }
            };

            method_2_jettybootstrap_qwen bootstrap = new method_2_jettybootstrap_qwen(config);
            
            System.out.println("┌─ CONFIGURATION INITIALIZATION PROCESS ─────────────────────┐");
            System.out.println("│ 1. Checking and cleaning temporary directory...");
            System.out.println("│ 2. Validating required host property...");
            System.out.println("│ 3. Detecting HTTPS connector requirement...");
            System.out.println("│ 4. Resolving default keystore path...");
            System.out.println("│ 5. Generating and saving new keystore...");
            
            IJettyConfiguration2 result = bootstrap.getInitializedConfiguration();
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            
            System.out.println("┌─ INITIALIZATION RESULT ────────────────────────────────────┐");
            System.out.println("✓ Configuration Initialized Successfully");
            System.out.println("✓ Host: " + result.getHost());
            System.out.println("✓ Temp Directory: " + result.getTempDirectory().getAbsolutePath());
            System.out.println("✓ HTTPS Enabled: " + result.hasJettyConnector(JettyConnector2.HTTPS));
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
            
            mockTempDir.delete();
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}