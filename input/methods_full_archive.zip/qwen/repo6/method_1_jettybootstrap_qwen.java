import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;




class JettyBootstrapException extends Exception {
    public JettyBootstrapException(String message) { super(message); }
    public JettyBootstrapException(String message, Throwable cause) { super(message, cause); }
}

enum JettyConnector { HTTP, HTTPS }
enum JettySslFileFormat { UNKNOWN, PKCS8, PKCS12 }

interface IJettyConfiguration {
    boolean hasJettyConnector(JettyConnector connector);
    int getSslPort();
    long getIdleTimeout();
    long getBlockingTimeout();
    String getHost();
    int getPort();
    KeyStore getSslKeyStore();
    String getSslPrivateKeyPath();
    String getSslCertificatePath();
    JettySslFileFormat getSslCertificateFormat();
    String getSslCertificatePassword();
    JettySslFileFormat getSslPrivateKeyFormat();
    String getSslPrivateKeyPassword();
    String getSslKeyStoreAlias();
    String getSslKeyStorePassword();
    String getSslKeyStorePath();
}

class JettyKeystoreException extends Exception {
    public JettyKeystoreException(String message, Throwable cause) { super(message, cause); }
}

class JettyKeystoreConvertorBuilder {
    public JettyKeystoreConvertorBuilder setCertificateFromPKCS8(InputStream is) { return this; }
    public JettyKeystoreConvertorBuilder setCertificateFromPKCS12(InputStream is, String pwd) { return this; }
    public JettyKeystoreConvertorBuilder setPrivateKeyFromPKCS8(InputStream is) { return this; }
    public JettyKeystoreConvertorBuilder setPrivateKeyFromPKCS12(InputStream is, String pwd) { return this; }
    public KeyStore build(String alias, String password) throws JettyKeystoreException {
        System.out.println("  -> Built mock KeyStore from PKCS streams");
        return null; 
    }
}




class Logger {
    public void trace(String msg) { System.out.println("[TRACE] " + msg); }
    public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
}

class HttpScheme {
    public static final HttpScheme HTTPS = new HttpScheme("https");
    private final String name;
    private HttpScheme(String name) { this.name = name; }
    public String asString() { return name; }
}

class HttpConfiguration {
    private int securePort;
    private String secureScheme;
    private long idleTimeout;
    private long blockingTimeout;
    public void setSecurePort(int port) { this.securePort = port; }
    public void setSecureScheme(String scheme) { this.secureScheme = scheme; }
    public void setIdleTimeout(long timeout) { this.idleTimeout = timeout; }
    public void setBlockingTimeout(long timeout) { this.blockingTimeout = timeout; }
}

class HttpConnectionFactory {
    private final HttpConfiguration config;
    public HttpConnectionFactory(HttpConfiguration config) { this.config = config; }
    public HttpConfiguration getHttpConfiguration() { return config; }
}

class SslContextFactory {
    private KeyStore keyStore;
    private String keyStorePath;
    private String keyStorePassword;
    public void setKeyStore(KeyStore ks) { this.keyStore = ks; }
    public void setKeyStorePath(String path) { this.keyStorePath = path; }
    public void setKeyStorePassword(String pwd) { this.keyStorePassword = pwd; }
}

class Server {}

abstract class Connector {}

class ServerConnector extends Connector {
    private final Server server;
    private long idleTimeout;
    private String host;
    private int port;
    private final List<Object> connectionFactories = new ArrayList<>();

    public ServerConnector(Server server) { 
        this.server = server; 
        this.connectionFactories.add(new HttpConnectionFactory(new HttpConfiguration()));
    }
    public ServerConnector(Server server, Object... factories) { 
        this.server = server; 
        for (Object f : factories) this.connectionFactories.add(f);
    }
    public void setIdleTimeout(long timeout) { this.idleTimeout = timeout; }
    public void setHost(String host) { this.host = host; }
    public void setPort(int port) { this.port = port; }
    public List<Object> getConnectionFactories() { return connectionFactories; }
}




public class method_1_jettybootstrap_qwen {
    private static final Logger LOG = new Logger();


// ORIGINAL CODESEARCHNET METHOD — START

protected Connector[] createConnectors(IJettyConfiguration iJettyConfiguration, Server server) throws JettyBootstrapException {
        LOG.trace("Creating Jetty Connectors...");

        List<Connector> connectors = new ArrayList<>();

        if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP)) {
            LOG.trace("Adding HTTP Connector...");

            ServerConnector serverConnector;

            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
                HttpConfiguration httpConfiguration = new HttpConfiguration();
                httpConfiguration.setSecurePort(iJettyConfiguration.getSslPort());
                httpConfiguration.setSecureScheme(HttpScheme.HTTPS.asString());
                httpConfiguration.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
                httpConfiguration.setBlockingTimeout(iJettyConfiguration.getBlockingTimeout());

                HttpConnectionFactory httpConnectionFactory = new HttpConnectionFactory(httpConfiguration);

                serverConnector = new ServerConnector(server, httpConnectionFactory);
            } else {
                serverConnector = new ServerConnector(server);

                serverConnector.getConnectionFactories().stream()
                        .filter(HttpConnectionFactory.class::isInstance)
                        .map(HttpConnectionFactory.class::cast)
                        .forEach(httpConnectionFactory -> httpConnectionFactory.getHttpConfiguration().setBlockingTimeout(iJettyConfiguration.getBlockingTimeout()));
            }

            serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
            serverConnector.setHost(iJettyConfiguration.getHost());
            serverConnector.setPort(iJettyConfiguration.getPort());

            connectors.add(serverConnector);
        }
        if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
            LOG.trace("Adding HTTPS Connector...");

            SslContextFactory sslContextFactory = new SslContextFactory();

            if (iJettyConfiguration.getSslKeyStore() != null) { 
                sslContextFactory.setKeyStore(iJettyConfiguration.getSslKeyStore());
            } else if (iJettyConfiguration.getSslPrivateKeyPath() != null && !iJettyConfiguration.getSslPrivateKeyPath().isEmpty() &&
                iJettyConfiguration.getSslCertificatePath() != null && !iJettyConfiguration.getSslCertificatePath().isEmpty()) { 

                JettyKeystoreConvertorBuilder jettyKeystoreConvertorBuilder = new JettyKeystoreConvertorBuilder();
                try {
                    File sslPrivateKeyFile = new File(iJettyConfiguration.getSslPrivateKeyPath());
                    if (!sslPrivateKeyFile.exists() || !sslPrivateKeyFile.canRead()) {
                        throw new JettyBootstrapException("Private key not exists or unreadable");
                    }

                    File sslCertificateFile = new File(iJettyConfiguration.getSslCertificatePath());
                    if (!sslCertificateFile.exists() || !sslCertificateFile.canRead()) {
                        throw new JettyBootstrapException("Certificate not exists or unreadable");
                    }

                    try (InputStream sslPrivateKeyInputStream = new FileInputStream(sslPrivateKeyFile);
                            InputStream sslCertificateInputStream = new FileInputStream(sslCertificateFile)) {

                        switch (iJettyConfiguration.getSslCertificateFormat()) {
                            case PKCS8:
                                jettyKeystoreConvertorBuilder.setCertificateFromPKCS8(sslCertificateInputStream);
                                break;
                            case PKCS12:
                                jettyKeystoreConvertorBuilder.setCertificateFromPKCS12(sslCertificateInputStream, iJettyConfiguration.getSslCertificatePassword());
                                break;
                            case UNKNOWN:
                                throw new JettyBootstrapException("Unknown Certificate Format");
                            default:
                                throw new JettyBootstrapException("Certificate Format not setted");
                        }

                        switch (iJettyConfiguration.getSslPrivateKeyFormat()) {
                            case PKCS8:
                                jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS8(sslPrivateKeyInputStream);
                                break;
                            case PKCS12:
                                jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS12(sslPrivateKeyInputStream, iJettyConfiguration.getSslPrivateKeyPassword());
                                break;
                            case UNKNOWN:
                                throw new JettyBootstrapException("Unknown Private key Format");
                            default:
                                throw new JettyBootstrapException("Private key Format not setted");
                        }
                    }

                    KeyStore keyStore = jettyKeystoreConvertorBuilder.build(iJettyConfiguration.getSslKeyStoreAlias(), iJettyConfiguration.getSslKeyStorePassword());

                    sslContextFactory.setKeyStore(keyStore);
                } catch (JettyKeystoreException | IOException e) {
                    throw new JettyBootstrapException("Can not load SSL private key or SSL certificate", e);
                }
            } else { 
                sslContextFactory.setKeyStorePath(iJettyConfiguration.getSslKeyStorePath());
            }
            sslContextFactory.setKeyStorePassword(iJettyConfiguration.getSslKeyStorePassword());
            ServerConnector serverConnector = new ServerConnector(server, sslContextFactory);

            serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
            serverConnector.setHost(iJettyConfiguration.getHost());
            serverConnector.setPort(iJettyConfiguration.getSslPort());

            connectors.add(serverConnector);
        }

        return connectors.toArray(new Connector[connectors.size()]);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 1: JettyBootstrap.createConnectors                   ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            IJettyConfiguration config = new IJettyConfiguration() {
                public boolean hasJettyConnector(JettyConnector c) { return c == JettyConnector.HTTP || c == JettyConnector.HTTPS; }
                public int getSslPort() { return 8443; }
                public long getIdleTimeout() { return 30000; }
                public long getBlockingTimeout() { return 5000; }
                public String getHost() { return "0.0.0.0"; }
                public int getPort() { return 8080; }
                public KeyStore getSslKeyStore() { return null; }
                public String getSslPrivateKeyPath() { return "mock.key"; }
                public String getSslCertificatePath() { return "mock.crt"; }
                public JettySslFileFormat getSslCertificateFormat() { return JettySslFileFormat.PKCS8; }
                public String getSslCertificatePassword() { return "changeit"; }
                public JettySslFileFormat getSslPrivateKeyFormat() { return JettySslFileFormat.PKCS8; }
                public String getSslPrivateKeyPassword() { return "changeit"; }
                public String getSslKeyStoreAlias() { return "jetty"; }
                public String getSslKeyStorePassword() { return "changeit"; }
                public String getSslKeyStorePath() { return null; }
            };

            
            new File("mock.key").createNewFile();
            new File("mock.crt").createNewFile();

            method_1_jettybootstrap_qwen bootstrap = new method_1_jettybootstrap_qwen();
            Server server = new Server();

            System.out.println("┌─ CONNECTOR CREATION PROCESS ───────────────────────────────┐");
            System.out.println("│ 1. Checking for HTTP connector configuration...");
            System.out.println("│ 2. Configuring HTTP ServerConnector with blocking timeout...");
            System.out.println("│ 3. Checking for HTTPS connector configuration...");
            System.out.println("│ 4. Reading PKCS8 private key and certificate streams...");
            System.out.println("│ 5. Building KeyStore and configuring SslContextFactory...");
            
            Connector[] connectors = bootstrap.createConnectors(config, server);
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            
            System.out.println("┌─ CREATION RESULT ──────────────────────────────────────────┐");
            System.out.println("✓ Total Connectors Created: " + connectors.length);
            System.out.println("✓ Connector 1 Type: " + connectors[0].getClass().getSimpleName() + " (Port 8080)");
            System.out.println("✓ Connector 2 Type: " + connectors[1].getClass().getSimpleName() + " (Port 8443, SSL)");
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
            
            new File("mock.key").delete();
            new File("mock.crt").delete();
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}