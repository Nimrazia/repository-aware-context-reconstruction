import java.text.ParseException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class method_2_pbs_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public List<Queue> parse(String text) throws ParseException {
        final List<Queue> queues;
        if (StringUtils.isNotBlank(text)) {
            queues = new LinkedList<Queue>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Queue queue = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_QUEUE.matcher(line);
                if (matcher.matches()) {
                    if (queue != null) {
                        queues.add(queue);
                    }
                    queue = new Queue();
                    final String name = matcher.group(1);
                    queue.setName(name);
                } else if (StringUtils.isNotBlank(line)) {
                    String[] temp = Utils.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("queue_type".equals(key)) {
                            queue.setQueueType(value);
                        } else if ("priority".equals(key)) {
                            try {
                                queue.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue priority: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("total_jobs".equals(key)) {
                            try {
                                queue.setTotalJobs(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue total jobs: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("state_count".equals(key)) {
                            queue.setStateCount(value);
                        } else if ("mtime".equals(key)) {
                            queue.setMtime(value);
                        } else if ("max_user_run".equals(key)) {
                            try {
                                queue.setMaxUserRun(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue max user run: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("enabled".equals(key)) {
                            queue.setEnabled(Boolean.parseBoolean(value));
                        } else if ("started".equals(key)) {
                            queue.setStarted(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resources_max.")) {
                            queue.getResourcesMax().put(key, value);
                        } else if (key.startsWith("resources_min.")) {
                            queue.getResourcesMin().put(key, value);
                        } else if (key.startsWith("resources_assigned.")) {
                            queue.getResourcesAssigned().put(key, value);
                        } else if (key.startsWith("resources_default.")) {
                            queue.getResourcesDefault().put(key, value);
                        } else {
                            LOGGER.info("Unmmaped key, value: " + key + ", " + value);
                        }
                    }
                }
            }
            if (queue != null) {
                queues.add(queue);
            }
            return queues;
        } else {
            return Collections.emptyList();
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== PBS QstatQueuesParser Reconstruction Test ===");
        method_2_pbs_QWEN parser = new method_2_pbs_QWEN();
        String mockQstatOutput = "Queue: workq\n\tqueue_type = Execution\n\tpriority = 0\n\ttotal_jobs = 5\n\tenabled = True\n\tstarted = True\n\tresources_max.ncpus = 16";
        try {
            List<Queue> queues = parser.parse(mockQstatOutput);
            System.out.println("SUCCESS: Parsed " + queues.size() + " queue(s).");
            if (!queues.isEmpty()) {
                System.out.println("Queue Name: " + queues.get(0).getName() + ", Total Jobs: " + queues.get(0).getTotalJobs());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    private static final Logger LOGGER = Logger.getLogger(method_2_pbs_QWEN.class.getName());
    private static final String REGEX_QUEUE = "(?i)queue:\\s*(.*)";
    private static final Pattern PATTERN_QUEUE = Pattern.compile(REGEX_QUEUE);
    private static final String CHAR_EQUALS = "=";

    public static class Queue {
        private String name, queueType, stateCount, mtime;
        private int priority = -1, totalJobs = -1, maxUserRun = -1;
        private boolean enabled, started;
        private Map<String, String> resourcesMax = new HashMap<>();
        private Map<String, String> resourcesMin = new HashMap<>();
        private Map<String, String> resourcesAssigned = new HashMap<>();
        private Map<String, String> resourcesDefault = new HashMap<>();

        public String getName() { return name; } public void setName(String name) { this.name = name; }
        public String getQueueType() { return queueType; } public void setQueueType(String q) { this.queueType = q; }
        public String getStateCount() { return stateCount; } public void setStateCount(String s) { this.stateCount = s; }
        public String getMtime() { return mtime; } public void setMtime(String m) { this.mtime = m; }
        public int getPriority() { return priority; } public void setPriority(int p) { this.priority = p; }
        public int getTotalJobs() { return totalJobs; } public void setTotalJobs(int t) { this.totalJobs = t; }
        public int getMaxUserRun() { return maxUserRun; } public void setMaxUserRun(int m) { this.maxUserRun = m; }
        public boolean getEnabled() { return enabled; } public void setEnabled(boolean e) { this.enabled = e; }
        public boolean getStarted() { return started; } public void setStarted(boolean s) { this.started = s; }
        public Map<String, String> getResourcesMax() { return resourcesMax; }
        public Map<String, String> getResourcesMin() { return resourcesMin; }
        public Map<String, String> getResourcesAssigned() { return resourcesAssigned; }
        public Map<String, String> getResourcesDefault() { return resourcesDefault; }
    }

    public static class StringUtils {
        public static boolean isNotBlank(String str) { return str != null && !str.trim().isEmpty(); }
    }

    public static class Utils {
        public static String[] splitFirst(String str, String delimiter) {
            if (str == null || delimiter == null) return new String[]{str};
            int idx = str.indexOf(delimiter);
            if (idx == -1) return new String[]{str};
            return new String[]{str.substring(0, idx), str.substring(idx + delimiter.length())};
        }
    }
}