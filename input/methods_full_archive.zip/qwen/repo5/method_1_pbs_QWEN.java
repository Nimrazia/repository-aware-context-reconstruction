import java.text.ParseException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class method_1_pbs_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public List<Job> parse(String text) throws ParseException {
        final List<Job> jobs;
        if (StringUtils.isNotBlank(text)) {
            text = StringUtils.replace(text, "\n\t", "");
            jobs = new LinkedList<Job>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Job job = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_JOB.matcher(line);
                if (matcher.matches()) {
                    if (job != null) {
                        jobs.add(job);
                    }
                    job = new Job();
                    final String id = matcher.group(1).trim();
                    job.setId(id);
                } else if (StringUtils.isNotBlank(line)) {
                    String[] temp = Utils.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("job_name".equalsIgnoreCase(key)) {
                            job.setName(value);
                        } else if ("job_owner".equalsIgnoreCase(key)) {
                            job.setOwner(value);
                        } else if (key.startsWith("resources_used.")) {
                            job.getResourcesUsed().put(key, value);
                        } else if ("job_state".equalsIgnoreCase(key)) {
                            job.setState(value);
                        } else if ("queue".equalsIgnoreCase(key)) {
                            job.setQueue(value);
                        } else if ("server".equalsIgnoreCase(key)) {
                            job.setServer(value);
                        } else if ("checkpoint".equalsIgnoreCase(key)) {
                            job.setCheckpoint(value);
                        } else if ("ctime".equalsIgnoreCase(key)) {
                            job.setCtime(value);
                        } else if ("error_path".equalsIgnoreCase(key)) {
                            job.setErrorPath(value);
                        } else if ("exec_host".equalsIgnoreCase(key)) {
                            job.setExecHost(value);
                        } else if ("exec_port".equalsIgnoreCase(key)) {
                            job.setExecPort(value);
                        } else if ("hold_types".equalsIgnoreCase(key)) {
                            job.setHoldTypes(value);
                        } else if ("join_path".equalsIgnoreCase(key)) {
                            job.setJoinPath(value);
                        } else if ("keep_files".equalsIgnoreCase(key)) {
                            job.setKeepFiles(value);
                        } else if ("mail_points".equalsIgnoreCase(key)) {
                            job.setMailPoints(value);
                        } else if ("mail_users".equalsIgnoreCase(key)) {
                            job.setMailUsers(value);
                        } else if ("mtime".equalsIgnoreCase(key)) {
                            job.setMtime(value);
                        } else if ("output_path".equalsIgnoreCase(key)) {
                            job.setOutputPath(value);
                        } else if ("priority".equalsIgnoreCase(key)) {
                            try {
                                job.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job priority: " + nfe.getMessage(), nfe);
                                job.setPriority(-1);
                            }
                        } else if ("qtime".equalsIgnoreCase(key)) {
                            job.setQtime(value);
                        } else if ("rerunable".equalsIgnoreCase(key)) {
                            job.setRerunable(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resource_list.")) {
                            job.getResourceList().put(key, value);
                        } else if ("session_id".equalsIgnoreCase(key)) {
                            try {
                                job.setSessionId(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job session id: " + nfe.getMessage(), nfe);
                                job.setSessionId(-1);
                            }
                        } else if ("substate".equalsIgnoreCase(key)) {
                            try {
                                job.setSubstate(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job substate: " + nfe.getMessage(), nfe);
                                job.setSubstate(-1);
                            }
                        } else if (key.startsWith("variable_list")) {
                            job.getVariableList().put(key, value);
                        } else if ("etime".equalsIgnoreCase(key)) {
                            job.setEtime(value);
                        } else if ("euser".equalsIgnoreCase(key)) {
                            job.setEuser(value);
                        } else if ("egroup".equalsIgnoreCase(key)) {
                            job.setEgroup(value);
                        } else if ("hashname".equalsIgnoreCase(key)) {
                            job.setHashName(value);
                        } else if ("queue_rank".equalsIgnoreCase(key)) {
                            try {
                                job.setQueueRank(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job queue rank: " + nfe.getMessage(), nfe);
                                job.setQueueRank(-1);
                            }
                        } else if ("queue_type".equalsIgnoreCase(key)) {
                            job.setQueueType(value);
                        } else if ("comment".equalsIgnoreCase(key)) {
                            job.setComment(value);
                        } else if ("submit_args".equalsIgnoreCase(key)) {
                            job.setSubmitArgs(value);
                        } else if ("submit_host".equalsIgnoreCase(key)) {
                            job.setSubmitHost(value);
                        } else if ("start_time".equalsIgnoreCase(key)) {
                            job.setStartTime(value);
                        } else if ("start_count".equalsIgnoreCase(key)) {
                            try {
                                job.setStartCount(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job start count: " + nfe.getMessage(), nfe);
                                job.setStartCount(-1);
                            }
                        } else if ("fault_tolerant".equalsIgnoreCase(key)) {
                            job.setFaultTolerant(Boolean.parseBoolean(value));
                        } else if ("job_array_id".equalsIgnoreCase(key)) {
                            job.setJobArrayId(Integer.parseInt(value));
                        } else if ("job_radix".equalsIgnoreCase(key)) {
                            try {
                                job.setRadix(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job radix: " + nfe.getMessage(), nfe);
                                job.setRadix(-1);
                            }
                        } else if ("walltime.remaining".equalsIgnoreCase(key)) {
                            try {
                                job.setWalltimeRemaining(Long.parseLong(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job walltime remaining: " + nfe.getMessage(), nfe);
                                job.setWalltimeRemaining(-1L);
                            }
                        }
                    }
                }
            }
            if (job != null) {
                jobs.add(job);
            }
            return jobs;
        } else {
            return Collections.emptyList();
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== PBS QstatJobsParser Reconstruction Test ===");
        method_1_pbs_QWEN parser = new method_1_pbs_QWEN();
        String mockQstatOutput = "Job Id: 12345.server\njob_name = TestJob\njob_owner = user1\njob_state = R\nqueue = workq\nresources_used.cput = 00:01:00\npriority = 10\nresource_list.nodes = 1:ppn=2\nwalltime.remaining = 3600";
        try {
            List<Job> jobs = parser.parse(mockQstatOutput);
            System.out.println("SUCCESS: Parsed " + jobs.size() + " job(s).");
            if (!jobs.isEmpty()) {
                System.out.println("Job ID: " + jobs.get(0).getId() + ", Name: " + jobs.get(0).getName());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    private static final Logger LOGGER = Logger.getLogger(method_1_pbs_QWEN.class.getName());
    private static final String REGEX_JOB = "(?i)job\\s+(?i)i(?i)d:(.*)";
    private static final Pattern PATTERN_JOB = Pattern.compile(REGEX_JOB);
    private static final String CHAR_EQUALS = "=";

    public static class Job {
        private String id, name, owner, state, queue, server, checkpoint, ctime, errorPath, execHost, execPort, holdTypes, joinPath, keepFiles, mailPoints, mailUsers, mtime, outputPath, qtime, etime, euser, egroup, hashName, queueType, comment, submitArgs, submitHost, startTime;
        private int priority = -1, sessionId = -1, substate = -1, queueRank = -1, startCount = -1, jobArrayId = -1, radix = -1;
        private long walltimeRemaining = -1L;
        private boolean rerunable, faultTolerant;
        private Map<String, String> resourcesUsed = new HashMap<>();
        private Map<String, String> resourceList = new HashMap<>();
        private Map<String, String> variableList = new HashMap<>();

        public String getId() { return id; } public void setId(String id) { this.id = id; }
        public String getName() { return name; } public void setName(String name) { this.name = name; }
        public String getOwner() { return owner; } public void setOwner(String owner) { this.owner = owner; }
        public String getState() { return state; } public void setState(String state) { this.state = state; }
        public String getQueue() { return queue; } public void setQueue(String queue) { this.queue = queue; }
        public String getServer() { return server; } public void setServer(String server) { this.server = server; }
        public String getCheckpoint() { return checkpoint; } public void setCheckpoint(String c) { this.checkpoint = c; }
        public String getCtime() { return ctime; } public void setCtime(String c) { this.ctime = c; }
        public String getErrorPath() { return errorPath; } public void setErrorPath(String e) { this.errorPath = e; }
        public String getExecHost() { return execHost; } public void setExecHost(String e) { this.execHost = e; }
        public String getExecPort() { return execPort; } public void setExecPort(String e) { this.execPort = e; }
        public String getHoldTypes() { return holdTypes; } public void setHoldTypes(String h) { this.holdTypes = h; }
        public String getJoinPath() { return joinPath; } public void setJoinPath(String j) { this.joinPath = j; }
        public String getKeepFiles() { return keepFiles; } public void setKeepFiles(String k) { this.keepFiles = k; }
        public String getMailPoints() { return mailPoints; } public void setMailPoints(String m) { this.mailPoints = m; }
        public String getMailUsers() { return mailUsers; } public void setMailUsers(String m) { this.mailUsers = m; }
        public String getMtime() { return mtime; } public void setMtime(String m) { this.mtime = m; }
        public String getOutputPath() { return outputPath; } public void setOutputPath(String o) { this.outputPath = o; }
        public String getQtime() { return qtime; } public void setQtime(String q) { this.qtime = q; }
        public String getEtime() { return etime; } public void setEtime(String e) { this.etime = e; }
        public String getEuser() { return euser; } public void setEuser(String e) { this.euser = e; }
        public String getEgroup() { return egroup; } public void setEgroup(String e) { this.egroup = e; }
        public String getHashName() { return hashName; } public void setHashName(String h) { this.hashName = h; }
        public String getQueueType() { return queueType; } public void setQueueType(String q) { this.queueType = q; }
        public String getComment() { return comment; } public void setComment(String c) { this.comment = c; }
        public String getSubmitArgs() { return submitArgs; } public void setSubmitArgs(String s) { this.submitArgs = s; }
        public String getSubmitHost() { return submitHost; } public void setSubmitHost(String s) { this.submitHost = s; }
        public String getStartTime() { return startTime; } public void setStartTime(String s) { this.startTime = s; }
        public int getPriority() { return priority; } public void setPriority(int p) { this.priority = p; }
        public int getSessionId() { return sessionId; } public void setSessionId(int s) { this.sessionId = s; }
        public int getSubstate() { return substate; } public void setSubstate(int s) { this.substate = s; }
        public int getQueueRank() { return queueRank; } public void setQueueRank(int q) { this.queueRank = q; }
        public int getStartCount() { return startCount; } public void setStartCount(int s) { this.startCount = s; }
        public int getJobArrayId() { return jobArrayId; } public void setJobArrayId(int j) { this.jobArrayId = j; }
        public int getRadix() { return radix; } public void setRadix(int r) { this.radix = r; }
        public long getWalltimeRemaining() { return walltimeRemaining; } public void setWalltimeRemaining(long w) { this.walltimeRemaining = w; }
        public boolean getRerunable() { return rerunable; } public void setRerunable(boolean r) { this.rerunable = r; }
        public boolean getFaultTolerant() { return faultTolerant; } public void setFaultTolerant(boolean f) { this.faultTolerant = f; }
        public Map<String, String> getResourcesUsed() { return resourcesUsed; }
        public Map<String, String> getResourceList() { return resourceList; }
        public Map<String, String> getVariableList() { return variableList; }
    }

    public static class StringUtils {
        public static boolean isNotBlank(String str) { return str != null && !str.trim().isEmpty(); }
        public static String replace(String text, String search, String replacement) { return text != null ? text.replace(search, replacement) : null; }
    }

    public static class Utils {
        public static String[] splitFirst(String str, String delimiter) {
            if (str == null || delimiter == null) return new String[]{str};
            int idx = str.indexOf(delimiter);
            if (idx == -1) return new String[]{str};
            return new String[]{str.substring(0, idx), str.substring(idx + delimiter.length())};
        }
    }
}