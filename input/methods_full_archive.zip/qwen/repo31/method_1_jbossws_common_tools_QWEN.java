import java.io.*;




class BuildException extends RuntimeException {
    public BuildException(String message) { super(message); }
    public BuildException(Throwable cause) { super(cause); }
}

class Project {
    public String getProperty(String name) { return System.getProperty("user.dir"); }
}

class FileSet {
    private final DirectoryScanner scanner = new DirectoryScanner();
    public DirectoryScanner getDirectoryScanner(Project project) { return scanner; }
}

class DirectoryScanner {
    public File getBasedir() { return new File("mock_source_modules"); }
    public String[] getIncludedFiles() { 
        
        return new String[]{"org" + File.separator + "jboss" + File.separator + "ws" + File.separator + "main" + File.separator + "module.xml"}; 
    }
}




public class method_1_jbossws_common_tools_QWEN {
    private FileSet fileset = new FileSet();
    private File targetDir = new File("mock_target_modules");

    private Project getProject() { return new Project(); }

    
    private String readFileContents(File file) throws IOException {
        return "<module xmlns=\"urn:jboss:module:1.1\" name=\"org.jboss.ws.main\">\n</module>";
    }

    private String updateContents(String contents, String[] libs) {
        StringBuilder sb = new StringBuilder(contents);
        int insertPos = sb.lastIndexOf("</module>");
        if (insertPos == -1) insertPos = sb.length();
        
        sb.insert(insertPos, "  <resources>\n");
        for (String lib : libs) {
            sb.append("    <resource-root path=\"").append(lib).append("\"/>\n");
        }
        sb.append("  </resources>\n");
        return sb.toString();
    }


// ORIGINAL CODESEARCHNET METHOD — START

   public void execute() throws BuildException
   {
      try
      {
         DirectoryScanner dsc = fileset.getDirectoryScanner(getProject());
         File baseDir = dsc.getBasedir();
         String[] files = dsc.getIncludedFiles();
         for (int i = 0; i < files.length; i++)
         {
            String currentFile = files[i];
            File moduleXml = new File(baseDir, currentFile);
            String modulePath = currentFile.substring(0, currentFile.lastIndexOf(File.separator));
            File libDir = new File(targetDir, modulePath);
            File destFile = new File(targetDir, currentFile);
            File destParent = destFile.getParentFile();
            if (destParent != null) destParent.mkdirs();
            System.out.println("Processing descriptor for module " + modulePath);
            System.out.println("* Source module descriptor: " + moduleXml);
            System.out.println("* Destination module descriptor: " + destFile);
            String c = readFileContents(moduleXml);
            if (libDir.exists())
            {
               String[] libs = libDir.list(new FilenameFilter()
               {
                  @Override
                  public boolean accept(File dir, String name)
                  {
                     return name.endsWith(".jar") || name.endsWith(".ear") || name.endsWith(".sar")
                           || name.endsWith(".war");
                  }
               });
               BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
               out.write(updateContents(c, libs));
               out.close();
            }
            else
            {
               libDir.mkdirs();
               BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
               out.write(c);
               out.close();
            }
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new BuildException(e);
      }
   }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 1: InstallModulesTask.execute - Ant Task Execution   ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            
            File srcDir = new File("mock_source_modules/org/jboss/ws/main");
            srcDir.mkdirs();
            new File(srcDir, "module.xml").createNewFile();
            
            File tgtDir = new File("mock_target_modules/org/jboss/ws/main");
            tgtDir.mkdirs();
            new File(tgtDir, "ws-api.jar").createNewFile();
            new File(tgtDir, "ws-impl.jar").createNewFile();

            method_1_jbossws_common_tools_QWEN task = new method_1_jbossws_common_tools_QWEN();
            
            System.out.println("┌─ MODULE INSTALLATION PROCESS ──────────────────────────────┐");
            System.out.println("│ 1. Scanning source directory for module descriptors...");
            System.out.println("│ 2. Checking for existing library directories...");
            System.out.println("│ 3. Filtering .jar, .ear, .sar, .war files...");
            System.out.println("│ 4. Updating module.xml with resource-root entries...");
            
            task.execute();
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            
            
            File destFile = new File("mock_target_modules/org/jboss/ws/main/module.xml");
            System.out.println("┌─ GENERATED MODULE DESCRIPTOR ──────────────────────────────┐");
            try (BufferedReader br = new BufferedReader(new FileReader(destFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println("│ " + line);
                }
            }
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
            System.out.println("\nSUCCESS: Module installation task executed successfully.");
            
            
            deleteDirectory(new File("mock_source_modules"));
            deleteDirectory(new File("mock_target_modules"));
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void deleteDirectory(File dir) {
        if (dir.exists()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) deleteDirectory(f);
            }
            dir.delete();
        }
    }
}