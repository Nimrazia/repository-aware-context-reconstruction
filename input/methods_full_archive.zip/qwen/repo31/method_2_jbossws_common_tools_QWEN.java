import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;




public class method_2_jbossws_common_tools_QWEN {


// ORIGINAL CODESEARCHNET METHOD — START

static ClassLoader setContextClassLoader(final ClassLoader cl)
   {
      if (System.getSecurityManager() == null)
      {
         ClassLoader result = Thread.currentThread().getContextClassLoader();
         if (cl != null)
            Thread.currentThread().setContextClassLoader(cl);
         return result;
      }
      else
      {
         try
         {
            return AccessController.doPrivileged(new PrivilegedExceptionAction<ClassLoader>() {
               public ClassLoader run() throws Exception
               {
                  try
                  {
                     ClassLoader result = Thread.currentThread().getContextClassLoader();
                     if (cl != null)
                        Thread.currentThread().setContextClassLoader(cl);
                     return result;
                  }
                  catch (Exception e)
                  {
                     throw e;
                  }
                  catch (Error e)
                  {
                     throw e;
                  }
                  catch (Throwable e)
                  {
                     throw new RuntimeException("Error setting context classloader", e);
                  }
               }
            });
         }
         catch (PrivilegedActionException e)
         {
            throw new RuntimeException("Error running privileged action", e.getCause());
         }
      }
   }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 2: SecurityActions.setContextClassLoader             ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            ClassLoader originalCL = Thread.currentThread().getContextClassLoader();
            ClassLoader mockCL = new ClassLoader() {
                @Override
                public String toString() { return "MockCustomClassLoader"; }
            };
            
            System.out.println("┌─ CONTEXT CLASSLOADER SWITCH ───────────────────────────────┐");
            System.out.println("│ 1. Current Context ClassLoader: " + originalCL.getClass().getSimpleName());
            System.out.println("│ 2. Checking SecurityManager status...");
            System.out.println("│ 3. " + (System.getSecurityManager() == null ? 
                "No SecurityManager: executing direct thread manipulation." : 
                "SecurityManager present: executing via AccessController.doPrivileged."));
            System.out.println("│ 4. Setting new Context ClassLoader...");
            
            ClassLoader returnedCL = setContextClassLoader(mockCL);
            
            System.out.println("│ 5. New Context ClassLoader: " + Thread.currentThread().getContextClassLoader());
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            
            System.out.println("┌─ OPERATION RESULT ─────────────────────────────────────────┐");
            System.out.println("✓ Successfully swapped Context ClassLoader.");
            System.out.println("✓ Returned original ClassLoader: " + returnedCL.getClass().getSimpleName());
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
            
            Thread.currentThread().setContextClassLoader(originalCL);
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}