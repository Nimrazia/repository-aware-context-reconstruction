import java.io.*;




class Priority {
    public static final Priority INFO = new Priority("INFO");
    public static final Priority DEBUG = new Priority("DEBUG");
    public static final Priority ERROR = new Priority("ERROR");
    
    private final String name;
    public Priority(String name) { this.name = name; }
    public String toString() { return name; }
}

class Category {
    private final String name;
    public Category(String name) { this.name = name; }
    
    public void log(Priority priority, String message) {
        System.out.println("[" + name + "] [" + priority + "] " + message.trim().replace("\n", "\\n"));
    }
}




public class method_3_jbossws_common_tools_QWEN extends OutputStream {
    private final Category category;
    private final Priority priority;
    private final byte[] buf = new byte[1024];
    private int count = 0;
    private static final String LINE_SEPERATOR = System.getProperty("line.separator", "\n");

    public method_3_jbossws_common_tools_QWEN(Category category, Priority priority) {
        this.category = category;
        this.priority = priority;
    }

    @Override
    public void write(int b) {
        if (count == buf.length) {
            flush();
        }
        buf[count++] = (byte) b;
    }

    private void reset() {
        count = 0;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public void flush()
   {
      if (count == 0)
      {
         return;
      }

      
      if (count == LINE_SEPERATOR.length())
      {
         if (((char)buf[0]) == LINE_SEPERATOR.charAt(0) && ((count == 1) || 
               ((count == 2) && ((char)buf[1]) == LINE_SEPERATOR.charAt(1))))
         {
            reset();
            return;
         }
      }

      final byte[] theBytes = new byte[count];

      System.arraycopy(buf, 0, theBytes, 0, count);

      category.log(priority, new String(theBytes));

      reset();
   }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 3: Log4jOutputStream.flush - Stream to Log Adapter   ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            Category mockCategory = new Category("org.jboss.ws.tools.cmd");
            method_3_jbossws_common_tools_QWEN logStream = new method_3_jbossws_common_tools_QWEN(mockCategory, Priority.INFO);
            PrintStream printStream = new PrintStream(logStream, true);
            
            System.out.println("┌─ STREAM FLUSHING PROCESS ──────────────────────────────────┐");
            System.out.println("│ 1. Writing standard text to Log4jOutputStream...");
            
            printStream.print("Application started successfully.");
            printStream.println(); 
            
            System.out.println("│ 2. Writing blank lines (should be ignored by flush logic)...");
            printStream.println();
            printStream.println();
            
            System.out.println("│ 3. Writing multi-line error output...");
            printStream.print("Error connecting to database:\n");
            printStream.print("  - Connection refused\n");
            printStream.print("  - Timeout after 5000ms");
            printStream.println(); 
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            
            System.out.println("┌─ LOG4J OUTPUT CAPTURE ─────────────────────────────────────┐");
            System.out.println("│ (See console output above prefixed with [org.jboss...] )   │");
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
            System.out.println("\nSUCCESS: Stream flushing and Log4j routing executed correctly.");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}