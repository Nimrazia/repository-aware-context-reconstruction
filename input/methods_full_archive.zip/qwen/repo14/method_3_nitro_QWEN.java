import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;

public class method_3_nitro_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private static String _put(nitro_service service, String request) throws Exception {
		HttpURLConnection httpURLConnection;
		StringBuilder responseStr = new StringBuilder();
		try
		{
			String urlstr;
			String ipaddress = service.get_ipaddress();
			String version = service.get_version();
			String protocol = service.get_protocol();
			urlstr = protocol+"://" + ipaddress + "/nitro/" + version + "/config/";
			URL url = new URL(urlstr);
			httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("PUT");
			if (httpURLConnection instanceof javax.net.ssl.HttpsURLConnection)
			{
				if (service.get_certvalidation()) {
					SocketFactory sslSocketFactory = SSLSocketFactory.getDefault();
					javax.net.ssl.HttpsURLConnection secured = (javax.net.ssl.HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);	
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				} else {
					SSLContext sslContext = SSLContext.getInstance("SSL");
					
					
					
					sslContext.init(null, new TrustManager[]{new EmptyTrustManager()}, null);
					SocketFactory sslSocketFactory = sslContext.getSocketFactory();
					
					javax.net.ssl.HttpsURLConnection secured = (javax.net.ssl.HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				}
			}

			httpURLConnection.setDoInput(true);
			httpURLConnection.setDoOutput(true);
			httpURLConnection.setUseCaches(false);
			httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			
			httpURLConnection.setDoOutput(true);
			OutputStreamWriter ouput = new OutputStreamWriter(httpURLConnection.getOutputStream());
			ouput.write(request);
			ouput.flush();
			ouput.close();

			InputStream input;
			try {
				input = httpURLConnection.getInputStream();
			}
			catch (Exception e) {
				input = httpURLConnection.getErrorStream();	
			}
			String contentEncoding = httpURLConnection.getContentEncoding();
			
			if (contentEncoding != null)
			{
				if(contentEncoding.equalsIgnoreCase("gzip"))
					input = new GZIPInputStream(input); 
				else if(contentEncoding.equalsIgnoreCase("deflate"))
					input = new InflaterInputStream(input);
			}

			int numOfTotalBytesRead;
			byte [] buffer = new byte[1024];
			while ((numOfTotalBytesRead = input.read(buffer, 0, buffer.length)) != -1)
			{
				responseStr.append(new String(buffer, 0, numOfTotalBytesRead));
			}

			httpURLConnection.disconnect();
			input.close();
		}
		catch (MalformedURLException mue)
		{
			throw mue;
		}
		catch (IOException ioe)
		{
			throw ioe;
		}
		catch(Exception e)
		{
			throw e;
		}
		
		return responseStr.toString();
	}
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== NetScaler NITRO _put Test ===");
        nitro_service service = new nitro_service();
        String mockRequest = "{\"lbvserver\": {\"name\": \"test_lb\", \"ipv46\": \"10.0.0.10\"}}";
        
        try {
            System.out.println("Invoking _put...");
            String response = _put(service, mockRequest);
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Response length: " + response.length() + " bytes");
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    public static class nitro_service {
        private String ipaddress = "10.0.0.1";
        private String version = "v1";
        private String protocol = "http";
        private boolean certvalidation = false;
        private boolean hostnameverification = false;

        public String get_ipaddress() { return ipaddress; }
        public String get_version() { return version; }
        public String get_protocol() { return protocol; }
        public boolean get_certvalidation() { return certvalidation; }
        public boolean get_hostnameverification() { return hostnameverification; }
    }

    public static class EmptyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) { return true; }
    }

    public static class EmptyTrustManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] chain, String authType) {}
        public void checkServerTrusted(X509Certificate[] chain, String authType) {}
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }
}