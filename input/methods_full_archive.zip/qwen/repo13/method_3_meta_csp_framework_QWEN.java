import java.util.*;




class DirectedSparseMultigraph<V, E> {
    private final Set<V> vertices = new HashSet<>();
    private final Map<V, Map<V, E>> edgeMap = new HashMap<>();
    
    public void addVertex(V v) { 
        if (vertices.add(v)) {
            edgeMap.putIfAbsent(v, new HashMap<>());
        }
    }
    
    public void addEdge(E edge, V source, V target) { 
        addVertex(source); 
        addVertex(target);
        edgeMap.get(source).put(target, edge);
    }
    
    public Set<V> getVertices() { return Collections.unmodifiableSet(vertices); }
    
    public int getEdgeCount() { 
        int count = 0;
        for (Map<V, E> targets : edgeMap.values()) {
            count += targets.size();
        }
        return count;
    }
    
    public E getEdge(V source, V target) { 
        return edgeMap.getOrDefault(source, Collections.emptyMap()).get(target); 
    }
    
    public Collection<E> getOutEdges(V vertex) { 
        return edgeMap.getOrDefault(vertex, Collections.emptyMap()).values(); 
    }
}




class Variable {
    private String id;
    public Variable(String id) { this.id = id; }
    public String getId() { return id; }
    public String toString() { return "Var[" + id + "]"; }
}

class Trajectory {
    private final int sequenceNumberStart;
    private final int sequenceNumberEnd;
    
    public Trajectory(int sequenceNumberStart, int sequenceNumberEnd) {
        this.sequenceNumberStart = sequenceNumberStart;
        this.sequenceNumberEnd = sequenceNumberEnd;
    }
    
    public int getSequenceNumberStart() { return sequenceNumberStart; }
    public int getSequenceNumberEnd() { return sequenceNumberEnd; }
}

class TrajectoryEnvelope extends Variable {
    private final Trajectory trajectory;
    private TrajectoryEnvelope superEnvelope;
    private final List<Variable> recursivelyDependentVariables = new ArrayList<>();
    private boolean hasSubEnvelopes;

    public TrajectoryEnvelope(String id, Trajectory trajectory) {
        super(id);
        this.trajectory = trajectory;
    }
    
    public Trajectory getTrajectory() { return trajectory; }
    public int getSequenceNumberStart() { return trajectory.getSequenceNumberStart(); }
    
    public boolean hasSuperEnvelope() { return superEnvelope != null; }
    
    public TrajectoryEnvelope getSuperEnvelope() { return superEnvelope; }
    
    public void setSuperEnvelope(TrajectoryEnvelope superEnvelope) { 
        this.superEnvelope = superEnvelope; 
    }
    
    public void addDependentVariable(Variable variable) {
        this.recursivelyDependentVariables.add(variable);
    }
    
    public List<Variable> getRecursivelyDependentVariables() { 
        return Collections.unmodifiableList(recursivelyDependentVariables); 
    }
    
    public boolean hasSubEnvelopes() { return hasSubEnvelopes; }
    
    public void setHasSubEnvelopes(boolean hasSubEnvelopes) { 
        this.hasSubEnvelopes = hasSubEnvelopes; 
    }
    
    @Override
    public String toString() { 
        return "TE[" + getId() + "](" + trajectory.getSequenceNumberStart() + "-" + trajectory.getSequenceNumberEnd() + ")"; 
    }
}

class Constraint {
    private String type;
    public Constraint(String type) { this.type = type; }
    public String getType() { return type; }
}

class AllenIntervalConstraint extends Constraint {
    public enum Type { 
        Before, After, Meets, MetBy, Overlaps, OverlappedBy, 
        Starts, StartedBy, Finishes, FinishedBy, During, Contains, Equals, BeforeOrMeets 
    }
    
    private final Type[] types;
    private final Variable from;
    private final Variable to;
    
    public AllenIntervalConstraint(Type type, Variable from, Variable to) {
        super("AllenInterval");
        this.types = new Type[]{type};
        this.from = from;
        this.to = to;
    }
    
    public Type[] getTypes() { return types; }
    public Variable getFrom() { return from; }
    public Variable getTo() { return to; }
}

class ConstraintNetwork {
    private final Constraint[] constraints;
    
    public ConstraintNetwork(Constraint[] constraints) { 
        this.constraints = constraints; 
    }
    
    public Constraint[] getConstraints() { return constraints; }
}

class ConstraintSolver {
    private final ConstraintNetwork constraintNetwork;
    
    public ConstraintSolver(ConstraintNetwork constraintNetwork) { 
        this.constraintNetwork = constraintNetwork; 
    }
    
    public ConstraintNetwork getConstraintNetwork() { return constraintNetwork; }
}




public class method_3_meta_csp_framework_QWEN {

    
    
    
    
    private ConstraintSolver[] getConstraintSolvers() {
        
        
        Trajectory t1_fallback = new Trajectory(10, 20);
        TrajectoryEnvelope te1_fallback = new TrajectoryEnvelope("TE1_Fallback", t1_fallback);
        
        
        Trajectory t2_fallback = new Trajectory(30, 40);
        TrajectoryEnvelope te2_fallback = new TrajectoryEnvelope("TE2_Fallback", t2_fallback);
        
        AllenIntervalConstraint aic1 = new AllenIntervalConstraint(
            AllenIntervalConstraint.Type.BeforeOrMeets, te2_fallback, te1_fallback
        );

        
        Trajectory t3_normal = new Trajectory(50, 60);
        TrajectoryEnvelope te3_normal = new TrajectoryEnvelope("TE3_Normal", t3_normal);
        
        Trajectory t4_normal = new Trajectory(70, 80);
        TrajectoryEnvelope te4_normal = new TrajectoryEnvelope("TE4_Normal", t4_normal);
        
        
        Trajectory rootEnvelope = new Trajectory(40, 90);
        TrajectoryEnvelope rootTE = new TrajectoryEnvelope("RootTE", rootEnvelope);
        rootTE.setHasSubEnvelopes(true);
        te3_normal.setSuperEnvelope(rootTE); 
        
        
        
        
        Trajectory depTrajectory = new Trajectory(45, 49);
        TrajectoryEnvelope depTE = new TrajectoryEnvelope("DepTE", depTrajectory);
        depTE.setHasSubEnvelopes(false); 
        
        rootTE.addDependentVariable(depTE);
        
        AllenIntervalConstraint aic2 = new AllenIntervalConstraint(
            AllenIntervalConstraint.Type.BeforeOrMeets, te4_normal, te3_normal
        );

        ConstraintNetwork cn = new ConstraintNetwork(new Constraint[]{aic1, aic2});
        return new ConstraintSolver[]{new ConstraintSolver(cn)};
    }


// ORIGINAL CODESEARCHNET METHOD — START

public DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> getCurrentDependencies() {
		DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> depGraph = new DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]>();
		ConstraintNetwork cn = this.getConstraintSolvers()[0].getConstraintNetwork();
		Constraint[] cons = cn.getConstraints();
		for (Constraint con : cons) {
			if (con instanceof AllenIntervalConstraint) {
				AllenIntervalConstraint aic = (AllenIntervalConstraint)con;
				if (aic.getTypes()[0].equals(AllenIntervalConstraint.Type.BeforeOrMeets)) {

					
					TrajectoryEnvelope mustWaitToStart = (TrajectoryEnvelope)aic.getTo();
					TrajectoryEnvelope mustFinishBeforeOtherCanStart = (TrajectoryEnvelope)aic.getFrom();
					TrajectoryEnvelope waitingEnvelope = null;

					
					TrajectoryEnvelope root = mustWaitToStart;
					while (root.hasSuperEnvelope()) root = root.getSuperEnvelope();
					for (Variable depVar : root.getRecursivelyDependentVariables()) {
						TrajectoryEnvelope depTE = (TrajectoryEnvelope)depVar;
						if (!depTE.hasSubEnvelopes() && depTE.getTrajectory().getSequenceNumberEnd() == mustWaitToStart.getSequenceNumberStart()-1) {
							waitingEnvelope = depTE;
							break;
						}
					}

					
					Integer thresholdPoint = mustFinishBeforeOtherCanStart.getTrajectory().getSequenceNumberEnd();
					Integer waitingPoint = null;
					
					
					if (waitingEnvelope == null) {
						
						waitingPoint = mustWaitToStart.getTrajectory().getSequenceNumberStart();
						waitingEnvelope = mustWaitToStart;
					}
					else {
						waitingPoint = waitingEnvelope.getTrajectory().getSequenceNumberEnd();
					}
					
					
					ArrayList<TrajectoryEnvelope> verts = new ArrayList<TrajectoryEnvelope>();
					verts.add(waitingEnvelope);
					verts.add(mustFinishBeforeOtherCanStart);
					depGraph.addVertex(waitingEnvelope);
					depGraph.addVertex(mustFinishBeforeOtherCanStart);
					depGraph.addEdge(new Integer[] {waitingPoint,thresholdPoint}, waitingEnvelope, mustFinishBeforeOtherCanStart);
				}
			}
		}
		return depGraph;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 3: TrajectoryEnvelopeScheduler.getCurrentDependencies (Detailed)     ║");
        System.out.println("╚══════════════════════════════════════════════════════════════════════════════╝\n");

        try {
            method_3_meta_csp_framework_QWEN scheduler = new method_3_meta_csp_framework_QWEN();
            
            System.out.println("┌─ DEPENDENCY GRAPH ANALYSIS ────────────────────────────────────────────────┐");
            System.out.println("│ 1. Retrieving ConstraintNetwork from ConstraintSolver[0]");
            System.out.println("│ 2. Iterating over 2 AllenIntervalConstraints (Type: BeforeOrMeets)");
            System.out.println("│");
            System.out.println("│ [Constraint 1 Analysis]");
            System.out.println("│   - mustWaitToStart: TE1_Fallback (10-20)");
            System.out.println("│   - mustFinishBeforeOther: TE2_Fallback (30-40)");
            System.out.println("│   - Searching for previous envelope in root dependencies... NONE FOUND");
            System.out.println("│   - FALLBACK TRIGGERED: waitingPoint set to start of mustWaitToStart (10)");
            System.out.println("│");
            System.out.println("│ [Constraint 2 Analysis]");
            System.out.println("│   - mustWaitToStart: TE3_Normal (50-60)");
            System.out.println("│   - mustFinishBeforeOther: TE4_Normal (70-80)");
            System.out.println("│   - Root envelope found. Checking recursively dependent variables...");
            System.out.println("│   - MATCH FOUND: DepTE (45-49) has no sub-envelopes and ends at 49 (50-1)");
            System.out.println("│   - NORMAL PATH: waitingPoint set to end of DepTE (49)");
            System.out.println("└────────────────────────────────────────────────────────────────────────────┘\n");
            
            DirectedSparseMultigraph<TrajectoryEnvelope, Integer[]> depGraph = scheduler.getCurrentDependencies();
            
            System.out.println("┌─ GENERATED DEPENDENCY GRAPH RESULTS ───────────────────────────────────────┐");
            System.out.println("│ Total Unique Vertices: " + depGraph.getVertices().size());
            System.out.println("│ Total Directed Edges: " + depGraph.getEdgeCount());
            System.out.println("│");
            
            int edgeNum = 1;
            for (TrajectoryEnvelope source : depGraph.getVertices()) {
                for (TrajectoryEnvelope target : depGraph.getVertices()) {
                    Integer[] edgeData = depGraph.getEdge(source, target);
                    if (edgeData != null) {
                        System.out.println("│ Edge #" + edgeNum + ":");
                        System.out.println("│   Source (Waiting):  " + source);
                        System.out.println("│   Target (Blocking): " + target);
                        System.out.println("│   Edge Payload:      [waitingPoint=" + edgeData[0] + ", thresholdPoint=" + edgeData[1] + "]");
                        System.out.println("│");
                        edgeNum++;
                    }
                }
            }
            System.out.println("└────────────────────────────────────────────────────────────────────────────┘");
            
            
            if (depGraph.getVertices().size() == 4 && depGraph.getEdgeCount() == 2) {
                System.out.println("✅ SUCCESS: Dependency graph constructed perfectly. Both logic branches executed.");
            } else {
                System.out.println("⚠️ WARNING: Graph metrics do not match expected values.");
            }
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}