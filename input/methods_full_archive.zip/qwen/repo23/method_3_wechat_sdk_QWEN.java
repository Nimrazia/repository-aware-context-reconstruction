import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;




class ServletException extends Exception {
    public ServletException(String message) { super(message); }
}

class HttpServletRequest {
    private final java.util.Map<String, String[]> parameters = new java.util.HashMap<>();
    public void setParameter(String name, String value) { parameters.put(name, new String[]{value}); }
    public String getParameter(String name) { 
        String[] values = parameters.get(name);
        return values != null && values.length > 0 ? values[0] : null;
    }
}

class HttpServletResponse {
    private final StringWriter writer = new StringWriter();
    public PrintWriter getWriter() { return new PrintWriter(writer); }
    public String getOutput() { return writer.toString(); }
}




class Signature {
    private String signature;
    private String timestamp;
    private String nonce;
    private String echostr;
    
    public void setSignature(String signature) { this.signature = signature; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    public void setNonce(String nonce) { this.nonce = nonce; }
    public void setEchostr(String echostr) { this.echostr = echostr; }
    public String getSignature() { return signature; }
    public String getEchostr() { return echostr; }
    public String toString() { 
        return "Signature{signature='" + signature + "', timestamp='" + timestamp + "', nonce='" + nonce + "'}"; 
    }
}

class WebUtil {
    public static void outputString(HttpServletResponse response, String str) throws IOException {
        System.out.println("  -> Writing to response: " + str);
        response.getWriter().write(str);
        response.getWriter().flush();
    }
}


class HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }
}




public class method_3_wechat_sdk_QWEN extends HttpServlet {
    private static class log {
        public static void info(String msg, Object... args) { System.out.println("[INFO] " + String.format(msg, args)); }
        public static void error(String msg, Throwable e) { System.err.println("[ERROR] " + msg + " - " + e.getMessage()); }
    }

    
    private boolean checkSignature(Signature signature, HttpServletRequest request) {
        signature.setSignature(request.getParameter("signature"));
        signature.setTimestamp(request.getParameter("timestamp"));
        signature.setNonce(request.getParameter("nonce"));
        signature.setEchostr(request.getParameter("echostr"));
        
        
        return "valid_sig".equals(signature.getSignature());
    }


// ORIGINAL CODESEARCHNET METHOD — START

@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Signature signature = new Signature();
            boolean hasRights = checkSignature(signature, request);

            if (hasRights) {
                log.info("signature-success:{}", signature);
                WebUtil.outputString(response, signature.getEchostr());
            } else {
                log.info("signature-not-match:{}", signature);
            }
        } catch (Exception e) {
            log.error("signature-error", e);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 3: AccessServlet.doGet - WeChat Signature Validation ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            method_3_wechat_sdk_QWEN servlet = new method_3_wechat_sdk_QWEN();
            
            HttpServletRequest request = new HttpServletRequest();
            request.setParameter("signature", "valid_sig");
            request.setParameter("timestamp", "1690000000");
            request.setParameter("nonce", "nonce123");
            request.setParameter("echostr", "echo_string_456");
            
            HttpServletResponse response = new HttpServletResponse();
            
            System.out.println("┌─ SIGNATURE VALIDATION PROCESS ─────────────────────────────┐");
            System.out.println("│ 1. Instantiating Signature object...");
            System.out.println("│ 2. Extracting parameters and validating signature...");
            System.out.println("│ 3. Checking validation result...");
            
            servlet.doGet(request, response);
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            
            System.out.println("┌─ VALIDATION RESULT ────────────────────────────────────────┐");
            System.out.println("│ ✓ Access Granted: true");
            System.out.println("│ ✓ Response Output: " + response.getOutput().trim());
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}