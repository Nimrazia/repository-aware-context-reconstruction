import java.io.File;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;




class License {
    private final String appId;
    private final String appSecret;
    public License(String appId, String appSecret) { this.appId = appId; this.appSecret = appSecret; }
    public String getAppId() { return appId; }
}

class MediaFile {
    private final MediaType mediaType;
    private final File file;
    public MediaFile(MediaType mediaType, File file) { this.mediaType = mediaType; this.file = file; }
    public MediaType getMediaType() { return mediaType; }
    public File getFile() { return file; }
    public String toString() { return "MediaFile{type=" + mediaType.getName() + ", file=" + file.getName() + "}"; }
}

enum MediaType {
    IMAGE("image"), VOICE("voice"), VIDEO("video"), THUMB("thumb");
    private final String name;
    MediaType(String name) { this.name = name; }
    public String getName() { return name; }
}

class MediaJsonRtn {
    private String type;
    private String media_id;
    private int created_at;
    private int errcode;
    private String errmsg;
    public void setType(String type) { this.type = type; }
    public void setMedia_id(String media_id) { this.media_id = media_id; }
    public void setCreated_at(int created_at) { this.created_at = created_at; }
    public void setErrcode(int errcode) { this.errcode = errcode; }
    public void setErrmsg(String errmsg) { this.errmsg = errmsg; }
    public String toString() { 
        return "MediaJsonRtn{type='" + type + "', media_id='" + media_id + "', errcode=" + errcode + "}"; 
    }
}

class JsonRtnUtil {
    public static <T> T buildFailureJsonRtn(Class<T> clazz, String errMsg) {
        try {
            T instance = clazz.getDeclaredConstructor().newInstance();
            
            clazz.getMethod("setErrcode", int.class).invoke(instance, -1);
            clazz.getMethod("setErrmsg", String.class).invoke(instance, errMsg);
            return instance;
        } catch (Exception e) { throw new RuntimeException(e); }
    }
    public static <T> T parseJsonRtn(String json, Class<T> clazz) {
        try {
            T instance = clazz.getDeclaredConstructor().newInstance();
            clazz.getMethod("setType", String.class).invoke(instance, "image");
            clazz.getMethod("setMedia_id", String.class).invoke(instance, "MEDIA_ID_12345");
            clazz.getMethod("setCreated_at", int.class).invoke(instance, 1690000000);
            clazz.getMethod("setErrcode", int.class).invoke(instance, 0);
            clazz.getMethod("setErrmsg", String.class).invoke(instance, "ok");
            return instance;
        } catch (Exception e) { throw new RuntimeException(e); }
    }
}

class AccessTokenUtil {
    public static String getAccessToken(License license) { return "MOCK_ACCESS_TOKEN_" + license.getAppId(); }
}

enum WechatRequest {
    UPLOAD_MEDIA("https://api.weixin.qq.com/cgi-bin/media/upload");
    private final String url;
    WechatRequest(String url) { this.url = url; }
    public String getUrl() { return url; }
}

class HttpUtil {
    public static final int CONNECT_TIMEOUT = 5000;
    public static final int SOCKET_TIMEOUT = 10000;
    public static final ResponseHandler<String> UTF8_CONTENT_HANDLER = response -> "{\"type\":\"image\",\"media_id\":\"MEDIA_ID_12345\",\"created_at\":1690000000}";
}
interface ResponseHandler<T> { T handleResponse(Object response) throws Exception; }




class HttpEntity {}
class MultipartEntityBuilder {
    public static MultipartEntityBuilder create() { return new MultipartEntityBuilder(); }
    public MultipartEntityBuilder addBinaryBody(String name, File file) { return this; }
    public HttpEntity build() { return new HttpEntity(); }
}

class RequestBuilder {
    URI uri;
    int connectTimeout;
    int socketTimeout;
    HttpEntity body;
    
    public RequestBuilder uri(URI uri) { this.uri = uri; return this; }
    public RequestBuilder connectTimeout(int ms) { this.connectTimeout = ms; return this; }
    public RequestBuilder socketTimeout(int ms) { this.socketTimeout = ms; return this; }
    public RequestBuilder body(HttpEntity entity) { this.body = entity; return this; }
    
    public Executor execute() { return new Executor(this); }
}

class Executor {
    private final RequestBuilder builder;
    public Executor(RequestBuilder builder) { this.builder = builder; }
    public <T> T handleResponse(ResponseHandler<T> handler) throws Exception {
        System.out.println("  -> Executing HTTP POST to: " + builder.uri);
        System.out.println("  -> Connect Timeout: " + builder.connectTimeout + "ms, Socket Timeout: " + builder.socketTimeout + "ms");
        return handler.handleResponse(new Object());
    }
}

class Request {
    public static RequestBuilder Post(URI uri) { return new RequestBuilder().uri(uri); }
}

class URIBuilder {
    private final String baseUrl;
    private final Map<String, String> params = new HashMap<>();
    public URIBuilder(String url) { this.baseUrl = url; }
    public URIBuilder setParameter(String key, String value) { params.put(key, value); return this; }
    public URI build() throws Exception {
        StringBuilder sb = new StringBuilder(baseUrl);
        sb.append("?");
        for (Map.Entry<String, String> entry : params.entrySet()) {
            sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
        }
        return new URI(sb.substring(0, sb.length() - 1));
    }
}




public class method_1_wechat_sdk_QWEN {
    private static class log {
        public static void info(String msg, Object... args) { System.out.println("[INFO] " + String.format(msg, args)); }
        public static void error(String msg, Throwable e) { System.err.println("[ERROR] " + msg + " - " + e.getMessage()); }
    }


// ORIGINAL CODESEARCHNET METHOD — START

public static MediaJsonRtn uploadMedia(License license, MediaFile mediaFile) {
        if (mediaFile == null) {
            return JsonRtnUtil.buildFailureJsonRtn(MediaJsonRtn.class, "missing mediaFile");
        }
        

        String accessToken = AccessTokenUtil.getAccessToken(license);
        String url = WechatRequest.UPLOAD_MEDIA.getUrl();
        try {
            MediaType mediaType = mediaFile.getMediaType();
            URI uri = new URIBuilder(url)
                    .setParameter("access_token", accessToken)
                    .setParameter("type", mediaType.getName())
                    .build();

            HttpEntity httpEntity = MultipartEntityBuilder.create()
                    .addBinaryBody("body", mediaFile.getFile())
                    .build();

            String rtnJson = Request.Post(uri)
                    .connectTimeout(HttpUtil.CONNECT_TIMEOUT)
                    .socketTimeout(HttpUtil.SOCKET_TIMEOUT)
                    .body(httpEntity)
                    .execute().handleResponse(HttpUtil.UTF8_CONTENT_HANDLER);

            MediaJsonRtn jsonRtn = JsonRtnUtil.parseJsonRtn(rtnJson, MediaJsonRtn.class);
            log.info("upload media:\n url={},\n body={},\n rtn={},{}", uri, mediaFile, rtnJson, jsonRtn);
            return jsonRtn;
        } catch (Exception e) {
            String msg = "upload media failed:\n " +
                    "url=" + url + "?access_token=" + accessToken + ",\n body=" + mediaFile;
            log.error(msg, e);
            return JsonRtnUtil.buildFailureJsonRtn(MediaJsonRtn.class, "uploadMedia failed");
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 1: MediaUtil.uploadMedia - WeChat Media Upload       ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            License license = new License("wx1234567890", "secret");
            MediaFile mediaFile = new MediaFile(MediaType.IMAGE, new java.io.File("test_image.jpg"));
            
            System.out.println("┌─ MEDIA UPLOAD PROCESS ─────────────────────────────────────┐");
            System.out.println("│ 1. Validating mediaFile...");
            System.out.println("│ 2. Fetching access token for license...");
            System.out.println("│ 3. Building multipart HTTP entity...");
            System.out.println("│ 4. Executing fluent HTTP POST request...");
            
            MediaJsonRtn result = uploadMedia(license, mediaFile);
            
            System.out.println("└──────────────────────────────────────────────────────────────┘\n");
            
            System.out.println("┌─ UPLOAD RESULT ────────────────────────────────────────────┐");
            System.out.println("│ ✓ Success: " + (result.toString().contains("errcode=0")));
            System.out.println("│ ✓ Response: " + result);
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}