import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeSet;

public class method_1_mrm_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public synchronized Metadata getMetadata( String path )
            throws IOException, MetadataNotFoundException
        {
            Metadata metadata = new Metadata();
            boolean foundMetadata = false;
            path = StringUtils.stripEnd( StringUtils.stripStart( path, "/" ), "/" );
            String groupId = path.replace( '/', '.' );
            Set<String> pluginArtifactIds = getArtifactIds( groupId );
            if ( pluginArtifactIds != null )
            {
                List<Plugin> plugins = new ArrayList<Plugin>();
                for ( String artifactId : pluginArtifactIds )
                {
                    Set<String> pluginVersions = getVersions( groupId, artifactId );
                    if ( pluginVersions == null || pluginVersions.isEmpty() )
                    {
                        continue;
                    }
                    String[] versions = pluginVersions.toArray( new String[pluginVersions.size()] );
                    Arrays.sort( versions, new VersionComparator() );
                    MavenXpp3Reader reader = new MavenXpp3Reader();
                    for ( int j = versions.length - 1; j >= 0; j-- )
                    {
                        InputStream inputStream = null;
                        try
                        {
                            inputStream = get( new Artifact( groupId, artifactId, versions[j], "pom" ) );
                            Model model = reader.read( new XmlStreamReader( inputStream ) );
                            if ( model == null || !"maven-plugin".equals( model.getPackaging() ) )
                            {
                                continue;
                            }
                            Plugin plugin = new Plugin();
                            plugin.setArtifactId( artifactId );
                            plugin.setName( model.getName() );
                            
                            
                            
                            boolean havePrefix = false;
                            final Build build = model.getBuild();
                            if ( build != null && build.getPlugins() != null )
                            {
                                havePrefix = setPluginGoalPrefixFromConfiguration( plugin, build.getPlugins() );
                            }
                            if ( !havePrefix && build != null && build.getPluginManagement() != null
                                && build.getPluginManagement().getPlugins() != null )
                            {
                                havePrefix = setPluginGoalPrefixFromConfiguration( plugin,
                                                                                   build.getPluginManagement().getPlugins() );
                            }
                            if ( !havePrefix && artifactId.startsWith( "maven-" ) && artifactId.endsWith( "-plugin" ) )
                            {
                                plugin.setPrefix(
                                    StringUtils.removeStart( StringUtils.removeEnd( artifactId, "-plugin" ), "maven-" ) );
                                havePrefix = true;
                            }
                            if ( !havePrefix && artifactId.endsWith( "-maven-plugin" ) )
                            {
                                plugin.setPrefix( StringUtils.removeEnd( artifactId, "-maven-plugin" ) );
                                havePrefix = true;
                            }
                            if ( !havePrefix )
                            {
                                plugin.setPrefix( artifactId );
                            }
                            plugins.add( plugin );
                            foundMetadata = true;
                            break;
                        }
                        catch ( ArtifactNotFoundException e )
                        {
                            
                        }
                        catch ( XmlPullParserException e )
                        {
                            
                        }
                        finally
                        {
                            IOUtils.closeQuietly( inputStream );
                        }
                    }
                }
                if ( !plugins.isEmpty() )
                {
                    metadata.setPlugins( plugins );
                }
            }
            int index = path.lastIndexOf( '/' );
            groupId = ( index == -1 ? groupId : groupId.substring( 0, index ) ).replace( '/', '.' );
            String artifactId = ( index == -1 ? null : path.substring( index + 1 ) );
            if ( artifactId != null )
            {
                Set<String> artifactVersions = getVersions( groupId, artifactId );
                if ( artifactVersions != null && !artifactVersions.isEmpty() )
                {
                    metadata.setGroupId( groupId );
                    metadata.setArtifactId( artifactId );
                    Versioning versioning = new Versioning();
                    List<String> versions = new ArrayList<String>( artifactVersions );
                    Collections.sort( versions, new VersionComparator() ); 
                    long lastUpdated = 0;
                    for ( String version : versions )
                    {
                        try
                        {
                            long lastModified = getLastModified( new Artifact( groupId, artifactId, version, "pom" ) );
                            versioning.addVersion( version );
                            if ( lastModified >= lastUpdated )
                            {
                                lastUpdated = lastModified;
                                versioning.setLastUpdatedTimestamp( new Date( lastModified ) );
                                versioning.setLatest( version );
                                if ( !version.endsWith( "-SNAPSHOT" ) )
                                {
                                    versioning.setRelease( version );
                                }
                            }
                        }
                        catch ( ArtifactNotFoundException e )
                        {
                            
                        }
                    }
                    metadata.setVersioning( versioning );
                    foundMetadata = true;
                }
            }

            int index2 = index == -1 ? -1 : path.lastIndexOf( '/', index - 1 );
            groupId = index2 == -1 ? groupId : groupId.substring( 0, index2 ).replace( '/', '.' );
            artifactId = index2 == -1 ? artifactId : path.substring( index2 + 1, index );
            String version = index2 == -1 ? null : path.substring( index + 1 );
            if ( version != null && version.endsWith( "-SNAPSHOT" ) )
            {
                Map<String, Map<String, Map<String, Map<Artifact, Content>>>> contents = getContents();
                Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get( groupId );
                Map<String, Map<Artifact, Content>> versionMap = ( artifactMap == null ? null : artifactMap.get( artifactId ) );
                Map<Artifact, Content> filesMap = ( versionMap == null ? null : versionMap.get( version ) );
                if ( filesMap != null )
                {
                    List<SnapshotVersion> snapshotVersions = new ArrayList<SnapshotVersion>();
                    int maxBuildNumber = 0;
                    long lastUpdated = 0;
                    String timestamp = null;
                    boolean found = false;
                    for ( final Map.Entry<Artifact, Content> entry : filesMap.entrySet() )
                    {
                        final Artifact artifact = entry.getKey();
                        final Content content = entry.getValue();
                        SimpleDateFormat fmt = new SimpleDateFormat( "yyyyMMddHHmmss" );
                        fmt.setTimeZone( TimeZone.getTimeZone( "GMT" ) );
                        String lastUpdatedTime = fmt.format( new Date( content.getLastModified() ) );
                        try
                        {
                            Maven3.addSnapshotVersion( snapshotVersions, artifact, lastUpdatedTime );
                        }
                        catch ( LinkageError e )
                        {
                            
                        }
                        if ( "pom".equals( artifact.getType() ) )
                        {
                            if ( artifact.getBuildNumber() != null
                                && maxBuildNumber < artifact.getBuildNumber().intValue() )
                            {
                                maxBuildNumber = artifact.getBuildNumber().intValue();
                                timestamp = artifact.getTimestampString();
                            }
                            else
                            {
                                maxBuildNumber = Math.max( 1, maxBuildNumber );
                            }
                            lastUpdated = Math.max( lastUpdated, content.getLastModified() );
                            found = true;
                        }
                    }

                    if ( !snapshotVersions.isEmpty() || found )
                    {
                        Versioning versioning = metadata.getVersioning();
                        if ( versioning == null )
                        {
                            versioning = new Versioning();
                        }
                        metadata.setGroupId( groupId );
                        metadata.setArtifactId( artifactId );
                        metadata.setVersion( version );
                        try
                        {
                            Maven3.addSnapshotVersions( versioning, snapshotVersions );
                        }
                        catch ( LinkageError e )
                        {
                            
                        }
                        if ( maxBuildNumber > 0 )
                        {
                            Snapshot snapshot = new Snapshot();
                            snapshot.setBuildNumber( maxBuildNumber );
                            snapshot.setTimestamp( timestamp );
                            versioning.setSnapshot( snapshot );
                        }
                        versioning.setLastUpdatedTimestamp( new Date( lastUpdated ) );
                        metadata.setVersioning( versioning );
                        foundMetadata = true;
                    }
                }

            }
            if ( !foundMetadata )
            {
                throw new MetadataNotFoundException( path );
            }
            return metadata;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== MRM MockArtifactStore.getMetadata Test ===");
        method_1_mrm_QWEN store = new method_1_mrm_QWEN();
        
        
        Map<String, Map<String, Map<String, Map<Artifact, Content>>>> contents = store.getContents();
        contents.put("org.apache.maven.plugins", new HashMap<>());
        Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get("org.apache.maven.plugins");
        artifactMap.put("maven-compiler-plugin", new HashMap<>());
        Map<String, Map<Artifact, Content>> versionMap = artifactMap.get("maven-compiler-plugin");
        versionMap.put("3.8.1", new HashMap<>());
        Map<Artifact, Content> filesMap = versionMap.get("3.8.1");
        
        String mockPom = "<?xml version=\"1.0\"?><project><packaging>maven-plugin</packaging><name>Compiler Plugin</name><build><plugins><plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-plugin-plugin</artifactId><configuration><goalPrefix>compiler</goalPrefix></configuration></plugin></plugins></build></project>";
        Artifact pomArtifact = new Artifact("org.apache.maven.plugins", "maven-compiler-plugin", "3.8.1", "pom");
        filesMap.put(pomArtifact, new BytesContent(mockPom.getBytes()));
        
        try {
            System.out.println("Invoking getMetadata for 'org/apache/maven/plugins/maven-compiler-plugin'...");
            Metadata metadata = store.getMetadata("org/apache/maven/plugins/maven-compiler-plugin");
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Metadata ArtifactId: " + metadata.getArtifactId());
            System.out.println("Metadata Plugins count: " + (metadata.getPlugins() != null ? metadata.getPlugins().size() : 0));
            if (metadata.getPlugins() != null && !metadata.getPlugins().isEmpty()) {
                System.out.println("First Plugin Prefix: " + metadata.getPlugins().get(0).getPrefix());
            }
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    private Map<String, Map<String, Map<String, Map<Artifact, Content>>>> contents = new HashMap<>();
    public Map<String, Map<String, Map<String, Map<Artifact, Content>>>> getContents() { return contents; }

    private Set<String> getArtifactIds(String groupId) {
        Map<String, Map<String, Map<Artifact, Content>>> map = contents.get(groupId);
        return map != null ? new TreeSet<>(map.keySet()) : null;
    }

    private Set<String> getVersions(String groupId, String artifactId) {
        Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get(groupId);
        if (artifactMap == null) return null;
        Map<String, Map<Artifact, Content>> versionMap = artifactMap.get(artifactId);
        return versionMap != null ? new TreeSet<>(versionMap.keySet()) : null;
    }

    private long getLastModified(Artifact artifact) throws IOException, ArtifactNotFoundException {
        Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get(artifact.getGroupId());
        if (artifactMap == null) throw new ArtifactNotFoundException(artifact);
        Map<String, Map<Artifact, Content>> versionMap = artifactMap.get(artifact.getArtifactId());
        if (versionMap == null) throw new ArtifactNotFoundException(artifact);
        Map<Artifact, Content> filesMap = versionMap.get(artifact.getVersion());
        if (filesMap == null) throw new ArtifactNotFoundException(artifact);
        Content content = filesMap.get(artifact);
        if (content == null) throw new ArtifactNotFoundException(artifact);
        return content.getLastModified();
    }

    private InputStream get(Artifact artifact) throws IOException, ArtifactNotFoundException {
        Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get(artifact.getGroupId());
        if (artifactMap == null) throw new ArtifactNotFoundException(artifact);
        Map<String, Map<Artifact, Content>> versionMap = artifactMap.get(artifact.getArtifactId());
        if (versionMap == null) throw new ArtifactNotFoundException(artifact);
        Map<Artifact, Content> filesMap = versionMap.get(artifact.getVersion());
        if (filesMap == null) throw new ArtifactNotFoundException(artifact);
        Content content = filesMap.get(artifact);
        if (content == null) throw new ArtifactNotFoundException(artifact);
        return content.getInputStream();
    }

    private boolean setPluginGoalPrefixFromConfiguration(Plugin plugin, List<?> pluginConfigs) {
        return false; 
    }

    
    public static class Metadata {
        private String groupId, artifactId, version;
        private List<Plugin> plugins;
        private Versioning versioning;
        public void setGroupId(String v) { groupId = v; } public String getGroupId() { return groupId; }
        public void setArtifactId(String v) { artifactId = v; } public String getArtifactId() { return artifactId; }
        public void setVersion(String v) { version = v; } public String getVersion() { return version; }
        public void setPlugins(List<Plugin> p) { plugins = p; } public List<Plugin> getPlugins() { return plugins; }
        public void setVersioning(Versioning v) { versioning = v; } public Versioning getVersioning() { return versioning; }
    }

    public static class Plugin {
        private String artifactId, name, prefix;
        public void setArtifactId(String v) { artifactId = v; } public String getArtifactId() { return artifactId; }
        public void setName(String v) { name = v; } public String getName() { return name; }
        public void setPrefix(String v) { prefix = v; } public String getPrefix() { return prefix; }
    }

    public static class Versioning {
        private String latest, release, lastUpdated;
        private List<String> versions = new ArrayList<>();
        private Snapshot snapshot;
        private List<SnapshotVersion> snapshotVersions = new ArrayList<>();
        public void setLatest(String v) { latest = v; } public String getLatest() { return latest; }
        public void setRelease(String v) { release = v; } public String getRelease() { return release; }
        public void setLastUpdated(String v) { lastUpdated = v; } public String getLastUpdated() { return lastUpdated; }
        public void setLastUpdatedTimestamp(Date d) { lastUpdated = new SimpleDateFormat("yyyyMMddHHmmss").format(d); }
        public void addVersion(String v) { versions.add(v); } public List<String> getVersions() { return versions; }
        public void setSnapshot(Snapshot s) { snapshot = s; } public Snapshot getSnapshot() { return snapshot; }
        public void addSnapshotVersion(SnapshotVersion sv) { snapshotVersions.add(sv); }
        public List<SnapshotVersion> getSnapshotVersions() { return snapshotVersions; }
    }

    public static class Snapshot {
        private int buildNumber; private String timestamp;
        public void setBuildNumber(int v) { buildNumber = v; } public int getBuildNumber() { return buildNumber; }
        public void setTimestamp(String v) { timestamp = v; } public String getTimestamp() { return timestamp; }
    }

    public static class SnapshotVersion {
        private String version, classifier, extension, updated;
        public void setVersion(String v) { version = v; } public String getVersion() { return version; }
        public void setClassifier(String v) { classifier = v; } public String getClassifier() { return classifier; }
        public void setExtension(String v) { extension = v; } public String getExtension() { return extension; }
        public void setUpdated(String v) { updated = v; } public String getUpdated() { return updated; }
    }

    
    public static class Artifact {
        private String groupId, artifactId, version, type, classifier;
        private Integer buildNumber; private String timestampString;
        public Artifact(String g, String a, String v, String t) { groupId=g; artifactId=a; version=v; type=t; }
        public String getGroupId() { return groupId; } public String getArtifactId() { return artifactId; }
        public String getVersion() { return version; } public String getType() { return type; }
        public String getClassifier() { return classifier; } public Integer getBuildNumber() { return buildNumber; }
        public String getTimestampString() { return timestampString; }
    }

    public interface Content {
        long getLastModified(); InputStream getInputStream() throws IOException; long getLength();
    }

    public static class BytesContent implements Content {
        private byte[] bytes;
        public BytesContent(byte[] bytes) { this.bytes = bytes; }
        public long getLastModified() { return System.currentTimeMillis(); }
        public InputStream getInputStream() { return new ByteArrayInputStream(bytes); }
        public long getLength() { return bytes.length; }
    }

    public static class ArtifactNotFoundException extends Exception {
        public ArtifactNotFoundException(Artifact a) { super("Not found: " + a.getArtifactId()); }
    }

    public static class MetadataNotFoundException extends Exception {
        public MetadataNotFoundException(String path) { super("Not found: " + path); }
    }

    
    public static class Model {
        private String packaging, name; private Build build;
        public String getPackaging() { return packaging; } public String getName() { return name; }
        public Build getBuild() { return build; }
    }

    public static class Build {
        private List<?> plugins; private PluginManagement pluginManagement;
        public List<?> getPlugins() { return plugins; }
        public PluginManagement getPluginManagement() { return pluginManagement; }
    }

    public static class PluginManagement {
        private List<?> plugins;
        public List<?> getPlugins() { return plugins; }
    }

    public static class MavenXpp3Reader {
        public Model read(Reader reader) throws IOException, XmlPullParserException { return new Model(); }
    }

    public static class XmlStreamReader extends Reader {
        private Reader delegate;
        public XmlStreamReader(InputStream in) { this.delegate = new java.io.InputStreamReader(in); }
        public int read(char[] cbuf, int off, int len) throws IOException { return delegate.read(cbuf, off, len); }
        public void close() throws IOException { delegate.close(); }
    }

    public static class XmlPullParserException extends Exception {}

    
    public static class IOUtils {
        public static void closeQuietly(InputStream in) { try { if(in!=null) in.close(); } catch(Exception e){} }
    }

    public static class StringUtils {
        public static String stripStart(String str, String stripChars) { return str != null ? str.replaceAll("^[" + stripChars + "]+", "") : null; }
        public static String stripEnd(String str, String stripChars) { return str != null ? str.replaceAll("[" + stripChars + "]+$", "") : null; }
        public static String removeStart(String str, String remove) { return str != null && str.startsWith(remove) ? str.substring(remove.length()) : str; }
        public static String removeEnd(String str, String remove) { return str != null && str.endsWith(remove) ? str.substring(0, str.length() - remove.length()) : str; }
        public static boolean isEmpty(String str) { return str == null || str.trim().isEmpty(); }
    }

    public static class VersionComparator implements Comparator<String> {
        public int compare(String o1, String o2) { return o1.compareTo(o2); }
    }

    public static class Maven3 {
        public static void addSnapshotVersion(List<SnapshotVersion> list, Artifact artifact, String time) {
            SnapshotVersion sv = new SnapshotVersion(); sv.setVersion(artifact.getVersion()); sv.setUpdated(time); list.add(sv);
        }
        public static void addSnapshotVersions(Versioning v, List<SnapshotVersion> list) {
            for (SnapshotVersion sv : list) v.addSnapshotVersion(sv);
        }
    }
}