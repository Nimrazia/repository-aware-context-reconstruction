import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

public class method_2_mrm_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    protected void doGet( HttpServletRequest req, HttpServletResponse resp )
            throws ServletException, IOException
        {
            String path = req.getPathInfo();
            String context;
            if ( path == null )
            {
                path = req.getServletPath();
                context = req.getContextPath();
            }
            else
            {
                context = req.getContextPath() + req.getServletPath();
            }
            
            if ( path.equals( "/" + settingsServletPath ) )
            {
                resp.setContentType( "text/xml" );
                PrintWriter w = resp.getWriter();
                
                Reader settingsReader = null;
                try 
                {
                    String hostAddress;
                    try
                    {
                        hostAddress = InetAddress.getLocalHost().getHostAddress();
                    }
                    catch ( UnknownHostException e )
                    {
                        hostAddress = req.getServerName();
                    }

                    String repositoryProxyUrl = req.getScheme() + "://" + hostAddress + ":" + req.getServerPort(); 
                    Reader in = new InputStreamReader( method_2_mrm_QWEN.class.getResourceAsStream( "/settings-mrm.xml" ) );
                    settingsReader = new InterpolationFilterReader( in, Collections.<String, Object>singletonMap( "repository.proxy.url", repositoryProxyUrl ), "@", "@" );
                    IOUtil.copy( settingsReader, w );
                }
                finally
                {
                    IOUtil.close( settingsReader );
                }
                return;
            }
            
            Entry entry = fileSystem.get( path );
            if ( entry instanceof FileEntry )
            {
                FileEntry fileEntry = (FileEntry) entry;
                long size = fileEntry.getSize();
                if ( size >= 0 && size < Integer.MAX_VALUE )
                {
                    resp.setContentLength( (int) size );
                }
                resp.setContentType( getServletContext().getMimeType( fileEntry.getName() ) );
                InputStream source = null;
                OutputStream destination = null;
                try
                {
                    source = fileEntry.getInputStream();
                    destination = resp.getOutputStream();
                    IOUtils.copy( source, destination );
                }
                finally
                {
                    IOUtils.closeQuietly( source );
                    IOUtils.closeQuietly( destination );
                }
                return;
            }
            else if ( entry instanceof DirectoryEntry )
            {
                if ( !path.endsWith( "/" ) )
                {
                    resp.sendRedirect( entry.getName() + "/" );
                    return;
                }
                DirectoryEntry dirEntry = (DirectoryEntry) entry;
                Entry[] entries = fileSystem.listEntries( dirEntry );
                resp.setContentType( "text/html" );
                PrintWriter w = resp.getWriter();
                w.println( "<html>" );
                w.println( "  <head>" );
                w.println( "    <title>Index of " + context + path + "</title>" );
                w.println( "    <meta http-equiv=\"Content-Type\" repository=\"text/html; charset=utf-8\"/>" );
                w.println( "</head>" );
                w.println( "<body>" );
                w.println( "<h1>Index of " + context + path + "</h1>" );
                w.println( "  <hr/>" );
                w.write( "<pre>" );

                if ( dirEntry.getParent() != null )
                {
                    w.println( "<a href='../'>../</a>" );
                }
                SimpleDateFormat format = new SimpleDateFormat( "dd-MMM-yyyy hh:mm" );
                if ( entries != null )
                {
                    for ( int i = 0; i < entries.length; i++ )
                    {
                        final String childName = entries[i].getName();
                        boolean directory = entries[i] instanceof DirectoryEntry;
                        if ( directory )
                        {
                            String dirName = childName + "/";
                            w.write(
                                "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "/\">" + formatName( dirName )
                                    + "</a>" + StringUtils.repeat( " ",
                                                                   Math.max( 0, NAME_COL_WIDTH - dirName.length() ) ) );
                        }
                        else
                        {
                            w.write(
                                "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "\">" + formatName( childName )
                                    + "</a>" + StringUtils.repeat( " ",
                                                                   Math.max( 0, NAME_COL_WIDTH - childName.length() ) ) );
                        }

                        long timestamp = 0;
                        try
                        {
                            timestamp = entries[i].getLastModified();
                        }
                        catch ( IOException e )
                        {
                            
                        }

                        w.write( " " );
                        w.write( format.format( timestamp != -1 ? new Date( timestamp ) : new Date() ) );
                        if ( directory )
                        {
                            w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                        }
                        else if ( entries[i] instanceof FileEntry )
                        {
                            FileEntry fileEntry = (FileEntry) entries[i];
                            try
                            {
                                long size = fileEntry.getSize();
                                if ( size >= 0 )
                                {
                                    w.println( StringUtils.leftPad( Long.toString( size ), SIZE_COL_WIDTH ) );
                                }
                                else
                                {
                                    w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                                }
                            }
                            catch ( IOException e )
                            {
                                w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                            }
                        }
                        else
                        {
                            w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                        }
                    }
                }
                w.write( "</pre>" );
                w.println( "  <hr/>" );
                w.println( "</body>" );
                w.println( "</html>" );
                return;
            }

            resp.sendError( HttpURLConnection.HTTP_NOT_FOUND );
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== MRM FileSystemServlet.doGet Test ===");
        method_2_mrm_QWEN servlet = new method_2_mrm_QWEN();
        servlet.settingsServletPath = "settings.xml";
        
        MockHttpServletRequest req = new MockHttpServletRequest();
        req.setPathInfo("/");
        req.setContextPath("/mrm");
        req.setServletPath("");
        
        MockHttpServletResponse resp = new MockHttpServletResponse();
        
        try {
            System.out.println("Invoking doGet for directory listing...");
            servlet.doGet(req, resp);
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Response Content-Type: " + resp.contentType);
            System.out.println("Response contains HTML index: " + resp.output.toString().contains("Index of"));
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    private static final int NAME_COL_WIDTH = 50;
    private static final int SIZE_COL_WIDTH = 20;
    protected String settingsServletPath = "settings.xml";
    private FileSystem fileSystem = new MockFileSystem();

    private static String formatName( String name ) {
        if ( name.length() < NAME_COL_WIDTH ) return name;
        return name.substring( 0, NAME_COL_WIDTH - 1 ) + ">";
    }

    protected ServletContext getServletContext() { return new MockServletContext(); }

    
    public interface HttpServletRequest {
        String getPathInfo(); String getServletPath(); String getContextPath();
        String getServerName(); int getServerPort(); String getScheme();
    }
    public interface HttpServletResponse {
        void setContentType(String t); PrintWriter getWriter() throws IOException;
        void setContentLength(int l); void sendRedirect(String l) throws IOException;
        void sendError(int c) throws IOException; OutputStream getOutputStream() throws IOException;
    }
    public interface ServletContext {
        String getMimeType(String file);
    }
    public static class ServletException extends Exception { public ServletException(String m) { super(m); } }
    
    public static class MockHttpServletRequest implements HttpServletRequest {
        private String pathInfo, servletPath, contextPath;
        public void setPathInfo(String p) { pathInfo = p; } public void setServletPath(String s) { servletPath = s; }
        public void setContextPath(String c) { contextPath = c; }
        public String getPathInfo() { return pathInfo; } public String getServletPath() { return servletPath; }
        public String getContextPath() { return contextPath; } public String getServerName() { return "localhost"; }
        public int getServerPort() { return 8080; } public String getScheme() { return "http"; }
    }
    public static class MockHttpServletResponse implements HttpServletResponse {
        public String contentType; public StringBuilder output = new StringBuilder();
        public void setContentType(String t) { contentType = t; }
        public PrintWriter getWriter() { return new PrintWriter(new StringWriter() { public void write(String s) { output.append(s); } }); }
        public void setContentLength(int l) {} public void sendRedirect(String l) {}
        public void sendError(int c) {} public OutputStream getOutputStream() { return new ByteArrayOutputStream(); }
    }
    public static class MockServletContext implements ServletContext {
        public String getMimeType(String file) { return "application/octet-stream"; }
    }

    
    public interface FileSystem { Entry get(String p); Entry[] listEntries(DirectoryEntry d); }
    public static class MockFileSystem implements FileSystem {
        public Entry get(String p) { return new MockDirectoryEntry(p); }
        public Entry[] listEntries(DirectoryEntry d) { return new Entry[]{ new MockFileEntry("file1.txt", 1024) }; }
    }
    public interface Entry { String getName(); long getLastModified() throws IOException; }
    public interface FileEntry extends Entry { long getSize() throws IOException; InputStream getInputStream() throws IOException; }
    public interface DirectoryEntry extends Entry { DirectoryEntry getParent(); }
    
    public static class MockFileEntry implements FileEntry {
        private String name; private long size;
        public MockFileEntry(String n, long s) { name = n; size = s; }
        public String getName() { return name; } public long getLastModified() { return System.currentTimeMillis(); }
        public long getSize() { return size; } public InputStream getInputStream() { return new ByteArrayInputStream(new byte[0]); }
    }
    public static class MockDirectoryEntry implements DirectoryEntry {
        private String name;
        public MockDirectoryEntry(String n) { name = n; }
        public String getName() { return name; } public long getLastModified() { return System.currentTimeMillis(); }
        public DirectoryEntry getParent() { return null; }
    }

    
    public static class IOUtils {
        public static void copy(InputStream in, OutputStream out) throws IOException {}
        public static void closeQuietly(InputStream in) { try { if(in!=null) in.close(); } catch(Exception e){} }
        public static void closeQuietly(OutputStream out) { try { if(out!=null) out.close(); } catch(Exception e){} }
    }
    public static class IOUtil {
        public static void copy(Reader in, Writer out) throws IOException {}
        public static void close(Reader in) { try { if(in!=null) in.close(); } catch(Exception e){} }
    }
    public static class StringUtils {
        public static String repeat(String s, int n) { StringBuilder sb = new StringBuilder(); for(int i=0;i<n;i++) sb.append(s); return sb.toString(); }
        public static String leftPad(String s, int size) { return String.format("%" + size + "s", s); }
        public static boolean isEmpty(String str) { return str == null || str.trim().isEmpty(); }
    }
    public static class Utils {
        public static String urlEncodePathSegment(String s) { return s; }
    }
    public static class InterpolationFilterReader extends Reader {
        private Reader delegate;
        public InterpolationFilterReader(Reader in, Map<String, Object> map, String start, String end) { this.delegate = in; }
        public int read(char[] cbuf, int off, int len) throws IOException { return delegate.read(cbuf, off, len); }
        public void close() throws IOException { delegate.close(); }
    }
}