import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class method_3_mrm_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public Metadata getMetadata( String path )
            throws IOException, MetadataNotFoundException
        {
            boolean found = false;
            Metadata result = new Metadata();
            Set<String> pluginArtifactIds = new HashSet<String>();
            Set<String> snapshotVersions = new HashSet<String>();
            for ( int i = 0; i < stores.length; i++ )
            {
                try
                {
                    Metadata partial = stores[i].getMetadata( path );
                    if ( StringUtils.isEmpty( result.getArtifactId() ) && !StringUtils.isEmpty( partial.getArtifactId() ) )
                    {
                        result.setArtifactId( partial.getArtifactId() );
                        found = true;
                    }
                    if ( StringUtils.isEmpty( result.getGroupId() ) && !StringUtils.isEmpty( partial.getGroupId() ) )
                    {
                        result.setGroupId( partial.getGroupId() );
                        found = true;
                    }
                    if ( StringUtils.isEmpty( result.getVersion() ) && !StringUtils.isEmpty( partial.getVersion() ) )
                    {
                        result.setVersion( partial.getVersion() );
                        found = true;
                    }
                    if ( partial.getPlugins() != null && !partial.getPlugins().isEmpty() )
                    {
                        for ( Plugin plugin : partial.getPlugins() )
                        {
                            if ( !pluginArtifactIds.contains( plugin.getArtifactId() ) )
                            {
                                result.addPlugin( plugin );
                                pluginArtifactIds.add( plugin.getArtifactId() );
                            }
                        }
                        found = true;
                    }
                    if ( partial.getVersioning() != null )
                    {
                        Versioning rVers = result.getVersioning();
                        if ( rVers == null )
                        {
                            rVers = new Versioning();
                        }
                        Versioning pVers = partial.getVersioning();
                        String rLU = found ? rVers.getLastUpdated() : null;
                        String pLU = pVers.getLastUpdated();
                        if ( pLU != null && ( rLU == null || rLU.compareTo( pLU ) < 0 ) )
                        {
                            
                            if ( !StringUtils.isEmpty( pVers.getLatest() ) )
                            {
                                rVers.setLatest( pVers.getLatest() );
                            }

                            if ( !StringUtils.isEmpty( pVers.getRelease() ) )
                            {
                                rVers.setLatest( pVers.getRelease() );
                            }
                            rVers.setLastUpdated( pVers.getLastUpdated() );
                        }
                        for ( String version : pVers.getVersions() )
                        {
                            if ( !rVers.getVersions().contains( version ) )
                            {
                                rVers.addVersion( version );
                            }
                        }
                        if ( pVers.getSnapshot() != null )
                        {
                            if ( rVers.getSnapshot() == null
                                || pVers.getSnapshot().getBuildNumber() > rVers.getSnapshot().getBuildNumber() )
                            {
                                Snapshot snapshot = new Snapshot();
                                snapshot.setBuildNumber( pVers.getSnapshot().getBuildNumber() );
                                snapshot.setTimestamp( pVers.getSnapshot().getTimestamp() );
                                rVers.setSnapshot( snapshot );
                            }
                        }
                        try
                        {
                            if ( pVers.getSnapshotVersions() != null && !pVers.getSnapshotVersions().isEmpty() )
                            {
                                for ( SnapshotVersion snapshotVersion : pVers.getSnapshotVersions() )
                                {
                                    String key = snapshotVersion.getVersion() + "-" + snapshotVersion.getClassifier() + "."
                                        + snapshotVersion.getExtension();
                                    if ( !snapshotVersions.contains( key ) )
                                    {
                                        rVers.addSnapshotVersion( snapshotVersion );
                                        snapshotVersions.add( key );
                                    }
                                }
                            }
                        }
                        catch ( NoSuchMethodError e )
                        {
                            
                        }

                        result.setVersioning( rVers );
                        found = true;
                    }
                }
                catch ( MetadataNotFoundException e )
                {
                    
                }
            }
            if ( !found )
            {
                throw new MetadataNotFoundException( path );
            }
            return result;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== MRM CompositeArtifactStore.getMetadata Test ===");
        
        MockArtifactStore store1 = new MockArtifactStore();
        store1.mockMetadata = new Metadata();
        store1.mockMetadata.setGroupId("org.apache.maven");
        store1.mockMetadata.setArtifactId("maven-core");
        store1.mockMetadata.setVersion("3.8.1");
        
        method_3_mrm_QWEN composite = new method_3_mrm_QWEN(new ArtifactStore[]{ store1 });
        
        try {
            System.out.println("Invoking getMetadata for 'org/apache/maven/maven-core'...");
            Metadata metadata = composite.getMetadata("org/apache/maven/maven-core");
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Merged Metadata GroupId: " + metadata.getGroupId());
            System.out.println("Merged Metadata ArtifactId: " + metadata.getArtifactId());
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    private ArtifactStore[] stores;

    public method_3_mrm_QWEN(ArtifactStore[] stores) {
        this.stores = stores;
    }

    public interface ArtifactStore {
        Metadata getMetadata(String path) throws IOException, MetadataNotFoundException;
    }

    public static class MockArtifactStore implements ArtifactStore {
        public Metadata mockMetadata;
        public Metadata getMetadata(String path) throws MetadataNotFoundException {
            if (mockMetadata != null) return mockMetadata;
            throw new MetadataNotFoundException(path);
        }
    }

    
    public static class Metadata {
        private String groupId, artifactId, version;
        private List<Plugin> plugins = new ArrayList<>();
        private Versioning versioning;
        public void setGroupId(String v) { groupId = v; } public String getGroupId() { return groupId; }
        public void setArtifactId(String v) { artifactId = v; } public String getArtifactId() { return artifactId; }
        public void setVersion(String v) { version = v; } public String getVersion() { return version; }
        public void addPlugin(Plugin p) { plugins.add(p); } public List<Plugin> getPlugins() { return plugins; }
        public void setVersioning(Versioning v) { versioning = v; } public Versioning getVersioning() { return versioning; }
    }

    public static class Plugin {
        private String artifactId;
        public void setArtifactId(String v) { artifactId = v; } public String getArtifactId() { return artifactId; }
    }

    public static class Versioning {
        private String latest, release, lastUpdated;
        private List<String> versions = new ArrayList<>();
        private Snapshot snapshot;
        private List<SnapshotVersion> snapshotVersions = new ArrayList<>();
        public void setLatest(String v) { latest = v; } public String getLatest() { return latest; }
        public void setRelease(String v) { release = v; } public String getRelease() { return release; }
        public void setLastUpdated(String v) { lastUpdated = v; } public String getLastUpdated() { return lastUpdated; }
        public void addVersion(String v) { versions.add(v); } public List<String> getVersions() { return versions; }
        public void setSnapshot(Snapshot s) { snapshot = s; } public Snapshot getSnapshot() { return snapshot; }
        public void addSnapshotVersion(SnapshotVersion sv) { snapshotVersions.add(sv); }
        public List<SnapshotVersion> getSnapshotVersions() { return snapshotVersions; }
    }

    public static class Snapshot {
        private int buildNumber; private String timestamp;
        public void setBuildNumber(int v) { buildNumber = v; } public int getBuildNumber() { return buildNumber; }
        public void setTimestamp(String v) { timestamp = v; } public String getTimestamp() { return timestamp; }
    }

    public static class SnapshotVersion {
        private String version, classifier, extension;
        public void setVersion(String v) { version = v; } public String getVersion() { return version; }
        public void setClassifier(String v) { classifier = v; } public String getClassifier() { return classifier; }
        public void setExtension(String v) { extension = v; } public String getExtension() { return extension; }
    }

    public static class MetadataNotFoundException extends Exception {
        public MetadataNotFoundException(String path) { super("Not found: " + path); }
    }

    public static class StringUtils {
        public static boolean isEmpty(String str) { return str == null || str.trim().isEmpty(); }
    }
}