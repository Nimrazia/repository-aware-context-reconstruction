import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.xml.sax.Attributes;

public class method_1_ojb_QWEN {


    
    static final int MAPPING_REPOSITORY=1, CLASS_DESCRIPTOR=2, OBJECT_CACHE=3, CLASS_EXTENT=4,
        FIELD_DESCRIPTOR=5, REFERENCE_DESCRIPTOR=6, FOREIGN_KEY=7, COLLECTION_DESCRIPTOR=8,
        ORDERBY=9, INVERSE_FK=10, FK_POINTING_TO_THIS_CLASS=11, FK_POINTING_TO_ITEMS_CLASS=12,
        ATTRIBUTE=13, QUERY_CUSTOMIZER=14, INDEX_DESCRIPTOR=15, INDEX_COLUMN=16,
        INSERT_PROCEDURE=17, UPDATE_PROCEDURE=18, DELETE_PROCEDURE=19, CONSTANT_ARGUMENT=20,
        RUNTIME_ARGUMENT=21;
    static final String TAG_SUPER = "super";
    static final int ISOLATION_LEVEL=100, PROXY_PREFETCHING_LIMIT=101, REPOSITORY_VERSION=102,
        CLASS_NAME=103, SCHEMA_NAME=104, CLASS_PROXY=105, TABLE_NAME=106, ROW_READER=107,
        EXTENDS=108, ACCEPT_LOCKS=109, INITIALIZATION_METHOD=110, FACTORY_CLASS=111,
        FACTORY_METHOD=112, REFRESH=113, ID=114, ACCESS=115, FIELD_NAME=116,
        COLUMN_NAME=117, JDBC_TYPE=118, PRIMARY_KEY=119, NULLABLE=120, INDEXED=121,
        AUTO_INCREMENT=122, SEQUENCE_NAME=123, LOCKING=124, UPDATE_LOCK=125,
        FIELD_CONVERSION=126, LENGTH=127, PRECISION=128, SCALE=129,
        REFERENCED_CLASS=130, PROXY_REFERENCE=131, AUTO_RETRIEVE=132, AUTO_UPDATE=133,
        AUTO_DELETE=134, OTM_DEPENDENT=135, FIELD_ID_REF=136, FIELD_REF=137,
        COLLECTION_CLASS=138, ITEMS_CLASS=139, SORT=140, INDIRECTION_TABLE=141,
        ATTRIBUTE_NAME=142, ATTRIBUTE_VALUE=143, NAME=144, UNIQUE=145,
        INCLUDE_ALL_FIELDS=146, RETURN_FIELD_REF=147, INCLUDE_PK_FIELDS_ONLY=148,
        VALUE=149, RETURN=150;

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void startElement(String uri, String name, String qName, Attributes atts)
    {
        boolean isDebug = logger.isDebugEnabled();

        m_CurrentString = null;
        try
        {
            switch (getLiteralId(qName))
            {
                case MAPPING_REPOSITORY:
                    {
                        if (isDebug) logger.debug(" > " + tags.getTagById(MAPPING_REPOSITORY));
                        this.m_CurrentAttrContainer = m_repository;

                        String defIso = atts.getValue(tags.getTagById(ISOLATION_LEVEL));
                        this.m_repository.setDefaultIsolationLevel(LockHelper.getIsolationLevelFor(defIso));
                        if (isDebug) logger.debug("     " + tags.getTagById(ISOLATION_LEVEL) + ": " + defIso);


                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit != null)
                        {
                            defProxyPrefetchingLimit = Integer.parseInt(proxyPrefetchingLimit);
                        }

                        
                        String version = atts.getValue(tags.getTagById(REPOSITORY_VERSION));
                        if (DescriptorRepository.getVersion().equals(version))
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(REPOSITORY_VERSION) + ": " + version);
                        }
                        else
                        {
                            throw new MetadataException("Repository version does not match. expected " +
                                    DescriptorRepository.getVersion() + " but found: " +
                                    version+". Please update your repository.dtd and your repository.xml"+
                                    " version attribute entry");
                        }
                        break;
                    }
                case CLASS_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("  > " + tags.getTagById(CLASS_DESCRIPTOR));
                        m_CurrentCLD = new ClassDescriptor(m_repository);

                        
                        this.m_CurrentAttrContainer = this.m_CurrentCLD;

                        
                        String isoLevel = atts.getValue(tags.getTagById(ISOLATION_LEVEL));
                        if (isDebug) logger.debug("     " + tags.getTagById(ISOLATION_LEVEL) + ": " + isoLevel);
                        




                        if(checkString(isoLevel)) m_CurrentCLD.setIsolationLevel(LockHelper.getIsolationLevelFor(isoLevel));

                        
                        String classname = atts.getValue(tags.getTagById(CLASS_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + classname);
                        try
                        {
                            m_CurrentCLD.setClassOfObject(ClassHelper.getClass(classname));
                        }
                        catch (ClassNotFoundException e)
                        {
                            m_CurrentCLD = null;
                            throw new MetadataException("Class "+classname+" could not be found"
                                    +" in the classpath. This could cause unexpected behaviour of OJB,"+
                                    " please remove or comment out this class descriptor" +
                                    " in the repository.xml file.", e);
                        }

                        
                        String schema = atts.getValue(tags.getTagById(SCHEMA_NAME));
                        if (schema != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(SCHEMA_NAME) + ": " + schema);
                            m_CurrentCLD.setSchema(schema);
                        }

                        
                        String proxy = atts.getValue(tags.getTagById(CLASS_PROXY));
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_PROXY) + ": " + proxy);
                        if (checkString(proxy))
                        {
                            if (proxy.equalsIgnoreCase(ClassDescriptor.DYNAMIC_STR))
                            {
                                m_CurrentCLD.setProxyClassName(ClassDescriptor.DYNAMIC_STR);
                            }
                            else
                            {
                                m_CurrentCLD.setProxyClassName(proxy);
                            }
                        }

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentCLD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentCLD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String table = atts.getValue(tags.getTagById(TABLE_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(TABLE_NAME) + ": " + table);
                        m_CurrentCLD.setTableName(table);
                        if (table == null)
                        {
                            m_CurrentCLD.setIsInterface(true);
                        }

                        
                        String rowreader = atts.getValue(tags.getTagById(ROW_READER));
                        if (isDebug) logger.debug("     " + tags.getTagById(ROW_READER) + ": " + rowreader);
                        if (rowreader != null)
                        {
                            m_CurrentCLD.setRowReader(rowreader);
                        }

                        

                        String extendsAtt = atts.getValue(tags.getTagById(EXTENDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(EXTENDS) + ": " + extendsAtt);
                        if (checkString(extendsAtt))
                        {
                            m_CurrentCLD.setSuperClass(extendsAtt);
                        }

                        
                        String acceptLocks = atts.getValue(tags.getTagById(ACCEPT_LOCKS));
                        if (acceptLocks==null)
                            acceptLocks="true"; 
                        logger.debug("     " + tags.getTagById(ACCEPT_LOCKS) + ": " + acceptLocks);
                        if (isDebug) logger.debug("     " + tags.getTagById(ACCEPT_LOCKS) + ": " + acceptLocks);
                        boolean b = (Boolean.valueOf(acceptLocks)).booleanValue();
                        m_CurrentCLD.setAcceptLocks(b);

                        
                        String initializationMethod = atts.getValue(tags.getTagById(INITIALIZATION_METHOD));
                        if (isDebug) logger.debug("     " + tags.getTagById(INITIALIZATION_METHOD) + ": " + initializationMethod);
                        if (initializationMethod != null)
                        {
                            m_CurrentCLD.setInitializationMethod(initializationMethod);
                        }

                        
                        String factoryClass = atts.getValue(tags.getTagById(FACTORY_CLASS));
                        if (isDebug)
                            logger.debug("     " + tags.getTagById(FACTORY_CLASS) + ": " + factoryClass);
                        if (factoryClass != null)
                        {
                            m_CurrentCLD.setFactoryClass(factoryClass);
                        }

                        
                        String factoryMethod = atts.getValue(tags.getTagById(FACTORY_METHOD));
                        if (isDebug)
                            logger.debug("     " + tags.getTagById(FACTORY_METHOD) + ": " + factoryMethod);
                        if (factoryMethod != null)
                        {
                            m_CurrentCLD.setFactoryMethod(factoryMethod);
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentCLD.setAlwaysRefresh(b);

                        
                        
						String pfClassName = atts.getValue("persistent-field-class");
						if (isDebug) logger.debug("     persistent-field-class: " + pfClassName);
						m_CurrentCLD.setPersistentFieldClassName(pfClassName);

                        
                        m_repository.put(classname, m_CurrentCLD);
                        break;
                    }
                case OBJECT_CACHE:
                    {
                        
                        
                        if(m_CurrentCLD != null)
                        {
                            String className = atts.getValue(tags.getTagById(CLASS_NAME));
                            if(checkString(className))
                            {
                                if (isDebug) logger.debug("     > " + tags.getTagById(OBJECT_CACHE));
                                ObjectCacheDescriptor ocd = new ObjectCacheDescriptor();
                                this.m_CurrentAttrContainer = ocd;
                                ocd.setObjectCache(ClassHelper.getClass(className));
                                if(m_CurrentCLD != null)
                                {
                                    m_CurrentCLD.setObjectCacheDescriptor(ocd);
                                }
                                if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + className);
                            }
                        }
                        break;
                    }
                case CLASS_EXTENT:
                    {
                        String classname = atts.getValue("class-ref");
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_EXTENT) + ": " + classname);
                        m_CurrentCLD.addExtentClass(classname);
                        break;
                    }

                case FIELD_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FIELD_DESCRIPTOR));

                        String strId = atts.getValue(tags.getTagById(ID));
                        m_lastId = (strId == null ? m_lastId + 1 : Integer.parseInt(strId));

                        String strAccess = atts.getValue(tags.getTagById(ACCESS));

                        if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                        {
                            m_CurrentFLD = new AnonymousFieldDescriptor(m_CurrentCLD, m_lastId);
                        }
                        else
                        {
                            m_CurrentFLD = new FieldDescriptor(m_CurrentCLD, m_lastId);
                        }
                        m_CurrentFLD.setAccess(strAccess);
                        m_CurrentCLD.addFieldDescriptor(m_CurrentFLD);

                        
                        this.m_CurrentAttrContainer = this.m_CurrentFLD;

                        String fieldName = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + fieldName);

                        if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                        {
							AnonymousFieldDescriptor anonymous = (AnonymousFieldDescriptor) m_CurrentFLD;
                            anonymous.setPersistentField(null,fieldName);
                        }
                        else
                        {
                            String classname = m_CurrentCLD.getClassNameOfObject();
							PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),ClassHelper.getClass(classname),fieldName);
                            m_CurrentFLD.setPersistentField(pf);
                        }

                        String columnName = atts.getValue(tags.getTagById(COLUMN_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(COLUMN_NAME) + ": " + columnName);
                        m_CurrentFLD.setColumnName(columnName);

                        String jdbcType = atts.getValue(tags.getTagById(JDBC_TYPE));
                        if (isDebug) logger.debug("     " + tags.getTagById(JDBC_TYPE) + ": " + jdbcType);
                        m_CurrentFLD.setColumnType(jdbcType);

                        String primaryKey = atts.getValue(tags.getTagById(PRIMARY_KEY));
                        if (isDebug) logger.debug("     " + tags.getTagById(PRIMARY_KEY) + ": " + primaryKey);
                        boolean b = (Boolean.valueOf(primaryKey)).booleanValue();
                        m_CurrentFLD.setPrimaryKey(b);

                        String nullable = atts.getValue(tags.getTagById(NULLABLE));
                        if (nullable != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(NULLABLE) + ": " + nullable);
                            b = !(Boolean.valueOf(nullable)).booleanValue();
                            m_CurrentFLD.setRequired(b);
                        }

                        String indexed = atts.getValue(tags.getTagById(INDEXED));
                        if (isDebug) logger.debug("     " + tags.getTagById(INDEXED) + ": " + indexed);
                        b = (Boolean.valueOf(indexed)).booleanValue();
                        m_CurrentFLD.setIndexed(b);

                        String autoincrement = atts.getValue(tags.getTagById(AUTO_INCREMENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_INCREMENT) + ": " + autoincrement);
                        b = (Boolean.valueOf(autoincrement)).booleanValue();
                        m_CurrentFLD.setAutoIncrement(b);

                        String sequenceName = atts.getValue(tags.getTagById(SEQUENCE_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(SEQUENCE_NAME) + ": " + sequenceName);
                        m_CurrentFLD.setSequenceName(sequenceName);

                        String locking = atts.getValue(tags.getTagById(LOCKING));
                        if (isDebug) logger.debug("     " + tags.getTagById(LOCKING) + ": " + locking);
                        b = (Boolean.valueOf(locking)).booleanValue();
                        m_CurrentFLD.setLocking(b);

                        String updateLock = atts.getValue(tags.getTagById(UPDATE_LOCK));
                        if (isDebug) logger.debug("     " + tags.getTagById(UPDATE_LOCK) + ": " + updateLock);
                        if(checkString(updateLock))
                        {
                            b = (Boolean.valueOf(updateLock)).booleanValue();
                            m_CurrentFLD.setUpdateLock(b);
                        }

                        String fieldConversion = atts.getValue(tags.getTagById(FIELD_CONVERSION));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_CONVERSION) + ": " + fieldConversion);
                        if (fieldConversion != null)
                        {
                            m_CurrentFLD.setFieldConversionClassName(fieldConversion);
                        }

                        
                        String length = atts.getValue(tags.getTagById(LENGTH));
                        if (length != null)
                        {
                            int i = Integer.parseInt(length);
                            if (isDebug) logger.debug("     " + tags.getTagById(LENGTH) + ": " + i);
                            m_CurrentFLD.setLength(i);
                            m_CurrentFLD.setLengthSpecified(true);
                        }

                        
                        String precision = atts.getValue(tags.getTagById(PRECISION));
                        if (precision != null)
                        {
                            int i = Integer.parseInt(precision);
                            if (isDebug) logger.debug("     " + tags.getTagById(PRECISION) + ": " + i);
                            m_CurrentFLD.setPrecision(i);
                            m_CurrentFLD.setPrecisionSpecified(true);
                        }

                        
                        String scale = atts.getValue(tags.getTagById(SCALE));
                        if (scale != null)
                        {
                            int i = Integer.parseInt(scale);
                            if (isDebug) logger.debug("     " + tags.getTagById(SCALE) + ": " + i);
                            m_CurrentFLD.setScale(i);
                            m_CurrentFLD.setScaleSpecified(true);
                        }

                        break;
                    }

                case REFERENCE_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(REFERENCE_DESCRIPTOR));
                        
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);

                        
                        String classRef = atts.getValue(tags.getTagById(REFERENCED_CLASS));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFERENCED_CLASS) + ": " + classRef);

                        ObjectReferenceDescriptor ord;
                        if (name.equals(TAG_SUPER))
                        {
                            






                            ord = new SuperReferenceDescriptor(m_CurrentCLD);
                        }
                        else
                        {
                            ord = new ObjectReferenceDescriptor(m_CurrentCLD);
                            PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                            ord.setPersistentField(pf);
                        }
                        m_CurrentORD = ord;

                        
                        m_CurrentCLD.addObjectReferenceDescriptor(m_CurrentORD);
                        m_CurrentORD.setItemClass(ClassHelper.getClass(classRef));

                        
                        this.m_CurrentAttrContainer = m_CurrentORD;

                        
                        String proxy = atts.getValue(tags.getTagById(PROXY_REFERENCE));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_REFERENCE) + ": " + proxy);
                        boolean b = (Boolean.valueOf(proxy)).booleanValue();
                        m_CurrentORD.setLazy(b);

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentORD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentORD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentORD.setRefresh(b);

                        
                        String autoRetrieve = atts.getValue(tags.getTagById(AUTO_RETRIEVE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_RETRIEVE) + ": " + autoRetrieve);
                        b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                        m_CurrentORD.setCascadeRetrieve(b);

                        
                        String autoUpdate = atts.getValue(tags.getTagById(AUTO_UPDATE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_UPDATE) + ": " + autoUpdate);
                        if(autoUpdate != null)
                        {
                            m_CurrentORD.setCascadingStore(autoUpdate);
                        }

                        
                        String autoDelete = atts.getValue(tags.getTagById(AUTO_DELETE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_DELETE) + ": " + autoDelete);

                        if(autoDelete != null)
                        {
                            m_CurrentORD.setCascadingDelete(autoDelete);
                        }

                        
                        String otmDependent = atts.getValue(tags.getTagById(OTM_DEPENDENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(OTM_DEPENDENT) + ": " + otmDependent);
                        b = (Boolean.valueOf(otmDependent)).booleanValue();
                        m_CurrentORD.setOtmDependent(b);

                        break;
                    }

                case FOREIGN_KEY:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FOREIGN_KEY));
                        String fieldIdRef = atts.getValue(tags.getTagById(FIELD_ID_REF));

                        if (fieldIdRef != null)
                        {
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_ID_REF) + ": " + fieldIdRef);

                            try
                            {
                                int fieldId;
                                fieldId = Integer.parseInt(fieldIdRef);
                                m_CurrentORD.addForeignKeyField(fieldId);
                            }
                            catch (NumberFormatException rex)
                            {
                                throw new MetadataException(tags.getTagById(FIELD_ID_REF)
                                        + " attribute must be an int. Found: "
                                        + fieldIdRef + ". Please check your repository file.", rex);
                            }
                        }
                        else
                        {
                            String fieldRef = atts.getValue(tags.getTagById(FIELD_REF));
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_REF) + ": " + fieldRef);
                            m_CurrentORD.addForeignKeyField(fieldRef);
                        }
                        break;
                    }

                case COLLECTION_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(COLLECTION_DESCRIPTOR));
                        m_CurrentCOD = new CollectionDescriptor(m_CurrentCLD);


                        
                        this.m_CurrentAttrContainer = m_CurrentCOD;

                        
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);
						PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                        m_CurrentCOD.setPersistentField(pf);

                        
                        String collectionClassName = atts.getValue(tags.getTagById(COLLECTION_CLASS));
                        if (collectionClassName != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(COLLECTION_CLASS) + ": " + collectionClassName);
                            m_CurrentCOD.setCollectionClass(ClassHelper.getClass(collectionClassName));
                        }
                        
                        String elementClassRef = atts.getValue(tags.getTagById(ITEMS_CLASS));
                        if (isDebug) logger.debug("     " + tags.getTagById(ITEMS_CLASS) + ": " + elementClassRef);
                        if (elementClassRef != null)
                        {
                            m_CurrentCOD.setItemClass(ClassHelper.getClass(elementClassRef));
                        }

                        
                        String orderby = atts.getValue(tags.getTagById(ORDERBY));
                        String sort = atts.getValue(tags.getTagById(SORT));
                        if (isDebug) logger.debug("     " + tags.getTagById(SORT) + ": " + orderby + ", " + sort);
                        if (orderby != null)
                        {
                            m_CurrentCOD.addOrderBy(orderby, "ASC".equalsIgnoreCase(sort));
                        }

                        
                        String indirectionTable = atts.getValue(tags.getTagById(INDIRECTION_TABLE));
                        if (isDebug) logger.debug("     " + tags.getTagById(INDIRECTION_TABLE) + ": " + indirectionTable);
                        m_CurrentCOD.setIndirectionTable(indirectionTable);

                        
                        String proxy = atts.getValue(tags.getTagById(PROXY_REFERENCE));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_REFERENCE) + ": " + proxy);
                        boolean b = (Boolean.valueOf(proxy)).booleanValue();
                        m_CurrentCOD.setLazy(b);

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentCOD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentCOD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentCOD.setRefresh(b);

                        
                        String autoRetrieve = atts.getValue(tags.getTagById(AUTO_RETRIEVE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_RETRIEVE) + ": " + autoRetrieve);
                        b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                        m_CurrentCOD.setCascadeRetrieve(b);

                        
                        String autoUpdate = atts.getValue(tags.getTagById(AUTO_UPDATE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_UPDATE) + ": " + autoUpdate);
                        if(autoUpdate != null)
                        {
                            m_CurrentCOD.setCascadingStore(autoUpdate);
                        }

                        
                        String autoDelete = atts.getValue(tags.getTagById(AUTO_DELETE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_DELETE) + ": " + autoDelete);
                        if(autoDelete != null)
                        {
                            m_CurrentCOD.setCascadingDelete(autoDelete);
                        }

                        
                        String otmDependent = atts.getValue(tags.getTagById(OTM_DEPENDENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(OTM_DEPENDENT) + ": " + otmDependent);
                        b = (Boolean.valueOf(otmDependent)).booleanValue();
                        m_CurrentCOD.setOtmDependent(b);

                        m_CurrentCLD.addCollectionDescriptor(m_CurrentCOD);

                        break;
                    }
                case ORDERBY :
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(ORDERBY));
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);
                        String sort = atts.getValue(tags.getTagById(SORT));
                        if (isDebug) logger.debug("     " + tags.getTagById(SORT) + ": " + name + ", " + sort);

                        m_CurrentCOD.addOrderBy(name, "ASC".equalsIgnoreCase(sort));
                        break;
                    }
                case INVERSE_FK:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(INVERSE_FK));
                        String fieldIdRef = atts.getValue(tags.getTagById(FIELD_ID_REF));

                        if (fieldIdRef != null)
                        {
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_ID_REF) + ": " + fieldIdRef);

                            try
                            {
                                int fieldId;
                                fieldId = Integer.parseInt(fieldIdRef);
                                m_CurrentCOD.addForeignKeyField(fieldId);
                            }
                            catch (NumberFormatException rex)
                            {
                                throw new MetadataException(tags.getTagById(FIELD_ID_REF)
                                        + " attribute must be an int. Found: "
                                        + fieldIdRef + " Please check your repository file.", rex);
                            }
                        }
                        else
                        {
                            String fieldRef = atts.getValue(tags.getTagById(FIELD_REF));
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_REF) + ": " + fieldRef);
                            m_CurrentCOD.addForeignKeyField(fieldRef);
                        }
                        break;
                    }

                case FK_POINTING_TO_THIS_CLASS:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FK_POINTING_TO_THIS_CLASS));
                        String column = atts.getValue("column");
                        if (isDebug) logger.debug("      " + "column" + ": " + column);
                        m_CurrentCOD.addFkToThisClass(column);
                        break;
                    }

                case FK_POINTING_TO_ITEMS_CLASS:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FK_POINTING_TO_ITEMS_CLASS));
                        String column = atts.getValue("column");
                        if (isDebug) logger.debug("      " + "column" + ": " + column);
                        m_CurrentCOD.addFkToItemClass(column);
                        break;
                    }
                case ATTRIBUTE:
                    {
                        
                        String attributeName = atts.getValue(tags.getTagById(ATTRIBUTE_NAME));
                        String attributeValue = atts.getValue(tags.getTagById(ATTRIBUTE_VALUE));
                        
                        if (this.m_CurrentAttrContainer != null)
                        {
                            if (isDebug) logger.debug("      > " + tags.getTagById(ATTRIBUTE));
                            if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_NAME) + ": " + attributeName);
                            if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_VALUE) + ": " + attributeValue);
                            this.m_CurrentAttrContainer.addAttribute(attributeName, attributeValue);
                        }
                        else
                        {


                        }
                        break;
                    }









                    case QUERY_CUSTOMIZER:
                        {
                            
                            String className = atts.getValue("class");
                            QueryCustomizer queryCust;

                            if (className != null)
                            {
                                if (isDebug) logger.debug("     " + "class" + ": " + className);
                                queryCust = (QueryCustomizer)ClassHelper.newInstance(className);
                                m_CurrentAttrContainer = queryCust;
                                m_CurrentCOD.setQueryCustomizer(queryCust);
                            }
                            break;
                        }
                    case INDEX_DESCRIPTOR:
                        {
                            m_CurrentIndexDescriptor = new IndexDescriptor();
                            m_CurrentIndexDescriptor.setName(atts.getValue(tags.getTagById(NAME)));
                            m_CurrentIndexDescriptor.setUnique(Boolean.valueOf(atts.getValue(tags.getTagById(UNIQUE))).booleanValue());
                            break;
                        }
                    case INDEX_COLUMN:
                        {
                            m_CurrentIndexDescriptor.getIndexColumns().add(atts.getValue(tags.getTagById(NAME)));
                            break;
                        }
                    case INSERT_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(INSERT_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllFields = atts.getValue(tags.getTagById(INCLUDE_ALL_FIELDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_ALL_FIELDS) +
                                                  ": " + includeAllFields);

                        
                        InsertProcedureDescriptor proc =
                            new InsertProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;
                    }
                case UPDATE_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(UPDATE_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllFields = atts.getValue(tags.getTagById(INCLUDE_ALL_FIELDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_ALL_FIELDS) +
                                                  ": " + includeAllFields);

                        
                        UpdateProcedureDescriptor proc =
                            new UpdateProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;
                    }
                case DELETE_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(DELETE_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllPkFields = atts.getValue(tags.getTagById(INCLUDE_PK_FIELDS_ONLY));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_PK_FIELDS_ONLY) +
                                                  ": " + includeAllPkFields);

                        
                        DeleteProcedureDescriptor proc =
                            new DeleteProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllPkFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;

                    }
                case CONSTANT_ARGUMENT:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(CONSTANT_ARGUMENT));
                        ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                        
                        String value = atts.getValue(tags.getTagById(VALUE));
                        if (isDebug) logger.debug("     " + tags.getTagById(VALUE) + ": " + value);

                        
                        arg.setValue(value);

                        
                        m_CurrentProcedure.addArgument(arg);
                        break;
                    }
                case RUNTIME_ARGUMENT:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(RUNTIME_ARGUMENT));
                        ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                        
                        String fieldRefName = atts.getValue(tags.getTagById(FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_REF) +
                                                  ": " + fieldRefName);

                        
                        String returnValue = atts.getValue(tags.getTagById(RETURN));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN) +
                                                  ": " + returnValue);

                        
                        if ((fieldRefName != null) && (fieldRefName.trim().length() != 0)) {
                            arg.setValue(fieldRefName,
                                         Boolean.valueOf(returnValue).booleanValue());
                        }

                        
                        m_CurrentProcedure.addArgument(arg);
                        break;
                    }

                default :
                    {
                        
                    }
            }
        }
        catch (Exception ex)
        {
            logger.error("Exception while read metadata", ex);
            if(ex instanceof MetadataException) throw (MetadataException)ex;
            else throw new MetadataException("Exception when reading metadata information,"+
                    " please check your repository.xml file", ex);
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== OJB RepositoryXmlHandler Reconstruction Test ===");
        method_1_ojb_QWEN handler = new method_1_ojb_QWEN(new DescriptorRepository());
        
        MockAttributes atts = new MockAttributes();
        atts.put("version", "1.0");
        atts.put("isolation-level", "read-committed");
        
        try {
            System.out.println("Invoking startElement for MAPPING_REPOSITORY...");
            handler.startElement("", "mapping-repository", "mapping-repository", atts);
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    static Logger logger = new Logger();
    DescriptorRepository m_repository;
    ClassDescriptor m_CurrentCLD;
    ProcedureDescriptor m_CurrentProcedure;
    FieldDescriptor m_CurrentFLD;
    ObjectReferenceDescriptor m_CurrentORD;
    CollectionDescriptor m_CurrentCOD;
    IndexDescriptor m_CurrentIndexDescriptor;
    String m_CurrentString;
    AttributeContainer m_CurrentAttrContainer;
    int defProxyPrefetchingLimit = 50;
    int m_lastId;
    RepositoryTags tags = RepositoryTags.getInstance();

    public method_1_ojb_QWEN(DescriptorRepository dr) { this.m_repository = dr; }

    private int getLiteralId(String literal) throws MetadataException {
        return tags.getIdByTag(literal);
    }

    private boolean checkString(String str) {
        return (str != null && !str.trim().equals(""));
    }

    static class Logger {
        public boolean isDebugEnabled() { return false; }
        public void debug(String msg) {}
        public void debug(String msg, Throwable t) {}
        public void error(String msg, Throwable t) {}
    }

    static class RepositoryTags {
        private static RepositoryTags instance = new RepositoryTags();
        public static RepositoryTags getInstance() { return instance; }
        public String getTagById(int id) {
            switch (id) {
                case ISOLATION_LEVEL: return "isolation-level";
                case PROXY_PREFETCHING_LIMIT: return "proxy-prefetching-limit";
                case REPOSITORY_VERSION: return "version";
                case CLASS_NAME: return "class";
                case SCHEMA_NAME: return "schema";
                case CLASS_PROXY: return "proxy";
                case TABLE_NAME: return "table";
                case ROW_READER: return "row-reader";
                case EXTENDS: return "extends";
                case ACCEPT_LOCKS: return "accept-locks";
                case INITIALIZATION_METHOD: return "initialization-method";
                case FACTORY_CLASS: return "factory-class";
                case FACTORY_METHOD: return "factory-method";
                case REFRESH: return "refresh";
                default: return "tag" + id;
            }
        }
        public int getIdByTag(String tag) { 
            if (tag.equals("mapping-repository")) return method_1_ojb_QWEN.MAPPING_REPOSITORY;
            if (tag.equals("class-descriptor")) return method_1_ojb_QWEN.CLASS_DESCRIPTOR;
            if (tag.equals("object-cache")) return method_1_ojb_QWEN.OBJECT_CACHE;
            if (tag.equals("class-extent")) return method_1_ojb_QWEN.CLASS_EXTENT;
            if (tag.equals("field-descriptor")) return method_1_ojb_QWEN.FIELD_DESCRIPTOR;
            if (tag.equals("reference-descriptor")) return method_1_ojb_QWEN.REFERENCE_DESCRIPTOR;
            if (tag.equals("foreign-key")) return method_1_ojb_QWEN.FOREIGN_KEY;
            if (tag.equals("collection-descriptor")) return method_1_ojb_QWEN.COLLECTION_DESCRIPTOR;
            if (tag.equals("orderby")) return method_1_ojb_QWEN.ORDERBY;
            if (tag.equals("inverse-fk")) return method_1_ojb_QWEN.INVERSE_FK;
            if (tag.equals("fk-pointing-to-this-class")) return method_1_ojb_QWEN.FK_POINTING_TO_THIS_CLASS;
            if (tag.equals("fk-pointing-to-items-class")) return method_1_ojb_QWEN.FK_POINTING_TO_ITEMS_CLASS;
            if (tag.equals("attribute")) return method_1_ojb_QWEN.ATTRIBUTE;
            if (tag.equals("query-customizer")) return method_1_ojb_QWEN.QUERY_CUSTOMIZER;
            if (tag.equals("index-descriptor")) return method_1_ojb_QWEN.INDEX_DESCRIPTOR;
            if (tag.equals("index-column")) return method_1_ojb_QWEN.INDEX_COLUMN;
            if (tag.equals("insert-procedure")) return method_1_ojb_QWEN.INSERT_PROCEDURE;
            if (tag.equals("update-procedure")) return method_1_ojb_QWEN.UPDATE_PROCEDURE;
            if (tag.equals("delete-procedure")) return method_1_ojb_QWEN.DELETE_PROCEDURE;
            if (tag.equals("constant-argument")) return method_1_ojb_QWEN.CONSTANT_ARGUMENT;
            if (tag.equals("runtime-argument")) return method_1_ojb_QWEN.RUNTIME_ARGUMENT;
            throw new RuntimeException("Unknown tag: " + tag);
        }
    }

    static class MetadataException extends RuntimeException {
        public MetadataException(String msg) { super(msg); }
        public MetadataException(String msg, Throwable t) { super(msg, t); }
    }

    static class LockHelper {
        public static int getIsolationLevelFor(String level) { return 2; }
    }

    static class ClassHelper {
        public static Class<?> getClass(String name) throws ClassNotFoundException { return Object.class; }
        public static Object newInstance(String name) { return new BasicQueryCustomizer(); }
    }

    static class PersistentField {}
    static class PersistentFieldFactory {
        public static PersistentField createPersistentField(String pfClass, Class<?> clazz, String fieldName) { return new PersistentField(); }
    }

    static interface AttributeContainer {
        void addAttribute(String name, String value);
    }

    static class DescriptorRepository implements AttributeContainer {
        public static String getVersion() { return "1.0"; }
        public void setDefaultIsolationLevel(int level) {}
        public void put(String name, ClassDescriptor cld) {}
        public void addAttribute(String name, String value) {}
    }

    static class ClassDescriptor implements AttributeContainer {
        public static final String DYNAMIC_STR = "dynamic";
        public ClassDescriptor(DescriptorRepository repo) {}
        public void setIsolationLevel(int level) {}
        public void setClassOfObject(Class<?> clazz) {}
        public void setSchema(String schema) {}
        public void setProxyClassName(String proxy) {}
        public void setProxyPrefetchingLimit(int limit) {}
        public void setTableName(String table) {}
        public void setIsInterface(boolean isInterface) {}
        public void setRowReader(String reader) {}
        public void setSuperClass(String superClass) {}
        public void setAcceptLocks(boolean accept) {}
        public void setInitializationMethod(String method) {}
        public void setFactoryClass(String factoryClass) {}
        public void setFactoryMethod(String factoryMethod) {}
        public void setAlwaysRefresh(boolean refresh) {}
        public void setPersistentFieldClassName(String className) {}
        public String getClassNameOfObject() { return "TestClass"; }
        public String getPersistentFieldClassName() { return null; }
        public Class<?> getClassOfObject() { return Object.class; }
        public void addFieldDescriptor(FieldDescriptor fd) {}
        public void addObjectReferenceDescriptor(ObjectReferenceDescriptor ord) {}
        public void addCollectionDescriptor(CollectionDescriptor cd) {}
        public void addExtentClass(String className) {}
        public void setObjectCacheDescriptor(ObjectCacheDescriptor ocd) {}
        public void addAttribute(String name, String value) {}
    }

    static class FieldDescriptor implements AttributeContainer {
        public FieldDescriptor(ClassDescriptor cld, int id) {}
        public void setAccess(String access) {}
        public void setPersistentField(PersistentField pf) {}
        public void setColumnName(String name) {}
        public void setColumnType(String type) {}
        public void setPrimaryKey(boolean pk) {}
        public void setRequired(boolean required) {}
        public void setIndexed(boolean indexed) {}
        public void setAutoIncrement(boolean auto) {}
        public void setSequenceName(String name) {}
        public void setLocking(boolean locking) {}
        public void setUpdateLock(boolean update) {}
        public void setFieldConversionClassName(String className) {}
        public void setLength(int length) {}
        public void setLengthSpecified(boolean specified) {}
        public void setPrecision(int precision) {}
        public void setPrecisionSpecified(boolean specified) {}
        public void setScale(int scale) {}
        public void setScaleSpecified(boolean specified) {}
        public void addAttribute(String name, String value) {}
    }

    static class AnonymousFieldDescriptor extends FieldDescriptor {
        public AnonymousFieldDescriptor(ClassDescriptor cld, int id) { super(cld, id); }
        public void setPersistentField(Object obj, String fieldName) {}
    }

    static class ObjectReferenceDescriptor implements AttributeContainer {
        public ObjectReferenceDescriptor(ClassDescriptor cld) {}
        public void setPersistentField(PersistentField pf) {}
        public void setItemClass(Class<?> clazz) {}
        public void setLazy(boolean lazy) {}
        public void setProxyPrefetchingLimit(int limit) {}
        public void setRefresh(boolean refresh) {}
        public void setCascadeRetrieve(boolean retrieve) {}
        public void setCascadingStore(String store) {}
        public void setCascadingDelete(String delete) {}
        public void setOtmDependent(boolean dependent) {}
        public void addForeignKeyField(int fieldId) {}
        public void addForeignKeyField(String fieldRef) {}
        public void addAttribute(String name, String value) {}
    }

    static class SuperReferenceDescriptor extends ObjectReferenceDescriptor {
        public SuperReferenceDescriptor(ClassDescriptor cld) { super(cld); }
    }

    static class CollectionDescriptor implements AttributeContainer {
        public CollectionDescriptor(ClassDescriptor cld) {}
        public void setPersistentField(PersistentField pf) {}
        public void setCollectionClass(Class<?> clazz) {}
        public void setItemClass(Class<?> clazz) {}
        public void addOrderBy(String orderby, boolean asc) {}
        public void setIndirectionTable(String table) {}
        public void setLazy(boolean lazy) {}
        public void setProxyPrefetchingLimit(int limit) {}
        public void setRefresh(boolean refresh) {}
        public void setCascadeRetrieve(boolean retrieve) {}
        public void setCascadingStore(String store) {}
        public void setCascadingDelete(String delete) {}
        public void setOtmDependent(boolean dependent) {}
        public void addForeignKeyField(int fieldId) {}
        public void addForeignKeyField(String fieldRef) {}
        public void addFkToThisClass(String column) {}
        public void addFkToItemClass(String column) {}
        public void setQueryCustomizer(QueryCustomizer qc) {}
        public void addAttribute(String name, String value) {}
    }

    static class IndexDescriptor {
        public void setName(String name) {}
        public void setUnique(boolean unique) {}
        public List<String> getIndexColumns() { return new ArrayList<>(); }
    }

    static class ProcedureDescriptor {
        public void setReturnValueFieldRef(String ref) {}
        public void addArgument(ArgumentDescriptor arg) {}
    }
    static class InsertProcedureDescriptor extends ProcedureDescriptor {
        public InsertProcedureDescriptor(ClassDescriptor cld, String name, boolean include) {}
    }
    static class UpdateProcedureDescriptor extends ProcedureDescriptor {
        public UpdateProcedureDescriptor(ClassDescriptor cld, String name, boolean include) {}
    }
    static class DeleteProcedureDescriptor extends ProcedureDescriptor {
        public DeleteProcedureDescriptor(ClassDescriptor cld, String name, boolean include) {}
    }

    static class ArgumentDescriptor {
        public ArgumentDescriptor(ProcedureDescriptor proc) {}
        public void setValue(String value) {}
        public void setValue(String fieldRef, boolean isReturn) {}
    }

    static interface QueryCustomizer extends AttributeContainer {}
    static class BasicQueryCustomizer implements QueryCustomizer {
        public void addAttribute(String name, String value) {}
    }
    static class ObjectCacheDescriptor implements AttributeContainer {
        public void setObjectCache(Class<?> clazz) {}
        public void addAttribute(String name, String value) {}
    }

    static class MockAttributes implements Attributes {
        private java.util.Map<String, String> map = new java.util.HashMap<>();
        public void put(String key, String value) { map.put(key, value); }
        public String getValue(String qName) { return map.get(qName); }
        public int getLength() { return 0; }
        public String getURI(int index) { return ""; }
        public String getLocalName(int index) { return ""; }
        public String getQName(int index) { return ""; }
        public String getType(int index) { return ""; }
        public String getType(String uri, String localName) { return ""; }
        public String getValue(int index) { return ""; }
        public String getValue(String uri, String localName) { return ""; }
        public int getIndex(String uri, String localName) { return -1; }
        public int getIndex(String qName) { return -1; }
        public String getType(String qName) { return ""; }
    }

    interface RepositoryElements {
        int MAPPING_REPOSITORY = 1, CLASS_DESCRIPTOR = 2, OBJECT_CACHE = 3, CLASS_EXTENT = 4,
        FIELD_DESCRIPTOR = 5, REFERENCE_DESCRIPTOR = 6, FOREIGN_KEY = 7, COLLECTION_DESCRIPTOR = 8,
        ORDERBY = 9, INVERSE_FK = 10, FK_POINTING_TO_THIS_CLASS = 11, FK_POINTING_TO_ITEMS_CLASS = 12,
        ATTRIBUTE = 13, QUERY_CUSTOMIZER = 14, INDEX_DESCRIPTOR = 15, INDEX_COLUMN = 16,
        INSERT_PROCEDURE = 17, UPDATE_PROCEDURE = 18, DELETE_PROCEDURE = 19, CONSTANT_ARGUMENT = 20, RUNTIME_ARGUMENT = 21;
        String TAG_ACCESS_ANONYMOUS = "anonymous", TAG_SUPER = "super";
        int ISOLATION_LEVEL = 100, PROXY_PREFETCHING_LIMIT = 101, REPOSITORY_VERSION = 102, CLASS_NAME = 103,
        SCHEMA_NAME = 104, CLASS_PROXY = 105, TABLE_NAME = 106, ROW_READER = 107, EXTENDS = 108, ACCEPT_LOCKS = 109,
        INITIALIZATION_METHOD = 110, FACTORY_CLASS = 111, FACTORY_METHOD = 112, REFRESH = 113, ID = 114, ACCESS = 115,
        FIELD_NAME = 116, COLUMN_NAME = 117, JDBC_TYPE = 118, PRIMARY_KEY = 119, NULLABLE = 120, INDEXED = 121,
        AUTO_INCREMENT = 122, SEQUENCE_NAME = 123, LOCKING = 124, UPDATE_LOCK = 125, FIELD_CONVERSION = 126,
        LENGTH = 127, PRECISION = 128, SCALE = 129, REFERENCED_CLASS = 130, PROXY_REFERENCE = 131, AUTO_RETRIEVE = 132,
        AUTO_UPDATE = 133, AUTO_DELETE = 134, OTM_DEPENDENT = 135, FIELD_ID_REF = 136, FIELD_REF = 137,
        COLLECTION_CLASS = 138, ITEMS_CLASS = 139, SORT = 140, INDIRECTION_TABLE = 141, ATTRIBUTE_NAME = 142,
        ATTRIBUTE_VALUE = 143, NAME = 144, UNIQUE = 145, INCLUDE_ALL_FIELDS = 146, RETURN_FIELD_REF = 147,
        INCLUDE_PK_FIELDS_ONLY = 148, VALUE = 149, RETURN = 150;
    }
    interface IsolationLevels {}
}