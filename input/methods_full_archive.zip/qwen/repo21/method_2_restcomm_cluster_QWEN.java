import java.util.concurrent.*;




enum PeriodicScheduleStrategy {
    withFixedDelay, atFixedRate
}

class TimerTaskData {
    private final String taskID;
    private final long startTime;
    private final long period;
    private final PeriodicScheduleStrategy periodicScheduleStrategy;

    public TimerTaskData(String taskID, long startTime, long period, PeriodicScheduleStrategy periodicScheduleStrategy) {
        this.taskID = taskID;
        this.startTime = startTime;
        this.period = period;
        this.periodicScheduleStrategy = periodicScheduleStrategy;
    }
    public String getTaskID() { return taskID; }
    public long getStartTime() { return startTime; }
    public long getPeriod() { return period; }
    public PeriodicScheduleStrategy getPeriodicScheduleStrategy() { return periodicScheduleStrategy; }
}


class TimerTask implements Runnable {
    private final TimerTaskData data;
    private ScheduledFuture<?> scheduledFuture;
    private Runnable setTimerTransactionalAction;

    public TimerTask(TimerTaskData data) { this.data = data; }
    public TimerTaskData getData() { return data; }
    public void setScheduledFuture(ScheduledFuture<?> scheduledFuture) { this.scheduledFuture = scheduledFuture; }
    public Runnable getSetTimerTransactionalAction() { return setTimerTransactionalAction; }
    public void setSetTimerTransactionalAction(Runnable action) { this.setTimerTransactionalAction = action; }
    
    public void run() {
        System.out.println("  -> Executing timer task: " + data.getTaskID());
    }
}

class Scheduler {
    private final ScheduledExecutorService executor = Executors.newScheduledThreadPool(2);
    private final ConcurrentHashMap<String, TimerTask> localRunningTasksMap = new ConcurrentHashMap<>();

    public ScheduledExecutorService getExecutor() { return executor; }
    public ConcurrentHashMap<String, TimerTask> getLocalRunningTasksMap() { return localRunningTasksMap; }
    public void remove(String taskID, boolean force) { 
        localRunningTasksMap.remove(taskID);
        System.out.println("  -> Removed task " + taskID + " from scheduler");
    }
}




public class method_2_restcomm_cluster_QWEN {
    private static class Logger {
        public boolean isDebugEnabled() { return true; }
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void error(String msg, Throwable e) { System.err.println("[ERROR] " + msg + " - " + e.getMessage()); }
    }
    private static final Logger logger = new Logger();

    private final TimerTask task;
    private final Scheduler scheduler;
    private boolean canceled = false;

    public method_2_restcomm_cluster_QWEN(TimerTask task, Scheduler scheduler) {
        this.task = task;
        this.scheduler = scheduler;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public void run() {
		
		task.setSetTimerTransactionalAction(null);
		
		if (!canceled) {
			
			TimerTask previousTask = scheduler.getLocalRunningTasksMap().putIfAbsent(task.getData().getTaskID(), task);
			if(previousTask != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("A task with id " + task.getData().getTaskID() + " has already been added to the local tasks, not rescheduling");
				}
			}
			
			final TimerTaskData taskData = task.getData();
			
			long delay = taskData.getStartTime() - System.currentTimeMillis();
			if (delay < 0) {
				delay = 0;
			}
			
			try {
				
				if (taskData.getPeriod() < 0) {
					if (logger.isDebugEnabled()) {
						logger.debug("Scheduling one-shot timer with id "
								+ task.getData().getTaskID() + ", delay " + delay);
					}
					task.setScheduledFuture(scheduler.getExecutor().schedule(task, delay, TimeUnit.MILLISECONDS));
				} else {
					if (logger.isDebugEnabled()) {
						logger.debug("Scheduling periodic timer with id "
								+ task.getData().getTaskID() + ", scheduling strategy " + taskData.getPeriodicScheduleStrategy() + ", delay " + delay + ", period " + taskData.getPeriod());
					}
					if (taskData.getPeriodicScheduleStrategy() == PeriodicScheduleStrategy.withFixedDelay) {
						task.setScheduledFuture(scheduler.getExecutor().scheduleWithFixedDelay(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
					}
					else {
						
						task.setScheduledFuture(scheduler.getExecutor().scheduleAtFixedRate(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
					}					
				}		
			} catch (Throwable e) {
				logger.error(e.getMessage(), e);
				scheduler.remove(taskData.getTaskID(),true);
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("Canceled scheduling periodic timer with id "
						+ task.getData().getTaskID());
			}
		}
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) throws InterruptedException {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 2: SetTimerAfterTxCommitRunnable.run                 ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        Scheduler scheduler = new Scheduler();
        long startTime = System.currentTimeMillis() + 100; 
        
        TimerTaskData data = new TimerTaskData("TASK-001", startTime, 500, PeriodicScheduleStrategy.withFixedDelay);
        TimerTask task = new TimerTask(data);
        
        method_2_restcomm_cluster_QWEN runnable = new method_2_restcomm_cluster_QWEN(task, scheduler);
        
        System.out.println("┌─ TIMER SCHEDULING PROCESS ─────────────────────────────────────┐");
        System.out.println("│ 1. Clearing transactional action...");
        System.out.println("│ 2. Checking for duplicate tasks in local map...");
        System.out.println("│ 3. Calculating delay (startTime - currentTime)...");
        System.out.println("│ 4. Scheduling periodic timer with fixed delay...");
        
        runnable.run();
        
        System.out.println("└──────────────────────────────────────────────────────────────┘\n");
        
        
        Thread.sleep(600);
        
        System.out.println("┌─ SCHEDULING RESULT ──────────────────────────────────────────┐");
        System.out.println("│ ✓ Task successfully scheduled and executed.");
        System.out.println("│ ✓ Task ID: " + task.getData().getTaskID());
        System.out.println("└──────────────────────────────────────────────────────────────┘");
        
        scheduler.getExecutor().shutdown();
    }
}