import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class method_3_openengsb_QWEN {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public IndexCommit convert(EKBCommit ekbCommit) {
        IndexCommit commit = new IndexCommit();

        commit.setCommitId(ekbCommit.getRevisionNumber());
        commit.setParentCommitId(ekbCommit.getParentRevisionNumber());
        commit.setConnectorId(ekbCommit.getConnectorId());
        commit.setDomainId(ekbCommit.getDomainId());
        commit.setInstanceId(ekbCommit.getInstanceId());
        commit.setTimestamp(new Date());

        commit.setUser(getUser());
        commit.setContextId(getContextId());

        List<OpenEngSBModel> inserts = ekbCommit.getInserts();
        List<OpenEngSBModel> updates = ekbCommit.getUpdates();
        List<OpenEngSBModel> deletes = ekbCommit.getDeletes();

        Set<Class<?>> modelClasses = extractTypes(inserts, updates, deletes);

        commit.setModelClasses(modelClasses);

        commit.setInserts(mapByClass(inserts));
        commit.setUpdates(mapByClass(updates));
        commit.setDeletes(mapByClass(deletes));

        return commit;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== OpenEngSB CommitConverter.convert Test ===");
        method_3_openengsb_QWEN converter = new method_3_openengsb_QWEN();
        
        
        EKBCommit mockCommit = new EKBCommit();
        mockCommit.setRevisionNumber("rev-123");
        mockCommit.setParentRevisionNumber("rev-122");
        mockCommit.setConnectorId("testConnector");
        mockCommit.setDomainId("testDomain");
        mockCommit.setInstanceId("testInstance");
        
        List<OpenEngSBModel> inserts = new ArrayList<>();
        inserts.add(new MockOpenEngSBModel("InsertModel"));
        mockCommit.setInserts(inserts);
        mockCommit.setUpdates(new ArrayList<>());
        mockCommit.setDeletes(new ArrayList<>());
        
        try {
            System.out.println("Invoking convert...");
            IndexCommit result = converter.convert(mockCommit);
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Commit ID: " + result.getCommitId());
            System.out.println("Domain ID: " + result.getDomainId());
            System.out.println("Model Classes count: " + result.getModelClasses().size());
            System.out.println("Inserts count: " + result.getInserts().size());
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    
    
    private String getUser() {
        return "system-user";
    }
    
    private String getContextId() {
        return "default-context";
    }
    
    private Set<Class<?>> extractTypes(List<OpenEngSBModel> inserts, List<OpenEngSBModel> updates, List<OpenEngSBModel> deletes) {
        Set<Class<?>> classes = new HashSet<>();
        addTypes(classes, inserts);
        addTypes(classes, updates);
        addTypes(classes, deletes);
        return classes;
    }
    
    private void addTypes(Set<Class<?>> classes, List<OpenEngSBModel> models) {
        if (models != null) {
            for (OpenEngSBModel model : models) {
                classes.add(model.getClass());
            }
        }
    }
    
    private Map<Class<?>, List<OpenEngSBModel>> mapByClass(List<OpenEngSBModel> models) {
        if (models == null) return Map.of();
        return models.stream().collect(Collectors.groupingBy(OpenEngSBModel::getClass));
    }

    
    public interface OpenEngSBModel {}

    public static class MockOpenEngSBModel implements OpenEngSBModel {
        private String name;
        public MockOpenEngSBModel(String name) { this.name = name; }
        public String getName() { return name; }
    }

    public static class EKBCommit {
        private String revisionNumber;
        private String parentRevisionNumber;
        private String connectorId;
        private String domainId;
        private String instanceId;
        private List<OpenEngSBModel> inserts;
        private List<OpenEngSBModel> updates;
        private List<OpenEngSBModel> deletes;

        public String getRevisionNumber() { return revisionNumber; }
        public void setRevisionNumber(String revisionNumber) { this.revisionNumber = revisionNumber; }
        public String getParentRevisionNumber() { return parentRevisionNumber; }
        public void setParentRevisionNumber(String parentRevisionNumber) { this.parentRevisionNumber = parentRevisionNumber; }
        public String getConnectorId() { return connectorId; }
        public void setConnectorId(String connectorId) { this.connectorId = connectorId; }
        public String getDomainId() { return domainId; }
        public void setDomainId(String domainId) { this.domainId = domainId; }
        public String getInstanceId() { return instanceId; }
        public void setInstanceId(String instanceId) { this.instanceId = instanceId; }
        public List<OpenEngSBModel> getInserts() { return inserts; }
        public void setInserts(List<OpenEngSBModel> inserts) { this.inserts = inserts; }
        public List<OpenEngSBModel> getUpdates() { return updates; }
        public void setUpdates(List<OpenEngSBModel> updates) { this.updates = updates; }
        public List<OpenEngSBModel> getDeletes() { return deletes; }
        public void setDeletes(List<OpenEngSBModel> deletes) { this.deletes = deletes; }
    }

    public static class IndexCommit {
        private String commitId;
        private String parentCommitId;
        private String connectorId;
        private String domainId;
        private String instanceId;
        private Date timestamp;
        private String user;
        private String contextId;
        private Set<Class<?>> modelClasses;
        private Map<Class<?>, List<OpenEngSBModel>> inserts;
        private Map<Class<?>, List<OpenEngSBModel>> updates;
        private Map<Class<?>, List<OpenEngSBModel>> deletes;

        public void setCommitId(String commitId) { this.commitId = commitId; }
        public String getCommitId() { return commitId; }
        public void setParentCommitId(String parentCommitId) { this.parentCommitId = parentCommitId; }
        public void setConnectorId(String connectorId) { this.connectorId = connectorId; }
        public void setDomainId(String domainId) { this.domainId = domainId; }
        public String getDomainId() { return domainId; }
        public void setInstanceId(String instanceId) { this.instanceId = instanceId; }
        public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
        public void setUser(String user) { this.user = user; }
        public void setContextId(String contextId) { this.contextId = contextId; }
        public void setModelClasses(Set<Class<?>> modelClasses) { this.modelClasses = modelClasses; }
        public Set<Class<?>> getModelClasses() { return modelClasses; }
        public void setInserts(Map<Class<?>, List<OpenEngSBModel>> inserts) { this.inserts = inserts; }
        public Map<Class<?>, List<OpenEngSBModel>> getInserts() { return inserts; }
        public void setUpdates(Map<Class<?>, List<OpenEngSBModel>> updates) { this.updates = updates; }
        public void setDeletes(Map<Class<?>, List<OpenEngSBModel>> deletes) { this.deletes = deletes; }
    }
}