import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class method_1_openengsb_QWEN {

    private static final Logger LOGGER = new Logger();
    private static final String FILEWRAPPER_FILENAME_SUFFIX = "_filename";

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private String convertSubModel(OpenEngSBModel model, List<EDBObject> objects, ConnectorInformation info) {
        String contextId = ContextHolder.get().getCurrentContextId();
        String oid = ModelWrapper.wrap(model).getCompleteModelOID();
        EDBObject object = new EDBObject(oid);
        try {
            fillEDBObjectWithEngineeringObjectInformation(object, model);
        } catch (IllegalAccessException e) {
            LOGGER.warn("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
            throw new EKBException("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
        }
        for (OpenEngSBModelEntry entry : model.toOpenEngSBModelEntries()) {
            if (entry.getValue() == null) {
                continue;
            } else if (entry.getType().equals(FileWrapper.class)) {
                try {
                    FileWrapper wrapper = (FileWrapper) entry.getValue();
                    String content = Base64.encodeBase64String(wrapper.getContent());
                    object.putEDBObjectEntry(entry.getKey(), content, String.class);
                    object.putEDBObjectEntry(entry.getKey() + FILEWRAPPER_FILENAME_SUFFIX,
                        wrapper.getFilename(), String.class);
                } catch (IOException e) {
                    LOGGER.error(e.getMessage());
                }
            } else if (OpenEngSBModel.class.isAssignableFrom(entry.getType())) {
                OpenEngSBModel temp = (OpenEngSBModel) entry.getValue();
                String subOid = convertSubModel(temp, objects, info);
                object.putEDBObjectEntry(entry.getKey(), subOid, String.class);
            } else if (List.class.isAssignableFrom(entry.getType())) {
                List<?> list = (List<?>) entry.getValue();
                if (list == null || list.size() == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < list.size(); i++) {
                    Object item = list.get(i);
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (entry.getType().isArray()) {
                Object[] array = (Object[]) entry.getValue();
                if (array == null || array.length == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < array.length; i++) {
                    Object item = array[i];
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (Map.class.isAssignableFrom(entry.getType())) {
                Map<?, ?> map = (Map<?, ?>) entry.getValue();
                if (map == null || map.size() == 0) {
                    continue;
                }
                Boolean keyIsModel = null;
                Boolean valueIsModel = null;
                int i = 0;
                for (Map.Entry<?, ?> ent : map.entrySet()) {
                    if (keyIsModel == null) {
                        keyIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getKey().getClass());
                    }
                    if (valueIsModel == null) {
                        valueIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getValue().getClass());
                    }
                    Object key = ent.getKey();
                    Object value = ent.getValue();
                    if (keyIsModel) {
                        key = convertSubModel((OpenEngSBModel) key, objects, info);
                    }
                    if (valueIsModel) {
                        value = convertSubModel((OpenEngSBModel) value, objects, info);
                    }
                    object.putEDBObjectEntry(getEntryNameForMapKey(entry.getKey(), i), key);
                    object.putEDBObjectEntry(getEntryNameForMapValue(entry.getKey(), i), value);
                    i++;
                }
            } else {
                object.putEDBObjectEntry(entry.getKey(), entry.getValue(), entry.getType());
            }
        }
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE, model.retrieveModelName());
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, model.retrieveModelVersion());
        object.putEDBObjectEntry("domainId", info.getDomainId());
        object.putEDBObjectEntry("connectorId", info.getConnectorId());
        object.putEDBObjectEntry("instanceId", info.getInstanceId());
        object.putEDBObjectEntry("contextId", contextId);
        objects.add(object);
        return oid;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== OpenEngSB EDBConverter.convertSubModel Test ===");
        method_1_openengsb_QWEN converter = new method_1_openengsb_QWEN();
        
        List<EDBObject> objects = new ArrayList<>();
        ConnectorInformation info = new ConnectorInformation("testDomain", "testConnector", "testInstance");
        
        
        OpenEngSBModel mockModel = new OpenEngSBModel() {
            @Override
            public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
                List<OpenEngSBModelEntry> entries = new ArrayList<>();
                entries.add(new OpenEngSBModelEntry("testField", "testValue", String.class));
                return entries;
            }
            @Override
            public String retrieveModelName() { return "TestModel"; }
            @Override
            public String retrieveModelVersion() { return "1.0"; }
        };
        
        try {
            System.out.println("Invoking convertSubModel...");
            String oid = converter.convertSubModel(mockModel, objects, info);
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("Generated OID: " + oid);
            System.out.println("Objects list size: " + objects.size());
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: Exception during execution: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    public static class Logger {
        public void warn(String message, Object... args) {
            System.out.println("[WARN] " + format(message, args));
        }
        public void error(String message, Object... args) {
            System.out.println("[ERROR] " + format(message, args));
        }
        private String format(String message, Object... args) {
            String result = message;
            if (args != null) {
                for (Object arg : args) {
                    result = result.replaceFirst("\\{\\}", java.util.regex.Matcher.quoteReplacement(String.valueOf(arg)));
                }
            }
            return result;
        }
    }

    
    
    private void fillEDBObjectWithEngineeringObjectInformation(EDBObject object, OpenEngSBModel model) throws IllegalAccessException {
        
    }
    
    private String getEntryNameForList(String key, int index) {
        return key + "[" + index + "]";
    }
    
    private String getEntryNameForMapKey(String key, int index) {
        return key + "_key_" + index;
    }
    
    private String getEntryNameForMapValue(String key, int index) {
        return key + "_value_" + index;
    }

    
    public interface OpenEngSBModel {
        List<OpenEngSBModelEntry> toOpenEngSBModelEntries();
        String retrieveModelName();
        String retrieveModelVersion();
    }

    public static class OpenEngSBModelEntry {
        private String key;
        private Object value;
        private Class<?> type;
        public OpenEngSBModelEntry(String key, Object value, Class<?> type) {
            this.key = key; this.value = value; this.type = type;
        }
        public String getKey() { return key; }
        public Object getValue() { return value; }
        public Class<?> getType() { return type; }
    }

    public static class EDBObject {
        private String oid;
        public EDBObject(String oid) { this.oid = oid; }
        public String getOID() { return oid; }
        public void putEDBObjectEntry(String key, Object value, Class<?> type) {}
        public void putEDBObjectEntry(String key, Object value) {}
        public Object getObject(String key) { return null; }
        public String getString(String key) { return null; }
        public void remove(String key) {}
        public boolean containsKey(String key) { return false; }
    }

    public static class ConnectorInformation {
        private String domainId, connectorId, instanceId;
        public ConnectorInformation(String d, String c, String i) {
            this.domainId = d; this.connectorId = c; this.instanceId = i;
        }
        public String getDomainId() { return domainId; }
        public String getConnectorId() { return connectorId; }
        public String getInstanceId() { return instanceId; }
    }

    public static class ContextHolder {
        private static final ContextHolder INSTANCE = new ContextHolder();
        public static ContextHolder get() { return INSTANCE; }
        public String getCurrentContextId() { return "default-context"; }
    }

    public static class ModelWrapper {
        private OpenEngSBModel model;
        private ModelWrapper(OpenEngSBModel model) { this.model = model; }
        public static ModelWrapper wrap(OpenEngSBModel model) { return new ModelWrapper(model); }
        public String getCompleteModelOID() { return "oid-" + model.retrieveModelName(); }
    }

    public static class FileWrapper {
        public byte[] getContent() throws IOException { return new byte[0]; }
        public String getFilename() { return "test.txt"; }
        public void setFilename(String name) {}
        public void setContent(byte[] content) {}
    }

    public static class EDBConstants {
        public static final String MODEL_TYPE = "modelType";
        public static final String MODEL_TYPE_VERSION = "modelTypeVersion";
        public static final String MODEL_TIMESTAMP = "modelTimestamp";
    }

    public static class EKBException extends RuntimeException {
        public EKBException(String msg, Throwable cause) { super(msg, cause); }
    }

    
    public static class Base64 {
        public static String encodeBase64String(byte[] data) {
            return java.util.Base64.getEncoder().encodeToString(data);
        }
        public static byte[] decodeBase64(String data) {
            return java.util.Base64.getDecoder().decode(data);
        }
    }
}