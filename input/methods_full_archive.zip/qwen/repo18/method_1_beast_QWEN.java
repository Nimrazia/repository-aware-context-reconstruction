import java.util.logging.Logger;

class Plan {
    public void body() {}
    protected method_1_beast_QWEN.Beliefbase getBeliefbase() { return new method_1_beast_QWEN.Beliefbase(); }
    protected Object getServiceContainer() { return new Object(); }
    protected method_1_beast_QWEN.IGoal createGoal(String name) { return new method_1_beast_QWEN.MockGoal(); }
    protected void dispatchSubgoalAndWait(method_1_beast_QWEN.IGoal goal) {}
    protected method_1_beast_QWEN.IMessageEvent createMessageEvent(String name) { return new method_1_beast_QWEN.MockMessageEvent(); }
    protected void sendMessage(method_1_beast_QWEN.IMessageEvent msg) {}
}


public class method_1_beast_QWEN extends Plan {

    private static final long serialVersionUID = 4357742910363913150L;
    private Logger logger = Logger.getLogger(method_1_beast_QWEN.class.getName());

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Override
    public void body() {

        CallQueue queue = (CallQueue) getBeliefbase().getBelief("queue")
                .getFact();

        Call call = queue.getPendingCall();
        if (call.getCustormer().getLanguage().equalsIgnoreCase("English")) {

            String target_service = "report-service";
            String msgContent = "NewRecordedCall";

            
            IDF df = (IDF) SServiceProvider.getService(getServiceContainer(),
                    IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
            IDFServiceDescription sd = df.createDFServiceDescription(
                    target_service, null, null);
            IDFComponentDescription dfadesc = df.createDFComponentDescription(
                    null, sd);

            ISearchConstraints constraints = df.createSearchConstraints(-1, 0);

            
            IGoal ft = createGoal("dfcap.df_search");
            ft.getParameter("description").setValue(dfadesc);
            ft.getParameter("constraints").setValue(constraints);

            dispatchSubgoalAndWait(ft);
            IDFComponentDescription[] agents = (IDFComponentDescription[]) ft
                    .getParameterSet("result").getValues();

            if (agents.length > 0) {
                IMessageEvent msg = createMessageEvent("send_inform");
                msg.getParameter(SFipa.CONTENT).setValue(msgContent);
                msg.getParameterSet(SFipa.RECEIVERS).addValue(
                        agents[0].getName());
                sendMessage(msg);
                logger.info("Message sent to: "
                        + agents[0].getName().getLocalName());
            } else {
                logger.severe("Service " + target_service + " not found.");
            }

        } else {

            System.out.println("Language: " + call.getCustormer().getLanguage());
            String target_service = "helpdesk-service";
            String msgContent = "UnknownLanguageCall";

            
            IDF df = (IDF) SServiceProvider.getService(getServiceContainer(),
                    IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
            IDFServiceDescription sd = df.createDFServiceDescription(
                    target_service, null, null);
            IDFComponentDescription dfadesc = df.createDFComponentDescription(
                    null, sd);

            ISearchConstraints constraints = df.createSearchConstraints(-1, 0);

            
            IGoal ft = createGoal("dfcap.df_search");
            ft.getParameter("description").setValue(dfadesc);
            ft.getParameter("constraints").setValue(constraints);

            dispatchSubgoalAndWait(ft);
            IDFComponentDescription[] agents = (IDFComponentDescription[]) ft
                    .getParameterSet("result").getValues();

            IMessageEvent msg = createMessageEvent("helpdesk-request");
            msg.getParameter(SFipa.CONTENT).setValue(msgContent);
            if (agents.length > 0) {
                msg.getParameterSet(SFipa.RECEIVERS).addValue(
                        agents[0].getName());
                sendMessage(msg);
                System.out.println("Enviado");
            } else {
                System.out.println("Service " + target_service + " not found.");
                logger.severe("Service " + target_service + " not found.");
            }

            logger.info("Message sent to: " + agents[0].getName());

        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== BeastTool ReceiveCallPlan.body Test ===");
        method_1_beast_QWEN plan = new method_1_beast_QWEN();
        try {
            System.out.println("Invoking body()...");
            plan.body();
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    
    
    
    public static class Plan {
        protected Beliefbase getBeliefbase() { return new Beliefbase(); }
        protected Object getServiceContainer() { return new Object(); }
        protected IGoal createGoal(String name) { return new MockGoal(); }
        protected void dispatchSubgoalAndWait(IGoal goal) {}
        protected IMessageEvent createMessageEvent(String name) { return new MockMessageEvent(); }
        protected void sendMessage(IMessageEvent msg) {}
    }

    public static class Beliefbase {
        public Belief getBelief(String name) { return new Belief(); }
    }
    public static class Belief {
        public Object getFact() { 
            CallQueue q = new CallQueue(); 
            q.setPendingCall(new Call(new Customer("English"))); 
            return q; 
        }
    }

    
    public static class CallQueue {
        private Call pendingCall;
        public Call getPendingCall() { return pendingCall; }
        public void setPendingCall(Call c) { this.pendingCall = c; }
    }
    public static class Call {
        private Customer custormer;
        public Call(Customer c) { this.custormer = c; }
        public Customer getCustormer() { return custormer; }
    }
    public static class Customer {
        private String language;
        public Customer(String lang) { this.language = lang; }
        public String getLanguage() { return language; }
    }

    
    public static interface IDF {
        IDFServiceDescription createDFServiceDescription(String name, String type, String description);
        IDFComponentDescription createDFComponentDescription(Object name, IDFServiceDescription sd);
        ISearchConstraints createSearchConstraints(int max, int start);
    }
    public static interface IDFServiceDescription {}
    public static interface IDFComponentDescription {
        ComponentName getName();
    }
    public static interface ComponentName {
        String getLocalName();
    }
    public static interface ISearchConstraints {}
    public static interface IGoal {
        Parameter getParameter(String name);
        ParameterSet getParameterSet(String name);
    }
    public static interface Parameter { void setValue(Object value); }
    public static interface ParameterSet { void addValue(Object value); Object[] getValues(); }
    public static interface IMessageEvent {
        Parameter getParameter(String name);
        ParameterSet getParameterSet(String name);
    }
    public static interface SFipa {
        String CONTENT = "content";
        String RECEIVERS = "receivers";
    }
    public static class SServiceProvider {
        public static ServiceProvider getService(Object container, Class<?> type, int scope) {
            return new MockServiceProvider();
        }
    }
    public static interface ServiceProvider {
        Object get(Object plan);
    }
    public static class RequiredServiceInfo {
        public static final int SCOPE_PLATFORM = 1;
    }

    
    public static class MockGoal implements IGoal {
        public Parameter getParameter(String name) { return new MockParameter(); }
        public ParameterSet getParameterSet(String name) { return new MockParameterSet(); }
    }
    public static class MockParameter implements Parameter {
        public void setValue(Object value) {}
    }
    public static class MockParameterSet implements ParameterSet {
        public void addValue(Object value) {}
        public Object[] getValues() {
            return new IDFComponentDescription[]{ new IDFComponentDescription() {
                public ComponentName getName() { return () -> "mock-agent"; }
            }};
        }
    }
    public static class MockMessageEvent implements IMessageEvent {
        public Parameter getParameter(String name) { return new MockParameter(); }
        public ParameterSet getParameterSet(String name) { return new MockParameterSet(); }
    }
    public static class MockServiceProvider implements ServiceProvider {
        public Object get(Object plan) {
            return new IDF() {
                public IDFServiceDescription createDFServiceDescription(String n, String t, String d) { return new IDFServiceDescription() {}; }
                public IDFComponentDescription createDFComponentDescription(Object n, IDFServiceDescription sd) {
                    return new IDFComponentDescription() { public ComponentName getName() { return () -> "mock-agent"; } };
                }
                public ISearchConstraints createSearchConstraints(int max, int start) { return new ISearchConstraints() {}; }
            };
        }
    }
}