import java.util.logging.Logger;

class Plan {
    protected Object getReason() { return new method_2_beast_QWEN.MockMessageEvent(); }
    protected method_2_beast_QWEN.Beliefbase getBeliefbase() { return new method_2_beast_QWEN.Beliefbase(); }
    protected method_2_beast_QWEN.Scope getScope() { return new method_2_beast_QWEN.Scope(); }
    protected void waitFor(int time) {}
    protected method_2_beast_QWEN.IGoal createGoal(String name) { return new method_2_beast_QWEN.MockGoal(); }
    protected void dispatchSubgoalAndWait(method_2_beast_QWEN.IGoal goal) {}
}


public class method_2_beast_QWEN extends Plan {

    private static final long serialVersionUID = 112334545L;
    private static final int LEASE_TIME = 60000;
    private static final int WAIT_FOR_TIME = 1000;

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void body() {

        MockConfiguration configuration = (MockConfiguration) ((IMessageEvent) getReason())
                .getParameter(SFipa.CONTENT).getValue();
        getBeliefbase().getBelief("agent_behaviour").setFact(
                configuration.getBehaviour());

        
        IServiceProvider iserviceprovider = getScope().getServiceContainer();
        DirectoryFacilitatorService idfservice = new DirectoryFacilitatorService(
                iserviceprovider);
        DFServiceDescription dfaux = (DFServiceDescription) idfservice
                .createDFServiceDescription(configuration.getDFservice(),
                        configuration.getDFservice(),
                        "Universidad Politécnica de Madrid");

        IDFComponentDescription df_description = idfservice
                .createDFComponentDescription(null, dfaux);
        waitFor(WAIT_FOR_TIME);

        IGoal keep = createGoal("dfcap.df_keep_registered");
        keep.getParameter("description").setValue(df_description);
        keep.getParameter("leasetime").setValue(new Long(LEASE_TIME));
        dispatchSubgoalAndWait(keep);

        Logger logger = Logger.getLogger(this.getClass().toString());
        logger.info(configuration.getDFservice() + " registered");
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("=== BeastTool SetupPlan.body Test ===");
        method_2_beast_QWEN plan = new method_2_beast_QWEN();
        try {
            System.out.println("Invoking body()...");
            plan.body();
            System.out.println("SUCCESS: Method executed without throwing exceptions.");
            System.out.println("=== Test Completed Successfully ===");
        } catch (Exception e) {
            System.err.println("FAILURE: " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
    

    
    public static class Plan {
        protected Object getReason() { return new MockMessageEvent(); }
        protected Beliefbase getBeliefbase() { return new Beliefbase(); }
        protected Scope getScope() { return new Scope(); }
        protected void waitFor(int time) {}
        protected IGoal createGoal(String name) { return new MockGoal(); }
        protected void dispatchSubgoalAndWait(IGoal goal) {}
    }

    public static class Beliefbase {
        public Belief getBelief(String name) { return new Belief(); }
    }
    public static class Belief {
        public void setFact(Object fact) {}
    }
    public static class Scope {
        public IServiceProvider getServiceContainer() { return new IServiceProvider() {}; }
    }

    
    public static class MockConfiguration {
        public String getBehaviour() { return "mock-behaviour"; }
        public String getDFservice() { return "mock-df-service"; }
    }

    
    public static interface IMessageEvent {
        Parameter getParameter(String name);
    }
    public static interface Parameter {
        Object getValue();
        void setValue(Object value);
    }
    public static interface SFipa {
        String CONTENT = "content";
    }
    public static interface IServiceProvider {}
    
    public static class DirectoryFacilitatorService {
        public DirectoryFacilitatorService(IServiceProvider provider) {}
        public DFServiceDescription createDFServiceDescription(String name, String type, String desc) {
            return new DFServiceDescription();
        }
        public IDFComponentDescription createDFComponentDescription(Object name, DFServiceDescription sd) {
            return new IDFComponentDescription();
        }
    }
    
    public static class DFServiceDescription {}
    public static class IDFComponentDescription {}

    public static interface IGoal {
        Parameter getParameter(String name);
    }

    
    public static class MockMessageEvent implements IMessageEvent {
        public Parameter getParameter(String name) {
            return new Parameter() {
                public Object getValue() { return new MockConfiguration(); }
                public void setValue(Object value) {}
            };
        }
    }
    public static class MockGoal implements IGoal {
        public Parameter getParameter(String name) {
            return new Parameter() { public void setValue(Object v) {} public Object getValue() { return null; } };
        }
    }
}