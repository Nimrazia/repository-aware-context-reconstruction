import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




class SerialMessageMock {
    private byte[] payload;
    private int offset;
    public SerialMessageMock(byte[] payload, int offset) {
        this.payload = payload;
        this.offset = offset;
    }
    public byte getMessagePayloadByte(int index) { return payload[index]; }
    public byte[] getMessagePayload() { return payload; }
}

class ZWaveDeviceClassMock {
    public enum Basic { NOT_KNOWN(0x00), ROUTING_SLAVE(0x04); 
        private int key; Basic(int k) { key = k; } public int getKey() { return key; } public String getLabel() { return name(); }
    }
    public enum Generic { MULTILEVEL_SWITCH(0x11); 
        private int key; Generic(int k) { key = k; } public int getKey() { return key; } public String getLabel() { return name(); }
        public static Generic getGeneric(int key) { return MULTILEVEL_SWITCH; }
    }
    public enum Specific { MULTILEVEL_POWER_SWITCH(0x01); 
        private int key; Specific(int k) { key = k; } public int getKey() { return key; } public String getLabel() { return name(); }
        public static Specific getSpecific(Generic g, int key) { return MULTILEVEL_POWER_SWITCH; }
    }
    private Basic basic = Basic.NOT_KNOWN;
    private Generic generic = Generic.MULTILEVEL_SWITCH;
    private Specific specific = Specific.MULTILEVEL_POWER_SWITCH;
    public Basic getBasicDeviceClass() { return basic; }
    public void setBasicDeviceClass(Basic b) { this.basic = b; }
    public Generic getGenericDeviceClass() { return generic; }
    public void setGenericDeviceClass(Generic g) { this.generic = g; }
    public Specific getSpecificDeviceClass() { return specific; }
    public void setSpecificDeviceClass(Specific s) { this.specific = s; }
}

class ZWaveCommandClassMock {
    public enum CommandClass { BASIC(0x20), SWITCH_MULTILEVEL(0x26); 
        private int key; CommandClass(int k) { key = k; } public int getKey() { return key; } public String getLabel() { return name(); }
    }
    private CommandClass commandClass;
    private int version = 1;
    public ZWaveCommandClassMock(CommandClass cc) { this.commandClass = cc; }
    public CommandClass getCommandClass() { return commandClass; }
    public void setVersion(int v) { this.version = v; }
    public int getVersion() { return version; }
    
    public static ZWaveCommandClassMock getInstance(int key, ZWaveNodeMock node, Object controller, ZWaveEndpointMock endpoint) {
        if (key == 0x20) return new ZWaveCommandClassMock(CommandClass.BASIC);
        if (key == 0x26) return new ZWaveCommandClassMock(CommandClass.SWITCH_MULTILEVEL);
        return null;
    }
}

class ZWaveEndpointMock {
    private int endpointId;
    private ZWaveDeviceClassMock deviceClass = new ZWaveDeviceClassMock();
    private Map<ZWaveCommandClassMock.CommandClass, ZWaveCommandClassMock> commandClasses = new HashMap<>();
    public ZWaveEndpointMock(int id) { this.endpointId = id; }
    public int getEndpointId() { return endpointId; }
    public ZWaveDeviceClassMock getDeviceClass() { return deviceClass; }
    public void addCommandClass(ZWaveCommandClassMock cc) { 
        commandClasses.put(cc.getCommandClass(), cc); 
        System.out.println("      → Added command class " + cc.getCommandClass().getLabel() + " to endpoint " + endpointId);
    }
}

class ZWaveNodeMock {
    private int nodeId = 3;
    private ZWaveDeviceClassMock deviceClass = new ZWaveDeviceClassMock();
    private Map<ZWaveCommandClassMock.CommandClass, ZWaveCommandClassMock> commandClasses = new HashMap<>();
    
    public ZWaveNodeMock() {
        commandClasses.put(ZWaveCommandClassMock.CommandClass.BASIC, new ZWaveCommandClassMock(ZWaveCommandClassMock.CommandClass.BASIC));
    }
    
    public int getNodeId() { return nodeId; }
    public ZWaveDeviceClassMock getDeviceClass() { return deviceClass; }
    public boolean supportsCommandClass(ZWaveCommandClassMock.CommandClass cc) { return commandClasses.containsKey(cc); }
    public ZWaveCommandClassMock getCommandClass(ZWaveCommandClassMock.CommandClass cc) { return commandClasses.get(cc); }
    public void advanceNodeStage() { System.out.println("  → Advancing node stage after endpoint capability report."); }
}

class ZWaveMultiInstanceCommandClassMock {
    private ZWaveNodeMock node;
    private Object controller;
    private Map<Integer, ZWaveEndpointMock> endpoints = new HashMap<>();
    private boolean endpointsAreTheSameDeviceClass = true;
    private static class logger {
        public static void debug(String msg, Object... args) { System.out.println("[DEBUG] " + String.format(msg, args)); }
        public static void error(String msg, Object... args) { System.out.println("[ERROR] " + String.format(msg, args)); }
    }

    public ZWaveMultiInstanceCommandClassMock(ZWaveNodeMock node, Object controller) {
        this.node = node;
        this.controller = controller;
        endpoints.put(1, new ZWaveEndpointMock(1));
    }

    public ZWaveNodeMock getNode() { return node; }
    public Object getController() { return controller; }


// ORIGINAL CODESEARCHNET METHOD — START

private void handleMultiChannelCapabilityReportResponse(SerialMessageMock serialMessage, int offset) {
		logger.debug("Process Multi-channel capability Report");
		int receivedEndpointId = serialMessage.getMessagePayloadByte(offset) & 0x7F;
		boolean dynamic = ((serialMessage.getMessagePayloadByte(offset) & 0x80) != 0);
		int genericDeviceClass = serialMessage.getMessagePayloadByte(offset + 1);
		int specificDeviceClass = serialMessage.getMessagePayloadByte(offset + 2);
		
		logger.debug("Endpoints are the same device class = {}", endpointsAreTheSameDeviceClass ? "true" : false);

		
		
		int startId = this.endpointsAreTheSameDeviceClass ? 1 : receivedEndpointId;
		int endId = this.endpointsAreTheSameDeviceClass ? this.endpoints.size() : receivedEndpointId;
		
		boolean supportsBasicCommandClass = this.getNode().supportsCommandClass(ZWaveCommandClassMock.CommandClass.BASIC);
		
		for (int endpointId = startId; endpointId <= endId; endpointId++) {
			ZWaveEndpointMock endpoint = this.endpoints.get(endpointId);
			
			if (endpoint == null){
				logger.error("Endpoint {} not found on node {}. Cannot set command classes.", endpoint, this.getNode().getNodeId());
				continue;
			}
	
			ZWaveDeviceClassMock.Basic basic = this.getNode().getDeviceClass().getBasicDeviceClass();
			ZWaveDeviceClassMock.Generic generic = ZWaveDeviceClassMock.Generic.getGeneric(genericDeviceClass);
			if (generic == null) {
				logger.error(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.", 
						endpoint, genericDeviceClass, specificDeviceClass));
				continue;
			}
			ZWaveDeviceClassMock.Specific specific = ZWaveDeviceClassMock.Specific.getSpecific(generic, specificDeviceClass);
			if (specific == null) {
				logger.error(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.", 
						endpoint, genericDeviceClass, specificDeviceClass));
				continue;
			}
			
			logger.debug("Endpoint Id = {}", endpointId);
			logger.debug("Endpoints is dynamic = {}", dynamic ? "true" : false);
			logger.debug(String.format("Basic = %s 0x%02x", basic.getLabel(), basic.getKey()));
			logger.debug(String.format("Generic = %s 0x%02x", generic.getLabel(), generic.getKey()));
			logger.debug(String.format("Specific = %s 0x%02x", specific.getLabel(), specific.getKey()));
			
			ZWaveDeviceClassMock deviceClass = endpoint.getDeviceClass();
			deviceClass.setBasicDeviceClass(basic);
			deviceClass.setGenericDeviceClass(generic);
			deviceClass.setSpecificDeviceClass(specific);
			
			
			if (supportsBasicCommandClass) {
				ZWaveCommandClassMock commandClass = new ZWaveCommandClassMock(ZWaveCommandClassMock.CommandClass.BASIC);
				endpoint.addCommandClass(commandClass);
			}
			
			for (int i = 0; i < serialMessage.getMessagePayload().length - offset - 3; i++) {
				int data = serialMessage.getMessagePayloadByte(offset + 3 + i);
				if(data == 0xef )  {
					
					break;
				}
				logger.debug(String.format("Adding command class 0x%02X to the list of supported command classes.", data));
				ZWaveCommandClassMock commandClass = ZWaveCommandClassMock.getInstance(data, this.getNode(), this.getController(), endpoint);
				if (commandClass == null) {
					continue;
				}

				endpoint.addCommandClass(commandClass);
				ZWaveCommandClassMock parentClass = this.getNode().getCommandClass(commandClass.getCommandClass());

				
				if (parentClass != null) {
					commandClass.setVersion(parentClass.getVersion());
				}
			}
		}
		
		if (this.endpointsAreTheSameDeviceClass)
			
			this.getNode().advanceNodeStage();
		else {
			for (ZWaveEndpointMock ep : this.endpoints.values())
			{
				if (ep.getDeviceClass().getBasicDeviceClass() == ZWaveDeviceClassMock.Basic.NOT_KNOWN) 
					return;
			}
			
			this.getNode().advanceNodeStage();
		}
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public void testHandleResponse() {
        
        
        
        
        
        
        byte[] payload = new byte[]{0x01, 0x11, 0x01, 0x20, 0x26};
        SerialMessageMock msg = new SerialMessageMock(payload, 0);
        
        System.out.println("┌─ MULTI-CHANNEL CAPABILITY REPORT PROCESSING ─────────────────┐");
        handleMultiChannelCapabilityReportResponse(msg, 0);
        System.out.println("└──────────────────────────────────────────────────────────────┘\n");
    }

    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Method 3: ZWaveMultiInstance.handleMultiChannelCapability   ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");

        try {
            ZWaveNodeMock node = new ZWaveNodeMock();
            ZWaveMultiInstanceCommandClassMock multiInstance = new ZWaveMultiInstanceCommandClassMock(node, new Object());
            
            multiInstance.testHandleResponse();
            
            System.out.println("┌─ PROCESSING RESULT ────────────────────────────────────────┐");
            System.out.println("✓ Endpoint device class updated successfully.");
            System.out.println("✓ Command classes parsed and assigned to endpoint.");
            System.out.println("✓ Version info copied from parent node.");
            System.out.println("✓ Node stage advanced upon completion.");
            System.out.println("└──────────────────────────────────────────────────────────────┘");
            
        } catch (Exception e) {
            System.err.println("\n✗ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}