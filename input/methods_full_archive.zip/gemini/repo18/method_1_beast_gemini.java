



import java.util.logging.Logger;
import java.util.HashMap;
import java.util.Map;

public class method_1_beast_gemini {

    
    
    

    static class Customer {
        private String language;
        public Customer(String language) { this.language = language; }
        public String getLanguage() { return language; }
    }

    static class Call {
        private Customer customer;
        public Call(Customer customer) { this.customer = customer; }
        public Customer getCustormer() { return customer; } 
    }

    static class CallQueue {
        private Call pendingCall;
        public CallQueue(Call pendingCall) { this.pendingCall = pendingCall; }
        public Call getPendingCall() { return pendingCall; }
    }

    interface IFact {
        Object getFact();
        void setFact(Object fact);
    }

    static class MockFact implements IFact {
        private Object fact;
        public MockFact(Object fact) { this.fact = fact; }
        public Object getFact() { return fact; }
        public void setFact(Object fact) { this.fact = fact; }
    }

    interface IBeliefbase {
        IFact getBelief(String name);
    }

    static class MockBeliefbase implements IBeliefbase {
        private Map<String, IFact> beliefs = new HashMap<>();
        public void addBelief(String name, IFact fact) { beliefs.put(name, fact); }
        public IFact getBelief(String name) { return beliefs.get(name); }
    }

    static class IComponentIdentifier {
        private String name;
        public IComponentIdentifier(String name) { this.name = name; }
        public String getName() { return name; }
        public String getLocalName() { return name; }
        @Override
        public String toString() { return name; }
    }

    interface IParameter {
        void setValue(Object value);
        Object getValue();
    }

    static class MockParameter implements IParameter {
        private Object value;
        public void setValue(Object value) { this.value = value; }
        public Object getValue() { return value; }
    }

    interface IParameterSet {
        void addValue(Object value);
        Object[] getValues();
    }

    static class MockParameterSet implements IParameterSet {
        private java.util.List<Object> values = new java.util.ArrayList<>();
        private Object[] typedValues;

        public void addValue(Object value) {
            values.add(value);
            typedValues = null;
        }

        public Object[] getValues() {
            return typedValues != null ? typedValues : values.toArray();
        }

        public void setValues(Object[] vals) {
            values.clear();
            for (Object value : vals) {
                values.add(value);
            }
            typedValues = vals;
        }
    }

    interface IMessageEvent {
        IParameter getParameter(String name);
        IParameterSet getParameterSet(String name);
    }

    static class MockMessageEvent implements IMessageEvent {
        private Map<String, IParameter> params = new HashMap<>();
        private Map<String, IParameterSet> paramSets = new HashMap<>();
        private String type;

        public MockMessageEvent(String type) {
            this.type = type;
            params.put(SFipa.CONTENT, new MockParameter());
            paramSets.put(SFipa.RECEIVERS, new MockParameterSet());
        }
        public IParameter getParameter(String name) { return params.get(name); }
        public IParameterSet getParameterSet(String name) { return paramSets.get(name); }
        public String getType() { return type; }
    }

    interface IGoal {
        IParameter getParameter(String name);
        IParameterSet getParameterSet(String name);
    }

    static class MockGoal implements IGoal {
        private Map<String, IParameter> params = new HashMap<>();
        private Map<String, IParameterSet> paramSets = new HashMap<>();
        
        public MockGoal() {
            params.put("description", new MockParameter());
            params.put("constraints", new MockParameter());
            paramSets.put("result", new MockParameterSet());
        }
        public IParameter getParameter(String name) { return params.get(name); }
        public IParameterSet getParameterSet(String name) { return paramSets.get(name); }
    }

    static class IDFServiceDescription {}
    static class IDFComponentDescription {
        private IComponentIdentifier name;
        public IDFComponentDescription(String nameStr) { this.name = new IComponentIdentifier(nameStr); }
        public IComponentIdentifier getName() { return name; }
    }
    static class ISearchConstraints {}

    interface IDF {
        IDFServiceDescription createDFServiceDescription(String type, String name, String ownership);
        IDFComponentDescription createDFComponentDescription(IComponentIdentifier cid, IDFServiceDescription sd);
        ISearchConstraints createSearchConstraints(int maxResults, int timeout);
    }

    static class MockDF implements IDF {
        public IDFServiceDescription createDFServiceDescription(String type, String name, String ownership) { return new IDFServiceDescription(); }
        public IDFComponentDescription createDFComponentDescription(IComponentIdentifier cid, IDFServiceDescription sd) { return new IDFComponentDescription("MockAgent"); }
        public ISearchConstraints createSearchConstraints(int maxResults, int timeout) { return new ISearchConstraints(); }
    }

    static class RequiredServiceInfo {
        public static final String SCOPE_PLATFORM = "platform";
    }

    static class SServiceProvider {
        public static MockServiceLocator getService(Object container, Class<?> clazz, String scope) {
            return new MockServiceLocator();
        }
    }

    static class MockServiceLocator {
        public Object get(Object component) { return new MockDF(); }
    }

    static class SFipa {
        public static final String CONTENT = "content";
        public static final String RECEIVERS = "receivers";
    }

    
    
    

    public abstract static class Plan {
        protected Logger logger = Logger.getLogger(Plan.class.getName());
        protected MockBeliefbase beliefbase = new MockBeliefbase();
        
        public IBeliefbase getBeliefbase() { return beliefbase; }
        public Object getServiceContainer() { return new Object(); }
        public IGoal createGoal(String type) { return new MockGoal(); }
        
        public void dispatchSubgoalAndWait(IGoal goal) {
            System.out.println("DEBUG: Dispatching subgoal and waiting...");
            
            MockParameterSet resultSet = (MockParameterSet) goal.getParameterSet("result");
            resultSet.setValues(new IDFComponentDescription[]{ new IDFComponentDescription("df_found_agent_1") });
        }
        
        public IMessageEvent createMessageEvent(String type) { return new MockMessageEvent(type); }
        
        public void sendMessage(IMessageEvent msg) {
            MockMessageEvent m = (MockMessageEvent) msg;
            System.out.println("DEBUG: Sending message of type '" + m.getType() + "' with content: '" + m.getParameter(SFipa.CONTENT).getValue() + "'");
        }

        public abstract void body();
    }

    
    
    

    public static class ReceiveCallPlan extends Plan {


// ORIGINAL CODESEARCHNET METHOD — START

@Override
	public void body() {

		CallQueue queue = (CallQueue) getBeliefbase().getBelief("queue")
				.getFact();

		Call call = queue.getPendingCall();
		if (call.getCustormer().getLanguage().equalsIgnoreCase("English")) {

			String target_service = "report-service";
			String msgContent = "NewRecordedCall";

			
			IDF df = (IDF) SServiceProvider.getService(getServiceContainer(),
					IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
			IDFServiceDescription sd = df.createDFServiceDescription(
					target_service, null, null);
			IDFComponentDescription dfadesc = df.createDFComponentDescription(
					null, sd);

			ISearchConstraints constraints = df.createSearchConstraints(-1, 0);

			
			IGoal ft = createGoal("dfcap.df_search");
			ft.getParameter("description").setValue(dfadesc);
			ft.getParameter("constraints").setValue(constraints);

			dispatchSubgoalAndWait(ft);
			IDFComponentDescription[] agents = (IDFComponentDescription[]) ft
					.getParameterSet("result").getValues();

			if (agents.length > 0) {
				IMessageEvent msg = createMessageEvent("send_inform");
				msg.getParameter(SFipa.CONTENT).setValue(msgContent);
				msg.getParameterSet(SFipa.RECEIVERS).addValue(
						agents[0].getName());
				sendMessage(msg);
				logger.info("Message sent to: "
						+ agents[0].getName().getLocalName());
			} else {
				logger.severe("Service " + target_service + " not found.");
			}

		} else {

			System.out.println("Language: " + call.getCustormer().getLanguage());
			String target_service = "helpdesk-service";
			String msgContent = "UnknownLanguageCall";

			
			IDF df = (IDF) SServiceProvider.getService(getServiceContainer(),
					IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
			IDFServiceDescription sd = df.createDFServiceDescription(
					target_service, null, null);
			IDFComponentDescription dfadesc = df.createDFComponentDescription(
					null, sd);

			ISearchConstraints constraints = df.createSearchConstraints(-1, 0);

			
			IGoal ft = createGoal("dfcap.df_search");
			ft.getParameter("description").setValue(dfadesc);
			ft.getParameter("constraints").setValue(constraints);

			dispatchSubgoalAndWait(ft);
			IDFComponentDescription[] agents = (IDFComponentDescription[]) ft
					.getParameterSet("result").getValues();

			IMessageEvent msg = createMessageEvent("helpdesk-request");
			msg.getParameter(SFipa.CONTENT).setValue(msgContent);
			if (agents.length > 0) {
				msg.getParameterSet(SFipa.RECEIVERS).addValue(
						agents[0].getName());
				sendMessage(msg);
				System.out.println("Enviado");
			} else {
				System.out.println("Service " + target_service + " not found.");
				logger.severe("Service " + target_service + " not found.");
			}

			logger.info("Message sent to: " + agents[0].getName());

		}
	}

// ORIGINAL CODESEARCHNET METHOD — END

    }

    public static void main(String[] args) {
        System.out.println("Starting ReceiveCallPlan Simulation...\n");

        System.out.println("--- Scenario 1: English Customer Call ---");
        ReceiveCallPlan plan1 = new ReceiveCallPlan();
        CallQueue queue1 = new CallQueue(new Call(new Customer("English")));
        plan1.beliefbase.addBelief("queue", new MockFact(queue1));
        plan1.body();

        System.out.println("\n--- Scenario 2: Spanish Customer Call ---");
        ReceiveCallPlan plan2 = new ReceiveCallPlan();
        CallQueue queue2 = new CallQueue(new Call(new Customer("Spanish")));
        plan2.beliefbase.addBelief("queue", new MockFact(queue2));
        plan2.body();

        System.out.println("\nExecution Complete.");
    }
}