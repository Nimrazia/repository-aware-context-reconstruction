import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Retention(RetentionPolicy.RUNTIME)
@interface PROTOTYPE {
}

@Retention(RetentionPolicy.RUNTIME)
@interface AOP {
	String value() default "";

	String method() default "";
}

@Retention(RetentionPolicy.RUNTIME)
@interface POSTCONSTRUCT {
}

@Retention(RetentionPolicy.RUNTIME)
@interface PREDESTROY {
}

@Retention(RetentionPolicy.RUNTIME)
@interface PostConstruct {
}

@Retention(RetentionPolicy.RUNTIME)
@interface PreDestroy {
}

class EMPTY {
}

@PROTOTYPE
@AOP(value = "sampleAop", method = "someMethod")
class SampleBean {
	@POSTCONSTRUCT
	public void init() {
	}

	@PREDESTROY
	public void destroy() {
	}
}

class BeanBox {
	private Class<?> beanClass;
	private boolean singleton = true;
	private Object target;
	private boolean pureValue;
	private boolean required;
	private Constructor<?> constructor;
	private BeanBox[] constructorParams;
	private Class<?> type;
	private Method postConstruct;
	private Method preDestroy;
	private Map<Field, BeanBox> fieldInjects;
	private Map<Method, BeanBox[]> methodInjects;

	public void setBeanClass(Class<?> beanClass) {
		this.beanClass = beanClass;
	}

	public Class<?> getBeanClass() {
		return beanClass;
	}

	public void setSingleton(boolean singleton) {
		this.singleton = singleton;
	}

	public boolean isSingleton() {
		return singleton;
	}

	public void setTarget(Object target) {
		this.target = target;
	}

	public Object getTarget() {
		return target;
	}

	public void setPureValue(boolean pureValue) {
		this.pureValue = pureValue;
	}

	public boolean isPureValue() {
		return pureValue;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	public boolean isRequired() {
		return required;
	}

	public void setConstructor(Constructor<?> constructor) {
		this.constructor = constructor;
	}

	public Constructor<?> getConstructor() {
		return constructor;
	}

	public void setConstructorParams(BeanBox[] constructorParams) {
		this.constructorParams = constructorParams;
	}

	public BeanBox[] getConstructorParams() {
		return constructorParams;
	}

	public void setType(Class<?> type) {
		this.type = type;
	}

	public Class<?> getType() {
		return type;
	}

	public void setPostConstruct(Method postConstruct) {
		this.postConstruct = postConstruct;
	}

	public Method getPostConstruct() {
		return postConstruct;
	}

	public void setPreDestroy(Method preDestroy) {
		this.preDestroy = preDestroy;
	}

	public Method getPreDestroy() {
		return preDestroy;
	}

	public Map<Field, BeanBox> getFieldInjects() {
		return fieldInjects;
	}

	public Map<Method, BeanBox[]> getMethodInjects() {
		return methodInjects;
	}

	public void addBeanAop(Object aop, String rule) {
	}

	public void addMethodAop(Object aop, Method m) {
	}

	public void checkOrCreateFieldInjects() {
		if (fieldInjects == null)
			fieldInjects = new HashMap<>();
	}

	public void checkOrCreateMethodInjects() {
		if (methodInjects == null)
			methodInjects = new HashMap<>();
	}
}

class BeanBoxContext {
	public boolean allowSpringJsrAnnotation = false;

	public boolean isAllowAnnotation() {
		return true;
	}
}

class BeanBoxException extends RuntimeException {
	public static Object throwEX(String msg) {
		throw new RuntimeException(msg);
	}
}

class ReflectionUtils {
	public static List<Field> getSelfAndSuperClassFields(Class<?> c) {
		List<Field> fields = new ArrayList<>();
		for (Field f : c.getDeclaredFields()) {
			fields.add(f);
		}
		return fields;
	}

	public static Method[] getAllDeclaredMethods(Class<?> c) {
		return c.getDeclaredMethods();
	}

	public static void makeAccessible(AccessibleObject ao) {
		ao.setAccessible(true);
	}
}

class BeanBoxUtils {
	public static boolean checkAnnoExist(Class<?> clazz, Class<?> annoClass) {
		return clazz.isAnnotationPresent((Class<? extends java.lang.annotation.Annotation>) annoClass);
	}

	public static Map<String, Object> getAnnoAsMap(Class<?> clazz, String name) {
		return null;
	}

	public static Object[] getInjectAnnotationAsArray(Object target, boolean allowSpringJsrAnno) {
		return null;
	}

	public static Map<String, Object> changeAnnotationValuesToMap(Annotation anno) {
		Map<String, Object> map = new HashMap<>();
		if (anno instanceof AOP) {
			AOP aop = (AOP) anno;
			map.put("value", aop.value());
			map.put("method", aop.method());
		}
		return map;
	}

	public static BeanBox[] getParameterInjectAsBeanBoxArray(AccessibleObject ao, boolean allowSpring) {
		return new BeanBox[0];
	}

	
	// ORIGINAL CODESEARCHNET METHOD — START
	
	private static BeanBox doCreateBeanBox(BeanBoxContext ctx, Class<?> clazz) {
		BeanBox box = new BeanBox();
		box.setBeanClass(clazz);
		box.setSingleton(true);

		if (!ctx.isAllowAnnotation())
			return box;
		boolean allowSpringJsrAnno = ctx.allowSpringJsrAnnotation;

		
		if (checkAnnoExist(clazz, PROTOTYPE.class))
			box.setSingleton(false);
		else if (allowSpringJsrAnno) {
			Map<String, Object> m = getAnnoAsMap(clazz, "org.springframework.context.annotation.Scope");
			if (m != null)
				for (Entry<String, Object> entry : m.entrySet())
					if ("value".equals(entry.getKey())) {
						if ("prototype".equalsIgnoreCase(String.valueOf(entry.getValue())))
							box.setSingleton(false);
						else if ("singleton".equalsIgnoreCase(String.valueOf(entry.getValue())))
							box.setSingleton(true);
						else
							BeanBoxException.throwEX("'prototype' or 'singleton' required in @Scope annotation");
					}
		}

		
		Object[] v = getInjectAnnotationAsArray(clazz, allowSpringJsrAnno);
		if (v != null) {
			box.setTarget(v[0]);
			box.setPureValue((Boolean) v[1]);
			box.setRequired((Boolean) v[2]);
		}

		
		Annotation[] annos = clazz.getAnnotations();
		for (Annotation anno : annos) {
			if (anno.annotationType().isAnnotationPresent(AOP.class)) {
				Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
				Object aop = annoMap.get("value");
				String methodNameRule = (String) annoMap.get("method");
				if (methodNameRule != null && methodNameRule.length() > 0 && aop != null)
					box.addBeanAop(aop, methodNameRule);
			}
		}

		
		Constructor<?>[] constrs = clazz.getConstructors();
		for (Constructor<?> constr : constrs) {
			v = getInjectAnnotationAsArray(constr, allowSpringJsrAnno);
			if (v != null) {
				box.setBeanClass(clazz);
				if (v[0] != null && EMPTY.class != v[0]) {
					BeanBox inject = new BeanBox();
					inject.setTarget(v[0]);
					inject.setPureValue((Boolean) v[1]);
					inject.setRequired((Boolean) v[2]);
					inject.setType(constr.getParameterTypes()[0]);
					box.setConstructor(constr);
					box.setConstructorParams(new BeanBox[] { inject });
				} else { 
					BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(constr, allowSpringJsrAnno);
					box.setConstructor(constr);
					box.setConstructorParams(paramInjects);
				}
			}
		}

		
		
		for (Field f : ReflectionUtils.getSelfAndSuperClassFields(clazz)) {
			v = getInjectAnnotationAsArray(f, allowSpringJsrAnno);
			if (v != null) {
				box.checkOrCreateFieldInjects();
				BeanBox inject = new BeanBox();
				inject.setTarget(v[0]);
				inject.setPureValue((Boolean) v[1]);
				inject.setRequired((Boolean) v[2]);
				inject.setType(f.getType());
				ReflectionUtils.makeAccessible(f);
				box.getFieldInjects().put(f, inject);
			}
		}

		
		Method[] methods = ReflectionUtils.getAllDeclaredMethods(clazz);
		for (Method m : methods) {
			
			if (m.getAnnotation(POSTCONSTRUCT.class) != null || m.getAnnotation(PostConstruct.class) != null) {
				if (m.getParameterTypes().length > 0)
					BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
				ReflectionUtils.makeAccessible(m);
				box.setPostConstruct(m);
			}
			if (m.getAnnotation(PREDESTROY.class) != null || m.getAnnotation(PreDestroy.class) != null) {
				if (m.getParameterTypes().length > 0)
					BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
				ReflectionUtils.makeAccessible(m);
				box.setPreDestroy(m);
			}

			
			Annotation[] mtdAnnos = m.getAnnotations();
			for (Annotation anno : mtdAnnos)
				if (anno.annotationType().isAnnotationPresent(AOP.class)) {
					Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
					Object aop = annoMap.get("value");
					if (aop != null)
						box.addMethodAop(aop, m);
				}

			
			v = getInjectAnnotationAsArray(m, allowSpringJsrAnno);
			if (v != null) {
				ReflectionUtils.makeAccessible(m);
				BeanBox oneParam = new BeanBox();
				oneParam.setTarget(v[0]);
				oneParam.setPureValue((Boolean) v[1]);
				oneParam.setRequired((Boolean) v[2]);
				boolean haveOneParameter = v[0] != null && EMPTY.class != v[0];
				if (haveOneParameter)
					oneParam.setType(m.getParameterTypes()[0]); 
				
				box.checkOrCreateMethodInjects();
				if (haveOneParameter) 
					box.getMethodInjects().put(m, new BeanBox[] { oneParam });
				else { 
					BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(m, allowSpringJsrAnno);
					box.getMethodInjects().put(m, paramInjects);
				}
			}
		}
		return box;

	}
	
	// ORIGINAL CODESEARCHNET METHOD — END
	

	public static BeanBox invokeDoCreateBeanBox(BeanBoxContext ctx, Class<?> clazz) throws Exception {
		Method m = BeanBoxUtils.class.getDeclaredMethod("doCreateBeanBox", BeanBoxContext.class, Class.class);
		m.setAccessible(true);
		return (BeanBox) m.invoke(null, ctx, clazz);
	}
}

public class method_1_jbeanbox_gemini {
	public static void main(String[] args) {
		System.out.println("=== Executing Reconstructed Method 1: BeanBoxUtils.doCreateBeanBox ===");
		try {
			BeanBoxContext context = new BeanBoxContext();
			BeanBox box = BeanBoxUtils.invokeDoCreateBeanBox(context, SampleBean.class);

			System.out.println("BeanBox successfully created for class: " + box.getBeanClass().getName());
			System.out.println("Is Singleton (should be false due to @PROTOTYPE): " + box.isSingleton());
			System.out.println("Post-Construct method configured: "
					+ (box.getPostConstruct() != null ? box.getPostConstruct().getName() : "None"));
			System.out.println("Pre-Destroy method configured: "
					+ (box.getPreDestroy() != null ? box.getPreDestroy().getName() : "None"));
			System.out.println("Execution completed");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}