


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_3_jbeanbox_gemini<V> {

    public static class Type {
        private String descriptor;
        public Type(String descriptor) { this.descriptor = descriptor; }
        public static Type getReturnType(String desc) { return new Type("V"); }
        public static Type[] getArgumentTypes(String desc) { return new Type[0]; }
        public static Type getObjectType(String internalName) { return new Type(internalName); }
        public int getSize() { return 1; }
    }

    public static class LabelNode {}

    public static class AbstractInsnNode {
        public static final int LABEL = 0;
        public static final int LINE = 1;
        public static final int FRAME = 2;
        public int getOpcode() { return 0; }
        public int getType() { return LABEL; }
    }

    public static class JumpInsnNode extends AbstractInsnNode {
        public LabelNode label;
    }

    public static class VarInsnNode extends AbstractInsnNode {
        public int var;
    }

    public static class IincInsnNode extends AbstractInsnNode {
        public int var;
    }

    public static class LookupSwitchInsnNode extends AbstractInsnNode {
        public LabelNode dflt;
        public List<LabelNode> labels = new ArrayList<LabelNode>();
    }

    public static class TableSwitchInsnNode extends AbstractInsnNode {
        public LabelNode dflt;
        public List<LabelNode> labels = new ArrayList<LabelNode>();
    }

    public static class TryCatchBlockNode {
        public AbstractInsnNode start;
        public AbstractInsnNode end;
        public LabelNode handler;
        public String type;
    }

    public static class InsnList {
        private List<AbstractInsnNode> list = new ArrayList<AbstractInsnNode>();
        public int size() { return list.size(); }
        public AbstractInsnNode get(int index) { return list.get(index); }
        public int indexOf(Object node) { return list.indexOf(node); }
    }

    public static class MethodNode {
        public int access;
        public int maxLocals = 4;
        public int maxStack = 4;
        public String desc = "()V";
        public InsnList instructions = new InsnList();
        public List<TryCatchBlockNode> tryCatchBlocks = new ArrayList<TryCatchBlockNode>();
    }

    public static class Subroutine {
        public LabelNode start;
        public List<JumpInsnNode> callers = new ArrayList<JumpInsnNode>();
        public boolean[] access;
        public Subroutine(LabelNode start, int maxLocals, AbstractInsnNode caller) {
            this.start = start;
            this.access = new boolean[maxLocals];
            if (caller instanceof JumpInsnNode) callers.add((JumpInsnNode) caller);
        }
        public Subroutine copy() { return this; }
    }

    public static class Frame<T> {
        public Frame<T> init(Frame<T> f) { return this; }
        public void execute(AbstractInsnNode insn, Interpreter<T> interp) {}
        public void setReturn(T v) {}
        public void setLocal(int index, T v) {}
        public void clearStack() {}
        public void push(T v) {}
    }

    public interface Interpreter<T> {
        T newValue(Type type);
    }

    public static class AnalyzerException extends Exception {
        public AbstractInsnNode node;
        public AnalyzerException(AbstractInsnNode node, String msg) { super(msg); this.node = node; }
        public AnalyzerException(AbstractInsnNode node, String msg, Throwable cause) { super(msg, cause); this.node = node; }
    }

    protected static final int ACC_ABSTRACT = 0x0400;
    protected static final int ACC_NATIVE = 0x0100;
    protected static final int ACC_STATIC = 0x0008;
    protected static final int GOTO = 167;
    protected static final int JSR = 168;
    protected static final int RET = 169;
    protected static final int IRETURN = 172;
    protected static final int RETURN = 177;
    protected static final int ATHROW = 191;
    protected static final int LLOAD = 22;
    protected static final int DLOAD = 24;
    protected static final int LSTORE = 55;
    protected static final int DSTORE = 57;

    protected Frame<V>[] frames;
    protected int n;
    protected InsnList insns;
    protected List<TryCatchBlockNode>[] handlers;
    protected Subroutine[] subroutines;
    protected boolean[] queued;
    protected int[] queue;
    protected int top;
    protected Interpreter<V> interpreter;

    public method_3_jbeanbox_gemini(Interpreter<V> interpreter) {
        this.interpreter = interpreter;
    }

    protected void findSubroutine(int pos, Subroutine sub, List<AbstractInsnNode> calls) {}
    protected Frame<V> newFrame(int locals, int stack) { return new Frame<V>(); }
    protected void init(String owner, MethodNode m) {}
    protected void merge(int insn, Frame<V> frame, Subroutine sub) {}
    protected void merge(int call, Frame<V> f1, Frame<V> f2, Subroutine s1, boolean[] a1) {}
    protected void newControlFlowEdge(int source, int target) {}
    protected boolean newControlFlowExceptionEdge(int source, TryCatchBlockNode tcb) { return true; }


// ORIGINAL CODESEARCHNET METHOD — START

public Frame<V>[] analyze(final String owner, final MethodNode m)
            throws AnalyzerException {
        if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) != 0) {
            frames = (Frame<V>[]) new Frame<?>[0];
            return frames;
        }
        n = m.instructions.size();
        insns = m.instructions;
        handlers = (List<TryCatchBlockNode>[]) new List<?>[n];
        frames = (Frame<V>[]) new Frame<?>[n];
        subroutines = new Subroutine[n];
        queued = new boolean[n];
        queue = new int[n];
        top = 0;

        
        for (int i = 0; i < m.tryCatchBlocks.size(); ++i) {
            TryCatchBlockNode tcb = m.tryCatchBlocks.get(i);
            int begin = insns.indexOf(tcb.start);
            int end = insns.indexOf(tcb.end);
            for (int j = begin; j < end; ++j) {
                List<TryCatchBlockNode> insnHandlers = handlers[j];
                if (insnHandlers == null) {
                    insnHandlers = new ArrayList<TryCatchBlockNode>();
                    handlers[j] = insnHandlers;
                }
                insnHandlers.add(tcb);
            }
        }

        
        Subroutine main = new Subroutine(null, m.maxLocals, null);
        List<AbstractInsnNode> subroutineCalls = new ArrayList<AbstractInsnNode>();
        Map<LabelNode, Subroutine> subroutineHeads = new HashMap<LabelNode, Subroutine>();
        findSubroutine(0, main, subroutineCalls);
        while (!subroutineCalls.isEmpty()) {
            JumpInsnNode jsr = (JumpInsnNode) subroutineCalls.remove(0);
            Subroutine sub = subroutineHeads.get(jsr.label);
            if (sub == null) {
                sub = new Subroutine(jsr.label, m.maxLocals, jsr);
                subroutineHeads.put(jsr.label, sub);
                findSubroutine(insns.indexOf(jsr.label), sub, subroutineCalls);
            } else {
                sub.callers.add(jsr);
            }
        }
        for (int i = 0; i < n; ++i) {
            if (subroutines[i] != null && subroutines[i].start == null) {
                subroutines[i] = null;
            }
        }

        
        Frame<V> current = newFrame(m.maxLocals, m.maxStack);
        Frame<V> handler = newFrame(m.maxLocals, m.maxStack);
        current.setReturn(interpreter.newValue(Type.getReturnType(m.desc)));
        Type[] args = Type.getArgumentTypes(m.desc);
        int local = 0;
        if ((m.access & ACC_STATIC) == 0) {
            Type ctype = Type.getObjectType(owner);
            current.setLocal(local++, interpreter.newValue(ctype));
        }
        for (int i = 0; i < args.length; ++i) {
            current.setLocal(local++, interpreter.newValue(args[i]));
            if (args[i].getSize() == 2) {
                current.setLocal(local++, interpreter.newValue(null));
            }
        }
        while (local < m.maxLocals) {
            current.setLocal(local++, interpreter.newValue(null));
        }
        merge(0, current, null);

        init(owner, m);

        
        while (top > 0) {
            int insn = queue[--top];
            Frame<V> f = frames[insn];
            Subroutine subroutine = subroutines[insn];
            queued[insn] = false;

            AbstractInsnNode insnNode = null;
            try {
                insnNode = m.instructions.get(insn);
                int insnOpcode = insnNode.getOpcode();
                int insnType = insnNode.getType();

                if (insnType == AbstractInsnNode.LABEL
                        || insnType == AbstractInsnNode.LINE
                        || insnType == AbstractInsnNode.FRAME) {
                    merge(insn + 1, f, subroutine);
                    newControlFlowEdge(insn, insn + 1);
                } else {
                    current.init(f).execute(insnNode, interpreter);
                    subroutine = subroutine == null ? null : subroutine.copy();

                    if (insnNode instanceof JumpInsnNode) {
                        JumpInsnNode j = (JumpInsnNode) insnNode;
                        if (insnOpcode != GOTO && insnOpcode != JSR) {
                            merge(insn + 1, current, subroutine);
                            newControlFlowEdge(insn, insn + 1);
                        }
                        int jump = insns.indexOf(j.label);
                        if (insnOpcode == JSR) {
                            merge(jump, current, new Subroutine(j.label,
                                    m.maxLocals, j));
                        } else {
                            merge(jump, current, subroutine);
                        }
                        newControlFlowEdge(insn, jump);
                    } else if (insnNode instanceof LookupSwitchInsnNode) {
                        LookupSwitchInsnNode lsi = (LookupSwitchInsnNode) insnNode;
                        int jump = insns.indexOf(lsi.dflt);
                        merge(jump, current, subroutine);
                        newControlFlowEdge(insn, jump);
                        for (int j = 0; j < lsi.labels.size(); ++j) {
                            LabelNode label = lsi.labels.get(j);
                            jump = insns.indexOf(label);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                        }
                    } else if (insnNode instanceof TableSwitchInsnNode) {
                        TableSwitchInsnNode tsi = (TableSwitchInsnNode) insnNode;
                        int jump = insns.indexOf(tsi.dflt);
                        merge(jump, current, subroutine);
                        newControlFlowEdge(insn, jump);
                        for (int j = 0; j < tsi.labels.size(); ++j) {
                            LabelNode label = tsi.labels.get(j);
                            jump = insns.indexOf(label);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                        }
                    } else if (insnOpcode == RET) {
                        if (subroutine == null) {
                            throw new AnalyzerException(insnNode,
                                    "RET instruction outside of a sub routine");
                        }
                        for (int i = 0; i < subroutine.callers.size(); ++i) {
                            JumpInsnNode caller = subroutine.callers.get(i);
                            int call = insns.indexOf(caller);
                            if (frames[call] != null) {
                                merge(call + 1, frames[call], current,
                                        subroutines[call], subroutine.access);
                                newControlFlowEdge(insn, call + 1);
                            }
                        }
                    } else if (insnOpcode != ATHROW
                            && (insnOpcode < IRETURN || insnOpcode > RETURN)) {
                        if (subroutine != null) {
                            if (insnNode instanceof VarInsnNode) {
                                int var = ((VarInsnNode) insnNode).var;
                                subroutine.access[var] = true;
                                if (insnOpcode == LLOAD || insnOpcode == DLOAD
                                        || insnOpcode == LSTORE
                                        || insnOpcode == DSTORE) {
                                    subroutine.access[var + 1] = true;
                                }
                            } else if (insnNode instanceof IincInsnNode) {
                                int var = ((IincInsnNode) insnNode).var;
                                subroutine.access[var] = true;
                            }
                        }
                        merge(insn + 1, current, subroutine);
                        newControlFlowEdge(insn, insn + 1);
                    }
                }

                List<TryCatchBlockNode> insnHandlers = handlers[insn];
                if (insnHandlers != null) {
                    for (int i = 0; i < insnHandlers.size(); ++i) {
                        TryCatchBlockNode tcb = insnHandlers.get(i);
                        Type type;
                        if (tcb.type == null) {
                            type = Type.getObjectType("java/lang/Throwable");
                        } else {
                            type = Type.getObjectType(tcb.type);
                        }
                        int jump = insns.indexOf(tcb.handler);
                        if (newControlFlowExceptionEdge(insn, tcb)) {
                            handler.init(f);
                            handler.clearStack();
                            handler.push(interpreter.newValue(type));
                            merge(jump, handler, subroutine);
                        }
                    }
                }
            } catch (AnalyzerException e) {
                throw new AnalyzerException(e.node, "Error at instruction "
                        + insn + ": " + e.getMessage(), e);
            } catch (Exception e) {
                throw new AnalyzerException(insnNode, "Error at instruction "
                        + insn + ": " + e.getMessage(), e);
            }
        }

        return frames;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting Analyzer.analyze Simulation...\n");
        method_3_jbeanbox_gemini<Object> analyzer = new method_3_jbeanbox_gemini<Object>(new Interpreter<Object>() {
            public Object newValue(Type type) { return new Object(); }
        });
        MethodNode method = new MethodNode();
        try {
            Frame<Object>[] result = analyzer.analyze("java/lang/Object", method);
            System.out.println("Analysis completed successfully, frames analyzed: " + result.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Execution Complete.");
    }
}