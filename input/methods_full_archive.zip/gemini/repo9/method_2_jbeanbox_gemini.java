import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class EMPTY {}

class BeanBoxException extends RuntimeException {
    public BeanBoxException(String msg) { super(msg); }
    public static void assureNotNull(Object o, String msg) {
        if (o == null) {
            throw new RuntimeException(msg);
        }
    }
    public static Object throwEX(String msg) {
        throw new RuntimeException(msg);
    }
    public static Object throwEX(Throwable e) {
        throw new RuntimeException(e);
    }
    public static Object throwEX(String msg, Throwable e) {
        throw new RuntimeException(msg, e);
    }
}

class ValueTranslator {
    public Object translate(String value, Class<?> type) {
        return value;
    }
}

class Caller {
    public Caller(BeanBoxContext ctx, boolean required, Set<Object> history, Object bean) {}
}

class AopUtils {
    public static Object createProxyBean(Class<?> clazz, BeanBox box, BeanBoxContext ctx) {
        return new Object();
    }
}

class ReflectionUtils {
    public static void invokeMethod(Method m, Object target, Object... args) {
        try {
            m.setAccessible(true);
            m.invoke(target, args);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static void setField(Field f, Object target, Object val) {
        try {
            f.setAccessible(true);
            f.set(target, val);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}

class BeanBox {
    private Class<?> beanClass = SampleTargetBean.class;
    private boolean singleton = true;
    private Object target;
    private boolean pureValue = false;
    private boolean required = true;
    private Object singletonId = "sampleId";
    private Method createMethod;
    private Method configMethod;
    private Method postConstruct;
    private Method preDestroy;
    private java.lang.reflect.Constructor<?> constructor;
    private BeanBox[] constructorParams;
    private Map<Field, BeanBox> fieldInjects;
    private Map<Method, BeanBox[]> methodInjects;
    private List<Object[]> aopRules;
    private List<Object> methodAops;

    public boolean isSingleton() { return singleton; }
    public boolean isPureValue() { return pureValue; }
    Object getTarget() { return target; }
    boolean isRequired() { return required; }
    Class<?> getType() { return null; }
    Class<?> getBeanClass() { return beanClass; }
    List<Object[]> getAopRules() { return aopRules; }
    List<Object> getMethodAops() { return methodAops; }
    Object getSingletonId() { return singletonId; }
    Method getCreateMethod() { return createMethod; }
    Method getConfigMethod() { return configMethod; }
    Method getPostConstruct() { return postConstruct; }
    Method getPreDestroy() { return preDestroy; }
    java.lang.reflect.Constructor<?> getConstructor() { return constructor; }
    BeanBox[] getConstructorParams() { return constructorParams; }
    Map<Field, BeanBox> getFieldInjects() { return fieldInjects; }
    Map<Method, BeanBox[]> getMethodInjects() { return methodInjects; }

    public void setPostConstruct(Method m) { this.postConstruct = m; }
}

class SampleTargetBean {
    public void postConstructMethod() {}
}

class BeanBoxContext {
    protected Map<Object, Object> singletonCache = new HashMap<>();
    protected ValueTranslator valueTranslator = new ValueTranslator();

    public List<Object[]> getAopRules() { return null; }

    public Object getBean(Object target, boolean required, Set<Object> history) {
        return null;
    }

    public Object notfoundOrException(Object target, boolean required) {
        if (required) {
            throw new RuntimeException("Bean not found");
        }
        return EMPTY.class;
    }

    public Object[] param2RealObjects(BeanBoxContext ctx, Set<Object> history, BeanBox[] params) {
        return new Object[0];
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private Object getBeanFromBox(BeanBox box, boolean required, Set<Object> history) {
		
		BeanBoxException.assureNotNull(box, "Fail to build instance for a null beanBox");
		Object bean = null;
		if (box.isSingleton()) { 
			bean = singletonCache.get(box);
			if (bean != null)
				return bean;
		}

		if (box.isPureValue()) 
			return box.getTarget();
		if (box.getTarget() != null) {
			if (EMPTY.class != box.getTarget())
				return getBean(box.getTarget(), box.isRequired(), history);
			if (box.getType() != null)
				return getBean(box.getType(), box.isRequired(), history);
			else
				return notfoundOrException(box.getTarget(), box.isRequired());
		}

		boolean aopFound = false;
		if (box.getAopRules() != null || box.getMethodAops() != null)
			aopFound = true;
		else if (this.getAopRules() != null && box.getBeanClass() != null)
			for (Object[] aops : this.getAopRules()) 
				if (BeanBoxUtils.nameMatch((String) aops[1], box.getBeanClass().getName())) {
					aopFound = true;
					break;
				}
		if (aopFound)
			bean = AopUtils.createProxyBean(box.getBeanClass(), box, this);
		else if (box.getCreateMethod() != null) 
			try {
				Method m = box.getCreateMethod();
				if (m.getParameterTypes().length == 1) {
					bean = m.invoke(box, new Caller(this, required, history, null));
				} else if (m.getParameterTypes().length == 0)
					bean = m.invoke(box);
				else
					BeanBoxException.throwEX("Create method can only have 0 or 1 parameter");
				BeanBoxException.assureNotNull(bean, "Create method created a null object.");
			} catch (Exception e) {
				return BeanBoxException.throwEX(e);
			}
		else if (box.getConstructor() != null) { 
			if (box.getConstructorParams() != null && box.getConstructorParams().length > 0) {
				Object[] initargs = param2RealObjects(this, history, box.getConstructorParams());
				try {
					bean = box.getConstructor().newInstance(initargs);
				} catch (Exception e) {
					return BeanBoxException.throwEX(e);
				}
			} else 
				try {
					bean = box.getConstructor().newInstance();
				} catch (Exception e) {
					return BeanBoxException.throwEX(e);
				}
		} else if (box.getBeanClass() != null) { 
			if (EMPTY.class == box.getBeanClass())
				return notfoundOrException(EMPTY.class, required);
			try {
				bean = box.getBeanClass().newInstance();
			} catch (Exception e) {
				BeanBoxException.throwEX("Failed to call 0 parameter constructor of: " + box.getBeanClass(), e);
			}
		} else
			return notfoundOrException(null, required); 

		

		
		if (box.isSingleton()) {
			Object id = box.getSingletonId();
			if (id != null)
				singletonCache.put(box, bean);
		} 

		if (box.getConfigMethod() != null) {
			try {
				Method m = box.getConfigMethod();
				if (m.getParameterTypes().length == 2)
					m.invoke(box, bean, new Caller(this, required, history, bean));
				else if (m.getParameterTypes().length == 1)
					m.invoke(box, bean);
				else
					BeanBoxException.throwEX("Config method can only have 1 or 2 parameters");
			} catch (Exception e) {
				return BeanBoxException.throwEX(e);
			}
		}

		if (box.getPostConstruct() != null) 
			ReflectionUtils.invokeMethod(box.getPostConstruct(), bean);

		if (box.getFieldInjects() != null) 
			for (Entry<Field, BeanBox> entry : box.getFieldInjects().entrySet()) {
				Field f = entry.getKey();
				BeanBox b = entry.getValue();
				Object fieldValue = this.getBeanFromBox(b, false, history);
				if (EMPTY.class == fieldValue) {
					if (b.isRequired())
						BeanBoxException.throwEX("Not found required value for field: " + f.getName() + " in "
								+ f.getDeclaringClass().getName());
				} else {
					if (fieldValue != null && fieldValue instanceof String)
						fieldValue = this.valueTranslator.translate((String) fieldValue, b.getType());
					ReflectionUtils.setField(f, bean, fieldValue);
				}
			}

		if (box.getMethodInjects() != null) { 
			for (Entry<Method, BeanBox[]> methods : box.getMethodInjects().entrySet()) {
				Method m = methods.getKey();
				BeanBox[] paramBoxs = methods.getValue();
				if (paramBoxs != null && paramBoxs.length > 0) {
					Object[] methodParams = param2RealObjects(this, history, paramBoxs);
					ReflectionUtils.invokeMethod(m, bean, methodParams);
				} else 
					ReflectionUtils.invokeMethod(m, bean);
			}
		}
		return bean;
	}
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public Object invokeGetBeanFromBox(BeanBox box, boolean required, Set<Object> history) throws Exception {
        Method m = BeanBoxContext.class.getDeclaredMethod("getBeanFromBox", BeanBox.class, boolean.class, Set.class);
        m.setAccessible(true);
        return m.invoke(this, box, required, history);
    }
}

class BeanBoxUtils {
    public static boolean nameMatch(String rule, String name) {
        return true;
    }
}

public class method_2_jbeanbox_gemini {
    public static void main(String[] args) {
        System.out.println("=== Executing Reconstructed Method 2: BeanBoxContext.getBeanFromBox ===");
        try {
            BeanBoxContext context = new BeanBoxContext();
            BeanBox box = new BeanBox();
            box.setPostConstruct(SampleTargetBean.class.getMethod("postConstructMethod"));

            Object instance = context.invokeGetBeanFromBox(box, true, new HashSet<>());
            System.out.println("Retrieved Bean instance class: " + instance.getClass().getName());
            System.out.println("Singleton cache verification: " + (context.singletonCache.get(box) != null));
            System.out.println("Execution completed");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}