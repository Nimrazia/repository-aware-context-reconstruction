import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public class method_3_jeppetto_gemini {

    

    public static class Projection {
        private String projectionType = "ALL";
        public String getProjectionType() { return projectionType; }
        public void setProjectionType(String type) { this.projectionType = type; }
    }

    public static class KeySchemaElement {
        private String attributeName;
        public KeySchemaElement(String name) { this.attributeName = name; }
        public String getAttributeName() { return attributeName; }
    }

    public static class LocalSecondaryIndexDescription {
        private String indexName;
        private List<KeySchemaElement> keySchema = new ArrayList<>();
        private Projection projection = new Projection();

        public LocalSecondaryIndexDescription(String name) { this.indexName = name; }
        public String getIndexName() { return indexName; }
        public List<KeySchemaElement> getKeySchema() { return keySchema; }
        public Projection getProjection() { return projection; }
    }

    public static class GlobalSecondaryIndexDescription {
        private String indexName;
        private List<KeySchemaElement> keySchema = new ArrayList<>();
        private Projection projection = new Projection();

        public GlobalSecondaryIndexDescription(String name) { this.indexName = name; }
        public String getIndexName() { return indexName; }
        public List<KeySchemaElement> getKeySchema() { return keySchema; }
        public Projection getProjection() { return projection; }
    }

    public static class TableDescription {
        private List<LocalSecondaryIndexDescription> lsis;
        private List<GlobalSecondaryIndexDescription> gsis;

        public List<LocalSecondaryIndexDescription> getLocalSecondaryIndexes() { return lsis; }
        public void setLocalSecondaryIndexes(List<LocalSecondaryIndexDescription> lsis) { this.lsis = lsis; }
        
        public List<GlobalSecondaryIndexDescription> getGlobalSecondaryIndexes() { return gsis; }
        public void setGlobalSecondaryIndexes(List<GlobalSecondaryIndexDescription> gsis) { this.gsis = gsis; }
    }

    

    public static class ProjectionExpressionBuilder {
        public boolean isCoveredBy(Projection p) { return true; }
    }

    public static class IndexData {
        public String indexName;
        public List<String> keyFields;
        public boolean projectsOverEntity;

        public IndexData(String indexName, List<String> keyFields, boolean projectsOverEntity) {
            this.indexName = indexName;
            this.keyFields = keyFields;
            this.projectsOverEntity = projectsOverEntity;
        }
    }

    public static class Pair<K, V> {
        private K first;
        private V second;
        public Pair(K first, V second) { this.first = first; this.second = second; }
        public K getFirst() { return first; }
        public V getSecond() { return second; }
    }

    

    private String hashKeyField = "id";
    private String rangeKeyField = "timestamp";

    private Pair<String, String> getKeyAttributeNames(List<KeySchemaElement> schema) {
        String first = schema.size() > 0 ? schema.get(0).getAttributeName() : null;
        String second = schema.size() > 1 ? schema.get(1).getAttributeName() : null;
        return new Pair<>(first, second);
    }


// ORIGINAL CODESEARCHNET METHOD — START

    private Map<String, Map<String, IndexData>> processIndexes(TableDescription tableDescription,
                                                               ProjectionExpressionBuilder projectionExpressionBuilder,
                                                               IndexData baseIndexData) {
        
        Map<String, IndexData> localIndexes;
        List<LocalSecondaryIndexDescription> localSecondaryIndexes = tableDescription.getLocalSecondaryIndexes();
        if (localSecondaryIndexes != null) {
            localIndexes = new HashMap<>(localSecondaryIndexes.size() + 2);

            
            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);

            for (LocalSecondaryIndexDescription description : localSecondaryIndexes) {
                String indexField = getKeyAttributeNames(description.getKeySchema()).getSecond();
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>(baseIndexData.keyFields);
                keyFields.add(indexField);

                localIndexes.put(indexField, new IndexData(description.getIndexName(), keyFields, projectsOverEntity));
            }
        } else if (rangeKeyField != null) {
            localIndexes = new HashMap<>(2);

            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);
        } else {
            localIndexes = Collections.singletonMap(null, baseIndexData);
        }

        
        List<GlobalSecondaryIndexDescription> globalSecondaryIndexes = tableDescription.getGlobalSecondaryIndexes();
        if (globalSecondaryIndexes != null) {
            Map<String, Map<String, IndexData>> indexes = new HashMap<>(globalSecondaryIndexes.size() + 1);

            for (GlobalSecondaryIndexDescription description : globalSecondaryIndexes) {
                Pair<String, String> indexFields = getKeyAttributeNames(description.getKeySchema());
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>();
                keyFields.add(indexFields.getFirst());
                if (indexFields.getSecond() != null) {
                    keyFields.add(indexFields.getSecond());
                }
                keyFields.add(hashKeyField);
                if (rangeKeyField != null) {
                    keyFields.add(rangeKeyField);
                }

                IndexData indexData = new IndexData(description.getIndexName(), keyFields, projectsOverEntity);

                if (!indexes.containsKey(indexFields.getFirst())) {
                    indexes.put(indexFields.getFirst(), new HashMap<String, IndexData>());
                }

                indexes.get(indexFields.getFirst()).put(indexFields.getSecond(), indexData);

                
                
                IndexData noRangeKeyIndexData = indexes.get(indexFields.getFirst()).get(null);
                if (noRangeKeyIndexData == null || !noRangeKeyIndexData.projectsOverEntity) {
                    indexes.get(indexFields.getFirst()).put(null, indexData);
                }
            }

            indexes.put(hashKeyField, localIndexes);

            return indexes;
        } else {
            return Collections.singletonMap(hashKeyField, localIndexes);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println("  DynamoDBQueryModelDAO.processIndexes   ");
        System.out.println("=========================================\n");

        method_3_jeppetto_gemini dao = new method_3_jeppetto_gemini();

        
        TableDescription desc = new TableDescription();

        
        List<LocalSecondaryIndexDescription> lsis = new ArrayList<>();
        LocalSecondaryIndexDescription lsi = new LocalSecondaryIndexDescription("LSI_1");
        lsi.getKeySchema().add(new KeySchemaElement("id"));
        lsi.getKeySchema().add(new KeySchemaElement("category"));
        lsis.add(lsi);
        desc.setLocalSecondaryIndexes(lsis);

        
        List<GlobalSecondaryIndexDescription> gsis = new ArrayList<>();
        GlobalSecondaryIndexDescription gsi = new GlobalSecondaryIndexDescription("GSI_1");
        gsi.getKeySchema().add(new KeySchemaElement("status"));
        gsi.getKeySchema().add(new KeySchemaElement("createdAt"));
        gsis.add(gsi);
        desc.setGlobalSecondaryIndexes(gsis);

        
        List<String> baseKeys = new ArrayList<>();
        baseKeys.add("id");
        baseKeys.add("timestamp");
        IndexData baseData = new IndexData("base", baseKeys, true);

        try {
            Map<String, Map<String, IndexData>> parsedIndexes = dao.processIndexes(desc, null, baseData);
            
            System.out.println("[SUCCESS] Extracted " + parsedIndexes.size() + " hash key index groups.");
            for (Map.Entry<String, Map<String, IndexData>> entry : parsedIndexes.entrySet()) {
                System.out.println(" -> Hash Key: '" + entry.getKey() + "' has " + entry.getValue().size() + " range variations.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\n=========================================");
    }
}