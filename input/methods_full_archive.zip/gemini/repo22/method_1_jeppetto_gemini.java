import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;




public class method_1_jeppetto_gemini {

    private static final Logger logger = Logger.getLogger(method_1_jeppetto_gemini.class.getName());

    

    public interface DBObject {}
    public static class BasicDBObject implements DBObject {}
    public static class BasicDBList implements DBObject {}

    public static class DBObjectUtil {
        public static boolean needsNoConversion(Class<?> clazz) {
            return String.class.isAssignableFrom(clazz) || Number.class.isAssignableFrom(clazz);
        }
    }

    public interface DirtyableDBObjectEnhancer {
        Class<?> getEnhancedClass();
    }

    public static class EnhancerHelper {
        public static DirtyableDBObjectEnhancer getDirtyableDBObjectEnhancer(Class<?> clazz) {
            
            return new DirtyableDBObjectEnhancer() {
                @Override
                public Class<?> getEnhancedClass() {
                    return clazz;
                }
            }; 
        }
    }

    

    private Class<?> rootClass;
    private Map<String, Class<?>> classCache = new HashMap<>();
    private Set<String> EXPLAIN_PATHS_TO_IGNORE = new HashSet<>();

    public method_1_jeppetto_gemini(Class<?> rootClass) {
        this.rootClass = rootClass;
        EXPLAIN_PATHS_TO_IGNORE.add("$id");
    }


// ORIGINAL CODESEARCHNET METHOD — START

    private Class deriveClass1(String path, String lastPathPart, boolean array) {
        Class containerClass;

        if (path.equals(lastPathPart)) {
            containerClass = rootClass;
        } else {
            containerClass = classCache.get(rootClass.getSimpleName() + "." + path.substring(0, path.lastIndexOf('.')));
        }

        if (containerClass != null && DBObject.class.isAssignableFrom(containerClass)) {
            try {
                Method m = containerClass.getMethod("__getPreEnhancedClass");

                containerClass = (Class) m.invoke(null);
            } catch (Exception e) {
                logger.warning("DBObject without __getPreEnhancedClass() method.  Was the container class enhanced?");
            }
        }

        
        
        if (containerClass == null) {
            return array ? BasicDBList.class : BasicDBObject.class;
        }

        Method getter;

        try {
            
            getter = containerClass.getMethod("get" + Character.toUpperCase(lastPathPart.charAt(0)) + lastPathPart.substring(1));
        } catch (NoSuchMethodException e) {
            if (!EXPLAIN_PATHS_TO_IGNORE.contains(lastPathPart) && !lastPathPart.startsWith("__")) {
                logger.warning("No getter for: " + lastPathPart + " (" + e.getMessage() + ")");
            }

            return array ? BasicDBList.class : BasicDBObject.class;
        }

        Type returnType = getter.getGenericReturnType();
        String qualifiedPath = rootClass.getSimpleName() + "." + path;

        if (Class.class.isAssignableFrom(returnType.getClass())) {
            
            Class enhancedClass = EnhancerHelper.getDirtyableDBObjectEnhancer((Class) returnType).getEnhancedClass();

            classCache.put(qualifiedPath, enhancedClass);

            return enhancedClass;
        } else if (ParameterizedType.class.isAssignableFrom(returnType.getClass())) {
            ParameterizedType parameterizedType = (ParameterizedType) returnType;
            Class rawType = (Class) parameterizedType.getRawType();
            Class rawClass;
            Class enhancedClass;

            if (Map.class.isAssignableFrom(rawType)) {
                rawClass = (Class) parameterizedType.getActualTypeArguments()[1];
            } else if (Iterable.class.isAssignableFrom(rawType)) {
                rawClass = (Class) parameterizedType.getActualTypeArguments()[0];
            } else {
                throw new RuntimeException("unknown type: " + rawType);
            }

            classCache.put(qualifiedPath, rawType);

            if (!DBObjectUtil.needsNoConversion(rawClass)) {
                
                enhancedClass = EnhancerHelper.getDirtyableDBObjectEnhancer(rawClass).getEnhancedClass();

                classCache.put(qualifiedPath + ".", enhancedClass);
            }

            return rawType;
        } else {
            throw new RuntimeException("Don't know how to handle: " + qualifiedPath);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    

    
    public static class DummyPerson {
        public String getName() { return "John"; }
        public DummyAddress getAddress() { return new DummyAddress(); }
    }
    public static class DummyAddress {
        public String getStreet() { return "Main St"; }
    }

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println("   MongoDBCallback.deriveClass1 Test     ");
        System.out.println("=========================================\n");

        method_1_jeppetto_gemini callback = new method_1_jeppetto_gemini(DummyPerson.class);

        try {
            System.out.println("Testing resolution of a basic String property (getName):");
            Class<?> resolvedClass = callback.deriveClass1("name", "name", false);
            System.out.println("[SUCCESS] Resolved class: " + resolvedClass.getSimpleName());

            System.out.println("\nTesting resolution of a nested entity property (getAddress):");
            Class<?> addressClass = callback.deriveClass1("address", "address", false);
            System.out.println("[SUCCESS] Resolved class: " + addressClass.getSimpleName());
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\n=========================================");
    }
}