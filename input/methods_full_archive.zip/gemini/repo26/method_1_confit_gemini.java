import java.nio.ByteBuffer;
import java.util.*;




public class method_1_confit_gemini {

    

    public enum TypeEnum {
        SCHEMA_ID, BYTE, SHORT, INTEGER, LONG, FLOAT, DOUBLE, STRING, BOOLEAN, OBJECT,
        BYTE_LIST, SHORT_LIST, INTEGER_LIST, LONG_LIST, FLOAT_LIST, DOUBLE_LIST, STRING_LIST, BOOLEAN_LIST, OBJECT_LIST,
        BYTE_SET, SHORT_SET, INTEGER_SET, LONG_SET, FLOAT_SET, DOUBLE_SET, STRING_SET, BOOLEAN_SET, OBJECT_SET,
        REFERENCE_HOLDER
    }

    public interface UnsafeSetOp {
        TypeEnum getType();
        void set(Object object, Object value);
        Class<?> getObjectClass();
    }

    public static class UniqueId {
        private final Map<Integer, UnsafeSetOp> ops = new HashMap<>();
        public void addOp(int id, UnsafeSetOp op) { ops.put(id, op); }
        public UnsafeSetOp getUnsafeSetOp(int id) { return ops.get(id); }
    }

    public static class ByteBuf {
        private final ByteBuffer buffer;
        public ByteBuf(byte[] data) { this.buffer = ByteBuffer.wrap(data); }
        public ByteBuffer getBuffer() { return buffer; }
    }

    public static class ByteArrayReader {
        private final ByteBuffer buf;
        public ByteArrayReader(ByteBuf byteBuf) { this.buf = byteBuf.getBuffer(); }
        public boolean available() { return buf.hasRemaining(); }
        public int readInt() { return buf.getInt(); }
        public byte readByte() { return buf.get(); }
        public short readShort() { return buf.getShort(); }
        public long readLong() { return buf.getLong(); }
        public float readFloat() { return buf.getFloat(); }
        public double readDouble() { return buf.getDouble(); }
        public boolean readBoolean() { return buf.get() != 0; }
        public String readString(int length) {
            byte[] bytes = new byte[length];
            buf.get(bytes);
            return new String(bytes);
        }
    }

    public interface ConversionService {
        Object convert(String value, Class<?> targetClass);
    }

    public static class ConfigReferenceHolder {
        private final Map<String, List<String>> references;
        public ConfigReferenceHolder(Map<String, List<String>> references) { this.references = references; }
        public Map<String, List<String>> getReferences() { return references; }
    }

    
    private ConversionService conversion = (value, targetClass) -> value;


// ORIGINAL CODESEARCHNET METHOD — START

    private void setProperties(Object object, UniqueId uniqueId, ByteBuf byteBuf) {
        ByteArrayReader reader = new ByteArrayReader(byteBuf);

        while(reader.available()) {
            int id = reader.readInt();
            UnsafeSetOp op = uniqueId.getUnsafeSetOp(id);
            Object value;
            int size;
            ArrayList<Object> list = new ArrayList<>();
            HashSet<Object> set = new HashSet<>();
            switch (op.getType()) {
                case SCHEMA_ID:
                    int length = reader.readInt();
                    value = reader.readString(length);
                    op.set(object, value);
                    break;
                case BYTE:
                    byte byteValue = (byte) reader.readByte();
                    op.set(object, byteValue);
                    break;
                case SHORT:
                    short shortVvalue = (short) reader.readShort();
                    op.set(object, shortVvalue);
                    break;
                case INTEGER:
                    int intValue = reader.readInt();
                    op.set(object, intValue);
                    break;
                case LONG:
                    long longValue = reader.readLong();
                    op.set(object, longValue);
                    break;
                case FLOAT:
                    float floatValue = reader.readFloat();
                    op.set(object, floatValue);
                    break;
                case DOUBLE:
                    double doubleValue = reader.readDouble();
                    op.set(object, doubleValue);
                    break;
                case STRING:
                    length = reader.readInt();
                    value = reader.readString(length);
                    op.set(object, value);
                    break;
                case BOOLEAN:
                    value = reader.readBoolean();
                    op.set(object, value);
                    break;
                case OBJECT:
                    length = reader.readInt();
                    value = conversion.convert(reader.readString(length), op.getObjectClass());
                    op.set(object, value);
                    break;
                case BYTE_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readByte());
                    }
                    op.set(object, list);
                    break;
                case SHORT_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readShort());
                    }
                    op.set(object, list);
                    break;
                case INTEGER_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readInt());
                    }
                    op.set(object, list);
                    break;
                case LONG_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readLong());
                    }
                    op.set(object, list);
                    break;
                case FLOAT_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readFloat());
                    }
                    op.set(object, list);
                    break;
                case DOUBLE_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readDouble());
                    }
                    op.set(object, list);
                    break;
                case STRING_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        length = reader.readInt();
                        list.add(reader.readString(length));
                    }
                    op.set(object, list);
                    break;
                case BOOLEAN_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        list.add(reader.readBoolean());
                    }
                    op.set(object, list);
                    break;
                case OBJECT_LIST:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        length = reader.readInt();
                        String stringValue = reader.readString(length);
                        value = conversion.convert(stringValue, op.getObjectClass());
                        list.add(value);
                    }
                    op.set(object, list);
                    break;
                case BYTE_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readByte());
                    }
                    op.set(object, set);
                    break;
                case SHORT_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readShort());
                    }
                    op.set(object, set);
                    break;
                case INTEGER_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readInt());
                    }
                    op.set(object, set);
                    break;
                case LONG_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readLong());
                    }
                    op.set(object, set);
                    break;
                case FLOAT_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readFloat());
                    }
                    op.set(object, set);
                    break;
                case DOUBLE_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readDouble());
                    }
                    op.set(object, set);
                    break;
                case STRING_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        length = reader.readInt();
                        set.add(reader.readString(length));
                    }
                    op.set(object, set);
                    break;
                case BOOLEAN_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        set.add(reader.readBoolean());
                    }
                    op.set(object, set);
                    break;
                case OBJECT_SET:
                    size = reader.readInt();
                    for (int i = 0; i < size; i++) {
                        length = reader.readInt();
                        String stringValue = reader.readString(length);
                        value = conversion.convert(stringValue, op.getObjectClass());
                        set.add(value);
                    }
                    op.set(object, set);
                    break;
                case REFERENCE_HOLDER:
                    Map<String, List<String>> references = new HashMap<>();
                    ConfigReferenceHolder holder = new ConfigReferenceHolder(references);
                    int numProperties = reader.readInt();
                    for (int i = 0; i < numProperties; i++) {
                        length = reader.readInt();
                        String property = reader.readString(length);
                        int numInstances = reader.readInt();
                        ArrayList<String> instances = new ArrayList<>();
                        for (int j = 0; j < numInstances; j++) {
                            length = reader.readInt();
                            instances.add(reader.readString(length));
                        }
                        references.put(property, instances);
                    }
                    op.set(object, holder);
                    break;
            }
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static class TargetBean {
        private String name;
        private int count;
        public void setName(String name) { this.name = name; }
        public void setCount(int count) { this.count = count; }
        @Override public String toString() { return "TargetBean{name='" + name + "', count=" + count + "}"; }
    }

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" DefaultCacheValueSerializer.setProps    ");
        System.out.println("=========================================\n");

        method_1_confit_gemini serializer = new method_1_confit_gemini();
        TargetBean bean = new TargetBean();
        UniqueId uid = new UniqueId();

        uid.addOp(1, new UnsafeSetOp() {
            public TypeEnum getType() { return TypeEnum.STRING; }
            public void set(Object obj, Object val) { ((TargetBean) obj).setName((String) val); }
            public Class<?> getObjectClass() { return String.class; }
        });
        uid.addOp(2, new UnsafeSetOp() {
            public TypeEnum getType() { return TypeEnum.INTEGER; }
            public void set(Object obj, Object val) { ((TargetBean) obj).setCount((Integer) val); }
            public Class<?> getObjectClass() { return Integer.class; }
        });

        
        ByteBuffer bb = ByteBuffer.allocate(100);
        bb.putInt(1); 
        bb.putInt(4); 
        bb.put("Test".getBytes());
        bb.putInt(2); 
        bb.putInt(99); 
        bb.flip();

        ByteBuf byteBuf = new ByteBuf(java.util.Arrays.copyOf(bb.array(), bb.limit()));

        try {
            serializer.setProperties(bean, uid, byteBuf);
            System.out.println("[SUCCESS] Properties populated successfully: " + bean);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\n=========================================");
    }
}