import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

class Element {
    private String html = "";
    private String text = "";
    private final Map<String, String> attrs = new HashMap<>();
    public Element(String html) { this.html = html; this.text = html; }
    public String html() { return html; }
    public String text() { return text; }
    public Element attr(String key, String val) { attrs.put(key, val); return this; }
    public String attr(String key) { return attrs.getOrDefault(key, "mock_val"); }
    public Elements select(String query) {
        Elements els = new Elements();
        for (int i = 0; i < 7; i++) els.add(new Element("Mocked Match TD"));
        return els;
    }
    public Element first() { return this; }
}
class Elements extends ArrayList<Element> {
    public Elements select(String query) { return new Elements(); }
    public Element first() { return isEmpty() ? null : get(0); }
}

public class method_3_sherdogparser_gemini {
    protected static final Logger logger = Logger.getLogger(method_3_sherdogparser_gemini.class.getName());
    protected static final int FIGHTER1_COLUMN = 0;
    protected static final int METHOD_COLUMN = 1;
    protected static final int FIGHTER2_COLUMN = 2;
    protected static final int ROUND_COLUMN = 3;
    protected static final int TIME_COLUMN = 4;

    public static class SherdogBaseObject {
        private String name;
        private String sherdogUrl;
        public void setName(String name) { this.name = name; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
        public String getName() { return name; }
        public String getSherdogUrl() { return sherdogUrl; }
    }
    public static class Event extends SherdogBaseObject {
        private Date date = new Date();
        private List<Fight> fights = new ArrayList<>();
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
        public void setFights(List<Fight> fights) { this.fights = fights; }
        public List<Fight> getFights() { return fights; }
    }
    public static class Fight {
        private SherdogBaseObject event, fighter1, fighter2;
        private String result, winMethod, winTime;
        private int winRound;
        private Date date;
        public void setEvent(SherdogBaseObject e) { event = e; }
        public void setFighter1(SherdogBaseObject f) { fighter1 = f; }
        public void setFighter2(SherdogBaseObject f) { fighter2 = f; }
        public void setResult(String r) { result = r; }
        public void setWinMethod(String m) { winMethod = m; }
        public void setWinRound(int r) { winRound = r; }
        public void setWinTime(String t) { winTime = t; }
        public void setDate(Date d) { date = d; }
        public String toString() { return "Fight[fighter1=" + (fighter1 != null ? fighter1.getName() : "null") + ", fighter2=" + (fighter2 != null ? fighter2.getName() : "null") + ", method=" + winMethod + ", round=" + winRound + "]"; }
    }

    protected SherdogBaseObject getFighter(Element e) {
        SherdogBaseObject f = new SherdogBaseObject();
        f.setName("Card Fighter");
        f.setSherdogUrl("https://www.sherdog.com/fighter/Card-Fighter-555");
        return f;
    }
    protected String getResult(Element e) { return "win"; }
    protected String getMethod(Element e) { return "Submission (Rear-Naked Choke)"; }
    protected int getRound(Element e) { return 2; }
    protected String getTime(Element e) { return "3:12"; }

    private List<Fight> parseEventFights(Elements trs, Event event) {
        SherdogBaseObject sEvent = new SherdogBaseObject();
        sEvent.setName(event.getName());
        sEvent.setSherdogUrl(event.getSherdogUrl());

        List<Fight> fights = new ArrayList<>();
        if (trs.size() > 0) {
            trs.remove(0);
            trs.forEach(tr -> {
                Fight fight = new Fight();
                fight.setEvent(sEvent);
                fight.setDate(event.getDate());
                Elements tds = tr.select("td");
                fight.setFighter1(getFighter(tds.get(FIGHTER1_COLUMN)));
                fight.setFighter2(getFighter(tds.get(FIGHTER2_COLUMN)));
                if (tds.size() == 7) {
                    fight.setResult(getResult(tds.get(FIGHTER1_COLUMN)));
                    fight.setWinMethod(getMethod(tds.get(METHOD_COLUMN)));
                    fight.setWinRound(getRound(tds.get(ROUND_COLUMN)));
                    fight.setWinTime(getTime(tds.get(TIME_COLUMN)));
                }
                fights.add(fight);
                logger.info("Fight added: " + fight);
            });
        }
        return fights;
    }

    public static void main(String[] args) {
        method_3_sherdogparser_gemini parser = new method_3_sherdogparser_gemini();
        Event mockEvent = new Event();
        mockEvent.setName("UFC 301");
        mockEvent.setSherdogUrl("https://www.sherdog.com/events/UFC-301-8888");
        mockEvent.setDate(new Date());
        Elements mockTrs = new Elements();
        mockTrs.add(new Element("Header TR"));
        mockTrs.add(new Element("Match TR"));
        List<Fight> fights = parser.parseEventFights(mockTrs, mockEvent);
        System.out.println("-> Total Card Fights Extracted: " + fights.size());
    }
}
