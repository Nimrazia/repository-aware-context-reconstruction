import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

class Element {
    private String html = "";
    private String text = "";
    private final Map<String, String> attrs = new HashMap<>();
    public Element(String html) { this.html = html; this.text = html; }
    public String html() { return html; }
    public String text() { return text; }
    public Element attr(String key, String val) { attrs.put(key, val); return this; }
    public String attr(String key) { return attrs.getOrDefault(key, "mock_val"); }
    public Elements select(String query) {
        Elements els = new Elements();
        for (int i = 0; i < 6; i++) els.add(new Element("Mocked TD Content"));
        return els;
    }
    public Element first() { return this; }
}
class Elements extends ArrayList<Element> {
    public Elements select(String query) { return new Elements(); }
    public Element first() { return isEmpty() ? null : get(0); }
}

public class method_2_sherdogparser_gemini {
    protected static final Logger logger = Logger.getLogger(method_2_sherdogparser_gemini.class.getName());
    protected static final int COLUMN_RESULT = 0;
    protected static final int COLUMN_OPPONENT = 1;
    protected static final int COLUMN_EVENT = 2;
    protected static final int COLUMN_METHOD = 3;
    protected static final int COLUMN_ROUND = 4;
    protected static final int COLUMN_TIME = 5;

    public static class SherdogBaseObject {
        private String name;
        private String sherdogUrl;
        public void setName(String name) { this.name = name; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
        public String getName() { return name; }
        public String getSherdogUrl() { return sherdogUrl; }
    }
    public static class Fight {
        private SherdogBaseObject fighter1, fighter2, event;
        private String result, winMethod, winTime;
        private Date date = new Date();
        private int winRound;
        public void setFighter1(SherdogBaseObject f1) { fighter1 = f1; }
        public void setFighter2(SherdogBaseObject f2) { fighter2 = f2; }
        public void setEvent(SherdogBaseObject e) { event = e; }
        public void setResult(String r) { result = r; }
        public void setDate(Date d) { date = d; }
        public void setWinMethod(String m) { winMethod = m; }
        public void setWinRound(int r) { winRound = r; }
        public void setWinTime(String t) { winTime = t; }
        public String toString() { return "Fight[result=" + result + ", method=" + winMethod + ", round=" + winRound + ", time=" + winTime + "]"; }
    }
    public static class Fighter extends SherdogBaseObject {
        private List<Fight> fights = new ArrayList<>();
        public void setFights(List<Fight> f) { fights = f; }
        public List<Fight> getFights() { return fights; }
    }

    protected String getFightResult(Element e) { return "Win"; }
    protected SherdogBaseObject getOpponent(Element e) {
        SherdogBaseObject o = new SherdogBaseObject();
        o.setName("Opponent Fighter");
        o.setSherdogUrl("https://www.sherdog.com/fighter/Opponent-999");
        return o;
    }
    protected SherdogBaseObject getEvent(Element e) {
        SherdogBaseObject ev = new SherdogBaseObject();
        ev.setName("UFC Fight Night");
        ev.setSherdogUrl("https://www.sherdog.com/events/UFC-Fight-Night-888");
        return ev;
    }
    protected Date getDate(Element e) { return new Date(); }
    protected String getWinMethod(Element e) { return "KO (Punch)"; }
    protected int getWinRound(Element e) { return 1; }
    protected String getWinTime(Element e) { return "2:45"; }

    private List<Fight> getFights(Elements trs, Fighter fighter) throws ArrayIndexOutOfBoundsException {
        List<Fight> fights = new ArrayList<>();
        logger.info(trs.size() + " TRs to parse through");

        SherdogBaseObject sFighter = new SherdogBaseObject();
        sFighter.setName(fighter.getName());
        sFighter.setSherdogUrl(fighter.getSherdogUrl());

        if (trs.size() > 0) {
            trs.remove(0);
            trs.forEach(tr -> {
                Fight fight = new Fight();
                fight.setFighter1(sFighter);
                Elements tds = tr.select("td");
                fight.setResult(getFightResult(tds.get(COLUMN_RESULT)));
                fight.setFighter2(getOpponent(tds.get(COLUMN_OPPONENT)));
                fight.setEvent(getEvent(tds.get(COLUMN_EVENT)));
                fight.setDate(getDate(tds.get(COLUMN_EVENT)));
                fight.setWinMethod(getWinMethod(tds.get(COLUMN_METHOD)));
                fight.setWinRound(getWinRound(tds.get(COLUMN_ROUND)));
                fight.setWinTime(getWinTime(tds.get(COLUMN_TIME)));
                fights.add(fight);
                logger.info(fight.toString());
            });
        }
        return fights;
    }

    public static void main(String[] args) {
        method_2_sherdogparser_gemini parser = new method_2_sherdogparser_gemini();
        Fighter mockFighter = new Fighter();
        mockFighter.setName("Jon Jones");
        mockFighter.setSherdogUrl("https://www.sherdog.com/fighter/Jon-Jones-111");
        Elements mockTrs = new Elements();
        mockTrs.add(new Element("Header TR"));
        mockTrs.add(new Element("Data TR"));
        List<Fight> fights = parser.getFights(mockTrs, mockFighter);
        System.out.println("-> Total Fights Extracted: " + fights.size());
    }
}
