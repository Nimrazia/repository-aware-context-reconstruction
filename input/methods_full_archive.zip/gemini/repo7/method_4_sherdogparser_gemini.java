import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.logging.Logger;


class Element {
    private String html = "";
    private String text = "";
    private final Map<String, String> attrs = new HashMap<>();
    private final List<Element> children = new ArrayList<>();

    public Element(String html) { this.html = html; this.text = html; }
    public String html() { return html; }
    public String text() { return text; }
    public Element attr(String key, String val) { attrs.put(key, val); return this; }
    public String attr(String key) { return attrs.getOrDefault(key, ""); }
    public Elements select(String query) { return new Elements(); }
    public Element first() { return this; }
}

class Elements extends ArrayList<Element> {
    public Elements select(String query) { return new Elements(); }
    public Element first() { return isEmpty() ? null : get(0); }
    public String html() { return isEmpty() ? "" : get(0).html(); }
    public String attr(String key) { return isEmpty() ? "" : get(0).attr(key); }
}

class Document extends Element {
    public Document() { super(""); }
    @Override
    public Elements select(String query) {
        Elements els = new Elements();
        els.add(new Element("Mocked Selector Content"));
        return els;
    }
}




public class method_4_sherdogparser_gemini {

    protected static final Logger logger = Logger.getLogger(method_4_sherdogparser_gemini.class.getName());
    protected static final DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

    
    protected static final int METHOD_KO = 0;
    protected static final int METHOD_SUBMISSION = 1;
    protected static final int METHOD_DECISION = 2;
    protected static final int METHOD_OTHERS = 3;

    protected static final int COLUMN_RESULT = 0;
    protected static final int COLUMN_OPPONENT = 1;
    protected static final int COLUMN_EVENT = 2;
    protected static final int COLUMN_METHOD = 3;
    protected static final int COLUMN_ROUND = 4;
    protected static final int COLUMN_TIME = 5;

    
    public enum FightType {
        PRO_MMA, AMATEUR_MMA, KICKBOXING;
        public static FightType fromString(String name) {
            return PRO_MMA;
        }
    }

    public static class SherdogBaseObject {
        private String name;
        private String sherdogUrl;
        public void setName(String name) { this.name = name; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
        public String getName() { return name; }
        public String getSherdogUrl() { return sherdogUrl; }
    }

    public static class Fight {
        private SherdogBaseObject fighter1;
        private SherdogBaseObject fighter2;
        private SherdogBaseObject event;
        private FightType type;
        private String result;
        private Date date = new Date();
        private String winMethod;
        private int winRound;
        private String winTime;

        public void setFighter1(SherdogBaseObject f1) { this.fighter1 = f1; }
        public void setFighter2(SherdogBaseObject f2) { this.fighter2 = f2; }
        public void setEvent(SherdogBaseObject event) { this.event = event; }
        public void setType(FightType type) { this.type = type; }
        public void setResult(String result) { this.result = result; }
        public void setDate(Date date) { this.date = date; }
        public void setWinMethod(String method) { this.winMethod = method; }
        public void setWinRound(int round) { this.winRound = round; }
        public void setWinTime(String time) { this.winTime = time; }
        public Date getDate() { return date; }
    }

    public static class Fighter extends SherdogBaseObject {
        private String nickname;
        private Date birthday;
        private String height;
        private String weight;
        private int wins, winsKo, winsSub, winsDec, winsOther;
        private int losses, lossesKo, lossesSub, lossesDec, lossesOther;
        private int draws, nc;
        private String picture;
        private List<Fight> fights = new ArrayList<>();

        public void setNickname(String n) { this.nickname = n; }
        public void setBirthday(Date b) { this.birthday = b; }
        public void setHeight(String h) { this.height = h; }
        public void setWeight(String w) { this.weight = w; }
        public void setWins(int w) { this.wins = w; }
        public void setWinsKo(int wk) { this.winsKo = wk; }
        public void setWinsSub(int ws) { this.winsSub = ws; }
        public void setWinsDec(int wd) { this.winsDec = wd; }
        public void setWinsOther(int wo) { this.winsOther = wo; }
        public void setLosses(int l) { this.losses = l; }
        public void setLossesKo(int lk) { this.lossesKo = lk; }
        public void setLossesSub(int ls) { this.lossesSub = ls; }
        public void setLossesDec(int ld) { this.lossesDec = ld; }
        public void setLossesOther(int lo) { this.lossesOther = lo; }
        public void setDraws(int d) { this.draws = d; }
        public void setNc(int nc) { this.nc = nc; }
        public void setPicture(String p) { this.picture = p; }
        public void setFights(List<Fight> f) { this.fights = f; }
        public List<Fight> getFights() { return fights; }
    }

    
    protected static class ParserUtils {
        public static String getSherdogPageUrl(Document doc) { return "https://www.sherdog.com/fighter/Mock-Fighter-123"; }
        public static String getFightResult(Element e) { return "win"; }
    }

    protected static interface PictureProcessor {
        String process(String url, Fighter f);
    }

    protected PictureProcessor PROCESSOR = (url, f) -> "processed_pic.jpg";

    protected List<Fight> getFights(Elements trs, Fighter fighter) {
        return new ArrayList<>();
    }


// ORIGINAL CODESEARCHNET METHOD — START

    public Fighter parseDocument(Document doc) throws IOException {
        Fighter fighter = new Fighter();
        fighter.setSherdogUrl(ParserUtils.getSherdogPageUrl(doc));

        logger.info("Refreshing fighter " + fighter.getSherdogUrl());


        try {
            Elements name = doc.select(".bio_fighter h1 span.fn");
            fighter.setName(name.get(0).html());
        } catch (Exception e) {
            
        }

        
        try {
            Elements nickname = doc.select(".bio_fighter span.nickname em");
            fighter.setNickname(nickname.get(0).html());
        } catch (Exception e) {
            
        }

        
        try {
            Elements birthday = doc.select("span[itemprop=\"birthDate\"]");
            fighter.setBirthday(df.parse(birthday.get(0).html()));
        } catch (Exception e) {
            
        }
        
        try {
            Elements height = doc.select(".size_info .height strong");
            fighter.setHeight(height.get(0).html());
        } catch (Exception e) {
            
        }
        
        try {
            Elements weight = doc.select(".size_info .weight strong");
            fighter.setWeight(weight.get(0).html());
        } catch (Exception e) {
            
        }
        
        try {
            Elements wins = doc.select(".bio_graph .counter");
            fighter.setWins(Integer.parseInt(wins.get(0).html()));
        } catch (Exception e) {
            
        }
        Elements winsMethods = doc.select(".bio_graph:first-of-type .graph_tag");
        try {
            fighter.setWinsKo(Integer.parseInt(winsMethods.get(METHOD_KO).html().split(" ")[0]));
        } catch (Exception e) {
            
        }

        try {
            fighter.setWinsSub(Integer.parseInt(winsMethods.get(METHOD_SUBMISSION).html().split(" ")[0]));
        } catch (Exception e) {
            
        }

        try {
            fighter.setWinsDec(Integer.parseInt(winsMethods.get(METHOD_DECISION).html().split(" ")[0]));
        } catch (Exception e) {
            
        }


        try {
            fighter.setWinsOther(Integer.parseInt(winsMethods.get(METHOD_OTHERS).html().split(" ")[0]));
        } catch (Exception e) {
            
        }
        
        try {
            Elements losses = doc.select(".bio_graph.loser .counter");
            fighter.setLosses(Integer.parseInt(losses.get(0).html()));
        } catch (Exception e) {
            
        }

        Elements lossesMethods = doc.select(".bio_graph.loser .graph_tag");


        try {

            fighter.setLossesKo((Integer.parseInt(lossesMethods.get(METHOD_KO).html().split(" ")[0])));
        } catch (Exception e) {
            
        }

        try {
            fighter.setLossesSub(Integer.parseInt(lossesMethods.get(METHOD_SUBMISSION).html().split(" ")[0]));
        } catch (Exception e) {
            
        }

        try {
            fighter.setLossesDec(Integer.parseInt(lossesMethods.get(METHOD_DECISION).html().split(" ")[0]));
        } catch (Exception e) {
            
        }

        try {
            fighter.setLossesOther(Integer.parseInt(lossesMethods.get(METHOD_OTHERS).html().split(" ")[0]));
        } catch (Exception e) {
            
        }
        
        Elements drawsNc = doc.select(".right_side .bio_graph .card");
        for (Element element : drawsNc) {

            switch (element.select("span.result").html()) {
                case "Draws":
                    fighter.setDraws(Integer.parseInt(element.select("span.counter").html()));
                    break;

                case "N/C":
                    fighter.setNc(Integer.parseInt(element.select("span.counter").html()));
                    break;
            }

        }

        Elements picture = doc.select(".bio_fighter .content img[itemprop=\"image\"]");
        String pictureUrl = "https://www.sherdog.com" + picture.attr("src").trim();


        Elements fightTables = doc.select(".fight_history");
        logger.info("Found " + fightTables.size() + " fight history tables");


        fightTables.stream()
                
                .filter(div -> !div.select(".module_header h2").html().trim().contains("Upcoming"))
                .collect(Collectors.groupingBy(div -> {
                    String categoryName = div.select(".module_header h2").html().trim().replaceAll("(?i)FIGHT HISTORY - ", "").trim();

                    return FightType.fromString(categoryName);
                }))
                .forEach((key, div) -> div.stream()
                        .map(d -> d.select(".table table tr"))
                        .filter(tdList -> tdList.size() > 0)
                        .findFirst()
                        .ifPresent(tdList -> {
                                    List<Fight> f = getFights(tdList, fighter);

                                    f.forEach(fight -> fight.setType(key));

                                    fighter.getFights().addAll(f);
                                }
                        ));

        List<Fight> sorted = fighter.getFights()
                .stream()
                .sorted(Comparator.comparing(Fight::getDate, Comparator.nullsFirst(Comparator.naturalOrder())))
                .collect(Collectors.toList());

        fighter.setFights(sorted);


        logger.info("Found " + fighter.getFights().size() + " fights for " + fighter.getName());

        
        if (pictureUrl.length() > 0) {
            fighter.setPicture(PROCESSOR.process(pictureUrl, fighter));
        }

        return fighter;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        method_4_sherdogparser_gemini parser = new method_4_sherdogparser_gemini();
        Document mockDoc = new Document();
        
        System.out.println("=========================================");
        System.out.println("   FighterParser.parseDocument Test      ");
        System.out.println("=========================================\n");

        try {
            Fighter fighter = parser.parseDocument(mockDoc);
            System.out.println("[SUCCESS] Fighter parsed successfully!");
            System.out.println("-> Sherdog URL : " + fighter.getSherdogUrl());
            System.out.println("-> Picture URL : " + fighter.picture);
        } catch (Exception e) {
            System.err.println("[FAILURE] Parsing failed: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("\n=========================================");
    }
}