import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

class Element {
    private String html = "";
    private String text = "";
    private final Map<String, String> attrs = new HashMap<>();

    public Element(String html) { this.html = html; this.text = html; }
    public String html() { return html; }
    public String text() { return text; }
    public Element attr(String key, String val) { attrs.put(key, val); return this; }
    public String attr(String key) { return attrs.getOrDefault(key, "mock_attr_val"); }
    public Elements select(String query) {
        Elements els = new Elements();
        if (query.contains("span[itemprop=\"name\"]")) {
            els.add(new Element("Mock Fighter"));
        } else {
            for (int i = 0; i < 5; i++) els.add(new Element(i == 3 ? "1" : "Mock Value"));
        }
        return els;
    }
    public Element first() { return this; }
}

class Elements extends ArrayList<Element> {
    public Elements select(String query) {
        Elements els = new Elements();
        if (query.equals("h3 a")) {
            els.add(new Element("Fighter One").attr("abs:href", "fighter1"));
            els.add(new Element("Fighter Two").attr("abs:href", "fighter2"));
        } else {
            for (Element e : this) els.addAll(e.select(query));
        }
        return els;
    }
    public Element first() { return isEmpty() ? null : get(0); }
    public String html() { return isEmpty() ? "" : get(0).html(); }
    public String attr(String key) { return isEmpty() ? "" : get(0).attr(key); }
}

class Document extends Element {
    public Document() { super(""); }
    @Override
    public Elements select(String query) {
        Elements els = new Elements();
        els.add(new Element("Mocked Event Content"));
        return els;
    }
}

public class method_1_sherdogparser_gemini {
    protected static final Logger logger = Logger.getLogger(method_1_sherdogparser_gemini.class.getName());

    public static class SherdogBaseObject {
        private String name;
        private String sherdogUrl;
        public void setName(String name) { this.name = name; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
        public String getName() { return name; }
        public String getSherdogUrl() { return sherdogUrl; }
    }

    public static class Event extends SherdogBaseObject {
        private Date date = new Date();
        private List<Fight> fights = new ArrayList<>();
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
        public void setFights(List<Fight> fights) { this.fights = fights; }
        public List<Fight> getFights() { return fights; }
    }

    public static class Fight {
        private SherdogBaseObject event;
        private SherdogBaseObject fighter1;
        private SherdogBaseObject fighter2;
        private String result;
        private String winMethod;
        private int winRound;
        private String winTime;
        private Date date;

        public void setEvent(SherdogBaseObject event) { this.event = event; }
        public void setFighter1(SherdogBaseObject f1) { this.fighter1 = f1; }
        public void setFighter2(SherdogBaseObject f2) { this.fighter2 = f2; }
        public void setResult(String result) { this.result = result; }
        public void setWinMethod(String method) { this.winMethod = method; }
        public void setWinRound(int round) { this.winRound = round; }
        public void setWinTime(String time) { this.winTime = time; }
        public void setDate(Date date) { this.date = date; }

        @Override
        public String toString() {
            return "Fight[result=" + result + ", method=" + winMethod + ", round=" + winRound + "]";
        }
    }

    protected static class ParserUtils {
        public static String getFightResult(Element e) { return "win"; }
    }

    protected List<Fight> parseEventFights(Elements trs, Event event) {
        return new ArrayList<>();
    }

    private void getFights(Document doc, Event event) {
        logger.info("Getting fights for event #" + event.getSherdogUrl() + "[" + event.getName() + "]");

        SherdogBaseObject sEvent = new SherdogBaseObject();
        sEvent.setName(event.getName());
        sEvent.setSherdogUrl(event.getSherdogUrl());

        List<Fight> fights = new ArrayList<>();

        Elements mainFightElement = doc.select(".content.event");
        Elements fighters = mainFightElement.select("h3 a");

        SherdogBaseObject mainFighter1 = new SherdogBaseObject();
        Element mainFighter1Element = fighters.get(0);
        mainFighter1.setSherdogUrl(mainFighter1Element.attr("abs:href"));
        mainFighter1.setName(mainFighter1Element.select("span[itemprop=\"name\"]").html());

        SherdogBaseObject mainFighter2 = new SherdogBaseObject();
        Element mainFighter2Element = fighters.get(1);
        mainFighter2.setSherdogUrl(mainFighter2Element.attr("abs:href"));
        mainFighter2.setName(mainFighter2Element.select("span[itemprop=\"name\"]").html());

        Fight mainFight = new Fight();
        mainFight.setEvent(sEvent);
        mainFight.setFighter1(mainFighter1);
        mainFight.setFighter2(mainFighter2);
        mainFight.setResult(ParserUtils.getFightResult(mainFightElement.first()));

        Elements mainTd = mainFightElement.select("td");
        if (mainTd.size() > 0) {
            mainFight.setWinMethod(mainTd.get(1).html().replaceAll("<em(.*)<br>", "").trim());
            mainFight.setWinRound(Integer.parseInt(mainTd.get(3).html().replaceAll("<em(.*)<br>", "").trim()));
            mainFight.setWinTime(mainTd.get(4).html().replaceAll("<em(.*)<br>", "").trim());
        }
        mainFight.setDate(event.getDate());

        fights.add(mainFight);
        logger.info("Fight added: " + mainFight);
        logger.info("Found " + fights.size() + " fights");

        Elements tds = doc.select(".event_match table tr");
        fights.addAll(parseEventFights(tds, event));
        event.setFights(fights);
    }

    public static void main(String[] args) {
        method_1_sherdogparser_gemini parser = new method_1_sherdogparser_gemini();
        Document mockDoc = new Document();
        Event mockEvent = new Event();
        mockEvent.setName("UFC 300");
        mockEvent.setSherdogUrl("https://www.sherdog.com/events/UFC-300-9999");
        mockEvent.setDate(new Date());

        try {
            parser.getFights(mockDoc, mockEvent);
            System.out.println("[SUCCESS] Event fights parsed successfully!");
            System.out.println("-> Total Fights Found: " + mockEvent.getFights().size());
        } catch (Exception e) {
            System.err.println("[FAILURE] Parsing failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
