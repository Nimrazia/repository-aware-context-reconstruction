



import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

public class method_1_jettybootstrap_gemini {

    
    
    

    public enum JettyConnector {
        HTTP, HTTPS
    }

    public enum CertificateFormat {
        PKCS8, PKCS12, UNKNOWN
    }

    public interface IJettyConfiguration {
        boolean hasJettyConnector(JettyConnector connector);
        int getSslPort();
        long getIdleTimeout();
        long getBlockingTimeout();
        String getHost();
        int getPort();
        KeyStore getSslKeyStore();
        String getSslPrivateKeyPath();
        String getSslCertificatePath();
        CertificateFormat getSslCertificateFormat();
        CertificateFormat getSslPrivateKeyFormat();
        String getSslCertificatePassword();
        String getSslPrivateKeyPassword();
        String getSslKeyStoreAlias();
        String getSslKeyStorePassword();
        String getSslKeyStorePath();
    }

    static class JettyBootstrapException extends Exception {
        public JettyBootstrapException(String msg) { super(msg); }
        public JettyBootstrapException(String msg, Throwable cause) { super(msg, cause); }
    }

    static class JettyKeystoreException extends Exception {
        public JettyKeystoreException(String msg) { super(msg); }
    }

    static class Logger {
        public void trace(String msg) { System.out.println("TRACE: " + msg); }
        public void debug(String msg) { System.out.println("DEBUG: " + msg); }
    }

    static class HttpConfiguration {
        private int securePort;
        private String secureScheme;
        private long idleTimeout;
        private long blockingTimeout;

        public void setSecurePort(int port) { this.securePort = port; }
        public void setSecureScheme(String scheme) { this.secureScheme = scheme; }
        public void setIdleTimeout(long timeout) { this.idleTimeout = timeout; }
        public void setBlockingTimeout(long timeout) { this.blockingTimeout = timeout; }
        public long getBlockingTimeout() { return blockingTimeout; }
    }

    static class HttpConnectionFactory {
        private HttpConfiguration httpConfig;
        public HttpConnectionFactory(HttpConfiguration config) { this.httpConfig = config; }
        public HttpConfiguration getHttpConfiguration() { return httpConfig; }
    }

    interface Connector {}

    static class ServerConnector implements Connector {
        private Server server;
        private List<Object> connectionFactories = new ArrayList<>();
        private long idleTimeout;
        private String host;
        private int port;

        public ServerConnector(Server server) {
            this.server = server;
            this.connectionFactories.add(new HttpConnectionFactory(new HttpConfiguration()));
        }

        public ServerConnector(Server server, HttpConnectionFactory factory) {
            this.server = server;
            this.connectionFactories.add(factory);
        }

        public ServerConnector(Server server, SslContextFactory sslFactory) {
            this.server = server;
        }

        public List<Object> getConnectionFactories() { return connectionFactories; }
        public void setIdleTimeout(long t) { this.idleTimeout = t; }
        public void setHost(String h) { this.host = h; }
        public void setPort(int p) { this.port = p; }
        
        @Override
        public String toString() {
            return "ServerConnector{host='" + host + "', port=" + port + ", idleTimeout=" + idleTimeout + "}";
        }
    }

    static class SslContextFactory {
        public void setKeyStore(KeyStore ks) {}
        public void setKeyStorePath(String path) {}
        public void setKeyStorePassword(String pwd) {}
    }

    static class HttpScheme {
        public static final HttpScheme HTTPS = new HttpScheme("https");
        private String scheme;
        public HttpScheme(String s) { this.scheme = s; }
        public String asString() { return scheme; }
    }

    static class Server {}

    static class JettyKeystoreConvertorBuilder {
        public void setCertificateFromPKCS8(InputStream is) {}
        public void setCertificateFromPKCS12(InputStream is, String pwd) {}
        public void setPrivateKeyFromPKCS8(InputStream is) {}
        public void setPrivateKeyFromPKCS12(InputStream is, String pwd) {}
        public KeyStore build(String alias, String pwd) throws JettyKeystoreException {
            try {
                KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
                ks.load(null, null);
                return ks;
            } catch (Exception e) {
                throw new JettyKeystoreException("Failed to create mock keystore");
            }
        }
    }

    
    
    

    private Logger LOG = new Logger();


// ORIGINAL CODESEARCHNET METHOD — START

protected Connector[] createConnectors(IJettyConfiguration iJettyConfiguration, Server server) throws JettyBootstrapException {
        LOG.trace("Creating Jetty Connectors...");

        List<Connector> connectors = new ArrayList<>();

        if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP)) {
            LOG.trace("Adding HTTP Connector...");

            ServerConnector serverConnector;

            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
                HttpConfiguration httpConfiguration = new HttpConfiguration();
                httpConfiguration.setSecurePort(iJettyConfiguration.getSslPort());
                httpConfiguration.setSecureScheme(HttpScheme.HTTPS.asString());
                httpConfiguration.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
                httpConfiguration.setBlockingTimeout(iJettyConfiguration.getBlockingTimeout());

                HttpConnectionFactory httpConnectionFactory = new HttpConnectionFactory(httpConfiguration);

                serverConnector = new ServerConnector(server, httpConnectionFactory);
            } else {
                serverConnector = new ServerConnector(server);

                serverConnector.getConnectionFactories().stream()
                        .filter(HttpConnectionFactory.class::isInstance)
                        .map(HttpConnectionFactory.class::cast)
                        .forEach(httpConnectionFactory -> httpConnectionFactory.getHttpConfiguration().setBlockingTimeout(iJettyConfiguration.getBlockingTimeout()));
            }

            serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
            serverConnector.setHost(iJettyConfiguration.getHost());
            serverConnector.setPort(iJettyConfiguration.getPort());

            connectors.add(serverConnector);
        }
        if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
            LOG.trace("Adding HTTPS Connector...");

            SslContextFactory sslContextFactory = new SslContextFactory();

            if (iJettyConfiguration.getSslKeyStore() != null) { 
                sslContextFactory.setKeyStore(iJettyConfiguration.getSslKeyStore());
            } else if (iJettyConfiguration.getSslPrivateKeyPath() != null && !iJettyConfiguration.getSslPrivateKeyPath().isEmpty() &&
                iJettyConfiguration.getSslCertificatePath() != null && !iJettyConfiguration.getSslCertificatePath().isEmpty()) { 

                JettyKeystoreConvertorBuilder jettyKeystoreConvertorBuilder = new JettyKeystoreConvertorBuilder();
                try {
                    File sslPrivateKeyFile = new File(iJettyConfiguration.getSslPrivateKeyPath());
                    if (!sslPrivateKeyFile.exists() || !sslPrivateKeyFile.canRead()) {
                        throw new JettyBootstrapException("Private key not exists or unreadable");
                    }

                    File sslCertificateFile = new File(iJettyConfiguration.getSslCertificatePath());
                    if (!sslCertificateFile.exists() || !sslCertificateFile.canRead()) {
                        throw new JettyBootstrapException("Certificate not exists or unreadable");
                    }

                    try (InputStream sslPrivateKeyInputStream = new FileInputStream(sslPrivateKeyFile);
                            InputStream sslCertificateInputStream = new FileInputStream(sslCertificateFile)) {

                        switch (iJettyConfiguration.getSslCertificateFormat()) {
                            case PKCS8:
                                jettyKeystoreConvertorBuilder.setCertificateFromPKCS8(sslCertificateInputStream);
                                break;
                            case PKCS12:
                                jettyKeystoreConvertorBuilder.setCertificateFromPKCS12(sslCertificateInputStream, iJettyConfiguration.getSslCertificatePassword());
                                break;
                            case UNKNOWN:
                                throw new JettyBootstrapException("Unknown Certificate Format");
                            default:
                                throw new JettyBootstrapException("Certificate Format not setted");
                        }

                        switch (iJettyConfiguration.getSslPrivateKeyFormat()) {
                            case PKCS8:
                                jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS8(sslPrivateKeyInputStream);
                                break;
                            case PKCS12:
                                jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS12(sslPrivateKeyInputStream, iJettyConfiguration.getSslPrivateKeyPassword());
                                break;
                            case UNKNOWN:
                                throw new JettyBootstrapException("Unknown Private key Format");
                            default:
                                throw new JettyBootstrapException("Private key Format not setted");
                        }
                    }

                    KeyStore keyStore = jettyKeystoreConvertorBuilder.build(iJettyConfiguration.getSslKeyStoreAlias(), iJettyConfiguration.getSslKeyStorePassword());

                    sslContextFactory.setKeyStore(keyStore);
                } catch (JettyKeystoreException | IOException e) {
                    throw new JettyBootstrapException("Can not load SSL private key or SSL certificate", e);
                }
            } else { 
                sslContextFactory.setKeyStorePath(iJettyConfiguration.getSslKeyStorePath());
            }
            sslContextFactory.setKeyStorePassword(iJettyConfiguration.getSslKeyStorePassword());
            ServerConnector serverConnector = new ServerConnector(server, sslContextFactory);

            serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
            serverConnector.setHost(iJettyConfiguration.getHost());
            serverConnector.setPort(iJettyConfiguration.getSslPort());

            connectors.add(serverConnector);
        }

        return connectors.toArray(new Connector[connectors.size()]);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting JettyBootstrap createConnectors Simulation...\n");

        method_1_jettybootstrap_gemini bootstrap = new method_1_jettybootstrap_gemini();
        Server server = new Server();

        
        IJettyConfiguration config = new IJettyConfiguration() {
            public boolean hasJettyConnector(JettyConnector c) { return c == JettyConnector.HTTP; }
            public int getSslPort() { return 8443; }
            public long getIdleTimeout() { return 30000; }
            public long getBlockingTimeout() { return 5000; }
            public String getHost() { return "localhost"; }
            public int getPort() { return 8080; }
            public KeyStore getSslKeyStore() { return null; }
            public String getSslPrivateKeyPath() { return null; }
            public String getSslCertificatePath() { return null; }
            public CertificateFormat getSslCertificateFormat() { return CertificateFormat.UNKNOWN; }
            public CertificateFormat getSslPrivateKeyFormat() { return CertificateFormat.UNKNOWN; }
            public String getSslCertificatePassword() { return null; }
            public String getSslPrivateKeyPassword() { return null; }
            public String getSslKeyStoreAlias() { return null; }
            public String getSslKeyStorePassword() { return null; }
            public String getSslKeyStorePath() { return null; }
        };

        try {
            Connector[] connectors = bootstrap.createConnectors(config, server);
            System.out.println("\nSuccessfully created " + connectors.length + " connector(s):");
            for (Connector c : connectors) {
                System.out.println(" -> " + c.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}