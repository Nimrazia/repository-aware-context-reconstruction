



import java.io.File;
import java.io.FileOutputStream;
import java.security.KeyStore;

public class method_2_jettybootstrap_gemini {

    
    
    

    public enum JettyConnector {
        HTTP, HTTPS
    }

    public static class IJettyConfiguration {
        private File tempDirectory;
        private boolean cleanTempDir;
        private String host;
        private boolean redirectWebAppsOnHttpsConnector;
        private String sslKeyStorePath;
        private KeyStore sslKeyStore;
        private String sslPrivateKeyPath;
        private String sslCertificatePath;
        private String sslKeyStoreAlgorithm = "JKS";
        private String sslKeyStoreSignatureAlgorithm = "SHA1withRSA";
        private String sslKeyStoreRdnOuValue = "IT";
        private String sslKeyStoreRdnOValue = "Teknux";
        private int sslKeyStoreDateNotBeforeNumberOfDays = -30;
        private int sslKeyStoreDateNotAfterNumberOfDays = 365;
        private String sslKeyStoreDomainName = "localhost";
        private String sslKeyStoreAlias = "jetty";
        private String sslKeyStorePassword = "password";

        private java.util.EnumSet<JettyConnector> connectors = java.util.EnumSet.noneOf(JettyConnector.class);

        public File getTempDirectory() { return tempDirectory; }
        public void setTempDirectory(File tempDirectory) { this.tempDirectory = tempDirectory; }
        public boolean isCleanTempDir() { return cleanTempDir; }
        public void setCleanTempDir(boolean cleanTempDir) { this.cleanTempDir = cleanTempDir; }
        public String getHost() { return host; }
        public void setHost(String host) { this.host = host; }
        public boolean hasJettyConnector(JettyConnector connector) { return connectors.contains(connector); }
        public void addJettyConnector(JettyConnector connector) { connectors.add(connector); }
        
        public KeyStore getSslKeyStore() { return sslKeyStore; }
        public String getSslPrivateKeyPath() { return sslPrivateKeyPath; }
        public String getSslCertificatePath() { return sslCertificatePath; }
        public String getSslKeyStorePath() { return sslKeyStorePath; }
        public void setSslKeyStorePath(String path) { this.sslKeyStorePath = path; }
        
        public String getSslKeyStoreAlgorithm() { return sslKeyStoreAlgorithm; }
        public String getSslKeyStoreSignatureAlgorithm() { return sslKeyStoreSignatureAlgorithm; }
        public String getSslKeyStoreRdnOuValue() { return sslKeyStoreRdnOuValue; }
        public String getSslKeyStoreRdnOValue() { return sslKeyStoreRdnOValue; }
        public int getSslKeyStoreDateNotBeforeNumberOfDays() { return sslKeyStoreDateNotBeforeNumberOfDays; }
        public int getSslKeyStoreDateNotAfterNumberOfDays() { return sslKeyStoreDateNotAfterNumberOfDays; }
        public String getSslKeyStoreDomainName() { return sslKeyStoreDomainName; }
        public String getSslKeyStoreAlias() { return sslKeyStoreAlias; }
        public String getSslKeyStorePassword() { return sslKeyStorePassword; }
        
        public boolean isRedirectWebAppsOnHttpsConnector() { return redirectWebAppsOnHttpsConnector; }
        public void setRedirectWebAppsOnHttpsConnector(boolean b) { this.redirectWebAppsOnHttpsConnector = b; }

        @Override
        public String toString() {
            return "IJettyConfiguration{host='" + host + "', tempDir=" + tempDirectory + "}";
        }
    }

    static class JettyBootstrapException extends Exception {
        public JettyBootstrapException(String msg) { super(msg); }
        public JettyBootstrapException(String msg, Throwable cause) { super(msg, cause); }
    }

    static class JettyKeystoreException extends Exception {
        public JettyKeystoreException(String msg) { super(msg); }
    }

    static class Logger {
        public void trace(String msg) { System.out.println("TRACE: " + msg); }
        public void trace(String msg, Object arg) { System.out.println("TRACE: " + msg.replace("{}", String.valueOf(arg))); }
        public void debug(String msg) { System.out.println("DEBUG: " + msg); }
    }

    static class FileUtils {
        public static void deleteDirectory(File dir) throws java.io.IOException {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) f.delete();
            }
            dir.delete();
        }
    }

    static class JettyKeystoreGeneratorBuilder {
        public void setAlgorithm(String s) {}
        public void setSignatureAlgorithm(String s) {}
        public void setRdnOuValue(String s) {}
        public void setRdnOValue(String s) {}
        public void setDateNotBeforeNumberOfDays(int n) {}
        public void setDateNotAfterNumberOfDays(int n) {}

        public KeyStore build(String domain, String alias, String pwd) throws JettyKeystoreException {
            try {
                KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
                ks.load(null, null);
                return ks;
            } catch (Exception e) {
                throw new JettyKeystoreException("Mock keystore build failed");
            }
        }

        public static void saveKeyStore(KeyStore ks, File file, String pwd) throws JettyKeystoreException {
            try (FileOutputStream fos = new FileOutputStream(file)) {
                ks.store(fos, pwd.toCharArray());
            } catch (Exception e) {
                throw new JettyKeystoreException("Mock keystore save failed");
            }
        }
    }

    
    
    

    private Logger LOG = new Logger();
    private boolean isInitializedConfiguration = false;
    private IJettyConfiguration iJettyConfiguration = new IJettyConfiguration();
    
    private static final File TEMP_DIRECTORY_DEFAULT = new File(System.getProperty("java.io.tmpdir"), "jetty-bootstrap-temp");
    private static final String DEFAULT_KEYSTORE_FILENAME = "keystore";


// ORIGINAL CODESEARCHNET METHOD — START

protected IJettyConfiguration getInitializedConfiguration() throws JettyBootstrapException {
        if (!isInitializedConfiguration) {
            LOG.debug("Init Configuration...");

            LOG.trace("Check Temp Directory...");
            if (iJettyConfiguration.getTempDirectory() == null) {
                iJettyConfiguration.setTempDirectory(TEMP_DIRECTORY_DEFAULT);
            }

            if (iJettyConfiguration.getTempDirectory().exists() && iJettyConfiguration.isCleanTempDir()) {
                LOG.trace("Clean Temp Directory...");

                try {
                    FileUtils.deleteDirectory(iJettyConfiguration.getTempDirectory());
                } catch (java.io.IOException e) {
                    throw new JettyBootstrapException("Can't clean temporary directory");
                }
            }
            if (!iJettyConfiguration.getTempDirectory().exists() && !iJettyConfiguration.getTempDirectory().mkdirs()) {
                throw new JettyBootstrapException("Can't create temporary directory");
            }

            LOG.trace("Check required properties...");
            if (iJettyConfiguration.getHost() == null || iJettyConfiguration.getHost().isEmpty()) {
                throw new JettyBootstrapException("Host not specified");
            }

            LOG.trace("Check connectors...");
            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {

                
                if (iJettyConfiguration.getSslKeyStore() == null &&
                    (iJettyConfiguration.getSslPrivateKeyPath() == null || iJettyConfiguration.getSslPrivateKeyPath().isEmpty() ||
                        iJettyConfiguration.getSslCertificatePath() == null || iJettyConfiguration.getSslCertificatePath().isEmpty())) {

                    
                    if (iJettyConfiguration.getSslKeyStorePath() == null || iJettyConfiguration.getSslKeyStorePath().isEmpty()) {
                        iJettyConfiguration.setSslKeyStorePath(iJettyConfiguration.getTempDirectory().getPath() + File.separator + DEFAULT_KEYSTORE_FILENAME);
                    }

                    
                    File keystoreFile = new File(iJettyConfiguration.getSslKeyStorePath());
                    if (!keystoreFile.exists()) {
                        try {
                            JettyKeystoreGeneratorBuilder jettyKeystoreGeneratorBuilder = new JettyKeystoreGeneratorBuilder();
                            jettyKeystoreGeneratorBuilder.setAlgorithm(iJettyConfiguration.getSslKeyStoreAlgorithm());
                            jettyKeystoreGeneratorBuilder.setSignatureAlgorithm(iJettyConfiguration.getSslKeyStoreSignatureAlgorithm());
                            jettyKeystoreGeneratorBuilder.setRdnOuValue(iJettyConfiguration.getSslKeyStoreRdnOuValue());
                            jettyKeystoreGeneratorBuilder.setRdnOValue(iJettyConfiguration.getSslKeyStoreRdnOValue());
                            jettyKeystoreGeneratorBuilder.setDateNotBeforeNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotBeforeNumberOfDays());
                            jettyKeystoreGeneratorBuilder.setDateNotAfterNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotAfterNumberOfDays());

                            KeyStore keyStore = jettyKeystoreGeneratorBuilder.build(iJettyConfiguration.getSslKeyStoreDomainName(), iJettyConfiguration.getSslKeyStoreAlias(),
                                    iJettyConfiguration.getSslKeyStorePassword());
                            JettyKeystoreGeneratorBuilder.saveKeyStore(keyStore, keystoreFile, iJettyConfiguration.getSslKeyStorePassword());
                        } catch (JettyKeystoreException e) {
                            throw new JettyBootstrapException("Can't generate keyStore", e);
                        }
                    }
                }
            }

            if (iJettyConfiguration.isRedirectWebAppsOnHttpsConnector() &&
                (!iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP) || !iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS))) {
                throw new JettyBootstrapException("You can't redirect all from HTTP to HTTPS Connector if both connectors are not setted");
            }

            isInitializedConfiguration = true;

            LOG.trace("Configuration : {}", iJettyConfiguration);
        }

        return iJettyConfiguration;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting JettyBootstrap getInitializedConfiguration Simulation...\n");
        method_2_jettybootstrap_gemini bootstrap = new method_2_jettybootstrap_gemini();
        
        
        bootstrap.iJettyConfiguration.setHost("127.0.0.1");
        bootstrap.iJettyConfiguration.addJettyConnector(JettyConnector.HTTPS);
        bootstrap.iJettyConfiguration.setCleanTempDir(true);

        try {
            IJettyConfiguration config = bootstrap.getInitializedConfiguration();
            System.out.println("\nConfiguration Initialized Successfully!");
            System.out.println(" -> Host: " + config.getHost());
            System.out.println(" -> Temp Directory: " + config.getTempDirectory());
            System.out.println(" -> Generated Keystore Path: " + config.getSslKeyStorePath());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}