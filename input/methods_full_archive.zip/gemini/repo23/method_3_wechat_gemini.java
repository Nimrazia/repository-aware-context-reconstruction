



import java.io.IOException;

public class method_3_wechat_gemini {

    
    
    

    public static class ServletException extends Exception {}

    public interface HttpServletRequest {
        String getParameter(String name);
    }

    public interface HttpServletResponse {
        void getWriter();
    }

    public static class Signature {
        private String echostr = "mock_echo_string_12345";
        public String getEchostr() { return echostr; }
        @Override
        public String toString() { return "Signature{echostr='" + echostr + "'}"; }
    }

    public static class WebUtil {
        public static void outputString(HttpServletResponse response, String str) {
            System.out.println("HTTP RESPONSE WRITER OUTPUT: " + str);
        }
    }

    public static class Logger {
        public void info(String format, Object arg) {
            System.out.println("INFO: " + format.replace("{}", String.valueOf(arg)));
        }
        public void error(String msg, Throwable e) {
            System.out.println("ERROR: " + msg);
        }
    }

    
    
    

    public static abstract class HttpServlet {
        protected abstract void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException;
    }

    public static class AccessServlet extends HttpServlet {

        private Logger log = new Logger();

        
        private boolean checkSignature(Signature signature, HttpServletRequest request) {
            String validationParam = request.getParameter("valid");
            return "true".equals(validationParam);
        }


// ORIGINAL CODESEARCHNET METHOD — START

@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Signature signature = new Signature();
            boolean hasRights = checkSignature(signature, request);

            if (hasRights) {
                log.info("signature-success:{}", signature);
                WebUtil.outputString(response, signature.getEchostr());
            } else {
                log.info("signature-not-match:{}", signature);
            }
        } catch (Exception e) {
            log.error("signature-error", e);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END

    }

    public static void main(String[] args) {
        System.out.println("Starting AccessServlet.doGet Simulation...\n");

        AccessServlet servlet = new AccessServlet();
        HttpServletResponse mockResponse = new HttpServletResponse() {
            @Override
            public void getWriter() {}
        };

        System.out.println("--- Scenario 1: Valid Signature Request ---");
        HttpServletRequest validRequest = new HttpServletRequest() {
            @Override
            public String getParameter(String name) { return "valid".equals(name) ? "true" : null; }
        };
        try {
            servlet.doGet(validRequest, mockResponse);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n--- Scenario 2: Invalid Signature Request ---");
        HttpServletRequest invalidRequest = new HttpServletRequest() {
            @Override
            public String getParameter(String name) { return "valid".equals(name) ? "false" : null; }
        };
        try {
            servlet.doGet(invalidRequest, mockResponse);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}