



import javax.net.SocketFactory;
import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.security.cert.X509Certificate;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;

public class method_3_netscaler_gemini {

    public static class nitro_service {
        private String ipaddress;
        private String version = "v1";
        private String protocol = "http";
        private boolean certvalidation = false;
        private boolean hostnameverification = false;

        public nitro_service(String ipaddress) { this.ipaddress = ipaddress; }
        public String get_ipaddress() { return ipaddress; }
        public String get_version() { return version; }
        public String get_protocol() { return protocol; }
        public boolean get_certvalidation() { return certvalidation; }
        public boolean get_hostnameverification() { return hostnameverification; }
    }

    public static class EmptyTrustManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] c, String a) {}
        public void checkServerTrusted(X509Certificate[] c, String a) {}
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }

    public static class EmptyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String h, SSLSession s) { return true; }
    }


// ORIGINAL CODESEARCHNET METHOD — START

private static String _put(nitro_service service, String request) throws Exception {
		HttpURLConnection httpURLConnection;
		StringBuilder responseStr = new StringBuilder();
		try
		{
			String urlstr;
			String ipaddress = service.get_ipaddress();
			String version = service.get_version();
			String protocol = service.get_protocol();
			urlstr = protocol+"://" + ipaddress + "/nitro/" + version + "/config/";
			URL url = new URL(urlstr);
			httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("PUT");
			if (httpURLConnection instanceof HttpsURLConnection)
			{
				if (service.get_certvalidation()) {
					SocketFactory sslSocketFactory = SSLSocketFactory.getDefault();
					HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);	
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				} else {
					SSLContext sslContext = SSLContext.getInstance("SSL");
					
					
					
					sslContext.init(null, new TrustManager[]{new EmptyTrustManager()}, null);
					SocketFactory sslSocketFactory = sslContext.getSocketFactory();
					
					HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				}
			}

			httpURLConnection.setDoInput(true);
			httpURLConnection.setDoOutput(true);
			httpURLConnection.setUseCaches(false);
			httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			
			httpURLConnection.setDoOutput(true);
			OutputStreamWriter ouput = new OutputStreamWriter(httpURLConnection.getOutputStream());
			ouput.write(request);
			ouput.flush();
			ouput.close();

			InputStream input;
			try {
				input = httpURLConnection.getInputStream();
			}
			catch (Exception e) {
				input = httpURLConnection.getErrorStream();	
			}
			String contentEncoding = httpURLConnection.getContentEncoding();
			
			if (contentEncoding != null)
			{
				if(contentEncoding.equalsIgnoreCase("gzip"))
					input = new GZIPInputStream(input); 
				else if(contentEncoding.equalsIgnoreCase("deflate"))
					input = new InflaterInputStream(input);
			}

			int numOfTotalBytesRead;
			byte [] buffer = new byte[1024];
			while ((numOfTotalBytesRead = input.read(buffer, 0, buffer.length)) != -1)
			{
				responseStr.append(new String(buffer, 0, numOfTotalBytesRead));
			}

			httpURLConnection.disconnect();
			input.close();
		}
		catch (MalformedURLException mue)
		{
			throw mue;
		}
		catch (IOException ioe)
		{
			throw ioe;
		}
		catch(Exception e)
		{
			throw e;
		}
		
		return responseStr.toString();
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting base_resource._put Simulation...\n");
        
        nitro_service service = new nitro_service("127.0.0.1:8080");
        try {
            
            _put(service, "test_payload=true");
        } catch (Exception e) {
            System.out.println("Connection attempt handled as expected in mock runtime: " + e.getMessage());
        }
        System.out.println("Execution Complete.");
    }
}
