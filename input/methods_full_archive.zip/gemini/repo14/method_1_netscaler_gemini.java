



import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;

public class method_1_netscaler_gemini {

    
    
    

    static class base_response {
        public int errorcode;
        public String message;
        public String severity;
        
        @Override
        public String toString() {
            return "base_response{errorcode=" + errorcode + ", message='" + message + "', severity='" + severity + "'}";
        }
    }

    static class nitro_exception extends Exception {
        public int errorcode;
        public nitro_exception(String message, int errorcode) {
            super(message);
            this.errorcode = errorcode;
        }
    }

    static class nitro_util {
        public static String encode(String str) {
            
            return str != null ? str.replace(" ", "%20") : null;
        }
    }

    interface PayloadFormatter {
        Object string_to_resource(Class<?> clazz, String payload);
    }

    static class MockPayloadFormatter implements PayloadFormatter {
        public Object string_to_resource(Class<?> clazz, String payload) {
            base_response response = new base_response();
            
            if (payload.contains("\"errorcode\": 0")) {
                response.errorcode = 0;
                response.message = "Done";
                response.severity = "NONE";
            } else if (payload.contains("\"errorcode\": 444")) {
                response.errorcode = 444;
                response.message = "Session Expired";
                response.severity = "ERROR";
            } else {
                response.errorcode = 500;
                response.message = "Internal Error";
                response.severity = "ERROR";
            }
            return response;
        }
    }

    static class nitro_service {
        private String ipaddress;
        public void set_ipaddress(String ip) { this.ipaddress = ip; }
        public String get_ipaddress() { return ipaddress; }
        public String get_version() { return "v1"; }
        public String get_sessionid() { return "mock_session_12345"; }
        public String get_protocol() { return "http"; }
        public Boolean get_warning() { return false; }
        public boolean get_certvalidation() { return false; }
        public boolean get_hostnameverification() { return false; }
        
        public void clear_session() {
            System.out.println("INFO: nitro_service session cleared.");
        }
        
        public PayloadFormatter get_payload_formatter() {
            return new MockPayloadFormatter();
        }
    }

    static class EmptyTrustManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] chain, String authType) {}
        public void checkServerTrusted(X509Certificate[] chain, String authType) {}
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }

    static class EmptyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) { return true; }
    }

    
    
    

    public String get_object_type() {
        return "lbvserver";
    }

    public String get_object_name() {
        return "my_lb_vserver";
    }


// ORIGINAL CODESEARCHNET METHOD — START

private base_response delete_request(nitro_service service, String req_args) throws Exception
	{
		StringBuilder responseStr = new StringBuilder();
		HttpURLConnection httpURLConnection = null;
		try
		{
			String urlstr;
			String ipaddress = service.get_ipaddress();
			String version = service.get_version();
			String sessionid = service.get_sessionid();
			String objtype = get_object_type();
			String protocol = service.get_protocol();

			
			urlstr = protocol + "://" + ipaddress + "/nitro/" + version + "/config/" + objtype;

			String name = this.get_object_name();
			if (name != null && name.length() > 0)
			{
				urlstr = urlstr+"/"+nitro_util.encode(nitro_util.encode(name));
			}

			if(req_args != null || (service.get_warning()!=null && service.get_warning())){
				urlstr = urlstr+"?";
				if(req_args != null)
				{
					urlstr = urlstr + "args=" + req_args;
				}
				if(service.get_warning()!=null && service.get_warning())
				{
					if (req_args != null)
					{
						urlstr = urlstr+"&";
					}
					urlstr = urlstr + "warning=yes";
				}
			}

			URL url = new URL(urlstr);
			httpURLConnection = (HttpURLConnection) url.openConnection();

			httpURLConnection.setRequestMethod("DELETE");

			httpURLConnection.setRequestProperty("Cookie", "sessionid=" + nitro_util.encode(sessionid));
			httpURLConnection.setRequestProperty("Accept-Encoding", "gzip, deflate");

			if (httpURLConnection instanceof HttpsURLConnection)
			{
				if (service.get_certvalidation()) {
					SocketFactory sslSocketFactory = SSLSocketFactory.getDefault();
					HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);	
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				} else {
					SSLContext sslContext = SSLContext.getInstance("SSL");
					
					
					
					sslContext.init(null, new TrustManager[]{new EmptyTrustManager()}, null);
					SocketFactory sslSocketFactory = sslContext.getSocketFactory();
					
					HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				}
			}

			InputStream input;
			try {
				input = httpURLConnection.getInputStream();
			}
			catch (Exception e) {
				input = httpURLConnection.getErrorStream();	
			}
			String contentEncoding = httpURLConnection.getContentEncoding();
			
			if (contentEncoding != null)
			{
				if(contentEncoding.equalsIgnoreCase("gzip"))
					input = new GZIPInputStream(input); 
				else if(contentEncoding.equalsIgnoreCase("deflate"))
					input = new InflaterInputStream(input);
			}

			int numOfTotalBytesRead;
			byte [] buffer = new byte[1024];
			while ((numOfTotalBytesRead = input.read(buffer, 0, buffer.length)) != -1)
			{
				responseStr.append(new String(buffer, 0, numOfTotalBytesRead));
			}

			httpURLConnection.disconnect();
			input.close();
		}
		catch (MalformedURLException mue)
		{
			throw mue;
		}
		catch (IOException ioe)
		{
			throw ioe;
		}
		catch(Exception e)
		{
			throw e;
		}
		base_response result =(base_response) service.get_payload_formatter().string_to_resource(base_response.class, responseStr.toString());
        if (result.errorcode != 0) 
        {
			if (result.errorcode == 444) {
				service.clear_session();
			}
			if(result.severity != null)
			{
				if(result.severity.equals("ERROR"))
					throw new nitro_exception(result.message,result.errorcode);
			}
			else
			{
				throw new nitro_exception(result.message,result.errorcode);
			}
		}
		return result;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting NetScaler Nitro base_resource.delete_request Simulation...\n");

        HttpServer server = null;
        try {
            
            server = HttpServer.create(new InetSocketAddress(0), 0);
            
            
            server.createContext("/nitro/v1/config/lbvserver/my_lb_vserver", new HttpHandler() {
                @Override
                public void handle(HttpExchange exchange) throws IOException {
                    String method = exchange.getRequestMethod();
                    System.out.println("SERVER: Received " + method + " request at " + exchange.getRequestURI());
                    
                    String query = exchange.getRequestURI().getQuery();
                    String responsePayload;
                    
                    if ("DELETE".equals(method)) {
                        if (query != null && query.contains("force=true")) {
                            
                            responsePayload = "{ \"errorcode\": 0, \"message\": \"Done\" }";
                            exchange.sendResponseHeaders(200, responsePayload.length());
                        } else {
                            
                            responsePayload = "{ \"errorcode\": 444, \"message\": \"Session Expired\", \"severity\": \"ERROR\" }";
                            exchange.sendResponseHeaders(401, responsePayload.length());
                        }
                    } else {
                        responsePayload = "{ \"errorcode\": 400 }";
                        exchange.sendResponseHeaders(400, responsePayload.length());
                    }
                    
                    OutputStream os = exchange.getResponseBody();
                    os.write(responsePayload.getBytes());
                    os.close();
                }
            });
            server.setExecutor(null);
            server.start();

            int port = server.getAddress().getPort();
            System.out.println("Mock NetScaler Server started on port: " + port + "\n");

            method_1_netscaler_gemini resource = new method_1_netscaler_gemini();
            nitro_service service = new nitro_service();
            service.set_ipaddress("127.0.0.1:" + port);

            System.out.println("--- Scenario 1: Successful DELETE Request (with args) ---");
            try {
                base_response resp = resource.delete_request(service, "force=true");
                System.out.println("Success! Response: " + resp.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }

            System.out.println("\n--- Scenario 2: Failed DELETE Request (triggers 444 Session Clear) ---");
            try {
                
                resource.delete_request(service, null);
            } catch (nitro_exception e) {
                System.out.println("Expected nitro_exception caught: Code=" + e.errorcode + ", Message=" + e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (server != null) {
                server.stop(0);
                System.out.println("\nMock Server stopped.");
            }
        }
        System.out.println("Execution Complete.");
    }
}