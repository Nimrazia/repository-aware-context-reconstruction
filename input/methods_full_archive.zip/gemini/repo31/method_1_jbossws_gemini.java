



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.nio.file.Files;

interface ExecutableTask {
    void execute() throws method_1_jbossws_gemini.BuildException;
}

public class method_1_jbossws_gemini implements ExecutableTask {

    
    
    

    public static class BuildException extends RuntimeException {
        public BuildException(Throwable cause) { super(cause); }
    }

    public interface Project {}

    public static class DirectoryScanner {
        private File basedir;
        private String[] includedFiles;

        public DirectoryScanner(File basedir, String[] includedFiles) {
            this.basedir = basedir;
            this.includedFiles = includedFiles;
        }

        public File getBasedir() { return basedir; }
        public String[] getIncludedFiles() { return includedFiles; }
    }

    public static class FileSet {
        private File basedir;
        private String[] files;

        public FileSet(File basedir, String[] files) {
            this.basedir = basedir;
            this.files = files;
        }

        public DirectoryScanner getDirectoryScanner(Project p) {
            return new DirectoryScanner(basedir, files);
        }
    }

    
    
    

    protected FileSet fileset;
    protected Project project;
    protected File targetDir;

    public method_1_jbossws_gemini(FileSet fileset, Project project, File targetDir) {
        this.fileset = fileset;
        this.project = project;
        this.targetDir = targetDir;
    }

    public Project getProject() {
        return project;
    }

    public String readFileContents(File file) {
        return "<module xmlns=\"urn:jboss:module:1.1\">\n    <resources>\n        <!-- jars go here -->\n    </resources>\n</module>";
    }

    public String updateContents(String content, String[] libs) {
        return content.replace("<!-- jars go here -->", "<resource-root path=\"lib.jar\"/>");
    }


// ORIGINAL CODESEARCHNET METHOD — START

@Override
   public void execute() throws BuildException
   {
      try
      {
         DirectoryScanner dsc = fileset.getDirectoryScanner(getProject());
         File baseDir = dsc.getBasedir();
         String[] files = dsc.getIncludedFiles();
         for (int i = 0; i < files.length; i++)
         {
            String currentFile = files[i];
            File moduleXml = new File(baseDir, currentFile);
            String modulePath = currentFile.substring(0, currentFile.lastIndexOf(File.separator));
            File libDir = new File(targetDir, modulePath);
            File destFile = new File(targetDir, currentFile);
            System.out.println("Processing descriptor for module " + modulePath);
            System.out.println("* Source module descriptor: " + moduleXml);
            System.out.println("* Destination module descriptor: " + destFile);
            String c = readFileContents(moduleXml);
            if (libDir.exists())
            {
               String[] libs = libDir.list(new FilenameFilter()
               {
                  @Override
                  public boolean accept(File dir, String name)
                  {
                     return name.endsWith(".jar") || name.endsWith(".ear") || name.endsWith(".sar")
                           || name.endsWith(".war");
                  }
               });
               BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
               out.write(updateContents(c, libs));
               out.close();
            }
            else
            {
               libDir.mkdirs();
               BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
               out.write(c);
               out.close();
            }
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new BuildException(e);
      }
   }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting InstallModulesTask.execute Simulation...\n");

        try {
            File tempDir = Files.createTempDirectory("jbossws_test").toFile();
            File srcDir = new File(tempDir, "src");
            File outDir = new File(tempDir, "out");
            srcDir.mkdirs();
            outDir.mkdirs();

            
            File subModDir = new File(srcDir, "org" + File.separator + "jboss" + File.separator + "ws");
            subModDir.mkdirs();
            File mockXml = new File(subModDir, "module.xml");
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(mockXml))) {
                bw.write("<module/>");
            }

            String relPath = "org" + File.separator + "jboss" + File.separator + "ws" + File.separator + "module.xml";
            FileSet fs = new FileSet(srcDir, new String[]{ relPath });

            method_1_jbossws_gemini task = new method_1_jbossws_gemini(fs, null, outDir);
            task.execute();

            System.out.println("\nExecution Successful!");
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}