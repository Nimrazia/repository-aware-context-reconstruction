



import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class method_3_geomajas_gemini {

    
    
    

    public static class Geometry {
        private double area;
        private String description;

        public Geometry(String description, double area) {
            this.description = description;
            this.area = area;
        }

        public double getArea() { return area; }
        public Geometry buffer(double distance) {
            return new Geometry(description + "-buffered(" + distance + ")", area * 1.5);
        }
        public Geometry intersection(Geometry other) {
            return new Geometry("intersection", Math.min(this.area, other.area) * 0.8);
        }

        @Override
        public String toString() { return description + " [area=" + area + "]"; }
    }

    public static class Crs {}

    public static class FeatureInfo {
        private GeometryType geometryType = new GeometryType("Polygon");
        public GeometryType getGeometryType() { return geometryType; }
    }

    public static class GeometryType {
        private String name;
        public GeometryType(String name) { this.name = name; }
        public String getName() { return name; }
    }

    public static class LayerInfo {
        private FeatureInfo featureInfo = new FeatureInfo();
        public FeatureInfo getFeatureInfo() { return featureInfo; }
    }

    public static class VectorLayer {
        private LayerInfo layerInfo = new LayerInfo();
        public LayerInfo getLayerInfo() { return layerInfo; }
    }

    public static interface Filter {
        void apply();
    }

    public static class InternalFeature {
        private String id;
        private Geometry geometry;

        public InternalFeature(String id, Geometry geometry) {
            this.id = id;
            this.geometry = geometry;
        }

        public Geometry getGeometry() { return geometry; }
        @Override
        public String toString() { return "InternalFeature{id='" + id + "', geom=" + geometry + "}"; }
    }

    public static class Feature {
        private String id;
        private String crs;

        public Feature(String id) { this.id = id; }
        public void setCrs(String crs) { this.crs = crs; }
        @Override
        public String toString() { return "FeatureDto{id='" + id + "', crs='" + crs + "'}"; }
    }

    public static class SearchByLocationRequest {
        public static final int QUERY_INTERSECTS = 1;
        public static final int QUERY_CONTAINS = 2;
        public static final int QUERY_TOUCHES = 3;
        public static final int QUERY_WITHIN = 4;
        public static final int SEARCH_FIRST_LAYER = 1;
        public static final int SEARCH_ALL_LAYERS = 2;

        private String[] layerIds = new String[]{"client_layer_1"};
        private String crs = "EPSG:4326";
        private Geometry location = new Geometry("Point(0 0)", 10.0);
        private int queryType = QUERY_INTERSECTS;
        private double ratio = 0.5;
        private int searchType = SEARCH_ALL_LAYERS;
        private double buffer = 2.0;
        private Map<String, String> serverIdMap = new HashMap<>();

        public SearchByLocationRequest() {
            serverIdMap.put("client_layer_1", "server_layer_1");
        }

        public String[] getLayerIds() { return layerIds; }
        public String getCrs() { return crs; }
        public Geometry getLocation() { return location; }
        public int getQueryType() { return queryType; }
        public double getRatio() { return ratio; }
        public int getSearchType() { return searchType; }
        public double getBuffer() { return buffer; }
        public String getServerLayerId(String clientLayerId) { return serverIdMap.get(clientLayerId); }
        public String getFilter(String clientLayerId) { return null; }
        public String getFilter() { return null; }
        public List<String> getFeatureIncludes() { return new ArrayList<>(); }
    }

    public static class SearchByLocationResponse {
        private Map<String, List<Feature>> layers = new HashMap<>();
        public void addLayer(String clientLayerId, List<Feature> features) {
            layers.put(clientLayerId, features);
        }
        public Map<String, List<Feature>> getLayers() { return layers; }
    }

    public enum ExceptionCode {
        PARAMETER_MISSING, RENDER_DIMENSION_MISMATCH
    }

    public static class GeomajasException extends Exception {
        private ExceptionCode code;
        public GeomajasException(ExceptionCode code, String message) {
            super(message);
            this.code = code;
        }
    }

    
    public interface GeometryConverter {
        Geometry toInternal(Geometry external);
        Feature toDto(InternalFeature internal);
    }

    public interface GeoService {
        Crs getCrs2(String crsCode);
        Geometry transform(Geometry geom, Crs from, Crs to);
    }

    public interface SecurityContext {
        boolean isLayerVisible(String layerId);
    }

    public interface ConfigurationService {
        VectorLayer getVectorLayer(String layerId);
    }

    public interface LayerService {
        Crs getCrs(VectorLayer layer);
        List<InternalFeature> getFeatures(String layerId, Crs crs, Filter filter, Object bbox, List<String> includes);
    }

    public interface FilterCreator {
        Filter createIntersectsFilter(Geometry geom, String geomName);
        Filter createContainsFilter(Geometry geom, String geomName);
        Filter createTouchesFilter(Geometry geom, String geomName);
        Filter createWithinFilter(Geometry geom, String geomName);
        Filter parseFilter(String expression);
        Filter createAndFilter(Filter f1, Filter f2);
    }

    public static class Logger {
        public void debug(String msg) { System.out.println("DEBUG: " + msg); }
        public void trace(String msg) { System.out.println("TRACE: " + msg); }
    }

    
    
    

    private Logger log = new Logger();
    private GeometryConverter converter;
    private GeoService geoService;
    private SecurityContext securityContext;
    private ConfigurationService configurationService;
    private LayerService layerService;
    private FilterCreator filterCreator;

    public method_3_geomajas_gemini(GeometryConverter converter, GeoService geoService,
                                      SecurityContext securityContext, ConfigurationService configurationService,
                                      LayerService layerService, FilterCreator filterCreator) {
        this.converter = converter;
        this.geoService = geoService;
        this.securityContext = securityContext;
        this.configurationService = configurationService;
        this.layerService = layerService;
        this.filterCreator = filterCreator;
    }


// ORIGINAL CODESEARCHNET METHOD — START

	public void execute(SearchByLocationRequest request, SearchByLocationResponse response) throws Exception {
		if (null == request.getLayerIds()) {
			throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, "layerIds");
		}
		String crsCode = request.getCrs();
		if (null == crsCode) {
			throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, "crs");
		}
		Geometry location = converter.toInternal(request.getLocation());
		int queryType = request.getQueryType();
		double ratio = request.getRatio();
		int searchType = request.getSearchType();
		Crs crs = geoService.getCrs2(request.getCrs());

		
		Geometry geometry = location;
		if (request.getBuffer() > 0) {
			geometry = location.buffer(request.getBuffer());
		}
		log.debug("search by location " + geometry);

		for (String clientLayerId : request.getLayerIds()) {
			String serverLayerId = request.getServerLayerId(clientLayerId);
			if (null == serverLayerId) {
				throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, 
								"serverLayerId for clientLayerId " + clientLayerId);
			}
			if (securityContext.isLayerVisible(serverLayerId)) {
				VectorLayer vectorLayer = configurationService.getVectorLayer(serverLayerId);
				if (vectorLayer != null) {
					String geomName = vectorLayer.getLayerInfo().getFeatureInfo().getGeometryType().getName();

					
					Geometry layerGeometry = geoService.transform(geometry, crs, layerService.getCrs(vectorLayer));
					log.trace("on layer " + serverLayerId + " use " + layerGeometry);

					
					Filter f = null;
					switch (queryType) {
						case SearchByLocationRequest.QUERY_INTERSECTS:
							f = filterCreator.createIntersectsFilter(layerGeometry, geomName);
							break;
						case SearchByLocationRequest.QUERY_CONTAINS:
							f = filterCreator.createContainsFilter(layerGeometry, geomName);
							break;
						case SearchByLocationRequest.QUERY_TOUCHES:
							f = filterCreator.createTouchesFilter(layerGeometry, geomName);
							break;
						case SearchByLocationRequest.QUERY_WITHIN:
							f = filterCreator.createWithinFilter(layerGeometry, geomName);
							break;
						default:
							throw new IllegalArgumentException("Unknown query type " + queryType);
					}
					
					if (null != request.getFilter(clientLayerId)) {
						if (null == f) {
							f = filterCreator.parseFilter(request.getFilter(clientLayerId));
						} else {
							f = filterCreator.createAndFilter(
									filterCreator.parseFilter(request.getFilter(clientLayerId)), f);
						}
					}
					
					if (null != request.getFilter()) {
						if (null == f) {
							f = filterCreator.parseFilter(request.getFilter());
						} else {
							f = filterCreator.createAndFilter(filterCreator.parseFilter(request.getFilter()), f);
						}
					}

					
					List<InternalFeature> temp = layerService.getFeatures(serverLayerId, crs, f, null, request
							.getFeatureIncludes());
					if (temp.size() > 0) {
						List<Feature> features = new ArrayList<Feature>();

						
						if (queryType == SearchByLocationRequest.QUERY_INTERSECTS && ratio >= 0 && ratio < 1) {
							for (InternalFeature feature : temp) {
								double minimalOverlap = feature.getGeometry().getArea() * ratio;
								Geometry overlap = geometry.intersection(feature.getGeometry());
								double effectiveOverlap = overlap.getArea();
								if (minimalOverlap <= effectiveOverlap) {
									log.trace("found " + feature);
									Feature dto = converter.toDto(feature);
									dto.setCrs(crsCode);
									features.add(dto);
								}
							}
						} else {
							for (InternalFeature feature : temp) {
								log.trace("found " + feature);
								Feature dto = converter.toDto(feature);
								dto.setCrs(crsCode);
								features.add(dto);
							}
						}

						
						if (features.size() > 0) {
							
							response.addLayer(clientLayerId, features);

							
							if (searchType == SearchByLocationRequest.SEARCH_FIRST_LAYER) {
								break;
							}
						}
					}
				}
			}
		}
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting SearchByLocationCommand execute Simulation...\n");

        GeometryConverter mockConverter = new GeometryConverter() {
            public Geometry toInternal(Geometry external) { return external; }
            public Feature toDto(InternalFeature internal) { return new Feature(internal.id); }
        };

        GeoService mockGeoService = new GeoService() {
            public Crs getCrs2(String crsCode) { return new Crs(); }
            public Geometry transform(Geometry geom, Crs from, Crs to) { return geom; }
        };

        SecurityContext mockSecCtx = layerId -> true;
        ConfigurationService mockCfgSvc = layerId -> new VectorLayer();

        LayerService mockLayerSvc = new LayerService() {
            public Crs getCrs(VectorLayer layer) { return new Crs(); }
            public List<InternalFeature> getFeatures(String layerId, Crs crs, Filter filter, Object bbox, List<String> includes) {
                List<InternalFeature> features = new ArrayList<>();
                features.add(new InternalFeature("parcel_101", new Geometry("Polygon(10 10)", 20.0)));
                return features;
            }
        };

        FilterCreator mockFilterCreator = new FilterCreator() {
            public Filter createIntersectsFilter(Geometry geom, String geomName) { return () -> {}; }
            public Filter createContainsFilter(Geometry geom, String geomName) { return () -> {}; }
            public Filter createTouchesFilter(Geometry geom, String geomName) { return () -> {}; }
            public Filter createWithinFilter(Geometry geom, String geomName) { return () -> {}; }
            public Filter parseFilter(String expression) { return () -> {}; }
            public Filter createAndFilter(Filter f1, Filter f2) { return () -> {}; }
        };

        method_3_geomajas_gemini command = new method_3_geomajas_gemini(
            mockConverter, mockGeoService, mockSecCtx, mockCfgSvc, mockLayerSvc, mockFilterCreator
        );

        SearchByLocationRequest request = new SearchByLocationRequest();
        SearchByLocationResponse response = new SearchByLocationResponse();

        try {
            command.execute(request, response);
            System.out.println("\nExecution Successful!");
            System.out.println("Layers found in response: " + response.getLayers().size());
            for (Map.Entry<String, List<Feature>> entry : response.getLayers().entrySet()) {
                System.out.println(" -> Client Layer ID: " + entry.getKey() + ", Features: " + entry.getValue());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}