



import java.util.HashMap;
import java.util.Map;

public class method_1_geomajas_gemini {

    public static class ClientWidgetInfo {
        private String widgetId;
        public ClientWidgetInfo(String widgetId) { this.widgetId = widgetId; }
        public String getWidgetId() { return widgetId; }
        @Override
        public String toString() { return "ClientWidgetInfo{id='" + widgetId + "'}"; }
    }

    public static class ServerSideOnlyInfo extends ClientWidgetInfo {
        public ServerSideOnlyInfo(String widgetId) { super(widgetId); }
    }


// ORIGINAL CODESEARCHNET METHOD — START

public Map<String, ClientWidgetInfo> securityClone(Map<String, ClientWidgetInfo> widgetInfo) {
		Map<String, ClientWidgetInfo> res = new HashMap<String, ClientWidgetInfo>();
		for (Map.Entry<String, ClientWidgetInfo> entry : widgetInfo.entrySet()) {
			ClientWidgetInfo value = entry.getValue();
			if (!(value instanceof ServerSideOnlyInfo)) {
				res.put(entry.getKey(), value);
			}
		}
		return res;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        method_1_geomajas_gemini command = new method_1_geomajas_gemini();

        Map<String, ClientWidgetInfo> inputWidgets = new HashMap<>();
        inputWidgets.put("widget1", new ClientWidgetInfo("toolbar"));
        inputWidgets.put("widget2", new ServerSideOnlyInfo("secret-admin-panel"));
        inputWidgets.put("widget3", new ClientWidgetInfo("map-canvas"));

        Map<String, ClientWidgetInfo> clonedWidgets = command.securityClone(inputWidgets);

        System.out.println("Cloned Widgets:");
        for (Map.Entry<String, ClientWidgetInfo> entry : clonedWidgets.entrySet()) {
            System.out.println(" -> " + entry.getKey() + ": " + entry.getValue());
        }
    }
}
