



import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_2_geomajas_gemini {

    public static class ClientWidgetInfo implements Serializable {}

    public static class LayerInfo implements Serializable {
        private Map<String, Object> extraInfo = new HashMap<>();
        public Map<String, Object> getExtraInfo() { return extraInfo; }
        public void setExtraInfo(Map<String, Object> extraInfo) { this.extraInfo = extraInfo; }
    }

    public static class AttributeInfo implements Serializable {
        private String name;
        public AttributeInfo(String name) { this.name = name; }
        public String getName() { return name; }
    }

    public static class FeatureInfo implements Serializable {
        private List<AttributeInfo> attributes = new ArrayList<>();
        public List<AttributeInfo> getAttributes() { return attributes; }
        public void setAttributes(List<AttributeInfo> attributes) { this.attributes = attributes; }
    }

    public static class ClientLayerInfo implements Serializable {
        private String serverLayerId;
        private Map<String, ClientWidgetInfo> widgetInfo = new HashMap<>();
        private LayerInfo layerInfo = new LayerInfo();

        public ClientLayerInfo(String serverLayerId) { this.serverLayerId = serverLayerId; }
        public String getServerLayerId() { return serverLayerId; }
        public Map<String, ClientWidgetInfo> getWidgetInfo() { return widgetInfo; }
        public void setWidgetInfo(Map<String, ClientWidgetInfo> widgetInfo) { this.widgetInfo = widgetInfo; }
        public LayerInfo getLayerInfo() { return layerInfo; }
    }

    public static class ClientVectorLayerInfo extends ClientLayerInfo {
        private boolean creatable;
        private boolean updatable;
        private boolean deletable;
        private FeatureInfo featureInfo = new FeatureInfo();

        public ClientVectorLayerInfo(String serverLayerId) { super(serverLayerId); }
        public void setCreatable(boolean creatable) { this.creatable = creatable; }
        public void setUpdatable(boolean updatable) { this.updatable = updatable; }
        public void setDeletable(boolean deletable) { this.deletable = deletable; }
        public FeatureInfo getFeatureInfo() { return featureInfo; }

        @Override
        public String toString() {
            return "ClientVectorLayerInfo{id='" + getServerLayerId() + "', creatable=" + creatable +
                   ", updatable=" + updatable + ", deletable=" + deletable +
                   ", attributes=" + featureInfo.getAttributes().size() + "}";
        }
    }

    public interface SecurityContext {
        boolean isLayerVisible(String layerId);
        boolean isLayerCreateAuthorized(String layerId);
        boolean isLayerUpdateAuthorized(String layerId);
        boolean isLayerDeleteAuthorized(String layerId);
        boolean isAttributeReadable(String layerId, String feature, String attributeName);
    }

    static class SerializationUtils {
        public static Object clone(Serializable object) {
            return object;
        }
    }

    private SecurityContext securityContext;

    public method_2_geomajas_gemini(SecurityContext securityContext) {
        this.securityContext = securityContext;
    }

    public Map<String, ClientWidgetInfo> securityClone(Map<String, ClientWidgetInfo> widgetInfo) {
        return widgetInfo;
    }

    public Map<String, Object> securityCloneLayerExtraInfo(Map<String, Object> extraInfo) {
        return extraInfo;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public ClientLayerInfo securityClone(ClientLayerInfo original) {
		
		if (null == original) {
			return null;
		}
		ClientLayerInfo client = null;
		String layerId = original.getServerLayerId();
		if (securityContext.isLayerVisible(layerId)) {
			client = (ClientLayerInfo) SerializationUtils.clone(original);
			client.setWidgetInfo(securityClone(original.getWidgetInfo()));
			client.getLayerInfo().setExtraInfo(securityCloneLayerExtraInfo(original.getLayerInfo().getExtraInfo()));
			if (client instanceof ClientVectorLayerInfo) {
				ClientVectorLayerInfo vectorLayer = (ClientVectorLayerInfo) client;
				
				vectorLayer.setCreatable(securityContext.isLayerCreateAuthorized(layerId));
				vectorLayer.setUpdatable(securityContext.isLayerUpdateAuthorized(layerId));
				vectorLayer.setDeletable(securityContext.isLayerDeleteAuthorized(layerId));
				
				FeatureInfo featureInfo = vectorLayer.getFeatureInfo();
				List<AttributeInfo> originalAttr = featureInfo.getAttributes();
				List<AttributeInfo> filteredAttr = new ArrayList<AttributeInfo>();
				featureInfo.setAttributes(filteredAttr);
				for (AttributeInfo ai : originalAttr) {
					if (securityContext.isAttributeReadable(layerId, null, ai.getName())) {
						filteredAttr.add(ai);
					}
				}
			}
		}
		return client;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        SecurityContext mockSecurityContext = new SecurityContext() {
            public boolean isLayerVisible(String layerId) { return true; }
            public boolean isLayerCreateAuthorized(String layerId) { return true; }
            public boolean isLayerUpdateAuthorized(String layerId) { return false; }
            public boolean isLayerDeleteAuthorized(String layerId) { return false; }
            public boolean isAttributeReadable(String layerId, String feature, String attributeName) {
                return !"secret_token".equals(attributeName);
            }
        };

        method_2_geomajas_gemini command = new method_2_geomajas_gemini(mockSecurityContext);

        ClientVectorLayerInfo inputLayer = new ClientVectorLayerInfo("vector_parcels");
        inputLayer.getFeatureInfo().getAttributes().add(new AttributeInfo("id"));
        inputLayer.getFeatureInfo().getAttributes().add(new AttributeInfo("name"));
        inputLayer.getFeatureInfo().getAttributes().add(new AttributeInfo("secret_token"));

        ClientLayerInfo clonedLayer = command.securityClone(inputLayer);
        System.out.println(clonedLayer);
    }
}
