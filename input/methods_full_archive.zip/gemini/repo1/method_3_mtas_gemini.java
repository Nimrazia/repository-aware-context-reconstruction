import java.io.IOException;
import java.util.*;


public class method_3_mtas_gemini {

    
    static final String NAME = "termvector";
    static final String PARAM_MTAS_TERMVECTOR = "mtas.termvector";
    static final String NAME_MTAS_TERMVECTOR_BOUNDARY = "boundary";
    static final String NAME_MTAS_TERMVECTOR_FIELD = "field";
    static final String NAME_MTAS_TERMVECTOR_PREFIX = "prefix";
    static final String NAME_MTAS_TERMVECTOR_KEY = "key";
    static final String NAME_MTAS_TERMVECTOR_NUMBER = "number";
    static final String NAME_MTAS_TERMVECTOR_SORT_TYPE = "sort.type";
    static final String NAME_MTAS_TERMVECTOR_SORT_DIRECTION = "sort.direction";
    static final String NAME_MTAS_TERMVECTOR_TYPE = "type";
    static final String NAME_MTAS_TERMVECTOR_DISTANCE = "distance";
    static final String NAME_MTAS_TERMVECTOR_DISTANCE_TYPE = "type";
    static final String NAME_MTAS_TERMVECTOR_DISTANCE_BASE = "base";
    static final String NAME_MTAS_TERMVECTOR_DISTANCE_KEY = "key";
    static final String NAME_MTAS_TERMVECTOR_DISTANCE_MINIMUM = "minimum";
    static final String NAME_MTAS_TERMVECTOR_DISTANCE_MAXIMUM = "maximum";
    static final String NAME_MTAS_TERMVECTOR_DISTANCE_PARAMETER = "parameter";
    static final String NAME_MTAS_TERMVECTOR_FUNCTION = "function";
    static final String NAME_MTAS_TERMVECTOR_FUNCTION_EXPRESSION = "expression";
    static final String NAME_MTAS_TERMVECTOR_FUNCTION_KEY = "key";
    static final String NAME_MTAS_TERMVECTOR_FUNCTION_TYPE = "type";
    static final String NAME_MTAS_TERMVECTOR_REGEXP = "regexp";

    private Object searchComponent = new Object();

    
    static class CommonParams {
        static final String FQ = "fq";
        static final String Q = "q";
        static final String CACHE = "cache";
        static final String ROWS = "rows";
    }

    static class ModifiableSolrParams {
        Map<String, List<String>> params = new HashMap<>();
        public void add(String name, String[] vals) {
            if (vals != null) params.computeIfAbsent(name, k -> new ArrayList<>()).addAll(Arrays.asList(vals));
        }
        public void add(String name, String val) {
            if (val != null) params.computeIfAbsent(name, k -> new ArrayList<>()).add(val);
        }
        public Set<String> getParameterNames() { return params.keySet(); }
        public boolean getBool(String name, boolean def) { return true; } 
    }

    static class SolrParams {
        public String[] getParams(String param) { return new String[]{"mock_param_value"}; }
    }

    static class SolrQueryRequest {
        public SolrParams getParams() { return new SolrParams(); }
        public SolrParams getOriginalParams() { return new SolrParams(); }
    }

    static class NamedList<T> {
        Map<String, T> map = new LinkedHashMap<>();
        public void add(String name, T val) { map.put(name, val); }
        public T get(String name) { return map.get(name); }
        public void clear() { map.clear(); }
        public Object findRecursive(String... args) { 
            if (args.length == 2 && args[0].equals("mtas") && args[1].equals(NAME)) {
                return map.get("mock_recursive_list");
            }
            return null;
        }
    }

    static class SolrResponse {
        NamedList<Object> response = new NamedList<>();
        public NamedList<Object> getResponse() { return response; }
        public void setResponse(NamedList<Object> response) { this.response = response; }
    }

    static class ShardResponse {
        SolrResponse solrResponse = new SolrResponse();
        String shardAddress;
        public ShardResponse(String addr) { this.shardAddress = addr; }
        public SolrResponse getSolrResponse() { return solrResponse; }
        public String getShardAddress() { return shardAddress; }
    }

    static class ShardRequest {
        static final int PURPOSE_PRIVATE = 1;
        public String[] shards;
        public int purpose;
        public ModifiableSolrParams params = new ModifiableSolrParams();
        public List<ShardResponse> responses = new ArrayList<>();
    }

    static class ResponseBuilder {
        public List<ShardRequest> finished = new ArrayList<>();
        public List<ShardRequest> newRequestsAdded = new ArrayList<>();
        public SolrQueryRequest req = new SolrQueryRequest();
        public void addRequest(Object component, ShardRequest sreq) {
            newRequestsAdded.add(sreq);
        }
    }

    
    static class Log {
        void debug(Exception e) { }
    }
    private static final Log log = new Log();

    static class MtasSolrSearchComponent {
        static final String PARAM_MTAS = "mtas";
    }

    static class CodecUtil {
        static final String SORT_TERM = "term";
        static final String SORT_DESC = "desc";
    }

    static class MtasDataItemNumberComparator {
        long value;
        public MtasDataItemNumberComparator(long value) { this.value = value; }
        public Long getValue() { return value; }
        public int compareTo(Long o) { return Long.compare(this.value, o); }
        public MtasDataItemNumberComparator clone() { return new MtasDataItemNumberComparator(this.value); }
        public void add(Long val) { this.value += val; }
        public void subtract(Long val) { this.value -= val; }
        public MtasDataItemNumberComparator recomputeBoundary(int size) { return new MtasDataItemNumberComparator(this.value / (size > 0 ? size : 1)); }
        @Override public String toString() { return String.valueOf(value); }
    }

    static class ResultData {
        MtasDataItemNumberComparator lastSortValue;
        Map<String, MtasDataItemNumberComparator> comparatorList = new HashMap<>();
        public MtasDataItemNumberComparator getLastSortValue() { return lastSortValue; }
        public Map<String, MtasDataItemNumberComparator> getComparatorList() { return comparatorList; }
    }

    static class MtasSolrMtasResult {
        ResultData result = new ResultData();
        public ResultData getResult() { return result; }
    }

    static class SubComponentFunction {
        String sortType = CodecUtil.SORT_DESC;
        String sortDirection = CodecUtil.SORT_DESC;
        String type = "mock_type";
        String expression = "mock_expr";
        String key = "mock_key";
    }

    static class SubComponentDistance {
        String type = "mock_distance";
        String base = "mock_base";
        String key;
        Integer minimum;
        Integer maximum;
        Map<String, String> parameters;
    }

    static class ComponentTermVector {
        String key = "tv1";
        String prefix = "mock_prefix";
        String regexp = null;
        int number = 2; 
        SubComponentFunction subComponentFunction = new SubComponentFunction();
        List<Object> distances = null;
        List<SubComponentFunction> functions = new ArrayList<>();
        
        public ComponentTermVector() {
            functions.add(new SubComponentFunction());
        }
    }

    static class ComponentFieldWrapper {
        List<ComponentTermVector> termVectorList = new ArrayList<>();
    }

    static class ComponentFields {
        Map<String, ComponentFieldWrapper> list = new HashMap<>();
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private void distributedProcessMissingTop(ResponseBuilder rb,
          ComponentFields mtasFields) throws IOException {
        
        Map<String, SortedMap<String, MtasDataItemNumberComparator>> mergedComparatorLists = new HashMap<>();
        Map<String, MtasDataItemNumberComparator> mergedComparatorBoundaryList = new HashMap<>();
        Map<String, MtasDataItemNumberComparator> summedComparatorBoundaryList = new HashMap<>();
        Map<String, Map<String, MtasDataItemNumberComparator>> comparatorBoundariesList = new HashMap<>();
        
        for (String field : mtasFields.list.keySet()) {
          List<ComponentTermVector> tvList = mtasFields.list
              .get(field).termVectorList;
          if (tvList != null) {
            for (ComponentTermVector tv : tvList) {
              if (!tv.subComponentFunction.sortType.equals(CodecUtil.SORT_TERM)) {
                mergedComparatorLists.put(tv.key,
                    new TreeMap<String, MtasDataItemNumberComparator>());
              }
            }
          }
        }
        
        
        for (ShardRequest sreq : rb.finished) {
          if (sreq.params.getBool(MtasSolrSearchComponent.PARAM_MTAS, false)
              && sreq.params.getBool(PARAM_MTAS_TERMVECTOR, false)) {
            for (ShardResponse shardResponse : sreq.responses) {
              SortedMap<String, MtasDataItemNumberComparator> mergedComparatorList;
              NamedList<Object> response = shardResponse.getSolrResponse()
                  .getResponse();
              String key;
              MtasSolrMtasResult list;
              MtasDataItemNumberComparator comparatorLast;
              Map<String, MtasDataItemNumberComparator> comparatorList;
              try {
                List<NamedList<Object>> data = (List<NamedList<Object>>) response
                    .findRecursive("mtas", NAME);
                if (data != null) {
                  for (int i = 0; i < data.size(); i++) {
                    NamedList<Object> dataItem = data.get(i);
                    try {
                      key = (String) dataItem.get("key");
                      list = (MtasSolrMtasResult) dataItem.get("list");
                      if (list != null) {
                        comparatorLast = list.getResult().getLastSortValue();
                        comparatorList = list.getResult().getComparatorList();
                        if (key == null) {
                          dataItem.clear();
                        } else if (comparatorLast == null || comparatorList == null
                            || !mergedComparatorLists.containsKey(key)) {
                          
                        } else {
                          mergedComparatorList = mergedComparatorLists.get(key);
                          for (Map.Entry<String, MtasDataItemNumberComparator> entry : comparatorList
                              .entrySet()) {
                            if (mergedComparatorList.containsKey(entry.getKey())) {
                              mergedComparatorList.get(entry.getKey())
                                  .add(entry.getValue().getValue());
                            } else {
                              mergedComparatorList.put(entry.getKey(),
                                  entry.getValue().clone());
                            }
                          }
                          if (!comparatorBoundariesList.containsKey(key)) {
                            comparatorBoundariesList.put(key,
                                new HashMap<String, MtasDataItemNumberComparator>());
                          }
                          comparatorBoundariesList.get(key)
                              .put(shardResponse.getShardAddress(), comparatorLast);
                          if (summedComparatorBoundaryList.containsKey(key)) {
                            summedComparatorBoundaryList.get(key)
                                .add(comparatorLast.getValue());
                          } else {
                            summedComparatorBoundaryList.put(key,
                                comparatorLast.clone());
                          }
                        }
                      } else {
                        throw new IOException("no data returned");
                      }
                    } catch (ClassCastException e) {
                      log.debug(e);
                      dataItem.clear();
                    }
                  }
                }
              } catch (ClassCastException e) {
                log.debug(e);
                
              }
              shardResponse.getSolrResponse().setResponse(response);
            }
          }
        }
        
        HashMap<String, HashMap<String, HashMap<String, MtasDataItemNumberComparator>>> recomputeFieldList = new HashMap<>();
        for (String field : mtasFields.list.keySet()) {
          List<ComponentTermVector> tvList = mtasFields.list
              .get(field).termVectorList;
          if (tvList != null) {
            for (ComponentTermVector tv : tvList) {
              SortedMap<String, MtasDataItemNumberComparator> mergedComparatorList;
              if (mergedComparatorLists.containsKey(tv.key)) {
                mergedComparatorList = mergedComparatorLists.get(tv.key);
                if (mergedComparatorList.size() < tv.number || tv.number <= 0) {
                  
                } else {
                  final int sortDirection = tv.subComponentFunction.sortDirection
                      .equals(CodecUtil.SORT_DESC) ? -1 : 1;
                  SortedSet<Map.Entry<String, MtasDataItemNumberComparator>> sortedSet = new TreeSet<>(
                      (Map.Entry<String, MtasDataItemNumberComparator> e1,
                          Map.Entry<String, MtasDataItemNumberComparator> e2) -> (e1
                              .getValue().compareTo(e2.getValue().getValue()) == 0)
                                  ? e1.getKey().compareTo(e2.getKey())
                                  : e1.getValue().compareTo(
                                      e2.getValue().getValue()) * sortDirection);
                  sortedSet.addAll(mergedComparatorLists.get(tv.key).entrySet());
                  Optional<Map.Entry<String, MtasDataItemNumberComparator>> optionalItem = sortedSet
                      .stream().skip(tv.number - 1L).findFirst();
                  if (optionalItem.isPresent()) {
                    mergedComparatorBoundaryList.put(tv.key,
                        optionalItem.get().getValue());
                  }
                }
              }
            }
          }
          HashMap<String, HashMap<String, MtasDataItemNumberComparator>> recomputeList = new HashMap<>();
          if (tvList != null) {
            for (ComponentTermVector tv : tvList) {
              String key = tv.key;
              if (mergedComparatorBoundaryList.containsKey(key)
                  && summedComparatorBoundaryList.containsKey(key)) {
                
                recomputeList.put(key,
                    new HashMap<String, MtasDataItemNumberComparator>());
                
                List<Map.Entry<String, MtasDataItemNumberComparator>> list = new LinkedList<>(
                    comparatorBoundariesList.get(key).entrySet());
                Collections.sort(list,
                    (Map.Entry<String, MtasDataItemNumberComparator> e1,
                        Map.Entry<String, MtasDataItemNumberComparator> e2) -> e1
                            .getValue().compareTo(e2.getValue().getValue()));
                HashMap<String, MtasDataItemNumberComparator> sortedHashMap = new LinkedHashMap<>();
                for (Iterator<Map.Entry<String, MtasDataItemNumberComparator>> it = list
                    .iterator(); it.hasNext();) {
                  Map.Entry<String, MtasDataItemNumberComparator> entry = it.next();
                  sortedHashMap.put(entry.getKey(), entry.getValue());
                }

                MtasDataItemNumberComparator mainNewBoundary = mergedComparatorBoundaryList
                    .get(key).recomputeBoundary(sortedHashMap.size());

                MtasDataItemNumberComparator sum = null;
                int number = 0;
                for (Map.Entry<String, MtasDataItemNumberComparator> entry : sortedHashMap
                    .entrySet()) {
                  MtasDataItemNumberComparator newBoundary = mainNewBoundary
                      .clone();
                  MtasDataItemNumberComparator currentBoundary = entry.getValue();
                  int compare = currentBoundary.compareTo(newBoundary.getValue());
                  if (tv.subComponentFunction.sortDirection
                      .equals(CodecUtil.SORT_DESC)) {
                    compare *= -1;
                  }
                  if (compare < 0) {
                    HashMap<String, MtasDataItemNumberComparator> recomputeSubList = new HashMap<>();
                    
                    if (number > 0 && sum != null
                        && tv.subComponentFunction.sortDirection
                            .equals(CodecUtil.SORT_DESC)) {
                      MtasDataItemNumberComparator tmpSumBoundary = mergedComparatorBoundaryList
                          .get(key);
                      tmpSumBoundary.subtract(sum.getValue());
                      MtasDataItemNumberComparator alternativeNewBoundary = tmpSumBoundary
                          .recomputeBoundary(sortedHashMap.size() - number);
                      compare = newBoundary
                          .compareTo(alternativeNewBoundary.getValue());
                      if (compare < 0) {
                        newBoundary = alternativeNewBoundary;
                        compare = currentBoundary.compareTo(newBoundary.getValue());
                        if (tv.subComponentFunction.sortDirection
                            .equals(CodecUtil.SORT_DESC)) {
                          compare *= -1;
                        }
                        if (compare < 0) {
                          recomputeSubList.put(entry.getKey(), newBoundary);
                        }
                      } else {
                        recomputeSubList.put(entry.getKey(), newBoundary);
                      }
                    } else {
                      recomputeSubList.put(entry.getKey(), newBoundary);
                    }
                    if (!recomputeSubList.isEmpty()) {
                      if (!recomputeList.containsKey(key)) {
                        recomputeList.put(key, recomputeSubList);
                      } else {
                        recomputeList.get(key).putAll(recomputeSubList);
                      }
                    }
                  } else {
                    newBoundary = currentBoundary.clone();
                  }
                  if (sum == null) {
                    sum = newBoundary.clone();
                  } else {
                    sum.add(newBoundary.getValue());
                  }
                  number++;
                }
              }
            }
          }
          if (!recomputeList.isEmpty()) {
            recomputeFieldList.put(field, recomputeList);
          }
        }

        
        if (recomputeFieldList.size() > 0) {

          
          HashSet<String> shards = new HashSet<>();
          for (ShardRequest sreq : rb.finished) {
            if (sreq.params.getBool(MtasSolrSearchComponent.PARAM_MTAS, false)
                && sreq.params.getBool(PARAM_MTAS_TERMVECTOR, false)) {
              for (ShardResponse shardResponse : sreq.responses) {
                NamedList<Object> response = shardResponse.getSolrResponse()
                    .getResponse();
                String key;
                String field;
                String shardAddress = shardResponse.getShardAddress();
                try {
                  ArrayList<NamedList<Object>> data = (ArrayList<NamedList<Object>>) response
                      .findRecursive("mtas", NAME);
                  shards.add(shardAddress);
                  if (data != null) {
                    for (int i = 0; i < data.size(); i++) {
                      NamedList<Object> dataItem = data.get(i);
                      try {
                        key = (String) dataItem.get("key");
                        field = (String) dataItem.get("field");
                        boolean doClear;
                        doClear = field != null && key != null;
                        doClear = doClear ? recomputeFieldList.get(field) != null
                            : false;
                        doClear = doClear
                            ? recomputeFieldList.get(field).containsKey(key)
                            : false;
                        doClear = doClear ? recomputeFieldList.get(field).get(key)
                            .containsKey(shardAddress) : false;
                        if (doClear) {
                          dataItem.clear();
                          dataItem.add("key", key);
                        }
                      } catch (ClassCastException e) {
                        log.debug(e);
                        dataItem.clear();
                      }
                    }
                  }
                } catch (ClassCastException e) {
                  log.debug(e);
                  
                }
                shardResponse.getSolrResponse().setResponse(response);
              }
            }
          }

          
          HashMap<String, ModifiableSolrParams> requestParamList = new HashMap<>();
          for (String shardAddress : shards) {
            ModifiableSolrParams paramsNewRequest = new ModifiableSolrParams();
            int termvectorCounter = 0;
            for (String field : mtasFields.list.keySet()) {
              List<ComponentTermVector> tvList = mtasFields.list
                  .get(field).termVectorList;
              if (recomputeFieldList.containsKey(field)) {
                HashMap<String, HashMap<String, MtasDataItemNumberComparator>> recomputeList = recomputeFieldList
                    .get(field);
                if (tvList != null) {
                  for (ComponentTermVector tv : tvList) {
                    if (recomputeList.containsKey(tv.key)
                        && recomputeList.get(tv.key).containsKey(shardAddress)) {
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_BOUNDARY,
                          String.valueOf(recomputeList.get(tv.key).get(shardAddress)
                              .getValue()));
                      paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                          + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_FIELD,
                          field);
                      paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                          + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_PREFIX,
                          tv.prefix);
                      paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                          + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_KEY,
                          tv.key);
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_NUMBER,
                          String.valueOf(tv.number));
                      if (tv.subComponentFunction.sortType != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                + NAME_MTAS_TERMVECTOR_SORT_TYPE,
                            tv.subComponentFunction.sortType);
                      }
                      if (tv.subComponentFunction.sortDirection != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                + NAME_MTAS_TERMVECTOR_SORT_DIRECTION,
                            tv.subComponentFunction.sortDirection);
                      }
                      if (tv.subComponentFunction.type != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                + NAME_MTAS_TERMVECTOR_TYPE,
                            tv.subComponentFunction.type);
                      }
                      if (tv.distances != null) {
                        int distanceCounter = 0;
                        for (SubComponentDistance distance : (List<SubComponentDistance>)(List<?>) tv.distances) {
                          paramsNewRequest.add(
                              PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                  + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                  + distanceCounter + "."
                                  + NAME_MTAS_TERMVECTOR_DISTANCE_TYPE,
                              distance.type);
                          paramsNewRequest.add(
                              PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                  + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                  + distanceCounter + "."
                                  + NAME_MTAS_TERMVECTOR_DISTANCE_BASE,
                              distance.base);
                          if (distance.key != null) {
                            paramsNewRequest.add(
                                PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                    + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                    + distanceCounter + "."
                                    + NAME_MTAS_TERMVECTOR_DISTANCE_KEY,
                                distance.key);
                          }
                          if (distance.minimum != null) {
                            paramsNewRequest.add(
                                PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                    + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                    + distanceCounter + "."
                                    + NAME_MTAS_TERMVECTOR_DISTANCE_MINIMUM,
                                String.valueOf(distance.minimum));
                          }
                          if (distance.maximum != null) {
                            paramsNewRequest.add(
                                PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                    + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                    + distanceCounter + "."
                                    + NAME_MTAS_TERMVECTOR_DISTANCE_MAXIMUM,
                                String.valueOf(distance.maximum));
                          }
                          if (distance.parameters != null) {
                            for (Map.Entry<String, String> parameter : distance.parameters
                                .entrySet()) {
                              paramsNewRequest.add(
                                  PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                      + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                      + distanceCounter + "."
                                      + NAME_MTAS_TERMVECTOR_DISTANCE_PARAMETER
                                      + "." + parameter.getKey(),
                                  parameter.getValue());
                            }
                          }
                          distanceCounter++;
                        }
                      }
                      if (tv.functions != null) {
                        int functionCounter = 0;
                        for (SubComponentFunction function : tv.functions) {
                          paramsNewRequest.add(
                              PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                  + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                                  + functionCounter + "."
                                  + NAME_MTAS_TERMVECTOR_FUNCTION_EXPRESSION,
                              function.expression);
                          paramsNewRequest.add(
                              PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                  + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                                  + functionCounter + "."
                                  + NAME_MTAS_TERMVECTOR_FUNCTION_KEY,
                              function.key);
                          if (function.type != null) {
                            paramsNewRequest.add(
                                PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                    + "." + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                                    + functionCounter + "."
                                    + NAME_MTAS_TERMVECTOR_FUNCTION_TYPE,
                                function.type);
                          }
                          functionCounter++;
                        }
                      }
                      if (tv.regexp != null) {
                        paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                            + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_REGEXP,
                            tv.regexp);
                      }
                      termvectorCounter++;
                    }
                  }
                }
              }
            }
            if (!paramsNewRequest.getParameterNames().isEmpty()) {
              requestParamList.put(shardAddress, paramsNewRequest);
            }
          }

          
          for (Map.Entry<String, ModifiableSolrParams> entry : requestParamList
              .entrySet()) {
            ShardRequest sreq = new ShardRequest();
            sreq.shards = new String[] { entry.getKey() };
            sreq.purpose = ShardRequest.PURPOSE_PRIVATE;
            sreq.params = entry.getValue();
            sreq.params.add(CommonParams.FQ,
                rb.req.getParams().getParams(CommonParams.FQ));
            sreq.params.add(CommonParams.Q,
                rb.req.getParams().getParams(CommonParams.Q));
            sreq.params.add(CommonParams.CACHE,
                rb.req.getParams().getParams(CommonParams.CACHE));
            sreq.params.add(CommonParams.ROWS, "0");
            sreq.params.add(MtasSolrSearchComponent.PARAM_MTAS, rb.req
                .getOriginalParams().getParams(MtasSolrSearchComponent.PARAM_MTAS));
            sreq.params.add(PARAM_MTAS_TERMVECTOR,
                rb.req.getOriginalParams().getParams(PARAM_MTAS_TERMVECTOR));
            rb.addRequest(searchComponent, sreq);
          }
        }

      }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        method_3_mtas_gemini engine = new method_3_mtas_gemini();
        
        ResponseBuilder rb = new ResponseBuilder();
        ComponentFields mtasFields = new ComponentFields();
        ComponentFieldWrapper fieldWrapper = new ComponentFieldWrapper();
        
        ComponentTermVector tv = new ComponentTermVector();
        tv.key = "tv1";
        tv.number = 2; 
        fieldWrapper.termVectorList.add(tv);
        mtasFields.list.put("mock_field", fieldWrapper);
        
        ShardRequest mockRequest = new ShardRequest();
        
        
        ShardResponse shard1 = new ShardResponse("node1:8983/solr");
        MtasSolrMtasResult res1 = new MtasSolrMtasResult();
        res1.result.comparatorList.put("tokenA", new MtasDataItemNumberComparator(80));
        res1.result.comparatorList.put("tokenB", new MtasDataItemNumberComparator(50));
        
        res1.result.lastSortValue = new MtasDataItemNumberComparator(100); 
        NamedList<Object> dataItem1 = new NamedList<>();
        dataItem1.add("key", "tv1");
        dataItem1.add("field", "mock_field");
        dataItem1.add("list", res1);
        List<NamedList<Object>> recursiveDataList1 = new ArrayList<>();
        recursiveDataList1.add(dataItem1);
        shard1.solrResponse.getResponse().add("mock_recursive_list", recursiveDataList1);
        mockRequest.responses.add(shard1);
        
        
        ShardResponse shard2 = new ShardResponse("node2:8983/solr");
        MtasSolrMtasResult res2 = new MtasSolrMtasResult();
        res2.result.comparatorList.put("tokenC", new MtasDataItemNumberComparator(70));
        res2.result.comparatorList.put("tokenD", new MtasDataItemNumberComparator(40));
        
        res2.result.lastSortValue = new MtasDataItemNumberComparator(120); 
        NamedList<Object> dataItem2 = new NamedList<>();
        dataItem2.add("key", "tv1");
        dataItem2.add("field", "mock_field");
        dataItem2.add("list", res2);
        List<NamedList<Object>> recursiveDataList2 = new ArrayList<>();
        recursiveDataList2.add(dataItem2);
        shard2.solrResponse.getResponse().add("mock_recursive_list", recursiveDataList2);
        mockRequest.responses.add(shard2);
        
        rb.finished.add(mockRequest);
        
        try {
            engine.distributedProcessMissingTop(rb, mtasFields);
            
            
            int finishedShardRequests = rb.finished.size();
            int newRequests = rb.newRequestsAdded.size();
            int shardResponsesProcessed = mockRequest.responses.size();
            String termvectorKey = tv.key;
            int requestedTop = tv.number;
            
            System.out.println("finishedShardRequests=" + finishedShardRequests);
            System.out.println("newRequests=" + newRequests);
            System.out.println("shardResponsesProcessed=" + shardResponsesProcessed);
            System.out.println("termvectorKey=" + termvectorKey + ", requestedTop=" + requestedTop);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
