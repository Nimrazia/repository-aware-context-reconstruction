import java.io.Reader;
import java.io.StringReader;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;




public class method_2_mtas_gemini {

    
    static class Log {
        void debug(String msg) { System.out.println("DEBUG: " + msg); }
        void debug(Exception e) { System.out.println("DEBUG: " + e.getMessage()); }
        void info(String msg) { System.out.println("INFO: " + msg); }
    }
    private static final Log log = new Log();

    
    private static final String MAPPING_TYPE_WORD = "WORD";
    private static final String MAPPING_TYPE_GROUP_ANNOTATION = "GROUP_ANNOTATION";
    private static final String MAPPING_TYPE_RELATION = "RELATION";
    private static final String MAPPING_TYPE_RELATION_ANNOTATION = "RELATION_ANNOTATION";
    private static final String MAPPING_TYPE_GROUP = "GROUP";
    private static final String MAPPING_TYPE_WORD_ANNOTATION = "WORD_ANNOTATION";
    private static final String MAPPING_TYPE_REF = "REF";

    private static final String UPDATE_TYPE_VARIABLE = "VAR";
    private static final String UPDATE_TYPE_OFFSET = "OFFSET";
    private static final String UPDATE_TYPE_POSITION = "POSITION";

    
    private String rootTag = "root";
    private String contentTag = "content";
    private boolean allowNonContent = true;
    private boolean autorepair = true;
    private boolean makeunique = true;
    
    private MtasTokenCollection tokenCollection;
    
    private Map<QName, MtasParserType<?>> variableTypes = new HashMap<>();
    private Map<QName, MtasParserType<?>> relationTypes = new HashMap<>();
    private Map<QName, MtasParserType<?>> relationAnnotationTypes = new HashMap<>();
    private Map<QName, MtasParserType<?>> groupTypes = new HashMap<>();
    private Map<QName, MtasParserType<?>> groupAnnotationTypes = new HashMap<>();
    private Map<QName, MtasParserType<?>> wordTypes = new HashMap<>();
    private Map<QName, MtasParserType<?>> wordAnnotationTypes = new HashMap<>();
    private Map<QName, MtasParserType<?>> refTypes = new HashMap<>();
    private Map<String, SortedSet<String>> relationKeyMap = new HashMap<>();

    
    static class MtasParserException extends Exception {
        MtasParserException(String msg) { super(msg); }
    }
    static class MtasConfigException extends Exception {}

    static class MtasTokenCollection {
        Map<Integer, MtasToken> tokens = new HashMap<>();
        public MtasToken get(Integer id) { return tokens.computeIfAbsent(id, k -> new MtasToken()); }
        public void check(boolean autorepair, boolean makeunique) {}
    }

    static class MtasTokenIdFactory {}

    static class MtasParserType<T> {
        private String name;
        private String refAttributeName;
        public MtasParserType(String name) { this.name = name; this.refAttributeName = "ref"; }
        public String getName() { return name; }
        public String getRefAttributeName() { return refAttributeName; }
    }

    static class MtasParserObject {
        private MtasParserType<?> type;
        private int unknownAncestorNumber;
        private int offsetStart, offsetEnd, realOffsetStart, realOffsetEnd;
        private String id = UUID.randomUUID().toString();
        private Set<Integer> positions = new HashSet<>();
        private Integer[] offset = new Integer[]{0, 0};
        
        public MtasParserObject(MtasParserType<?> type) { this.type = type; }
        public MtasParserType<?> getType() { return type; }
        public String getId() { return id; }
        public void setUnknownAncestorNumber(int n) { this.unknownAncestorNumber = n; }
        public int getUnknownAncestorNumber() { return unknownAncestorNumber; }
        
        public void setOffsetStart(int o) { this.offsetStart = o; }
        public void setOffsetEnd(int o) { this.offsetEnd = o; }
        public void setRealOffsetStart(int o) { this.realOffsetStart = o; }
        public void setRealOffsetEnd(int o) { this.realOffsetEnd = o; }
        public int getOffsetStart() { return offsetStart; }
        public int getOffsetEnd() { return offsetEnd; }
        public Integer[] getOffset() { return offset; }
        
        public void addPosition(int p) { positions.add(p); }
        public void addPositions(Set<Integer> p) { if (p != null) positions.addAll(p); }
        public Set<Integer> getPositions() { return positions; }
        
        public void addOffsetStart(int o) {}
        public void addOffsetEnd(int o) {}
        
        public void updateMappings(Map<String, Set<Integer>> p, Map<String, Integer[]> o) {}
        public void addUpdateableIdWithOffset(String id) {}
        public void addText(String text) {}
        public String getAttribute(String attr) { return "attr_val"; }
        public void addRefId(String refId) {}
    }

    static class MtasToken {
        public String getPrefix() { return "pre"; }
        public String getPostfix() { return "post"; }
        public void setValue(String val) {}
        public void addOffset(int start, int end) {}
        public void addPositions(Set<Integer> p) {}
    }

    
    private Map<String, Map<Integer, Set<String>>> createUpdateList() {
        Map<String, Map<Integer, Set<String>>> map = new HashMap<>();
        map.put(UPDATE_TYPE_VARIABLE, new HashMap<>());
        map.put(UPDATE_TYPE_OFFSET, new HashMap<>());
        map.put(UPDATE_TYPE_POSITION, new HashMap<>());
        return map;
    }

    private Map<String, List<MtasParserObject>> createCurrentList() {
        Map<String, List<MtasParserObject>> map = new HashMap<>();
        map.put(MAPPING_TYPE_WORD, new ArrayList<>());
        map.put(MAPPING_TYPE_GROUP_ANNOTATION, new ArrayList<>());
        map.put(MAPPING_TYPE_RELATION, new ArrayList<>());
        map.put(MAPPING_TYPE_RELATION_ANNOTATION, new ArrayList<>());
        map.put(MAPPING_TYPE_GROUP, new ArrayList<>());
        map.put(MAPPING_TYPE_WORD_ANNOTATION, new ArrayList<>());
        map.put(MAPPING_TYPE_REF, new ArrayList<>());
        return map;
    }

    private Map<String, Map<String, String>> createVariables() { return new HashMap<>(); }
    
    private QName getQName(String tag) { return new QName(tag); }
    
    private void collectAttributes(MtasParserObject obj, XMLStreamReader reader) {}
    
    private void computeVariablesFromObject(MtasParserObject obj, Map<String, List<MtasParserObject>> list, Map<String, Map<String, String>> vars) {}
    
    private boolean prevalidateObject(MtasParserObject obj, Map<String, List<MtasParserObject>> list) { return true; }
    
    private void computeMappingsFromObject(MtasTokenIdFactory fact, MtasParserObject obj, Map<String, List<MtasParserObject>> list, Map<String, Map<Integer, Set<String>>> update) {}
    
    private String decodeAndUpdateWithVariables(String pre, String post, Map<String, Map<String, String>> vars) { return pre + post; }
    
    private Collection<String> recursiveCollect(String refId, Map<String, SortedSet<String>> map, int depth) { return new ArrayList<>(); }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public MtasTokenCollection createTokenCollection(Reader reader)
        throws MtasParserException, MtasConfigException {
      Boolean hasRoot = rootTag == null ? true : false;
      Boolean parsingContent = contentTag == null ? true : false;
      String textContent = null;
      Integer unknownAncestors = 0;
      Integer lastOffset = 0;

      AtomicInteger position = new AtomicInteger(0);
      Map<String, Set<Integer>> idPositions = new HashMap<>();
      Map<String, Integer[]> idOffsets = new HashMap<>();

      Map<String, Map<Integer, Set<String>>> updateList = createUpdateList();
      Map<String, List<MtasParserObject>> currentList = createCurrentList();
      Map<String, Map<String, String>> variables = createVariables();

      tokenCollection = new MtasTokenCollection();
      MtasTokenIdFactory mtasTokenIdFactory = new MtasTokenIdFactory();
      XMLInputFactory factory = XMLInputFactory.newInstance();
      try {      
        XMLStreamReader streamReader = factory.createXMLStreamReader(reader);
        QName qname;
        try {
          int event = streamReader.getEventType();
          MtasParserType<?> currentType;
          MtasParserType<?> tmpCurrentType;
          MtasParserType<?> tmpVariableType;
          MtasParserObject currentObject = null;
          MtasParserObject variableObject = null;
          while (true) {
            switch (event) {
            case XMLStreamConstants.START_DOCUMENT:
              log.debug("start of document");
              String encodingScheme = streamReader.getCharacterEncodingScheme();
              if (encodingScheme == null) {
                
                log.info("No encodingScheme found, assume utf-8");
                
              } else if (!encodingScheme.equalsIgnoreCase("utf-8")) {
                throw new MtasParserException(
                    "XML not UTF-8 encoded but '" + encodingScheme + "'");
              }
              break;
            case XMLStreamConstants.END_DOCUMENT:
              log.debug("end of document");
              break;
            case XMLStreamConstants.SPACE:
              
              lastOffset = streamReader.getLocation().getCharacterOffset();
              break;
            case XMLStreamConstants.START_ELEMENT:
              
              qname = streamReader.getName();
              
              if (!hasRoot) {
                if (qname.equals(getQName(rootTag))) {
                  hasRoot = true;
                } else {
                  throw new MtasParserException("No " + rootTag);
                }
                
              } else {
                if ((tmpVariableType = variableTypes.get(qname)) != null) {
                  variableObject = new MtasParserObject(tmpVariableType);
                  collectAttributes(variableObject, streamReader);
                  computeVariablesFromObject(variableObject, currentList,
                      variables);
                }
                if (parsingContent) {
                  
                  
                  if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty())
                      && (tmpCurrentType = relationTypes.get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_RELATION).add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (!currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (tmpCurrentType = relationAnnotationTypes
                          .get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                          .add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty())
                      && (tmpCurrentType = groupTypes.get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_GROUP).add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (!currentList.get(MAPPING_TYPE_GROUP).isEmpty())
                      && (tmpCurrentType = groupAnnotationTypes
                          .get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty())
                      && (currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (currentList.get(MAPPING_TYPE_WORD_ANNOTATION).isEmpty())
                      && (tmpCurrentType = wordTypes.get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setOffsetStart(lastOffset);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentObject.addPosition(position.getAndIncrement());
                      currentList.get(MAPPING_TYPE_WORD).add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                    
                  } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                      && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty())
                      && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())
                      && (tmpCurrentType = wordAnnotationTypes
                          .get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.addPositions(currentList.get(MAPPING_TYPE_WORD)
                        .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                        .getPositions());
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                          .add(currentObject);
                      unknownAncestors = 0;
                    }
                    
                  } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()
                      && (tmpCurrentType = refTypes.get(qname)) != null) {
                    currentObject = new MtasParserObject(tmpCurrentType);
                    collectAttributes(currentObject, streamReader);
                    currentObject.setUnknownAncestorNumber(unknownAncestors);
                    currentObject.setRealOffsetStart(lastOffset);
                    if (!prevalidateObject(currentObject, currentList)) {
                      unknownAncestors++;
                    } else {
                      currentType = tmpCurrentType;
                      currentList.get(MAPPING_TYPE_REF).add(currentObject);
                      unknownAncestors = 0;
                      
                      for (MtasParserObject currentRelation : currentList
                          .get(MAPPING_TYPE_RELATION)) {
                        currentRelation.addRefId(currentObject
                            .getAttribute(currentType.getRefAttributeName()));
                        
                        SortedSet<String> keyMapList;
                        if (currentRelation.getId() != null) {
                          if (relationKeyMap
                              .containsKey(currentRelation.getId())) {
                            keyMapList = relationKeyMap
                                .get(currentRelation.getId());
                          } else {
                            keyMapList = new TreeSet<>();
                            relationKeyMap.put(currentRelation.getId(),
                                keyMapList);
                          }
                          keyMapList.add(currentObject
                              .getAttribute(currentType.getRefAttributeName()));
                        }
                      }
                    }
                  } else {
                    unknownAncestors++;
                  }
                  
                } else if (qname.equals(getQName(contentTag))) {
                  parsingContent = true;
                  
                } else if (!allowNonContent) {
                  throw new MtasParserException(
                      "Unexpected " + qname.getLocalPart() + " in document");
                }
              }
              
              lastOffset = streamReader.getLocation().getCharacterOffset();
              break;
            case XMLStreamConstants.END_ELEMENT:
              
              lastOffset = streamReader.getLocation().getCharacterOffset();
              
              qname = streamReader.getName();
              
              if (parsingContent) {
                if (unknownAncestors > 0) {
                  unknownAncestors--;
                  
                  
                } else if (!currentList.get(MAPPING_TYPE_REF).isEmpty()) {
                  if ((currentType = refTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_REF)
                        .remove(currentList.get(MAPPING_TYPE_REF).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                  
                } else if (!currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                    .isEmpty()) {
                  if ((currentType = wordAnnotationTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                        .remove(
                            currentList.get(MAPPING_TYPE_WORD_ANNOTATION).size()
                                - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    
                    
                    if ((currentObject.getId() != null)
                        && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())) {
                      currentList.get(MAPPING_TYPE_WORD)
                          .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                          .addUpdateableIdWithOffset(currentObject.getId());
                    }
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                  
                } else if (!currentList.get(MAPPING_TYPE_WORD).isEmpty()) {
                  if ((currentType = wordTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_WORD)
                        .remove(currentList.get(MAPPING_TYPE_WORD).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    currentObject.setOffsetEnd(lastOffset);
                    currentObject.setRealOffsetEnd(lastOffset);
                    
                    for (MtasParserObject currentGroup : currentList
                        .get(MAPPING_TYPE_GROUP)) {
                      currentGroup.addPositions(currentObject.getPositions());
                      currentGroup.addOffsetStart(currentObject.getOffsetStart());
                      currentGroup.addOffsetEnd(currentObject.getOffsetEnd());
                    }
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                  
                } else if (!currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                    .isEmpty()) {
                  if ((currentType = groupAnnotationTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .remove(
                            currentList.get(MAPPING_TYPE_GROUP_ANNOTATION).size()
                                - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                } else if (!currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                    .isEmpty()) {
                  if ((currentType = relationAnnotationTypes
                      .get(qname)) != null) {
                    currentObject = currentList
                        .get(MAPPING_TYPE_RELATION_ANNOTATION).remove(currentList
                            .get(MAPPING_TYPE_RELATION_ANNOTATION).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()) {
                  if ((currentType = relationTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_RELATION).remove(
                        currentList.get(MAPPING_TYPE_RELATION).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    
                  }
                  
                } else if (!currentList.get(MAPPING_TYPE_GROUP).isEmpty()) {
                  if ((currentType = groupTypes.get(qname)) != null) {
                    currentObject = currentList.get(MAPPING_TYPE_GROUP)
                        .remove(currentList.get(MAPPING_TYPE_GROUP).size() - 1);
                    assert currentObject.getType()
                        .equals(currentType) : "object expected to be "
                            + currentObject.getType().getName() + ", not "
                            + currentType.getName();
                    assert unknownAncestors == 0 : "error in administration "
                        + currentObject.getType().getName();
                    
                    currentObject.setRealOffsetEnd(lastOffset);
                    idPositions.put(currentObject.getId(),
                        currentObject.getPositions());
                    idOffsets.put(currentObject.getId(),
                        currentObject.getOffset());
                    currentObject.updateMappings(idPositions, idOffsets);
                    unknownAncestors = currentObject.getUnknownAncestorNumber();
                    computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                        currentList, updateList);
                  } else {
                    unknownAncestors--;
                  }
                } else if (qname.equals(getQName("text"))) {
                  parsingContent = false;
                  assert unknownAncestors == 0 : "error in administration unknownAncestors";
                  assert currentList.get(MAPPING_TYPE_REF)
                      .isEmpty() : "error in administration references";
                  assert currentList.get(MAPPING_TYPE_GROUP)
                      .isEmpty() : "error in administration groups";
                  assert currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                      .isEmpty() : "error in administration groupAnnotations";
                  assert currentList.get(MAPPING_TYPE_WORD)
                      .isEmpty() : "error in administration words";
                  assert currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                      .isEmpty() : "error in administration wordAnnotations";
                  assert currentList.get(MAPPING_TYPE_RELATION)
                      .isEmpty() : "error in administration relations";
                  assert currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                      .isEmpty() : "error in administration relationAnnotations";
                }
              }
              
              textContent = null;
              break;
            case XMLStreamConstants.CHARACTERS:
              
              lastOffset = streamReader.getLocation().getCharacterOffset();
              
              if (streamReader.hasText()) {
                textContent = streamReader.getText();
              }
              if (currentObject != null && unknownAncestors.equals(0)) {
                currentObject.addText(textContent);
              }
              break;
            default:
              break;
            }
            if (!streamReader.hasNext()) {
              break;
            }
            event = streamReader.next();
          }
        } finally {
          streamReader.close();
        }
        
        assert unknownAncestors == 0 : "error in administration unknownAncestors";
        assert hasRoot : "no " + rootTag;
      } catch (XMLStreamException e) {
        log.debug(e);      
        throw new MtasParserException("No valid XML: " + e.getMessage());
      }

      
      for (Map.Entry<Integer, Set<String>> updateItem : updateList
          .get(UPDATE_TYPE_VARIABLE).entrySet()) {
        MtasToken token = tokenCollection.get(updateItem.getKey());
        String encodedPrefix = token.getPrefix();
        String encodedPostfix = token.getPostfix();
        token.setValue(decodeAndUpdateWithVariables(encodedPrefix, encodedPostfix,
            variables));
      }
      
      for (Map.Entry<Integer, Set<String>> updateItem : updateList
          .get(UPDATE_TYPE_OFFSET).entrySet()) {
        Set<String> refIdList = new HashSet<>();
        for (String refId : updateItem.getValue()) {
          if (idPositions.containsKey(refId)) {
            refIdList.add(refId);
          }
          if (relationKeyMap.containsKey(refId)) {
            refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
          }
        }
        for (String refId : refIdList) {
          Integer[] refOffset = idOffsets.get(refId);
          Integer tokenId = updateItem.getKey();
          if (tokenId != null && refOffset != null) {
            MtasToken token = tokenCollection.get(tokenId);
            token.addOffset(refOffset[0], refOffset[1]);
          }
        }
      }
      
      for (Map.Entry<Integer, Set<String>> updateItem : updateList
          .get(UPDATE_TYPE_POSITION).entrySet()) {
        HashSet<String> refIdList = new HashSet<>();
        for (String refId : updateItem.getValue()) {
          if (idPositions.containsKey(refId)) {
            refIdList.add(refId);
          }
          if (relationKeyMap.containsKey(refId)) {
            refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
          }
        }
        for (String refId : refIdList) {
          Set<Integer> refPositions = idPositions.get(refId);
          Integer tokenId = updateItem.getKey();
          if (tokenId != null && refPositions != null) {
            MtasToken token = tokenCollection.get(tokenId);
            token.addPositions(refPositions);
          }
        }
      }
      
      tokenCollection.check(autorepair, makeunique);
      return tokenCollection;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        method_2_mtas_gemini parser = new method_2_mtas_gemini();
        
        
        String mockXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                         "<root>" +
                         "<content>" +
                         "Hello World" +
                         "</content>" +
                         "</root>";
                         
        try {
            System.out.println("Starting execution of createTokenCollection...");
            MtasTokenCollection result = parser.createTokenCollection(new StringReader(mockXml));
            System.out.println("Successfully created TokenCollection with " + result.tokens.size() + " tokens (or variables).");
        } catch (Exception e) {
            System.err.println("Execution failed: " + e.getMessage());
        }
    }
}
