import java.text.ParseException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




public class method_1_pbs_java_api_gemini {

    private static final Logger LOGGER = Logger.getLogger(method_1_pbs_java_api_gemini.class.getName());
    private static final Pattern PATTERN_JOB = Pattern.compile("^Job Id: (.+)$");
    private static final char CHAR_EQUALS = '=';

    public static class Job {
        private String id;
        private String name;
        private String owner;
        private String state;
        private String queue;
        private String server;
        private String checkpoint;
        private String ctime;
        private String errorPath;
        private String execHost;
        private String execPort;
        private String holdTypes;
        private String joinPath;
        private String keepFiles;
        private String mailPoints;
        private String mailUsers;
        private String mtime;
        private String outputPath;
        private int priority;
        private String qtime;
        private boolean rerunable;
        private int sessionId;
        private int substate;
        private String etime;
        private String euser;
        private String egroup;
        private String hashName;
        private int queueRank;
        private String queueType;
        private String comment;
        private String submitArgs;
        private String submitHost;
        private String startTime;
        private int startCount;
        private boolean faultTolerant;
        private int jobArrayId;
        private int radix;
        private long walltimeRemaining;
        
        private final Map<String, String> resourcesUsed = new HashMap<>();
        private final Map<String, String> resourceList = new HashMap<>();
        private final Map<String, String> variableList = new HashMap<>();

        public void setId(String id) { this.id = id; }
        public void setName(String name) { this.name = name; }
        public void setOwner(String owner) { this.owner = owner; }
        public void setState(String state) { this.state = state; }
        public void setQueue(String queue) { this.queue = queue; }
        public void setServer(String server) { this.server = server; }
        public void setCheckpoint(String checkpoint) { this.checkpoint = checkpoint; }
        public void setCtime(String ctime) { this.ctime = ctime; }
        public void setErrorPath(String errorPath) { this.errorPath = errorPath; }
        public void setExecHost(String execHost) { this.execHost = execHost; }
        public void setExecPort(String execPort) { this.execPort = execPort; }
        public void setHoldTypes(String holdTypes) { this.holdTypes = holdTypes; }
        public void setJoinPath(String joinPath) { this.joinPath = joinPath; }
        public void setKeepFiles(String keepFiles) { this.keepFiles = keepFiles; }
        public void setMailPoints(String mailPoints) { this.mailPoints = mailPoints; }
        public void setMailUsers(String mailUsers) { this.mailUsers = mailUsers; }
        public void setMtime(String mtime) { this.mtime = mtime; }
        public void setOutputPath(String outputPath) { this.outputPath = outputPath; }
        public void setPriority(int priority) { this.priority = priority; }
        public void setQtime(String qtime) { this.qtime = qtime; }
        public void setRerunable(boolean rerunable) { this.rerunable = rerunable; }
        public void setSessionId(int sessionId) { this.sessionId = sessionId; }
        public void setSubstate(int substate) { this.substate = substate; }
        public void setEtime(String etime) { this.etime = etime; }
        public void setEuser(String euser) { this.euser = euser; }
        public void setEgroup(String egroup) { this.egroup = egroup; }
        public void setHashName(String hashName) { this.hashName = hashName; }
        public void setQueueRank(int queueRank) { this.queueRank = queueRank; }
        public void setQueueType(String queueType) { this.queueType = queueType; }
        public void setComment(String comment) { this.comment = comment; }
        public void setSubmitArgs(String submitArgs) { this.submitArgs = submitArgs; }
        public void setSubmitHost(String submitHost) { this.submitHost = submitHost; }
        public void setStartTime(String startTime) { this.startTime = startTime; }
        public void setStartCount(int startCount) { this.startCount = startCount; }
        public void setFaultTolerant(boolean faultTolerant) { this.faultTolerant = faultTolerant; }
        public void setJobArrayId(int jobArrayId) { this.jobArrayId = jobArrayId; }
        public void setRadix(int radix) { this.radix = radix; }
        public void setWalltimeRemaining(long walltimeRemaining) { this.walltimeRemaining = walltimeRemaining; }

        public Map<String, String> getResourcesUsed() { return resourcesUsed; }
        public Map<String, String> getResourceList() { return resourceList; }
        public Map<String, String> getVariableList() { return variableList; }
        
        public String getId() { return id; }
        public String getName() { return name; }
        public String getState() { return state; }
        public int getPriority() { return priority; }
    }

    static class StringUtils {
        public static boolean isNotBlank(CharSequence cs) {
            return cs != null && cs.length() > 0 && !cs.toString().trim().isEmpty();
        }
        public static String replace(String text, String searchString, String replacement) {
            if (text == null || searchString == null || replacement == null) return text;
            return text.replace(searchString, replacement);
        }
    }

    static class Utils {
        public static String[] splitFirst(String line, char c) {
            int idx = line.indexOf(c);
            if (idx < 0) return new String[0];
            return new String[] { line.substring(0, idx), line.substring(idx + 1) };
        }
    }


// ORIGINAL CODESEARCHNET METHOD — START

    public List<Job> parse(String text) throws ParseException {
        final List<Job> jobs;
        if (StringUtils.isNotBlank(text)) {
            text = StringUtils.replace(text, "\n\t", "");
            jobs = new LinkedList<Job>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Job job = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_JOB.matcher(line);
                if (matcher.matches()) {
                    if (job != null) {
                        jobs.add(job);
                    }
                    job = new Job();
                    final String id = matcher.group(1).trim();
                    job.setId(id);
                } else if (StringUtils.isNotBlank(line)) {
                    String[] temp = Utils.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("job_name".equalsIgnoreCase(key)) {
                            job.setName(value);
                        } else if ("job_owner".equalsIgnoreCase(key)) {
                            job.setOwner(value);
                        } else if (key.startsWith("resources_used.")) {
                            job.getResourcesUsed().put(key, value);
                        } else if ("job_state".equalsIgnoreCase(key)) {
                            job.setState(value);
                        } else if ("queue".equalsIgnoreCase(key)) {
                            job.setQueue(value);
                        } else if ("server".equalsIgnoreCase(key)) {
                            job.setServer(value);
                        } else if ("checkpoint".equalsIgnoreCase(key)) {
                            job.setCheckpoint(value);
                        } else if ("ctime".equalsIgnoreCase(key)) {
                            job.setCtime(value);
                        } else if ("error_path".equalsIgnoreCase(key)) {
                            job.setErrorPath(value);
                        } else if ("exec_host".equalsIgnoreCase(key)) {
                            job.setExecHost(value);
                        } else if ("exec_port".equalsIgnoreCase(key)) {
                            job.setExecPort(value);
                        } else if ("hold_types".equalsIgnoreCase(key)) {
                            job.setHoldTypes(value);
                        } else if ("join_path".equalsIgnoreCase(key)) {
                            job.setJoinPath(value);
                        } else if ("keep_files".equalsIgnoreCase(key)) {
                            job.setKeepFiles(value);
                        } else if ("mail_points".equalsIgnoreCase(key)) {
                            job.setMailPoints(value);
                        } else if ("mail_users".equalsIgnoreCase(key)) {
                            job.setMailUsers(value);
                        } else if ("mtime".equalsIgnoreCase(key)) {
                            job.setMtime(value);
                        } else if ("output_path".equalsIgnoreCase(key)) {
                            job.setOutputPath(value);
                        } else if ("priority".equalsIgnoreCase(key)) {
                            try {
                                job.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job priority: " + nfe.getMessage(), nfe);
                                job.setPriority(-1);
                            }
                        } else if ("qtime".equalsIgnoreCase(key)) {
                            job.setQtime(value);
                        } else if ("rerunable".equalsIgnoreCase(key)) {
                            job.setRerunable(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resource_list.")) {
                            job.getResourceList().put(key, value);
                        } else if ("session_id".equalsIgnoreCase(key)) {
                            try {
                                job.setSessionId(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job session id: " + nfe.getMessage(), nfe);
                                job.setSessionId(-1);
                            }
                        } else if ("substate".equalsIgnoreCase(key)) {
                            try {
                                job.setSubstate(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job substate: " + nfe.getMessage(), nfe);
                                job.setSubstate(-1);
                            }
                        } else if (key.startsWith("variable_list")) {
                            job.getVariableList().put(key, value);
                        } else if ("etime".equalsIgnoreCase(key)) {
                            job.setEtime(value);
                        } else if ("euser".equalsIgnoreCase(key)) {
                            job.setEuser(value);
                        } else if ("egroup".equalsIgnoreCase(key)) {
                            job.setEgroup(value);
                        } else if ("hashname".equalsIgnoreCase(key)) {
                            job.setHashName(value);
                        } else if ("queue_rank".equalsIgnoreCase(key)) {
                            try {
                                job.setQueueRank(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job queue rank: " + nfe.getMessage(), nfe);
                                job.setQueueRank(-1);
                            }
                        } else if ("queue_type".equalsIgnoreCase(key)) {
                            job.setQueueType(value);
                        } else if ("comment".equalsIgnoreCase(key)) {
                            job.setComment(value);
                        } else if ("submit_args".equalsIgnoreCase(key)) {
                            job.setSubmitArgs(value);
                        } else if ("submit_host".equalsIgnoreCase(key)) {
                            job.setSubmitHost(value);
                        } else if ("start_time".equalsIgnoreCase(key)) {
                            job.setStartTime(value);
                        } else if ("start_count".equalsIgnoreCase(key)) {
                            try {
                                job.setStartCount(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job start count: " + nfe.getMessage(), nfe);
                                job.setStartCount(-1);
                            }
                        } else if ("fault_tolerant".equalsIgnoreCase(key)) {
                            job.setFaultTolerant(Boolean.parseBoolean(value));
                        } else if ("job_array_id".equalsIgnoreCase(key)) {
                            job.setJobArrayId(Integer.parseInt(value));
                        } else if ("job_radix".equalsIgnoreCase(key)) {
                            try {
                                job.setRadix(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job radix: " + nfe.getMessage(), nfe);
                                job.setRadix(-1);
                            }
                        } else if ("walltime.remaining".equalsIgnoreCase(key)) {
                            try {
                                job.setWalltimeRemaining(Long.parseLong(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job walltime remaining: " + nfe.getMessage(),
                                        nfe);
                                job.setWalltimeRemaining(-1L);
                            }
                        }
                    }
                }
            }
            if (job != null) {
                jobs.add(job);
            }
            return jobs;
        } else {
            return Collections.emptyList();
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        method_1_pbs_java_api_gemini parser = new method_1_pbs_java_api_gemini();
        String sampleQstatOutput = 
            "Job Id: 54321.torque.cluster\n" +
            "    Job_Name = data_crunching\n" +
            "    job_owner = analyst@node01\n" +
            "    job_state = R\n" +
            "    priority = 300\n" +
            "    resources_used.cput = 00:15:00\n";

        try {
            System.out.println("Running QstatJobsParser validation...");
            List<Job> parsedJobs = parser.parse(sampleQstatOutput);
            
            System.out.println("-> Successfully parsed jobs count: " + parsedJobs.size());
            if (!parsedJobs.isEmpty()) {
                Job j = parsedJobs.get(0);
                System.out.println("   [Job ID]       : " + j.getId());
                System.out.println("   [Job Name]     : " + j.getName());
                System.out.println("   [Job State]    : " + j.getState());
                System.out.println("   [Priority]     : " + j.getPriority());
                System.out.println("   [Resources Used]: " + j.getResourcesUsed());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}