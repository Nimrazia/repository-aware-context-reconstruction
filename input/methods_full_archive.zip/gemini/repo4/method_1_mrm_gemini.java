



import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

public class method_1_mrm_gemini {

    
    
    
    
    
    

    static class MetadataNotFoundException extends Exception {
        public MetadataNotFoundException(String message) {
            super(message);
        }
    }

    static class ArtifactNotFoundException extends Exception {
    }

    static class XmlPullParserException extends Exception {
    }

    static class Plugin {
        private String artifactId;
        private String name;
        private String prefix;

        public String getArtifactId() {
            return artifactId;
        }

        public void setArtifactId(String artifactId) {
            this.artifactId = artifactId;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setPrefix(String prefix) {
            this.prefix = prefix;
        }

        @Override
        public String toString() {
            return "Plugin{artifactId='" + artifactId + "', prefix='" + prefix + "'}";
        }
    }

    static class Snapshot {
        private int buildNumber;
        private String timestamp;

        public void setBuildNumber(int buildNumber) {
            this.buildNumber = buildNumber;
        }

        public void setTimestamp(String timestamp) {
            this.timestamp = timestamp;
        }

        @Override
        public String toString() {
            return "Snapshot{buildNumber=" + buildNumber + ", timestamp='" + timestamp + "'}";
        }
    }

    static class SnapshotVersion {
        private String version = "1.0-SNAPSHOT";
        private String classifier = "";
        private String extension = "pom";

        public String getVersion() {
            return version;
        }

        public String getClassifier() {
            return classifier;
        }

        public String getExtension() {
            return extension;
        }
    }

    static class Versioning {
        private List<String> versions = new ArrayList<>();
        private List<SnapshotVersion> snapshotVersions = new ArrayList<>();
        private Snapshot snapshot;
        private Date lastUpdatedTimestamp;
        private String latest;
        private String release;

        public void addVersion(String version) {
            versions.add(version);
        }

        public void setLastUpdatedTimestamp(Date d) {
            this.lastUpdatedTimestamp = d;
        }

        public void setLatest(String latest) {
            this.latest = latest;
        }

        public void setRelease(String release) {
            this.release = release;
        }

        public void setSnapshot(Snapshot snapshot) {
            this.snapshot = snapshot;
        }

        public void setSnapshotVersions(List<SnapshotVersion> svs) {
            this.snapshotVersions = svs;
        }

        @Override
        public String toString() {
            return "Versioning{versions=" + versions + ", latest='" + latest + "', release='" + release + "', snapshot="
                    + snapshot + "}";
        }
    }

    static class Metadata {
        private List<Plugin> plugins;
        private String groupId;
        private String artifactId;
        private String version;
        private Versioning versioning;

        public void setPlugins(List<Plugin> plugins) {
            this.plugins = plugins;
        }

        public void setGroupId(String groupId) {
            this.groupId = groupId;
        }

        public void setArtifactId(String artifactId) {
            this.artifactId = artifactId;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public void setVersioning(Versioning versioning) {
            this.versioning = versioning;
        }

        public Versioning getVersioning() {
            return versioning;
        }

        @Override
        public String toString() {
            return "Metadata{\n  groupId='" + groupId + "', \n  artifactId='" + artifactId + "', \n  version='"
                    + version + "', \n  plugins=" + plugins + ", \n  versioning=" + versioning + "\n}";
        }
    }

    static class Artifact {
        private String groupId, artifactId, version, type;

        public Artifact(String groupId, String artifactId, String version, String type) {
            this.groupId = groupId;
            this.artifactId = artifactId;
            this.version = version;
            this.type = type;
        }

        public String getType() {
            return type;
        }

        public Integer getBuildNumber() {
            return 1;
        }

        public String getTimestampString() {
            return "20260727.045850";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (!(o instanceof Artifact))
                return false;
            Artifact artifact = (Artifact) o;
            return groupId.equals(artifact.groupId) && artifactId.equals(artifact.artifactId)
                    && version.equals(artifact.version);
        }

        @Override
        public int hashCode() {
            return (groupId + artifactId + version).hashCode();
        }
    }

    static class Content {
        private long lastModified;

        public Content(long lastModified) {
            this.lastModified = lastModified;
        }

        public long getLastModified() {
            return lastModified;
        }
    }

    static class ModelPlugin {
    }

    static class PluginManagement {
        public List<ModelPlugin> getPlugins() {
            return new ArrayList<>();
        }
    }

    static class Build {
        public List<ModelPlugin> getPlugins() {
            return new ArrayList<>();
        }

        public PluginManagement getPluginManagement() {
            return new PluginManagement();
        }
    }

    static class Model {
        private String packaging;
        private String name;
        private Build build = new Build();

        public String getPackaging() {
            return packaging;
        }

        public void setPackaging(String packaging) {
            this.packaging = packaging;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Build getBuild() {
            return build;
        }
    }

    static class XmlStreamReader {
        public XmlStreamReader(InputStream is) {
        }
    }

    static class MavenXpp3Reader {
        public Model read(XmlStreamReader reader) throws XmlPullParserException {
            
            Model model = new Model();
            model.setPackaging("maven-plugin");
            model.setName("Mock Maven Plugin");
            return model;
        }
    }

    static class StringUtils {
        public static String stripStart(String str, String stripChars) {
            return str.startsWith(stripChars) ? str.substring(stripChars.length()) : str;
        }

        public static String stripEnd(String str, String stripChars) {
            return str.endsWith(stripChars) ? str.substring(0, str.length() - stripChars.length()) : str;
        }

        public static String removeStart(String str, String remove) {
            return str.startsWith(remove) ? str.substring(remove.length()) : str;
        }

        public static String removeEnd(String str, String remove) {
            return str.endsWith(remove) ? str.substring(0, str.length() - remove.length()) : str;
        }
    }

    static class IOUtils {
        public static void closeQuietly(InputStream is) {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                }
            }
        }
    }

    static class Maven3 {
        public static void addSnapshotVersion(List<SnapshotVersion> svs, Artifact a, String timestamp) {
            svs.add(new SnapshotVersion());
        }

        public static void addSnapshotVersions(Versioning v, List<SnapshotVersion> svs) {
            v.setSnapshotVersions(svs);
        }
    }

    static class VersionComparator implements Comparator<String> {
        @Override
        public int compare(String v1, String v2) {
            
            return v1.compareTo(v2);
        }
    }

    
    
    

    private Map<String, Map<String, Map<String, Map<Artifact, Content>>>> contents = new HashMap<>();

    private Set<String> getArtifactIds(String groupId) {
        if ("org.codehaus.mojo".equals(groupId)) {
            return new HashSet<>(Arrays.asList("mock-maven-plugin"));
        }
        return null;
    }

    private Set<String> getVersions(String groupId, String artifactId) {
        if ("org.codehaus.mojo".equals(groupId) && "mock-maven-plugin".equals(artifactId)) {
            return new HashSet<>(Arrays.asList("1.0.0", "1.1.0-SNAPSHOT"));
        }
        return null;
    }

    private InputStream get(Artifact artifact) throws ArtifactNotFoundException {
        return new ByteArrayInputStream("<project></project>".getBytes());
    }

    private long getLastModified(Artifact artifact) throws ArtifactNotFoundException {
        return System.currentTimeMillis();
    }

    private boolean setPluginGoalPrefixFromConfiguration(Plugin plugin, List<ModelPlugin> plugins) {
        
        return false;
    }

    
    public void addMockSnapshotContent(String groupId, String artifactId, String version) {
        contents.putIfAbsent(groupId, new HashMap<>());
        contents.get(groupId).putIfAbsent(artifactId, new HashMap<>());
        Map<Artifact, Content> versionMap = new HashMap<>();
        Artifact pomArtifact = new Artifact(groupId, artifactId, version, "pom");
        versionMap.put(pomArtifact, new Content(System.currentTimeMillis() - 10000));
        contents.get(groupId).get(artifactId).put(version, versionMap);
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public synchronized Metadata getMetadata(String path)
            throws IOException, MetadataNotFoundException {
        Metadata metadata = new Metadata();
        boolean foundMetadata = false;
        path = StringUtils.stripEnd(StringUtils.stripStart(path, "/"), "/");
        String groupId = path.replace('/', '.');
        Set<String> pluginArtifactIds = getArtifactIds(groupId);
        if (pluginArtifactIds != null) {
            List<Plugin> plugins = new ArrayList<Plugin>();
            for (String artifactId : pluginArtifactIds) {
                Set<String> pluginVersions = getVersions(groupId, artifactId);
                if (pluginVersions == null || pluginVersions.isEmpty()) {
                    continue;
                }
                String[] versions = pluginVersions.toArray(new String[pluginVersions.size()]);
                Arrays.sort(versions, new VersionComparator());
                MavenXpp3Reader reader = new MavenXpp3Reader();
                for (int j = versions.length - 1; j >= 0; j--) {
                    InputStream inputStream = null;
                    try {
                        inputStream = get(new Artifact(groupId, artifactId, versions[j], "pom"));
                        Model model = reader.read(new XmlStreamReader(inputStream));
                        if (model == null || !"maven-plugin".equals(model.getPackaging())) {
                            continue;
                        }
                        Plugin plugin = new Plugin();
                        plugin.setArtifactId(artifactId);
                        plugin.setName(model.getName());
                        
                        
                        
                        
                        boolean havePrefix = false;
                        final Build build = model.getBuild();
                        if (build != null && build.getPlugins() != null) {
                            havePrefix = setPluginGoalPrefixFromConfiguration(plugin, build.getPlugins());
                        }
                        if (!havePrefix && build != null && build.getPluginManagement() != null
                                && build.getPluginManagement().getPlugins() != null) {
                            havePrefix = setPluginGoalPrefixFromConfiguration(plugin,
                                    build.getPluginManagement().getPlugins());
                        }
                        if (!havePrefix && artifactId.startsWith("maven-") && artifactId.endsWith("-plugin")) {
                            plugin.setPrefix(
                                    StringUtils.removeStart(StringUtils.removeEnd(artifactId, "-plugin"), "maven-"));
                            havePrefix = true;
                        }
                        if (!havePrefix && artifactId.endsWith("-maven-plugin")) {
                            plugin.setPrefix(StringUtils.removeEnd(artifactId, "-maven-plugin"));
                            havePrefix = true;
                        }
                        if (!havePrefix) {
                            plugin.setPrefix(artifactId);
                        }
                        plugins.add(plugin);
                        foundMetadata = true;
                        break;
                    } catch (ArtifactNotFoundException e) {
                        
                    } catch (XmlPullParserException e) {
                        
                    } finally {
                        IOUtils.closeQuietly(inputStream);
                    }
                }
            }
            if (!plugins.isEmpty()) {
                metadata.setPlugins(plugins);
            }
        }
        int index = path.lastIndexOf('/');
        groupId = (index == -1 ? groupId : groupId.substring(0, index)).replace('/', '.');
        String artifactId = (index == -1 ? null : path.substring(index + 1));
        if (artifactId != null) {
            Set<String> artifactVersions = getVersions(groupId, artifactId);
            if (artifactVersions != null && !artifactVersions.isEmpty()) {
                metadata.setGroupId(groupId);
                metadata.setArtifactId(artifactId);
                Versioning versioning = new Versioning();
                List<String> versions = new ArrayList<String>(artifactVersions);
                Collections.sort(versions, new VersionComparator()); 
                long lastUpdated = 0;
                for (String version : versions) {
                    try {
                        long lastModified = getLastModified(new Artifact(groupId, artifactId, version, "pom"));
                        versioning.addVersion(version);
                        if (lastModified >= lastUpdated) {
                            lastUpdated = lastModified;
                            versioning.setLastUpdatedTimestamp(new Date(lastModified));
                            versioning.setLatest(version);
                            if (!version.endsWith("-SNAPSHOT")) {
                                versioning.setRelease(version);
                            }
                        }
                    } catch (ArtifactNotFoundException e) {
                        
                    }
                }
                metadata.setVersioning(versioning);
                foundMetadata = true;
            }
        }

        int index2 = index == -1 ? -1 : path.lastIndexOf('/', index - 1);
        groupId = index2 == -1 ? groupId : groupId.substring(0, index2).replace('/', '.');
        artifactId = index2 == -1 ? artifactId : path.substring(index2 + 1, index);
        String version = index2 == -1 ? null : path.substring(index + 1);
        if (version != null && version.endsWith("-SNAPSHOT")) {
            Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get(groupId);
            Map<String, Map<Artifact, Content>> versionMap = (artifactMap == null ? null : artifactMap.get(artifactId));
            Map<Artifact, Content> filesMap = (versionMap == null ? null : versionMap.get(version));
            if (filesMap != null) {
                List<SnapshotVersion> snapshotVersions = new ArrayList<SnapshotVersion>();
                int maxBuildNumber = 0;
                long lastUpdated = 0;
                String timestamp = null;
                boolean found = false;
                for (final Map.Entry<Artifact, Content> entry : filesMap.entrySet()) {
                    final Artifact artifact = entry.getKey();
                    final Content content = entry.getValue();
                    SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMddHHmmss");
                    fmt.setTimeZone(TimeZone.getTimeZone("GMT"));
                    String lastUpdatedTime = fmt.format(new Date(content.getLastModified()));
                    try {
                        Maven3.addSnapshotVersion(snapshotVersions, artifact, lastUpdatedTime);
                    } catch (LinkageError e) {
                        
                    }
                    if ("pom".equals(artifact.getType())) {
                        if (artifact.getBuildNumber() != null
                                && maxBuildNumber < artifact.getBuildNumber().intValue()) {
                            maxBuildNumber = artifact.getBuildNumber().intValue();
                            timestamp = artifact.getTimestampString();
                        } else {
                            maxBuildNumber = Math.max(1, maxBuildNumber);
                        }
                        lastUpdated = Math.max(lastUpdated, content.getLastModified());
                        found = true;
                    }
                }

                if (!snapshotVersions.isEmpty() || found) {
                    Versioning versioning = metadata.getVersioning();
                    if (versioning == null) {
                        versioning = new Versioning();
                    }
                    metadata.setGroupId(groupId);
                    metadata.setArtifactId(artifactId);
                    metadata.setVersion(version);
                    try {
                        Maven3.addSnapshotVersions(versioning, snapshotVersions);
                    } catch (LinkageError e) {
                        
                    }
                    if (maxBuildNumber > 0) {
                        Snapshot snapshot = new Snapshot();
                        snapshot.setBuildNumber(maxBuildNumber);
                        snapshot.setTimestamp(timestamp);
                        versioning.setSnapshot(snapshot);
                    }
                    versioning.setLastUpdatedTimestamp(new Date(lastUpdated));
                    metadata.setVersioning(versioning);
                    foundMetadata = true;
                }
            }

        }
        if (!foundMetadata) {
            throw new MetadataNotFoundException(path);
        }
        return metadata;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        System.out.println("Starting MockArtifactStore Metadata Extraction Simulation...\n");
        method_1_mrm_gemini store = new method_1_mrm_gemini();

        System.out.println("--- Scenario 1: Fetch Metadata for a Plugin Group Directory ---");
        try {
            
            Metadata meta = store.getMetadata("/org/codehaus/mojo");
            System.out.println("Result:\n" + meta.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n--- Scenario 2: Fetch Metadata for a Specific Plugin Artifact ---");
        try {
            
            Metadata meta2 = store.getMetadata("/org/codehaus/mojo/mock-maven-plugin");
            System.out.println("Result:\n" + meta2.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n--- Scenario 3: Fetch Metadata for a Snapshot Version ---");
        try {
            
            store.addMockSnapshotContent("org.codehaus.mojo", "mock-maven-plugin", "1.1.0-SNAPSHOT");

            
            Metadata meta3 = store.getMetadata("/org/codehaus/mojo/mock-maven-plugin/1.1.0-SNAPSHOT");
            System.out.println("Result:\n" + meta3.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n--- Scenario 4: Requesting Non-Existent Metadata ---");
        try {
            store.getMetadata("/org/unknown/path");
        } catch (MetadataNotFoundException e) {
            System.out.println("Expected MetadataNotFoundException successfully caught for path: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}