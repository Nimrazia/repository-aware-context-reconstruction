


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class method_3_mrm_gemini {

    public static class StringUtils {
        public static boolean isEmpty(String str) {
            return str == null || str.trim().isEmpty();
        }
    }

    public static class Plugin {
        private String artifactId;
        public Plugin(String artifactId) { this.artifactId = artifactId; }
        public String getArtifactId() { return artifactId; }
    }

    public static class Snapshot {
        private int buildNumber;
        private String timestamp;
        public int getBuildNumber() { return buildNumber; }
        public void setBuildNumber(int buildNumber) { this.buildNumber = buildNumber; }
        public String getTimestamp() { return timestamp; }
        public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    }

    public static class SnapshotVersion {
        private String version;
        private String classifier;
        private String extension;
        public SnapshotVersion(String version, String classifier, String extension) {
            this.version = version; this.classifier = classifier; this.extension = extension;
        }
        public String getVersion() { return version; }
        public String getClassifier() { return classifier; }
        public String getExtension() { return extension; }
    }

    public static class Versioning {
        private String lastUpdated;
        private String latest;
        private String release;
        private List<String> versions = new ArrayList<String>();
        private Snapshot snapshot;
        private List<SnapshotVersion> snapshotVersions = new ArrayList<SnapshotVersion>();

        public String getLastUpdated() { return lastUpdated; }
        public void setLastUpdated(String lastUpdated) { this.lastUpdated = lastUpdated; }
        public String getLatest() { return latest; }
        public void setLatest(String latest) { this.latest = latest; }
        public String getRelease() { return release; }
        public void setRelease(String release) { this.release = release; }
        public List<String> getVersions() { return versions; }
        public void addVersion(String v) { versions.add(v); }
        public Snapshot getSnapshot() { return snapshot; }
        public void setSnapshot(Snapshot s) { this.snapshot = s; }
        public List<SnapshotVersion> getSnapshotVersions() { return snapshotVersions; }
        public void addSnapshotVersion(SnapshotVersion sv) { snapshotVersions.add(sv); }
    }

    public static class Metadata {
        private String artifactId;
        private String groupId;
        private String version;
        private List<Plugin> plugins = new ArrayList<Plugin>();
        private Versioning versioning;

        public String getArtifactId() { return artifactId; }
        public void setArtifactId(String artifactId) { this.artifactId = artifactId; }
        public String getGroupId() { return groupId; }
        public void setGroupId(String groupId) { this.groupId = groupId; }
        public String getVersion() { return version; }
        public void setVersion(String version) { this.version = version; }
        public List<Plugin> getPlugins() { return plugins; }
        public void addPlugin(Plugin p) { plugins.add(p); }
        public Versioning getVersioning() { return versioning; }
        public void setVersioning(Versioning v) { this.versioning = v; }
    }

    public static class MetadataNotFoundException extends Exception {
        public MetadataNotFoundException(String path) { super("Metadata not found at: " + path); }
    }

    public interface ArtifactStore {
        Metadata getMetadata(String path) throws IOException, MetadataNotFoundException;
    }

    protected ArtifactStore[] stores;

    public method_3_mrm_gemini(ArtifactStore[] stores) {
        this.stores = stores;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public Metadata getMetadata( String path )
        throws IOException, MetadataNotFoundException
    {
        boolean found = false;
        Metadata result = new Metadata();
        Set<String> pluginArtifactIds = new HashSet<String>();
        Set<String> snapshotVersions = new HashSet<String>();
        for ( int i = 0; i < stores.length; i++ )
        {
            try
            {
                Metadata partial = stores[i].getMetadata( path );
                if ( StringUtils.isEmpty( result.getArtifactId() ) && !StringUtils.isEmpty( partial.getArtifactId() ) )
                {
                    result.setArtifactId( partial.getArtifactId() );
                    found = true;
                }
                if ( StringUtils.isEmpty( result.getGroupId() ) && !StringUtils.isEmpty( partial.getGroupId() ) )
                {
                    result.setGroupId( partial.getGroupId() );
                    found = true;
                }
                if ( StringUtils.isEmpty( result.getVersion() ) && !StringUtils.isEmpty( partial.getVersion() ) )
                {
                    result.setVersion( partial.getVersion() );
                    found = true;
                }
                if ( partial.getPlugins() != null && !partial.getPlugins().isEmpty() )
                {
                    for ( Plugin plugin : partial.getPlugins() )
                    {
                        if ( !pluginArtifactIds.contains( plugin.getArtifactId() ) )
                        {
                            result.addPlugin( plugin );
                            pluginArtifactIds.add( plugin.getArtifactId() );
                        }
                    }
                    found = true;
                }
                if ( partial.getVersioning() != null )
                {
                    Versioning rVers = result.getVersioning();
                    if ( rVers == null )
                    {
                        rVers = new Versioning();
                    }
                    Versioning pVers = partial.getVersioning();
                    String rLU = found ? rVers.getLastUpdated() : null;
                    String pLU = pVers.getLastUpdated();
                    if ( pLU != null && ( rLU == null || rLU.compareTo( pLU ) < 0 ) )
                    {
                        
                        if ( !StringUtils.isEmpty( pVers.getLatest() ) )
                        {
                            rVers.setLatest( pVers.getLatest() );
                        }

                        if ( !StringUtils.isEmpty( pVers.getRelease() ) )
                        {
                            rVers.setLatest( pVers.getRelease() );
                        }
                        rVers.setLastUpdated( pVers.getLastUpdated() );
                    }
                    for ( String version : pVers.getVersions() )
                    {
                        if ( !rVers.getVersions().contains( version ) )
                        {
                            rVers.addVersion( version );
                        }
                    }
                    if ( pVers.getSnapshot() != null )
                    {
                        if ( rVers.getSnapshot() == null
                            || pVers.getSnapshot().getBuildNumber() > rVers.getSnapshot().getBuildNumber() )
                        {
                            Snapshot snapshot = new Snapshot();
                            snapshot.setBuildNumber( pVers.getSnapshot().getBuildNumber() );
                            snapshot.setTimestamp( pVers.getSnapshot().getTimestamp() );
                            rVers.setSnapshot( snapshot );
                        }
                    }
                    try
                    {
                        if ( pVers.getSnapshotVersions() != null && !pVers.getSnapshotVersions().isEmpty() )
                        {
                            for ( SnapshotVersion snapshotVersion : pVers.getSnapshotVersions() )
                            {
                                String key = snapshotVersion.getVersion() + "-" + snapshotVersion.getClassifier() + "."
                                    + snapshotVersion.getExtension();
                                if ( !snapshotVersions.contains( key ) )
                                {
                                    rVers.addSnapshotVersion( snapshotVersion );
                                    snapshotVersions.add( key );
                                }
                            }
                        }
                    }
                    catch ( NoSuchMethodError e )
                    {
                        
                    }

                    result.setVersioning( rVers );
                    found = true;
                }
            }
            catch ( MetadataNotFoundException e )
            {
                
            }
        }
        if ( !found )
        {
            throw new MetadataNotFoundException( path );
        }
        return result;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting CompositeArtifactStore.getMetadata Simulation...\n");
        ArtifactStore store1 = new ArtifactStore() {
            public Metadata getMetadata(String path) {
                Metadata m = new Metadata();
                m.setGroupId("org.codehaus.mojo");
                m.setArtifactId("mrm-servlet");
                m.setVersion("1.0");
                return m;
            }
        };
        method_3_mrm_gemini store = new method_3_mrm_gemini(new ArtifactStore[]{store1});
        try {
            Metadata res = store.getMetadata("metadata.xml");
            System.out.println("Metadata retrieved successfully: GroupId=" + res.getGroupId() + ", ArtifactId=" + res.getArtifactId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Execution Complete.");
    }
}