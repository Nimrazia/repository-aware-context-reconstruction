



import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class method_2_mrm_gemini {

    public static void main(String[] args) throws Exception {
        System.out.println("Starting FileSystemServlet.doGet() Simulation...\n");

        
        
        File settingsFile = new File("settings-mrm.xml");
        try (FileOutputStream fos = new FileOutputStream(settingsFile)) {
            fos.write("<settings>\n  <proxy>@repository.proxy.url@</proxy>\n</settings>".getBytes("UTF-8"));
        }
        settingsFile.deleteOnExit();

        FileSystemServlet servlet = new FileSystemServlet();
        servlet.init(new MockServletContext());

        System.out.println("--- Scenario 1: Requesting Settings XML ---");
        MockHttpServletRequest req1 = new MockHttpServletRequest("/settings.xml", null);
        MockHttpServletResponse resp1 = new MockHttpServletResponse();
        servlet.doGet(req1, resp1);
        System.out.println("Status: " + resp1.getStatus());
        System.out.println("Content-Type: " + resp1.getContentType());
        System.out.println("Response Body:\n" + resp1.getWriterOutput());

        System.out.println("--- Scenario 2: Requesting a File ---");
        MockHttpServletRequest req2 = new MockHttpServletRequest("/repo/artifact.jar", null);
        MockHttpServletResponse resp2 = new MockHttpServletResponse();
        servlet.doGet(req2, resp2);
        System.out.println("Status: " + resp2.getStatus());
        System.out.println("Content-Type: " + resp2.getContentType());
        System.out.println("Content-Length: " + resp2.getContentLength());
        System.out.println("Response Data Length: " + resp2.getStreamOutput().length + " bytes\n");

        System.out.println("--- Scenario 3: Requesting a Directory (Without Trailing Slash) ---");
        MockHttpServletRequest req3 = new MockHttpServletRequest("/repo/org", null);
        MockHttpServletResponse resp3 = new MockHttpServletResponse();
        servlet.doGet(req3, resp3);
        System.out.println("Status: " + resp3.getStatus());
        System.out.println("Redirected to: " + resp3.getRedirectUrl() + "\n");

        System.out.println("--- Scenario 4: Requesting a Directory (With Trailing Slash) ---");
        MockHttpServletRequest req4 = new MockHttpServletRequest("/repo/org/", null);
        MockHttpServletResponse resp4 = new MockHttpServletResponse();
        servlet.doGet(req4, resp4);
        System.out.println("Status: " + resp4.getStatus());
        System.out.println("Content-Type: " + resp4.getContentType());
        System.out.println("Response Body (HTML Index):");
        System.out.println(resp4.getWriterOutput());

        System.out.println("--- Scenario 5: Requesting Non-Existent Path ---");
        MockHttpServletRequest req5 = new MockHttpServletRequest("/repo/notfound", null);
        MockHttpServletResponse resp5 = new MockHttpServletResponse();
        servlet.doGet(req5, resp5);
        System.out.println("Status: " + resp5.getStatus());
        System.out.println("Error Message: HTTP " + resp5.getStatus() + " Not Found");

        System.out.println("\nExecution Complete.");
    }
}





class ServletException extends Exception {}

interface ServletContext {
    String getMimeType(String file);
}

class MockServletContext implements ServletContext {
    public String getMimeType(String file) {
        if (file.endsWith(".jar")) return "application/java-archive";
        if (file.endsWith(".xml")) return "text/xml";
        return "application/octet-stream";
    }
}

class HttpServletRequest {
    private String pathInfo, servletPath, contextPath, scheme, serverName;
    private int serverPort;
    public HttpServletRequest(String pathInfo, String servletPath, String contextPath) {
        this.pathInfo = pathInfo; this.servletPath = servletPath; this.contextPath = contextPath;
        this.scheme = "http"; this.serverName = "localhost"; this.serverPort = 8080;
    }
    public String getPathInfo() { return pathInfo; }
    public String getServletPath() { return servletPath; }
    public String getContextPath() { return contextPath; }
    public String getScheme() { return scheme; }
    public String getServerName() { return serverName; }
    public int getServerPort() { return serverPort; }
}

class MockHttpServletRequest extends HttpServletRequest {
    public MockHttpServletRequest(String pathInfo, String servletPath) {
        super(pathInfo, servletPath == null ? "" : servletPath, "/mrm");
    }
}

class HttpServletResponse {
    protected int status = 200;
    protected String contentType;
    protected int contentLength = -1;
    protected String redirectUrl;
    protected StringWriter stringWriter = new StringWriter();
    protected PrintWriter writer = new PrintWriter(stringWriter);
    protected ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

    public void setContentType(String type) { this.contentType = type; }
    public void setContentLength(int len) { this.contentLength = len; }
    public PrintWriter getWriter() { return writer; }
    public OutputStream getOutputStream() { return outputStream; }
    public void sendRedirect(String url) { this.status = 302; this.redirectUrl = url; }
    public void sendError(int code) { this.status = code; }
    
    
    public int getStatus() { return status; }
    public String getContentType() { return contentType; }
    public int getContentLength() { return contentLength; }
    public String getRedirectUrl() { return redirectUrl; }
    public String getWriterOutput() { writer.flush(); return stringWriter.toString(); }
    public byte[] getStreamOutput() { return outputStream.toByteArray(); }
}

class MockHttpServletResponse extends HttpServletResponse {}

abstract class HttpServlet {
    private ServletContext context;
    public void init(ServletContext context) { this.context = context; }
    public ServletContext getServletContext() { return context; }
}

class IOUtil {
    public static void copy(Reader r, PrintWriter w) throws IOException {
        char[] buf = new char[4096];
        int n;
        while ((n = r.read(buf)) != -1) w.write(buf, 0, n);
    }
    public static void close(Reader r) {
        if (r != null) try { r.close(); } catch (Exception e) {}
    }
}

class IOUtils {
    public static void copy(InputStream is, OutputStream os) throws IOException {
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) != -1) os.write(buf, 0, n);
    }
    public static void closeQuietly(InputStream is) {
        if (is != null) try { is.close(); } catch (Exception e) {}
    }
    public static void closeQuietly(OutputStream os) {
        if (os != null) try { os.close(); } catch (Exception e) {}
    }
}

class StringUtils {
    public static String repeat(String str, int repeat) {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < repeat; i++) sb.append(str);
        return sb.toString();
    }
    public static String leftPad(String str, int size) {
        if (str == null) return null;
        int pads = size - str.length();
        if (pads <= 0) return str;
        return repeat(" ", pads) + str;
    }
}

class InterpolationFilterReader extends FilterReader {
    private Map<String, Object> map;
    public InterpolationFilterReader(Reader in, Map<String, Object> map, String start, String end) {
        super(in);
        this.map = map;
    }
    @Override
    public int read(char[] cbuf, int off, int len) throws IOException {
        
        
        return super.read(cbuf, off, len);
    }
}

class Utils {
    public static String urlEncodePathSegment(String s) { return s; }
}

interface Entry {
    String getName();
    long getLastModified() throws IOException;
}

class FileEntry implements Entry {
    private String name;
    public FileEntry(String name) { this.name = name; }
    public String getName() { return name; }
    public long getLastModified() { return System.currentTimeMillis(); }
    public long getSize() throws IOException { return 1024; }
    public InputStream getInputStream() { return new ByteArrayInputStream(new byte[1024]); }
}

class DirectoryEntry implements Entry {
    private String name;
    private DirectoryEntry parent;
    public DirectoryEntry(String name, DirectoryEntry parent) { this.name = name; this.parent = parent; }
    public String getName() { return name; }
    public long getLastModified() { return System.currentTimeMillis(); }
    public DirectoryEntry getParent() { return parent; }
}

class FileSystem {
    public Entry get(String path) {
        if ("/repo/artifact.jar".equals(path)) return new FileEntry("artifact.jar");
        if ("/repo/org".equals(path)) return new DirectoryEntry("org", new DirectoryEntry("repo", null));
        if ("/repo/org/".equals(path)) return new DirectoryEntry("org", new DirectoryEntry("repo", null));
        return null; 
    }
    public Entry[] listEntries(DirectoryEntry dir) {
        return new Entry[]{
            new DirectoryEntry("apache", dir),
            new FileEntry("maven-metadata.xml")
        };
    }
}





class FileSystemServlet extends HttpServlet {
    private String settingsServletPath = "settings.xml";
    private FileSystem fileSystem = new FileSystem();
    private static final int NAME_COL_WIDTH = 50;
    private static final int SIZE_COL_WIDTH = 20;

    private String formatName(String name) {
        return name.length() > NAME_COL_WIDTH ? name.substring(0, NAME_COL_WIDTH) : name;
    }


// ORIGINAL CODESEARCHNET METHOD — START

protected void doGet( HttpServletRequest req, HttpServletResponse resp )
        throws ServletException, IOException
    {
        String path = req.getPathInfo();
        String context;
        if ( path == null )
        {
            path = req.getServletPath();
            context = req.getContextPath();
        }
        else
        {
            context = req.getContextPath() + req.getServletPath();
        }
        
        if ( path.equals( "/" + settingsServletPath ) )
        {
            resp.setContentType( "text/xml" );
            PrintWriter w = resp.getWriter();
            
            Reader settingsReader = null;
            try 
            {
                String hostAddress;
                try
                {
                    hostAddress = InetAddress.getLocalHost().getHostAddress();
                }
                catch ( UnknownHostException e )
                {
                    hostAddress = req.getServerName();
                }

                String repositoryProxyUrl = req.getScheme() + "://" + hostAddress + ":" + req.getServerPort(); 
                Reader in = new InputStreamReader( FileSystemServlet.class.getResourceAsStream( "/settings-mrm.xml" ) );
                settingsReader = new InterpolationFilterReader( in, Collections.<String, Object>singletonMap( "repository.proxy.url", repositoryProxyUrl ), "@", "@" );
                IOUtil.copy( settingsReader, w );
            }
            finally
            {
                IOUtil.close( settingsReader );
            }
            return;
        }
        
        Entry entry = fileSystem.get( path );
        if ( entry instanceof FileEntry )
        {
            FileEntry fileEntry = (FileEntry) entry;
            long size = fileEntry.getSize();
            if ( size >= 0 && size < Integer.MAX_VALUE )
            {
                resp.setContentLength( (int) size );
            }
            resp.setContentType( getServletContext().getMimeType( fileEntry.getName() ) );
            InputStream source = null;
            OutputStream destination = null;
            try
            {
                source = fileEntry.getInputStream();
                destination = resp.getOutputStream();
                IOUtils.copy( source, destination );
            }
            finally
            {
                IOUtils.closeQuietly( source );
                IOUtils.closeQuietly( destination );
            }
            return;
        }
        else if ( entry instanceof DirectoryEntry )
        {
            if ( !path.endsWith( "/" ) )
            {
                resp.sendRedirect( entry.getName() + "/" );
                return;
            }
            DirectoryEntry dirEntry = (DirectoryEntry) entry;
            Entry[] entries = fileSystem.listEntries( dirEntry );
            resp.setContentType( "text/html" );
            PrintWriter w = resp.getWriter();
            w.println( "<html>" );
            w.println( "  <head>" );
            w.println( "    <title>Index of " + context + path + "</title>" );
            w.println( "    <meta http-equiv=\"Content-Type\" repository=\"text/html; charset=utf-8\"/>" );
            w.println( "</head>" );
            w.println( "<body>" );
            w.println( "<h1>Index of " + context + path + "</h1>" );
            w.println( "  <hr/>" );
            w.write( "<pre>" );

            if ( dirEntry.getParent() != null )
            {
                w.println( "<a href='../'>../</a>" );
            }
            SimpleDateFormat format = new SimpleDateFormat( "dd-MMM-yyyy hh:mm" );
            if ( entries != null )
            {
                for ( int i = 0; i < entries.length; i++ )
                {
                    final String childName = entries[i].getName();
                    boolean directory = entries[i] instanceof DirectoryEntry;
                    if ( directory )
                    {
                        String dirName = childName + "/";
                        w.write(
                            "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "/\">" + formatName( dirName )
                                + "</a>" + StringUtils.repeat( " ",
                                                               Math.max( 0, NAME_COL_WIDTH - dirName.length() ) ) );
                    }
                    else
                    {
                        w.write(
                            "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "\">" + formatName( childName )
                                + "</a>" + StringUtils.repeat( " ",
                                                               Math.max( 0, NAME_COL_WIDTH - childName.length() ) ) );
                    }

                    long timestamp = 0;
                    try
                    {
                        timestamp = entries[i].getLastModified();
                    }
                    catch ( IOException e )
                    {
                        
                    }

                    w.write( " " );
                    w.write( format.format( timestamp != -1 ? new Date( timestamp ) : new Date() ) );
                    if ( directory )
                    {
                        w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                    }
                    else if ( entries[i] instanceof FileEntry )
                    {
                        FileEntry fileEntry = (FileEntry) entries[i];
                        try
                        {
                            long size = fileEntry.getSize();
                            if ( size >= 0 )
                            {
                                w.println( StringUtils.leftPad( Long.toString( size ), SIZE_COL_WIDTH ) );
                            }
                            else
                            {
                                w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                            }
                        }
                        catch ( IOException e )
                        {
                            w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                        }
                    }
                    else
                    {
                        w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                    }
                }
            }
            w.write( "</pre>" );
            w.println( "  <hr/>" );
            w.println( "</body>" );
            w.println( "</html>" );
            return;
        }

        resp.sendError( HttpURLConnection.HTTP_NOT_FOUND );
    }

// ORIGINAL CODESEARCHNET METHOD — END

}