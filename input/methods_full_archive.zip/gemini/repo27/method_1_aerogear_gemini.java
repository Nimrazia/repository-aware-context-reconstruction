



import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class method_1_aerogear_gemini {

    
    
    

    public static class Log {
        public static void e(String tag, String msg, Throwable tr) {
            System.out.println("ERROR [" + tag + "]: " + msg + " | Exception: " + tr.getMessage());
        }
    }

    public static class HeaderAndBody {}

    public interface Pipe<T> {}

    public static class ReadFilter {
        private URI linkUri;
        private JSONObject where;

        public void setLinkUri(URI linkUri) { this.linkUri = linkUri; }
        public void setWhere(JSONObject where) { this.where = where; }
        public URI getLinkUri() { return linkUri; }
    }

    public static class JSONObject {}

    public static class WrappingPagedList<T> extends ArrayList<T> {
        private Pipe<T> pipe;
        private List<T> result;
        private ReadFilter nextRead;
        private ReadFilter previousRead;

        public WrappingPagedList(Pipe<T> pipe, List<T> result, ReadFilter nextRead, ReadFilter previousRead) {
            this.pipe = pipe;
            this.result = result;
            this.nextRead = nextRead;
            this.previousRead = previousRead;
            this.addAll(result);
        }

        public ReadFilter getNextRead() { return nextRead; }
        public ReadFilter getPreviousRead() { return previousRead; }
    }

    public static class PageConfig {
        public enum MetadataLocations { WEB_LINKING, HEADERS, BODY }
        
        private MetadataLocations metadataLocation = MetadataLocations.WEB_LINKING;
        private String nextIdentifier = "next";
        private String previousIdentifier = "prev";
        private PageParameterExtractor pageParameterExtractor;

        public MetadataLocations getMetadataLocation() { return metadataLocation; }
        public void setMetadataLocation(MetadataLocations loc) { this.metadataLocation = loc; }
        public String getNextIdentifier() { return nextIdentifier; }
        public String getPreviousIdentifier() { return previousIdentifier; }
        public PageParameterExtractor getPageParameterExtractor() { return pageParameterExtractor; }
    }

    public interface PageParameterExtractor {
        ReadFilter getNextFilter(HeaderAndBody response, PageConfig config);
        ReadFilter getPreviousFilter(HeaderAndBody response, PageConfig config);
    }

    public static class WebLink {
        private String uri;
        private Map<String, String> parameters = new HashMap<>();

        public WebLink(String uri, String rel) {
            this.uri = uri;
            parameters.put("rel", rel);
        }

        public String getUri() { return uri; }
        public Map<String, String> getParameters() { return parameters; }
    }

    public static class WebLinkParser {
        public static List<WebLink> parse(String raw) throws ParseException {
            List<WebLink> links = new ArrayList<>();
            if (raw.contains("next")) {
                links.add(new WebLink("http://example.com/api?page=2", "next"));
            }
            if (raw.contains("prev")) {
                links.add(new WebLink("http://example.com/api?page=1", "prev"));
            }
            return links;
        }
    }

    
    
    

    private static final String TAG = "RestAdapter";
    private PageConfig pageConfig = new PageConfig();

    public String getWebLinkHeader(HeaderAndBody response) {
        return "<http://example.com/api?page=2>; rel=\"next\", <http://example.com/api?page=1>; rel=\"prev\"";
    }


// ORIGINAL CODESEARCHNET METHOD — START

private List<Object> computePagedList(List<Object> result, HeaderAndBody httpResponse, JSONObject where, Pipe<Object> requestingPipe) {
        ReadFilter previousRead = null;
        ReadFilter nextRead = null;

        if (PageConfig.MetadataLocations.WEB_LINKING.equals(pageConfig.getMetadataLocation())) {
            String webLinksRaw = "";
            final String relHeader = "rel";
            final String nextIdentifier = pageConfig.getNextIdentifier();
            final String prevIdentifier = pageConfig.getPreviousIdentifier();
            try {
                webLinksRaw = getWebLinkHeader(httpResponse);
                if (webLinksRaw == null) { 
                    return result;
                }
                List<WebLink> webLinksParsed = WebLinkParser.parse(webLinksRaw);
                for (WebLink link : webLinksParsed) {
                    if (nextIdentifier.equals(link.getParameters().get(relHeader))) {
                        nextRead = new ReadFilter();
                        nextRead.setLinkUri(new URI(link.getUri()));
                    } else if (prevIdentifier.equals(link.getParameters().get(relHeader))) {
                        previousRead = new ReadFilter();
                        previousRead.setLinkUri(new URI(link.getUri()));
                    }

                }
            } catch (URISyntaxException ex) {
                Log.e(TAG, webLinksRaw + " did not contain a valid context URI", ex);
                throw new RuntimeException(ex);
            } catch (ParseException ex) {
                Log.e(TAG, webLinksRaw + " could not be parsed as a web link header", ex);
                throw new RuntimeException(ex);
            }
        } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.HEADERS)) {
            nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, method_1_aerogear_gemini.this.pageConfig);
            previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, method_1_aerogear_gemini.this.pageConfig);
        } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.BODY)) {
            nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, method_1_aerogear_gemini.this.pageConfig);
            previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, method_1_aerogear_gemini.this.pageConfig);
        } else {
            throw new IllegalStateException("Not supported");
        }
        if (nextRead != null) {
            nextRead.setWhere(where);
        }

        if (previousRead != null) {
            previousRead.setWhere(where);
        }

        return new WrappingPagedList<Object>(requestingPipe, result, nextRead, previousRead);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting RestAdapter.computePagedList Simulation...\n");

        method_1_aerogear_gemini adapter = new method_1_aerogear_gemini();
        List<Object> rawResult = new ArrayList<>();
        rawResult.add("Item 1");
        rawResult.add("Item 2");

        List<Object> pagedResult = adapter.computePagedList(rawResult, new HeaderAndBody(), new JSONObject(), new Pipe<Object>() {});

        System.out.println("Computed Paged List successfully!");
        System.out.println(" -> Items in list: " + pagedResult.size());
        if (pagedResult instanceof WrappingPagedList) {
            WrappingPagedList<?> wrapped = (WrappingPagedList<?>) pagedResult;
            System.out.println(" -> Next Read URI: " + wrapped.getNextRead().getLinkUri());
            System.out.println(" -> Previous Read URI: " + wrapped.getPreviousRead().getLinkUri());
        }

        System.out.println("\nExecution Complete.");
    }
}