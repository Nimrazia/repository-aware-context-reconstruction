



import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

interface AeroGearRemoveAdapter {
    void remove(String id, method_3_aerogear_gemini.Callback<Void> callback);
}

public class method_3_aerogear_gemini implements AeroGearRemoveAdapter {

    
    
    

    public interface Callback<T> {
        void onSuccess(T data);
        void onFailure(Exception e);
    }

    public static class RestRunner {
        private boolean shouldThrow;
        public RestRunner(boolean shouldThrow) { this.shouldThrow = shouldThrow; }
        public void onRemove(String id) throws Exception {
            if (shouldThrow) throw new Exception("Failed to delete record ID: " + id);
            System.out.println("DEBUG: RestRunner successfully deleted record ID: " + id);
        }
    }

    
    
    

    private ExecutorService THREAD_POOL_EXECUTOR = Executors.newSingleThreadExecutor();
    private RestRunner restRunner;

    public method_3_aerogear_gemini(RestRunner restRunner) {
        this.restRunner = restRunner;
    }

    public void shutdown() { THREAD_POOL_EXECUTOR.shutdown(); }


// ORIGINAL CODESEARCHNET METHOD — START

@Override
    public void remove(final String id, final Callback<Void> callback) {

        THREAD_POOL_EXECUTOR.execute(new Runnable() {
            Exception exception = null;

            @Override
            public void run() {
                try {
                    method_3_aerogear_gemini.this.restRunner.onRemove(id);
                } catch (Exception e) {
                    exception = e;
                }
                if (exception == null) {
                    callback.onSuccess(null);
                } else {
                    callback.onFailure(exception);
                }
            }
        });

    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting RestAdapter.remove Simulation...\n");

        System.out.println("--- Scenario 1: Successful Removal ---");
        method_3_aerogear_gemini adapter1 = new method_3_aerogear_gemini(new RestRunner(false));
        adapter1.remove("id_123", new Callback<Void>() {
            @Override
            public void onSuccess(Void data) { System.out.println("Callback: Successfully removed!"); }
            @Override
            public void onFailure(Exception e) { System.out.println("Callback: Failed - " + e.getMessage()); }
        });

        
        try { Thread.sleep(100); } catch (InterruptedException e) {}
        adapter1.shutdown();

        System.out.println("\n--- Scenario 2: Failed Removal ---");
        method_3_aerogear_gemini adapter2 = new method_3_aerogear_gemini(new RestRunner(true));
        adapter2.remove("id_456", new Callback<Void>() {
            @Override
            public void onSuccess(Void data) { System.out.println("Callback: Successfully removed!"); }
            @Override
            public void onFailure(Exception e) { System.out.println("Callback: Caught expected failure - " + e.getMessage()); }
        });

        try { Thread.sleep(100); } catch (InterruptedException e) {}
        adapter2.shutdown();

        System.out.println("\nExecution Complete.");
    }
}