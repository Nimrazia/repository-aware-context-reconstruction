import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class method_2_lvt_gemini {

    
    static class Label { public String value() { return "label"; } }
    static class StringLabel extends Label { String v; public StringLabel(String v) { this.v = v; } public String value() { return v; } }
    
    static class Tree implements Iterable<Tree> {
        public Tree prune(Object f) { return this; }
        public ArrayList<Label> yield() { ArrayList<Label> l = new ArrayList<>(); l.add(new Label()); return l; }
        public Label label() { return new StringLabel("ROOT"); }
        public boolean isUnaryRewrite() { return false; }
        public Tree firstChild() { return this; }
        public ArrayList<TaggedWord> taggedYield() { return new ArrayList<>(); }
        public void pennPrint(PrintWriter pw) { pw.print("(ROOT label)"); }
        public void indentedListPrint(PrintWriter pw, boolean b) { pw.print("indentedTree"); }
        public Tree deepCopy(Object tf, Object cf) { return this; }
        public Object treeFactory() { return null; }
        public void indexLeaves() {}
        public Set<Dependency<Label, Label, Object>> mapDependencies(Object f, Object hf) { return Collections.emptySet(); }
        public Set<Dependency<Label, Label, Object>> mapDependencies(Object f, Object hf, String root) { return Collections.emptySet(); }
        public List<CoreLabel> taggedLabeledYield() { return new ArrayList<>(); }
        public Tree treeSkeletonCopy() { return this; }
        public boolean isLeaf() { return true; }
        public void setLabel(Label l) {}
        public List<Tree> getLeaves() { return new ArrayList<>(); }
        public Tree parent(Tree t) { return this; }
        @Override public Iterator<Tree> iterator() { return Collections.emptyIterator(); }
    }

    static class BobChrisTreeNormalizer {
        static class EmptyFilter {}
        public Tree normalizeWholeTree(Tree t, Object tf) { return t; }
    }

    static class Sentence {
        public static String listToString(List<?> l, boolean b) { return "sentence_string"; }
    }

    static class PTBTokenizer {
        public static String ptb2Text(String s) { return s; }
        public static String ptbToken2Text(String s) { return s; }
    }

    static class TaggedWord {
        public String tag() { return "NN"; }
        public String word() { return "word"; }
    }

    static class Trees {
        public static Tree lexicalize(Tree t, Object hf) { return t; }
    }

    interface Function<T1, T2> { T2 apply(T1 in); }
    static class TreeFunctions {
        public static Function<Tree, Tree> getLabeledToDescriptiveCoreLabelTreeFunction() { return t -> t; }
        public static Function<Tree, Tree> getLabeledTreeToStringLabeledTreeFunction() { return t -> t; }
    }

    static class ChineseEnglishWordMap {
        static ChineseEnglishWordMap inst = new ChineseEnglishWordMap();
        public static ChineseEnglishWordMap getInstance() { return inst; }
        public String getFirstTranslation(String s) { return "trans"; }
    }

    static class XMLUtils {
        public static String escapeXML(String s) { return s; }
    }

    static class Dependency<G, D, N> {
        public Object governor() { return new CoreLabel(); }
        public Object dependent() { return new CoreLabel(); }
        public String toString(String fmt) { return "dep"; }
    }

    static class Dependencies {
        public static java.util.Comparator<Dependency<Label, Label, Object>> dependencyIndexComparator() { return (a, b) -> 0; }
    }

    static class GrammaticalStructure {
        public Object typedDependencies() { return null; }
        public Object allTypedDependencies() { return null; }
        public Object typedDependenciesCollapsed(boolean b) { return null; }
        public Object typedDependenciesCCprocessed(boolean b) { return null; }
        public Object typedDependenciesCollapsedTree() { return null; }
    }

    static class CoreLabel extends Label implements CoreMapLike {
        public static Object factory() { return null; }
        public String tag() { return "NN"; }
        public String word() { return "word"; }
        @SuppressWarnings("unchecked") public <T> T get(Class<?> c) { return (T) Integer.valueOf(1); }
    }

    static class CyclicCoreLabel {
        public static Object factory() { return null; }
    }

    interface CoreMapLike {}
    static class CoreMap implements CoreMapLike {
        @SuppressWarnings("unchecked") public <T> T get(Class<?> c) { return (T) Integer.valueOf(1); }
    }

    static class CoreAnnotations {
        static class IndexAnnotation {}
    }

    interface TreeTransformer { Tree transformTree(Tree t); }

    
    Map<String, Boolean> formats = new HashMap<>();
    boolean removeEmpty = false;
    boolean ptb2text = false;
    Map<String, String> options = new HashMap<>();
    TLP tlp = new TLP();
    static class TLP { public boolean isStartSymbol(String s) { return false; } }
    Object stemmer = null;
    boolean lexicalize = false;
    Object hf = null;
    boolean markHeadNodes = false;
    boolean transChinese = false;
    Object dependencyWordFilter = null;
    Object dependencyFilter = null;
    boolean basicDependencies = true;
    boolean nonCollapsedDependencies = false;
    boolean nonCollapsedDependenciesSeparated = false;
    boolean collapsedDependencies = false;
    boolean CCPropagatedDependencies = false;
    boolean treeDependencies = false;
    String rootLabelOnlyFormat = "rootLabelOnly";
    
    Object gsf = new Object() { 
        public GrammaticalStructure newGrammaticalStructure(Tree t) { return new GrammaticalStructure(); } 
    };

    
    private boolean propertyToBoolean(Map<String, String> m, String k) { return "true".equals(m.get(k)); }
    private Tree getCollocationProcessedTree(Tree t, Object hf) { return t; }
    private Tree markHeadNodes(Tree t) { return t; }
    private void print(Object deps, String fmt, PrintWriter pw) { pw.println("<deps/>"); }
    private void print(Object deps, PrintWriter pw) { pw.println("deps"); }


// ORIGINAL CODESEARCHNET METHOD — START

    private void printTreeInternal(final Tree t, final PrintWriter pw, final boolean inXml) {
        Tree outputTree = t;

        if (formats.containsKey("conll2007") || removeEmpty) {
          outputTree = outputTree.prune(new BobChrisTreeNormalizer.EmptyFilter());
        }

        if (formats.containsKey("words")) {
          if (inXml) {
            ArrayList<Label> sentUnstemmed = outputTree.yield();
            pw.println("  <words>");
            int i = 1;
            for (Label w : sentUnstemmed) {
              pw.println("    <word ind=\"" + i + "\">" + XMLUtils.escapeXML(w.value()) + "</word>");
              i++;
            }
            pw.println("  </words>");
          } else {
            String sent = Sentence.listToString(outputTree.yield(), false);
            if(ptb2text) {
              pw.println(PTBTokenizer.ptb2Text(sent));
            } else {
              pw.println(sent);
              pw.println();
            }
          }
        }

        if (propertyToBoolean(options, "removeTopBracket")) {
          String s = outputTree.label().value();
          if (tlp.isStartSymbol(s)) {
            if (outputTree.isUnaryRewrite()) {
              outputTree = outputTree.firstChild();
            } else {
              
              
              
              System.err.println("TreePrint: can't remove top bracket: not unary");
            }
          }
          
          
          
          
        }
        if (stemmer != null) {
          
        }
        if (lexicalize) {
          outputTree = Trees.lexicalize(outputTree, hf);
          Function<Tree, Tree> a =
            TreeFunctions.getLabeledToDescriptiveCoreLabelTreeFunction();
          outputTree = a.apply(outputTree);
        }

        if (formats.containsKey("collocations")) {
          outputTree = getCollocationProcessedTree(outputTree, hf);
        }

        if (!lexicalize) { 
          Function<Tree, Tree> a =
            TreeFunctions.getLabeledTreeToStringLabeledTreeFunction();
          outputTree = a.apply(outputTree);
        }

        Tree outputPSTree = outputTree;  

        if (markHeadNodes) {
          outputPSTree = markHeadNodes(outputPSTree);
        }

        if (transChinese) {
          TreeTransformer tt = new TreeTransformer() {
            public Tree transformTree(Tree t) {
              t = t.treeSkeletonCopy();
              for (Tree subtree : t) {
                if (subtree.isLeaf()) {
                  Label oldLabel = subtree.label();
                  String translation = ChineseEnglishWordMap.getInstance().getFirstTranslation(oldLabel.value());
                  if (translation == null) translation = "[UNK]";
                  Label newLabel = new StringLabel(oldLabel.value() + ':' + translation);
                  subtree.setLabel(newLabel);
                }
              }
              return t;
            }
          };
          outputPSTree = tt.transformTree(outputPSTree);
        }

        if (propertyToBoolean(options, "xml")) {
          if (formats.containsKey("wordsAndTags")) {
            ArrayList<TaggedWord> sent = outputTree.taggedYield();
            pw.println("  <words pos=\"true\">");
            int i = 1;
            for (TaggedWord tw : sent) {
              pw.println("    <word ind=\"" + i + "\" pos=\"" + XMLUtils.escapeXML(tw.tag()) + "\">" + XMLUtils.escapeXML(tw.word()) + "</word>");
              i++;
            }
            pw.println("  </words>");
          }
          if (formats.containsKey("penn")) {
            pw.println("  <tree style=\"penn\">");
            StringWriter sw = new StringWriter();
            PrintWriter psw = new PrintWriter(sw);
            outputPSTree.pennPrint(psw);
            pw.print(XMLUtils.escapeXML(sw.toString()));
            pw.println("  </tree>");
          }
          if (formats.containsKey("latexTree")) {
            pw.println("    <tree style=\"latexTrees\">");
            pw.println(".[");
            StringWriter sw = new StringWriter();
            PrintWriter psw = new PrintWriter(sw);
            outputTree.indentedListPrint(psw,false);
            pw.print(XMLUtils.escapeXML(sw.toString()));
            pw.println(".]");
            pw.println("  </tree>");
          }
          if (formats.containsKey("dependencies")) {
            Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                     CoreLabel.factory());
            indexedTree.indexLeaves();
            Set<Dependency<Label, Label, Object>> depsSet = indexedTree.mapDependencies(dependencyWordFilter, hf);
            List<Dependency<Label, Label, Object>> sortedDeps = new ArrayList<Dependency<Label, Label, Object>>(depsSet);
            Collections.sort(sortedDeps, Dependencies.dependencyIndexComparator());
            pw.println("<dependencies style=\"untyped\">");
            for (Dependency<Label, Label, Object> d : sortedDeps) {
              pw.println(d.toString("xml"));
            }
            pw.println("</dependencies>");
          }
          if (formats.containsKey("conll2007") || formats.containsKey("conllStyleDependencies")) {
            System.err.println("The \"conll2007\" and \"conllStyleDependencies\" formats are ignored in xml.");
          }
          if (formats.containsKey("typedDependencies")) {
            GrammaticalStructure gs = null; 
            if (basicDependencies) {
              print(gs.typedDependencies(), "xml", pw);
            }
            if (nonCollapsedDependencies || nonCollapsedDependenciesSeparated) {
              print(gs.allTypedDependencies(), "xml", pw);
            }
            if (collapsedDependencies) {
              print(gs.typedDependenciesCollapsed(true), "xml", pw);
            }
            if (CCPropagatedDependencies) {
              print(gs.typedDependenciesCCprocessed(true), "xml", pw);
            }
            if(treeDependencies) {
              print(gs.typedDependenciesCollapsedTree(), "xml", pw);
            }
          }
          if (formats.containsKey("typedDependenciesCollapsed")) {
            GrammaticalStructure gs = null; 
            print(gs.typedDependenciesCCprocessed(true), "xml", pw);
          }

          
          
          
          
          
        } else {
          
          if (formats.containsKey("wordsAndTags")) {
            pw.println(Sentence.listToString(outputTree.taggedYield(), false));
            pw.println();
          }
          if (formats.containsKey("oneline")) {
            pw.println(outputPSTree.toString());
          }
          if (formats.containsKey("penn")) {
            outputPSTree.pennPrint(pw);
            pw.println();
          }
          if (formats.containsKey(rootLabelOnlyFormat)) {
            pw.println(outputTree.label().value());
          }
          if (formats.containsKey("latexTree")) {
            pw.println(".[");
            outputTree.indentedListPrint(pw,false);
            pw.println(".]");
          }
          if (formats.containsKey("dependencies")) {
            
            Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                     CyclicCoreLabel.factory());
            indexedTree.indexLeaves();
            Set<Dependency<Label, Label, Object>> depsSet = indexedTree.mapDependencies(dependencyWordFilter, hf);
            List<Dependency<Label, Label, Object>> sortedDeps = new ArrayList<Dependency<Label, Label, Object>>(depsSet);
            Collections.sort(sortedDeps, Dependencies.dependencyIndexComparator());
            for (Dependency<Label, Label, Object> d : sortedDeps) {
              pw.println(d.toString("predicate"));
            }
            pw.println();
          }
          if (formats.containsKey("conll2007")) {
            
            
            
            
            

            Tree it = outputTree.deepCopy(outputTree.treeFactory(), CoreLabel.factory());
            it.indexLeaves();

            List<CoreLabel> tagged = it.taggedLabeledYield();
            Set<Dependency<Label, Label, Object>> depsSet = it.mapDependencies(dependencyFilter, hf, "root");
            List<Dependency<Label, Label, Object>> sortedDeps = new ArrayList<Dependency<Label, Label, Object>>(depsSet);
            Collections.sort(sortedDeps, Dependencies.dependencyIndexComparator());

            for (int i = 0; i < tagged.size(); i++) {
              CoreLabel w = tagged.get(i);
              Dependency<Label, Label, Object> d = null; 
              CoreMap dep = (CoreMap) d.dependent();
              CoreMap gov = (CoreMap) d.governor();

              Integer depi = dep.get(CoreAnnotations.IndexAnnotation.class);
              Integer govi = gov.get(CoreAnnotations.IndexAnnotation.class);

              
              String tag = PTBTokenizer.ptbToken2Text(w.tag());

              String word = PTBTokenizer.ptbToken2Text(w.word());
              String lemma = "_";
              String feats = "_";
              String pHead = "_";
              String pDepRel = "_";
              String depRel = (govi == 0) ? "ROOT" : "NULL";

              
              pw.printf("%d\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\t%s%n", depi,word,lemma,tag,tag,feats,govi,depRel,pHead,pDepRel);
            }
            pw.println();
          }
          if (formats.containsKey("conllStyleDependencies")) {
            
            BobChrisTreeNormalizer tn = new BobChrisTreeNormalizer();
            Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                     CoreLabel.factory());
            
            for (Tree node : indexedTree) {
              if (node.label().value().startsWith("NML")) {
                ((StringLabel)node.label()).v = "NP";
              }
            }

            indexedTree = tn.normalizeWholeTree(indexedTree, outputTree.treeFactory());
            indexedTree.indexLeaves();
            Set<Dependency<Label, Label, Object>> depsSet = null;
            boolean failed = false;
            try {
              depsSet = indexedTree.mapDependencies(dependencyFilter, hf);
            } catch (Exception e) {
              failed = true;
            }
            if (failed) {
              System.err.println("failed: ");
              System.err.println(t);
              System.err.println();
            } else {
              Map<Integer,Integer> deps = new HashMap<Integer, Integer>();
              for (Dependency<Label, Label, Object> dep : depsSet) {
                CoreLabel child = (CoreLabel)dep.dependent();
                CoreLabel parent = (CoreLabel)dep.governor();
                Integer childIndex =
                  child.get(CoreAnnotations.IndexAnnotation.class);
                Integer parentIndex =
                  parent.get(CoreAnnotations.IndexAnnotation.class);

                deps.put(childIndex, parentIndex);
              }
              boolean foundRoot = false;
              int index = 1;
              for (Tree node : indexedTree.getLeaves()) {
                String word = node.label().value();
                String tag = node.parent(indexedTree).label().value();
                int parent = 0;
                if (deps.containsKey(index)) {
                  parent = deps.get(index);
                } else {
                  if (foundRoot) { throw new RuntimeException(); }
                  foundRoot = true;
                }
                pw.println(index+"\t"+word+"\t"+tag+"\t"+parent);
                index++;
              }
              pw.println();
            }
          }
          if (formats.containsKey("typedDependencies")) {
            GrammaticalStructure gs = null; 
            if (basicDependencies) {
              print(gs.typedDependencies(), pw);
            }
            if (nonCollapsedDependencies) {
              print(gs.allTypedDependencies(), pw);
            }
            if (nonCollapsedDependenciesSeparated) {
              print(gs.allTypedDependencies(), "separator", pw);
            }
            if (collapsedDependencies) {
              print(gs.typedDependenciesCollapsed(true), pw);
            }
            if (CCPropagatedDependencies) {
              print(gs.typedDependenciesCCprocessed(true), pw);
            }
            if (treeDependencies) {
              print(gs.typedDependenciesCollapsedTree(), pw);
            }
          }
          if (formats.containsKey("typedDependenciesCollapsed")) {
            GrammaticalStructure gs = null; 
            print(gs.typedDependenciesCCprocessed(true), pw);
          }
          
          
          
          
          
        }

        
        pw.flush();
      }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        method_2_lvt_gemini engine = new method_2_lvt_gemini();
        engine.formats.put("penn", true);
        engine.formats.put("words", true);
        
        PrintWriter pw = new PrintWriter(System.out);
        Tree mockTree = new Tree();
        
        engine.printTreeInternal(mockTree, pw, true); 
    }
}