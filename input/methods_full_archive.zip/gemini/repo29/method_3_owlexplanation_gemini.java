




import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


interface OWLAxiom {
    boolean isLogicalAxiom();
}

interface OWLClass extends OWLClassExpression {
    String getName();
}

class MockOWLClass implements OWLClass {
    private String name;
    public MockOWLClass(String name) { this.name = name; }
    public String getName() { return name; }
    @Override
    public String toString() { return "Class(" + name + ")"; }
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof MockOWLClass) return name.equals(((MockOWLClass) obj).name);
        return false;
    }
    @Override
    public int hashCode() { return name.hashCode(); }
}

interface OWLNothing extends OWLClass {}

class MockOWLNothing implements OWLNothing {
    public String getName() { return "Nothing"; }
    @Override
    public String toString() { return "Nothing"; }
}

interface OWLDataFactory {
    OWLAxiom getOWLSubClassOfAxiom(OWLClass sub, OWLClassExpression sup);
    OWLNothing getOWLNothing();
}

interface OWLClassExpression {}

class MockOWLDataFactory implements OWLDataFactory {
    public OWLAxiom getOWLSubClassOfAxiom(OWLClass sub, OWLClassExpression sup) {
        return new MockSubClassOfAxiom(sub, sup);
    }
    public OWLNothing getOWLNothing() { return new MockOWLNothing(); }
}

class MockSubClassOfAxiom implements OWLAxiom {
    private OWLClass sub;
    private OWLClassExpression sup;
    public MockSubClassOfAxiom(OWLClass sub, OWLClassExpression sup) {
        this.sub = sub;
        this.sup = sup;
    }
    public boolean isLogicalAxiom() { return true; }
    @Override
    public String toString() { return "SubClassOf(" + sub + " -> " + sup + ")"; }
}

interface OWLOntologyManager {
    OWLDataFactory getOWLDataFactory();
}

class MockOWLOntologyManager implements OWLOntologyManager {
    private OWLDataFactory df = new MockOWLDataFactory();
    public OWLDataFactory getOWLDataFactory() { return df; }
}

interface OWLOntology {
    Set<OWLAxiom> getLogicalAxioms();
    Set<OWLOntology> getImportsClosure();
}

class MockOWLOntology implements OWLOntology {
    private Set<OWLAxiom> axioms = new HashSet<OWLAxiom>();
    public void addAxiom(OWLAxiom ax) { axioms.add(ax); }
    public Set<OWLAxiom> getLogicalAxioms() { return axioms; }
    public Set<OWLOntology> getImportsClosure() {
        return Collections.<OWLOntology>singleton(this);
    }
}

interface OWLReasoner {
    OWLOntology getRootOntology();
}

class MockOWLReasoner implements OWLReasoner {
    private OWLOntology rootOntology;
    public MockOWLReasoner(OWLOntology rootOntology) { this.rootOntology = rootOntology; }
    public OWLOntology getRootOntology() { return rootOntology; }
}

interface ReasonerFactory {}

class Explanation<E> {
    private E entailment;
    private Set<OWLAxiom> axioms;

    public Explanation(E entailment, Set<OWLAxiom> axioms) {
        this.entailment = entailment;
        this.axioms = axioms;
    }
    public E getEntailment() { return entailment; }
    public Set<OWLAxiom> getAxioms() { return axioms; }
}

interface ExplanationGenerator<E> {
    Set<Explanation<E>> getExplanations(E entailment);
}

interface ExplanationGeneratorFactory<E> {
    ExplanationGenerator<E> createExplanationGenerator(Set<OWLAxiom> axioms);
}

class ExplanationManager {
    public static ExplanationGeneratorFactory<OWLAxiom> createExplanationGeneratorFactory(ReasonerFactory factory) {
        return new ExplanationGeneratorFactory<OWLAxiom>() {
            public ExplanationGenerator<OWLAxiom> createExplanationGenerator(Set<OWLAxiom> axioms) {
                return new ExplanationGenerator<OWLAxiom>() {
                    public Set<Explanation<OWLAxiom>> getExplanations(OWLAxiom entailment) {
                        Set<Explanation<OWLAxiom>> set = new HashSet<Explanation<OWLAxiom>>();
                        set.add(new Explanation<OWLAxiom>(entailment, axioms));
                        return set;
                    }
                };
            }
        };
    }
}

class StructuralRootDerivedReasoner {
    public StructuralRootDerivedReasoner(OWLOntologyManager man, OWLReasoner reasoner, ReasonerFactory factory) {}
    public Set<OWLClass> getRootUnsatisfiableClasses() {
        Set<OWLClass> roots = new HashSet<OWLClass>();
        roots.add(new MockOWLClass("ClassA"));
        roots.add(new MockOWLClass("ClassB"));
        return roots;
    }
}

class ExplanationException extends Exception {
    public ExplanationException(String msg) { super(msg); }
}

public class method_3_owlexplanation_gemini {

    protected OWLOntologyManager manager = new MockOWLOntologyManager();
    protected OWLReasoner baseReasoner = new MockOWLReasoner(new MockOWLOntology());
    protected ReasonerFactory reasonerFactory = new ReasonerFactory() {};
    protected Map<OWLClass, Set<Explanation<OWLAxiom>>> cls2JustificationMap = new HashMap<OWLClass, Set<Explanation<OWLAxiom>>>();
    protected Set<OWLClass> roots = new HashSet<OWLClass>();

    protected boolean isRootFor(Explanation<OWLAxiom> explA, Explanation<OWLAxiom> explB) {
        return false; 
    }


// ORIGINAL CODESEARCHNET METHOD — START

public Set<OWLClass> getRootUnsatisfiableClasses() throws ExplanationException {
        StructuralRootDerivedReasoner srd = new StructuralRootDerivedReasoner(manager, baseReasoner, reasonerFactory);
        Set<OWLClass> estimatedRoots = srd.getRootUnsatisfiableClasses();
        cls2JustificationMap = new HashMap<OWLClass, Set<Explanation<OWLAxiom>>>();
        Set<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
        for (OWLOntology ont : baseReasoner.getRootOntology().getImportsClosure()) {
            allAxioms.addAll(ont.getLogicalAxioms());
        }

        for (OWLClass cls : estimatedRoots) {
            cls2JustificationMap.put(cls, new HashSet<Explanation<OWLAxiom>>());
            System.out.println("POTENTIAL ROOT: " + cls);
        }
        System.out.println("Finding real roots from " + estimatedRoots.size() + " estimated roots");

        int done = 0;
        roots.addAll(estimatedRoots);
        for (final OWLClass estimatedRoot : estimatedRoots) {
            ExplanationGeneratorFactory<OWLAxiom> genFac = ExplanationManager.createExplanationGeneratorFactory(reasonerFactory);
            ExplanationGenerator<OWLAxiom> gen = genFac.createExplanationGenerator(allAxioms);
            OWLDataFactory df = manager.getOWLDataFactory();
            Set<Explanation<OWLAxiom>> expls = gen.getExplanations(df.getOWLSubClassOfAxiom(estimatedRoot, df.getOWLNothing()));
            cls2JustificationMap.get(estimatedRoot).addAll(expls);
            done++;
            System.out.println("Done " + done);
        }
        for(OWLClass clsA : estimatedRoots) {
            for(OWLClass clsB : estimatedRoots) {
                if (!clsA.equals(clsB)) {
                    Set<Explanation<OWLAxiom>> clsAExpls = cls2JustificationMap.get(clsA);
                    Set<Explanation<OWLAxiom>> clsBExpls = cls2JustificationMap.get(clsB);
                    boolean clsARootForClsB = false;
                    boolean clsBRootForClsA = false;
                    
                    for(Explanation<OWLAxiom> clsAExpl : clsAExpls) {
                        for(Explanation<OWLAxiom> clsBExpl : clsBExpls) {
                            if(isRootFor(clsAExpl, clsBExpl)) {
                                
                                clsARootForClsB = true;

                            }
                            else if(isRootFor(clsBExpl, clsAExpl)) {
                                
                                clsBRootForClsA = true;

                            }
                        }
                    }
                    if (!clsARootForClsB || !clsBRootForClsA) {
                        if(clsARootForClsB) {
                            roots.remove(clsB);
                        }
                        else if(clsBRootForClsA) {
                            roots.remove(clsA);
                        }
                    }
                }
            }
        }
        return roots;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting CompleteRootDerivedReasoner.getRootUnsatisfiableClasses Simulation...\n");

        method_3_owlexplanation_gemini reasoner = new method_3_owlexplanation_gemini();
        
        System.out.println("--- Invoking getRootUnsatisfiableClasses ---");
        try {
            Set<OWLClass> rootClasses = reasoner.getRootUnsatisfiableClasses();
            System.out.println("\nRoot Unsatisfiable Classes Computed Successfully!");
            System.out.println(" -> Real Roots Found: " + rootClasses);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}