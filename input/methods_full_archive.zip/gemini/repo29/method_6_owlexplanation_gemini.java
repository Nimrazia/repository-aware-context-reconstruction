




import java.util.Collections;
import java.util.HashSet;
import java.util.Set;


interface OWLAxiom {}

class MockAxiom implements OWLAxiom {
    private String name;
    public MockAxiom(String name) { this.name = name; }
    @Override
    public String toString() { return "Axiom(" + name + ")"; }
}

class Explanation<E> {
    private E entailment;
    private Set<OWLAxiom> axioms;

    public Explanation(E entailment, Set<OWLAxiom> axioms) {
        this.entailment = entailment;
        this.axioms = axioms;
    }

    public E getEntailment() { return entailment; }
    public Set<OWLAxiom> getAxioms() { return axioms; }
}

interface ExplanationGenerator<E> {
    Set<Explanation<E>> getExplanations(E entailment);
}

interface ExplanationGeneratorFactory<E> {
    ExplanationGenerator<E> createExplanationGenerator(Set<OWLAxiom> axioms, Object monitor);
}

class ExplanationGeneratorInterruptedException extends RuntimeException {}

interface OWLOntology {
    Set<OWLAxiom> getLogicalAxioms();
}

class MockOWLOntology implements OWLOntology {
    private Set<OWLAxiom> axioms = new HashSet<OWLAxiom>();
    public void addAxiom(OWLAxiom ax) { axioms.add(ax); }
    public Set<OWLAxiom> getLogicalAxioms() { return axioms; }
}

public class method_6_owlexplanation_gemini<E> {

    protected int limit;
    protected Set<Explanation<E>> foundLaconicJustifications = new HashSet<Explanation<E>>();
    protected ExplanationGeneratorFactory<E> explanationGeneratorFactory;
    protected Set<OWLAxiom> axioms = new HashSet<OWLAxiom>();
    protected Set<Explanation<E>> lastRegularJusts = new HashSet<Explanation<E>>();
    protected Set<Explanation<E>> allPreviouslyFoundJustifications;
    protected OWLOntology ont = new MockOWLOntology();

    public method_6_owlexplanation_gemini() {
        this.explanationGeneratorFactory = new ExplanationGeneratorFactory<E>() {
            public ExplanationGenerator<E> createExplanationGenerator(Set<OWLAxiom> ax, Object monitor) {
                return new ExplanationGenerator<E>() {
                    public Set<Explanation<E>> getExplanations(E entailment) {
                        Set<Explanation<E>> expls = new HashSet<Explanation<E>>();
                        expls.add(new Explanation<E>(entailment, ax));
                        return expls;
                    }
                };
            }
        };
    }

    protected boolean isCancelled() {
        return false;
    }

    protected Set<OWLAxiom> computeOPlus(Set<OWLAxiom> axioms) {
        return axioms; 
    }

    protected Set<Explanation<E>> getReconstitutedLaconicJustifications() {
        return foundLaconicJustifications;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public Set<Explanation<E>> computePreciseJustsOptimised(E entailment, int limit) throws Exception {
        this.limit = limit;
        foundLaconicJustifications.clear();
        ExplanationGenerator<E> gen = explanationGeneratorFactory.createExplanationGenerator(axioms, this);
        Set<Explanation<E>> regularJusts = null;
        try {
            regularJusts = gen.getExplanations(entailment);
        }
        catch (ExplanationGeneratorInterruptedException e) {
            
            return foundLaconicJustifications;
        }
        if (isCancelled()) {
            return foundLaconicJustifications;
        }
        lastRegularJusts.clear();

        
        allPreviouslyFoundJustifications = new HashSet<Explanation<E>>();
        allPreviouslyFoundJustifications.addAll(regularJusts);




        Set<OWLAxiom> axiomsInPreviousOntology = new HashSet<OWLAxiom>();

        
        while (true) {

            if (isCancelled()) {
                return getReconstitutedLaconicJustifications();
            }
            
            

            Set<OWLAxiom> unionOfAllJustifications = new HashSet<OWLAxiom>();
            for (Explanation<E> exp : allPreviouslyFoundJustifications) {
                unionOfAllJustifications.addAll(exp.getAxioms());
            }
            Set<OWLAxiom> oPlus = computeOPlus(unionOfAllJustifications);

            
            Set<OWLAxiom> augmentedAxioms = new HashSet<OWLAxiom>(oPlus);

            
            
            

            
            
            
            
            
            
            
            
            for (OWLAxiom ax : ont.getLogicalAxioms()) {
                
                
                if (unionOfAllJustifications.contains(ax) && !oPlus.contains(ax)) {
                    continue;
                }
                augmentedAxioms.add(ax);
            }

            
            

            


            if (augmentedAxioms.equals(axiomsInPreviousOntology)) {
                break;
            }

            ExplanationGenerator<E> gen2 = explanationGeneratorFactory.createExplanationGenerator(augmentedAxioms, this);

            axiomsInPreviousOntology.clear();
            axiomsInPreviousOntology.addAll(augmentedAxioms);

            Set<Explanation> allPrevJustsCopy = new HashSet<Explanation>(allPreviouslyFoundJustifications);

            
            Set<Explanation<E>> currentJustifications = null;
            try {
                currentJustifications = gen2.getExplanations(entailment);
            }
            catch (ExplanationGeneratorInterruptedException e) {
                return getReconstitutedLaconicJustifications();
            }
            if (isCancelled()) {
                return getReconstitutedLaconicJustifications();
            }
            allPreviouslyFoundJustifications.addAll(currentJustifications);
            if (allPreviouslyFoundJustifications.equals(allPrevJustsCopy)) {
                break;
            }
            
            

















        }


















        return getReconstitutedLaconicJustifications();
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting LaconicExplanationGenerator.computePreciseJustsOptimised Simulation...\n");

        method_6_owlexplanation_gemini<String> generator = new method_6_owlexplanation_gemini<String>();
        OWLAxiom ax = new MockAxiom("TestAxiom");
        generator.axioms.add(ax);
        ((MockOWLOntology) generator.ont).addAxiom(ax);

        System.out.println("--- Invoking computePreciseJustsOptimised ---");
        try {
            Set<Explanation<String>> results = generator.computePreciseJustsOptimised("TestEntailment", 5);
            System.out.println("\nPrecise Justifications Computed Successfully!");
            System.out.println(" -> Result Explanations Count: " + results.size());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}