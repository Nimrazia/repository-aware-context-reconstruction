




import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


interface OWLAxiom {}

interface OWLClassExpression {
    boolean isAnonymous();
    OWLClass asOWLClass();
}

interface OWLClass extends OWLClassExpression {
    String getName();
}

class MockOWLClass implements OWLClass {
    private String name;
    public MockOWLClass(String name) { this.name = name; }
    public boolean isAnonymous() { return false; }
    public OWLClass asOWLClass() { return this; }
    public String getName() { return name; }
    @Override
    public String toString() { return "Class(" + name + ")"; }
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof MockOWLClass) return name.equals(((MockOWLClass) obj).name);
        return false;
    }
    @Override
    public int hashCode() { return name.hashCode(); }
}

interface OWLSubClassOfAxiom extends OWLAxiom {
    OWLClassExpression getSubClass();
    OWLClassExpression getSuperClass();
}

class MockOWLSubClassOfAxiom implements OWLSubClassOfAxiom {
    private OWLClassExpression subClass;
    private OWLClassExpression superClass;

    public MockOWLSubClassOfAxiom(OWLClassExpression subClass, OWLClassExpression superClass) {
        this.subClass = subClass;
        this.superClass = superClass;
    }

    public OWLClassExpression getSubClass() { return subClass; }
    public OWLClassExpression getSuperClass() { return superClass; }
    @Override
    public String toString() { return "SubClassOf(" + subClass + " -> " + superClass + ")"; }
}

interface OWLObjectIntersectionOf extends OWLClassExpression {}

class MockOWLObjectIntersectionOf implements OWLObjectIntersectionOf {
    private Set<OWLClassExpression> operands;
    public MockOWLObjectIntersectionOf(Set<OWLClassExpression> operands) { this.operands = operands; }
    public boolean isAnonymous() { return true; }
    public OWLClass asOWLClass() { return null; }
    @Override
    public String toString() { return "IntersectionOf(" + operands + ")"; }
}

interface OWLDataFactory {
    OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClassExpression sub, OWLClassExpression sup);
    OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression> operands);
}

class MockOWLDataFactory implements OWLDataFactory {
    public OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClassExpression sub, OWLClassExpression sup) {
        return new MockOWLSubClassOfAxiom(sub, sup);
    }
    public OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression> operands) {
        return new MockOWLObjectIntersectionOf(operands);
    }
}

interface OWLOntologyManager {
    OWLDataFactory getOWLDataFactory();
}

class MockOWLOntologyManager implements OWLOntologyManager {
    private OWLDataFactory dataFactory = new MockOWLDataFactory();
    public OWLDataFactory getOWLDataFactory() { return dataFactory; }
}

interface OWLOntology {
    boolean containsAxiom(OWLAxiom axiom);
}

class MockOWLOntology implements OWLOntology {
    private Set<OWLAxiom> ontologyAxioms = new HashSet<OWLAxiom>();
    public void addAxiom(OWLAxiom ax) { ontologyAxioms.add(ax); }
    public boolean containsAxiom(OWLAxiom axiom) { return ontologyAxioms.contains(axiom); }
}

class Explanation<E> {
    private E entailment;
    private Set<OWLAxiom> axioms;

    public Explanation(E entailment, Set<OWLAxiom> axioms) {
        this.entailment = entailment;
        this.axioms = axioms;
    }

    public E getEntailment() { return entailment; }
    public Set<OWLAxiom> getAxioms() { return axioms; }
}

public class method_2_owlexplanation_gemini<E> {

    protected Set<Explanation<E>> allPreviouslyFoundJustifications = new HashSet<Explanation<E>>();
    protected Set<Explanation<E>> foundLaconicJustifications = new HashSet<Explanation<E>>();
    protected OWLOntology ont = new MockOWLOntology();
    protected OWLOntologyManager man = new MockOWLOntologyManager();

    protected Set<OWLAxiom> computeOPlus(Set<OWLAxiom> axioms) {
        return axioms; 
    }


// ORIGINAL CODESEARCHNET METHOD — START

private Set<Explanation<E>> getReconstitutedLaconicJustifications() {
        

        
        
        
        
        Map<OWLAxiom, Set<OWLAxiom>> sourceAxioms2OPlus = new HashMap<OWLAxiom, Set<OWLAxiom>>();

        for (Explanation<E> exp : allPreviouslyFoundJustifications) {
            for (OWLAxiom ax : exp.getAxioms()) {
                if (ont.containsAxiom(ax)) {
                    sourceAxioms2OPlus.put(ax, computeOPlus(Collections.singleton(ax)));
                }
            }
        }

        Set<Explanation<E>> reconstituedExplanations = new HashSet<Explanation<E>>();
        for (Explanation<E> laconicExp : foundLaconicJustifications) {
            
            Map<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>> lhs2SubClassAxiom = new HashMap<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>>();

            Set<OWLAxiom> reconstituedAxioms = new HashSet<OWLAxiom>();
            for (OWLAxiom laconicAx : laconicExp.getAxioms()) {
                if (laconicAx instanceof OWLSubClassOfAxiom) {
                    OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) laconicAx;
                    if (sca.getSubClass().isAnonymous()) {
                        
                        reconstituedAxioms.add(sca);
                        continue;
                    }
                    Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2AxiomMap = lhs2SubClassAxiom.get(sca.getSubClass().asOWLClass());
                    if (source2AxiomMap == null) {
                        source2AxiomMap = new HashMap<OWLAxiom, Set<OWLSubClassOfAxiom>>();
                        lhs2SubClassAxiom.put(sca.getSubClass().asOWLClass(), source2AxiomMap);
                    }
                    for (OWLAxiom sourceAx : sourceAxioms2OPlus.keySet()) {
                        if (sourceAxioms2OPlus.get(sourceAx).contains(sca)) {
                            Set<OWLSubClassOfAxiom> subClassAxioms = source2AxiomMap.get(sourceAx);
                            if (subClassAxioms == null) {
                                subClassAxioms = new HashSet<OWLSubClassOfAxiom>();
                                source2AxiomMap.put(sourceAx, subClassAxioms);
                            }
                            subClassAxioms.add(sca);
                        }
                    }
                }
                else {
                    reconstituedAxioms.add(laconicAx);
                }
            }
            
            Set<OWLSubClassOfAxiom> consumedAxioms = new HashSet<OWLSubClassOfAxiom>();
            for (OWLClass lhs : lhs2SubClassAxiom.keySet()) {
                Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2SubClassAxiom = lhs2SubClassAxiom.get(lhs);
                for (OWLAxiom source : source2SubClassAxiom.keySet()) {
                    Set<OWLClassExpression> rightHandSides = new HashSet<OWLClassExpression>();
                    for (OWLSubClassOfAxiom subClassAx : source2SubClassAxiom.get(source)) {
                        if (!consumedAxioms.contains(subClassAx)) {
                            rightHandSides.add(subClassAx.getSuperClass());
                            consumedAxioms.add(subClassAx);
                        }
                    }
                    if (rightHandSides.size() == 1) {
                        reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, rightHandSides.iterator().next()));
                    }
                    else if (rightHandSides.size() > 1) {
                        OWLObjectIntersectionOf conjunction = man.getOWLDataFactory().getOWLObjectIntersectionOf(rightHandSides);
                        reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, conjunction));
                    }
                }
            }
            Explanation<E> explanation = new Explanation<E>(laconicExp.getEntailment(), reconstituedAxioms);
            reconstituedExplanations.add(explanation);

        }
        return reconstituedExplanations;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting LaconicExplanationGenerator.getReconstitutedLaconicJustifications Simulation...\n");

        method_2_owlexplanation_gemini<String> generator = new method_2_owlexplanation_gemini<String>();

        OWLClass clsA = new MockOWLClass("A");
        OWLClass clsB = new MockOWLClass("B");
        OWLClass clsC = new MockOWLClass("C");

        OWLAxiom sourceAx = new MockOWLSubClassOfAxiom(clsA, clsB);
        ((MockOWLOntology) generator.ont).addAxiom(sourceAx);

        Set<OWLAxiom> prevAxioms = new HashSet<OWLAxiom>();
        prevAxioms.add(sourceAx);
        generator.allPreviouslyFoundJustifications.add(new Explanation<String>("entailment-1", prevAxioms));

        Set<OWLAxiom> laconicAxioms = new HashSet<OWLAxiom>();
        laconicAxioms.add(new MockOWLSubClassOfAxiom(clsA, clsB));
        laconicAxioms.add(new MockOWLSubClassOfAxiom(clsA, clsC));
        generator.foundLaconicJustifications.add(new Explanation<String>("entailment-1", laconicAxioms));

        System.out.println("--- Invoking getReconstitutedLaconicJustifications ---");
        Set<Explanation<String>> results = generator.getReconstitutedLaconicJustifications();

        System.out.println("\nReconstitution Completed Successfully!");
        System.out.println(" -> Result Explanations Count: " + results.size());
        for (Explanation<String> exp : results) {
            System.out.println(" -> Reconstituted Axioms: " + exp.getAxioms());
        }

        System.out.println("\nExecution Complete.");
    }
}