import java.math.BigDecimal;
import java.util.Date;





public class method_1_isis_module_excel_gemini {

    
    public @interface Action {
        SemanticsOf semantics();
        InvokeOn invokeOn();
    }

    public enum SemanticsOf { IDEMPOTENT }
    public enum InvokeOn { OBJECT_AND_COLLECTION }

    
    public static class Container {
        public void warnUser(String message) {
            System.out.println("[WARNING] " + message);
        }
    }

    public static class ActionInvocationContext {
        public InvokedOn getInvokedOn() { return new InvokedOn(); }
        public static class InvokedOn {
            public boolean isCollection() { return false; }
        }
    }

    public static class ExcelModuleDemoToDoItem {
        private String description;
        private String category;
        private String subcategory;
        private Date dueBy;
        private BigDecimal cost;
        private String notes;
        private String ownedBy;
        private boolean complete;

        public void setDescription(String description) { this.description = description; }
        public void setCategory(String category) { this.category = category; }
        public void setSubcategory(String subcategory) { this.subcategory = subcategory; }
        public void setDueBy(Date dueBy) { this.dueBy = dueBy; }
        public void setCost(BigDecimal cost) { this.cost = cost; }
        public void setNotes(String notes) { this.notes = notes; }
        public void setOwnedBy(String ownedBy) { this.ownedBy = ownedBy; }
        public void setComplete(boolean complete) { this.complete = complete; }

        @Override
        public String toString() {
            return "ExcelModuleDemoToDoItem{description='" + description + "'}";
        }
    }

    public static class ToDoItems {
        public ExcelModuleDemoToDoItem findByDescription(String description) {
            
            if ("existing_task".equals(description)) {
                ExcelModuleDemoToDoItem item = new ExcelModuleDemoToDoItem();
                item.setDescription(description);
                return item;
            }
            return null;
        }

        public ExcelModuleDemoToDoItem newToDo(String description, String category, String subcategory, Date dueBy, BigDecimal cost) {
            ExcelModuleDemoToDoItem item = new ExcelModuleDemoToDoItem();
            item.setDescription(description);
            item.setCategory(category);
            item.setSubcategory(subcategory);
            item.setDueBy(dueBy);
            item.setCost(cost);
            return item;
        }
    }

    
    private ExcelModuleDemoToDoItem toDoItem;
    private String description;
    private String category;
    private String subcategory;
    private Date dueBy;
    private BigDecimal cost;
    private String notes;
    private String ownedBy;
    private boolean complete;

    private ToDoItems toDoItems = new ToDoItems();
    private Container container = new Container();
    private ActionInvocationContext actionInvocationContext = new ActionInvocationContext();

    public ExcelModuleDemoToDoItem getToDoItem() { return toDoItem; }
    public void setToDoItem(ExcelModuleDemoToDoItem item) { this.toDoItem = item; }
    public String getDescription() { return description; }
    public void setDescription(String desc) { this.description = desc; }
    public String getCategory() { return category; }
    public String getSubcategory() { return subcategory; }
    public Date getDueBy() { return dueBy; }
    public BigDecimal getCost() { return cost; }
    public String getNotes() { return notes; }
    public String getOwnedBy() { return ownedBy; }
    public boolean isComplete() { return complete; }
    public Container getContainer() { return container; }


// ORIGINAL CODESEARCHNET METHOD — START

    @Action(
            semantics = SemanticsOf.IDEMPOTENT,
            invokeOn = InvokeOn.OBJECT_AND_COLLECTION
    )
    public ExcelModuleDemoToDoItem apply() {
        ExcelModuleDemoToDoItem item = getToDoItem();
        if(item == null) {
            
            item = toDoItems.findByDescription(getDescription());
            if(item != null) {
                getContainer().warnUser("Item already exists with description '" + getDescription() + "'");
            } else {
                
                
                item = toDoItems.newToDo(getDescription(), getCategory(), getSubcategory(), getDueBy(), getCost());
                item.setNotes(getNotes());
                item.setOwnedBy(getOwnedBy());
                item.setComplete(isComplete());
            }
        } else {
            
            
            item.setDescription(getDescription());
            item.setCategory(getCategory());
            item.setSubcategory(getSubcategory());
            item.setDueBy(getDueBy());
            item.setCost(getCost());
            item.setNotes(getNotes());
            item.setOwnedBy(getOwnedBy());
            item.setComplete(isComplete());
        }
        return actionInvocationContext.getInvokedOn().isCollection()? null: item;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println("  Method 1 Execution - BulkUpdate Apply");
        System.out.println("=========================================\n");

        method_1_isis_module_excel_gemini lineItem = new method_1_isis_module_excel_gemini();
        
        
        lineItem.setDescription("new_task");
        ExcelModuleDemoToDoItem resultA = lineItem.apply();
        System.out.println("[SUCCESS] Scenario A (New Item)    -> Created: " + resultA);

        
        lineItem.setDescription("existing_task");
        ExcelModuleDemoToDoItem resultB = lineItem.apply();
        System.out.println("[SUCCESS] Scenario B (Conflict)    -> Retrieved: " + resultB);

        
        lineItem.setToDoItem(new ExcelModuleDemoToDoItem());
        lineItem.setDescription("updated_task");
        ExcelModuleDemoToDoItem resultC = lineItem.apply();
        System.out.println("[SUCCESS] Scenario C (Update Item) -> Updated: " + resultC);

        System.out.println("\n=========================================");
    }
}