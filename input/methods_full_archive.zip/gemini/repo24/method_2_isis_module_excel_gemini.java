import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;





public class method_2_isis_module_excel_gemini {

    
    public @interface Nullable {}

    
    public interface Function<F, T> {
        T apply(F input);
    }

    public static class ImmutableSet<E> implements Iterable<E> {
        private final Set<E> elements;
        public ImmutableSet(Set<E> elements) { this.elements = elements; }
        public int size() { return elements.size(); }
        @Override public java.util.Iterator<E> iterator() { return elements.iterator(); }
    }

    public static class FluentIterable<E> {
        private final Iterable<E> iterable;
        private FluentIterable(Iterable<E> iterable) { this.iterable = iterable; }
        
        public static <E> FluentIterable<E> from(Iterable<E> iterable) {
            return new FluentIterable<>(iterable);
        }
        
        public <T> FluentIterable<T> transform(Function<? super E, T> function) {
            List<T> list = new ArrayList<>();
            for (E e : iterable) {
                list.add(function.apply(e));
            }
            return new FluentIterable<>(list);
        }
        
        public ImmutableSet<E> toSet() {
            Set<E> set = new HashSet<>();
            for (E e : iterable) {
                set.add(e);
            }
            return new ImmutableSet<>(set);
        }
    }

    
    public static class XSSFWorkbook {
        public void write(FileOutputStream fos) throws IOException {
            fos.write("mock_excel_data".getBytes());
        }
    }

    
    public static class WorksheetSpec {
        private String sheetName;
        private Object factory;
        public WorksheetSpec(String sheetName) { this.sheetName = sheetName; }
        public String getSheetName() { return sheetName; }
        public Object getFactory() { return factory; }
    }

    public static class WorksheetContent {
        private WorksheetSpec spec;
        private List<Object> domainObjects = new ArrayList<>();
        public WorksheetContent(WorksheetSpec spec) { this.spec = spec; }
        public WorksheetSpec getSpec() { return spec; }
        public List<Object> getDomainObjects() { return domainObjects; }
    }

    
    private static final String XLSX_SUFFIX = ".xlsx";

    
    private void appendSheet(XSSFWorkbook workbook, List<Object> domainObjects, Object factory, String sheetName) {
        System.out.println("   -> Sub-method appendSheet() called for sheet: " + sheetName);
    }

    
    public static class ExcelConverter {}


// ORIGINAL CODESEARCHNET METHOD — START

    File appendSheet(final List<WorksheetContent> worksheetContents) throws IOException {
        final ImmutableSet<String> worksheetNames = FluentIterable.from(worksheetContents)
                .transform(new Function<WorksheetContent, String>() {
                    @Nullable @Override public String apply(@Nullable final WorksheetContent worksheetContent) {
                        return worksheetContent.getSpec().getSheetName();
                    }
                }).toSet();
        if(worksheetNames.size() < worksheetContents.size()) {
            throw new IllegalArgumentException("Sheet names must have distinct names");
        }
        for (final String worksheetName : worksheetNames) {
            if(worksheetName.length() > 30) {
                throw new IllegalArgumentException(
                        String.format("Sheet name cannot exceed 30 characters (invalid name: '%s')",
                                worksheetName));
            }
        }

        final XSSFWorkbook workbook = new XSSFWorkbook();
        final File tempFile =
                File.createTempFile(ExcelConverter.class.getName(), UUID.randomUUID().toString() + XLSX_SUFFIX);
        final FileOutputStream fos = new FileOutputStream(tempFile);

        for (WorksheetContent worksheetContent : worksheetContents) {
            final WorksheetSpec spec = worksheetContent.getSpec();
            appendSheet(workbook, worksheetContent.getDomainObjects(), spec.getFactory(), spec.getSheetName());
        }
        workbook.write(fos);
        fos.close();
        return tempFile;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println("  Method 2 Execution - appendSheet");
        System.out.println("=========================================\n");

        method_2_isis_module_excel_gemini converter = new method_2_isis_module_excel_gemini();

        List<WorksheetContent> contents = new ArrayList<>();
        contents.add(new WorksheetContent(new WorksheetSpec("Tasks_Q1")));
        contents.add(new WorksheetContent(new WorksheetSpec("Tasks_Q2")));

        try {
            File outputFile = converter.appendSheet(contents);
            System.out.println("[SUCCESS] Excel sheets appended successfully.");
            System.out.println("Output temp file: " + outputFile.getAbsolutePath());
            outputFile.deleteOnExit(); 
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        System.out.println("\n--- Testing validation (Duplicates) ---");
        contents.add(new WorksheetContent(new WorksheetSpec("Tasks_Q1"))); 
        try {
            converter.appendSheet(contents);
        } catch (IllegalArgumentException e) {
            System.out.println("[SUCCESS] Expected exception caught: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("[ERROR] Unexpected I/O error: " + e.getMessage());
        }

        System.out.println("\n=========================================");
    }
}