import java.util.ArrayList;
import java.util.Collection;


public class method_3_metacsp_gemini {

    
    static class DirectedSparseMultigraph<V, E> {
        private int vertices = 0;
        private int edges = 0;
        public void addVertex(V v) { vertices++; }
        public void addEdge(E e, V v1, V v2) { edges++; }
        public int getEdgeCount() { return edges; }
        public int getVertexCount() { return vertices; }
    }

    
    interface Variable {}
    interface Constraint {}

    static class ConstraintNetwork {
        private Constraint[] constraints;
        public ConstraintNetwork(Constraint[] c) { this.constraints = c; }
        public Constraint[] getConstraints() { return constraints; }
    }

    static class ConstraintSolver {
        private ConstraintNetwork network;
        public ConstraintSolver(ConstraintNetwork cn) { this.network = cn; }
        public ConstraintNetwork getConstraintNetwork() { return network; }
    }

    static class AllenIntervalConstraint implements Constraint {
        public enum Type { BeforeOrMeets, Equals }
        private Variable from;
        private Variable to;
        private Type[] types;

        public AllenIntervalConstraint(Variable from, Variable to, Type[] types) {
            this.from = from; this.to = to; this.types = types;
        }
        public Variable getFrom() { return from; }
        public Variable getTo() { return to; }
        public Type[] getTypes() { return types; }
    }

    static class Trajectory {
        private int start, end;
        public Trajectory(int s, int e) { this.start = s; this.end = e; }
        public int getSequenceNumberStart() { return start; }
        public int getSequenceNumberEnd() { return end; }
    }

    static class TrajectoryEnvelope implements Variable {
        private TrajectoryEnvelope superEnv = null;
        private Trajectory trajectory;
        private String name;
        
        public TrajectoryEnvelope(String name, Trajectory t) { this.name = name; this.trajectory = t; }
        public boolean hasSuperEnvelope() { return superEnv != null; }
        public TrajectoryEnvelope getSuperEnvelope() { return superEnv; }
        public void setSuperEnvelope(TrajectoryEnvelope e) { this.superEnv = e; }
        public boolean hasSubEnvelopes() { return false; }
        public Trajectory getTrajectory() { return trajectory; }
        public int getSequenceNumberStart() { return trajectory.getSequenceNumberStart(); }
        public Variable[] getRecursivelyDependentVariables() { return new Variable[]{}; } 
        
        @Override public String toString() { return name; }
    }

    private ConstraintSolver[] solvers;
    public ConstraintSolver[] getConstraintSolvers() { return solvers; }


// ORIGINAL CODESEARCHNET METHOD — START

    public DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> getCurrentDependencies() {
        DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> depGraph = new DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]>();
        ConstraintNetwork cn = this.getConstraintSolvers()[0].getConstraintNetwork();
        Constraint[] cons = cn.getConstraints();
        for (Constraint con : cons) {
            if (con instanceof AllenIntervalConstraint) {
                AllenIntervalConstraint aic = (AllenIntervalConstraint)con;
                if (aic.getTypes()[0].equals(AllenIntervalConstraint.Type.BeforeOrMeets)) {

                    
                    TrajectoryEnvelope mustWaitToStart = (TrajectoryEnvelope)aic.getTo();
                    TrajectoryEnvelope mustFinishBeforeOtherCanStart = (TrajectoryEnvelope)aic.getFrom();
                    TrajectoryEnvelope waitingEnvelope = null;

                    
                    TrajectoryEnvelope root = mustWaitToStart;
                    while (root.hasSuperEnvelope()) root = root.getSuperEnvelope();
                    for (Variable depVar : root.getRecursivelyDependentVariables()) {
                        TrajectoryEnvelope depTE = (TrajectoryEnvelope)depVar;
                        if (!depTE.hasSubEnvelopes() && depTE.getTrajectory().getSequenceNumberEnd() == mustWaitToStart.getSequenceNumberStart()-1) {
                            waitingEnvelope = depTE;
                            break;
                        }
                    }

                    
                    Integer thresholdPoint = mustFinishBeforeOtherCanStart.getTrajectory().getSequenceNumberEnd();
                    Integer waitingPoint = null;
                    
                    
                    if (waitingEnvelope == null) {
                        
                        waitingPoint = mustWaitToStart.getTrajectory().getSequenceNumberStart();
                        waitingEnvelope = mustWaitToStart;
                    }
                    else {
                        waitingPoint = waitingEnvelope.getTrajectory().getSequenceNumberEnd();
                    }
                    
                    
                    ArrayList<TrajectoryEnvelope> verts = new ArrayList<TrajectoryEnvelope>();
                    verts.add(waitingEnvelope);
                    verts.add(mustFinishBeforeOtherCanStart);
                    depGraph.addVertex(waitingEnvelope);
                    depGraph.addVertex(mustFinishBeforeOtherCanStart);
                    depGraph.addEdge(new Integer[] {waitingPoint,thresholdPoint}, waitingEnvelope, mustFinishBeforeOtherCanStart);
                }
            }
        }
        return depGraph;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("--- TrajectoryEnvelopeScheduler.getCurrentDependencies Execution ---");
        method_3_metacsp_gemini scheduler = new method_3_metacsp_gemini();
        
        
        TrajectoryEnvelope env1 = new TrajectoryEnvelope("Robot1_Path", new Trajectory(0, 10));
        TrajectoryEnvelope env2 = new TrajectoryEnvelope("Robot2_Path", new Trajectory(10, 20));
        
        
        AllenIntervalConstraint aic = new AllenIntervalConstraint(env1, env2, new AllenIntervalConstraint.Type[]{ AllenIntervalConstraint.Type.BeforeOrMeets });
        
        
        ConstraintNetwork cn = new ConstraintNetwork(new Constraint[]{ aic });
        scheduler.solvers = new ConstraintSolver[]{ new ConstraintSolver(cn) };

        try {
            DirectedSparseMultigraph<TrajectoryEnvelope, Integer[]> graph = scheduler.getCurrentDependencies();
            System.out.println("[SUCCESS] Dependency graph built successfully.");
            System.out.println("-> Vertices identified: " + graph.getVertexCount() + " (Expect 2)");
            System.out.println("-> Edges added: " + graph.getEdgeCount() + " (Expect 1)");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}