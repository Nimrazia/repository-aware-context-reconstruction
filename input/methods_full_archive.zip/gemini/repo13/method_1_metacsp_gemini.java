import java.awt.BasicStroke;
import java.awt.Color;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Vector;


public class method_1_metacsp_gemini {

    
    interface CategoryDataset { int getRowCount(); }
    static class TextTitle { public void setHorizontalAlignment(HorizontalAlignment h) {} }
    static class JFreeChart { 
        public TextTitle getTitle() { return new TextTitle(); } 
        public CategoryPlot getCategoryPlot() { return new CategoryPlot(); }
    }
    enum PlotOrientation { HORIZONTAL, VERTICAL }
    enum HorizontalAlignment { LEFT, RIGHT, CENTER }
    enum AxisLocation { BOTTOM_OR_RIGHT, TOP_OR_LEFT }
    enum ItemLabelAnchor { INSIDE1, OUTSIDE }
    enum TextAnchor { TOP_RIGHT, BOTTOM_LEFT }

    static class ItemLabelPosition {
        public ItemLabelPosition(ItemLabelAnchor anchor, TextAnchor textAnchor) {}
    }

    static class NumberAxis {
        public static Object createIntegerTickUnits() { return new Object(); }
        public void setStandardTickUnits(Object units) {}
        public void setLowerMargin(double m) {}
        public void setUpperMargin(double m) {}
        public void setNumberFormatOverride(NumberFormat nf) {}
        public void setRange(Range r) {}
    }

    static class Range {}

    static class StackedBarRenderer {
        public void setItemLabelsVisible(boolean b) {}
        public void setItemLabelGenerator(LabelGenerator g) {}
        public void setPositiveItemLabelPositionFallback(ItemLabelPosition p) {}
        public void setSeriesPositiveItemLabelPosition(int i, ItemLabelPosition p) {}
        public void setToolTipGenerator(PlotBoxTooltip t) {}
        public void setBase(long base) {}
        public void setSeriesPaint(int i, Color c) {}
        public void setSeriesOutlinePaint(int i, Color c) {}
        public void setBaseSeriesVisibleInLegend(boolean b1, boolean b2) {}
        public void setSeriesStroke(int i, BasicStroke s) {}
    }

    static class CategoryPlot {
        public void setRangeAxisLocation(AxisLocation l) {}
        public StackedBarRenderer getRenderer() { return new StackedBarRenderer(); }
        public void setRenderer(StackedBarRenderer r) {}
        public void setForegroundAlpha(float a) {}
        public NumberAxis getRangeAxis() { return new NumberAxis(); }
    }

    static class ChartFactory {
        public static JFreeChart createStackedBarChart(String title, String domainAxisLabel, String rangeAxisLabel,
                CategoryDataset dataset, PlotOrientation orientation, boolean legend, boolean tooltips, boolean urls) {
            return new JFreeChart();
        }
    }

    
    static class LabelGenerator { public LabelGenerator(boolean show) {} }
    static class PlotBoxTooltip {}
    static class SimpleTimeline {
        public Long[] getPulses() { return new Long[]{ 100L }; }
        public boolean isInconsistent(Object v) { return false; }
        public boolean isCritical(Object v) { return true; }
        public boolean isUndetermined(Object v) { return false; }
    }

    
    private String name = "Test Chart";
    private JFreeChart chart;
    private boolean showlabels = true;
    private Range range = null;
    private SimpleTimeline stl = new SimpleTimeline();
    private int[] durations = new int[]{10, 20};
    private Object[] values = new Object[]{new Object(), new Object()};


// ORIGINAL CODESEARCHNET METHOD — START

    @SuppressWarnings("deprecation")
    private JFreeChart createChart(CategoryDataset dataset) {


        String s = null;
        String tit = null;
        String ax = null;





        tit = this.name;
        
        chart = ChartFactory.createStackedBarChart(
            tit,  
            s,                  
            ax,                     
            dataset,                     
            PlotOrientation.HORIZONTAL,    
            false,                        
            false,                       
            false                        
        );
        CategoryPlot plot = chart.getCategoryPlot();

        chart.getTitle().setHorizontalAlignment(HorizontalAlignment.LEFT);
        plot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_RIGHT);

        
        
        StackedBarRenderer renderer = (StackedBarRenderer) plot.getRenderer();
        renderer.setItemLabelsVisible(true);
        renderer.setItemLabelGenerator(new LabelGenerator(showlabels));
        ItemLabelPosition pos = new ItemLabelPosition(ItemLabelAnchor.INSIDE1, TextAnchor.TOP_RIGHT);
        renderer.setPositiveItemLabelPositionFallback(pos);
        for(int i = 0; i < dataset.getRowCount(); i++) {
            renderer.setSeriesPositiveItemLabelPosition(i, pos);
        }
        
        






        renderer.setToolTipGenerator(new PlotBoxTooltip());
        plot.setRenderer(renderer);
       
        plot.setForegroundAlpha(0.8f);
                        
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        rangeAxis.setLowerMargin(2.0);
        rangeAxis.setUpperMargin(2.0);
        
        
        
        long origin = stl.getPulses()[0].longValue();
        NumberFormat nf = new DecimalFormat();
        rangeAxis.setNumberFormatOverride ( nf ); 
        if (this.range != null) rangeAxis.setRange(range);
        
   
        
        renderer.setBase(origin);
        
        
        
        

        for (int i = 0; i < durations.length; i++) {
            if (stl.isInconsistent(values[i]))
                renderer.setSeriesPaint(i, new Color(198, 30, 69));
            else if (stl.isCritical(values[i]))
                renderer.setSeriesPaint(i, new Color(238,234,111));
            else if (stl.isUndetermined(values[i]))
                renderer.setSeriesPaint(i, new Color(255,255,255));
            else renderer.setSeriesPaint(i, new Color(111,180,238));
            renderer.setSeriesOutlinePaint(i, Color.black);
        }
        
        renderer.setBaseSeriesVisibleInLegend(false, false);
        
        renderer.setSeriesStroke(0, new BasicStroke(40f));
        
        return chart;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("--- PlotBoxTLSmall.createChart Execution ---");
        method_1_metacsp_gemini plotBox = new method_1_metacsp_gemini();
        
        CategoryDataset mockDataset = new CategoryDataset() {
            @Override public int getRowCount() { return 2; }
        };

        try {
            JFreeChart chart = plotBox.createChart(mockDataset);
            System.out.println("[SUCCESS] Chart created and configured successfully.");
            System.out.println("-> Target Timeline Origin Pulled: " + plotBox.stl.getPulses()[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}