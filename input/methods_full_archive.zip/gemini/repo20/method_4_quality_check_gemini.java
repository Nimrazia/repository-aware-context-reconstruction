import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




public class method_4_quality_check_gemini {

    

    


    @Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.FIELD})
    @Retention(RetentionPolicy.CLASS)
    public @interface Nonnull {}

    


    public static class Check {
        public static <T> T notNull(T obj, String message) {
            if (obj == null) {
                throw new IllegalArgumentException(message + " must not be null");
            }
            return obj;
        }

        public static String notEmpty(String str, String message) {
            if (str == null || str.trim().isEmpty()) {
                throw new IllegalArgumentException(message + " must not be empty");
            }
            return str;
        }

        public static void stateIsTrue(boolean expression, String messageTemplate, Object... args) {
            if (!expression) {
                throw new IllegalStateException(String.format(messageTemplate, args));
            }
        }
    }

    


    public enum AccessorPrefix {
        GET("get"),
        IS("is"),
        HAS("has");

        private final String prefix;

        AccessorPrefix(String prefix) {
            this.prefix = prefix;
        }

        public String getPrefix() {
            return prefix;
        }
    }

    


    public static class MethodUtil {

        
        private static final Pattern PATTERN = Pattern.compile("[a-zA-Z0-9]+");


// ORIGINAL CODESEARCHNET METHOD — START

        public static String determineAccessorName(@Nonnull final AccessorPrefix prefix, @Nonnull final String fieldName) {
            Check.notNull(prefix, "prefix");
            Check.notEmpty(fieldName, "fieldName");
            final Matcher m = PATTERN.matcher(fieldName);
            Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
            final String name = m.group();
            return prefix.getPrefix() + name.substring(0, 1).toUpperCase() + name.substring(1);
        }

// ORIGINAL CODESEARCHNET METHOD — END


    }

    
    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" MethodUtil.determineAccessorName Test   ");
        System.out.println("=========================================\n");

        try {
            
            String result1 = MethodUtil.determineAccessorName(AccessorPrefix.GET, "name");
            System.out.println("[SUCCESS] GET + 'name'       -> " + result1);

            
            String result2 = MethodUtil.determineAccessorName(AccessorPrefix.IS, "active");
            System.out.println("[SUCCESS] IS + 'active'      -> " + result2);

            
            
            String result3 = MethodUtil.determineAccessorName(AccessorPrefix.GET, "_value");
            System.out.println("[SUCCESS] GET + '_value'     -> " + result3);

            
            String result4 = MethodUtil.determineAccessorName(AccessorPrefix.HAS, "children");
            System.out.println("[SUCCESS] HAS + 'children'   -> " + result4);

            
            System.out.print("[TEST] Expecting Exception for empty field: ");
            try {
                MethodUtil.determineAccessorName(AccessorPrefix.GET, "   ");
            } catch (IllegalArgumentException e) {
                System.out.println("Caught -> " + e.getMessage());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n=========================================");
    }
}