import java.math.BigDecimal;
import java.math.BigInteger;




public class method_3_quality_check_gemini {

    

    


    public static class IllegalNumberArgumentException extends IllegalArgumentException {
        public IllegalNumberArgumentException(String message) {
            super(message);
        }
    }

    



    public static class NumberInRange {
        public static void checkByte(Number number) {
            long val = number.longValue();
            if (val < Byte.MIN_VALUE || val > Byte.MAX_VALUE) {
                throw new IllegalArgumentException("Value is out of range for a Byte: " + val);
            }
        }

        public static void checkShort(Number number) {
            long val = number.longValue();
            if (val < Short.MIN_VALUE || val > Short.MAX_VALUE) {
                throw new IllegalArgumentException("Value is out of range for a Short: " + val);
            }
        }

        public static void checkInteger(Number number) {
            long val = number.longValue();
            if (val < Integer.MIN_VALUE || val > Integer.MAX_VALUE) {
                throw new IllegalArgumentException("Value is out of range for an Integer: " + val);
            }
        }

        public static void checkLong(Number number) {
            
            BigInteger val = new BigInteger(number.toString());
            if (val.compareTo(BigInteger.valueOf(Long.MIN_VALUE)) < 0 || val.compareTo(BigInteger.valueOf(Long.MAX_VALUE)) > 0) {
                throw new IllegalArgumentException("Value is out of range for a Long: " + val);
            }
        }

        public static void checkFloat(Number number) {
            BigDecimal val = new BigDecimal(number.toString());
            
            if (val.abs().compareTo(BigDecimal.valueOf(Float.MAX_VALUE)) > 0) {
                throw new IllegalArgumentException("Value is out of range for a Float");
            }
        }

        public static void checkDouble(Number number) {
            BigDecimal val = new BigDecimal(number.toString());
            
            if (val.abs().compareTo(BigDecimal.valueOf(Double.MAX_VALUE)) > 0) {
                throw new IllegalArgumentException("Value is out of range for a Double");
            }
        }
    }

    


    public static class Check {


// ORIGINAL CODESEARCHNET METHOD — START

        private static <T> Number checkNumberInRange(final String value, final Class<T> type) {
            final Number ret;
            if (type.equals(Byte.class)) {
                final Number number = new BigInteger(value);
                NumberInRange.checkByte(number);
                ret = Byte.valueOf(number.byteValue());
            } else if (type.equals(Double.class)) {
                final Number number = new BigDecimal(value);
                NumberInRange.checkDouble(number);
                ret = Double.valueOf(number.doubleValue());
            } else if (type.equals(Float.class)) {
                final Number number = new BigDecimal(value);
                NumberInRange.checkFloat(number);
                ret = Float.valueOf(number.floatValue());
            } else if (type.equals(Integer.class)) {
                final Number number = new BigInteger(value);
                NumberInRange.checkInteger(number);
                ret = Integer.valueOf(number.intValue());
            } else if (type.equals(Long.class)) {
                final Number number = new BigInteger(value);
                NumberInRange.checkLong(number);
                ret = Long.valueOf(number.longValue());
            } else if (type.equals(Short.class)) {
                final Number number = new BigInteger(value);
                NumberInRange.checkShort(number);
                ret = Short.valueOf(number.shortValue());
            } else if (type.equals(BigInteger.class)) {
                ret = new BigInteger(value);
            } else if (type.equals(BigDecimal.class)) {
                ret = new BigDecimal(value);
            } else {
                throw new IllegalNumberArgumentException("Return value is no known subclass of 'java.lang.Number': " + type.getName());
            }
            return ret;
        }

// ORIGINAL CODESEARCHNET METHOD — END


        


        public static <T> Number invokeCheckNumberInRange(final String value, final Class<T> type) {
            return checkNumberInRange(value, type);
        }
    }

    
    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" Check.checkNumberInRange Execution Test ");
        System.out.println("=========================================\n");

        try {
            
            Number intVal = Check.invokeCheckNumberInRange("1024", Integer.class);
            System.out.println("[SUCCESS] Parsed Integer : " + intVal + " (Type: " + intVal.getClass().getSimpleName() + ")");

            
            Number doubleVal = Check.invokeCheckNumberInRange("3.14159265359", Double.class);
            System.out.println("[SUCCESS] Parsed Double  : " + doubleVal + " (Type: " + doubleVal.getClass().getSimpleName() + ")");

            
            Number bdVal = Check.invokeCheckNumberInRange("987654321.123456789", BigDecimal.class);
            System.out.println("[SUCCESS] Parsed Dec/Big : " + bdVal + " (Type: " + bdVal.getClass().getSimpleName() + ")");

            
            try {
                System.out.print("[TEST] Expecting Exception for Byte out of bounds: ");
                Check.invokeCheckNumberInRange("256", Byte.class); 
            } catch (IllegalArgumentException e) {
                System.out.println("Caught -> " + e.getMessage());
            }

            
            try {
                System.out.print("[TEST] Expecting Exception for Non-Number class: ");
                Check.invokeCheckNumberInRange("123", String.class); 
            } catch (IllegalNumberArgumentException e) {
                System.out.println("Caught -> " + e.getMessage());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n=========================================");
    }
}