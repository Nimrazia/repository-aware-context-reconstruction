import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;




public class method_1_quality_check_gemini {

    

    @Target({ElementType.PARAMETER, ElementType.METHOD})
    @Retention(RetentionPolicy.CLASS)
    public @interface Nonnull {}

    public static class Check {
        public static <T> T notNull(T obj, String message) {
            if (obj == null) throw new IllegalArgumentException(message + " must not be null");
            return obj;
        }

        public static <T extends Collection<?>> T notEmpty(T collection, String message) {
            if (collection == null || collection.isEmpty()) 
                throw new IllegalArgumentException(message + " must not be empty");
            return collection;
        }

        public static void stateIsTrue(boolean expression, String messageTemplate, Object... args) {
            if (!expression) {
                throw new IllegalStateException(String.format(messageTemplate, args));
            }
        }
    }

    public static class Package {
        public static final Package UNDEFINED = new Package("undefined");
        private final String name;
        public Package(String name) { this.name = name; }
        public String getName() { return name; }
        @Override public String toString() { return name; }
    }

    public static class NameNode {
        private final String name;
        public NameNode(String name) { this.name = name; }
        @Override public String toString() { return name; }
    }

    public static class PackageDeclaration {
        private final NameNode name;
        public PackageDeclaration(String name) { this.name = new NameNode(name); }
        public NameNode getName() { return name; }
    }

    public interface TypeDeclaration {
        String getName();
    }

    public static class ClassOrInterfaceDeclaration implements TypeDeclaration {
        private final String name;
        public ClassOrInterfaceDeclaration(String name) { this.name = name; }
        @Override public String getName() { return name; }
        public List<Object> getAnnotations() { return new ArrayList<>(); }
        public List<Object> getMembers() { return new ArrayList<>(); }
    }

    public static class CompilationUnit {
        public List<TypeDeclaration> getTypes() {
            List<TypeDeclaration> types = new ArrayList<>();
            types.add(new ClassOrInterfaceDeclaration("MockInterface"));
            return types;
        }
        public List<Object> getImports() { return new ArrayList<>(); }
        public PackageDeclaration getPackage() { return new PackageDeclaration("com.example.mock"); }
    }

    public static class Imports {
        public List<Object> asList() { return new ArrayList<>(); }
    }

    public static class Annotation {}
    public static class Method {}
    public static class Interface {}

    public interface InterfaceAnalysis {
        String getInterfaceName();
    }

    public static class ImmutableInterfaceAnalysis implements InterfaceAnalysis {
        private final String interfaceName;
        public ImmutableInterfaceAnalysis(List<Annotation> annotations, List<Interface> extendsInterfaces, 
                                          List<Object> imports, String interfaceName, List<Method> methods, Package pkg) {
            this.interfaceName = interfaceName;
        }
        @Override
        public String getInterfaceName() { return interfaceName; }
    }

    public static class SourceCodeReader {
        public static CompilationUnit parse(String code) {
            return new CompilationUnit();
        }
        public static Imports findImports(List<Object> imports) {
            return new Imports();
        }
        public static List<Annotation> findAnnotations(List<Object> annotations, Imports imports) {
            return new ArrayList<>();
        }
        public static List<Method> findMethods(List<Object> members, Imports imports) {
            return new ArrayList<>();
        }
        public static List<Interface> findExtends(ClassOrInterfaceDeclaration type) {
            return new ArrayList<>();
        }
    }

    public static class InterfaceAnalyzer {
        
        private static boolean hasPossibleMutatingMethods(List<Method> methods) {
            return false; 
        }


// ORIGINAL CODESEARCHNET METHOD — START

        @Nonnull
        public static InterfaceAnalysis analyze(@Nonnull final String code) {
            Check.notNull(code, "code");

            final CompilationUnit unit = Check.notNull(SourceCodeReader.parse(code), "compilationUnit");
            final List<TypeDeclaration> types = Check.notEmpty(unit.getTypes(), "typeDeclarations");
            Check.stateIsTrue(types.size() == 1, "only one interface declaration per analysis is supported");

            final ClassOrInterfaceDeclaration type = (ClassOrInterfaceDeclaration) types.get(0);

            final Imports imports = SourceCodeReader.findImports(unit.getImports());
            final Package pkg = unit.getPackage() != null ? new Package(unit.getPackage().getName().toString()) : Package.UNDEFINED;
            final List<Annotation> annotations = SourceCodeReader.findAnnotations(type.getAnnotations(), imports);
            final List<Method> methods = SourceCodeReader.findMethods(type.getMembers(), imports);
            Check.stateIsTrue(!hasPossibleMutatingMethods(methods), "The passed interface '%s' seems to have mutating methods", type.getName());
            final List<Interface> extendsInterfaces = SourceCodeReader.findExtends(type);
            final String interfaceName = type.getName();
            return new ImmutableInterfaceAnalysis(annotations, extendsInterfaces, imports.asList(), interfaceName, methods, pkg);
        }

// ORIGINAL CODESEARCHNET METHOD — END

    }

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" InterfaceAnalyzer.analyze Execution Test");
        System.out.println("=========================================\n");

        String mockJavaCode = "package com.example.mock;\n\npublic interface MockInterface {}";
        
        try {
            InterfaceAnalysis analysis = InterfaceAnalyzer.analyze(mockJavaCode);
            System.out.println("[SUCCESS] Interface analysis completed.");
            System.out.println("-> Interface Name Parsed: " + analysis.getInterfaceName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\n=========================================");
    }
}