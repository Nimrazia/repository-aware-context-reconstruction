import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.*;
import java.util.stream.Collectors;



interface TypeMirror {
    String toString();
}

class Name implements CharSequence {
    private String name;
    public Name(String name) { this.name = name; }
    public boolean contentEquals(CharSequence cs) { return name.contentEquals(cs); }
    @Override public int length() { return name.length(); }
    @Override public char charAt(int index) { return name.charAt(index); }
    @Override public CharSequence subSequence(int start, int end) { return name.subSequence(start, end); }
    @Override public String toString() { return name; }
}

interface Element {
    ElementKind getKind();
    <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType);
    List<? extends Element> getEnclosedElements();
    Name getSimpleName();
    TypeMirror asType();
}

interface TypeElement extends Element, TypeMirror {
    ElementKind getKind();
}

enum ElementKind {
    INTERFACE, CLASS, METHOD;
    public boolean isInterface() { return this == INTERFACE; }
}

interface ExecutableType extends TypeMirror {
    TypeMirror getReturnType();
    List<? extends TypeMirror> getParameterTypes();
}

class Diagnostic {
    public enum Kind { ERROR, WARNING, NOTE }
}

class MessagerStub {
    public void printMessage(Diagnostic.Kind kind, String msg, Element e) {
        System.out.println("[" + kind + "] " + msg + " (Element: " + (e != null ? e.getSimpleName() : "null") + ")");
    }
}

class TypesStub {
    public Element asElement(TypeMirror t) {
        if (t instanceof Element) return (Element) t;
        return null;
    }
}



@Retention(RetentionPolicy.RUNTIME)
@interface VarContextProvider {
    boolean parametrization() default true;
}

@Retention(RetentionPolicy.RUNTIME)
@interface Var {}

interface VariableContext {}

class LoggingEvent {
    public String eventName;
    public long timestamp;
}

enum LogLevel {
    INFO("info", "infoEvent"),
    DEBUG("debug", "debugEvent"),
    ERROR("error", "errorEvent");

    private String levelMethodName;
    private String logEventMethodName;

    LogLevel(String lm, String lem) {
        this.levelMethodName = lm;
        this.logEventMethodName = lem;
    }

    public String getLevelMethodName() { return levelMethodName; }
    public String getLogEventMethodName() { return logEventMethodName; }
}

class Variable {
    private Name name;
    private TypeMirror type;
    public Variable(Name name, TypeMirror type) { 
        this.name = name; 
        this.type = type; 
    }
    public Name getName() { return name; }
}

class VariableContextProvider {
    private TypeMirror typeMirror;
    private List<Variable> variables;
    private boolean parametrization;
    
    public VariableContextProvider(TypeMirror typeMirror, List<Variable> variables, boolean parametrization) {
        this.typeMirror = typeMirror;
        this.variables = variables;
        this.parametrization = parametrization;
    }
}




public class method_2_structlogger_gemini {

    protected TypesStub types = new TypesStub();
    protected MessagerStub messager = new MessagerStub();
    
    protected Set<TypeMirror> varContextProviders = new HashSet<>();
    protected Map<TypeMirror, VariableContextProvider> varsHashMap = new HashMap<>();

    protected boolean extendsVariableContext(TypeElement element) {
        return true; 
    }

    protected String format(String format, Object... args) {
        return String.format(format, args);
    }


// ORIGINAL CODESEARCHNET METHOD — START

    private boolean checkVarContextProvider(final TypeMirror typeMirror) {
        final TypeElement element = (TypeElement) types.asElement(typeMirror);
        if (varContextProviders.contains(typeMirror)) { 
            return true;
        }

        if (!element.getKind().isInterface()) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be interface",
                            element
                    ),
                    element
            );
            return false;
        }

        boolean extendsVariableContext = extendsVariableContext(element);

        if (!extendsVariableContext) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be extending %s",
                            element,
                            VariableContext.class.getName()
                    ),
                    element
            );
            return false;
        }

        final List<Variable> elements = new ArrayList<>();
        final VarContextProvider varContextProvider = element.getAnnotation(VarContextProvider.class);

        if (varContextProvider == null) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be annotated with @VarContextProvider",
                            element
                    ),
                    element
            );
            return false;
        }

        
        for (Element enclosed : element.getEnclosedElements()) {
            final Var annotation = enclosed.getAnnotation(Var.class);
            if (annotation != null) {
                final ExecutableType executableType = (ExecutableType) enclosed.asType();
                final Name simpleName = enclosed.getSimpleName();
                

                
                final List<String> logLevelsMethodNames = Arrays.stream(
                        LogLevel.values()
                )
                        .map(
                                LogLevel::getLevelMethodName
                        )
                        .collect(
                                Collectors.toList()
                        );

                
                final List<String> logEventMethodNames = Arrays.stream(
                        LogLevel.values()
                )
                        .map(
                                LogLevel::getLogEventMethodName
                        )
                        .collect(
                                Collectors.toList()
                        );

                List<String> loggingEventFieldNames =
                        Arrays.stream(LoggingEvent.class.getDeclaredFields()).map(e -> e.getName()).collect(Collectors.toList());
                if (
                        simpleName.contentEquals("log") || 
                        logLevelsMethodNames.stream().anyMatch(simpleName::contentEquals) ||
                        logEventMethodNames.stream().anyMatch(simpleName::contentEquals) ||
                        loggingEventFieldNames.stream().anyMatch(simpleName::contentEquals)
                   )
                {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s interface cannot have method named %s",
                                    element,
                                    simpleName
                            ),
                            element
                    );
                    return false;
                }
                if (!executableType.getReturnType().toString().equals(typeMirror.toString())) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method must have return type %s",
                                    element,
                                    simpleName,
                                    element
                            ),
                            element
                    );
                    return false;
                }
                if (executableType.getParameterTypes().size() != 1) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method must have exactly one argument",
                                    element,
                                    simpleName
                            ),
                            element);
                    return false;
                }
                if (elements.stream().map(Variable::getName).anyMatch(e -> e.contentEquals(simpleName))) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method cannot be overloaded",
                                    element,
                                    simpleName
                            ),
                            element
                    );
                    return false;
                }
                elements.add(new Variable(simpleName, executableType.getParameterTypes().get(0)));
            }
        }
        if (elements.isEmpty()) { 
            messager.printMessage(
                    Diagnostic.Kind.WARNING,
                    format(
                            "%s has no @Var annotated methods",
                            element
                    ),
                    element
            );
        }
        varsHashMap.put(typeMirror, new VariableContextProvider(typeMirror, elements, varContextProvider.parametrization()));
        varContextProviders.add(typeMirror);
        return true;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    
    @VarContextProvider
    public static class MockContextClass {}

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" LogInvocationProcessor Validator Test   ");
        System.out.println("=========================================\n");

        method_2_structlogger_gemini processor = new method_2_structlogger_gemini();

        
        TypeElement mockInterface = new TypeElement() {
            @Override public ElementKind getKind() { return ElementKind.INTERFACE; }
            @Override public Name getSimpleName() { return new Name("ValidContextInterface"); }
            @Override public TypeMirror asType() { return this; }
            @Override public String toString() { return "ValidContextInterface"; }
            
            @SuppressWarnings("unchecked")
            @Override public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType) {
                if (annotationType == VarContextProvider.class) {
                    return (A) MockContextClass.class.getAnnotation(VarContextProvider.class);
                }
                return null;
            }

            @Override public List<? extends Element> getEnclosedElements() {
                
                Element mockMethod = new Element() {
                    @Override public ElementKind getKind() { return ElementKind.METHOD; }
                    @Override public Name getSimpleName() { return new Name("userId"); }
                    
                    @SuppressWarnings("unchecked")
                    @Override public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType) {
                        if (annotationType == Var.class) {
                            return (A) new Var() {
                                @Override public Class<? extends java.lang.annotation.Annotation> annotationType() { return Var.class; }
                            };
                        }
                        return null;
                    }

                    @Override public TypeMirror asType() {
                        return new ExecutableType() {
                            @Override public TypeMirror getReturnType() {
                                return new TypeMirror() {
                                    @Override public String toString() { return "ValidContextInterface"; }
                                };
                            } 
                            @Override public List<? extends TypeMirror> getParameterTypes() {
                                return Collections.singletonList(new TypeMirror() {
                                    @Override public String toString() { return "java.lang.String"; }
                                });
                            }
                            @Override public String toString() { return "ExecutableType(userId)"; }
                        };
                    }

                    @Override public List<? extends Element> getEnclosedElements() { return Collections.emptyList(); }
                };
                return Collections.singletonList(mockMethod);
            }
        };

        try {
            System.out.println("-> Validating the simulated Context Interface...");
            boolean isValid = processor.checkVarContextProvider(mockInterface);
            
            if (isValid) {
                System.out.println("[SUCCESS] The variable context provider passed all structural checks.");
                System.out.println("-> Vars Map Size: " + processor.varsHashMap.size());
            } else {
                System.out.println("[FAILED] The variable context provider failed validation.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\n=========================================");
    }
}