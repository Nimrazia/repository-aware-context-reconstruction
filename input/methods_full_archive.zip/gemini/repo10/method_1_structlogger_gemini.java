import java.util.*;
import java.util.regex.Pattern;


class Name {
    private String name;
    public Name(String name) { this.name = name; }
    public boolean contentEquals(CharSequence cs) { return name.contentEquals(cs); }
    @Override public String toString() { return name; }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Name)) return false;
        return name.equals(((Name) o).name);
    }
    @Override public int hashCode() { return name.hashCode(); }
}

interface TypeMirror {
    String toString();
}

interface MethodInvocationTree {
    List<Object> getArguments();
}

class Diagnostic {
    public enum Kind { ERROR, WARNING, NOTE }
}

class MessagerStub {
    public void printMessage(Diagnostic.Kind kind, String msg) {
        System.out.println("[" + kind + "] " + msg);
    }
}

class JavaFile {
    String packageName = "com.example.generated";
    TypeSpec typeSpec = new TypeSpec("GeneratedEvent");
    static class TypeSpec {
        String name;
        public TypeSpec(String name) { this.name = name; }
    }
}

class GeneratedClassInfo {
    private String qualifiedName, className, packageName;
    private List<VariableAndValue> usedVariables;
    public GeneratedClassInfo(String qn, String cn, String msg, List<VariableAndValue> uv, String pn) {
        this.qualifiedName = qn; this.className = cn; this.usedVariables = uv; this.packageName = pn;
    }
    public String getQualifiedName() { return qualifiedName; }
    public List<VariableAndValue> getUsedVariables() { return usedVariables; }
}

class VariableAndValue {}
class StatementInfo {
    public String getStatement() { return "mock_statement();"; }
}
class StructLoggerFieldContext {
    private TypeMirror contextProvider;
    public TypeMirror getContextProvider() { return contextProvider; }
}
class VariableContextProvider {
    private TypeMirror typeMirror;
    private List<Variable> variables;
    public VariableContextProvider(TypeMirror tm, List<Variable> v, boolean s) {
        this.typeMirror = tm; this.variables = v;
    }
    public List<Variable> getVariables() { return variables; }
    public TypeMirror getTypeMirror() { return typeMirror; }
    public boolean shouldParametrize() { return true; }
}
class Variable {
    private Name name;
    public Variable(Name name, TypeMirror tm) { this.name = name; }
    public Name getName() { return name; }
}
class MethodAndParameter {
    private Name methodName;
    private Object parameter;
    public MethodAndParameter(Name mn, Object p) { this.methodName = mn; this.parameter = p; }
    public Name getMethodName() { return methodName; }
    public Object getParameter() { return parameter; }
}
enum LogLevel {
    INFO("info", "infoEvent", "INFO"),
    DEBUG("debug", "debugEvent", "DEBUG"),
    ERROR("error", "errorEvent", "ERROR");

    private String levelMethodName, logEventMethodName, levelName;
    LogLevel(String lm, String lem, String ln) {
        this.levelMethodName = lm; this.logEventMethodName = lem; this.levelName = ln;
    }
    public String getLevelMethodName() { return levelMethodName; }
    public String getLogEventMethodName() { return logEventMethodName; }
    public String getLevelName() { return levelName; }
}

class JCTree {
    public static class JCLiteral {
        private Object value;
        public JCLiteral(Object value) { this.value = value; }
        public Object getValue() { return value; }
    }
}

class PackageNameException extends Exception {}

interface PojoService {
    JavaFile createPojo(String eventName, JCTree.JCLiteral literal, List<VariableAndValue> usedVariables) throws PackageNameException;
    void writeJavaFile(JavaFile javaFile);
}

class ScannerParams {
    private Map<Name, StructLoggerFieldContext> fields = new HashMap<>();
    private Map<TypeMirror, VariableContextProvider> varsHashMap = new HashMap<>();
    private List<GeneratedClassInfo> generatedClassesInfo = new ArrayList<>();
    
    public Map<Name, StructLoggerFieldContext> getFields() { return fields; }
    public Map<TypeMirror, VariableContextProvider> getVarsHashMap() { return varsHashMap; }
    public List<GeneratedClassInfo> getGeneratedClassesInfo() { return generatedClassesInfo; }
}

class StringUtils {
    public static boolean isBlank(CharSequence cs) {
        return cs == null || cs.toString().trim().isEmpty();
    }
    public static int countMatches(CharSequence str, CharSequence sub) {
        if (str == null || sub == null || str.length() == 0 || sub.length() == 0) return 0;
        int count = 0, idx = 0;
        while ((idx = str.toString().indexOf(sub.toString(), idx)) != -1) {
            count++; idx += sub.length();
        }
        return count;
    }
}




public class method_1_structlogger_gemini {

    protected MessagerStub messager = new MessagerStub();
    protected PojoService pojoService = new PojoService() {
        @Override
        public JavaFile createPojo(String eventName, JCTree.JCLiteral literal, List<VariableAndValue> usedVariables) {
            return new JavaFile();
        }
        @Override
        public void writeJavaFile(JavaFile javaFile) {
            System.out.println("-> PojoService wrote JavaFile for package: " + javaFile.packageName);
        }
    };

    protected void addToUsedVariables(List<VariableAndValue> usedVariables, MethodAndParameter top, Variable variable) {
        usedVariables.add(new VariableAndValue());
    }

    protected void printStatementMustHaveStringLiteralError(StatementInfo statementInfo, Name methodName) {
        messager.printMessage(Diagnostic.Kind.ERROR, "Statement must have string literal for method: " + methodName);
    }

    protected String formatWithStatementLocation(String msg, StatementInfo statementInfo, Object... args) {
        return String.format(msg, args);
    }

    protected void replaceInCode(String loggerName, GeneratedClassInfo classInfo, StatementInfo statementInfo, 
                                 List<VariableAndValue> usedVariables, JCTree.JCLiteral literal, 
                                 String level, VariableContextProvider provider) {
        System.out.println("-> Code replacement successfully executed for logger: " + loggerName);
    }


// ORIGINAL CODESEARCHNET METHOD — START

    private void handleStructLogExpression(final Stack<MethodAndParameter> stack,
                                           final MethodInvocationTree node,
                                           final Name name,
                                           final StatementInfo statementInfo,
                                           final ScannerParams scannerParams) {
        final java.util.List<VariableAndValue> usedVariables = new ArrayList<>();
        JCTree.JCLiteral literal = null;
        String level = null;
        String eventName = null;

        
        final StructLoggerFieldContext structLoggerFieldContext = scannerParams.getFields().get(name);
        final TypeMirror typeMirror = structLoggerFieldContext.getContextProvider();
        final VariableContextProvider variableContextProvider = scannerParams.getVarsHashMap().get(typeMirror);

        
        
        while (!stack.empty()) {
            
            boolean matched = false;
            final MethodAndParameter top = stack.pop();
            
            for (Variable variable : variableContextProvider.getVariables()) {
                final Name topMethodName = top.getMethodName();

                if (variable.getName().equals(topMethodName)) {
                    addToUsedVariables(usedVariables, top, variable);
                    matched = true;
                    break;
                }
                else {
                    for (LogLevel logLevel : LogLevel.values()) {
                        if (topMethodName.contentEquals(logLevel.getLevelMethodName())) {
                            if (!(node.getArguments().get(0) instanceof JCTree.JCLiteral)) {
                                printStatementMustHaveStringLiteralError(statementInfo, topMethodName);
                                return;
                            }
                            literal = (JCTree.JCLiteral) node.getArguments().get(0);
                            level = logLevel.getLevelName();
                            matched = true;
                            break;
                        }
                        else if (topMethodName.contentEquals(logLevel.getLogEventMethodName())) {
                            return; 
                        }
                    }
                }
            }

            if (top.getMethodName().contentEquals("log") && top.getParameter() != null) {
                if (!(top.getParameter() instanceof JCTree.JCLiteral)) {
                    printStatementMustHaveStringLiteralError(statementInfo, top.getMethodName());
                    return;
                }
                eventName = ((JCTree.JCLiteral) top.getParameter()).getValue().toString();
                if (!Pattern.compile("^(\\w+(\\.\\w+)*)+$").matcher(eventName).matches()) {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            formatWithStatementLocation(
                                    "qualified event name %s specified by %s statement is not valid",
                                    statementInfo,
                                    eventName,
                                    statementInfo.getStatement()
                            )
                    );
                    return;
                }
                matched = true;
            } else if (top.getMethodName().contentEquals("log") && top.getParameter() == null) {
                matched = true;
            }
            if (stack.empty() && !top.getMethodName().contentEquals("log")) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "statement %s must be ended by calling log() method",
                                statementInfo,
                                statementInfo.getStatement()
                        )
                );
                return;
            }
            if (!matched) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "variable %s in statement %s is not specified by variable context %s",
                                statementInfo,
                                top.getMethodName(),
                                statementInfo.getStatement(),
                                variableContextProvider.getTypeMirror()
                        )
                );
                return;
            }
        }

        
        if (variableContextProvider.shouldParametrize()) {
            final int countOfStringVariables = StringUtils.countMatches(literal.getValue().toString(), "{}");
            if (countOfStringVariables != usedVariables.size()) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "literal %s contains %d variables, but statement %s uses %d variables",
                                statementInfo,
                                literal.getValue().toString(),
                                countOfStringVariables,
                                statementInfo.getStatement(),
                                usedVariables.size()
                        )
                );
                return;
            }
        }

        
        JavaFile javaFile;
        try {
            javaFile = pojoService.createPojo(eventName, literal, usedVariables);
        } catch (PackageNameException e) {
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    formatWithStatementLocation(
                            "qualified event name %s generated by statement %s is not valid, please check specified event name and package does not contain java keyword or no subpackage or class name starts with number",
                            statementInfo,
                            eventName,
                            statementInfo.getStatement()
                    )
            );
            return;
        }
        final String className = javaFile.typeSpec.name;
        final String qualifiedName = StringUtils.isBlank(javaFile.packageName) ? className : javaFile.packageName + "." + className;
        final GeneratedClassInfo generatedClassInfo = new GeneratedClassInfo(qualifiedName, className, (String) literal.getValue(), usedVariables, javaFile.packageName);
        for (GeneratedClassInfo info : scannerParams.getGeneratedClassesInfo()) {
            if (info.getQualifiedName().equals(generatedClassInfo.getQualifiedName())
                    && !info.getUsedVariables().equals(generatedClassInfo.getUsedVariables())
                    ) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "Statement %s generates different event structure for same event name",
                                statementInfo,
                                statementInfo.getStatement()
                        )
                );
                return;
            }
        }
        scannerParams.getGeneratedClassesInfo().add(generatedClassInfo);

        pojoService.writeJavaFile(javaFile);

        
        replaceInCode(name.toString(), generatedClassInfo, statementInfo, usedVariables, literal, level, variableContextProvider);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        method_1_structlogger_gemini scanner = new method_1_structlogger_gemini();
        
        Stack<MethodAndParameter> stack = new Stack<>();
        stack.push(new MethodAndParameter(new Name("log"), new JCTree.JCLiteral("User logged in {}")));
        stack.push(new MethodAndParameter(new Name("userId"), "123"));

        MethodInvocationTree node = () -> Arrays.asList(new JCTree.JCLiteral("User logged in {}"));
        Name loggerName = new Name("logField");
        StatementInfo stmtInfo = new StatementInfo();
        ScannerParams params = new ScannerParams();
        
        TypeMirror tm = new TypeMirror() {
            @Override public String toString() { return "com.example.UserContext"; }
        };
        StructLoggerFieldContext fieldContext = new StructLoggerFieldContext();
        
        params.getFields().put(loggerName, fieldContext);

        System.out.println("=========================================");
        System.out.println("   LogInvocationScanner Test Execution   ");
        System.out.println("=========================================\n");

        try {
            
            System.out.println("-> Initializing scanner handleStructLogExpression test...");
            
            System.out.println("[SUCCESS] Scanner setup configured successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\n=========================================");
    }
}