



public class method_3_jetty_gemini {

    
    
    

    static class TranscoderException extends Exception {
        public TranscoderException(String msg) { super(msg); }
    }

    static class Logger {
        public void debug(String msg) { System.out.println("DEBUG: " + msg); }
        public void warn(Throwable t) { System.out.println("WARN: " + t.getMessage()); }
    }

    public interface ISerializableSession {
        void setDomain(String domain);
        void setPath(String path);
        void setVersion(long version);
    }

    public static class MockSerializableSession implements ISerializableSession {
        private long version;
        public void setDomain(String domain) {}
        public void setPath(String path) {}
        public void setVersion(long version) { this.version = version; }
        @Override
        public String toString() { return "MockSerializableSession[version=" + version + "]"; }
    }

    public static class NoSqlSession {
        private String id;
        private boolean valid;

        public NoSqlSession(String id, boolean valid) {
            this.id = id;
            this.valid = valid;
        }

        public String getId() { return id; }
        public boolean isValid() { return valid; }
        
        public void willPassivate() { System.out.println("INFO: Session will passivate."); }
        public void didActivate() { System.out.println("INFO: Session did activate."); }
        
        @Override
        public String toString() { return "NoSqlSession[" + id + "]"; }
    }

    public interface SessionFactory {
        ISerializableSession create(NoSqlSession session);
    }

    public static class MockSessionFactory implements SessionFactory {
        public ISerializableSession create(NoSqlSession session) {
            return new MockSerializableSession();
        }
    }

    
    
    

    public static abstract class BaseSessionManager {
        protected abstract Object save(NoSqlSession session, Object version, boolean activateAfterSave);
    }

    public static class KeyValueStoreSessionManager extends BaseSessionManager {
        protected Logger log = new Logger();
        protected String _cookieDomain = "example.com";
        protected String _cookiePath = "/app";
        private SessionFactory sessionFactory = new MockSessionFactory();

        protected SessionFactory getSessionFactory() { return sessionFactory; }

        protected boolean setKey(String id, ISerializableSession data) throws TranscoderException {
            System.out.println("INFO: Key stored in remote KVS.");
            return true;
        }

        protected void deleteKey(String id) {
            System.out.println("INFO: Key deleted from remote KVS.");
        }


// ORIGINAL CODESEARCHNET METHOD — START

@Override
    protected Object save(final NoSqlSession session, final Object version, final boolean activateAfterSave)
    {
        try
        {
            log.debug("save:" + session);
            session.willPassivate();

            if (!session.isValid())
            {
                log.debug("save: skip saving invalidated session: id=" + session.getId());
                deleteKey(session.getId());
                return null;
            }

            ISerializableSession data;
            synchronized (session)
            {
                data = getSessionFactory().create(session);
            }
            data.setDomain(_cookieDomain);
            data.setPath(_cookiePath);
            long longVersion = 1; 
            if (version != null)
            {
                longVersion = (Long) version + 1L;
            }
            data.setVersion(longVersion);

            try
            {
                if (!setKey(session.getId(), data))
                {
                    throw (new RuntimeException("unable to set key: data=" + data));
                }
            }
            catch (TranscoderException error)
            {
                throw (new IllegalArgumentException("unable to serialize session: id=" + session.getId() + ", data="
                    + data, error));
            }
            log.debug("save:db.sessions.update(" + session.getId() + "," + data + ")");

            if (activateAfterSave)
            {
                session.didActivate();
            }

            return longVersion;
        }
        catch (Exception e)
        {
            log.warn(e);
        }
        return null;
    }

// ORIGINAL CODESEARCHNET METHOD — END

    }

    public static void main(String[] args) {
        System.out.println("Starting KeyValueStoreSessionManager.save Simulation...\n");

        KeyValueStoreSessionManager manager = new KeyValueStoreSessionManager();
        
        System.out.println("--- Scenario 1: Saving a Valid Session ---");
        NoSqlSession validSession = new NoSqlSession("sess-1", true);
        Object versionRet = manager.save(validSession, 5L, true);
        System.out.println("Returned version: " + versionRet);

        System.out.println("\n--- Scenario 2: Saving an Invalidated Session ---");
        NoSqlSession invalidSession = new NoSqlSession("sess-2", false);
        Object versionRet2 = manager.save(invalidSession, 2L, false);
        System.out.println("Returned version: " + versionRet2);

        System.out.println("\nExecution Complete.");
    }
}