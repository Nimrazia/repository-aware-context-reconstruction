import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;


public class method_3_fuchsia_gemini {

    static final Logger logger = Logger.getLogger("ZWaveMultiInstance");

    
    enum CommandClass { BASIC }

    static class ZWaveCommandClass {
        public CommandClass getCommandClass() { return CommandClass.BASIC; }
        public int getVersion() { return 1; }
        public void setVersion(int v) {}
        public static ZWaveCommandClass getInstance(int data, ZWaveNode n, ZWaveController c, ZWaveEndpoint e) {
            return new ZWaveCommandClass();
        }
    }

    static class ZWaveBasicCommandClass extends ZWaveCommandClass {
        public ZWaveBasicCommandClass(ZWaveNode n, ZWaveController c, ZWaveEndpoint e) {}
    }

    static class ZWaveDeviceClass {
        enum Basic { NOT_KNOWN(0), SLAVE(4); 
            int key; Basic(int k){key=k;} 
            public String getLabel() { return name(); } public int getKey(){return key;} 
        }
        enum Generic { 
            SWITCH_BINARY(0x10); 
            int key; Generic(int k){key=k;} 
            public String getLabel() { return name(); } public int getKey(){return key;}
            public static Generic getGeneric(int k) { return SWITCH_BINARY; } 
        }
        enum Specific { 
            POWER_SWITCH_BINARY(0x01); 
            int key; Specific(int k){key=k;} 
            public String getLabel() { return name(); } public int getKey(){return key;}
            public static Specific getSpecific(Generic g, int k) { return POWER_SWITCH_BINARY; } 
        }
        
        private Basic basic = Basic.NOT_KNOWN;
        public Basic getBasicDeviceClass() { return basic; }
        public void setBasicDeviceClass(Basic b) { this.basic = b; }
        public void setGenericDeviceClass(Generic g) {}
        public void setSpecificDeviceClass(Specific s) {}
    }

    static class ZWaveEndpoint {
        private ZWaveDeviceClass devClass = new ZWaveDeviceClass();
        public ZWaveDeviceClass getDeviceClass() { return devClass; }
        public void addCommandClass(ZWaveCommandClass c) {}
    }

    static class ZWaveNode {
        public int getNodeId() { return 2; }
        public boolean supportsCommandClass(CommandClass c) { return true; }
        public ZWaveDeviceClass getDeviceClass() { 
            ZWaveDeviceClass zdc = new ZWaveDeviceClass(); zdc.setBasicDeviceClass(ZWaveDeviceClass.Basic.SLAVE); return zdc; 
        }
        public ZWaveCommandClass getCommandClass(CommandClass c) { return new ZWaveCommandClass(); }
        public void advanceNodeStage() { System.out.println("[MOCK] Node stage advanced."); }
    }

    static class ZWaveController {}

    static class SerialMessage {
        private byte[] payload;
        public SerialMessage(byte[] payload) { this.payload = payload; }
        public int getMessagePayloadByte(int i) { return payload[i] & 0xFF; }
        public byte[] getMessagePayload() { return payload; }
    }

    
    private boolean endpointsAreTheSameDeviceClass = false;
    private Map<Integer, ZWaveEndpoint> endpoints = new HashMap<>();
    private ZWaveNode node = new ZWaveNode();
    private ZWaveController controller = new ZWaveController();

    public ZWaveNode getNode() { return node; }
    public ZWaveController getController() { return controller; }


// ORIGINAL CODESEARCHNET METHOD — START

    private void handleMultiChannelCapabilityReportResponse(SerialMessage serialMessage, int offset) {
        logger.fine("Process Multi-channel capability Report");
        int receivedEndpointId = serialMessage.getMessagePayloadByte(offset) & 0x7F;
        boolean dynamic = ((serialMessage.getMessagePayloadByte(offset) & 0x80) != 0);
        int genericDeviceClass = serialMessage.getMessagePayloadByte(offset + 1);
        int specificDeviceClass = serialMessage.getMessagePayloadByte(offset + 2);
        
        logger.fine("Endpoints are the same device class = " + (endpointsAreTheSameDeviceClass ? "true" : false));

        
        
        int startId = this.endpointsAreTheSameDeviceClass ? 1 : receivedEndpointId;
        int endId = this.endpointsAreTheSameDeviceClass ? this.endpoints.size() : receivedEndpointId;
        
        boolean supportsBasicCommandClass = this.getNode().supportsCommandClass(CommandClass.BASIC);
        
        for (int endpointId = startId; endpointId <= endId; endpointId++) {
            ZWaveEndpoint endpoint = this.endpoints.get(endpointId);
            
            if (endpoint == null){
                logger.severe("Endpoint " + endpointId + " not found on node " + this.getNode().getNodeId() + ". Cannot set command classes.");
                continue;
            }
    
            ZWaveDeviceClass.Basic basic = this.getNode().getDeviceClass().getBasicDeviceClass();
            ZWaveDeviceClass.Generic generic = ZWaveDeviceClass.Generic.getGeneric(genericDeviceClass);
            if (generic == null) {
                logger.severe(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.", 
                        endpointId, genericDeviceClass, specificDeviceClass));
                continue;
            }
            ZWaveDeviceClass.Specific specific = ZWaveDeviceClass.Specific.getSpecific(generic, specificDeviceClass);
            if (specific == null) {
                logger.severe(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.", 
                        endpointId, genericDeviceClass, specificDeviceClass));
                continue;
            }
            
            logger.fine("Endpoint Id = " + endpointId);
            logger.fine("Endpoints is dynamic = " + (dynamic ? "true" : false));
            logger.fine(String.format("Basic = %s 0x%02x", basic.getLabel(), basic.getKey()));
            logger.fine(String.format("Generic = %s 0x%02x", generic.getLabel(), generic.getKey()));
            logger.fine(String.format("Specific = %s 0x%02x", specific.getLabel(), specific.getKey()));
            
            ZWaveDeviceClass deviceClass = endpoint.getDeviceClass();
            deviceClass.setBasicDeviceClass(basic);
            deviceClass.setGenericDeviceClass(generic);
            deviceClass.setSpecificDeviceClass(specific);
            
            
            if (supportsBasicCommandClass) {
                ZWaveCommandClass commandClass = new ZWaveBasicCommandClass(this.getNode(), this.getController(), endpoint);
                endpoint.addCommandClass(commandClass);
            }
            
            for (int i = 0; i < serialMessage.getMessagePayload().length - offset - 3; i++) {
                int data = serialMessage.getMessagePayloadByte(offset + 3 + i);
                if(data == 0xef )  {
                    
                    break;
                }
                logger.fine(String.format("Adding command class 0x%02X to the list of supported command classes.", data));
                ZWaveCommandClass commandClass = ZWaveCommandClass.getInstance(data, this.getNode(), this.getController(), endpoint);
                if (commandClass == null) {
                    continue;
                }

                endpoint.addCommandClass(commandClass);
                ZWaveCommandClass parentClass = this.getNode().getCommandClass(commandClass.getCommandClass());

                
                if (parentClass != null) {
                    commandClass.setVersion(parentClass.getVersion());
                }
            }
        }
        
        if (this.endpointsAreTheSameDeviceClass)
            
            this.getNode().advanceNodeStage();
        else {
            for (ZWaveEndpoint ep : this.endpoints.values())
            {
                if (ep.getDeviceClass().getBasicDeviceClass() == ZWaveDeviceClass.Basic.NOT_KNOWN) 
                    return;
            }
            
            this.getNode().advanceNodeStage();
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("--- ZWaveMultiInstance Command Class Parsing ---");
        method_3_fuchsia_gemini parser = new method_3_fuchsia_gemini();
        
        
        parser.endpoints.put(1, new ZWaveEndpoint());
        
        
        
        byte[] payload = new byte[] { 0x01, 0x10, 0x01, 0x25, (byte)0xef };
        SerialMessage msg = new SerialMessage(payload);

        try {
            parser.handleMultiChannelCapabilityReportResponse(msg, 0);
            System.out.println("[SUCCESS] ZWave serial buffer unpacked and endpoints assigned.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}