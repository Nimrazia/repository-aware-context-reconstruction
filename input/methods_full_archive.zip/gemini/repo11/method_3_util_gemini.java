



import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.Name;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NameClassPair;
import javax.naming.Binding;
import javax.naming.spi.InitialContextFactory;
import javax.sql.DataSource;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Hashtable;
import java.util.logging.Logger;

public class method_3_util_gemini {

    
    
    

    static class FactoryException extends Exception {
        public FactoryException(String message) { super(message); }
        public FactoryException(String message, Throwable cause) { super(message, cause); }
    }

    static class Validate {
        public static void notBlank(CharSequence cs, String message) {
            if (cs == null || cs.toString().trim().isEmpty()) {
                throw new IllegalArgumentException(message);
            }
        }
    }

    static class InternalLogger {
        public void warn(String msg) { System.out.println("WARN: " + msg); }
    }

    
    static class MockDataSource implements DataSource {
        public Connection getConnection() throws SQLException { return null; }
        public Connection getConnection(String username, String password) throws SQLException { return null; }
        public <T> T unwrap(Class<T> iface) throws SQLException { return null; }
        public boolean isWrapperFor(Class<?> iface) throws SQLException { return false; }
        public PrintWriter getLogWriter() throws SQLException { return null; }
        public void setLogWriter(PrintWriter out) throws SQLException {}
        public void setLoginTimeout(int seconds) throws SQLException {}
        public int getLoginTimeout() throws SQLException { return 0; }
        public Logger getParentLogger() throws SQLFeatureNotSupportedException { return null; }
        @Override
        public String toString() { return "MockDataSource Instance"; }
    }

    
    public static class MockInitialContextFactory implements InitialContextFactory {
        @Override
        public Context getInitialContext(Hashtable<?, ?> environment) throws NamingException {
            return new MockContext();
        }
    }

    
    public static class MockContext implements Context {
        @Override
        public Object lookup(String name) throws NamingException {
            if ("jdbc/ValidDS".equals(name)) {
                return new MockDataSource();
            } else if ("jdbc/InvalidDS".equals(name)) {
                return new Object(); 
            }
            throw new NamingException("Name '" + name + "' not found in Mock JNDI Context.");
        }
        @Override
        public void close() throws NamingException {
            System.out.println("INFO: JNDI Context closed successfully.");
        }
        
        
        public Object lookup(Name name) throws NamingException { return lookup(name.toString()); }
        public void bind(Name name, Object obj) throws NamingException {}
        public void bind(String name, Object obj) throws NamingException {}
        public void rebind(Name name, Object obj) throws NamingException {}
        public void rebind(String name, Object obj) throws NamingException {}
        public void unbind(Name name) throws NamingException {}
        public void unbind(String name) throws NamingException {}
        public void rename(Name oldName, Name newName) throws NamingException {}
        public void rename(String oldName, String newName) throws NamingException {}
        public NamingEnumeration<NameClassPair> list(Name name) throws NamingException { return null; }
        public NamingEnumeration<NameClassPair> list(String name) throws NamingException { return null; }
        public NamingEnumeration<Binding> listBindings(Name name) throws NamingException { return null; }
        public NamingEnumeration<Binding> listBindings(String name) throws NamingException { return null; }
        public void destroySubcontext(Name name) throws NamingException {}
        public void destroySubcontext(String name) throws NamingException {}
        public Context createSubcontext(Name name) throws NamingException { return null; }
        public Context createSubcontext(String name) throws NamingException { return null; }
        public Object lookupLink(Name name) throws NamingException { return null; }
        public Object lookupLink(String name) throws NamingException { return null; }
        public NameParser getNameParser(Name name) throws NamingException { return null; }
        public NameParser getNameParser(String name) throws NamingException { return null; }
        public Name composeName(Name name, Name prefix) throws NamingException { return null; }
        public String composeName(String name, String prefix) throws NamingException { return null; }
        public Object addToEnvironment(String propName, Object propVal) throws NamingException { return null; }
        public Object removeFromEnvironment(String propName) throws NamingException { return null; }
        public Hashtable<?, ?> getEnvironment() throws NamingException { return null; }
        public String getNameInNamespace() throws NamingException { return null; }
    }

    
    
    

    private static InternalLogger LOG = new InternalLogger();


// ORIGINAL CODESEARCHNET METHOD — START

public static DataSource getDataSource(final String jndiName)
            throws FactoryException {

        Validate.notBlank(jndiName, "The validated character sequence 'jndiName' is null or empty");

        

        try {
            
            final Context context = new InitialContext();

            
            final Object namedObject = context.lookup(jndiName);
            if (DataSource.class.isInstance(namedObject)) {
                final DataSource dataSource = (DataSource) context.lookup(jndiName);
                context.close();

                return dataSource;
            } else {
                final String error = "The JNDI name '" + jndiName + "' does not reference a SQL DataSource."
                        + " This is a configuration issue.";
                LOG.warn(error);
                throw new FactoryException(error);
            }
        } catch (NamingException e) {
            final String error = "Error retrieving JDBC date source from JNDI: " + jndiName;
            LOG.warn(error);
            throw new FactoryException(error, e);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting DataSourceFactory.getDataSource Simulation...\n");

        
        System.setProperty(Context.INITIAL_CONTEXT_FACTORY, MockInitialContextFactory.class.getName());

        System.out.println("--- Scenario 1: Lookup Valid DataSource ---");
        try {
            DataSource ds = getDataSource("jdbc/ValidDS");
            System.out.println("Success! Retrieved DataSource: " + ds);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n--- Scenario 2: Lookup Object that is NOT a DataSource ---");
        try {
            getDataSource("jdbc/InvalidDS");
        } catch (FactoryException e) {
            System.out.println("Expected FactoryException caught: " + e.getMessage());
        }

        System.out.println("\n--- Scenario 3: Lookup Non-Existent JNDI Name ---");
        try {
            getDataSource("jdbc/MissingDS");
        } catch (FactoryException e) {
            System.out.println("Expected FactoryException caught: " + e.getMessage());
            System.out.println("  -> Caused by: " + e.getCause().getMessage());
        }

        System.out.println("\n--- Scenario 4: Pass Null JNDI Name ---");
        try {
            getDataSource(null);
        } catch (IllegalArgumentException e) {
            System.out.println("Expected IllegalArgumentException caught from Validate: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}