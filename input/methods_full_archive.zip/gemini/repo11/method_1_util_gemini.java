




import java.util.Properties;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;





interface ConnectionFactory {
    String getUrl();
    Properties getProperties();
}

class DriverManagerConnectionFactory implements ConnectionFactory {
    private final String url;
    private final Properties properties;
    DriverManagerConnectionFactory(String url, Properties properties) {
        this.url = url;
        this.properties = properties;
    }
    public String getUrl() { return url; }
    public Properties getProperties() { return properties; }
}

class PoolableConnection {
    private final String description;
    PoolableConnection(String description) { this.description = description; }
    @Override public String toString() { return description; }
}

class GenericObjectPoolConfig {
    int maxTotal, maxIdle, minIdle, numTestsPerEvictionRun;
    long maxWaitMillis, timeBetweenEvictionRunsMillis, minEvictableIdleTimeMillis, softMinEvictableIdleTimeMillis;
    boolean testOnCreate, testOnBorrow, testOnReturn, testWhileIdle, lifo;
    public void setMaxTotal(int v) { maxTotal = v; }
    public void setMaxIdle(int v) { maxIdle = v; }
    public void setMinIdle(int v) { minIdle = v; }
    public void setMaxWaitMillis(long v) { maxWaitMillis = v; }
    public void setTestOnCreate(boolean v) { testOnCreate = v; }
    public void setTestOnBorrow(boolean v) { testOnBorrow = v; }
    public void setTestOnReturn(boolean v) { testOnReturn = v; }
    public void setTestWhileIdle(boolean v) { testWhileIdle = v; }
    public void setTimeBetweenEvictionRunsMillis(long v) { timeBetweenEvictionRunsMillis = v; }
    public void setNumTestsPerEvictionRun(int v) { numTestsPerEvictionRun = v; }
    public void setMinEvictableIdleTimeMillis(long v) { minEvictableIdleTimeMillis = v; }
    public void setSoftMinEvictableIdleTimeMillis(long v) { softMinEvictableIdleTimeMillis = v; }
    public void setLifo(boolean v) { lifo = v; }
}

class PoolableConnectionFactory {
    private final ConnectionFactory connectionFactory;
    private GenericObjectPool<PoolableConnection> pool;
    private boolean defaultAutoCommit, defaultReadOnly, cacheState;
    private Integer defaultTransactionIsolation;
    private String validationQuery;
    private long maxConnLifetimeMillis;

    PoolableConnectionFactory(ConnectionFactory connectionFactory, Object ignored) {
        this.connectionFactory = connectionFactory;
    }
    public void setDefaultAutoCommit(boolean v) { defaultAutoCommit = v; }
    public void setDefaultReadOnly(boolean v) { defaultReadOnly = v; }
    public void setDefaultTransactionIsolation(Integer v) { defaultTransactionIsolation = v; }
    public void setCacheState(boolean v) { cacheState = v; }
    public void setValidationQuery(String v) { validationQuery = v; }
    public void setMaxConnLifetimeMillis(long v) { maxConnLifetimeMillis = v; }
    public void setPool(GenericObjectPool<PoolableConnection> pool) { this.pool = pool; }
    public PoolableConnection create() {
        return new PoolableConnection("Mock pooled connection for " + connectionFactory.getUrl());
    }
}

class GenericObjectPool<T> {
    private final Object factory;
    private final GenericObjectPoolConfig config;
    GenericObjectPool(Object factory, GenericObjectPoolConfig config) {
        this.factory = factory;
        this.config = config;
    }
    public Object getFactory() { return factory; }
    public GenericObjectPoolConfig getConfig() { return config; }
}

class PoolingDataSource<T> {
    private final GenericObjectPool<T> pool;
    PoolingDataSource(GenericObjectPool<T> pool) { this.pool = pool; }
    public GenericObjectPool<T> getPool() { return pool; }
    @Override public String toString() { return "PoolingDataSource[pool=" + pool + "]"; }
}

public class method_1_util_gemini {

    
    
    

    public static class ConnectionProperties {
        private int maxTotal = 8;
        private int maxIdle = 8;
        private int minIdle = 0;
        private long maxWaitMillis = -1L;
        private boolean testOnCreate = false;
        private boolean testOnBorrow = true;
        private boolean testOnReturn = false;
        private boolean testWhileIdle = false;
        private long timeBetweenEvictionRunsMillis = -1L;
        private int numTestsPerEvictionRun = 3;
        private long minEvictableIdleTimeMillis = 1800000L;
        private long softMinEvictableIdleTimeMillis = -1L;
        private boolean lifo = true;
        private boolean defaultAutoCommit = true;
        private boolean defaultReadOnly = false;
        private Integer defaultTransactionIsolation = null;
        private boolean cacheState = true;
        private String validationQuery = null;
        private long maxConnLifetimeMillis = -1L;

        public int getMaxTotal() { return maxTotal; }
        public int getMaxIdle() { return maxIdle; }
        public int getMinIdle() { return minIdle; }
        public long getMaxWaitMillis() { return maxWaitMillis; }
        public boolean isTestOnCreate() { return testOnCreate; }
        public boolean isTestOnBorrow() { return testOnBorrow; }
        public boolean isTestOnReturn() { return testOnReturn; }
        public boolean isTestWhileIdle() { return testWhileIdle; }
        public long getTimeBetweenEvictionRunsMillis() { return timeBetweenEvictionRunsMillis; }
        public int getNumTestsPerEvictionRun() { return numTestsPerEvictionRun; }
        public long getMinEvictableIdleTimeMillis() { return minEvictableIdleTimeMillis; }
        public long getSoftMinEvictableIdleTimeMillis() { return softMinEvictableIdleTimeMillis; }
        public boolean isLifo() { return lifo; }
        public boolean isDefaultAutoCommit() { return defaultAutoCommit; }
        public boolean isDefaultReadOnly() { return defaultReadOnly; }
        public Integer getDefaultTransactionIsolation() { return defaultTransactionIsolation; }
        public boolean isCacheState() { return cacheState; }
        public String getValidationQuery() { return validationQuery; }
        public long getMaxConnLifetimeMillis() { return maxConnLifetimeMillis; }
    }

    static class Logger {
        public void debug(String msg) { System.out.println("DEBUG: " + msg); }
    }

    
    
    

    private static Logger LOG = new Logger();


// ORIGINAL CODESEARCHNET METHOD — START

private static PoolingDataSource<PoolableConnection> getPoolingDataSource(final String url,
                                            final ConcurrentMap<String, String> properties,
                                            final ConnectionProperties poolSpec) {

        
        assert url != null : "The url cannot be null";
        assert properties != null : "The properties cannot be null";
        assert poolSpec != null : "The pol spec cannot be null";

        LOG.debug("Creating new pooled data source for '" + url + "'");

        
        final Properties props = new Properties();
        props.putAll(properties);

        
        final GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
        poolConfig.setMaxTotal(poolSpec.getMaxTotal());
        poolConfig.setMaxIdle(poolSpec.getMaxIdle());
        poolConfig.setMinIdle(poolSpec.getMinIdle());
        poolConfig.setMaxWaitMillis(poolSpec.getMaxWaitMillis());
        poolConfig.setTestOnCreate(poolSpec.isTestOnCreate());
        poolConfig.setTestOnBorrow(poolSpec.isTestOnBorrow());
        poolConfig.setTestOnReturn(poolSpec.isTestOnReturn());
        poolConfig.setTestWhileIdle(poolSpec.isTestWhileIdle());
        poolConfig.setTimeBetweenEvictionRunsMillis(poolSpec.getTimeBetweenEvictionRunsMillis());
        poolConfig.setNumTestsPerEvictionRun(poolSpec.getNumTestsPerEvictionRun());
        poolConfig.setMinEvictableIdleTimeMillis(poolSpec.getMinEvictableIdleTimeMillis());
        poolConfig.setSoftMinEvictableIdleTimeMillis(poolSpec.getSoftMinEvictableIdleTimeMillis());
        poolConfig.setLifo(poolSpec.isLifo());


        
        final ConnectionFactory connFactory = new DriverManagerConnectionFactory(url, props);
        final PoolableConnectionFactory poolConnFactory = new PoolableConnectionFactory(connFactory, null);
        poolConnFactory.setDefaultAutoCommit(poolSpec.isDefaultAutoCommit());
        poolConnFactory.setDefaultReadOnly(poolSpec.isDefaultReadOnly());
        poolConnFactory.setDefaultTransactionIsolation(poolSpec.getDefaultTransactionIsolation());
        poolConnFactory.setCacheState(poolSpec.isCacheState());
        poolConnFactory.setValidationQuery(poolSpec.getValidationQuery());
        poolConnFactory.setMaxConnLifetimeMillis(poolSpec.getMaxConnLifetimeMillis());
        final GenericObjectPool<PoolableConnection> connPool = new GenericObjectPool<>(poolConnFactory, poolConfig);
        poolConnFactory.setPool(connPool);

        
        return new PoolingDataSource<>(connPool);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting DataSourceFactory getPoolingDataSource Simulation...\n");

        String url = "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1";
        ConcurrentMap<String, String> properties = new ConcurrentHashMap<>();
        properties.put("user", "sa");
        properties.put("password", "");

        ConnectionProperties poolSpec = new ConnectionProperties();

        try {
            PoolingDataSource<PoolableConnection> dataSource = getPoolingDataSource(url, properties, poolSpec);
            System.out.println("\nPoolingDataSource created successfully!");
            System.out.println(" -> DataSource Class: " + dataSource.getClass().getName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\nExecution Complete.");
    }
}