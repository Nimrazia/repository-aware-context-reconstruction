



import org.xml.sax.Attributes;
import org.xml.sax.helpers.AttributesImpl;

import java.util.ArrayList;
import java.util.List;

public class method_1_ojb_gemini {

    
    
    
    
    
    
    
    public static final int MAPPING_REPOSITORY = 1;
    public static final int CLASS_DESCRIPTOR = 2;
    public static final int OBJECT_CACHE = 3;
    public static final int CLASS_EXTENT = 4;
    public static final int FIELD_DESCRIPTOR = 5;
    public static final int REFERENCE_DESCRIPTOR = 6;
    public static final int FOREIGN_KEY = 7;
    public static final int COLLECTION_DESCRIPTOR = 8;
    public static final int ORDERBY = 9;
    public static final int INVERSE_FK = 10;
    public static final int FK_POINTING_TO_THIS_CLASS = 11;
    public static final int FK_POINTING_TO_ITEMS_CLASS = 12;
    public static final int ATTRIBUTE = 13;
    public static final int QUERY_CUSTOMIZER = 14;
    public static final int INDEX_DESCRIPTOR = 15;
    public static final int INDEX_COLUMN = 16;
    public static final int INSERT_PROCEDURE = 17;
    public static final int UPDATE_PROCEDURE = 18;
    public static final int DELETE_PROCEDURE = 19;
    public static final int CONSTANT_ARGUMENT = 20;
    public static final int RUNTIME_ARGUMENT = 21;

    public static final int ISOLATION_LEVEL = 101;
    public static final int PROXY_PREFETCHING_LIMIT = 102;
    public static final int REPOSITORY_VERSION = 103;
    public static final int CLASS_NAME = 104;
    public static final int SCHEMA_NAME = 105;
    public static final int CLASS_PROXY = 106;
    public static final int TABLE_NAME = 107;
    public static final int ROW_READER = 108;
    public static final int EXTENDS = 109;
    public static final int ACCEPT_LOCKS = 110;
    public static final int INITIALIZATION_METHOD = 111;
    public static final int FACTORY_CLASS = 112;
    public static final int FACTORY_METHOD = 113;
    public static final int REFRESH = 114;
    public static final int ID = 115;
    public static final int ACCESS = 116;
    public static final int FIELD_NAME = 117;
    public static final int COLUMN_NAME = 118;
    public static final int JDBC_TYPE = 119;
    public static final int PRIMARY_KEY = 120;
    public static final int NULLABLE = 121;
    public static final int INDEXED = 122;
    public static final int AUTO_INCREMENT = 123;
    public static final int SEQUENCE_NAME = 124;
    public static final int LOCKING = 125;
    public static final int UPDATE_LOCK = 126;
    public static final int FIELD_CONVERSION = 127;
    public static final int LENGTH = 128;
    public static final int PRECISION = 129;
    public static final int SCALE = 130;
    public static final int REFERENCED_CLASS = 131;
    public static final int PROXY_REFERENCE = 132;
    public static final int AUTO_RETRIEVE = 133;
    public static final int AUTO_UPDATE = 134;
    public static final int AUTO_DELETE = 135;
    public static final int OTM_DEPENDENT = 136;
    public static final int FIELD_ID_REF = 137;
    public static final int FIELD_REF = 138;
    public static final int COLLECTION_CLASS = 139;
    public static final int ITEMS_CLASS = 140;
    public static final int SORT = 141;
    public static final int INDIRECTION_TABLE = 142;
    public static final int ATTRIBUTE_NAME = 143;
    public static final int ATTRIBUTE_VALUE = 144;
    public static final int NAME = 145;
    public static final int UNIQUE = 146;
    public static final int INCLUDE_ALL_FIELDS = 147;
    public static final int RETURN_FIELD_REF = 148;
    public static final int INCLUDE_PK_FIELDS_ONLY = 149;
    public static final int VALUE = 150;
    public static final int RETURN = 151;

    public static final String TAG_SUPER = "super";

    static class RepositoryElements {
        public static final String TAG_ACCESS_ANONYMOUS = "anonymous";
    }

    static class Logger {
        public boolean isDebugEnabled() { return true; }
        public void debug(String s) { System.out.println("DEBUG: " + s); }
        public void error(String s, Throwable t) { 
            System.out.println("ERROR: " + s); 
            t.printStackTrace(); 
        }
    }

    static class Tags {
        public String getTagById(int id) {
            switch(id) {
                case ISOLATION_LEVEL: return "isolation-level";
                case PROXY_PREFETCHING_LIMIT: return "proxy-prefetching-limit";
                case REPOSITORY_VERSION: return "version";
                case CLASS_NAME: return "class-name";
                case FIELD_NAME: return "name";
                case COLUMN_NAME: return "column";
                case JDBC_TYPE: return "jdbc-type";
                case TABLE_NAME: return "table";
                case PRIMARY_KEY: return "primarykey";
                case FIELD_ID_REF: return "field-id-ref";
                case FIELD_REF: return "field-ref";
                case REFERENCED_CLASS: return "class-ref";
                case PROXY_REFERENCE: return "proxy";
                case AUTO_RETRIEVE: return "auto-retrieve";
                case AUTO_UPDATE: return "auto-update";
                case AUTO_DELETE: return "auto-delete";
                case COLLECTION_CLASS: return "collection-class";
                case ITEMS_CLASS: return "element-class-ref";
                case INDIRECTION_TABLE: return "indirection-table";
                case ATTRIBUTE_NAME: return "attribute-name";
                case ATTRIBUTE_VALUE: return "attribute-value";
                case NAME: return "name";
                case INCLUDE_ALL_FIELDS: return "include-all-fields";
                case RETURN_FIELD_REF: return "return-field-ref";
                case INCLUDE_PK_FIELDS_ONLY: return "include-pk-fields-only";
                case VALUE: return "value";
                case RETURN: return "return";
            }
            return "tag-" + id;
        }
    }

    interface AttributeContainer {
        void addAttribute(String name, String value);
    }

    static class DescriptorRepository implements AttributeContainer {
        public static String getVersion() { return "1.0"; }
        public void setDefaultIsolationLevel(int level) {}
        public void put(String name, ClassDescriptor cld) {
            System.out.println("Repository: Added ClassDescriptor for " + name);
        }
        public void addAttribute(String name, String value) {}
    }

    static class LockHelper {
        public static int getIsolationLevelFor(String defIso) { return 1; }
    }

    static class ClassHelper {
        public static Class<?> getClass(String name) throws ClassNotFoundException { 
            return Class.forName(name); 
        }
        public static Object newInstance(String className) throws Exception {
            return Class.forName(className).getDeclaredConstructor().newInstance();
        }
    }

    static class MetadataException extends RuntimeException {
        public MetadataException(String msg) { super(msg); }
        public MetadataException(String msg, Throwable cause) { super(msg, cause); }
    }

    static class ObjectCacheDescriptor implements AttributeContainer {
        public void setObjectCache(Class<?> cls) {}
        public void addAttribute(String name, String value) {}
    }

    static class ClassDescriptor implements AttributeContainer {
        public static final String DYNAMIC_STR = "dynamic";
        public ClassDescriptor(DescriptorRepository repo) {}
        public void setIsolationLevel(int level) {}
        public void setClassOfObject(Class<?> c) {}
        public Class<?> getClassOfObject() { return Object.class; }
        public void setSchema(String s) {}
        public void setProxyClassName(String s) {}
        public void setProxyPrefetchingLimit(int l) {}
        public void setTableName(String s) {}
        public void setIsInterface(boolean b) {}
        public void setRowReader(String s) {}
        public void setSuperClass(String s) {}
        public void setAcceptLocks(boolean b) {}
        public void setInitializationMethod(String s) {}
        public void setFactoryClass(String s) {}
        public void setFactoryMethod(String s) {}
        public void setAlwaysRefresh(boolean b) {}
        public void setPersistentFieldClassName(String s) {}
        public String getPersistentFieldClassName() { return "PersistentField"; }
        public String getClassNameOfObject() { return "java.lang.Object"; }
        public void setObjectCacheDescriptor(ObjectCacheDescriptor o) {}
        public void addExtentClass(String s) {}
        public void addFieldDescriptor(FieldDescriptor f) {}
        public void addObjectReferenceDescriptor(ObjectReferenceDescriptor o) {}
        public void addCollectionDescriptor(CollectionDescriptor c) {}
        public void addAttribute(String name, String value) {}
        public int getProxyPrefetchingLimit() { return 50; }
    }

    static class PersistentField {}
    
    static class PersistentFieldFactory {
        public static PersistentField createPersistentField(String className, Class<?> cls, String fieldName) {
            return new PersistentField();
        }
    }

    static class FieldDescriptor implements AttributeContainer {
        public FieldDescriptor(ClassDescriptor cld, int id) {}
        public void setAccess(String s) {}
        public void setPersistentField(PersistentField pf) {}
        public void setColumnName(String s) {}
        public void setColumnType(String s) {}
        public void setPrimaryKey(boolean b) {}
        public void setRequired(boolean b) {}
        public void setIndexed(boolean b) {}
        public void setAutoIncrement(boolean b) {}
        public void setSequenceName(String s) {}
        public void setLocking(boolean b) {}
        public void setUpdateLock(boolean b) {}
        public void setFieldConversionClassName(String s) {}
        public void setLength(int i) {}
        public void setLengthSpecified(boolean b) {}
        public void setPrecision(int i) {}
        public void setPrecisionSpecified(boolean b) {}
        public void setScale(int i) {}
        public void setScaleSpecified(boolean b) {}
        public void addAttribute(String name, String value) {}
    }

    static class AnonymousFieldDescriptor extends FieldDescriptor {
        public AnonymousFieldDescriptor(ClassDescriptor cld, int id) { super(cld, id); }
        public void setPersistentField(PersistentField pf, String name) {}
    }

    static class ObjectReferenceDescriptor implements AttributeContainer {
        public ObjectReferenceDescriptor(ClassDescriptor cld) {}
        public void setPersistentField(PersistentField pf) {}
        public void setItemClass(Class<?> c) {}
        public void setLazy(boolean b) {}
        public void setProxyPrefetchingLimit(int l) {}
        public void setRefresh(boolean b) {}
        public void setCascadeRetrieve(boolean b) {}
        public void setCascadingStore(String s) {}
        public void setCascadingDelete(String s) {}
        public void setOtmDependent(boolean b) {}
        public void addForeignKeyField(int i) {}
        public void addForeignKeyField(String s) {}
        public void addAttribute(String name, String value) {}
    }

    static class SuperReferenceDescriptor extends ObjectReferenceDescriptor {
        public SuperReferenceDescriptor(ClassDescriptor cld) { super(cld); }
    }

    static class CollectionDescriptor implements AttributeContainer {
        public CollectionDescriptor(ClassDescriptor cld) {}
        public void setPersistentField(PersistentField pf) {}
        public void setCollectionClass(Class<?> c) {}
        public void setItemClass(Class<?> c) {}
        public void addOrderBy(String s, boolean b) {}
        public void setIndirectionTable(String s) {}
        public void setLazy(boolean b) {}
        public void setProxyPrefetchingLimit(int l) {}
        public void setRefresh(boolean b) {}
        public void setCascadeRetrieve(boolean b) {}
        public void setCascadingStore(String s) {}
        public void setCascadingDelete(String s) {}
        public void setOtmDependent(boolean b) {}
        public void addForeignKeyField(int i) {}
        public void addForeignKeyField(String s) {}
        public void addFkToThisClass(String s) {}
        public void addFkToItemClass(String s) {}
        public void setQueryCustomizer(QueryCustomizer qc) {}
        public void addAttribute(String name, String value) {}
    }

    static class QueryCustomizer implements AttributeContainer {
        public void addAttribute(String name, String value) {}
    }

    static class IndexDescriptor {
        private List<String> columns = new ArrayList<>();
        public void setName(String name) {}
        public void setUnique(boolean unique) {}
        public List<String> getIndexColumns() { return columns; }
    }

    static class ProcedureDescriptor {
        public void setReturnValueFieldRef(String s) {}
        public void addArgument(ArgumentDescriptor a) {}
    }

    static class InsertProcedureDescriptor extends ProcedureDescriptor {
        public InsertProcedureDescriptor(ClassDescriptor c, String n, boolean b) {}
    }

    static class UpdateProcedureDescriptor extends ProcedureDescriptor {
        public UpdateProcedureDescriptor(ClassDescriptor c, String n, boolean b) {}
    }

    static class DeleteProcedureDescriptor extends ProcedureDescriptor {
        public DeleteProcedureDescriptor(ClassDescriptor c, String n, boolean b) {}
    }

    static class ArgumentDescriptor {
        public ArgumentDescriptor(ProcedureDescriptor p) {}
        public void setValue(String s) {}
        public void setValue(String s, boolean b) {}
    }

    
    
    

    private Logger logger = new Logger();
    private String m_CurrentString;
    private DescriptorRepository m_repository = new DescriptorRepository();
    private AttributeContainer m_CurrentAttrContainer;
    private Tags tags = new Tags();
    private ClassDescriptor m_CurrentCLD;
    private FieldDescriptor m_CurrentFLD;
    private ObjectReferenceDescriptor m_CurrentORD;
    private CollectionDescriptor m_CurrentCOD;
    private IndexDescriptor m_CurrentIndexDescriptor;
    private ProcedureDescriptor m_CurrentProcedure;
    private int defProxyPrefetchingLimit = 50;
    private int m_lastId = 0;

    private int getLiteralId(String qName) {
        if ("class-descriptor".equals(qName)) return CLASS_DESCRIPTOR;
        if ("field-descriptor".equals(qName)) return FIELD_DESCRIPTOR;
        if ("mapping-repository".equals(qName)) return MAPPING_REPOSITORY;
        if ("reference-descriptor".equals(qName)) return REFERENCE_DESCRIPTOR;
        return -1;
    }

    private boolean checkString(String str) {
        return str != null && str.trim().length() > 0;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public void startElement(String uri, String name, String qName, Attributes atts)
    {
        boolean isDebug = logger.isDebugEnabled();

        m_CurrentString = null;
        try
        {
            switch (getLiteralId(qName))
            {
                case MAPPING_REPOSITORY:
                    {
                        if (isDebug) logger.debug(" > " + tags.getTagById(MAPPING_REPOSITORY));
                        this.m_CurrentAttrContainer = m_repository;

                        String defIso = atts.getValue(tags.getTagById(ISOLATION_LEVEL));
                        this.m_repository.setDefaultIsolationLevel(LockHelper.getIsolationLevelFor(defIso));
                        if (isDebug) logger.debug("     " + tags.getTagById(ISOLATION_LEVEL) + ": " + defIso);


                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit != null)
                        {
                            defProxyPrefetchingLimit = Integer.parseInt(proxyPrefetchingLimit);
                        }

                        
                        String version = atts.getValue(tags.getTagById(REPOSITORY_VERSION));
                        if (DescriptorRepository.getVersion().equals(version))
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(REPOSITORY_VERSION) + ": " + version);
                        }
                        else
                        {
                            throw new MetadataException("Repository version does not match. expected " +
                                    DescriptorRepository.getVersion() + " but found: " +
                                    version+". Please update your repository.dtd and your repository.xml"+
                                    " version attribute entry");
                        }
                        break;
                    }
                case CLASS_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("  > " + tags.getTagById(CLASS_DESCRIPTOR));
                        m_CurrentCLD = new ClassDescriptor(m_repository);

                        
                        this.m_CurrentAttrContainer = this.m_CurrentCLD;

                        
                        String isoLevel = atts.getValue(tags.getTagById(ISOLATION_LEVEL));
                        if (isDebug) logger.debug("     " + tags.getTagById(ISOLATION_LEVEL) + ": " + isoLevel);
                        




                        if(checkString(isoLevel)) m_CurrentCLD.setIsolationLevel(LockHelper.getIsolationLevelFor(isoLevel));

                        
                        String classname = atts.getValue(tags.getTagById(CLASS_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + classname);
                        try
                        {
                            m_CurrentCLD.setClassOfObject(ClassHelper.getClass(classname));
                        }
                        catch (ClassNotFoundException e)
                        {
                            m_CurrentCLD = null;
                            throw new MetadataException("Class "+classname+" could not be found"
                                    +" in the classpath. This could cause unexpected behaviour of OJB,"+
                                    " please remove or comment out this class descriptor" +
                                    " in the repository.xml file.", e);
                        }

                        
                        String schema = atts.getValue(tags.getTagById(SCHEMA_NAME));
                        if (schema != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(SCHEMA_NAME) + ": " + schema);
                            m_CurrentCLD.setSchema(schema);
                        }

                        
                        String proxy = atts.getValue(tags.getTagById(CLASS_PROXY));
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_PROXY) + ": " + proxy);
                        if (checkString(proxy))
                        {
                            if (proxy.equalsIgnoreCase(ClassDescriptor.DYNAMIC_STR))
                            {
                                m_CurrentCLD.setProxyClassName(ClassDescriptor.DYNAMIC_STR);
                            }
                            else
                            {
                                m_CurrentCLD.setProxyClassName(proxy);
                            }
                        }

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentCLD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentCLD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String table = atts.getValue(tags.getTagById(TABLE_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(TABLE_NAME) + ": " + table);
                        m_CurrentCLD.setTableName(table);
                        if (table == null)
                        {
                            m_CurrentCLD.setIsInterface(true);
                        }

                        
                        String rowreader = atts.getValue(tags.getTagById(ROW_READER));
                        if (isDebug) logger.debug("     " + tags.getTagById(ROW_READER) + ": " + rowreader);
                        if (rowreader != null)
                        {
                            m_CurrentCLD.setRowReader(rowreader);
                        }

                        

                        String extendsAtt = atts.getValue(tags.getTagById(EXTENDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(EXTENDS) + ": " + extendsAtt);
                        if (checkString(extendsAtt))
                        {
                            m_CurrentCLD.setSuperClass(extendsAtt);
                        }

                        
                        String acceptLocks = atts.getValue(tags.getTagById(ACCEPT_LOCKS));
                        if (acceptLocks==null)
                            acceptLocks="true"; 
                        logger.debug("     " + tags.getTagById(ACCEPT_LOCKS) + ": " + acceptLocks);
                        if (isDebug) logger.debug("     " + tags.getTagById(ACCEPT_LOCKS) + ": " + acceptLocks);
                        boolean b = (Boolean.valueOf(acceptLocks)).booleanValue();
                        m_CurrentCLD.setAcceptLocks(b);

                        
                        String initializationMethod = atts.getValue(tags.getTagById(INITIALIZATION_METHOD));
                        if (isDebug) logger.debug("     " + tags.getTagById(INITIALIZATION_METHOD) + ": " + initializationMethod);
                        if (initializationMethod != null)
                        {
                            m_CurrentCLD.setInitializationMethod(initializationMethod);
                        }

                        
                        String factoryClass = atts.getValue(tags.getTagById(FACTORY_CLASS));
                        if (isDebug)
                            logger.debug("     " + tags.getTagById(FACTORY_CLASS) + ": " + factoryClass);
                        if (factoryClass != null)
                        {
                            m_CurrentCLD.setFactoryClass(factoryClass);
                        }

                        
                        String factoryMethod = atts.getValue(tags.getTagById(FACTORY_METHOD));
                        if (isDebug)
                            logger.debug("     " + tags.getTagById(FACTORY_METHOD) + ": " + factoryMethod);
                        if (factoryMethod != null)
                        {
                            m_CurrentCLD.setFactoryMethod(factoryMethod);
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentCLD.setAlwaysRefresh(b);

                        
                        
						String pfClassName = atts.getValue("persistent-field-class");
						if (isDebug) logger.debug("     persistent-field-class: " + pfClassName);
						m_CurrentCLD.setPersistentFieldClassName(pfClassName);

                        
                        m_repository.put(classname, m_CurrentCLD);
                        break;
                    }
                case OBJECT_CACHE:
                    {
                        
                        
                        if(m_CurrentCLD != null)
                        {
                            String className = atts.getValue(tags.getTagById(CLASS_NAME));
                            if(checkString(className))
                            {
                                if (isDebug) logger.debug("     > " + tags.getTagById(OBJECT_CACHE));
                                ObjectCacheDescriptor ocd = new ObjectCacheDescriptor();
                                this.m_CurrentAttrContainer = ocd;
                                ocd.setObjectCache(ClassHelper.getClass(className));
                                if(m_CurrentCLD != null)
                                {
                                    m_CurrentCLD.setObjectCacheDescriptor(ocd);
                                }
                                if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + className);
                            }
                        }
                        break;
                    }
                case CLASS_EXTENT:
                    {
                        String classname = atts.getValue("class-ref");
                        if (isDebug) logger.debug("     " + tags.getTagById(CLASS_EXTENT) + ": " + classname);
                        m_CurrentCLD.addExtentClass(classname);
                        break;
                    }

                case FIELD_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FIELD_DESCRIPTOR));

                        String strId = atts.getValue(tags.getTagById(ID));
                        m_lastId = (strId == null ? m_lastId + 1 : Integer.parseInt(strId));

                        String strAccess = atts.getValue(tags.getTagById(ACCESS));

                        if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                        {
                            m_CurrentFLD = new AnonymousFieldDescriptor(m_CurrentCLD, m_lastId);
                        }
                        else
                        {
                            m_CurrentFLD = new FieldDescriptor(m_CurrentCLD, m_lastId);
                        }
                        m_CurrentFLD.setAccess(strAccess);
                        m_CurrentCLD.addFieldDescriptor(m_CurrentFLD);

                        
                        this.m_CurrentAttrContainer = this.m_CurrentFLD;

                        String fieldName = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + fieldName);

                        if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                        {
							AnonymousFieldDescriptor anonymous = (AnonymousFieldDescriptor) m_CurrentFLD;
                            anonymous.setPersistentField(null,fieldName);
                        }
                        else
                        {
                            String classname = m_CurrentCLD.getClassNameOfObject();
							PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),ClassHelper.getClass(classname),fieldName);
                            m_CurrentFLD.setPersistentField(pf);
                        }

                        String columnName = atts.getValue(tags.getTagById(COLUMN_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(COLUMN_NAME) + ": " + columnName);
                        m_CurrentFLD.setColumnName(columnName);

                        String jdbcType = atts.getValue(tags.getTagById(JDBC_TYPE));
                        if (isDebug) logger.debug("     " + tags.getTagById(JDBC_TYPE) + ": " + jdbcType);
                        m_CurrentFLD.setColumnType(jdbcType);

                        String primaryKey = atts.getValue(tags.getTagById(PRIMARY_KEY));
                        if (isDebug) logger.debug("     " + tags.getTagById(PRIMARY_KEY) + ": " + primaryKey);
                        boolean b = (Boolean.valueOf(primaryKey)).booleanValue();
                        m_CurrentFLD.setPrimaryKey(b);

                        String nullable = atts.getValue(tags.getTagById(NULLABLE));
                        if (nullable != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(NULLABLE) + ": " + nullable);
                            b = !(Boolean.valueOf(nullable)).booleanValue();
                            m_CurrentFLD.setRequired(b);
                        }

                        String indexed = atts.getValue(tags.getTagById(INDEXED));
                        if (isDebug) logger.debug("     " + tags.getTagById(INDEXED) + ": " + indexed);
                        b = (Boolean.valueOf(indexed)).booleanValue();
                        m_CurrentFLD.setIndexed(b);

                        String autoincrement = atts.getValue(tags.getTagById(AUTO_INCREMENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_INCREMENT) + ": " + autoincrement);
                        b = (Boolean.valueOf(autoincrement)).booleanValue();
                        m_CurrentFLD.setAutoIncrement(b);

                        String sequenceName = atts.getValue(tags.getTagById(SEQUENCE_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(SEQUENCE_NAME) + ": " + sequenceName);
                        m_CurrentFLD.setSequenceName(sequenceName);

                        String locking = atts.getValue(tags.getTagById(LOCKING));
                        if (isDebug) logger.debug("     " + tags.getTagById(LOCKING) + ": " + locking);
                        b = (Boolean.valueOf(locking)).booleanValue();
                        m_CurrentFLD.setLocking(b);

                        String updateLock = atts.getValue(tags.getTagById(UPDATE_LOCK));
                        if (isDebug) logger.debug("     " + tags.getTagById(UPDATE_LOCK) + ": " + updateLock);
                        if(checkString(updateLock))
                        {
                            b = (Boolean.valueOf(updateLock)).booleanValue();
                            m_CurrentFLD.setUpdateLock(b);
                        }

                        String fieldConversion = atts.getValue(tags.getTagById(FIELD_CONVERSION));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_CONVERSION) + ": " + fieldConversion);
                        if (fieldConversion != null)
                        {
                            m_CurrentFLD.setFieldConversionClassName(fieldConversion);
                        }

                        
                        String length = atts.getValue(tags.getTagById(LENGTH));
                        if (length != null)
                        {
                            int i = Integer.parseInt(length);
                            if (isDebug) logger.debug("     " + tags.getTagById(LENGTH) + ": " + i);
                            m_CurrentFLD.setLength(i);
                            m_CurrentFLD.setLengthSpecified(true);
                        }

                        
                        String precision = atts.getValue(tags.getTagById(PRECISION));
                        if (precision != null)
                        {
                            int i = Integer.parseInt(precision);
                            if (isDebug) logger.debug("     " + tags.getTagById(PRECISION) + ": " + i);
                            m_CurrentFLD.setPrecision(i);
                            m_CurrentFLD.setPrecisionSpecified(true);
                        }

                        
                        String scale = atts.getValue(tags.getTagById(SCALE));
                        if (scale != null)
                        {
                            int i = Integer.parseInt(scale);
                            if (isDebug) logger.debug("     " + tags.getTagById(SCALE) + ": " + i);
                            m_CurrentFLD.setScale(i);
                            m_CurrentFLD.setScaleSpecified(true);
                        }

                        break;
                    }

                case REFERENCE_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(REFERENCE_DESCRIPTOR));
                        
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);

                        
                        String classRef = atts.getValue(tags.getTagById(REFERENCED_CLASS));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFERENCED_CLASS) + ": " + classRef);

                        ObjectReferenceDescriptor ord;
                        if (name.equals(TAG_SUPER))
                        {
                            






                            ord = new SuperReferenceDescriptor(m_CurrentCLD);
                        }
                        else
                        {
                            ord = new ObjectReferenceDescriptor(m_CurrentCLD);
                            PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                            ord.setPersistentField(pf);
                        }
                        m_CurrentORD = ord;

                        
                        m_CurrentCLD.addObjectReferenceDescriptor(m_CurrentORD);
                        m_CurrentORD.setItemClass(ClassHelper.getClass(classRef));

                        
                        this.m_CurrentAttrContainer = m_CurrentORD;

                        
                        String proxy = atts.getValue(tags.getTagById(PROXY_REFERENCE));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_REFERENCE) + ": " + proxy);
                        boolean b = (Boolean.valueOf(proxy)).booleanValue();
                        m_CurrentORD.setLazy(b);

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentORD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentORD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentORD.setRefresh(b);

                        
                        String autoRetrieve = atts.getValue(tags.getTagById(AUTO_RETRIEVE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_RETRIEVE) + ": " + autoRetrieve);
                        b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                        m_CurrentORD.setCascadeRetrieve(b);

                        
                        String autoUpdate = atts.getValue(tags.getTagById(AUTO_UPDATE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_UPDATE) + ": " + autoUpdate);
                        if(autoUpdate != null)
                        {
                            m_CurrentORD.setCascadingStore(autoUpdate);
                        }

                        
                        String autoDelete = atts.getValue(tags.getTagById(AUTO_DELETE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_DELETE) + ": " + autoDelete);

                        if(autoDelete != null)
                        {
                            m_CurrentORD.setCascadingDelete(autoDelete);
                        }

                        
                        String otmDependent = atts.getValue(tags.getTagById(OTM_DEPENDENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(OTM_DEPENDENT) + ": " + otmDependent);
                        b = (Boolean.valueOf(otmDependent)).booleanValue();
                        m_CurrentORD.setOtmDependent(b);

                        break;
                    }

                case FOREIGN_KEY:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FOREIGN_KEY));
                        String fieldIdRef = atts.getValue(tags.getTagById(FIELD_ID_REF));

                        if (fieldIdRef != null)
                        {
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_ID_REF) + ": " + fieldIdRef);

                            try
                            {
                                int fieldId;
                                fieldId = Integer.parseInt(fieldIdRef);
                                m_CurrentORD.addForeignKeyField(fieldId);
                            }
                            catch (NumberFormatException rex)
                            {
                                throw new MetadataException(tags.getTagById(FIELD_ID_REF)
                                        + " attribute must be an int. Found: "
                                        + fieldIdRef + ". Please check your repository file.", rex);
                            }
                        }
                        else
                        {
                            String fieldRef = atts.getValue(tags.getTagById(FIELD_REF));
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_REF) + ": " + fieldRef);
                            m_CurrentORD.addForeignKeyField(fieldRef);
                        }
                        break;
                    }

                case COLLECTION_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(COLLECTION_DESCRIPTOR));
                        m_CurrentCOD = new CollectionDescriptor(m_CurrentCLD);


                        
                        this.m_CurrentAttrContainer = m_CurrentCOD;

                        
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);
						PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                        m_CurrentCOD.setPersistentField(pf);

                        
                        String collectionClassName = atts.getValue(tags.getTagById(COLLECTION_CLASS));
                        if (collectionClassName != null)
                        {
                            if (isDebug) logger.debug("     " + tags.getTagById(COLLECTION_CLASS) + ": " + collectionClassName);
                            m_CurrentCOD.setCollectionClass(ClassHelper.getClass(collectionClassName));
                        }
                        
                        String elementClassRef = atts.getValue(tags.getTagById(ITEMS_CLASS));
                        if (isDebug) logger.debug("     " + tags.getTagById(ITEMS_CLASS) + ": " + elementClassRef);
                        if (elementClassRef != null)
                        {
                            m_CurrentCOD.setItemClass(ClassHelper.getClass(elementClassRef));
                        }

                        
                        String orderby = atts.getValue(tags.getTagById(ORDERBY));
                        String sort = atts.getValue(tags.getTagById(SORT));
                        if (isDebug) logger.debug("     " + tags.getTagById(SORT) + ": " + orderby + ", " + sort);
                        if (orderby != null)
                        {
                            m_CurrentCOD.addOrderBy(orderby, "ASC".equalsIgnoreCase(sort));
                        }

                        
                        String indirectionTable = atts.getValue(tags.getTagById(INDIRECTION_TABLE));
                        if (isDebug) logger.debug("     " + tags.getTagById(INDIRECTION_TABLE) + ": " + indirectionTable);
                        m_CurrentCOD.setIndirectionTable(indirectionTable);

                        
                        String proxy = atts.getValue(tags.getTagById(PROXY_REFERENCE));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_REFERENCE) + ": " + proxy);
                        boolean b = (Boolean.valueOf(proxy)).booleanValue();
                        m_CurrentCOD.setLazy(b);

                        
                        String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                        if (proxyPrefetchingLimit == null)
                        {
                            m_CurrentCOD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                        }
                        else
                        {
                            m_CurrentCOD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                        }

                        
                        String refresh = atts.getValue(tags.getTagById(REFRESH));
                        if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                        b = (Boolean.valueOf(refresh)).booleanValue();
                        m_CurrentCOD.setRefresh(b);

                        
                        String autoRetrieve = atts.getValue(tags.getTagById(AUTO_RETRIEVE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_RETRIEVE) + ": " + autoRetrieve);
                        b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                        m_CurrentCOD.setCascadeRetrieve(b);

                        
                        String autoUpdate = atts.getValue(tags.getTagById(AUTO_UPDATE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_UPDATE) + ": " + autoUpdate);
                        if(autoUpdate != null)
                        {
                            m_CurrentCOD.setCascadingStore(autoUpdate);
                        }

                        
                        String autoDelete = atts.getValue(tags.getTagById(AUTO_DELETE));
                        if (isDebug) logger.debug("     " + tags.getTagById(AUTO_DELETE) + ": " + autoDelete);
                        if(autoDelete != null)
                        {
                            m_CurrentCOD.setCascadingDelete(autoDelete);
                        }

                        
                        String otmDependent = atts.getValue(tags.getTagById(OTM_DEPENDENT));
                        if (isDebug) logger.debug("     " + tags.getTagById(OTM_DEPENDENT) + ": " + otmDependent);
                        b = (Boolean.valueOf(otmDependent)).booleanValue();
                        m_CurrentCOD.setOtmDependent(b);

                        m_CurrentCLD.addCollectionDescriptor(m_CurrentCOD);

                        break;
                    }
                case ORDERBY :
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(ORDERBY));
                        name = atts.getValue(tags.getTagById(FIELD_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);
                        String sort = atts.getValue(tags.getTagById(SORT));
                        if (isDebug) logger.debug("     " + tags.getTagById(SORT) + ": " + name + ", " + sort);

                        m_CurrentCOD.addOrderBy(name, "ASC".equalsIgnoreCase(sort));
                        break;
                    }
                case INVERSE_FK:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(INVERSE_FK));
                        String fieldIdRef = atts.getValue(tags.getTagById(FIELD_ID_REF));

                        if (fieldIdRef != null)
                        {
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_ID_REF) + ": " + fieldIdRef);

                            try
                            {
                                int fieldId;
                                fieldId = Integer.parseInt(fieldIdRef);
                                m_CurrentCOD.addForeignKeyField(fieldId);
                            }
                            catch (NumberFormatException rex)
                            {
                                throw new MetadataException(tags.getTagById(FIELD_ID_REF)
                                        + " attribute must be an int. Found: "
                                        + fieldIdRef + " Please check your repository file.", rex);
                            }
                        }
                        else
                        {
                            String fieldRef = atts.getValue(tags.getTagById(FIELD_REF));
                            if (isDebug) logger.debug("      " + tags.getTagById(FIELD_REF) + ": " + fieldRef);
                            m_CurrentCOD.addForeignKeyField(fieldRef);
                        }
                        break;
                    }

                case FK_POINTING_TO_THIS_CLASS:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FK_POINTING_TO_THIS_CLASS));
                        String column = atts.getValue("column");
                        if (isDebug) logger.debug("      " + "column" + ": " + column);
                        m_CurrentCOD.addFkToThisClass(column);
                        break;
                    }

                case FK_POINTING_TO_ITEMS_CLASS:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(FK_POINTING_TO_ITEMS_CLASS));
                        String column = atts.getValue("column");
                        if (isDebug) logger.debug("      " + "column" + ": " + column);
                        m_CurrentCOD.addFkToItemClass(column);
                        break;
                    }
                case ATTRIBUTE:
                    {
                        
                        String attributeName = atts.getValue(tags.getTagById(ATTRIBUTE_NAME));
                        String attributeValue = atts.getValue(tags.getTagById(ATTRIBUTE_VALUE));
                        
                        if (this.m_CurrentAttrContainer != null)
                        {
                            if (isDebug) logger.debug("      > " + tags.getTagById(ATTRIBUTE));
                            if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_NAME) + ": " + attributeName);
                            if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_VALUE) + ": " + attributeValue);
                            this.m_CurrentAttrContainer.addAttribute(attributeName, attributeValue);
                        }
                        else
                        {


                        }
                        break;
                    }









                    case QUERY_CUSTOMIZER:
                        {
                            
                            String className = atts.getValue("class");
                            QueryCustomizer queryCust;

                            if (className != null)
                            {
                                if (isDebug) logger.debug("     " + "class" + ": " + className);
                                queryCust = (QueryCustomizer)ClassHelper.newInstance(className);
                                m_CurrentAttrContainer = queryCust;
                                m_CurrentCOD.setQueryCustomizer(queryCust);
                            }
                            break;
                        }
                    case INDEX_DESCRIPTOR:
                        {
                            m_CurrentIndexDescriptor = new IndexDescriptor();
                            m_CurrentIndexDescriptor.setName(atts.getValue(tags.getTagById(NAME)));
                            m_CurrentIndexDescriptor.setUnique(Boolean.valueOf(atts.getValue(tags.getTagById(UNIQUE))).booleanValue());
                            break;
                        }
                    case INDEX_COLUMN:
                        {
                            m_CurrentIndexDescriptor.getIndexColumns().add(atts.getValue(tags.getTagById(NAME)));
                            break;
                        }
                    case INSERT_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(INSERT_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllFields = atts.getValue(tags.getTagById(INCLUDE_ALL_FIELDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_ALL_FIELDS) +
                                                  ": " + includeAllFields);

                        
                        InsertProcedureDescriptor proc =
                            new InsertProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;
                    }
                case UPDATE_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(UPDATE_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllFields = atts.getValue(tags.getTagById(INCLUDE_ALL_FIELDS));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_ALL_FIELDS) +
                                                  ": " + includeAllFields);

                        
                        UpdateProcedureDescriptor proc =
                            new UpdateProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;
                    }
                case DELETE_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(DELETE_PROCEDURE));

                        
                        String procName = atts.getValue(tags.getTagById(NAME));
                        String includeAllPkFields = atts.getValue(tags.getTagById(INCLUDE_PK_FIELDS_ONLY));
                        if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                  ": " + procName);
                        if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_PK_FIELDS_ONLY) +
                                                  ": " + includeAllPkFields);

                        
                        DeleteProcedureDescriptor proc =
                            new DeleteProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllPkFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                  ": " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;

                    }
                case CONSTANT_ARGUMENT:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(CONSTANT_ARGUMENT));
                        ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                        
                        String value = atts.getValue(tags.getTagById(VALUE));
                        if (isDebug) logger.debug("     " + tags.getTagById(VALUE) + ": " + value);

                        
                        arg.setValue(value);

                        
                        m_CurrentProcedure.addArgument(arg);
                        break;
                    }
                case RUNTIME_ARGUMENT:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(RUNTIME_ARGUMENT));
                        ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                        
                        String fieldRefName = atts.getValue(tags.getTagById(FIELD_REF));
                        if (isDebug) logger.debug("     " + tags.getTagById(FIELD_REF) +
                                                  ": " + fieldRefName);

                        
                        String returnValue = atts.getValue(tags.getTagById(RETURN));
                        if (isDebug) logger.debug("     " + tags.getTagById(RETURN) +
                                                  ": " + returnValue);

                        
                        if ((fieldRefName != null) && (fieldRefName.trim().length() != 0)) {
                            arg.setValue(fieldRefName,
                                         Boolean.valueOf(returnValue).booleanValue());
                        }

                        
                        m_CurrentProcedure.addArgument(arg);
                        break;
                    }

                default :
                    {
                        
                    }
            }
        }
        catch (Exception ex)
        {
            logger.error("Exception while read metadata", ex);
            if(ex instanceof MetadataException) throw (MetadataException)ex;
            else throw new MetadataException("Exception when reading metadata information,"+
                    " please check your repository.xml file", ex);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting RepositoryXmlHandler SAX Element Simulation...");
        method_1_ojb_gemini handler = new method_1_ojb_gemini();

        System.out.println("\n--- Scenario 1: Parsing <mapping-repository> ---");
        AttributesImpl mappingRepoAtts = new AttributesImpl();
        mappingRepoAtts.addAttribute("", "", "isolation-level", "CDATA", "read-committed");
        mappingRepoAtts.addAttribute("", "", "proxy-prefetching-limit", "CDATA", "20");
        mappingRepoAtts.addAttribute("", "", "version", "CDATA", "1.0"); 
        handler.startElement("", "mapping-repository", "mapping-repository", mappingRepoAtts);

        System.out.println("\n--- Scenario 2: Parsing <class-descriptor> ---");
        AttributesImpl classDescAtts = new AttributesImpl();
        classDescAtts.addAttribute("", "", "class-name", "CDATA", "java.lang.String");
        classDescAtts.addAttribute("", "", "table", "CDATA", "STRING_TABLE");
        classDescAtts.addAttribute("", "", "isolation-level", "CDATA", "serializable");
        classDescAtts.addAttribute("", "", "proxy", "CDATA", "dynamic");
        handler.startElement("", "class-descriptor", "class-descriptor", classDescAtts);

        System.out.println("\n--- Scenario 3: Parsing <field-descriptor> ---");
        AttributesImpl fieldDescAtts = new AttributesImpl();
        fieldDescAtts.addAttribute("", "", "name", "CDATA", "someField");
        fieldDescAtts.addAttribute("", "", "column", "CDATA", "SOME_FIELD_COL");
        fieldDescAtts.addAttribute("", "", "jdbc-type", "CDATA", "VARCHAR");
        fieldDescAtts.addAttribute("", "", "primarykey", "CDATA", "true");
        handler.startElement("", "field-descriptor", "field-descriptor", fieldDescAtts);
        
        System.out.println("\nExecution Complete.");
    }
}