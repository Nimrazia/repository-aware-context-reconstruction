



import org.xml.sax.Attributes;
import org.xml.sax.helpers.AttributesImpl;

import java.util.ArrayList;
import java.util.List;

public class method_2_ojb_gemini {

    
    
    
    
    
    
    
    public static final int JDBC_CONNECTION_DESCRIPTOR = 1;
    public static final int CONNECTION_POOL = 2;
    public static final int OBJECT_CACHE = 3;
    public static final int SEQUENCE_MANAGER = 4;
    public static final int ATTRIBUTE = 5;

    public static final int JCD_ALIAS = 101;
    public static final int DEFAULT_CONNECTION = 102;
    public static final int DBMS_NAME = 103;
    public static final int JDBC_LEVEL = 104;
    public static final int DRIVER_NAME = 105;
    public static final int URL_PROTOCOL = 106;
    public static final int URL_SUBPROTOCOL = 107;
    public static final int URL_DBALIAS = 108;
    public static final int DATASOURCE_NAME = 109;
    public static final int USER_NAME = 110;
    public static final int USER_PASSWD = 111;
    public static final int EAGER_RELEASE = 112;
    public static final int BATCH_MODE = 113;
    public static final int USE_AUTOCOMMIT = 114;
    public static final int IGNORE_AUTOCOMMIT_EXCEPTION = 115;

    public static final int CON_MAX_ACTIVE = 201;
    public static final int CON_MAX_IDLE = 202;
    public static final int CON_MAX_WAIT = 203;
    public static final int CON_MIN_EVICTABLE_IDLE_TIME_MILLIS = 204;
    public static final int CON_NUM_TESTS_PER_EVICTION_RUN = 205;
    public static final int CON_TEST_ON_BORROW = 206;
    public static final int CON_TEST_ON_RETURN = 207;
    public static final int CON_TEST_WHILE_IDLE = 208;
    public static final int CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS = 209;
    public static final int CON_WHEN_EXHAUSTED_ACTION = 210;
    public static final int CONNECTION_FACTORY = 211;
    public static final int VALIDATION_QUERY = 212;
    public static final int CON_LOG_ABANDONED = 213;
    public static final int CON_REMOVE_ABANDONED = 214;
    public static final int CON_REMOVE_ABANDONED_TIMEOUT = 215;

    public static final int CLASS_NAME = 301;
    public static final int SEQUENCE_MANAGER_CLASS = 302;
    public static final int ATTRIBUTE_NAME = 303;
    public static final int ATTRIBUTE_VALUE = 304;

    static class Logger {
        public boolean isDebugEnabled() { return true; }
        public void debug(String s) { System.out.println("DEBUG: " + s); }
        public void info(String s) { System.out.println("INFO: " + s); }
        public void error(Exception ex) { 
            System.out.println("ERROR: " + ex.getMessage()); 
            ex.printStackTrace(); 
        }
    }

    static class Tags {
        public String getTagById(int id) {
            switch(id) {
                case JDBC_CONNECTION_DESCRIPTOR: return "jdbc-connection-descriptor";
                case CONNECTION_POOL: return "connection-pool";
                case OBJECT_CACHE: return "object-cache";
                case SEQUENCE_MANAGER: return "sequence-manager";
                case ATTRIBUTE: return "attribute";
                case JCD_ALIAS: return "jcd-alias";
                case DEFAULT_CONNECTION: return "default-connection";
                case DBMS_NAME: return "platform";
                case JDBC_LEVEL: return "jdbc-level";
                case DRIVER_NAME: return "driver";
                case URL_PROTOCOL: return "protocol";
                case URL_SUBPROTOCOL: return "subprotocol";
                case URL_DBALIAS: return "dbalias";
                case DATASOURCE_NAME: return "datasource";
                case USER_NAME: return "username";
                case USER_PASSWD: return "password";
                case EAGER_RELEASE: return "eager-release";
                case BATCH_MODE: return "batch-mode";
                case USE_AUTOCOMMIT: return "useAutoCommit";
                case IGNORE_AUTOCOMMIT_EXCEPTION: return "ignoreAutoCommitExceptions";
                case CON_MAX_ACTIVE: return "maxActive";
                case CON_MAX_IDLE: return "maxIdle";
                case CON_MAX_WAIT: return "maxWait";
                case CLASS_NAME: return "class-name";
                case SEQUENCE_MANAGER_CLASS: return "className";
                case ATTRIBUTE_NAME: return "attribute-name";
                case ATTRIBUTE_VALUE: return "attribute-value";
                case CON_MIN_EVICTABLE_IDLE_TIME_MILLIS: return "minEvictableIdleTimeMillis";
                case CON_NUM_TESTS_PER_EVICTION_RUN: return "numTestsPerEvictionRun";
                case CON_TEST_ON_BORROW: return "testOnBorrow";
                case CON_TEST_ON_RETURN: return "testOnReturn";
                case CON_TEST_WHILE_IDLE: return "testWhileIdle";
                case CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS: return "timeBetweenEvictionRunsMillis";
                case CON_WHEN_EXHAUSTED_ACTION: return "whenExhaustedAction";
                case CONNECTION_FACTORY: return "connectionFactory";
                case VALIDATION_QUERY: return "validationQuery";
                case CON_LOG_ABANDONED: return "logAbandoned";
                case CON_REMOVE_ABANDONED: return "removeAbandoned";
                case CON_REMOVE_ABANDONED_TIMEOUT: return "removeAbandonedTimeout";
            }
            return "tag-" + id;
        }
    }

    interface AttributeContainer {
        void addAttribute(String name, String value);
    }

    static class ConnectionPoolDescriptor implements AttributeContainer {
        public void setMaxActive(int maxActive) {}
        public void setMaxIdle(int maxIdle) {}
        public void setMaxWait(int maxWait) {}
        public void setMinEvictableIdleTimeMillis(long l) {}
        public void setNumTestsPerEvictionRun(int i) {}
        public void setTestOnBorrow(boolean b) {}
        public void setTestOnReturn(boolean b) {}
        public void setTestWhileIdle(boolean b) {}
        public void setTimeBetweenEvictionRunsMillis(long l) {}
        public void setWhenExhaustedAction(byte b) {}
        public void setConnectionFactory(Class<?> c) {}
        public void setValidationQuery(String s) {}
        public void setLogAbandoned(boolean b) {}
        public void setRemoveAbandoned(boolean b) {}
        public void setRemoveAbandonedTimeout(int i) {}
        public void addAttribute(String name, String value) {
            System.out.println("ConnectionPoolDescriptor: added attribute " + name + "=" + value);
        }
    }

    static class ObjectCacheDescriptor implements AttributeContainer {
        public void setObjectCache(Class<?> cls) {}
        public void addAttribute(String name, String value) {
            System.out.println("ObjectCacheDescriptor: added attribute " + name + "=" + value);
        }
    }

    static class SequenceDescriptor implements AttributeContainer {
        public SequenceDescriptor(JdbcConnectionDescriptor jcd) {}
        public void setSequenceManagerClass(Class<?> cls) {}
        public void addAttribute(String name, String value) {
            System.out.println("SequenceDescriptor: added attribute " + name + "=" + value);
        }
    }

    static class JdbcConnectionDescriptor implements AttributeContainer {
        private ConnectionPoolDescriptor cpd = new ConnectionPoolDescriptor();
        private ObjectCacheDescriptor ocd = new ObjectCacheDescriptor();
        private SequenceDescriptor sd;
        private String jcdAlias;
        private boolean defaultConnection;

        public void setJcdAlias(String jcdAlias) { this.jcdAlias = jcdAlias; }
        public String getJcdAlias() { return jcdAlias; }
        public void setDefaultConnection(boolean defaultConnection) { this.defaultConnection = defaultConnection; }
        public boolean isDefaultConnection() { return defaultConnection; }
        public void setDbms(String dbms) {}
        public void setJdbcLevel(String jdbcLevel) {}
        public void setDriver(String driver) {}
        public void setProtocol(String protocol) {}
        public void setSubProtocol(String subProtocol) {}
        public void setDbAlias(String dbAlias) {}
        public void setDatasourceName(String datasourceName) {}
        public void setUserName(String userName) {}
        public void setPassWord(String passWord) {}
        public void setEagerRelease(boolean eagerRelease) {}
        public void setBatchMode(boolean batchMode) {}
        public void setUseAutoCommit(int useAutoCommit) {}
        public void setIgnoreAutoCommitExceptions(boolean ignoreAutoCommitExceptions) {}
        
        public ConnectionPoolDescriptor getConnectionPoolDescriptor() { return cpd; }
        public ObjectCacheDescriptor getObjectCacheDescriptor() { return ocd; }
        public void setSequenceDescriptor(SequenceDescriptor sd) { this.sd = sd; }
        
        public void addAttribute(String name, String value) {
            System.out.println("JdbcConnectionDescriptor: added attribute " + name + "=" + value);
        }
    }

    static class ClassHelper {
        public static Class<?> getClass(String name) throws ClassNotFoundException { 
            return Class.forName(name); 
        }
    }

    static class PersistenceBrokerException extends RuntimeException {
        public PersistenceBrokerException(String msg) { super(msg); }
        public PersistenceBrokerException(Exception cause) { super(cause); }
    }
    
    static class MetadataException extends RuntimeException {
        public MetadataException(String msg) { super(msg); }
    }

    
    
    

    private Logger logger = new Logger();
    private Tags tags = new Tags();
    private AttributeContainer currentAttributeContainer;
    private SequenceDescriptor currentSequenceDescriptor;
    private JdbcConnectionDescriptor m_CurrentJCD;
    private List<JdbcConnectionDescriptor> conDesList = new ArrayList<>();
    private boolean defaultConnectionFound = false;

    private int getLiteralId(String qName) {
        if ("jdbc-connection-descriptor".equals(qName)) return JDBC_CONNECTION_DESCRIPTOR;
        if ("connection-pool".equals(qName)) return CONNECTION_POOL;
        if ("object-cache".equals(qName)) return OBJECT_CACHE;
        if ("sequence-manager".equals(qName)) return SEQUENCE_MANAGER;
        if ("attribute".equals(qName)) return ATTRIBUTE;
        return -1;
    }

    private boolean checkString(String str) {
        return str != null && str.trim().length() > 0;
    }


// ORIGINAL CODESEARCHNET METHOD — START

public void startElement(String uri, String name, String qName, Attributes atts)
    {
        boolean isDebug = logger.isDebugEnabled();
        try
        {
            switch (getLiteralId(qName))
            {
                case JDBC_CONNECTION_DESCRIPTOR:
                    {
                        if (isDebug) logger.debug("   > " + tags.getTagById(JDBC_CONNECTION_DESCRIPTOR));
                        JdbcConnectionDescriptor newJcd = new JdbcConnectionDescriptor();
                        currentAttributeContainer = newJcd;

                        conDesList.add(newJcd);
                        m_CurrentJCD = newJcd;

                        
                        String jcdAlias = atts.getValue(tags.getTagById(JCD_ALIAS));
                        if (isDebug) logger.debug("     " + tags.getTagById(JCD_ALIAS) + ": " + jcdAlias);
                        m_CurrentJCD.setJcdAlias(jcdAlias);

                        
                        String defaultConnection = atts.getValue(tags.getTagById(DEFAULT_CONNECTION));
                        if (isDebug) logger.debug("     " + tags.getTagById(DEFAULT_CONNECTION) + ": " + defaultConnection);
                        m_CurrentJCD.setDefaultConnection(Boolean.valueOf(defaultConnection).booleanValue());
                        if (m_CurrentJCD.isDefaultConnection())
                        {
                            if (defaultConnectionFound)
                            {
                                throw new MetadataException("Found two jdbc-connection-descriptor elements with default-connection=\"true\"");
                            }
                            else
                            {
                                defaultConnectionFound = true;
                            }
                        }

                        
                        String platform = atts.getValue(tags.getTagById(DBMS_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(DBMS_NAME) + ": " + platform);
                        m_CurrentJCD.setDbms(platform);

                        
                        String level = atts.getValue(tags.getTagById(JDBC_LEVEL));
                        if (isDebug) logger.debug("     " + tags.getTagById(JDBC_LEVEL) + ": " + level);
                        m_CurrentJCD.setJdbcLevel(level);

                        
                        String driver = atts.getValue(tags.getTagById(DRIVER_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(DRIVER_NAME) + ": " + driver);
                        m_CurrentJCD.setDriver(driver);

                        
                        String protocol = atts.getValue(tags.getTagById(URL_PROTOCOL));
                        if (isDebug) logger.debug("     " + tags.getTagById(URL_PROTOCOL) + ": " + protocol);
                        m_CurrentJCD.setProtocol(protocol);

                        
                        String subprotocol = atts.getValue(tags.getTagById(URL_SUBPROTOCOL));
                        if (isDebug) logger.debug("     " + tags.getTagById(URL_SUBPROTOCOL) + ": " + subprotocol);
                        m_CurrentJCD.setSubProtocol(subprotocol);

                        
                        String dbalias = atts.getValue(tags.getTagById(URL_DBALIAS));
                        if (isDebug) logger.debug("     " + tags.getTagById(URL_DBALIAS) + ": " + dbalias);
                        m_CurrentJCD.setDbAlias(dbalias);

                        
                        String datasource = atts.getValue(tags.getTagById(DATASOURCE_NAME));
                        
                        if(datasource != null && datasource.trim().equals("")) datasource = null;
                        if (isDebug) logger.debug("     " + tags.getTagById(DATASOURCE_NAME) + ": " + datasource);
                        m_CurrentJCD.setDatasourceName(datasource);

                        
                        String user = atts.getValue(tags.getTagById(USER_NAME));
                        if (isDebug) logger.debug("     " + tags.getTagById(USER_NAME) + ": " + user);
                        m_CurrentJCD.setUserName(user);

                        
                        String password = atts.getValue(tags.getTagById(USER_PASSWD));
                        if (isDebug) logger.debug("     " + tags.getTagById(USER_PASSWD) + ": " + password);
                        m_CurrentJCD.setPassWord(password);

                        
                        String eagerRelease = atts.getValue(tags.getTagById(EAGER_RELEASE));
                        if (isDebug) logger.debug("     " + tags.getTagById(EAGER_RELEASE) + ": " + eagerRelease);
                        m_CurrentJCD.setEagerRelease(Boolean.valueOf(eagerRelease).booleanValue());

                        
                        String batchMode = atts.getValue(tags.getTagById(BATCH_MODE));
                        if (isDebug) logger.debug("     " + tags.getTagById(BATCH_MODE) + ": " + batchMode);
                        m_CurrentJCD.setBatchMode(Boolean.valueOf(batchMode).booleanValue());

                        
                        String useAutoCommit = atts.getValue(tags.getTagById(USE_AUTOCOMMIT));
                        if (isDebug) logger.debug("     " + tags.getTagById(USE_AUTOCOMMIT) + ": " + useAutoCommit);
                        m_CurrentJCD.setUseAutoCommit(Integer.valueOf(useAutoCommit).intValue());

                        
                        String ignoreAutoCommitExceptions = atts.getValue(tags.getTagById(IGNORE_AUTOCOMMIT_EXCEPTION));
                        if (isDebug) logger.debug("     " + tags.getTagById(IGNORE_AUTOCOMMIT_EXCEPTION) + ": " + ignoreAutoCommitExceptions);
                        m_CurrentJCD.setIgnoreAutoCommitExceptions(Boolean.valueOf(ignoreAutoCommitExceptions).booleanValue());

                        break;
                    }
                case CONNECTION_POOL:
                    {
                        if (m_CurrentJCD != null)
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(CONNECTION_POOL));
                            final ConnectionPoolDescriptor m_CurrentCPD = m_CurrentJCD.getConnectionPoolDescriptor();
                            this.currentAttributeContainer = m_CurrentCPD;

                            String maxActive = atts.getValue(tags.getTagById(CON_MAX_ACTIVE));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_ACTIVE) + ": " + maxActive);
                            if (checkString(maxActive)) m_CurrentCPD.setMaxActive(Integer.parseInt(maxActive));

                            String maxIdle = atts.getValue(tags.getTagById(CON_MAX_IDLE));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_IDLE) + ": " + maxIdle);
                            if (checkString(maxIdle)) m_CurrentCPD.setMaxIdle(Integer.parseInt(maxIdle));

                            String maxWait = atts.getValue(tags.getTagById(CON_MAX_WAIT));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_WAIT) + ": " + maxWait);
                            if (checkString(maxWait)) m_CurrentCPD.setMaxWait(Integer.parseInt(maxWait));

                            String minEvictableIdleTimeMillis = atts.getValue(tags.getTagById(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS) + ": " + minEvictableIdleTimeMillis);
                            if (checkString(minEvictableIdleTimeMillis)) m_CurrentCPD.setMinEvictableIdleTimeMillis(Long.parseLong(minEvictableIdleTimeMillis));

                            String numTestsPerEvictionRun = atts.getValue(tags.getTagById(CON_NUM_TESTS_PER_EVICTION_RUN));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_NUM_TESTS_PER_EVICTION_RUN) + ": " + numTestsPerEvictionRun);
                            if (checkString(numTestsPerEvictionRun)) m_CurrentCPD.setNumTestsPerEvictionRun(Integer.parseInt(numTestsPerEvictionRun));

                            String testOnBorrow = atts.getValue(tags.getTagById(CON_TEST_ON_BORROW));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_ON_BORROW) + ": " + testOnBorrow);
                            if (checkString(testOnBorrow)) m_CurrentCPD.setTestOnBorrow(Boolean.valueOf(testOnBorrow).booleanValue());

                            String testOnReturn = atts.getValue(tags.getTagById(CON_TEST_ON_RETURN));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_ON_RETURN) + ": " + testOnReturn);
                            if (checkString(testOnReturn)) m_CurrentCPD.setTestOnReturn(Boolean.valueOf(testOnReturn).booleanValue());

                            String testWhileIdle = atts.getValue(tags.getTagById(CON_TEST_WHILE_IDLE));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_WHILE_IDLE) + ": " + testWhileIdle);
                            if (checkString(testWhileIdle)) m_CurrentCPD.setTestWhileIdle(Boolean.valueOf(testWhileIdle).booleanValue());

                            String timeBetweenEvictionRunsMillis = atts.getValue(tags.getTagById(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS) + ": " + timeBetweenEvictionRunsMillis);
                            if (checkString(timeBetweenEvictionRunsMillis)) m_CurrentCPD.setTimeBetweenEvictionRunsMillis(Long.parseLong(timeBetweenEvictionRunsMillis));

                            String whenExhaustedAction = atts.getValue(tags.getTagById(CON_WHEN_EXHAUSTED_ACTION));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_WHEN_EXHAUSTED_ACTION) + ": " + whenExhaustedAction);
                            if (checkString(whenExhaustedAction)) m_CurrentCPD.setWhenExhaustedAction(Byte.parseByte(whenExhaustedAction));

                            String connectionFactoryStr = atts.getValue(tags.getTagById(CONNECTION_FACTORY));
                            if (isDebug) logger.debug("     " + tags.getTagById(CONNECTION_FACTORY) + ": " + connectionFactoryStr);
                            if (checkString(connectionFactoryStr)) m_CurrentCPD.setConnectionFactory(ClassHelper.getClass(connectionFactoryStr));

                            String validationQuery = atts.getValue(tags.getTagById(VALIDATION_QUERY));
                            if (isDebug) logger.debug("     " + tags.getTagById(VALIDATION_QUERY) + ": " + validationQuery);
                            if (checkString(validationQuery)) m_CurrentCPD.setValidationQuery(validationQuery);

                            
                            String logAbandoned = atts.getValue(tags.getTagById(CON_LOG_ABANDONED));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_LOG_ABANDONED) + ": " + logAbandoned);
                            if (checkString(logAbandoned)) m_CurrentCPD.setLogAbandoned(Boolean.valueOf(logAbandoned).booleanValue());

                            String removeAbandoned = atts.getValue(tags.getTagById(CON_REMOVE_ABANDONED));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_REMOVE_ABANDONED) + ": " + removeAbandoned);
                            if (checkString(removeAbandoned)) m_CurrentCPD.setRemoveAbandoned(Boolean.valueOf(removeAbandoned).booleanValue());

                            String removeAbandonedTimeout = atts.getValue(tags.getTagById(CON_REMOVE_ABANDONED_TIMEOUT));
                            if (isDebug) logger.debug("     " + tags.getTagById(CON_REMOVE_ABANDONED_TIMEOUT) + ": " + removeAbandonedTimeout);
                            if (checkString(removeAbandonedTimeout)) m_CurrentCPD.setRemoveAbandonedTimeout(Integer.parseInt(removeAbandonedTimeout));
                        }
                        break;
                    }

                case OBJECT_CACHE:
                    {
                        String className = atts.getValue(tags.getTagById(CLASS_NAME));
                        if(checkString(className) && m_CurrentJCD != null)
                        {
                            ObjectCacheDescriptor ocd = m_CurrentJCD.getObjectCacheDescriptor();
                            this.currentAttributeContainer = ocd;
                            ocd.setObjectCache(ClassHelper.getClass(className));
                            if (isDebug) logger.debug("    > " + tags.getTagById(OBJECT_CACHE));
                            if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + className);
                        }
                        break;
                    }
                case SEQUENCE_MANAGER:
                    {
                        String className = atts.getValue(tags.getTagById(SEQUENCE_MANAGER_CLASS));
                        if(checkString(className))
                        {
                            this.currentSequenceDescriptor = new SequenceDescriptor(this.m_CurrentJCD);
                            this.currentAttributeContainer = currentSequenceDescriptor;
                            this.m_CurrentJCD.setSequenceDescriptor(this.currentSequenceDescriptor);
                            if (isDebug) logger.debug("    > " + tags.getTagById(SEQUENCE_MANAGER));
                            if (isDebug) logger.debug("     " + tags.getTagById(SEQUENCE_MANAGER_CLASS) + ": " + className);
                            if (checkString(className)) currentSequenceDescriptor.setSequenceManagerClass(ClassHelper.getClass(className));
                        }
                        break;
                    }
                case ATTRIBUTE:
                    {
                        
                        String attributeName = atts.getValue(tags.getTagById(ATTRIBUTE_NAME));
                        String attributeValue = atts.getValue(tags.getTagById(ATTRIBUTE_VALUE));

                        
                        if (this.currentAttributeContainer != null)
                        {

                            if (checkString(attributeName))
                            {
                                if (isDebug) logger.debug("      > " + tags.getTagById(ATTRIBUTE));
                                if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_NAME) + ": " + attributeName
                                        + "  "+tags.getTagById(ATTRIBUTE_VALUE) + ": " + attributeValue);
                                this.currentAttributeContainer.addAttribute(attributeName, attributeValue);

                            }
                            else
                            {
                                logger.info("Found 'null' or 'empty' attribute object for element "+currentAttributeContainer.getClass() +
                                        " attribute-name=" + attributeName + ", attribute-value=" + attributeValue+
                                        " See jdbc-connection-descriptor with jcdAlias '"+m_CurrentJCD.getJcdAlias()+"'");
                            }
                        }






                        break;
                    }
                default :
                    {
                        
                    }
            }
        }
        catch (Exception ex)
        {
            logger.error(ex);
            throw new PersistenceBrokerException(ex);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting ConnectionDescriptorXmlHandler SAX Element Simulation...\n");
        method_2_ojb_gemini handler = new method_2_ojb_gemini();

        System.out.println("--- Scenario 1: Parsing <jdbc-connection-descriptor> ---");
        AttributesImpl jdbcAtts = new AttributesImpl();
        jdbcAtts.addAttribute("", "", "jcd-alias", "CDATA", "default");
        jdbcAtts.addAttribute("", "", "default-connection", "CDATA", "true");
        jdbcAtts.addAttribute("", "", "platform", "CDATA", "Hsqldb");
        jdbcAtts.addAttribute("", "", "driver", "CDATA", "org.hsqldb.jdbcDriver");
        jdbcAtts.addAttribute("", "", "protocol", "CDATA", "jdbc");
        jdbcAtts.addAttribute("", "", "subprotocol", "CDATA", "hsqldb");
        jdbcAtts.addAttribute("", "", "useAutoCommit", "CDATA", "1");
        handler.startElement("", "jdbc-connection-descriptor", "jdbc-connection-descriptor", jdbcAtts);

        System.out.println("\n--- Scenario 2: Parsing <connection-pool> ---");
        AttributesImpl poolAtts = new AttributesImpl();
        poolAtts.addAttribute("", "", "maxActive", "CDATA", "21");
        poolAtts.addAttribute("", "", "testOnBorrow", "CDATA", "true");
        handler.startElement("", "connection-pool", "connection-pool", poolAtts);

        System.out.println("\n--- Scenario 3: Parsing <object-cache> ---");
        AttributesImpl cacheAtts = new AttributesImpl();
        cacheAtts.addAttribute("", "", "class-name", "CDATA", "java.util.HashMap");
        handler.startElement("", "object-cache", "object-cache", cacheAtts);

        System.out.println("\n--- Scenario 4: Parsing <sequence-manager> ---");
        AttributesImpl seqAtts = new AttributesImpl();
        seqAtts.addAttribute("", "", "className", "CDATA", "java.lang.Object");
        handler.startElement("", "sequence-manager", "sequence-manager", seqAtts);

        System.out.println("\n--- Scenario 5: Parsing <attribute> inside sequence-manager ---");
        AttributesImpl attrAtts = new AttributesImpl();
        attrAtts.addAttribute("", "", "attribute-name", "CDATA", "seq.start");
        attrAtts.addAttribute("", "", "attribute-value", "CDATA", "100");
        handler.startElement("", "attribute", "attribute", attrAtts);

        System.out.println("\nExecution Complete. Parsed descriptors count: " + handler.conDesList.size());
    }
}