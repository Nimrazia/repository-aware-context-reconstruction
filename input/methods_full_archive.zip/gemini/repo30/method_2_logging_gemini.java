import java.util.Collection;
import java.util.Collections;
import java.util.logging.Logger;




public class method_2_logging_gemini {

    public static class Layout {}

    public static class Level {
        public static final Level INFO = new Level();
    }

    public static class MDC {
        private static final java.util.Map<String, Object> VALUES = new java.util.HashMap<String, Object>();
        public static Object get(String key) { return VALUES.get(key); }
        public static void put(String key, Object value) { VALUES.put(key, value); }
        public static void remove(String key) { VALUES.remove(key); }
    }

    public static class LoggingEvent {
        private final Object message;
        public LoggingEvent(String fqcn, java.util.logging.Logger logger, Level level, Object message, Throwable throwable) {
            this.message = message;
        }
        public Object getMessage() { return message; }
    }

    public static class ApplicationState {
        public static final String FQCN = ApplicationState.class.getName();
        public static final Logger LOGGER = Logger.getLogger(ApplicationState.class.getName());
        
        public static class ApplicationStateMessage {
            public String getLevel() { return "INFO"; }
            public String getMessage() { return "System Memory Status: Optimal"; }
        }

        public static Collection<ApplicationStateMessage> getAppStateEntries() {
            return Collections.singletonList(new ApplicationStateMessage());
        }

        public static Level getLog4jLevel(String levelName) {
            return Level.INFO;
        }
    }

    public interface FoundationFileRollingAppender {
        Layout getLayout();
        void setLayout(Layout layout);
        boolean isAddApplicationState();
        String getFile();
    }

    public static class FileRollEvent {
        private FoundationFileRollingAppender appender = new FoundationFileRollingAppender() {
            public Layout getLayout() { return null; }
            public void setLayout(Layout l) {}
            public boolean isAddApplicationState() { return true; }
            public String getFile() { return "app-rolling.log"; }
        };
        public FoundationFileRollingAppender getSource() { return appender; }
        public void dispatchToAppender(LoggingEvent event) {
            System.out.println("Dispatched State Logging Event: " + event.getMessage());
        }
    }

    private void logState(final FileRollEvent fileRollEvent) {
        synchronized (this) {
            final Collection<ApplicationState.ApplicationStateMessage> entries = ApplicationState.getAppStateEntries();
            for (ApplicationState.ApplicationStateMessage entry : entries) {
                Level level = ApplicationState.getLog4jLevel(entry.getLevel());
                final LoggingEvent loggingEvent = new LoggingEvent(ApplicationState.FQCN, ApplicationState.LOGGER, level, entry.getMessage(), null);

                Layout current = fileRollEvent.getSource().getLayout();
                String flowContext = (String) MDC.get("flowCtxt");
                MDC.remove("flowCtxt");
                
                if(fileRollEvent.getSource().isAddApplicationState() && fileRollEvent.getSource().getFile().endsWith("log")){
                    fileRollEvent.dispatchToAppender(loggingEvent);
                }
                
                fileRollEvent.getSource().setLayout(current);
                if (flowContext != null) {
                    MDC.put("flowCtxt", flowContext);
                }
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("Executing Method 2: FoundationRollEventListener.logState()");
        method_2_logging_gemini listener = new method_2_logging_gemini();
        listener.logState(new FileRollEvent());
        System.out.println("Method 2 Execution Complete.\n");
    }
}