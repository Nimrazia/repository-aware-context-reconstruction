import java.util.HashMap;
import java.util.Map.Entry;




public class method_7_logging_gemini {

    protected static final String TOTAL_COMPONENT = "TOTAL_COMPONENT";
    protected HashMap<String, Component> components = new HashMap<>();
    protected Component total = new Component();

    public static class Component {
        public long getTime() { return 125L; }
    }

    protected void addTimePerComponent(HashMap<String, Long> map, Component c) {
        map.put("DatabaseExecutionComponent", c.getTime());
    }

    protected void putProperty(String key, String value) {
        System.out.println("Transaction Property Recorded -> [" + key + " : " + value + "]");
    }

    protected String addDuration(long time) { 
        return time + "ms"; 
    }

    protected void addPropertiesProcessingTime() {
        HashMap<String, Long> mapComponentTimes = new HashMap<>();
        HashMap<String, Long> mapComponentInvocations = new HashMap<>();

        for (Component component : this.components.values()) {
            addTimePerComponent(mapComponentTimes, component);
        }

        for (Entry<String, Long> entry : mapComponentTimes.entrySet()) {
            putProperty(entry.getKey(), addDuration(entry.getValue()));
        }

        putProperty(TOTAL_COMPONENT, addDuration(this.total.getTime()));
    }

    public static void main(String[] args) {
        System.out.println("Executing Method 7: addPropertiesProcessingTime()");
        method_7_logging_gemini logger = new method_7_logging_gemini();
        logger.components.put("db", new Component());
        logger.addPropertiesProcessingTime();
        System.out.println("Method 7 Execution Complete.\n");
    }
}