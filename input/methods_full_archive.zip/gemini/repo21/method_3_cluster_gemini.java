



import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class method_3_cluster_gemini {

    
    
    

    public static class Logger {
        public boolean isDebugEnabled() { return true; }
        public void debug(String msg) { System.out.println("DEBUG: " + msg); }
    }

    public static class SetTimerAfterTxCommitRunnable {
        public void cancel() { System.out.println("INFO: Tx Set action cancelled."); }
    }

    public static class TimerTask {
        private String id;
        private SetTimerAfterTxCommitRunnable setTimerAction;
        public TimerTask(String id) { this.id = id; }
        public SetTimerAfterTxCommitRunnable getSetTimerTransactionalAction() { return setTimerAction; }
        public void setSetTimerTransactionalAction(SetTimerAfterTxCommitRunnable a) { this.setTimerAction = a; }
        @Override
        public String toString() { return "TimerTask[" + id + "]"; }
    }

    public static class TimerTaskCacheData {
        public TimerTaskCacheData(Serializable id, String baseFqn, Object cluster) {}
        public void remove() { System.out.println("INFO: Removed task from cache."); }
    }

    public static abstract class AfterTxCommitRunnable {
        public TimerTask task;
        public AfterTxCommitRunnable(TimerTask task) { this.task = task; }
        public abstract void run();
    }

    public static class CancelTimerAfterTxCommitRunnable extends AfterTxCommitRunnable {
        private FaultTolerantScheduler scheduler;
        public CancelTimerAfterTxCommitRunnable(TimerTask task, FaultTolerantScheduler scheduler) {
            super(task);
            this.scheduler = scheduler;
        }
        @Override
        public void run() { System.out.println("INFO: Actually executed task cancellation."); }
    }

    public interface Transaction {
        void registerSynchronization(TransactionSynchronization sync);
    }

    public static class MockTransaction implements Transaction {
        public void registerSynchronization(TransactionSynchronization sync) {}
    }

    public interface TransactionManager {
        Transaction getTransaction();
    }

    public static class MockTransactionManager implements TransactionManager {
        public Transaction getTransaction() { return new MockTransaction(); }
    }

    public static class TransactionContext {
        private Map<Serializable, AfterTxCommitRunnable> contextMap = new HashMap<>();
        public void put(Serializable key, AfterTxCommitRunnable runnable) {
            System.out.println("INFO: Registered runnable in Transaction Context for key: " + key);
            contextMap.put(key, runnable);
        }
        public AfterTxCommitRunnable remove(Serializable key) {
            return contextMap.remove(key);
        }
    }

    public static class TransactionContextThreadLocal {
        private static final ThreadLocal<TransactionContext> tl = new ThreadLocal<>();
        public static TransactionContext getTransactionContext() { return tl.get(); }
        public static void setTransactionContext(TransactionContext c) { tl.set(c); }
    }

    public static class TransactionSynchronization {
        public TransactionSynchronization(TransactionContext ctx) {}
    }

    
    
    

    public static class FaultTolerantScheduler {
        private Logger logger = new Logger();
        private Map<Serializable, TimerTask> localRunningTasks = new HashMap<>();
        private String baseFqn = "/timers";
        private Object cluster = new Object();
        private TransactionManager txManager = new MockTransactionManager();

        public void addTask(Serializable id, TimerTask task) {
            localRunningTasks.put(id, task);
        }


// ORIGINAL CODESEARCHNET METHOD — START

public TimerTask cancel(Serializable taskID) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Canceling task with timer id "+taskID);
		}
		
		TimerTask task = localRunningTasks.get(taskID);
		if (task != null) {
			
			new TimerTaskCacheData(taskID, baseFqn, cluster).remove();

			final SetTimerAfterTxCommitRunnable setAction = task.getSetTimerTransactionalAction();
			if (setAction != null) {
				
				setAction.cancel();
			}
			else {
				
				AfterTxCommitRunnable runnable = new CancelTimerAfterTxCommitRunnable(task,this);
				if (txManager != null) {
					try {
						Transaction tx = txManager.getTransaction();
						if (tx != null) {
							TransactionContext txContext = TransactionContextThreadLocal.getTransactionContext();
							if (txContext == null) {
								txContext = new TransactionContext();
								tx.registerSynchronization(new TransactionSynchronization(txContext));
							}
							txContext.put(taskID, runnable);					
						}
						else {
							runnable.run();
						}
					}
					catch (Throwable e) {
						throw new RuntimeException("Unable to register tx synchronization object",e);
					}
				}
				else {
					runnable.run();
				}			
			}		
		}
		else {
			
			
			if (txManager != null) {
				try {
					Transaction tx = txManager.getTransaction();
					if (tx != null) {
						TransactionContext txContext = TransactionContextThreadLocal.getTransactionContext();
						if (txContext != null) {
							final AfterTxCommitRunnable r = txContext.remove(taskID);
							if (r != null) {
								task = r.task;
								
								new TimerTaskCacheData(taskID, baseFqn, cluster).remove();
							}							
						}											
					}
				}
				catch (Throwable e) {
					throw new RuntimeException("Failed to check tx context.",e);
				}
			}			
		}
		
		return task;
	}

// ORIGINAL CODESEARCHNET METHOD — END

    }

    public static void main(String[] args) {
        System.out.println("Starting FaultTolerantScheduler cancel Simulation...\n");

        FaultTolerantScheduler scheduler = new FaultTolerantScheduler();
        TransactionContextThreadLocal.setTransactionContext(null); 

        System.out.println("--- Scenario 1: Cancel task with SetTimerAction ---");
        TimerTask task1 = new TimerTask("task-1");
        task1.setSetTimerTransactionalAction(new SetTimerAfterTxCommitRunnable());
        scheduler.addTask("task-1", task1);
        scheduler.cancel("task-1");

        System.out.println("\n--- Scenario 2: Cancel task without SetTimerAction (Tx active) ---");
        TimerTask task2 = new TimerTask("task-2");
        scheduler.addTask("task-2", task2);
        scheduler.cancel("task-2");

        System.out.println("\n--- Scenario 3: Cancel unknown task locally, but present in TxContext ---");
        TransactionContext ctx = new TransactionContext();
        ctx.put("task-3", new CancelTimerAfterTxCommitRunnable(new TimerTask("task-3"), scheduler));
        TransactionContextThreadLocal.setTransactionContext(ctx);
        TimerTask returnedTask = scheduler.cancel("task-3");
        System.out.println("INFO: Cancelled unknown local task but found in TxContext: " + returnedTask);

        System.out.println("\nExecution Complete.");
    }
}