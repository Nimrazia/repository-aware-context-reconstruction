



import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class method_2_cluster_gemini {

    
    
    

    public enum PeriodicScheduleStrategy {
        withFixedDelay, defaultRate
    }

    public static class Logger {
        public boolean isDebugEnabled() { return true; }
        public void debug(String msg) { System.out.println("DEBUG: " + msg); }
        public void error(String msg, Throwable e) { System.out.println("ERROR: " + msg); }
    }

    public static class TimerTaskData {
        private String taskID;
        private long startTime;
        private long period;
        private PeriodicScheduleStrategy periodicScheduleStrategy;

        public TimerTaskData(String taskID, long startTime, long period, PeriodicScheduleStrategy strategy) {
            this.taskID = taskID;
            this.startTime = startTime;
            this.period = period;
            this.periodicScheduleStrategy = strategy;
        }

        public String getTaskID() { return taskID; }
        public long getStartTime() { return startTime; }
        public long getPeriod() { return period; }
        public PeriodicScheduleStrategy getPeriodicScheduleStrategy() { return periodicScheduleStrategy; }
    }

    public static class TimerTask implements Runnable {
        private TimerTaskData data;
        private ScheduledFuture<?> scheduledFuture;
        
        public TimerTask(TimerTaskData data) { this.data = data; }
        public void setSetTimerTransactionalAction(Object action) {}
        public TimerTaskData getData() { return data; }
        public void setScheduledFuture(ScheduledFuture<?> scheduledFuture) { this.scheduledFuture = scheduledFuture; }
        
        @Override
        public void run() { System.out.println("Timer task executed: " + data.getTaskID()); }
    }

    public static class FaultTolerantScheduler {
        private ConcurrentMap<String, TimerTask> localRunningTasksMap = new ConcurrentHashMap<>();
        private ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

        public ConcurrentMap<String, TimerTask> getLocalRunningTasksMap() { return localRunningTasksMap; }
        public ScheduledExecutorService getExecutor() { return executor; }
        public void remove(String taskID, boolean b) {
            System.out.println("Removed task: " + taskID);
            localRunningTasksMap.remove(taskID);
        }
        
        public void shutdown() { executor.shutdownNow(); }
    }

    
    
    

    public static class SetTimerAfterTxCommitRunnable implements Runnable {
        private TimerTask task;
        private FaultTolerantScheduler scheduler;
        private boolean canceled = false;
        private Logger logger = new Logger();

        public SetTimerAfterTxCommitRunnable(TimerTask task, FaultTolerantScheduler scheduler) {
            this.task = task;
            this.scheduler = scheduler;
        }


// ORIGINAL CODESEARCHNET METHOD — START

public void run() {
		
		task.setSetTimerTransactionalAction(null);
		
		if (!canceled) {
			
			TimerTask previousTask = scheduler.getLocalRunningTasksMap().putIfAbsent(task.getData().getTaskID(), task);
			if(previousTask != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("A task with id " + task.getData().getTaskID() + " has already been added to the local tasks, not rescheduling");
				}
			}
			
			final TimerTaskData taskData = task.getData();
			
			long delay = taskData.getStartTime() - System.currentTimeMillis();
			if (delay < 0) {
				delay = 0;
			}
			
			try {
				
				if (taskData.getPeriod() < 0) {
					if (logger.isDebugEnabled()) {
						logger.debug("Scheduling one-shot timer with id "
								+ task.getData().getTaskID() + ", delay " + delay);
					}
					task.setScheduledFuture(scheduler.getExecutor().schedule(task, delay, TimeUnit.MILLISECONDS));
				} else {
					if (logger.isDebugEnabled()) {
						logger.debug("Scheduling periodic timer with id "
								+ task.getData().getTaskID() + ", scheduling strategy " + taskData.getPeriodicScheduleStrategy() + ", delay " + delay + ", period " + taskData.getPeriod());
					}
					if (taskData.getPeriodicScheduleStrategy() == PeriodicScheduleStrategy.withFixedDelay) {
						task.setScheduledFuture(scheduler.getExecutor().scheduleWithFixedDelay(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
					}
					else {
						
						task.setScheduledFuture(scheduler.getExecutor().scheduleAtFixedRate(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
					}					
				}		
			} catch (Throwable e) {
				logger.error(e.getMessage(), e);
				scheduler.remove(taskData.getTaskID(),true);
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("Canceled scheduling periodic timer with id "
						+ task.getData().getTaskID());
			}
		}
	}

// ORIGINAL CODESEARCHNET METHOD — END

    }

    public static void main(String[] args) {
        System.out.println("Starting SetTimerAfterTxCommitRunnable Simulation...\n");

        FaultTolerantScheduler scheduler = new FaultTolerantScheduler();
        
        System.out.println("--- Scenario 1: One-Shot Timer ---");
        TimerTaskData data1 = new TimerTaskData("task-1", System.currentTimeMillis() + 100, -1, null);
        TimerTask task1 = new TimerTask(data1);
        SetTimerAfterTxCommitRunnable runnable1 = new SetTimerAfterTxCommitRunnable(task1, scheduler);
        runnable1.run();

        System.out.println("\n--- Scenario 2: Periodic Timer ---");
        TimerTaskData data2 = new TimerTaskData("task-2", System.currentTimeMillis() + 100, 500, PeriodicScheduleStrategy.withFixedDelay);
        TimerTask task2 = new TimerTask(data2);
        SetTimerAfterTxCommitRunnable runnable2 = new SetTimerAfterTxCommitRunnable(task2, scheduler);
        runnable2.run();

        
        try { Thread.sleep(200); } catch (InterruptedException e) {}
        
        scheduler.shutdown();
        System.out.println("\nExecution Complete.");
    }
}