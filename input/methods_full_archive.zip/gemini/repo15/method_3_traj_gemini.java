




import java.awt.geom.Point2D;
import java.util.*;

public class method_3_traj_gemini {

    
    public enum SeriesLineStyle { NONE, DASH_DASH }
    public enum SeriesType { Line }
    public enum SeriesMarker { NONE }

    public static class Series {
        public void setLineStyle(SeriesLineStyle style) {}
        public void setSeriesType(SeriesType type) {}
        public void setMarker(SeriesMarker marker) {}
    }

    public static class Chart {
        public Series addSeries(String name, double[] x, double[] y) {
            System.out.println("DEBUG: Chart added series '" + name + "' with " + x.length + " points.");
            return new Series();
        }
    }

    public static class QuickChart {
        public static Chart getChart(String title, String xlabel, String ylabel, String yname, double[] x, double[] y) {
            System.out.println("DEBUG: QuickChart created chart titled '" + title + "'");
            return new Chart();
        }
    }

    public static class SwingWrapper {
        private Chart chart;
        public SwingWrapper(Chart chart) { this.chart = chart; }
        public void displayChart() {
            System.out.println("DEBUG: SwingWrapper displayed chart window successfully (headless mock).");
        }
    }

    public static interface PolynomialSplineFunction {
        int getN();
        double value(double v);
        double[] getKnots();
    }

    public static class TrajectoryPoint {
        public double x, y, z;
        public TrajectoryPoint(double x, double y, double z) {
            this.x = x; this.y = y; this.z = z;
        }
    }

    public static class Trajectory extends ArrayList<TrajectoryPoint> {
        private static final long serialVersionUID = 1L;
        public int getDimension() { return 2; }
        public void add(double x, double y, double z) {
            super.add(new TrajectoryPoint(x, y, z));
        }
    }

    private Trajectory rotatedTrajectory = new Trajectory();
    private List<Point2D.Double> splineSupportPoints = new ArrayList<Point2D.Double>();
    private PolynomialSplineFunction spline;

    public method_3_traj_gemini() {
        
        for (int i = 0; i < 10; i++) {
            rotatedTrajectory.add(i * 1.0, Math.sin(i * 0.5) * 2.0, 0);
        }
        splineSupportPoints.add(new Point2D.Double(0.0, 0.0));
        splineSupportPoints.add(new Point2D.Double(5.0, 1.5));
        splineSupportPoints.add(new Point2D.Double(9.0, 0.0));

        spline = new PolynomialSplineFunction() {
            public int getN() { return 2; }
            public double value(double v) { return Math.sin(v * 0.5); }
            public double[] getKnots() { return new double[]{0.0, 4.5, 9.0}; }
        };
    }


// ORIGINAL CODESEARCHNET METHOD — START

public void showTrajectoryAndSpline(){
		
		if(t.getDimension()==2){
		 	double[] xData = new double[rotatedTrajectory.size()];
		    double[] yData = new double[rotatedTrajectory.size()];
		    for(int i = 0; i < rotatedTrajectory.size(); i++){
		    	xData[i] = rotatedTrajectory.get(i).x;
		    	yData[i] = rotatedTrajectory.get(i).y;		    	
		    }
		    
		    Chart chart = QuickChart.getChart("Spline+Track", "X", "Y", "y(x)", xData, yData);
		    
		    
		    double[] subxData  = new double[splineSupportPoints.size()];
		    double[] subyData  = new double[splineSupportPoints.size()];
		    
		    for(int i = 0; i < splineSupportPoints.size(); i++){
		    	subxData[i] = splineSupportPoints.get(i).x;
		    	subyData[i] = splineSupportPoints.get(i).y;
		    }
		    Series s = chart.addSeries("Spline Support Points", subxData, subyData);
		    s.setLineStyle(SeriesLineStyle.NONE);
		    s.setSeriesType(SeriesType.Line);
		    
		    
		    int numberInterpolatedPointsPerSegment = 20;
		    int numberOfSplines = spline.getN();
		    double[] sxData = new double[numberInterpolatedPointsPerSegment*numberOfSplines];
		    
		    double[] syData = new double[numberInterpolatedPointsPerSegment*numberOfSplines];
		    double[] knots = spline.getKnots();
		    for(int i = 0; i < numberOfSplines; i++){
		    	double x = knots[i];
		   
		    	double stopx = knots[i+1];
		    	double dx = (stopx-x)/numberInterpolatedPointsPerSegment;
		    	
		    	for(int j = 0; j < numberInterpolatedPointsPerSegment; j++){

		    		sxData[i*numberInterpolatedPointsPerSegment+j] = x;
		    		syData[i*numberInterpolatedPointsPerSegment+j] = spline.value(x);
		    		x += dx;
		    	}
		    	
		    }
		    s = chart.addSeries("Spline", sxData, syData);
		    s.setLineStyle(SeriesLineStyle.DASH_DASH);
		    s.setMarker(SeriesMarker.NONE);
		    s.setSeriesType(SeriesType.Line);
		   
		    
		    
		    new SwingWrapper(chart).displayChart();
		}	
	}

// ORIGINAL CODESEARCHNET METHOD — END


    
    private Trajectory t = new Trajectory() {
        public int getDimension() { return 2; }
    };

    public static void main(String[] args) {
        System.out.println("Starting TrajectorySplineFit showTrajectoryAndSpline Simulation...\n");
        method_3_traj_gemini fit = new method_3_traj_gemini();
        fit.showTrajectoryAndSpline();
        System.out.println("\nExecution Complete.");
    }
}