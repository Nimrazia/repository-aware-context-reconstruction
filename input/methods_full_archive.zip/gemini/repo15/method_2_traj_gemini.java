




import java.awt.geom.Point2D;
import java.util.*;

public class method_2_traj_gemini {

    
    public static class StandardDeviation {
        private double[] data;
        public void setData(double[] data) { this.data = data; }
        public double evaluate() {
            if (data == null || data.length == 0) return 0.0;
            double sum = 0;
            for (double d : data) sum += d;
            double mean = sum / data.length;
            double var = 0;
            for (double d : data) var += (d - mean) * (d - mean);
            return Math.sqrt(var / data.length);
        }
    }

    public static interface PolynomialSplineFunction {
        int getN();
        double value(double v);
    }

    public static class SplineInterpolator {
        public PolynomialSplineFunction interpolate(double[] x, double[] y) {
            return new PolynomialSplineFunction() {
                public int getN() { return x.length - 1; }
                public double value(double v) { return y[0]; }
            };
        }
    }

    public static class TrajectoryPoint {
        public double x, y, z;
        public TrajectoryPoint(double x, double y, double z) {
            this.x = x; this.y = y; this.z = z;
        }
    }

    public static class Trajectory extends ArrayList<TrajectoryPoint> {
        private static final long serialVersionUID = 1L;
        public void add(double x, double y, double z) {
            super.add(new TrajectoryPoint(x, y, z));
        }
    }

    public static class RotatingCalipers {
        public static Point2D.Double[] getMinimumBoundingRectangle(ArrayList<Point2D.Double> points) {
            return new Point2D.Double[]{
                new Point2D.Double(0, 10),
                new Point2D.Double(10, 10),
                new Point2D.Double(0, 0),
                new Point2D.Double(10, 0)
            };
        }
    }

    public static class Vector2d {
        public double x, y;
        public Vector2d(double x, double y) { this.x = x; this.y = y; }
        public void normalize() {
            double len = Math.sqrt(x * x + y * y);
            if (len != 0) { x /= len; y /= len; }
        }
        public void scale(double factor) { x *= factor; y *= factor; }
    }

    public static class KeySizeException extends Exception { private static final long serialVersionUID = 1L; }
    public static class KeyDuplicateException extends Exception { private static final long serialVersionUID = 1L; }

    public static class KDTree<T> {
        private Map<String, T> map = new HashMap<String, T>();
        public KDTree(int dims) {}
        public void insert(double[] key, T val) throws KeySizeException, KeyDuplicateException {
            map.put(key[0] + "," + key[1], val);
        }
        public List<T> nearestEuclidean(double[] center, double radius) throws KeySizeException {
            return new ArrayList<T>(map.values());
        }
    }

    private static boolean isLeft(Point2D.Double a, Point2D.Double b, Point2D.Double c) {
        return true;
    }

    private static double distancePointLine(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        return 1.0;
    }

    private static Point2D.Double projectPointToLine(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        return new Point2D.Double(p.x, p1.y);
    }

    private static Point2D.Double minDistancePointToLine(Point2D.Double p1, Point2D.Double p2, ArrayList<Point2D.Double> points) {
        return points.get(0);
    }

    private Trajectory t;
    private Trajectory rotatedTrajectory = new Trajectory();
    private int nSegments = 5;
    private double angleRotated;
    private List<Point2D.Double> splineSupportPoints;
    private PolynomialSplineFunction spline;

    public method_2_traj_gemini(Trajectory t) { this.t = t; }


// ORIGINAL CODESEARCHNET METHOD — START

public PolynomialSplineFunction calculateSpline(){
		
		
		


		ArrayList<Point2D.Double> points = new ArrayList<Point2D.Double>();
		for(int i = 0; i < t.size(); i++){
			Point2D.Double p = new Point2D.Double();
			p.setLocation(t.get(i).x, t.get(i).y);
			points.add(p);
		}
		Point2D.Double[] rect = null;
		try{
			rect = RotatingCalipers.getMinimumBoundingRectangle(points);
		}
		catch(IllegalArgumentException e)
		{
		
		}
		catch(EmptyStackException e){
		
		}
		
		


		
		Point2D.Double majorDirection = null;
		
		Point2D.Double p1 = rect[2]; 
		Point2D.Double p2 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[1] : rect[3]; 
		Point2D.Double p3 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[3] : rect[1]; 
		majorDirection = new Point2D.Double(p2.x-p1.x, p2.y-p1.y);
		double width = p1.distance(p2);
		double inRad = -1*Math.atan2(majorDirection.y, majorDirection.x);

		boolean doTransform = (Math.abs(Math.abs(inRad)-Math.PI)>0.001);

		if(doTransform)
		{
			angleRotated = inRad;
			for(int i = 0; i < t.size(); i++){
				double x = t.get(i).x;
				double y = t.get(i).y;
				double newX = x*Math.cos(inRad)-y*Math.sin(inRad);
				double newY = x*Math.sin(inRad)+y*Math.cos(inRad);
				rotatedTrajectory.add(newX, newY, 0);
				points.get(i).setLocation(newX, newY);
			}
			for(int i = 0; i < rect.length; i++){
				rect[i].setLocation(rect[i].x*Math.cos(inRad)-rect[i].y*Math.sin(inRad), rect[i].x*Math.sin(inRad)+rect[i].y*Math.cos(inRad));
			}

			p1 = rect[2]; 
			p2 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[1] : rect[3]; 
			p3 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[3] : rect[1]; 
		}
		else{
			angleRotated = 0;
			rotatedTrajectory = t;
		}
		
		






		List<List<Point2D.Double>> pointsInSegments =null;
		boolean allSegmentsContainingAtLeastTwoPoints = true;
		do{
			
			allSegmentsContainingAtLeastTwoPoints = true;
			double segmentWidth = p1.distance(p2)/nSegments;
			pointsInSegments = new ArrayList<List<Point2D.Double>>(nSegments);
			for(int i = 0; i < nSegments; i++){
				pointsInSegments.add(new ArrayList<Point2D.Double>());
			}
			for(int i = 0; i < points.size(); i++){
				Point2D.Double projPoint  = projectPointToLine(p1, p2, points.get(i));
				int index = (int)(p1.distance(projPoint)/segmentWidth);
				
				if(index>(nSegments-1)){
					index = (nSegments-1);
				}
				pointsInSegments.get(index).add(points.get(i));
			}
			
			for(int i = 0; i < pointsInSegments.size(); i++){
				if(pointsInSegments.get(i).size()<2){
					if(nSegments>2){
						nSegments--;
						i = pointsInSegments.size();
						allSegmentsContainingAtLeastTwoPoints = false;
				
					}
				}
			}
		}while(allSegmentsContainingAtLeastTwoPoints==false);
		
		
		


		
		Point2D.Double eMajorP1 = new Point2D.Double(p1.x - (p3.x-p1.x)/2.0,p1.y - (p3.y-p1.y)/2.0); 
		Point2D.Double eMajorP2 = new Point2D.Double(p2.x - (p3.x-p1.x)/2.0,p2.y - (p3.y-p1.y)/2.0); 
		double sumMean=0;
		int Nsum = 0;
		for(int i = 0; i < nSegments; i++){
			StandardDeviation sd = new StandardDeviation();
			double[] distances = new double[pointsInSegments.get(i).size()];
			for(int j = 0; j < pointsInSegments.get(i).size(); j++){
				int factor = 1;
				if(isLeft(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j))){
					factor = -1;
				}
				distances[j] = factor*distancePointLine(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j));
			}
			if(distances.length >0){
				sd.setData(distances);
	
				sumMean += sd.evaluate();
			
				Nsum++;
			}
		}
		double s = sumMean/Nsum;
		if(s<0.000000000001){
			s = width/nSegments;
		}
	
		


		KDTree<Point2D.Double> kdtree = new KDTree<Point2D.Double>(2);
		
		for(int i = 0; i< points.size(); i++){
			try {
				

				kdtree.insert(new double[]{points.get(i).x,points.get(i).y}, points.get(i));
			} catch (KeySizeException e) {
				e.printStackTrace();
			} catch (KeyDuplicateException e) {
				
			}
			
		}
		
		



		List<Point2D.Double> near = null;
		
		Point2D.Double first = minDistancePointToLine(p1, p3, points);
		double r1 = 3*s;
		try {
			
			near = kdtree.nearestEuclidean(new double[]{first.x ,first.y}, r1);
			
		} catch (KeySizeException e) {
			e.printStackTrace();
		} 

		double cx = 0;
		double cy = 0;
		for(int i = 0; i < near.size(); i++){
			cx += near.get(i).x;
			cy += near.get(i).y;
		}
		cx /= near.size();
		cy /= near.size();

		splineSupportPoints = new ArrayList<Point2D.Double>();
		splineSupportPoints.add(new Point2D.Double(cx, cy));
		
		





		
		


		
		
		



		int nCircleSegments = 100;
		double deltaRad = 2*Math.PI/nCircleSegments;
		boolean stop = false;
		int minN = 2; 
		double tempr1 = r1;
		double allowedDeltaDirection = 0.5*Math.PI;
				
		while(stop==false){
			List<Point2D.Double> nearestr1 = null;
			List<Point2D.Double> nearest2xr1 = null;
			try {
				nearestr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},tempr1);
				nearest2xr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},2*tempr1);
			} catch (KeySizeException e) {
				
				e.printStackTrace();
			}
			nearest2xr1.removeAll(nearestr1);
			
			double lThreshRad = 0;
			double hThreshRad = Math.PI/2;
			double stopThresh = 2*Math.PI;
			if(splineSupportPoints.size()>1){
				double directionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				lThreshRad = directionInRad - allowedDeltaDirection/2 - Math.PI/4; 
				if(lThreshRad<0){
					lThreshRad = 2*Math.PI+lThreshRad;
				}
				if(lThreshRad>2*Math.PI){
					lThreshRad = lThreshRad - 2*Math.PI;
				}
				hThreshRad = directionInRad + allowedDeltaDirection/2 + Math.PI/4; 
				if(hThreshRad<0){
					hThreshRad = 2*Math.PI+hThreshRad;
				}
				if(hThreshRad>2*Math.PI){
					hThreshRad = hThreshRad - 2*Math.PI;
				}
				stopThresh = directionInRad + allowedDeltaDirection/2 - Math.PI/4; 
				if(stopThresh>2*Math.PI){
					stopThresh = stopThresh - 2*Math.PI;
				}
				
			}
			
			double newCx=0;
			double newCy=0;
			int newCN = 0;
			int candN = 0;
			
			
			double lastDist = 0;
			double newDist = 0;
			do{ 
				lastDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));

				candN=0;
				double candCx =0;
				double candCy =0;
			
				for(int i = 0; i < nearest2xr1.size(); i++){
					Point2D.Double centerOfCircle = splineSupportPoints.get(splineSupportPoints.size()-1);
					Vector2d relativeToCircle = new Vector2d(nearest2xr1.get(i).x-centerOfCircle.x,nearest2xr1.get(i).y-centerOfCircle.y);
					relativeToCircle.normalize();
					double angleInRadians = Math.atan2(relativeToCircle.y, relativeToCircle.x)+Math.PI;

					if(lThreshRad<hThreshRad){
						if(angleInRadians>lThreshRad && angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}	
					}
					else{
						if(angleInRadians>lThreshRad || angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}
					}
					
								
				}
				
				if(candN>0 && candN > newCN ){
					candCx /= candN;
					candCy /= candN;
					newCx = candCx;
					newCy = candCy;
					newCN = candN;
				}
				lThreshRad += deltaRad;
				hThreshRad += deltaRad;
				if(lThreshRad>2*Math.PI){
					lThreshRad = lThreshRad - 2*Math.PI;
				}
				if(hThreshRad>2*Math.PI){
					hThreshRad = hThreshRad - 2*Math.PI;
				}
				newDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));
			
			}while((newDist-lastDist)>0);
			
			
			
			if(splineSupportPoints.size()>1){
				double currentDirectionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				double candDirectionInRad = Math.atan2(newCy-splineSupportPoints.get(splineSupportPoints.size()-1).y,
						newCx-splineSupportPoints.get(splineSupportPoints.size()-1).x)+Math.PI;
				double dDir = Math.max(currentDirectionInRad, candDirectionInRad)-Math.min(currentDirectionInRad, candDirectionInRad);
				if(dDir>2*Math.PI){
					dDir = 2*Math.PI-dDir;
				}
				if(dDir>allowedDeltaDirection){

					stop = true;
				}
			}
			boolean enoughPoints = (newCN<minN);
			boolean isNormalRadius = Math.abs(tempr1-r1)<Math.pow(10, -18);
			boolean isExtendedRadius = Math.abs(tempr1-3*r1)<Math.pow(10, -18);
			
			if(enoughPoints&& isNormalRadius){
				
				tempr1 = 3*r1;
			}
			else if(enoughPoints && isExtendedRadius){
				
				stop = true;
			}
			else if(stop==false){
				splineSupportPoints.add(new Point2D.Double(newCx,newCy));
				tempr1 = r1;
			}
            
            if(splineSupportPoints.size() > 5) stop = true;
			
		}

		
				Collections.sort(splineSupportPoints, new Comparator<Point2D.Double>() {

					public int compare(Point2D.Double o1, Point2D.Double o2) {
						if(o1.x<o2.x){
							return -1;
						}
						if(o1.x>o2.x){
							return 1;
						}
						return 0;
					}
				});
				
	
		
		
		if(splineSupportPoints.size()>1){
			Vector2d start = new Vector2d(splineSupportPoints.get(0).x-splineSupportPoints.get(1).x, splineSupportPoints.get(0).y-splineSupportPoints.get(1).y);
			start.normalize();
			start.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+start.x, splineSupportPoints.get(0).y+start.y));
			
			Vector2d end = new Vector2d(splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x, 
					splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y);
			end.normalize();
			end.scale(r1*6);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+end.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+end.y));
		}
		else{
			Vector2d majordir = new Vector2d(-1, 0);
			majordir.normalize();
			majordir.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+majordir.x, splineSupportPoints.get(0).y+majordir.y));
			majordir.scale(-1);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+majordir.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+majordir.y));
		

		}
		
		
		
		
		
		double[] supX = new double[splineSupportPoints.size()];
		double[] supY = new double[splineSupportPoints.size()];
		for(int i = 0; i < splineSupportPoints.size(); i++){
			supX[i] = splineSupportPoints.get(i).x;
			supY[i] = splineSupportPoints.get(i).y;
		}
		
		SplineInterpolator sIinter = new SplineInterpolator();
		spline = sIinter.interpolate(supX, supY);
		
		return spline;
	}

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        System.out.println("Starting TrajectorySplineFitLegacy calculateSpline Simulation...\n");
        Trajectory trajectory = new Trajectory();
        for (int i = 0; i < 20; i++) {
            trajectory.add(i * 1.0, Math.cos(i * 0.5) * 2.0, 0);
        }
        method_2_traj_gemini fit = new method_2_traj_gemini(trajectory);
        PolynomialSplineFunction res = fit.calculateSpline();
        System.out.println("Legacy Spline calculated successfully! Number of segments: " + res.getN());
        System.out.println("Execution Complete.");
    }
}