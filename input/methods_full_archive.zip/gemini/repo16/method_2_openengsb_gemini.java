import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public class method_2_openengsb_gemini {

    static class Logger {
        static Logger getLogger(String name) { return new Logger(); }
        void warn(String message, Throwable throwable) {
            System.out.println("[WARN] " + message + ": " + throwable.getMessage());
        }
        void severe(String message) {
            System.out.println("[SEVERE] " + message);
        }
    }

    private static final Logger LOGGER = Logger.getLogger(method_2_openengsb_gemini.class.getName());
    private static final String FILEWRAPPER_FILENAME_SUFFIX = ".filename";

    
    static class Base64 {
        public static String encodeBase64String(byte[] data) {
            return java.util.Base64.getEncoder().encodeToString(data);
        }
    }

    
    public static class EDBConstants {
        public static final String MODEL_TYPE = "edbId";
        public static final String MODEL_TYPE_VERSION = "modelTypeVersion";
    }

    public static class EKBException extends RuntimeException {
        public EKBException(String msg, Throwable cause) { super(msg, cause); }
    }

    public static class FileWrapper {
        private String filename;
        private byte[] content;
        public FileWrapper(String filename, byte[] content) { this.filename = filename; this.content = content; }
        public String getFilename() { return filename; }
        public byte[] getContent() { return content; }
    }

    public static class OpenEngSBModelEntry {
        private String key;
        private Object value;
        private Class<?> type;
        public OpenEngSBModelEntry(String key, Object value, Class<?> type) {
            this.key = key; this.value = value; this.type = type;
        }
        public String getKey() { return key; }
        public Object getValue() { return value; }
        public Class<?> getType() { return type; }
    }

    public interface OpenEngSBModel {
        List<OpenEngSBModelEntry> toOpenEngSBModelEntries();
        String retrieveModelName();
        String retrieveModelVersion();
    }

    public static class EDBObject {
        private String oid;
        private Map<String, Object> entries = new HashMap<>();
        
        public EDBObject(String oid) { this.oid = oid; }
        public void putEDBObjectEntry(String key, Object value, Class<?> type) { entries.put(key, value); }
        public void putEDBObjectEntry(String key, Object value) { entries.put(key, value); }
        public String getOID() { return oid; }
        
        @Override
        public String toString() {
            return "EDBObject{oid='" + oid + "', entries=" + entries.size() + "}";
        }
    }

    public static class ConnectorInformation {
        private String domainId;
        private String connectorId;
        private String instanceId;
        public ConnectorInformation(String d, String c, String i) { domainId = d; connectorId = c; instanceId = i; }
        public String getDomainId() { return domainId; }
        public String getConnectorId() { return connectorId; }
        public String getInstanceId() { return instanceId; }
    }

    
    public static class ContextHolder {
        private static ContextHolder instance = new ContextHolder();
        public static ContextHolder get() { return instance; }
        public String getCurrentContextId() { return "test-context-id"; }
    }

    public static class ModelWrapper {
        private OpenEngSBModel model;
        public static ModelWrapper wrap(OpenEngSBModel model) {
            ModelWrapper wrapper = new ModelWrapper();
            wrapper.model = model;
            return wrapper;
        }
        public String getCompleteModelOID() {
            return "oid:" + model.retrieveModelName() + "/" + System.identityHashCode(model);
        }
    }

    
    private void fillEDBObjectWithEngineeringObjectInformation(EDBObject object, OpenEngSBModel model) throws IllegalAccessException {
        
        object.putEDBObjectEntry("engineering_info", "filled");
    }

    private String getEntryNameForList(String key, int i) {
        return key + "." + i;
    }

    private String getEntryNameForMapKey(String key, int i) {
        return key + "." + i + ".key";
    }

    private String getEntryNameForMapValue(String key, int i) {
        return key + "." + i + ".value";
    }


// ORIGINAL CODESEARCHNET METHOD — START

    private String convertSubModel(OpenEngSBModel model, List<EDBObject> objects, ConnectorInformation info) {
        String contextId = ContextHolder.get().getCurrentContextId();
        String oid = ModelWrapper.wrap(model).getCompleteModelOID();
        EDBObject object = new EDBObject(oid);
        try {
            fillEDBObjectWithEngineeringObjectInformation(object, model);
        } catch (IllegalAccessException e) {
            LOGGER.warn("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
            throw new EKBException("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
        }
        for (OpenEngSBModelEntry entry : model.toOpenEngSBModelEntries()) {
            if (entry.getValue() == null) {
                continue;
            } else if (entry.getType().equals(FileWrapper.class)) {
                try {
                    FileWrapper wrapper = (FileWrapper) entry.getValue();
                    String content = Base64.encodeBase64String(wrapper.getContent());
                    object.putEDBObjectEntry(entry.getKey(), content, String.class);
                    object.putEDBObjectEntry(entry.getKey() + FILEWRAPPER_FILENAME_SUFFIX,
                        wrapper.getFilename(), String.class);
                } catch (Exception e) { 
                    LOGGER.severe(e.getMessage());
                }
            } else if (OpenEngSBModel.class.isAssignableFrom(entry.getType())) {
                OpenEngSBModel temp = (OpenEngSBModel) entry.getValue();
                String subOid = convertSubModel(temp, objects, info);
                object.putEDBObjectEntry(entry.getKey(), subOid, String.class);
            } else if (List.class.isAssignableFrom(entry.getType())) {
                List<?> list = (List<?>) entry.getValue();
                if (list == null || list.size() == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < list.size(); i++) {
                    Object item = list.get(i);
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (entry.getType().isArray()) {
                Object[] array = (Object[]) entry.getValue();
                if (array == null || array.length == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < array.length; i++) {
                    Object item = array[i];
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (Map.class.isAssignableFrom(entry.getType())) {
                Map<?, ?> map = (Map<?, ?>) entry.getValue();
                if (map == null || map.size() == 0) {
                    continue;
                }
                Boolean keyIsModel = null;
                Boolean valueIsModel = null;
                int i = 0;
                for (Map.Entry<?, ?> ent : map.entrySet()) {
                    if (keyIsModel == null) {
                        keyIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getKey().getClass());
                    }
                    if (valueIsModel == null) {
                        valueIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getValue().getClass());
                    }
                    Object key = ent.getKey();
                    Object value = ent.getValue();
                    if (keyIsModel) {
                        key = convertSubModel((OpenEngSBModel) key, objects, info);
                    }
                    if (valueIsModel) {
                        value = convertSubModel((OpenEngSBModel) value, objects, info);
                    }
                    object.putEDBObjectEntry(getEntryNameForMapKey(entry.getKey(), i), key);
                    object.putEDBObjectEntry(getEntryNameForMapValue(entry.getKey(), i), value);
                    i++;
                }
            } else {
                object.putEDBObjectEntry(entry.getKey(), entry.getValue(), entry.getType());
            }
        }
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE, model.retrieveModelName());
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, model.retrieveModelVersion());
        object.putEDBObjectEntry("domainId", info.getDomainId());
        object.putEDBObjectEntry("connectorId", info.getConnectorId());
        object.putEDBObjectEntry("instanceId", info.getInstanceId());
        object.putEDBObjectEntry("contextId", contextId);
        objects.add(object);
        return oid;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    
    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" EDBConverter.convertSubModel Test       ");
        System.out.println("=========================================\n");

        method_2_openengsb_gemini converter = new method_2_openengsb_gemini();
        List<EDBObject> edbObjects = new ArrayList<>();
        ConnectorInformation info = new ConnectorInformation("test-domain", "test-connector", "test-instance");

        OpenEngSBModel mockModel = new OpenEngSBModel() {
            @Override
            public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
                List<OpenEngSBModelEntry> entries = new ArrayList<>();
                entries.add(new OpenEngSBModelEntry("prop1", "stringValue", String.class));
                
                Map<String, String> mapData = new HashMap<>();
                mapData.put("keyA", "valA");
                entries.add(new OpenEngSBModelEntry("mapProp", mapData, Map.class));
                
                entries.add(new OpenEngSBModelEntry("fileProp", new FileWrapper("doc.txt", "data".getBytes()), FileWrapper.class));
                return entries;
            }
            @Override public String retrieveModelName() { return "TestModel"; }
            @Override public String retrieveModelVersion() { return "1.0.0"; }
        };

        try {
            String returnedOid = converter.convertSubModel(mockModel, edbObjects, info);
            System.out.println("[SUCCESS] Model converted to EDBObjects.");
            System.out.println("-> Target OID: " + returnedOid);
            System.out.println("-> Objects Extracted: " + edbObjects.size());
            for(EDBObject obj : edbObjects) {
                System.out.println("   - " + obj.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\n=========================================");
    }
}