import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;




public class method_3_openengsb_gemini {

    
    public interface OpenEngSBModel {}

    public static class EKBCommit {
        private String revisionNumber = "rev-001";
        private String parentRevisionNumber = "rev-000";
        private String connectorId = "conn-123";
        private String domainId = "domain-abc";
        private String instanceId = "inst-999";
        
        private List<OpenEngSBModel> inserts = new ArrayList<>();
        private List<OpenEngSBModel> updates = new ArrayList<>();
        private List<OpenEngSBModel> deletes = new ArrayList<>();

        public String getRevisionNumber() { return revisionNumber; }
        public String getParentRevisionNumber() { return parentRevisionNumber; }
        public String getConnectorId() { return connectorId; }
        public String getDomainId() { return domainId; }
        public String getInstanceId() { return instanceId; }

        public List<OpenEngSBModel> getInserts() { return inserts; }
        public List<OpenEngSBModel> getUpdates() { return updates; }
        public List<OpenEngSBModel> getDeletes() { return deletes; }
    }

    public static class IndexCommit {
        private String commitId;
        private String parentCommitId;
        private String connectorId;
        private String domainId;
        private String instanceId;
        private Date timestamp;
        private String user;
        private String contextId;
        private Set<Class<?>> modelClasses;
        private Map<Class<?>, List<OpenEngSBModel>> inserts;
        private Map<Class<?>, List<OpenEngSBModel>> updates;
        private Map<Class<?>, List<OpenEngSBModel>> deletes;

        public void setCommitId(String commitId) { this.commitId = commitId; }
        public void setParentCommitId(String parentCommitId) { this.parentCommitId = parentCommitId; }
        public void setConnectorId(String connectorId) { this.connectorId = connectorId; }
        public void setDomainId(String domainId) { this.domainId = domainId; }
        public void setInstanceId(String instanceId) { this.instanceId = instanceId; }
        public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
        public void setUser(String user) { this.user = user; }
        public void setContextId(String contextId) { this.contextId = contextId; }
        public void setModelClasses(Set<Class<?>> modelClasses) { this.modelClasses = modelClasses; }
        public void setInserts(Map<Class<?>, List<OpenEngSBModel>> inserts) { this.inserts = inserts; }
        public void setUpdates(Map<Class<?>, List<OpenEngSBModel>> updates) { this.updates = updates; }
        public void setDeletes(Map<Class<?>, List<OpenEngSBModel>> deletes) { this.deletes = deletes; }

        public String getCommitId() { return commitId; }
        public Set<Class<?>> getModelClasses() { return modelClasses; }
    }

    
    private String getUser() { return "admin_user"; }
    private String getContextId() { return "global_context"; }

    @SafeVarargs
    private final Set<Class<?>> extractTypes(List<OpenEngSBModel>... lists) {
        Set<Class<?>> types = new HashSet<>();
        for (List<OpenEngSBModel> list : lists) {
            if (list != null) {
                for (OpenEngSBModel model : list) {
                    types.add(model.getClass());
                }
            }
        }
        return types;
    }

    private Map<Class<?>, List<OpenEngSBModel>> mapByClass(List<OpenEngSBModel> models) {
        Map<Class<?>, List<OpenEngSBModel>> map = new HashMap<>();
        if (models != null) {
            for (OpenEngSBModel model : models) {
                Class<?> clazz = model.getClass();
                map.computeIfAbsent(clazz, k -> new ArrayList<>()).add(model);
            }
        }
        return map;
    }


// ORIGINAL CODESEARCHNET METHOD — START

    public IndexCommit convert(EKBCommit ekbCommit) {
        IndexCommit commit = new IndexCommit();

        commit.setCommitId(ekbCommit.getRevisionNumber());
        commit.setParentCommitId(ekbCommit.getParentRevisionNumber());
        commit.setConnectorId(ekbCommit.getConnectorId());
        commit.setDomainId(ekbCommit.getDomainId());
        commit.setInstanceId(ekbCommit.getInstanceId());
        commit.setTimestamp(new Date());

        commit.setUser(getUser());
        commit.setContextId(getContextId());

        List<OpenEngSBModel> inserts = ekbCommit.getInserts();
        List<OpenEngSBModel> updates = ekbCommit.getUpdates();
        List<OpenEngSBModel> deletes = ekbCommit.getDeletes();

        Set<Class<?>> modelClasses = extractTypes(inserts, updates, deletes);

        commit.setModelClasses(modelClasses);

        commit.setInserts(mapByClass(inserts));
        commit.setUpdates(mapByClass(updates));
        commit.setDeletes(mapByClass(deletes));

        return commit;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    
    static class UserDataModel implements OpenEngSBModel {}
    static class ProjectDataModel implements OpenEngSBModel {}

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" CommitConverter.convert Test            ");
        System.out.println("=========================================\n");

        method_3_openengsb_gemini converter = new method_3_openengsb_gemini();
        EKBCommit ekbCommit = new EKBCommit();

        ekbCommit.getInserts().add(new UserDataModel());
        ekbCommit.getInserts().add(new UserDataModel());
        ekbCommit.getUpdates().add(new ProjectDataModel());

        try {
            IndexCommit result = converter.convert(ekbCommit);
            System.out.println("[SUCCESS] EKBCommit converted to IndexCommit.");
            System.out.println("-> Assigned Commit ID: " + result.getCommitId());
            System.out.println("-> Extracted Model Classes: ");
            for(Class<?> clazz : result.getModelClasses()) {
                System.out.println("   - " + clazz.getSimpleName());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\n=========================================");
    }
}