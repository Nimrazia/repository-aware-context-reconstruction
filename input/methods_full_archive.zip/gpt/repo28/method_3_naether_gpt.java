import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class method_3_naether_gpt {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    

    public static Model loadPOM(String pomPath, String localRepo, Collection<RemoteRepository> repositories) throws ProjectException {
        RepositoryClient repoClient = new RepositoryClient(localRepo);
        NaetherModelResolver resolver = new NaetherModelResolver(repoClient, repositories);

        ModelBuildingRequest req = new DefaultModelBuildingRequest();
        req.setProcessPlugins( false );
        req.setPomFile( new File(pomPath) );
        req.setModelResolver( resolver );
        req.setValidationLevel( ModelBuildingRequest.VALIDATION_LEVEL_MINIMAL );

        DefaultModelBuilder builder = (new DefaultModelBuilderFactory()).newInstance();
        try {
            return builder.build( req ).getEffectiveModel();
        } catch ( ModelBuildingException e ) {
            throw new ProjectException("Failed to build project from pom", e);
        }
    }

    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        File pom = new File("sample-pom.xml");
        try (FileWriter writer = new FileWriter(pom)) {
            writer.write("<project>\n");
            writer.write("  <modelVersion>4.0.0</modelVersion>\n");
            writer.write("  <groupId>com.example</groupId>\n");
            writer.write("  <artifactId>sample-app</artifactId>\n");
            writer.write("  <version>1.0.0</version>\n");
            writer.write("</project>\n");
        }

        List<RemoteRepository> repositories = Collections.singletonList(
                new RemoteRepository("central", "https://repo1.maven.org/maven2")
        );
        Model model = loadPOM(pom.getPath(), "build/local-repository", repositories);

        System.out.println("Effective model: " + model.getGroupId() + ":" +
                model.getArtifactId() + ":" + model.getVersion());
        System.out.println("Source POM: " + model.getPomFile().getPath());
        System.out.println("Configured repositories: " + model.getRepositoryCount());
        System.out.println("Plugins processed: " + model.isProcessPlugins());
        pom.delete();
    }

    static final class RemoteRepository {
        private final String id;
        private final String url;

        RemoteRepository(String id, String url) {
            this.id = id;
            this.url = url;
        }

        String getId() { return id; }
        String getUrl() { return url; }
    }

    static final class RepositoryClient {
        private final String localRepo;

        RepositoryClient(String localRepo) {
            this.localRepo = localRepo;
        }

        String getLocalRepo() {
            return localRepo;
        }
    }

    static final class NaetherModelResolver {
        private final RepositoryClient client;
        private final Collection<RemoteRepository> repositories;

        NaetherModelResolver(RepositoryClient client, Collection<RemoteRepository> repositories) {
            this.client = client;
            this.repositories = new ArrayList<RemoteRepository>(repositories);
        }

        RepositoryClient getClient() { return client; }
        Collection<RemoteRepository> getRepositories() { return repositories; }
    }

    interface ModelBuildingRequest {
        int VALIDATION_LEVEL_MINIMAL = 1;
        void setProcessPlugins(boolean value);
        void setPomFile(File file);
        void setModelResolver(NaetherModelResolver resolver);
        void setValidationLevel(int level);
    }

    static final class DefaultModelBuildingRequest implements ModelBuildingRequest {
        private boolean processPlugins;
        private File pomFile;
        private NaetherModelResolver resolver;
        private int validationLevel;

        public void setProcessPlugins(boolean value) { processPlugins = value; }
        public void setPomFile(File file) { pomFile = file; }
        public void setModelResolver(NaetherModelResolver resolver) { this.resolver = resolver; }
        public void setValidationLevel(int level) { validationLevel = level; }

        boolean isProcessPlugins() { return processPlugins; }
        File getPomFile() { return pomFile; }
        NaetherModelResolver getResolver() { return resolver; }
        int getValidationLevel() { return validationLevel; }
    }

    static final class DefaultModelBuilderFactory {
        DefaultModelBuilder newInstance() {
            return new DefaultModelBuilder();
        }
    }

    static final class DefaultModelBuilder {
        ModelBuildingResult build(ModelBuildingRequest request) throws ModelBuildingException {
            DefaultModelBuildingRequest req = (DefaultModelBuildingRequest) request;
            if (req.getPomFile() == null || !req.getPomFile().isFile()) {
                throw new ModelBuildingException("POM file does not exist");
            }
            try {
                String xml = read(req.getPomFile());
                Model model = new Model(
                        tag(xml, "groupId"),
                        tag(xml, "artifactId"),
                        tag(xml, "version"),
                        req.getPomFile(),
                        req.getResolver().getRepositories().size(),
                        req.isProcessPlugins()
                );
                return new ModelBuildingResult(model);
            } catch (IOException e) {
                throw new ModelBuildingException("Unable to read POM", e);
            }
        }

        private static String read(File file) throws IOException {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
            }
            return sb.toString();
        }

        private static String tag(String xml, String name) throws ModelBuildingException {
            String start = "<" + name + ">";
            String end = "</" + name + ">";
            int a = xml.indexOf(start);
            int b = xml.indexOf(end);
            if (a < 0 || b < 0 || b < a) {
                throw new ModelBuildingException("Missing required POM element: " + name);
            }
            return xml.substring(a + start.length(), b).trim();
        }
    }

    static final class ModelBuildingResult {
        private final Model model;

        ModelBuildingResult(Model model) {
            this.model = model;
        }

        Model getEffectiveModel() {
            return model;
        }
    }

    static final class Model {
        private final String groupId;
        private final String artifactId;
        private final String version;
        private final File pomFile;
        private final int repositoryCount;
        private final boolean processPlugins;

        Model(String groupId, String artifactId, String version, File pomFile,
              int repositoryCount, boolean processPlugins) {
            this.groupId = groupId;
            this.artifactId = artifactId;
            this.version = version;
            this.pomFile = pomFile;
            this.repositoryCount = repositoryCount;
            this.processPlugins = processPlugins;
        }

        String getGroupId() { return groupId; }
        String getArtifactId() { return artifactId; }
        String getVersion() { return version; }
        File getPomFile() { return pomFile; }
        int getRepositoryCount() { return repositoryCount; }
        boolean isProcessPlugins() { return processPlugins; }
    }

    static class ModelBuildingException extends Exception {
        ModelBuildingException(String message) { super(message); }
        ModelBuildingException(String message, Throwable cause) { super(message, cause); }
    }

    static final class ProjectException extends Exception {
        ProjectException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
