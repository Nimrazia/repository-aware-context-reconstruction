import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class method_4_naether_gpt {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    

    public static List<String> getLocalPaths( String localRepoPath, List<String> notations ) throws NaetherException {
        DefaultServiceLocator locator = new DefaultServiceLocator();
        SimpleLocalRepositoryManagerFactory factory = new SimpleLocalRepositoryManagerFactory();
        factory.initService( locator );

        LocalRepository localRepo = new LocalRepository(localRepoPath);
        LocalRepositoryManager manager = null;
        try {
            manager = factory.newInstance( localRepo );
        } catch (NoLocalRepositoryManagerException e) {
            throw new NaetherException( "Failed to initial local repository manage", e  );
        }

        List<String> localPaths = new ArrayList<String>();

        for ( String notation : notations ) {
            Dependency dependency = new Dependency(new DefaultArtifact(notation), "compile");
            File path = new File( localRepo.getBasedir(), manager.getPathForLocalArtifact( dependency.getArtifact() ) );
            localPaths.add( path.toString() );
        }

        return localPaths;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        List<String> paths = getLocalPaths(
                "build/local-repository",
                Arrays.asList(
                        "org.example:demo:1.0",
                        "com.acme:tool:jar:tests:2.1"
                )
        );
        System.out.println("Computed local paths: " + paths.size());
        for (String path : paths) {
            System.out.println(path);
        }
    }

    static final class DefaultServiceLocator {
        private boolean initialized;

        void markInitialized() {
            initialized = true;
        }

        boolean isInitialized() {
            return initialized;
        }
    }

    static final class SimpleLocalRepositoryManagerFactory {
        private DefaultServiceLocator locator;

        void initService(DefaultServiceLocator locator) {
            this.locator = locator;
            locator.markInitialized();
        }

        LocalRepositoryManager newInstance(LocalRepository repository)
                throws NoLocalRepositoryManagerException {
            if (locator == null || !locator.isInitialized()) {
                throw new NoLocalRepositoryManagerException("Factory service has not been initialized");
            }
            return new SimpleLocalRepositoryManager(repository);
        }
    }

    static final class LocalRepository {
        private final File basedir;

        LocalRepository(String path) {
            basedir = new File(path);
        }

        File getBasedir() {
            return basedir;
        }
    }

    interface Artifact {
        String getGroupId();
        String getArtifactId();
        String getExtension();
        String getClassifier();
        String getVersion();
    }

    static final class DefaultArtifact implements Artifact {
        private final String groupId;
        private final String artifactId;
        private final String extension;
        private final String classifier;
        private final String version;

        DefaultArtifact(String notation) {
            String[] parts = notation.split(":");
            if (parts.length == 3) {
                groupId = parts[0];
                artifactId = parts[1];
                extension = "jar";
                classifier = "";
                version = parts[2];
            } else if (parts.length == 5) {
                groupId = parts[0];
                artifactId = parts[1];
                extension = parts[2];
                classifier = parts[3];
                version = parts[4];
            } else {
                throw new IllegalArgumentException("Unsupported notation: " + notation);
            }
        }

        public String getGroupId() { return groupId; }
        public String getArtifactId() { return artifactId; }
        public String getExtension() { return extension; }
        public String getClassifier() { return classifier; }
        public String getVersion() { return version; }
    }

    static final class Dependency {
        private final Artifact artifact;
        private final String scope;

        Dependency(Artifact artifact, String scope) {
            this.artifact = artifact;
            this.scope = scope;
        }

        Artifact getArtifact() {
            return artifact;
        }

        String getScope() {
            return scope;
        }
    }

    interface LocalRepositoryManager {
        String getPathForLocalArtifact(Artifact artifact);
    }

    static final class SimpleLocalRepositoryManager implements LocalRepositoryManager {
        private final LocalRepository repository;

        SimpleLocalRepositoryManager(LocalRepository repository) {
            this.repository = repository;
        }

        public String getPathForLocalArtifact(Artifact artifact) {
            String classifier = artifact.getClassifier().isEmpty()
                    ? ""
                    : "-" + artifact.getClassifier();
            return artifact.getGroupId().replace('.', File.separatorChar)
                    + File.separator + artifact.getArtifactId()
                    + File.separator + artifact.getVersion()
                    + File.separator + artifact.getArtifactId()
                    + "-" + artifact.getVersion()
                    + classifier
                    + "." + artifact.getExtension();
        }
    }

    static final class NoLocalRepositoryManagerException extends Exception {
        NoLocalRepositoryManagerException(String message) {
            super(message);
        }
    }

    static final class NaetherException extends Exception {
        NaetherException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
