import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class method_2_naether_gpt {

    private final String localRepoPath;
    private final List<RemoteRepository> remoteRepositories = new ArrayList<RemoteRepository>();
    private final Log log = new Log();

    public method_2_naether_gpt(String localRepoPath) {
        this.localRepoPath = localRepoPath;
    }

    public String getLocalRepoPath() {
        return localRepoPath;
    }

    public List<RemoteRepository> getRemoteRepositories() {
        return Collections.unmodifiableList(remoteRepositories);
    }

    public void addRemoteRepository(RemoteRepository repository) {
        remoteRepositories.add(repository);
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    

    @SuppressWarnings("rawtypes")
    public List<File> downloadArtifacts( List artifactsOrNotations ) throws NaetherException {

        List<Artifact> artifacts = new ArrayList<Artifact>();

        for ( Object artifactsOrNotation : artifactsOrNotations ) {
            if ( artifactsOrNotation != null ) {
                if ( artifactsOrNotation instanceof String ) {
                    artifacts.add( new DefaultArtifact( (String) artifactsOrNotation ) );
                } else if ( artifactsOrNotation instanceof Artifact ) {
                    artifacts.add( (Artifact)artifactsOrNotation );
                } else {
                    throw new NaetherException( "Only String notations or Artifact instances allowed. Found " + artifactsOrNotation.getClass() );
                }
            } else {
                log.warn( "Null found in list of artifacts to download" );
            }
        }

        List<File> files = new ArrayList<File>();

        for ( Artifact artifact : artifacts ) {

            log.debug( "Downloading {}", artifact );

            ArtifactRequest artifactRequest = new ArtifactRequest();
            artifactRequest.setArtifact( artifact );
            for ( RemoteRepository repo : this.getRemoteRepositories() ) {
                artifactRequest.addRepository( repo );
            }

            RepositoryClient repoClient = new RepositoryClient(this.getLocalRepoPath());

            ArtifactResult artifactResult = null;
            try {
                artifactResult = repoClient.resolveArtifact(artifactRequest );
            } catch (ArtifactResolutionException e) {
                throw new ResolveException(e);
            }

            Artifact downloadedArtifact = artifactResult.getArtifact();
            files.add( downloadedArtifact.getFile() );
        }

        return files;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        method_2_naether_gpt naether = new method_2_naether_gpt("build/local-repository");
        naether.addRemoteRepository(new RemoteRepository("central", "https://repo1.maven.org/maven2"));
        naether.addRemoteRepository(new RemoteRepository("internal", "https://repo.example.test/releases"));

        List<Object> requested = Arrays.<Object>asList(
                "org.example:demo-lib:1.2.3",
                new DefaultArtifact("com.acme:utility:jar:tests:2.0"),
                null
        );

        List<File> downloaded = naether.downloadArtifacts(requested);
        System.out.println("Downloaded artifact count: " + downloaded.size());
        for (File file : downloaded) {
            System.out.println("Resolved local file: " + file.getPath());
        }
    }

    static final class Log {
        void debug(String pattern, Object value) {
            System.out.println("DEBUG " + pattern.replace("{}", String.valueOf(value)));
        }

        void warn(String message) {
            System.out.println("WARN " + message);
        }
    }

    static class NaetherException extends Exception {
        NaetherException(String message) {
            super(message);
        }

        NaetherException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    static final class ResolveException extends NaetherException {
        ResolveException(Throwable cause) {
            super("Artifact resolution failed", cause);
        }
    }

    interface Artifact {
        String getGroupId();
        String getArtifactId();
        String getExtension();
        String getClassifier();
        String getVersion();
        File getFile();
        Artifact setFile(File file);
    }

    static final class DefaultArtifact implements Artifact {
        private final String groupId;
        private final String artifactId;
        private final String extension;
        private final String classifier;
        private final String version;
        private File file;

        DefaultArtifact(String notation) {
            String[] parts = notation.split(":");
            if (parts.length == 3) {
                groupId = parts[0];
                artifactId = parts[1];
                extension = "jar";
                classifier = "";
                version = parts[2];
            } else if (parts.length == 5) {
                groupId = parts[0];
                artifactId = parts[1];
                extension = parts[2];
                classifier = parts[3];
                version = parts[4];
            } else {
                throw new IllegalArgumentException("Unsupported artifact notation: " + notation);
            }
        }

        public String getGroupId() { return groupId; }
        public String getArtifactId() { return artifactId; }
        public String getExtension() { return extension; }
        public String getClassifier() { return classifier; }
        public String getVersion() { return version; }
        public File getFile() { return file; }

        public Artifact setFile(File file) {
            this.file = file;
            return this;
        }

        public String toString() {
            return groupId + ":" + artifactId + ":" + extension +
                    (classifier.isEmpty() ? "" : ":" + classifier) + ":" + version;
        }
    }

    static final class RemoteRepository {
        private final String id;
        private final String url;

        RemoteRepository(String id, String url) {
            this.id = id;
            this.url = url;
        }

        String getId() { return id; }
        String getUrl() { return url; }
    }

    static final class ArtifactRequest {
        private Artifact artifact;
        private final List<RemoteRepository> repositories = new ArrayList<RemoteRepository>();

        void setArtifact(Artifact artifact) {
            this.artifact = artifact;
        }

        Artifact getArtifact() {
            return artifact;
        }

        void addRepository(RemoteRepository repository) {
            repositories.add(repository);
        }

        List<RemoteRepository> getRepositories() {
            return repositories;
        }
    }

    static final class ArtifactResult {
        private final Artifact artifact;

        ArtifactResult(Artifact artifact) {
            this.artifact = artifact;
        }

        Artifact getArtifact() {
            return artifact;
        }
    }

    static final class ArtifactResolutionException extends Exception {
        ArtifactResolutionException(String message) {
            super(message);
        }
    }

    static final class RepositoryClient {
        private final File localRepo;

        RepositoryClient(String localRepoPath) {
            this.localRepo = new File(localRepoPath);
        }

        ArtifactResult resolveArtifact(ArtifactRequest request) throws ArtifactResolutionException {
            Artifact artifact = request.getArtifact();
            if (artifact == null) {
                throw new ArtifactResolutionException("No artifact supplied");
            }
            String relative = artifact.getGroupId().replace('.', File.separatorChar)
                    + File.separator + artifact.getArtifactId()
                    + File.separator + artifact.getVersion()
                    + File.separator + artifact.getArtifactId() + "-" + artifact.getVersion()
                    + (artifact.getClassifier().isEmpty() ? "" : "-" + artifact.getClassifier())
                    + "." + artifact.getExtension();
            artifact.setFile(new File(localRepo, relative));
            return new ArtifactResult(artifact);
        }
    }
}
