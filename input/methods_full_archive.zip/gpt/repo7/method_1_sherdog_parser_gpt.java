import java.io.*;
import java.util.*;
import java.util.stream.*;
interface SherdogParserContract {
    method_1_sherdog_parser_gpt.Fighter parseDocument(method_1_sherdog_parser_gpt.Document doc) throws IOException;
}
public class method_1_sherdog_parser_gpt implements SherdogParserContract {
    static final Logger logger = new Logger();
    static final java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd");
    static final int METHOD_KO=0, METHOD_SUBMISSION=1, METHOD_DECISION=2, METHOD_OTHERS=3;
    static final int COLUMN_RESULT=0, COLUMN_OPPONENT=1, COLUMN_EVENT=2, COLUMN_METHOD=3, COLUMN_ROUND=4, COLUMN_TIME=5;
    static final int FIGHTER1_COLUMN=0, FIGHTER2_COLUMN=1, METHOD_COLUMN=2, ROUND_COLUMN=3, TIME_COLUMN=4;
    static final PictureProcessor PROCESSOR = new PictureProcessor();

    static class Logger {
        void info(String s,Object...o){System.out.println("INFO "+format(s,o));}
        String format(String s,Object...o){for(Object x:o)s=s.replaceFirst("\\{}",java.util.regex.Matcher.quoteReplacement(String.valueOf(x)));return s;}
    }
    static class Element {
        String html=""; Map<String,String> attrs=new HashMap<>(); Map<String,Elements> selections=new HashMap<>();
        Element(){} Element(String h){html=h;}
        String html(){return html;} String attr(String n){return attrs.getOrDefault(n,"");}
        Elements select(String q){return selections.getOrDefault(q,new Elements());}
    }
    static class Elements extends ArrayList<Element> {
        Elements(){} Elements(Element...e){super(Arrays.asList(e));}
        String html(){return isEmpty()?"":get(0).html();}
        String attr(String n){return isEmpty()?"":get(0).attr(n);}
        Elements select(String q){Elements r=new Elements(); for(Element e:this)r.addAll(e.select(q)); return r;}
        Element first(){return isEmpty()?null:get(0);}
    }
    static class Document extends Element {
        String location="https://www.sherdog.com/fighter/demo";
        @Override Elements select(String q){return selections.getOrDefault(q,new Elements());}
    }
    static class ParserUtils {
        static String getSherdogPageUrl(Document d){return d.location;}
        static String getFightResult(Element e){return e==null?"UNKNOWN":e.html();}
    }
    enum FightType { MMA, KICKBOXING, OTHER;
        static FightType fromString(String s){ if(s==null)return OTHER; s=s.toUpperCase(); return s.contains("KICK")?KICKBOXING:s.contains("MMA")?MMA:OTHER;}
    }
    static class SherdogBaseObject {
        String name,url; void setName(String v){name=v;} void setSherdogUrl(String v){url=v;}
        String getName(){return name;} String getSherdogUrl(){return url;}
    }
    static class Fight {
        SherdogBaseObject f1,f2,event; String result,method,time; Integer round; Date date; FightType type;
        void setFighter1(SherdogBaseObject v){f1=v;} void setFighter2(SherdogBaseObject v){f2=v;}
        void setEvent(SherdogBaseObject v){event=v;} void setResult(String v){result=v;} void setWinMethod(String v){method=v;}
        void setWinRound(Integer v){round=v;} void setWinTime(String v){time=v;} void setDate(Date v){date=v;} void setType(FightType v){type=v;}
        Date getDate(){return date;} public String toString(){return "Fight{"+(f1==null?"?":f1.name)+" vs "+(f2==null?"?":f2.name)+", "+result+"}";}
    }
    static class Fighter extends SherdogBaseObject {
        String nickname,height,weight,picture; Date birthday; int wins,winsKo,winsSub,winsDec,winsOther,losses,lossesKo,lossesSub,lossesDec,lossesOther,draws,nc;
        List<Fight> fights=new ArrayList<>();
        void setNickname(String v){nickname=v;} void setBirthday(Date v){birthday=v;} void setHeight(String v){height=v;} void setWeight(String v){weight=v;}
        void setWins(int v){wins=v;} void setWinsKo(int v){winsKo=v;} void setWinsSub(int v){winsSub=v;} void setWinsDec(int v){winsDec=v;} void setWinsOther(int v){winsOther=v;}
        void setLosses(int v){losses=v;} void setLossesKo(int v){lossesKo=v;} void setLossesSub(int v){lossesSub=v;} void setLossesDec(int v){lossesDec=v;} void setLossesOther(int v){lossesOther=v;}
        void setDraws(int v){draws=v;} void setNc(int v){nc=v;} List<Fight> getFights(){return fights;} void setFights(List<Fight> v){fights=v;} void setPicture(String v){picture=v;}
    }
    static class Event extends SherdogBaseObject {
        Date date; List<Fight> fights=new ArrayList<>(); Date getDate(){return date;} void setDate(Date d){date=d;} void setFights(List<Fight> f){fights=f;}
    }
    static class PictureProcessor { String process(String url,Fighter f){return "processed:"+url;} }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Override
        public Fighter parseDocument(Document doc) throws IOException {
            Fighter fighter = new Fighter();
            fighter.setSherdogUrl(ParserUtils.getSherdogPageUrl(doc));

            logger.info("Refreshing fighter {}", fighter.getSherdogUrl());


            try {
                Elements name = doc.select(".bio_fighter h1 span.fn");
                fighter.setName(name.get(0).html());
            } catch (Exception e) {
                
            }

            
            try {
                Elements nickname = doc.select(".bio_fighter span.nickname em");
                fighter.setNickname(nickname.get(0).html());
            } catch (Exception e) {
                
            }

            
            try {
                Elements birthday = doc.select("span[itemprop=\"birthDate\"]");
                fighter.setBirthday(df.parse(birthday.get(0).html()));
            } catch (Exception e) {
                
            }
            
            try {
                Elements height = doc.select(".size_info .height strong");
                fighter.setHeight(height.get(0).html());
            } catch (Exception e) {
                
            }
            
            try {
                Elements weight = doc.select(".size_info .weight strong");
                fighter.setWeight(weight.get(0).html());
            } catch (Exception e) {
                
            }
            
            try {
                Elements wins = doc.select(".bio_graph .counter");
                fighter.setWins(Integer.parseInt(wins.get(0).html()));
            } catch (Exception e) {
                
            }
            Elements winsMethods = doc.select(".bio_graph:first-of-type .graph_tag");
            try {
                fighter.setWinsKo(Integer.parseInt(winsMethods.get(METHOD_KO).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setWinsSub(Integer.parseInt(winsMethods.get(METHOD_SUBMISSION).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setWinsDec(Integer.parseInt(winsMethods.get(METHOD_DECISION).html().split(" ")[0]));
            } catch (Exception e) {
                
            }


            try {
                fighter.setWinsOther(Integer.parseInt(winsMethods.get(METHOD_OTHERS).html().split(" ")[0]));
            } catch (Exception e) {
                
            }
            
            try {
                Elements losses = doc.select(".bio_graph.loser .counter");
                fighter.setLosses(Integer.parseInt(losses.get(0).html()));
            } catch (Exception e) {
                
            }

            Elements lossesMethods = doc.select(".bio_graph.loser .graph_tag");


            try {

                fighter.setLossesKo((Integer.parseInt(lossesMethods.get(METHOD_KO).html().split(" ")[0])));
            } catch (Exception e) {
                
            }

            try {
                fighter.setLossesSub(Integer.parseInt(lossesMethods.get(METHOD_SUBMISSION).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setLossesDec(Integer.parseInt(lossesMethods.get(METHOD_DECISION).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setLossesOther(Integer.parseInt(lossesMethods.get(METHOD_OTHERS).html().split(" ")[0]));
            } catch (Exception e) {
                
            }
            
            Elements drawsNc = doc.select(".right_side .bio_graph .card");
            for (Element element : drawsNc) {

                switch (element.select("span.result").html()) {
                    case "Draws":
                        fighter.setDraws(Integer.parseInt(element.select("span.counter").html()));
                        break;

                    case "N/C":
                        fighter.setNc(Integer.parseInt(element.select("span.counter").html()));
                        break;
                }

            }

            Elements picture = doc.select(".bio_fighter .content img[itemprop=\"image\"]");
            String pictureUrl = "https://www.sherdog.com" + picture.attr("src").trim();


            Elements fightTables = doc.select(".fight_history");
            logger.info("Found {} fight history tables", fightTables.size());


            fightTables.stream()
                    
                    .filter(div -> !div.select(".module_header h2").html().trim().contains("Upcoming"))
                    .collect(Collectors.groupingBy(div -> {
                        String categoryName = div.select(".module_header h2").html().trim().replaceAll("(?i)FIGHT HISTORY - ", "").trim();

                        return FightType.fromString(categoryName);
                    }))
                    .forEach((key, div) -> div.stream()
                            .map(d -> d.select(".table table tr"))
                            .filter(tdList -> tdList.size() > 0)
                            .findFirst()
                            .ifPresent(tdList -> {
                                        List<Fight> f = getFights(tdList, fighter);

                                        f.forEach(fight -> fight.setType(key));

                                        fighter.getFights().addAll(f);
                                    }
                            ));

            List<Fight> sorted = fighter.getFights()
                    .stream()
                    .sorted(Comparator.comparing(Fight::getDate, Comparator.nullsFirst(Comparator.naturalOrder())))
                    .collect(Collectors.toList());

            fighter.setFights(sorted);


            logger.info("Found {} fights for {}", fighter.getFights().size(), fighter.getName());

            
            if (pictureUrl.length() > 0) {
                fighter.setPicture(PROCESSOR.process(pictureUrl, fighter));
            }

            return fighter;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private List<Fight> getFights(Elements trs, Fighter fighter) {
        List<Fight> out=new ArrayList<>();
        if(trs.size()>1){Fight f=new Fight(); f.setFighter1(fighter); f.setResult("Win"); f.setDate(new Date(0)); out.add(f);}
        return out;
    }

    public static void main(String[] args) throws Exception {
        Document d=new Document();
        d.selections.put(".bio_fighter h1 span.fn",new Elements(new Element("Demo Fighter")));
        d.selections.put(".bio_fighter span.nickname em",new Elements(new Element("The Demo")));
        d.selections.put("span[itemprop=\"birthDate\"]",new Elements(new Element("1990-01-01")));
        d.selections.put(".size_info .height strong",new Elements(new Element("180 cm")));
        d.selections.put(".size_info .weight strong",new Elements(new Element("77 kg")));
        d.selections.put(".bio_graph .counter",new Elements(new Element("10")));
        d.selections.put(".bio_graph:first-of-type .graph_tag",new Elements(new Element("4 KO"),new Element("3 SUB"),new Element("2 DEC"),new Element("1 OTHER")));
        d.selections.put(".bio_graph.loser .counter",new Elements(new Element("2")));
        d.selections.put(".bio_graph.loser .graph_tag",new Elements(new Element("1 KO"),new Element("0 SUB"),new Element("1 DEC"),new Element("0 OTHER")));
        Element img=new Element();img.attrs.put("src","/image.jpg"); d.selections.put(".bio_fighter .content img[itemprop=\"image\"]",new Elements(img));
        Fighter f=new method_1_sherdog_parser_gpt().parseDocument(d);
        System.out.println("Parsed fighter="+f.getName()+", wins="+f.wins+", picture="+f.picture+", fights="+f.getFights().size());
    }
}
