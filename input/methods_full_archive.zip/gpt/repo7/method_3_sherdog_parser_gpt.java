import java.util.*;

public class method_3_sherdog_parser_gpt {
    static final Logger logger = new Logger();
    static final java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd");
    static final int METHOD_KO=0, METHOD_SUBMISSION=1, METHOD_DECISION=2, METHOD_OTHERS=3;
    static final int COLUMN_RESULT=0, COLUMN_OPPONENT=1, COLUMN_EVENT=2, COLUMN_METHOD=3, COLUMN_ROUND=4, COLUMN_TIME=5;
    static final int FIGHTER1_COLUMN=0, FIGHTER2_COLUMN=1, METHOD_COLUMN=2, ROUND_COLUMN=3, TIME_COLUMN=4;
    static final PictureProcessor PROCESSOR = new PictureProcessor();

    static class Logger {
        void info(String s,Object...o){System.out.println("INFO "+format(s,o));}
        String format(String s,Object...o){for(Object x:o)s=s.replaceFirst("\\{}",java.util.regex.Matcher.quoteReplacement(String.valueOf(x)));return s;}
    }
    static class Element {
        String html=""; Map<String,String> attrs=new HashMap<>(); Map<String,Elements> selections=new HashMap<>();
        Element(){} Element(String h){html=h;}
        String html(){return html;} String attr(String n){return attrs.getOrDefault(n,"");}
        Elements select(String q){return selections.getOrDefault(q,new Elements());}
    }
    static class Elements extends ArrayList<Element> {
        Elements(){} Elements(Element...e){super(Arrays.asList(e));}
        String html(){return isEmpty()?"":get(0).html();}
        String attr(String n){return isEmpty()?"":get(0).attr(n);}
        Elements select(String q){Elements r=new Elements(); for(Element e:this)r.addAll(e.select(q)); return r;}
        Element first(){return isEmpty()?null:get(0);}
    }
    static class Document extends Element {
        String location="https://www.sherdog.com/fighter/demo";
        @Override Elements select(String q){return selections.getOrDefault(q,new Elements());}
    }
    static class ParserUtils {
        static String getSherdogPageUrl(Document d){return d.location;}
        static String getFightResult(Element e){return e==null?"UNKNOWN":e.html();}
    }
    enum FightType { MMA, KICKBOXING, OTHER;
        static FightType fromString(String s){ if(s==null)return OTHER; s=s.toUpperCase(); return s.contains("KICK")?KICKBOXING:s.contains("MMA")?MMA:OTHER;}
    }
    static class SherdogBaseObject {
        String name,url; void setName(String v){name=v;} void setSherdogUrl(String v){url=v;}
        String getName(){return name;} String getSherdogUrl(){return url;}
    }
    static class Fight {
        SherdogBaseObject f1,f2,event; String result,method,time; Integer round; Date date; FightType type;
        void setFighter1(SherdogBaseObject v){f1=v;} void setFighter2(SherdogBaseObject v){f2=v;}
        void setEvent(SherdogBaseObject v){event=v;} void setResult(String v){result=v;} void setWinMethod(String v){method=v;}
        void setWinRound(Integer v){round=v;} void setWinTime(String v){time=v;} void setDate(Date v){date=v;} void setType(FightType v){type=v;}
        Date getDate(){return date;} public String toString(){return "Fight{"+(f1==null?"?":f1.name)+" vs "+(f2==null?"?":f2.name)+", "+result+"}";}
    }
    static class Fighter extends SherdogBaseObject {
        String nickname,height,weight,picture; Date birthday; int wins,winsKo,winsSub,winsDec,winsOther,losses,lossesKo,lossesSub,lossesDec,lossesOther,draws,nc;
        List<Fight> fights=new ArrayList<>();
        void setNickname(String v){nickname=v;} void setBirthday(Date v){birthday=v;} void setHeight(String v){height=v;} void setWeight(String v){weight=v;}
        void setWins(int v){wins=v;} void setWinsKo(int v){winsKo=v;} void setWinsSub(int v){winsSub=v;} void setWinsDec(int v){winsDec=v;} void setWinsOther(int v){winsOther=v;}
        void setLosses(int v){losses=v;} void setLossesKo(int v){lossesKo=v;} void setLossesSub(int v){lossesSub=v;} void setLossesDec(int v){lossesDec=v;} void setLossesOther(int v){lossesOther=v;}
        void setDraws(int v){draws=v;} void setNc(int v){nc=v;} List<Fight> getFights(){return fights;} void setFights(List<Fight> v){fights=v;} void setPicture(String v){picture=v;}
    }
    static class Event extends SherdogBaseObject {
        Date date; List<Fight> fights=new ArrayList<>(); Date getDate(){return date;} void setDate(Date d){date=d;} void setFights(List<Fight> f){fights=f;}
    }
    static class PictureProcessor { String process(String url,Fighter f){return "processed:"+url;} }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private List<Fight> getFights(Elements trs, Fighter fighter) throws ArrayIndexOutOfBoundsException {
            List<Fight> fights = new ArrayList<>();

            logger.info("{} TRs to parse through", trs.size());


            SherdogBaseObject sFighter = new SherdogBaseObject();
            sFighter.setName(fighter.getName());
            sFighter.setSherdogUrl(fighter.getSherdogUrl());


            
            if (trs.size() > 0) {
                trs.remove(0);

                trs.forEach(tr -> {
                    Fight fight = new Fight();
                    fight.setFighter1(sFighter);

                    Elements tds = tr.select("td");
                    fight.setResult(getFightResult(tds.get(COLUMN_RESULT)));
                    fight.setFighter2(getOpponent(tds.get(COLUMN_OPPONENT)));
                    fight.setEvent(getEvent(tds.get(COLUMN_EVENT)));
                    fight.setDate(getDate(tds.get(COLUMN_EVENT)));
                    fight.setWinMethod(getWinMethod(tds.get(COLUMN_METHOD)));
                    fight.setWinRound(getWinRound(tds.get(COLUMN_ROUND)));
                    fight.setWinTime(getWinTime(tds.get(COLUMN_TIME)));
                    fights.add(fight);
                    logger.info("{}", fight);
                });
            }

            return fights;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private String getFightResult(Element e){return e.html();} private SherdogBaseObject getOpponent(Element e){SherdogBaseObject o=new SherdogBaseObject();o.setName(e.html());return o;}
    private SherdogBaseObject getEvent(Element e){SherdogBaseObject o=new SherdogBaseObject();o.setName(e.html());return o;} private Date getDate(Element e){return new Date(0);}
    private String getWinMethod(Element e){return e.html();} private int getWinRound(Element e){return Integer.parseInt(e.html());} private String getWinTime(Element e){return e.html();}

    public static void main(String[] args){
     Fighter f=new Fighter();f.setName("A");f.setSherdogUrl("fighter/a");
     Element header=new Element(); Element tr=new Element();tr.selections.put("td",new Elements(new Element("Win"),new Element("B"),new Element("Event"),new Element("KO"),new Element("1"),new Element("1:00")));
     Elements rows=new Elements(header,tr); List<Fight> r=new method_3_sherdog_parser_gpt().getFights(rows,f);System.out.println("Parsed fights="+r);
    }
}
