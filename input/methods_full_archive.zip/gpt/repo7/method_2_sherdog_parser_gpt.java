import java.util.*;

public class method_2_sherdog_parser_gpt {
    static final Logger logger = new Logger();
    static final java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd");
    static final int METHOD_KO=0, METHOD_SUBMISSION=1, METHOD_DECISION=2, METHOD_OTHERS=3;
    static final int COLUMN_RESULT=0, COLUMN_OPPONENT=1, COLUMN_EVENT=2, COLUMN_METHOD=3, COLUMN_ROUND=4, COLUMN_TIME=5;
    static final int FIGHTER1_COLUMN=0, FIGHTER2_COLUMN=1, METHOD_COLUMN=2, ROUND_COLUMN=3, TIME_COLUMN=4;
    static final PictureProcessor PROCESSOR = new PictureProcessor();

    static class Logger {
        void info(String s,Object...o){System.out.println("INFO "+format(s,o));}
        String format(String s,Object...o){for(Object x:o)s=s.replaceFirst("\\{}",java.util.regex.Matcher.quoteReplacement(String.valueOf(x)));return s;}
    }
    static class Element {
        String html=""; Map<String,String> attrs=new HashMap<>(); Map<String,Elements> selections=new HashMap<>();
        Element(){} Element(String h){html=h;}
        String html(){return html;} String attr(String n){return attrs.getOrDefault(n,"");}
        Elements select(String q){return selections.getOrDefault(q,new Elements());}
    }
    static class Elements extends ArrayList<Element> {
        Elements(){} Elements(Element...e){super(Arrays.asList(e));}
        String html(){return isEmpty()?"":get(0).html();}
        String attr(String n){return isEmpty()?"":get(0).attr(n);}
        Elements select(String q){Elements r=new Elements(); for(Element e:this)r.addAll(e.select(q)); return r;}
        Element first(){return isEmpty()?null:get(0);}
    }
    static class Document extends Element {
        String location="https://www.sherdog.com/fighter/demo";
        @Override Elements select(String q){return selections.getOrDefault(q,new Elements());}
    }
    static class ParserUtils {
        static String getSherdogPageUrl(Document d){return d.location;}
        static String getFightResult(Element e){return e==null?"UNKNOWN":e.html();}
    }
    enum FightType { MMA, KICKBOXING, OTHER;
        static FightType fromString(String s){ if(s==null)return OTHER; s=s.toUpperCase(); return s.contains("KICK")?KICKBOXING:s.contains("MMA")?MMA:OTHER;}
    }
    static class SherdogBaseObject {
        String name,url; void setName(String v){name=v;} void setSherdogUrl(String v){url=v;}
        String getName(){return name;} String getSherdogUrl(){return url;}
    }
    static class Fight {
        SherdogBaseObject f1,f2,event; String result,method,time; Integer round; Date date; FightType type;
        void setFighter1(SherdogBaseObject v){f1=v;} void setFighter2(SherdogBaseObject v){f2=v;}
        void setEvent(SherdogBaseObject v){event=v;} void setResult(String v){result=v;} void setWinMethod(String v){method=v;}
        void setWinRound(Integer v){round=v;} void setWinTime(String v){time=v;} void setDate(Date v){date=v;} void setType(FightType v){type=v;}
        Date getDate(){return date;} public String toString(){return "Fight{"+(f1==null?"?":f1.name)+" vs "+(f2==null?"?":f2.name)+", "+result+"}";}
    }
    static class Fighter extends SherdogBaseObject {
        String nickname,height,weight,picture; Date birthday; int wins,winsKo,winsSub,winsDec,winsOther,losses,lossesKo,lossesSub,lossesDec,lossesOther,draws,nc;
        List<Fight> fights=new ArrayList<>();
        void setNickname(String v){nickname=v;} void setBirthday(Date v){birthday=v;} void setHeight(String v){height=v;} void setWeight(String v){weight=v;}
        void setWins(int v){wins=v;} void setWinsKo(int v){winsKo=v;} void setWinsSub(int v){winsSub=v;} void setWinsDec(int v){winsDec=v;} void setWinsOther(int v){winsOther=v;}
        void setLosses(int v){losses=v;} void setLossesKo(int v){lossesKo=v;} void setLossesSub(int v){lossesSub=v;} void setLossesDec(int v){lossesDec=v;} void setLossesOther(int v){lossesOther=v;}
        void setDraws(int v){draws=v;} void setNc(int v){nc=v;} List<Fight> getFights(){return fights;} void setFights(List<Fight> v){fights=v;} void setPicture(String v){picture=v;}
    }
    static class Event extends SherdogBaseObject {
        Date date; List<Fight> fights=new ArrayList<>(); Date getDate(){return date;} void setDate(Date d){date=d;} void setFights(List<Fight> f){fights=f;}
    }
    static class PictureProcessor { String process(String url,Fighter f){return "processed:"+url;} }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private void getFights(Document doc, Event event) {
            logger.info("Getting fights for event #{}[{}]", event.getSherdogUrl(), event.getName());

            SherdogBaseObject sEvent = new SherdogBaseObject();
            sEvent.setName(event.getName());
            sEvent.setSherdogUrl(event.getSherdogUrl());

            List<Fight> fights = new ArrayList<>();

            
            Elements mainFightElement = doc.select(".content.event");

            Elements fighters = mainFightElement.select("h3 a");
            
            SherdogBaseObject mainFighter1 = new SherdogBaseObject();
            Element mainFighter1Element = fighters.get(0);
            mainFighter1.setSherdogUrl(mainFighter1Element.attr("abs:href"));
            mainFighter1.setName(mainFighter1Element.select("span[itemprop=\"name\"]").html());

            
            SherdogBaseObject mainFighter2 = new SherdogBaseObject();
            Element mainFighter2Element = fighters.get(1);
            mainFighter2.setSherdogUrl(mainFighter2Element.attr("abs:href"));
            mainFighter2.setName(mainFighter2Element.select("span[itemprop=\"name\"]").html());


            Fight mainFight = new Fight();
            mainFight.setEvent(sEvent);
            mainFight.setFighter1(mainFighter1);
            mainFight.setFighter2(mainFighter2);
            mainFight.setResult(ParserUtils.getFightResult(mainFightElement.first()));

            
            Elements mainTd = mainFightElement.select("td");
            if (mainTd.size() > 0) {
                mainFight.setWinMethod(mainTd.get(1).html().replaceAll("<em(.*)<br>", "").trim());
                mainFight.setWinRound(Integer.parseInt(mainTd.get(3).html().replaceAll("<em(.*)<br>", "").trim()));
                mainFight.setWinTime(mainTd.get(4).html().replaceAll("<em(.*)<br>", "").trim());
            }
            mainFight.setDate(event.getDate());


            fights.add(mainFight);
            logger.info("Fight added: {}", mainFight);
            

            logger.info("Found {} fights", fights.size());

            Elements tds = doc.select(".event_match table tr");

            fights.addAll(parseEventFights(tds, event));


            event.setFights(fights);
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private List<Fight> parseEventFights(Elements trs, Event event){List<Fight> r=new ArrayList<>(); return r;}

    public static void main(String[] args){
     Document d=new Document(); Event e=new Event();e.setName("Demo Event");e.setSherdogUrl("event/1");e.setDate(new Date(0));
     Element content=new Element(); Element a1=new Element();a1.attrs.put("abs:href","fighter/1");a1.selections.put("span[itemprop=\"name\"]",new Elements(new Element("A")));
     Element a2=new Element();a2.attrs.put("abs:href","fighter/2");a2.selections.put("span[itemprop=\"name\"]",new Elements(new Element("B")));
     content.selections.put("h3 a",new Elements(a1,a2)); content.html="Win";
     d.selections.put(".content.event",new Elements(content)); d.selections.put(".event_match table tr",new Elements());
     new method_2_sherdog_parser_gpt().getFights(d,e); System.out.println("Event fights="+e.fights.size());
    }
}
