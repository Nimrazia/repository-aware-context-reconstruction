import java.util.*;

public class method_3_owlexplanation_gpt {

    static class OWLAnnotation {}
    static class OWLAxiom {
        final String text; final boolean logical;
        OWLAxiom(String text){this(text,true);} OWLAxiom(String text, boolean logical){this.text=text;this.logical=logical;}
        boolean isLogicalAxiom(){return logical;}
        OWLAxiom getAnnotatedAxiom(Set<OWLAnnotation> a){return new OWLAxiom(text+" annotations="+a);}
        public boolean equals(Object o){return o instanceof OWLAxiom && text.equals(((OWLAxiom)o).text);} public int hashCode(){return text.hashCode();}
        public String toString(){return text;}
    }
    static class OWLClassExpression { final String text; OWLClassExpression(String t){text=t;} boolean isAnonymous(){return true;} OWLClass asOWLClass(){throw new IllegalStateException();} public String toString(){return text;} }
    static class OWLClass extends OWLClassExpression { OWLClass(String t){super(t);} boolean isAnonymous(){return false;} OWLClass asOWLClass(){return this;} public boolean equals(Object o){return o instanceof OWLClass&&text.equals(((OWLClass)o).text);} public int hashCode(){return text.hashCode();} }
    static class OWLSubClassOfAxiom extends OWLAxiom { final OWLClassExpression sub,sup; OWLSubClassOfAxiom(OWLClassExpression a,OWLClassExpression b){super(a+" ⊑ "+b);sub=a;sup=b;} OWLClassExpression getSubClass(){return sub;} OWLClassExpression getSuperClass(){return sup;} }
    static class OWLObjectIntersectionOf extends OWLClassExpression { OWLObjectIntersectionOf(Set<OWLClassExpression>s){super("and"+s);} }
    static class Explanation<T> {
        final T entailment; final Set<OWLAxiom> axioms;
        Explanation(T e, Set<OWLAxiom>a){entailment=e;axioms=new LinkedHashSet<>(a);} static <T> Explanation<T> getEmptyExplanation(T e){return new Explanation<>(e,Collections.emptySet());}
        Set<OWLAxiom> getAxioms(){return axioms;} T getEntailment(){return entailment;} int getSize(){return axioms.size();} boolean isEmpty(){return axioms.isEmpty();} boolean contains(OWLAxiom a){return axioms.contains(a);} boolean isJustificationEntailment(){return entailment instanceof OWLAxiom && axioms.contains(entailment);} public String toString(){return "Explanation"+axioms;}
        public boolean equals(Object o){return o instanceof Explanation && Objects.equals(entailment,((Explanation<?>)o).entailment)&&axioms.equals(((Explanation<?>)o).axioms);} public int hashCode(){return Objects.hash(entailment,axioms);}
    }

    static class ExplanationException extends Exception{}
    static class OWLOntology { Set<OWLAxiom> logical=new LinkedHashSet<>(); Set<OWLAxiom> getLogicalAxioms(){return logical;} Set<OWLOntology> getImportsClosure(){return Set.of(this);} }
    static class Reasoner { OWLOntology root=new OWLOntology(); OWLOntology getRootOntology(){return root;} }
    static class OWLOntologyManager { OWLDataFactory getOWLDataFactory(){return new OWLDataFactory();} }
    static class OWLDataFactory { OWLClass getOWLNothing(){return new OWLClass("Nothing");} OWLAxiom getOWLSubClassOfAxiom(OWLClass a,OWLClass b){return new OWLSubClassOfAxiom(a,b);} }
    static class StructuralRootDerivedReasoner { StructuralRootDerivedReasoner(Object m,Reasoner b,Object f){} Set<OWLClass> getRootUnsatisfiableClasses(){return new LinkedHashSet<>(List.of(new OWLClass("BrokenA"),new OWLClass("BrokenB")));} }
    interface ExplanationGenerator<T>{Set<Explanation<T>> getExplanations(T e);} interface ExplanationGeneratorFactory<T>{ExplanationGenerator<T> createExplanationGenerator(Set<OWLAxiom>a);} static class ExplanationManager { static ExplanationGeneratorFactory<OWLAxiom> createExplanationGeneratorFactory(Object f){return axioms->e->Set.of(new Explanation<>(e,new LinkedHashSet<>(axioms)));} }
    static class ImportsOntology extends OWLOntology { Set<OWLOntology> getImportsClosure(){return Set.of(this);} }
    final OWLOntologyManager manager=new OWLOntologyManager(); final Reasoner baseReasoner=new Reasoner(){ {root=new ImportsOntology();root.logical.add(new OWLAxiom("dependency BrokenA"));} }; final Object reasonerFactory=new Object(); Map<OWLClass,Set<Explanation<OWLAxiom>>> cls2JustificationMap; final Set<OWLClass> roots=new LinkedHashSet<>();

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public Set<OWLClass> getRootUnsatisfiableClasses() throws ExplanationException {
            StructuralRootDerivedReasoner srd = new StructuralRootDerivedReasoner(manager, baseReasoner, reasonerFactory);
            Set<OWLClass> estimatedRoots = srd.getRootUnsatisfiableClasses();
            cls2JustificationMap = new HashMap<OWLClass, Set<Explanation<OWLAxiom>>>();
            Set<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
            for (OWLOntology ont : baseReasoner.getRootOntology().getImportsClosure()) {
                allAxioms.addAll(ont.getLogicalAxioms());
            }

            for (OWLClass cls : estimatedRoots) {
                cls2JustificationMap.put(cls, new HashSet<Explanation<OWLAxiom>>());
                System.out.println("POTENTIAL ROOT: " + cls);
            }
            System.out.println("Finding real roots from " + estimatedRoots.size() + " estimated roots");

            int done = 0;
            roots.addAll(estimatedRoots);
            for (final OWLClass estimatedRoot : estimatedRoots) {
                ExplanationGeneratorFactory<OWLAxiom> genFac = ExplanationManager.createExplanationGeneratorFactory(reasonerFactory);
                ExplanationGenerator<OWLAxiom> gen = genFac.createExplanationGenerator(allAxioms);
                OWLDataFactory df = manager.getOWLDataFactory();
                Set<Explanation<OWLAxiom>> expls = gen.getExplanations(df.getOWLSubClassOfAxiom(estimatedRoot, df.getOWLNothing()));
                cls2JustificationMap.get(estimatedRoot).addAll(expls);
                done++;
                System.out.println("Done " + done);
            }
            for(OWLClass clsA : estimatedRoots) {
                for(OWLClass clsB : estimatedRoots) {
                    if (!clsA.equals(clsB)) {
                        Set<Explanation<OWLAxiom>> clsAExpls = cls2JustificationMap.get(clsA);
                        Set<Explanation<OWLAxiom>> clsBExpls = cls2JustificationMap.get(clsB);
                        boolean clsARootForClsB = false;
                        boolean clsBRootForClsA = false;
                        
                        for(Explanation<OWLAxiom> clsAExpl : clsAExpls) {
                            for(Explanation<OWLAxiom> clsBExpl : clsBExpls) {
                                if(isRootFor(clsAExpl, clsBExpl)) {
                                    
                                    clsARootForClsB = true;
    
                                }
                                else if(isRootFor(clsBExpl, clsAExpl)) {
                                    
                                    clsBRootForClsA = true;
    
                                }
                            }
                        }
                        if (!clsARootForClsB || !clsBRootForClsA) {
                            if(clsARootForClsB) {
                                roots.remove(clsB);
                            }
                            else if(clsBRootForClsA) {
                                roots.remove(clsA);
                            }
                        }
                    }
                }
            }
            return roots;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
    boolean isRootFor(Explanation<OWLAxiom>a,Explanation<OWLAxiom>b){return a.getAxioms().size()<b.getAxioms().size();}
    public static void main(String[] args) throws Exception{method_3_owlexplanation_gpt x=new method_3_owlexplanation_gpt();System.out.println("ROOTS="+x.getRootUnsatisfiableClasses());}
}
