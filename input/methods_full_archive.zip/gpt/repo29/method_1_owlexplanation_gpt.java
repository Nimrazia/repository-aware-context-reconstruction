import java.util.*;

public class method_1_owlexplanation_gpt<E> {

    static class OWLAnnotation {}
    static class OWLAxiom {
        final String text; final boolean logical;
        OWLAxiom(String text){this(text,true);} OWLAxiom(String text, boolean logical){this.text=text;this.logical=logical;}
        boolean isLogicalAxiom(){return logical;}
        OWLAxiom getAnnotatedAxiom(Set<OWLAnnotation> a){return new OWLAxiom(text+" annotations="+a);}
        public boolean equals(Object o){return o instanceof OWLAxiom && text.equals(((OWLAxiom)o).text);} public int hashCode(){return text.hashCode();}
        public String toString(){return text;}
    }
    static class OWLClassExpression { final String text; OWLClassExpression(String t){text=t;} boolean isAnonymous(){return true;} OWLClass asOWLClass(){throw new IllegalStateException();} public String toString(){return text;} }
    static class OWLClass extends OWLClassExpression { OWLClass(String t){super(t);} boolean isAnonymous(){return false;} OWLClass asOWLClass(){return this;} public boolean equals(Object o){return o instanceof OWLClass&&text.equals(((OWLClass)o).text);} public int hashCode(){return text.hashCode();} }
    static class OWLSubClassOfAxiom extends OWLAxiom { final OWLClassExpression sub,sup; OWLSubClassOfAxiom(OWLClassExpression a,OWLClassExpression b){super(a+" ⊑ "+b);sub=a;sup=b;} OWLClassExpression getSubClass(){return sub;} OWLClassExpression getSuperClass(){return sup;} }
    static class OWLObjectIntersectionOf extends OWLClassExpression { OWLObjectIntersectionOf(Set<OWLClassExpression>s){super("and"+s);} }
    static class Explanation<T> {
        final T entailment; final Set<OWLAxiom> axioms;
        Explanation(T e, Set<OWLAxiom>a){entailment=e;axioms=new LinkedHashSet<>(a);} static <T> Explanation<T> getEmptyExplanation(T e){return new Explanation<>(e,Collections.emptySet());}
        Set<OWLAxiom> getAxioms(){return axioms;} T getEntailment(){return entailment;} int getSize(){return axioms.size();} boolean isEmpty(){return axioms.isEmpty();} boolean contains(OWLAxiom a){return axioms.contains(a);} boolean isJustificationEntailment(){return entailment instanceof OWLAxiom && axioms.contains(entailment);} public String toString(){return "Explanation"+axioms;}
        public boolean equals(Object o){return o instanceof Explanation && Objects.equals(entailment,((Explanation<?>)o).entailment)&&axioms.equals(((Explanation<?>)o).axioms);} public int hashCode(){return Objects.hash(entailment,axioms);}
    }

    interface EntailmentChecker<T>{boolean isEntailed(Set<OWLAxiom>a);}
    interface CheckerFactory<T>{EntailmentChecker<T> createEntailementChecker(T e);}
    static class Monitor { boolean cancelled; boolean isCancelled(){return cancelled;} }
    static class TelemetryTimer { long start; long elapsed; void start(){start=System.nanoTime();} void stop(){elapsed=System.nanoTime()-start;} }
    interface TelemetryInfo{} static class DefaultTelemetryInfo implements TelemetryInfo { final String n; DefaultTelemetryInfo(String n,TelemetryTimer t){this.n=n;} }
    static class TelemetryTransmitter { static final TelemetryTransmitter T=new TelemetryTransmitter(); static TelemetryTransmitter getTransmitter(){return T;} void beginTransmission(TelemetryInfo i){System.out.println("telemetry begin");} void endTransmission(TelemetryInfo i){System.out.println("telemetry end");} void recordMeasurement(TelemetryInfo i,String k,Object v){System.out.println(k+"="+v);} void recordTiming(TelemetryInfo i,String k,TelemetryTimer t){System.out.println(k+"Ns="+t.elapsed);} void recordException(TelemetryInfo i,Exception e){} }
    static class TimeOutException extends RuntimeException{} static class ExplanationGeneratorInterruptedException extends RuntimeException{}
    final Set<OWLAxiom> workingAxioms=new LinkedHashSet<>(); final Set<OWLAxiom> module=new LinkedHashSet<>(); final Monitor progressMonitor=new Monitor(); final CheckerFactory<E> checkerFactory=e->a->e instanceof OWLAxiom && a.contains((OWLAxiom)e);

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    protected Explanation<E> computeExplanation(E entailment) {

            TelemetryTimer justificationTimer = new TelemetryTimer();

            TelemetryInfo findOneInfo = new DefaultTelemetryInfo("findone", justificationTimer);
            final TelemetryTransmitter transmitter = TelemetryTransmitter.getTransmitter();
            transmitter.beginTransmission(findOneInfo);

            Explanation<E> result = Explanation.getEmptyExplanation(entailment);

            boolean entailed = false;

            try {
                justificationTimer.start();

                
                if (entailment instanceof OWLAxiom && workingAxioms.contains((OWLAxiom) entailment)) {
                    entailed = true;
                    result = new Explanation<E>(entailment, Collections.singleton((OWLAxiom) entailment));
                }
                else {
                    if (progressMonitor.isCancelled()) {
                        throw new ExplanationGeneratorInterruptedException();
                    }
                    EntailmentChecker<E> checker = checkerFactory.createEntailementChecker(entailment);
                    
                    Set<OWLAxiom> expandedAxioms = doExpansion(checker);

                    if (!expandedAxioms.isEmpty()) {
                        
                        Set<OWLAxiom> justificationAxioms = doContraction(checker, expandedAxioms);

                        result = new Explanation<E>(entailment, justificationAxioms);
                    }

                }
                justificationTimer.stop();

            }
            catch (TimeOutException e) {
                transmitter.recordMeasurement(findOneInfo, "reasoner time out", true);
                throw e;
            }
            catch (ExplanationGeneratorInterruptedException e) {
                transmitter.recordMeasurement(findOneInfo, "interrupted", true);
                throw e;
            }
            catch (RuntimeException e) {
                transmitter.recordException(findOneInfo, e);
                throw e;
            }
            finally {
                transmitter.recordMeasurement(findOneInfo, "input size", module.size());
                transmitter.recordMeasurement(findOneInfo, "entailed", entailed);
                transmitter.recordMeasurement(findOneInfo, "self justification", result.isJustificationEntailment());
                transmitter.recordMeasurement(findOneInfo, "justification size", result.getSize());
                transmitter.recordTiming(findOneInfo, "time", justificationTimer);
                recordJustification(entailment, findOneInfo, result);
                transmitter.endTransmission(findOneInfo);
            }


            return result;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    Set<OWLAxiom> doExpansion(EntailmentChecker<E> c){return c.isEntailed(module)?new LinkedHashSet<>(module):Collections.emptySet();}
    Set<OWLAxiom> doContraction(EntailmentChecker<E> c,Set<OWLAxiom>a){for(OWLAxiom x:new ArrayList<>(a)){Set<OWLAxiom> trial=new LinkedHashSet<>(a);trial.remove(x);if(c.isEntailed(trial))a=trial;}return a;}
    void recordJustification(E e,TelemetryInfo i,Explanation<E>x){System.out.println("recorded "+x);}

    public static void main(String[] args){method_1_owlexplanation_gpt x=new method_1_owlexplanation_gpt<OWLAxiom>();OWLAxiom e=new OWLAxiom("A entails B");x.module.add(e);System.out.println("RESULT="+x.computeExplanation(e));}
}
