import java.util.*;

public class method_2_owlexplanation_gpt<E> {

    static class OWLAnnotation {}
    static class OWLAxiom {
        final String text; final boolean logical;
        OWLAxiom(String text){this(text,true);} OWLAxiom(String text, boolean logical){this.text=text;this.logical=logical;}
        boolean isLogicalAxiom(){return logical;}
        OWLAxiom getAnnotatedAxiom(Set<OWLAnnotation> a){return new OWLAxiom(text+" annotations="+a);}
        public boolean equals(Object o){return o instanceof OWLAxiom && text.equals(((OWLAxiom)o).text);} public int hashCode(){return text.hashCode();}
        public String toString(){return text;}
    }
    static class OWLClassExpression { final String text; OWLClassExpression(String t){text=t;} boolean isAnonymous(){return true;} OWLClass asOWLClass(){throw new IllegalStateException();} public String toString(){return text;} }
    static class OWLClass extends OWLClassExpression { OWLClass(String t){super(t);} boolean isAnonymous(){return false;} OWLClass asOWLClass(){return this;} public boolean equals(Object o){return o instanceof OWLClass&&text.equals(((OWLClass)o).text);} public int hashCode(){return text.hashCode();} }
    static class OWLSubClassOfAxiom extends OWLAxiom { final OWLClassExpression sub,sup; OWLSubClassOfAxiom(OWLClassExpression a,OWLClassExpression b){super(a+" ⊑ "+b);sub=a;sup=b;} OWLClassExpression getSubClass(){return sub;} OWLClassExpression getSuperClass(){return sup;} }
    static class OWLObjectIntersectionOf extends OWLClassExpression { OWLObjectIntersectionOf(Set<OWLClassExpression>s){super("and"+s);} }
    static class Explanation<T> {
        final T entailment; final Set<OWLAxiom> axioms;
        Explanation(T e, Set<OWLAxiom>a){entailment=e;axioms=new LinkedHashSet<>(a);} static <T> Explanation<T> getEmptyExplanation(T e){return new Explanation<>(e,Collections.emptySet());}
        Set<OWLAxiom> getAxioms(){return axioms;} T getEntailment(){return entailment;} int getSize(){return axioms.size();} boolean isEmpty(){return axioms.isEmpty();} boolean contains(OWLAxiom a){return axioms.contains(a);} boolean isJustificationEntailment(){return entailment instanceof OWLAxiom && axioms.contains(entailment);} public String toString(){return "Explanation"+axioms;}
        public boolean equals(Object o){return o instanceof Explanation && Objects.equals(entailment,((Explanation<?>)o).entailment)&&axioms.equals(((Explanation<?>)o).axioms);} public int hashCode(){return Objects.hash(entailment,axioms);}
    }

    static class Ontology { Set<OWLAxiom> axioms=new HashSet<>(); boolean containsAxiom(OWLAxiom a){return axioms.contains(a);} }
    static class Manager { OWLDataFactory getOWLDataFactory(){return new OWLDataFactory();} }
    static class OWLDataFactory { OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClass a,OWLClassExpression b){return new OWLSubClassOfAxiom(a,b);} OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression>s){return new OWLObjectIntersectionOf(s);} }
    final Set<Explanation<E>> allPreviouslyFoundJustifications=new LinkedHashSet<>(),foundLaconicJustifications=new LinkedHashSet<>(); final Ontology ont=new Ontology(); final Manager man=new Manager();

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private Set<Explanation<E>> getReconstitutedLaconicJustifications() {
            

            
            
            
            
            Map<OWLAxiom, Set<OWLAxiom>> sourceAxioms2OPlus = new HashMap<OWLAxiom, Set<OWLAxiom>>();

            for (Explanation<E> exp : allPreviouslyFoundJustifications) {
                for (OWLAxiom ax : exp.getAxioms()) {
                    if (ont.containsAxiom(ax)) {
                        sourceAxioms2OPlus.put(ax, computeOPlus(Collections.singleton(ax)));
                    }
                }
            }

            Set<Explanation<E>> reconstituedExplanations = new HashSet<Explanation<E>>();
            for (Explanation<E> laconicExp : foundLaconicJustifications) {
                
                Map<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>> lhs2SubClassAxiom = new HashMap<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>>();

                Set<OWLAxiom> reconstituedAxioms = new HashSet<OWLAxiom>();
                for (OWLAxiom laconicAx : laconicExp.getAxioms()) {
                    if (laconicAx instanceof OWLSubClassOfAxiom) {
                        OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) laconicAx;
                        if (sca.getSubClass().isAnonymous()) {
                            
                            reconstituedAxioms.add(sca);
                            continue;
                        }
                        Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2AxiomMap = lhs2SubClassAxiom.get(sca.getSubClass().asOWLClass());
                        if (source2AxiomMap == null) {
                            source2AxiomMap = new HashMap<OWLAxiom, Set<OWLSubClassOfAxiom>>();
                            lhs2SubClassAxiom.put(sca.getSubClass().asOWLClass(), source2AxiomMap);
                        }
                        for (OWLAxiom sourceAx : sourceAxioms2OPlus.keySet()) {
                            if (sourceAxioms2OPlus.get(sourceAx).contains(sca)) {
                                Set<OWLSubClassOfAxiom> subClassAxioms = source2AxiomMap.get(sourceAx);
                                if (subClassAxioms == null) {
                                    subClassAxioms = new HashSet<OWLSubClassOfAxiom>();
                                    source2AxiomMap.put(sourceAx, subClassAxioms);
                                }
                                subClassAxioms.add(sca);
                            }
                        }
                    }
                    else {
                        reconstituedAxioms.add(laconicAx);
                    }
                }
                
                Set<OWLSubClassOfAxiom> consumedAxioms = new HashSet<OWLSubClassOfAxiom>();
                for (OWLClass lhs : lhs2SubClassAxiom.keySet()) {
                    Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2SubClassAxiom = lhs2SubClassAxiom.get(lhs);
                    for (OWLAxiom source : source2SubClassAxiom.keySet()) {
                        Set<OWLClassExpression> rightHandSides = new HashSet<OWLClassExpression>();
                        for (OWLSubClassOfAxiom subClassAx : source2SubClassAxiom.get(source)) {
                            if (!consumedAxioms.contains(subClassAx)) {
                                rightHandSides.add(subClassAx.getSuperClass());
                                consumedAxioms.add(subClassAx);
                            }
                        }
                        if (rightHandSides.size() == 1) {
                            reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, rightHandSides.iterator().next()));
                        }
                        else if (rightHandSides.size() > 1) {
                            OWLObjectIntersectionOf conjunction = man.getOWLDataFactory().getOWLObjectIntersectionOf(rightHandSides);
                            reconstituedAxioms.add(man.getOWLDataFactory().getOWLSubClassOfAxiom(lhs, conjunction));
                        }
                    }
                }
                Explanation<E> explanation = new Explanation<E>(laconicExp.getEntailment(), reconstituedAxioms);
                reconstituedExplanations.add(explanation);

            }
            return reconstituedExplanations;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
    Set<OWLAxiom> computeOPlus(Set<OWLAxiom>s){return new LinkedHashSet<>(s);}
    public static void main(String[] args){method_2_owlexplanation_gpt x=new method_2_owlexplanation_gpt<OWLAxiom>();OWLClass a=new OWLClass("A");OWLAxiom src=new OWLSubClassOfAxiom(a,new OWLClass("B"));x.ont.axioms.add(src);x.allPreviouslyFoundJustifications.add(new Explanation<>(src,Set.of(src)));x.foundLaconicJustifications.add(new Explanation<>(src,Set.of(src)));System.out.println("RECONSTITUTED="+x.getReconstitutedLaconicJustifications());}
}
