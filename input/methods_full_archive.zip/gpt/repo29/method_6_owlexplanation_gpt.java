import java.util.*;

public class method_6_owlexplanation_gpt<E> {
    static class OWLException extends Exception { OWLException(String m){super(m);} }
    static class ExplanationGeneratorInterruptedException extends RuntimeException {}
    static class OWLAxiom {
        final String text;
        OWLAxiom(String text){this.text=text;}
        public boolean equals(Object o){return o instanceof OWLAxiom && text.equals(((OWLAxiom)o).text);}
        public int hashCode(){return text.hashCode();}
        public String toString(){return text;}
    }
    static class Explanation<T> {
        final T entailment; final Set<OWLAxiom> axioms;
        Explanation(T entailment, Collection<OWLAxiom> axioms){this.entailment=entailment;this.axioms=new LinkedHashSet<OWLAxiom>(axioms);}
        T getEntailment(){return entailment;} Set<OWLAxiom> getAxioms(){return Collections.unmodifiableSet(axioms);}
        public boolean equals(Object o){return o instanceof Explanation && Objects.equals(entailment,((Explanation<?>)o).entailment)&&axioms.equals(((Explanation<?>)o).axioms);}
        public int hashCode(){return Objects.hash(entailment,axioms);}
        public String toString(){return "Explanation"+axioms;}
    }
    interface ExplanationGenerator<T>{Set<Explanation<T>> getExplanations(T entailment);}
    interface ExplanationGeneratorFactory<T>{ExplanationGenerator<T> createExplanationGenerator(Set<OWLAxiom> axioms, method_6_owlexplanation_gpt<T> monitor);}
    static class Ontology { final Set<OWLAxiom> logicalAxioms=new LinkedHashSet<OWLAxiom>(); Set<OWLAxiom> getLogicalAxioms(){return logicalAxioms;} }

    int limit;
    boolean cancelled;
    final Set<Explanation<E>> foundLaconicJustifications=new LinkedHashSet<Explanation<E>>();
    final Set<Explanation<E>> lastRegularJusts=new LinkedHashSet<Explanation<E>>();
    Set<Explanation<E>> allPreviouslyFoundJustifications=new LinkedHashSet<Explanation<E>>();
    final Set<OWLAxiom> axioms=new LinkedHashSet<OWLAxiom>();
    final Ontology ont=new Ontology();
    final ExplanationGeneratorFactory<E> explanationGeneratorFactory;

    method_6_owlexplanation_gpt(){
        explanationGeneratorFactory=new ExplanationGeneratorFactory<E>(){
            public ExplanationGenerator<E> createExplanationGenerator(final Set<OWLAxiom> source, final method_6_owlexplanation_gpt<E> monitor){
                return new ExplanationGenerator<E>(){
                    public Set<Explanation<E>> getExplanations(E entailment){
                        LinkedHashSet<Explanation<E>> result=new LinkedHashSet<Explanation<E>>();
                        LinkedHashSet<OWLAxiom> selected=new LinkedHashSet<OWLAxiom>();
                        int count=0;
                        for(OWLAxiom ax:source){selected.add(ax);if(++count==2)break;}
                        if(!selected.isEmpty()){
                            Explanation<E> exp=new Explanation<E>(entailment,selected);
                            result.add(exp);
                            monitor.foundLaconicJustifications.add(exp);
                        }
                        return result;
                    }
                };
            }
        };
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public Set<Explanation<E>> computePreciseJustsOptimised(E entailment, int limit) throws OWLException {
        this.limit = limit;
        foundLaconicJustifications.clear();
        ExplanationGenerator<E> gen = explanationGeneratorFactory.createExplanationGenerator(axioms, this);
        Set<Explanation<E>> regularJusts = null;
        try {
            regularJusts = gen.getExplanations(entailment);
        }
        catch (ExplanationGeneratorInterruptedException e) {
            
            return foundLaconicJustifications;
        }
        if (isCancelled()) {
            return foundLaconicJustifications;
        }
        lastRegularJusts.clear();

        
        allPreviouslyFoundJustifications = new HashSet<Explanation<E>>();
        allPreviouslyFoundJustifications.addAll(regularJusts);




        Set<OWLAxiom> axiomsInPreviousOntology = new HashSet<OWLAxiom>();

        
        while (true) {

            if (isCancelled()) {
                return getReconstitutedLaconicJustifications();
            }
            
            

            Set<OWLAxiom> unionOfAllJustifications = new HashSet<OWLAxiom>();
            for (Explanation<E> exp : allPreviouslyFoundJustifications) {
                unionOfAllJustifications.addAll(exp.getAxioms());
            }
            Set<OWLAxiom> oPlus = computeOPlus(unionOfAllJustifications);

            
            Set<OWLAxiom> augmentedAxioms = new HashSet<OWLAxiom>(oPlus);

            
            
            

            
            
            
            
            
            
            
            
            for (OWLAxiom ax : ont.getLogicalAxioms()) {
                
                
                if (unionOfAllJustifications.contains(ax) && !oPlus.contains(ax)) {
                    continue;
                }
                augmentedAxioms.add(ax);
            }

            
            

            


            if (augmentedAxioms.equals(axiomsInPreviousOntology)) {
                break;
            }

            ExplanationGenerator<E> gen2 = explanationGeneratorFactory.createExplanationGenerator(augmentedAxioms, this);

            axiomsInPreviousOntology.clear();
            axiomsInPreviousOntology.addAll(augmentedAxioms);

            Set<Explanation> allPrevJustsCopy = new HashSet<Explanation>(allPreviouslyFoundJustifications);

            
            Set<Explanation<E>> currentJustifications = null;
            try {
                currentJustifications = gen2.getExplanations(entailment);
            }
            catch (ExplanationGeneratorInterruptedException e) {
                return getReconstitutedLaconicJustifications();
            }
            if (isCancelled()) {
                return getReconstitutedLaconicJustifications();
            }
            allPreviouslyFoundJustifications.addAll(currentJustifications);
            if (allPreviouslyFoundJustifications.equals(allPrevJustsCopy)) {
                break;
            }
            
            

















        }


















        return getReconstitutedLaconicJustifications();
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    boolean isCancelled(){return cancelled;}
    Set<OWLAxiom> computeOPlus(Set<OWLAxiom> source){return new LinkedHashSet<OWLAxiom>(source);}
    Set<Explanation<E>> getReconstitutedLaconicJustifications(){return new LinkedHashSet<Explanation<E>>(foundLaconicJustifications);}

    public static void main(String[] args) throws Exception {
        method_6_owlexplanation_gpt<OWLAxiom> generator=new method_6_owlexplanation_gpt<OWLAxiom>();
        OWLAxiom a=new OWLAxiom("A SubClassOf B"); OWLAxiom b=new OWLAxiom("B SubClassOf C"); OWLAxiom extra=new OWLAxiom("D SubClassOf E");
        generator.axioms.add(a);generator.axioms.add(b);generator.ont.logicalAxioms.addAll(Arrays.asList(a,b,extra));
        Set<Explanation<OWLAxiom>> result=generator.computePreciseJustsOptimised(new OWLAxiom("A SubClassOf C"),5);
        System.out.println("PRECISE_JUSTIFICATION_COUNT="+result.size());
        for(Explanation<OWLAxiom> e:result)System.out.println("JUSTIFICATION="+e.getAxioms());
        System.out.println("ALL_PREVIOUSLY_FOUND="+generator.allPreviouslyFoundJustifications.size());
    }
}
