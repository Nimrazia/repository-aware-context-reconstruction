import java.util.*;
import java.io.*;

public class method_4_owlexplanation_gpt {

    static class OWLAxiom {
        final String text; final boolean logical;
        OWLAxiom(String text){this(text,true);} OWLAxiom(String text, boolean logical){this.text=text;this.logical=logical;}
        boolean isLogicalAxiom(){return logical;}
        OWLAxiom getAnnotatedAxiom(Set<OWLAnnotation> a){return new OWLAxiom(text+" annotations="+a);}
        public boolean equals(Object o){return o instanceof OWLAxiom && text.equals(((OWLAxiom)o).text);} public int hashCode(){return text.hashCode();}
        public String toString(){return text;}
    }
    static class OWLClassExpression { final String text; OWLClassExpression(String t){text=t;} boolean isAnonymous(){return true;} OWLClass asOWLClass(){throw new IllegalStateException();} public String toString(){return text;} }
    static class OWLClass extends OWLClassExpression { OWLClass(String t){super(t);} boolean isAnonymous(){return false;} OWLClass asOWLClass(){return this;} public boolean equals(Object o){return o instanceof OWLClass&&text.equals(((OWLClass)o).text);} public int hashCode(){return text.hashCode();} }
    static class OWLSubClassOfAxiom extends OWLAxiom { final OWLClassExpression sub,sup; OWLSubClassOfAxiom(OWLClassExpression a,OWLClassExpression b){super(a+" ⊑ "+b);sub=a;sup=b;} OWLClassExpression getSubClass(){return sub;} OWLClassExpression getSuperClass(){return sup;} }
    static class OWLObjectIntersectionOf extends OWLClassExpression { OWLObjectIntersectionOf(Set<OWLClassExpression>s){super("and"+s);} }
    static class Explanation<T> {
        final T entailment; final Set<OWLAxiom> axioms;
        Explanation(T e, Set<OWLAxiom>a){entailment=e;axioms=new LinkedHashSet<>(a);} static <T> Explanation<T> getEmptyExplanation(T e){return new Explanation<>(e,Collections.emptySet());}
        Set<OWLAxiom> getAxioms(){return axioms;} T getEntailment(){return entailment;} int getSize(){return axioms.size();} boolean isEmpty(){return axioms.isEmpty();} boolean contains(OWLAxiom a){return axioms.contains(a);} boolean isJustificationEntailment(){return entailment instanceof OWLAxiom && axioms.contains(entailment);} public String toString(){return "Explanation"+axioms;}
        public boolean equals(Object o){return o instanceof Explanation && Objects.equals(entailment,((Explanation<?>)o).entailment)&&axioms.equals(((Explanation<?>)o).axioms);} public int hashCode(){return Objects.hash(entailment,axioms);}
    }

    static final String ENTAILMENT_MARKER_IRI="urn:entailment";
    static class IRI{} static class OWLAnnotationProperty{} static class OWLAnnotation{public String toString(){return "entailed=true";}} static class OWLOntology {final Set<OWLAxiom>a;OWLOntology(Set<OWLAxiom>a){this.a=a;}}
    static class OWLDataFactory { OWLAnnotationProperty getOWLAnnotationProperty(String i){return new OWLAnnotationProperty();} OWLAnnotation getOWLAnnotation(OWLAnnotationProperty p,Object l){return new OWLAnnotation();} Object getOWLLiteral(boolean b){return b;} }
    static class OWLOntologyManager { OWLOntology createOntology(Set<OWLAxiom>a)throws OWLOntologyCreationException{return new OWLOntology(a);} OWLDataFactory getOWLDataFactory(){return new OWLDataFactory();} void addAxiom(OWLOntology o,OWLAxiom a){o.a.add(a);} void saveOntology(OWLOntology o,Object f,OutputStream os)throws OWLOntologyStorageException{try{os.write(("<Ontology>"+o.a+"</Ontology>").getBytes());os.flush();}catch(IOException e){throw new OWLOntologyStorageException();}} }
    static class OWLManager { static OWLOntologyManager createOWLOntologyManager(){return new OWLOntologyManager();} } static class OWLXMLDocumentFormat{} static class OWLOntologyStorageException extends Exception{} static class OWLOntologyCreationException extends Exception{}

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public static void store(Explanation<OWLAxiom> explanation, OutputStream os) throws IOException {
            try {
                OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
                OWLOntology ontology = manager.createOntology(explanation.getAxioms());
                OWLDataFactory df = manager.getOWLDataFactory();
                OWLAnnotationProperty entailmentMarkerAnnotationProperty = df.getOWLAnnotationProperty(ENTAILMENT_MARKER_IRI);
                OWLAnnotation entailmentAnnotation = df.getOWLAnnotation(entailmentMarkerAnnotationProperty, df.getOWLLiteral(true));
                OWLAxiom annotatedEntailment = explanation.getEntailment().getAnnotatedAxiom(Collections.singleton(entailmentAnnotation));
                manager.addAxiom(ontology, annotatedEntailment);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(os);
                OWLXMLDocumentFormat justificationOntologyFormat = new OWLXMLDocumentFormat();
                manager.saveOntology(ontology, justificationOntologyFormat, bufferedOutputStream);
            }
            catch (OWLOntologyStorageException | OWLOntologyCreationException e) {
                throw new RuntimeException(e);
            }

        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args)throws Exception{OWLAxiom e=new OWLAxiom("A ⊑ B");Explanation<OWLAxiom>x=new Explanation<>(e,new LinkedHashSet<>(Set.of(e)));ByteArrayOutputStream out=new ByteArrayOutputStream();store(x,out);System.out.println("SERIALIZED="+out.toString());}
}
