import java.util.*;

public class method_5_owlexplanation_gpt<E> {

    static class OWLAnnotation {}
    static class OWLAxiom {
        final String text; final boolean logical;
        OWLAxiom(String text){this(text,true);} OWLAxiom(String text, boolean logical){this.text=text;this.logical=logical;}
        boolean isLogicalAxiom(){return logical;}
        OWLAxiom getAnnotatedAxiom(Set<OWLAnnotation> a){return new OWLAxiom(text+" annotations="+a);}
        public boolean equals(Object o){return o instanceof OWLAxiom && text.equals(((OWLAxiom)o).text);} public int hashCode(){return text.hashCode();}
        public String toString(){return text;}
    }
    static class OWLClassExpression { final String text; OWLClassExpression(String t){text=t;} boolean isAnonymous(){return true;} OWLClass asOWLClass(){throw new IllegalStateException();} public String toString(){return text;} }
    static class OWLClass extends OWLClassExpression { OWLClass(String t){super(t);} boolean isAnonymous(){return false;} OWLClass asOWLClass(){return this;} public boolean equals(Object o){return o instanceof OWLClass&&text.equals(((OWLClass)o).text);} public int hashCode(){return text.hashCode();} }
    static class OWLSubClassOfAxiom extends OWLAxiom { final OWLClassExpression sub,sup; OWLSubClassOfAxiom(OWLClassExpression a,OWLClassExpression b){super(a+" ⊑ "+b);sub=a;sup=b;} OWLClassExpression getSubClass(){return sub;} OWLClassExpression getSuperClass(){return sup;} }
    static class OWLObjectIntersectionOf extends OWLClassExpression { OWLObjectIntersectionOf(Set<OWLClassExpression>s){super("and"+s);} }
    static class Explanation<T> {
        final T entailment; final Set<OWLAxiom> axioms;
        Explanation(T e, Set<OWLAxiom>a){entailment=e;axioms=new LinkedHashSet<>(a);} static <T> Explanation<T> getEmptyExplanation(T e){return new Explanation<>(e,Collections.emptySet());}
        Set<OWLAxiom> getAxioms(){return axioms;} T getEntailment(){return entailment;} int getSize(){return axioms.size();} boolean isEmpty(){return axioms.isEmpty();} boolean contains(OWLAxiom a){return axioms.contains(a);} boolean isJustificationEntailment(){return entailment instanceof OWLAxiom && axioms.contains(entailment);} public String toString(){return "Explanation"+axioms;}
        public boolean equals(Object o){return o instanceof Explanation && Objects.equals(entailment,((Explanation<?>)o).entailment)&&axioms.equals(((Explanation<?>)o).axioms);} public int hashCode(){return Objects.hash(entailment,axioms);}
    }

    static class OWLException extends Exception{} static class OWLRuntimeException extends RuntimeException{OWLRuntimeException(String s){super(s);}} static class MutableTree<T>{MutableTree(T t){}}
    static class Monitor {boolean isCancelled(){return false;} void foundExplanation(Object g,Explanation<?>e,Set<?>all){System.out.println("FOUND="+e);}}
    final Set<OWLAxiom> module=new LinkedHashSet<>(); final Monitor progressMonitor=new Monitor();

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private void constructHittingSetTree(E entailment, Explanation<E> justification, Set<Explanation<E>> allJustifications,
                                             Set<Set<OWLAxiom>> satPaths, Set<OWLAxiom> currentPathContents,
                                             int maxExplanations) throws OWLException {

    
            
            
            List<OWLAxiom> orderedJustification = getOrderedJustifications(new ArrayList<OWLAxiom>(justification.getAxioms()), allJustifications);

            while (!orderedJustification.isEmpty()) {
                OWLAxiom axiom = orderedJustification.get(0);
                orderedJustification.remove(0);
                if (allJustifications.size() == maxExplanations) {
                    return;
                }

                
                

                module.remove(axiom);
                currentPathContents.add(axiom);

                boolean earlyTermination = false;
                
                
                for (Set<OWLAxiom> satPath : satPaths) {
                    if (currentPathContents.containsAll(satPath)) {
                        earlyTermination = true;
                        break;
                    }
                }

                if (!earlyTermination) {
                    Explanation<E> newJustification = null;
                    for (Explanation<E> foundJustification : allJustifications) {
                        Set<OWLAxiom> foundMUPSCopy = new HashSet<OWLAxiom>(foundJustification.getAxioms());
                        foundMUPSCopy.retainAll(currentPathContents);
                        if (foundMUPSCopy.isEmpty()) {
                            
                            newJustification = foundJustification;
                            break;
                        }
                    }
                    if (newJustification == null) {
                        newJustification = computeExplanation(entailment);
                    }
                    
                    if (axiom.isLogicalAxiom() && newJustification.contains(axiom)) {
                        
                        throw new OWLRuntimeException("Explanation contains removed axiom: " + axiom + " (Working axioms contains axiom: " + module.contains(axiom) + ")");
                    }

                    if (!newJustification.isEmpty()) {
                        
                        
                        
                        
                        boolean added = allJustifications.add(newJustification);
                        if (added) {
                            progressMonitor.foundExplanation(this, newJustification, allJustifications);
                        }
                        if (progressMonitor.isCancelled()) {
                            return;
                        }

                        
    
    
                        constructHittingSetTree(entailment,
                                newJustification,
                                allJustifications,
                                satPaths,
                                currentPathContents,
                                maxExplanations);
                        
                        
                        orderedJustification = getOrderedJustifications(orderedJustification, allJustifications);
                    } else {
                        
                        satPaths.add(new HashSet<OWLAxiom>(currentPathContents));
                        Explanation exp = new Explanation<E>(entailment, new HashSet<OWLAxiom>(0));
                        MutableTree<Explanation> node = new MutableTree<Explanation>(exp);
    
    
                    }
                }

                
                currentPathContents.remove(axiom);

                
                module.add(axiom);
            }
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    List<OWLAxiom> getOrderedJustifications(List<OWLAxiom>a,Set<Explanation<E>>all){a.sort(Comparator.comparing(Object::toString));return a;}
    Explanation<E> computeExplanation(E e){return e instanceof OWLAxiom && module.contains((OWLAxiom)e)?new Explanation<>(e,Set.of((OWLAxiom)e)):Explanation.getEmptyExplanation(e);}

    public static void main(String[] args)throws Exception{method_5_owlexplanation_gpt x=new method_5_owlexplanation_gpt<OWLAxiom>();OWLAxiom a=new OWLAxiom("Axiom-1"),b=new OWLAxiom("Axiom-2");x.module.addAll(Set.of(a,b));Explanation<OWLAxiom> j=new Explanation<>(a,Set.of(a,b));Set<Explanation<OWLAxiom>>all=new LinkedHashSet<>();all.add(j);x.constructHittingSetTree(a,j,all,new LinkedHashSet<>(),new LinkedHashSet<>(),3);System.out.println("JUSTIFICATIONS="+all.size()+" MODULE="+x.module);}
}
