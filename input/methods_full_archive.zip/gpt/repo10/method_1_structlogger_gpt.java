import java.util.*;
import java.util.regex.*;

public class method_1_structlogger_gpt {
    static class SimpleName implements CharSequence {
     final String v;SimpleName(String s){v=s;}public int length(){return v.length();}public char charAt(int i){return v.charAt(i);}public CharSequence subSequence(int s,int e){return v.subSequence(s,e);}public boolean contentEquals(CharSequence c){return v.contentEquals(c);}public String toString(){return v;}public boolean equals(Object o){return o instanceof SimpleName&&v.equals(o.toString());}public int hashCode(){return v.hashCode();}
    }
    interface Name extends CharSequence{boolean contentEquals(CharSequence c);}
    static class N extends SimpleName implements Name{N(String s){super(s);}}
    static class JCTree{static class JCLiteral implements ExpressionTree{Object value;JCLiteral(Object v){value=v;}Object getValue(){return value;}}}
    interface ExpressionTree{}
    interface MethodInvocationTree{List<? extends ExpressionTree> getArguments();}
    static class Invocation implements MethodInvocationTree{List<ExpressionTree>a=new ArrayList<>();public List<? extends ExpressionTree>getArguments(){return a;}}
    static class StatementInfo{String statement;StatementInfo(String s){statement=s;}String getStatement(){return statement;}public String toString(){return statement;}}
    static class MethodAndParameter{Name methodName;Object parameter;MethodAndParameter(String n,Object p){methodName=new N(n);parameter=p;}Name getMethodName(){return methodName;}Object getParameter(){return parameter;}}
    static class Variable{Name name;Object type;Variable(Name n,Object t){name=n;type=t;}Variable(String n,Object t){this(new N(n),t);}Name getName(){return name;}}
    static class VariableAndValue{Variable variable;Object value;VariableAndValue(Variable v,Object x){variable=v;value=x;}public boolean equals(Object o){return o instanceof VariableAndValue&&variable.getName().toString().equals(((VariableAndValue)o).variable.getName().toString());}}
    enum LogLevel{INFO("info","INFO","infoEvent"),DEBUG("debug","DEBUG","debugEvent"),ERROR("error","ERROR","errorEvent");String lm,ln,em;LogLevel(String a,String b,String c){lm=a;ln=b;em=c;}String getLevelMethodName(){return lm;}String getLevelName(){return ln;}String getLogEventMethodName(){return em;}}
    static class TypeMirror{String name;TypeMirror(String n){name=n;}public String toString(){return name;}public boolean equals(Object o){return o instanceof TypeMirror&&name.equals(((TypeMirror)o).name);}public int hashCode(){return name.hashCode();}}
    static class StructLoggerFieldContext{TypeMirror c;StructLoggerFieldContext(TypeMirror t){c=t;}TypeMirror getContextProvider(){return c;}}
    static class VariableContextProvider{TypeMirror tm;List<Variable>vars;boolean p;VariableContextProvider(TypeMirror t,List<Variable>v,boolean p){tm=t;vars=v;this.p=p;}List<Variable>getVariables(){return vars;}boolean shouldParametrize(){return p;}TypeMirror getTypeMirror(){return tm;}}
    static class ScannerParams{Map<Name,StructLoggerFieldContext>fields;Map<TypeMirror,VariableContextProvider>vars;List<GeneratedClassInfo>generated;ScannerParams(Object...o){fields=(Map<Name,StructLoggerFieldContext>)o[3];vars=(Map<TypeMirror,VariableContextProvider>)o[2];generated=(List<GeneratedClassInfo>)o[4];}Map<Name,StructLoggerFieldContext>getFields(){return fields;}Map<TypeMirror,VariableContextProvider>getVarsHashMap(){return vars;}List<GeneratedClassInfo>getGeneratedClassesInfo(){return generated;}}
    static class TypeSpec{String name;TypeSpec(String n){name=n;}}static class JavaFile{String packageName;TypeSpec typeSpec;JavaFile(String p,String n){packageName=p;typeSpec=new TypeSpec(n);}}
    static class GeneratedClassInfo{String q,c,l,p;List<VariableAndValue>u;GeneratedClassInfo(String q,String c,String l,List<VariableAndValue>u,String p){this.q=q;this.c=c;this.l=l;this.u=u;this.p=p;}String getQualifiedName(){return q;}List<VariableAndValue>getUsedVariables(){return u;}}
    static class PackageNameException extends Exception{}
    static class PojoService{JavaFile createPojo(String event,JCTree.JCLiteral l,List<VariableAndValue>v)throws PackageNameException{String q=event==null?"generated.Event":event;int i=q.lastIndexOf('.');return new JavaFile(i<0?"":q.substring(0,i),i<0?q:q.substring(i+1));}void writeJavaFile(JavaFile f){System.out.println("Generated "+f.packageName+"."+f.typeSpec.name);}}
    static class Messager{List<String>messages=new ArrayList<>();void printMessage(Object...o){String s=Arrays.toString(o);messages.add(s);System.out.println("MESSAGE "+s);}}
    static class Diagnostic{enum Kind{ERROR,WARNING}}
    static class StringUtils{static int countMatches(String s,String x){int c=0,p=0;while((p=s.indexOf(x,p))>=0){c++;p+=x.length();}return c;}static boolean isBlank(String s){return s==null||s.trim().isEmpty();}}
    static class LoggingEvent{String level,message,threadName;}
    static String formatWithStatementLocation(String f,Object...o){return String.format(f,o);}
    static String format(String f,Object...o){return String.format(f,o);}

    final Messager messager=new Messager();final PojoService pojoService=new PojoService();
    void addToUsedVariables(List<VariableAndValue>u,MethodAndParameter m,Variable v){u.add(new VariableAndValue(v,m.getParameter()));}
    void printStatementMustHaveStringLiteralError(StatementInfo s,Name n){messager.printMessage(Diagnostic.Kind.ERROR,"literal required "+n);}
    void replaceInCode(String n,GeneratedClassInfo g,StatementInfo s,List<VariableAndValue>u,JCTree.JCLiteral l,String level,VariableContextProvider v){System.out.println("Replaced "+s+" with "+g.getQualifiedName()+" level="+level);}

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private void handleStructLogExpression(final Stack<MethodAndParameter> stack,
                                               final MethodInvocationTree node,
                                               final Name name,
                                               final StatementInfo statementInfo,
                                               final ScannerParams scannerParams) {
            final java.util.List<VariableAndValue> usedVariables = new ArrayList<>();
            JCTree.JCLiteral literal = null;
            String level = null;
            String eventName = null;

            
            final StructLoggerFieldContext structLoggerFieldContext = scannerParams.getFields().get(name);
            final TypeMirror typeMirror = structLoggerFieldContext.getContextProvider();
            final VariableContextProvider variableContextProvider = scannerParams.getVarsHashMap().get(typeMirror);

            
            
            while (!stack.empty()) {
                
                boolean matched = false;
                final MethodAndParameter top = stack.pop();
                
                for (Variable variable : variableContextProvider.getVariables()) {
                    final Name topMethodName = top.getMethodName();

                    if (variable.getName().equals(topMethodName)) {
                        addToUsedVariables(usedVariables, top, variable);
                        matched = true;
                        break;
                    }
                    else {
                        for (LogLevel logLevel : LogLevel.values()) {
                            if (topMethodName.contentEquals(logLevel.getLevelMethodName())) {
                                if (!(node.getArguments().get(0) instanceof JCTree.JCLiteral)) {
                                    printStatementMustHaveStringLiteralError(statementInfo, topMethodName);
                                    return;
                                }
                                literal = (JCTree.JCLiteral) node.getArguments().get(0);
                                level = logLevel.getLevelName();
                                matched = true;
                                break;
                            }
                            else if (topMethodName.contentEquals(logLevel.getLogEventMethodName())) {
                                return; 
                            }
                        }
                    }
                }

                if (top.getMethodName().contentEquals("log") && top.getParameter() != null) {
                    if (!(top.getParameter() instanceof JCTree.JCLiteral)) {
                        printStatementMustHaveStringLiteralError(statementInfo, top.getMethodName());
                        return;
                    }
                    eventName = ((JCTree.JCLiteral) top.getParameter()).getValue().toString();
                    if (!Pattern.compile("^(\\w+(\\.\\w+)*)+$").matcher(eventName).matches()) {
                        messager.printMessage(
                                Diagnostic.Kind.ERROR,
                                formatWithStatementLocation(
                                        "qualified event name %s specified by %s statement is not valid",
                                        statementInfo,
                                        eventName,
                                        statementInfo.getStatement()
                                )
                        );
                        return;
                    }
                    matched = true;
                } else if (top.getMethodName().contentEquals("log") && top.getParameter() == null) {
                    matched = true;
                }
                if (stack.empty() && !top.getMethodName().contentEquals("log")) {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            formatWithStatementLocation(
                                    "statement %s must be ended by calling log() method",
                                    statementInfo,
                                    statementInfo.getStatement()
                            )
                    );
                    return;
                }
                if (!matched) {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            formatWithStatementLocation(
                                    "variable %s in statement %s is not specified by variable context %s",
                                    statementInfo,
                                    top.getMethodName(),
                                    statementInfo.getStatement(),
                                    variableContextProvider.getTypeMirror()
                            )
                    );
                    return;
                }
            }

            
            if (variableContextProvider.shouldParametrize()) {
                final int countOfStringVariables = StringUtils.countMatches(literal.getValue().toString(), "{}");
                if (countOfStringVariables != usedVariables.size()) {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            formatWithStatementLocation(
                                    "literal %s contains %d variables, but statement %s uses %d variables",
                                    statementInfo,
                                    literal.getValue().toString(),
                                    countOfStringVariables,
                                    statementInfo.getStatement(),
                                    usedVariables.size()
                            )
                    );
                    return;
                }
            }

            
            JavaFile javaFile;
            try {
                javaFile = pojoService.createPojo(eventName, literal, usedVariables);
            } catch (PackageNameException e) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "qualified event name %s generated by statement %s is not valid, please check specified event name and package does not contain java keyword or no subpackage or class name starts with number",
                                statementInfo,
                                eventName,
                                statementInfo.getStatement()
                        )
                );
                return;
            }
            final String className = javaFile.typeSpec.name;
            final String qualifiedName = StringUtils.isBlank(javaFile.packageName) ? className : javaFile.packageName + "." + className;
            final GeneratedClassInfo generatedClassInfo = new GeneratedClassInfo(qualifiedName, className, (String) literal.getValue(), usedVariables, javaFile.packageName);
            for (GeneratedClassInfo info : scannerParams.getGeneratedClassesInfo()) {
                if (info.getQualifiedName().equals(generatedClassInfo.getQualifiedName())
                        && !info.getUsedVariables().equals(generatedClassInfo.getUsedVariables())
                        ) {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            formatWithStatementLocation(
                                    "Statement %s generates different event structure for same event name",
                                    statementInfo,
                                    statementInfo.getStatement()
                            )
                    );
                    return;
                }
            }
            scannerParams.getGeneratedClassesInfo().add(generatedClassInfo);

            pojoService.writeJavaFile(javaFile);

            
            replaceInCode(name.toString(), generatedClassInfo, statementInfo, usedVariables, literal, level, variableContextProvider);
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    



    public static void main(String[]a){
     method_1_structlogger_gpt x=new method_1_structlogger_gpt();TypeMirror tm=new TypeMirror("Ctx");Variable v=new Variable("user",String.class);
     Map<TypeMirror,VariableContextProvider>vm=new HashMap<>();vm.put(tm,new VariableContextProvider(tm,Arrays.asList(v),true));
     N loggerName=new N("LOG");Map<Name,StructLoggerFieldContext>fm=new HashMap<>();fm.put(loggerName,new StructLoggerFieldContext(tm));
     List<GeneratedClassInfo>g=new ArrayList<>();ScannerParams sp=new ScannerParams(null,null,vm,fm,g);
     Stack<MethodAndParameter>st=new Stack<>();st.push(new MethodAndParameter("log",new JCTree.JCLiteral("demo.Login")));st.push(new MethodAndParameter("info",null));st.push(new MethodAndParameter("user","alice"));
     Invocation inv=new Invocation();inv.a.add(new JCTree.JCLiteral("User {} logged in"));
     x.handleStructLogExpression(st,inv,loggerName,new StatementInfo("LOG.user(...).info(...).log(...)"),sp);
     System.out.println("generatedClasses="+g.size()+", messages="+x.messager.messages.size());
    }
}
