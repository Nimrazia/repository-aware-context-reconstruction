import java.io.*;
import java.util.*;
public class method_4_openengsb_gpt {
    static final Logger LOGGER=new Logger(); static final String FILEWRAPPER_FILENAME_SUFFIX=".filename";
    static void fillEDBObjectWithEngineeringObjectInformation(EDBObject o,OpenEngSBModel m)throws IllegalAccessException{}
    static String getEntryNameForList(String p,int i){return p+"."+i;} static String getEntryNameForMapKey(String p,int i){return p+"."+i+".key";} static String getEntryNameForMapValue(String p,int i){return p+"."+i+".value";}

// ORIGINAL CODESEARCHNET METHOD — START

private String convertSubModel(OpenEngSBModel model, List<EDBObject> objects, ConnectorInformation info) {
        String contextId = ContextHolder.get().getCurrentContextId();
        String oid = ModelWrapper.wrap(model).getCompleteModelOID();
        EDBObject object = new EDBObject(oid);
        try {
            fillEDBObjectWithEngineeringObjectInformation(object, model);
        } catch (IllegalAccessException e) {
            LOGGER.warn("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
            throw new EKBException("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
        }
        for (OpenEngSBModelEntry entry : model.toOpenEngSBModelEntries()) {
            if (entry.getValue() == null) {
                continue;
            } else if (entry.getType().equals(FileWrapper.class)) {
                try {
                    FileWrapper wrapper = (FileWrapper) entry.getValue();
                    String content = Base64.encodeBase64String(wrapper.getContent());
                    object.putEDBObjectEntry(entry.getKey(), content, String.class);
                    object.putEDBObjectEntry(entry.getKey() + FILEWRAPPER_FILENAME_SUFFIX,
                        wrapper.getFilename(), String.class);
                } catch (IOException e) {
                    LOGGER.error(e.getMessage());
                }
            } else if (OpenEngSBModel.class.isAssignableFrom(entry.getType())) {
                OpenEngSBModel temp = (OpenEngSBModel) entry.getValue();
                String subOid = convertSubModel(temp, objects, info);
                object.putEDBObjectEntry(entry.getKey(), subOid, String.class);
            } else if (List.class.isAssignableFrom(entry.getType())) {
                List<?> list = (List<?>) entry.getValue();
                if (list == null || list.size() == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < list.size(); i++) {
                    Object item = list.get(i);
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (entry.getType().isArray()) {
                Object[] array = (Object[]) entry.getValue();
                if (array == null || array.length == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < array.length; i++) {
                    Object item = array[i];
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (Map.class.isAssignableFrom(entry.getType())) {
                Map<?, ?> map = (Map<?, ?>) entry.getValue();
                if (map == null || map.size() == 0) {
                    continue;
                }
                Boolean keyIsModel = null;
                Boolean valueIsModel = null;
                int i = 0;
                for (Map.Entry<?, ?> ent : map.entrySet()) {
                    if (keyIsModel == null) {
                        keyIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getKey().getClass());
                    }
                    if (valueIsModel == null) {
                        valueIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getValue().getClass());
                    }
                    Object key = ent.getKey();
                    Object value = ent.getValue();
                    if (keyIsModel) {
                        key = convertSubModel((OpenEngSBModel) key, objects, info);
                    }
                    if (valueIsModel) {
                        value = convertSubModel((OpenEngSBModel) value, objects, info);
                    }
                    object.putEDBObjectEntry(getEntryNameForMapKey(entry.getKey(), i), key);
                    object.putEDBObjectEntry(getEntryNameForMapValue(entry.getKey(), i), value);
                    i++;
                }
            } else {
                object.putEDBObjectEntry(entry.getKey(), entry.getValue(), entry.getType());
            }
        }
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE, model.retrieveModelName());
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, model.retrieveModelVersion());
        object.putEDBObjectEntry("domainId", info.getDomainId());
        object.putEDBObjectEntry("connectorId", info.getConnectorId());
        object.putEDBObjectEntry("instanceId", info.getInstanceId());
        object.putEDBObjectEntry("contextId", contextId);
        objects.add(object);
        return oid;
    }

// ORIGINAL CODESEARCHNET METHOD — END

    public static void main(String[]a){method_4_openengsb_gpt x=new method_4_openengsb_gpt(); List<EDBObject> os=new ArrayList<>(); BasicModel child=new BasicModel("child"); BasicModel root=new BasicModel("root"); root.e.add(new OpenEngSBModelEntry("child",child,BasicModel.class)); root.e.add(new OpenEngSBModelEntry("items",Arrays.asList("a","b"),List.class)); String oid=x.convertSubModel(root,os,new ConnectorInformation()); System.out.println("oid="+oid+", objects="+os.size()+", rootEntries="+os.get(os.size()-1).m.size());}
    interface OpenEngSBModel{List<OpenEngSBModelEntry> toOpenEngSBModelEntries();String retrieveModelName();String retrieveModelVersion();}
    static class BasicModel implements OpenEngSBModel{String id;List<OpenEngSBModelEntry>e=new ArrayList<>();BasicModel(String i){id=i;}public List<OpenEngSBModelEntry>toOpenEngSBModelEntries(){return e;}public String retrieveModelName(){return getClass().getName();}public String retrieveModelVersion(){return "1";}}
    static class OpenEngSBModelEntry{String k;Object v;Class<?>t;OpenEngSBModelEntry(String k,Object v,Class<?>t){this.k=k;this.v=v;this.t=t;}String getKey(){return k;}Object getValue(){return v;}Class<?>getType(){return t;}}
    static class EDBObject{String oid;Map<String,Object>m=new LinkedHashMap<>();EDBObject(String o){oid=o;}void putEDBObjectEntry(String k,Object v){m.put(k,v);}void putEDBObjectEntry(String k,Object v,Class<?>t){m.put(k,v);}}
    static class ConnectorInformation{String getDomainId(){return "domain";}String getConnectorId(){return "connector";}String getInstanceId(){return "instance";}}
    static class ContextHolder{static ContextHolder get(){return new ContextHolder();}String getCurrentContextId(){return "ctx";}}
    static class ModelWrapper{OpenEngSBModel m;ModelWrapper(OpenEngSBModel m){this.m=m;}static ModelWrapper wrap(OpenEngSBModel m){return new ModelWrapper(m);}String getCompleteModelOID(){return "oid:"+((BasicModel)m).id;}}
    static class FileWrapper{String f;byte[]c;String getFilename(){return f;}byte[]getContent()throws IOException{return c;}}
    static class Base64{static String encodeBase64String(byte[]b){return java.util.Base64.getEncoder().encodeToString(b);}}
    static class EDBConstants{static final String MODEL_TYPE="modelType",MODEL_TYPE_VERSION="modelVersion";} static class EKBException extends RuntimeException{EKBException(String s,Throwable t){super(s,t);}} static class Logger{void warn(String s,Throwable t){}void error(String s){}}

}
