import java.util.*;
public class method_6_openengsb_gpt {
    String getUser(){return "tester";}String getContextId(){return "ctx";}Set<Class<?>>extractTypes(Collection<OpenEngSBModel>...cs){Set<Class<?>>s=new HashSet<>();for(Collection<OpenEngSBModel>c:cs)for(OpenEngSBModel m:c)s.add(m.getClass());return s;}Map<Class<?>,List<OpenEngSBModel>>mapByClass(Collection<OpenEngSBModel>ms){Map<Class<?>,List<OpenEngSBModel>>r=new LinkedHashMap<>();for(OpenEngSBModel m:ms)r.computeIfAbsent(m.getClass(),k->new ArrayList<>()).add(m);return r;}

// ORIGINAL CODESEARCHNET METHOD — START

public IndexCommit convert(EKBCommit ekbCommit) {
        IndexCommit commit = new IndexCommit();

        commit.setCommitId(ekbCommit.getRevisionNumber());
        commit.setParentCommitId(ekbCommit.getParentRevisionNumber());
        commit.setConnectorId(ekbCommit.getConnectorId());
        commit.setDomainId(ekbCommit.getDomainId());
        commit.setInstanceId(ekbCommit.getInstanceId());
        commit.setTimestamp(new Date());

        commit.setUser(getUser());
        commit.setContextId(getContextId());

        List<OpenEngSBModel> inserts = ekbCommit.getInserts();
        List<OpenEngSBModel> updates = ekbCommit.getUpdates();
        List<OpenEngSBModel> deletes = ekbCommit.getDeletes();

        Set<Class<?>> modelClasses = extractTypes(inserts, updates, deletes);

        commit.setModelClasses(modelClasses);

        commit.setInserts(mapByClass(inserts));
        commit.setUpdates(mapByClass(updates));
        commit.setDeletes(mapByClass(deletes));

        return commit;
    }

// ORIGINAL CODESEARCHNET METHOD — END

    public static void main(String[]a){EKBCommit e=new EKBCommit();e.inserts.add(new ModelA());IndexCommit c=new method_6_openengsb_gpt().convert(e);System.out.println("commit="+c.commitId+", classes="+c.modelClasses.size()+", user="+c.user);}
    interface OpenEngSBModel{}static class ModelA implements OpenEngSBModel{}static class EKBCommit{List<OpenEngSBModel>inserts=new ArrayList<>(),updates=new ArrayList<>(),deletes=new ArrayList<>();long getRevisionNumber(){return 2;}long getParentRevisionNumber(){return 1;}String getConnectorId(){return "c";}String getDomainId(){return "d";}String getInstanceId(){return "i";}List<OpenEngSBModel>getInserts(){return inserts;}List<OpenEngSBModel>getUpdates(){return updates;}List<OpenEngSBModel>getDeletes(){return deletes;}}
    static class IndexCommit{long commitId,parent;String connector,domain,instance,user,context;Date ts;Set<Class<?>>modelClasses;Map<Class<?>,List<OpenEngSBModel>>inserts,updates,deletes;void setCommitId(long v){commitId=v;}void setParentCommitId(long v){parent=v;}void setConnectorId(String v){connector=v;}void setDomainId(String v){domain=v;}void setInstanceId(String v){instance=v;}void setTimestamp(Date v){ts=v;}void setUser(String v){user=v;}void setContextId(String v){context=v;}void setModelClasses(Set<Class<?>>v){modelClasses=v;}void setInserts(Map<Class<?>,List<OpenEngSBModel>>v){inserts=v;}void setUpdates(Map<Class<?>,List<OpenEngSBModel>>v){updates=v;}void setDeletes(Map<Class<?>,List<OpenEngSBModel>>v){deletes=v;}}

}
