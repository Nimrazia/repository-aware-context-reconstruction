import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public class method_3_ojb_gpt {
    private final Logger log=LoggerFactory.getLogger(method_3_ojb_gpt.class);
    private PersistenceBrokerImpl pb;
    private HashMap m_retrievalTasks;
    private ArrayList prefetchingListeners;
    private final boolean batchRetrieval=true;
    private final boolean prefetchProxies=true;
    private Class classToPrefetch;
    private PBLifeCycleEvent afterLookupEvent;

    public method_3_ojb_gpt(PersistenceBrokerImpl pb) { this.pb=pb; afterLookupEvent=new PBLifeCycleEvent(pb,PBLifeCycleEvent.Type.AFTER_LOOKUP); }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private ManageableCollection getCollectionByQuery(Class collectionClass, Class itemClass, Query query)
                throws ClassNotPersistenceCapableException, PersistenceBrokerException
        {
            if (log.isDebugEnabled()) log.debug("getCollectionByQuery (" + collectionClass + ", " + itemClass + ", " + query + ")");

            ClassDescriptor cld = pb.getClassDescriptor(itemClass);
            ManageableCollection result = null;
            OJBIterator iter = null;
            int fullSize = -1;
            int size = 0;

            final boolean isRetrievalTasksCreated = batchRetrieval && m_retrievalTasks == null;
            if (isRetrievalTasksCreated)
            {
                
                m_retrievalTasks = new HashMap();
            }

            
            pb.getInternalCache().enableMaterializationCache();
            try
            {
                result = (ManageableCollection) collectionClass.newInstance();
                
                
                
                iter = pb.getIteratorFromQuery(query, cld);
                iter.disableLifeCycleEvents();

                
                
                if (iter instanceof PagingIterator)
                {
                    fullSize = iter.fullSize();
                }

                while (iter.hasNext())
                {
                    Object candidate = iter.next();

                    





                    if (candidate != null)
                    {
                        IndirectionHandler handler = ProxyHelper.getIndirectionHandler(candidate);

                        if ((handler != null) || itemClass.isAssignableFrom(candidate.getClass()))
                        {
                            result.ojbAdd(candidate);

                            
                            
                            size++;
                        }
                        else
                        {
                            
                            log.warn("Candidate object ["+candidate
                                        +"] class ["+candidate.getClass().getName()
                                        +"] is not a subtype of ["+itemClass.getName()
                                        +"] or any type of proxy. NOT INCLUDED in result collection");
                        }
                        if (prefetchProxies && (handler != null)
                                && (cld.getProxyPrefetchingLimit() > 0)
                                && addRetrievalTask(candidate, this))
                        {
                            new PBMaterializationListener(candidate, m_retrievalTasks,
                                    this, cld.getProxyPrefetchingLimit());
                        }
                    }
                }

                if (isRetrievalTasksCreated)
                {
                    
                    final Class saveClassToPrefetch = classToPrefetch;
                    classToPrefetch = null;
                    try
                    {
                        performRetrievalTasks();
                    }
                    finally
                    {
                        classToPrefetch = saveClassToPrefetch;
                    }
                }

                
                
                Iterator resultIter = result.ojbIterator();
                while (resultIter.hasNext())
                {
                    Object obj = resultIter.next();
                    afterLookupEvent.setTarget(obj);
                    pb.fireBrokerEvent(afterLookupEvent);
                    afterLookupEvent.setTarget(null);
                }

                
                pb.getInternalCache().disableMaterializationCache();
            }
            catch(RuntimeException e)
            {
                
                pb.getInternalCache().doLocalClear();
                throw e;
            }
            catch (Exception ex)
            {
                
                pb.getInternalCache().doLocalClear();
                log.error(ex);
                throw new PersistenceBrokerException(ex);
            }
            finally
            {
                if (iter != null)
                {
                    iter.releaseDbResources();
                }
                if (isRetrievalTasksCreated)
                {
                    m_retrievalTasks = null;
                }
            }

            
            
            if (fullSize < 0)
            {
                fullSize = size;	
            }
            query.fullSize(fullSize);
            
            return result;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private boolean addRetrievalTask(Object candidate, method_3_ojb_gpt owner) { m_retrievalTasks.put(candidate,owner); return true; }
    private void performRetrievalTasks() { if(m_retrievalTasks!=null) pb.retrievalTaskCount+=m_retrievalTasks.size(); }

    public static void main(String[] args) throws Exception {
        List<Object> rows=new ArrayList<>(); rows.add(new DemoItem("A")); rows.add(null); rows.add(new DemoItem("B")); rows.add("wrong-type");
        PersistenceBrokerImpl pb=new PersistenceBrokerImpl(rows);
        method_3_ojb_gpt broker=new method_3_ojb_gpt(pb);
        Query q=new Query();
        ManageableCollection result=broker.getCollectionByQuery(ManageableArrayList.class,DemoItem.class,q);
        System.out.println("result.size="+((ManageableArrayList)result).values.size());
        System.out.println("result="+((ManageableArrayList)result).values);
        System.out.println("query.fullSize="+q.fullSize);
        System.out.println("cache.enabled="+pb.cache.enabled);
        System.out.println("lifecycle.events="+pb.firedEvents);
        System.out.println("iterator.released="+pb.iterator.released);
    }

    interface ManageableCollection { void ojbAdd(Object o); Iterator ojbIterator(); }
    public static class ManageableArrayList implements ManageableCollection { final List values=new ArrayList(); public ManageableArrayList(){} public void ojbAdd(Object o){values.add(o);} public Iterator ojbIterator(){return values.iterator();} }
    static class DemoItem { final String name; DemoItem(String n){name=n;} public String toString(){return name;} }
    static class Query { int fullSize=-1; void fullSize(int n){fullSize=n;} public String toString(){return "DemoQuery";} }
    static class ClassDescriptor { int proxyPrefetchingLimit=2; int getProxyPrefetchingLimit(){return proxyPrefetchingLimit;} }
    static class PersistenceBrokerImpl { final InternalCache cache=new InternalCache(); final DemoIterator iterator; int firedEvents,retrievalTaskCount; PersistenceBrokerImpl(List rows){iterator=new DemoIterator(rows);} ClassDescriptor getClassDescriptor(Class c){return new ClassDescriptor();} InternalCache getInternalCache(){return cache;} OJBIterator getIteratorFromQuery(Query q,ClassDescriptor c){return iterator;} void fireBrokerEvent(PBLifeCycleEvent e){firedEvents++;} }
    static class InternalCache { boolean enabled; void enableMaterializationCache(){enabled=true;} void disableMaterializationCache(){enabled=false;} void doLocalClear(){enabled=false;} }
    interface OJBIterator extends Iterator { void disableLifeCycleEvents(); int fullSize(); void releaseDbResources(); }
    interface PagingIterator { int fullSize(); }
    static class DemoIterator implements OJBIterator, PagingIterator { final List values; int i; boolean released; DemoIterator(List v){values=v;} public boolean hasNext(){return i<values.size();} public Object next(){return values.get(i++);} public void remove(){throw new UnsupportedOperationException();} public void disableLifeCycleEvents(){} public int fullSize(){return values.size();} public void releaseDbResources(){released=true;} }
    static class IndirectionHandler {}
    static class ProxyHelper { static IndirectionHandler getIndirectionHandler(Object o){return null;} }
    static class PBMaterializationListener { PBMaterializationListener(Object c,Map tasks,method_3_ojb_gpt o,int limit){} }
    static class PBLifeCycleEvent { enum Type{AFTER_LOOKUP} Object target; PBLifeCycleEvent(Object pb,Type t){} void setTarget(Object o){target=o;} }
    static class Logger { boolean isDebugEnabled(){return false;} void debug(Object o){} void warn(Object o){System.out.println("warning="+o);} void error(Object o){} }
    static class LoggerFactory { static Logger getLogger(Class c){return new Logger();} }
    static class ClassNotPersistenceCapableException extends Exception {}
    static class PersistenceBrokerException extends RuntimeException { PersistenceBrokerException(Object o){super(String.valueOf(o));} }
}
