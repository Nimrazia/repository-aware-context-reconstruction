import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.DefaultHandler;


public class method_2_ojb_gpt extends DefaultHandler {
    static final int JDBC_CONNECTION_DESCRIPTOR=1, CONNECTION_POOL=2, OBJECT_CACHE=3, SEQUENCE_MANAGER=4, ATTRIBUTE=5;
    static final int JCD_ALIAS=6, DEFAULT_CONNECTION=7, DBMS_NAME=8, JDBC_LEVEL=9, DRIVER_NAME=10;
    static final int URL_PROTOCOL=11, URL_SUBPROTOCOL=12, URL_DBALIAS=13, DATASOURCE_NAME=14;
    static final int USER_NAME=15, USER_PASSWD=16, EAGER_RELEASE=17, BATCH_MODE=18, USE_AUTOCOMMIT=19;
    static final int IGNORE_AUTOCOMMIT_EXCEPTION=20, CON_MAX_ACTIVE=21, CON_MAX_IDLE=22, CON_MAX_WAIT=23;
    static final int CON_MIN_EVICTABLE_IDLE_TIME_MILLIS=24, CON_NUM_TESTS_PER_EVICTION_RUN=25;
    static final int CON_TEST_ON_BORROW=26, CON_TEST_ON_RETURN=27, CON_TEST_WHILE_IDLE=28;
    static final int CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS=29, CON_WHEN_EXHAUSTED_ACTION=30;
    static final int CONNECTION_FACTORY=31, VALIDATION_QUERY=32, CON_LOG_ABANDONED=33;
    static final int CON_REMOVE_ABANDONED=34, CON_REMOVE_ABANDONED_TIMEOUT=35, CLASS_NAME=36;
    static final int SEQUENCE_MANAGER_CLASS=37, ATTRIBUTE_NAME=38, ATTRIBUTE_VALUE=39;

    private final Logger logger=LoggerFactory.getLogger(method_2_ojb_gpt.class);
    private ConnectionRepository con_repository;
    private JdbcConnectionDescriptor m_CurrentJCD;
    private SequenceDescriptor currentSequenceDescriptor;
    private List conDesList;
    private AttributeContainer currentAttributeContainer;
    private boolean defaultConnectionFound=false;
    private final RepositoryTags tags=RepositoryTags.getInstance();

    public method_2_ojb_gpt(ConnectionRepository cr) {
        if(cr==null) throw new MetadataException("Given ConnectionRepository argument was null");
        con_repository=cr; conDesList=new ArrayList();
    }
    public void startDocument() { logger.debug("startDoc"); }
    public void endDocument() { for(Object o: conDesList) con_repository.addDescriptor((JdbcConnectionDescriptor)o); }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void startElement(String uri, String name, String qName, Attributes atts)
        {
            boolean isDebug = logger.isDebugEnabled();
            try
            {
                switch (getLiteralId(qName))
                {
                    case JDBC_CONNECTION_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("   > " + tags.getTagById(JDBC_CONNECTION_DESCRIPTOR));
                            JdbcConnectionDescriptor newJcd = new JdbcConnectionDescriptor();
                            currentAttributeContainer = newJcd;

                            conDesList.add(newJcd);
                            m_CurrentJCD = newJcd;

                            
                            String jcdAlias = atts.getValue(tags.getTagById(JCD_ALIAS));
                            if (isDebug) logger.debug("     " + tags.getTagById(JCD_ALIAS) + ": " + jcdAlias);
                            m_CurrentJCD.setJcdAlias(jcdAlias);

                            
                            String defaultConnection = atts.getValue(tags.getTagById(DEFAULT_CONNECTION));
                            if (isDebug) logger.debug("     " + tags.getTagById(DEFAULT_CONNECTION) + ": " + defaultConnection);
                            m_CurrentJCD.setDefaultConnection(Boolean.valueOf(defaultConnection).booleanValue());
                            if (m_CurrentJCD.isDefaultConnection())
                            {
                                if (defaultConnectionFound)
                                {
                                    throw new MetadataException("Found two jdbc-connection-descriptor elements with default-connection=\"true\"");
                                }
                                else
                                {
                                    defaultConnectionFound = true;
                                }
                            }

                            
                            String platform = atts.getValue(tags.getTagById(DBMS_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(DBMS_NAME) + ": " + platform);
                            m_CurrentJCD.setDbms(platform);

                            
                            String level = atts.getValue(tags.getTagById(JDBC_LEVEL));
                            if (isDebug) logger.debug("     " + tags.getTagById(JDBC_LEVEL) + ": " + level);
                            m_CurrentJCD.setJdbcLevel(level);

                            
                            String driver = atts.getValue(tags.getTagById(DRIVER_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(DRIVER_NAME) + ": " + driver);
                            m_CurrentJCD.setDriver(driver);

                            
                            String protocol = atts.getValue(tags.getTagById(URL_PROTOCOL));
                            if (isDebug) logger.debug("     " + tags.getTagById(URL_PROTOCOL) + ": " + protocol);
                            m_CurrentJCD.setProtocol(protocol);

                            
                            String subprotocol = atts.getValue(tags.getTagById(URL_SUBPROTOCOL));
                            if (isDebug) logger.debug("     " + tags.getTagById(URL_SUBPROTOCOL) + ": " + subprotocol);
                            m_CurrentJCD.setSubProtocol(subprotocol);

                            
                            String dbalias = atts.getValue(tags.getTagById(URL_DBALIAS));
                            if (isDebug) logger.debug("     " + tags.getTagById(URL_DBALIAS) + ": " + dbalias);
                            m_CurrentJCD.setDbAlias(dbalias);

                            
                            String datasource = atts.getValue(tags.getTagById(DATASOURCE_NAME));
                            
                            if(datasource != null && datasource.trim().equals("")) datasource = null;
                            if (isDebug) logger.debug("     " + tags.getTagById(DATASOURCE_NAME) + ": " + datasource);
                            m_CurrentJCD.setDatasourceName(datasource);

                            
                            String user = atts.getValue(tags.getTagById(USER_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(USER_NAME) + ": " + user);
                            m_CurrentJCD.setUserName(user);

                            
                            String password = atts.getValue(tags.getTagById(USER_PASSWD));
                            if (isDebug) logger.debug("     " + tags.getTagById(USER_PASSWD) + ": " + password);
                            m_CurrentJCD.setPassWord(password);

                            
                            String eagerRelease = atts.getValue(tags.getTagById(EAGER_RELEASE));
                            if (isDebug) logger.debug("     " + tags.getTagById(EAGER_RELEASE) + ": " + eagerRelease);
                            m_CurrentJCD.setEagerRelease(Boolean.valueOf(eagerRelease).booleanValue());

                            
                            String batchMode = atts.getValue(tags.getTagById(BATCH_MODE));
                            if (isDebug) logger.debug("     " + tags.getTagById(BATCH_MODE) + ": " + batchMode);
                            m_CurrentJCD.setBatchMode(Boolean.valueOf(batchMode).booleanValue());

                            
                            String useAutoCommit = atts.getValue(tags.getTagById(USE_AUTOCOMMIT));
                            if (isDebug) logger.debug("     " + tags.getTagById(USE_AUTOCOMMIT) + ": " + useAutoCommit);
                            m_CurrentJCD.setUseAutoCommit(Integer.valueOf(useAutoCommit).intValue());

                            
                            String ignoreAutoCommitExceptions = atts.getValue(tags.getTagById(IGNORE_AUTOCOMMIT_EXCEPTION));
                            if (isDebug) logger.debug("     " + tags.getTagById(IGNORE_AUTOCOMMIT_EXCEPTION) + ": " + ignoreAutoCommitExceptions);
                            m_CurrentJCD.setIgnoreAutoCommitExceptions(Boolean.valueOf(ignoreAutoCommitExceptions).booleanValue());

                            break;
                        }
                    case CONNECTION_POOL:
                        {
                            if (m_CurrentJCD != null)
                            {
                                if (isDebug) logger.debug("    > " + tags.getTagById(CONNECTION_POOL));
                                final ConnectionPoolDescriptor m_CurrentCPD = m_CurrentJCD.getConnectionPoolDescriptor();
                                this.currentAttributeContainer = m_CurrentCPD;

                                String maxActive = atts.getValue(tags.getTagById(CON_MAX_ACTIVE));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_ACTIVE) + ": " + maxActive);
                                if (checkString(maxActive)) m_CurrentCPD.setMaxActive(Integer.parseInt(maxActive));

                                String maxIdle = atts.getValue(tags.getTagById(CON_MAX_IDLE));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_IDLE) + ": " + maxIdle);
                                if (checkString(maxIdle)) m_CurrentCPD.setMaxIdle(Integer.parseInt(maxIdle));

                                String maxWait = atts.getValue(tags.getTagById(CON_MAX_WAIT));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_MAX_WAIT) + ": " + maxWait);
                                if (checkString(maxWait)) m_CurrentCPD.setMaxWait(Integer.parseInt(maxWait));

                                String minEvictableIdleTimeMillis = atts.getValue(tags.getTagById(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS) + ": " + minEvictableIdleTimeMillis);
                                if (checkString(minEvictableIdleTimeMillis)) m_CurrentCPD.setMinEvictableIdleTimeMillis(Long.parseLong(minEvictableIdleTimeMillis));

                                String numTestsPerEvictionRun = atts.getValue(tags.getTagById(CON_NUM_TESTS_PER_EVICTION_RUN));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_NUM_TESTS_PER_EVICTION_RUN) + ": " + numTestsPerEvictionRun);
                                if (checkString(numTestsPerEvictionRun)) m_CurrentCPD.setNumTestsPerEvictionRun(Integer.parseInt(numTestsPerEvictionRun));

                                String testOnBorrow = atts.getValue(tags.getTagById(CON_TEST_ON_BORROW));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_ON_BORROW) + ": " + testOnBorrow);
                                if (checkString(testOnBorrow)) m_CurrentCPD.setTestOnBorrow(Boolean.valueOf(testOnBorrow).booleanValue());

                                String testOnReturn = atts.getValue(tags.getTagById(CON_TEST_ON_RETURN));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_ON_RETURN) + ": " + testOnReturn);
                                if (checkString(testOnReturn)) m_CurrentCPD.setTestOnReturn(Boolean.valueOf(testOnReturn).booleanValue());

                                String testWhileIdle = atts.getValue(tags.getTagById(CON_TEST_WHILE_IDLE));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_TEST_WHILE_IDLE) + ": " + testWhileIdle);
                                if (checkString(testWhileIdle)) m_CurrentCPD.setTestWhileIdle(Boolean.valueOf(testWhileIdle).booleanValue());

                                String timeBetweenEvictionRunsMillis = atts.getValue(tags.getTagById(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS) + ": " + timeBetweenEvictionRunsMillis);
                                if (checkString(timeBetweenEvictionRunsMillis)) m_CurrentCPD.setTimeBetweenEvictionRunsMillis(Long.parseLong(timeBetweenEvictionRunsMillis));

                                String whenExhaustedAction = atts.getValue(tags.getTagById(CON_WHEN_EXHAUSTED_ACTION));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_WHEN_EXHAUSTED_ACTION) + ": " + whenExhaustedAction);
                                if (checkString(whenExhaustedAction)) m_CurrentCPD.setWhenExhaustedAction(Byte.parseByte(whenExhaustedAction));

                                String connectionFactoryStr = atts.getValue(tags.getTagById(CONNECTION_FACTORY));
                                if (isDebug) logger.debug("     " + tags.getTagById(CONNECTION_FACTORY) + ": " + connectionFactoryStr);
                                if (checkString(connectionFactoryStr)) m_CurrentCPD.setConnectionFactory(ClassHelper.getClass(connectionFactoryStr));

                                String validationQuery = atts.getValue(tags.getTagById(VALIDATION_QUERY));
                                if (isDebug) logger.debug("     " + tags.getTagById(VALIDATION_QUERY) + ": " + validationQuery);
                                if (checkString(validationQuery)) m_CurrentCPD.setValidationQuery(validationQuery);

                                
                                String logAbandoned = atts.getValue(tags.getTagById(CON_LOG_ABANDONED));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_LOG_ABANDONED) + ": " + logAbandoned);
                                if (checkString(logAbandoned)) m_CurrentCPD.setLogAbandoned(Boolean.valueOf(logAbandoned).booleanValue());

                                String removeAbandoned = atts.getValue(tags.getTagById(CON_REMOVE_ABANDONED));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_REMOVE_ABANDONED) + ": " + removeAbandoned);
                                if (checkString(removeAbandoned)) m_CurrentCPD.setRemoveAbandoned(Boolean.valueOf(removeAbandoned).booleanValue());

                                String removeAbandonedTimeout = atts.getValue(tags.getTagById(CON_REMOVE_ABANDONED_TIMEOUT));
                                if (isDebug) logger.debug("     " + tags.getTagById(CON_REMOVE_ABANDONED_TIMEOUT) + ": " + removeAbandonedTimeout);
                                if (checkString(removeAbandonedTimeout)) m_CurrentCPD.setRemoveAbandonedTimeout(Integer.parseInt(removeAbandonedTimeout));
                            }
                            break;
                        }

                    case OBJECT_CACHE:
                        {
                            String className = atts.getValue(tags.getTagById(CLASS_NAME));
                            if(checkString(className) && m_CurrentJCD != null)
                            {
                                ObjectCacheDescriptor ocd = m_CurrentJCD.getObjectCacheDescriptor();
                                this.currentAttributeContainer = ocd;
                                ocd.setObjectCache(ClassHelper.getClass(className));
                                if (isDebug) logger.debug("    > " + tags.getTagById(OBJECT_CACHE));
                                if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + className);
                            }
                            break;
                        }
                    case SEQUENCE_MANAGER:
                        {
                            String className = atts.getValue(tags.getTagById(SEQUENCE_MANAGER_CLASS));
                            if(checkString(className))
                            {
                                this.currentSequenceDescriptor = new SequenceDescriptor(this.m_CurrentJCD);
                                this.currentAttributeContainer = currentSequenceDescriptor;
                                this.m_CurrentJCD.setSequenceDescriptor(this.currentSequenceDescriptor);
                                if (isDebug) logger.debug("    > " + tags.getTagById(SEQUENCE_MANAGER));
                                if (isDebug) logger.debug("     " + tags.getTagById(SEQUENCE_MANAGER_CLASS) + ": " + className);
                                if (checkString(className)) currentSequenceDescriptor.setSequenceManagerClass(ClassHelper.getClass(className));
                            }
                            break;
                        }
                    case ATTRIBUTE:
                        {
                            
                            String attributeName = atts.getValue(tags.getTagById(ATTRIBUTE_NAME));
                            String attributeValue = atts.getValue(tags.getTagById(ATTRIBUTE_VALUE));

                            
                            if (this.currentAttributeContainer != null)
                            {

                                if (checkString(attributeName))
                                {
                                    if (isDebug) logger.debug("      > " + tags.getTagById(ATTRIBUTE));
                                    if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_NAME) + ": " + attributeName
                                            + "  "+tags.getTagById(ATTRIBUTE_VALUE) + ": " + attributeValue);
                                    this.currentAttributeContainer.addAttribute(attributeName, attributeValue);
    
                                }
                                else
                                {
                                    logger.info("Found 'null' or 'empty' attribute object for element "+currentAttributeContainer.getClass() +
                                            " attribute-name=" + attributeName + ", attribute-value=" + attributeValue+
                                            " See jdbc-connection-descriptor with jcdAlias '"+m_CurrentJCD.getJcdAlias()+"'");
                                }
                            }
    
    
    
    
    

                            break;
                        }
                    default :
                        {
                            
                        }
                }
            }
            catch (Exception ex)
            {
                logger.error(ex);
                throw new PersistenceBrokerException(ex);
            }
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private boolean checkString(String str) { return str!=null && !str.trim().equals(""); }
    private int getLiteralId(String literal) throws PersistenceBrokerException { return tags.getIdByTag(literal); }

    public static void main(String[] args) {
        ConnectionRepository repo=new ConnectionRepository();
        method_2_ojb_gpt h=new method_2_ojb_gpt(repo);
        AttributesImpl jdbc=new AttributesImpl();
        add(jdbc,"jcd-alias","demo"); add(jdbc,"default-connection","true"); add(jdbc,"platform","Hsqldb");
        add(jdbc,"jdbc-level","3.0"); add(jdbc,"driver","java.lang.String"); add(jdbc,"protocol","jdbc");
        add(jdbc,"subprotocol","hsqldb"); add(jdbc,"dbalias","mem:demo"); add(jdbc,"datasource-name","");
        add(jdbc,"user-name","sa"); add(jdbc,"user-passwd",""); add(jdbc,"eager-release","false");
        add(jdbc,"batch-mode","true"); add(jdbc,"use-autocommit","1"); add(jdbc,"ignore-autocommit-exceptions","true");
        h.startElement("","","jdbc-connection-descriptor",jdbc);
        AttributesImpl pool=new AttributesImpl(); add(pool,"max-active","8"); add(pool,"max-idle","4");
        add(pool,"max-wait","5000"); add(pool,"validation-query","SELECT 1");
        h.startElement("","","connection-pool",pool);
        AttributesImpl attr=new AttributesImpl(); add(attr,"attribute-name","tenant"); add(attr,"attribute-value","demo");
        h.startElement("","","attribute",attr); h.endDocument();
        JdbcConnectionDescriptor d=repo.descriptors.get(0);
        System.out.println("alias="+d.jcdAlias); System.out.println("default="+d.defaultConnection);
        System.out.println("db="+d.protocol+":"+d.subProtocol+":"+d.dbAlias);
        System.out.println("pool.maxActive="+d.pool.maxActive); System.out.println("pool.validation="+d.pool.validationQuery);
        System.out.println("attributes="+d.pool.attributes);
    }
    private static void add(AttributesImpl a,String n,String v) { a.addAttribute("",n,n,"CDATA",v); }

    interface AttributeContainer { void addAttribute(String n,String v); }
    static class BaseAttributes implements AttributeContainer { final Map attributes=new HashMap(); public void addAttribute(String n,String v){attributes.put(n,v);} }
    static class ConnectionRepository { final List<JdbcConnectionDescriptor> descriptors=new ArrayList<>(); void addDescriptor(JdbcConnectionDescriptor d){descriptors.add(d);} }
    static class JdbcConnectionDescriptor extends BaseAttributes {
        String jcdAlias,dbms,jdbcLevel,driver,protocol,subProtocol,dbAlias,datasourceName,userName,password; boolean defaultConnection,eagerRelease,batchMode,ignoreAutoCommitExceptions; int useAutoCommit;
        final ConnectionPoolDescriptor pool=new ConnectionPoolDescriptor(); final ObjectCacheDescriptor cache=new ObjectCacheDescriptor(); SequenceDescriptor sequence;
        void setJcdAlias(String v){jcdAlias=v;} void setDefaultConnection(boolean v){defaultConnection=v;} boolean isDefaultConnection(){return defaultConnection;}
        void setDbms(String v){dbms=v;} void setJdbcLevel(String v){jdbcLevel=v;} void setDriver(String v){driver=v;} void setProtocol(String v){protocol=v;}
        void setSubProtocol(String v){subProtocol=v;} void setDbAlias(String v){dbAlias=v;} void setDatasourceName(String v){datasourceName=v;}
        void setUserName(String v){userName=v;} void setPassWord(String v){password=v;} void setEagerRelease(boolean v){eagerRelease=v;}
        void setBatchMode(boolean v){batchMode=v;} void setUseAutoCommit(int v){useAutoCommit=v;} void setIgnoreAutoCommitExceptions(boolean v){ignoreAutoCommitExceptions=v;}
        ConnectionPoolDescriptor getConnectionPoolDescriptor(){return pool;} ObjectCacheDescriptor getObjectCacheDescriptor(){return cache;} void setSequenceDescriptor(SequenceDescriptor v){sequence=v;} String getJcdAlias(){return jcdAlias;}
    }
    static class ConnectionPoolDescriptor extends BaseAttributes { int maxActive,maxIdle; long maxWait,minEvictableIdleTimeMillis,timeBetweenEvictionRunsMillis; int numTestsPerEvictionRun,removeAbandonedTimeout; boolean testOnBorrow,testOnReturn,testWhileIdle,logAbandoned,removeAbandoned; byte whenExhaustedAction; Class connectionFactory; String validationQuery;
        void setMaxActive(int v){maxActive=v;} void setMaxIdle(int v){maxIdle=v;} void setMaxWait(long v){maxWait=v;} void setMinEvictableIdleTimeMillis(long v){minEvictableIdleTimeMillis=v;} void setNumTestsPerEvictionRun(int v){numTestsPerEvictionRun=v;} void setTestOnBorrow(boolean v){testOnBorrow=v;} void setTestOnReturn(boolean v){testOnReturn=v;} void setTestWhileIdle(boolean v){testWhileIdle=v;} void setTimeBetweenEvictionRunsMillis(long v){timeBetweenEvictionRunsMillis=v;} void setWhenExhaustedAction(byte v){whenExhaustedAction=v;} void setConnectionFactory(Class v){connectionFactory=v;} void setValidationQuery(String v){validationQuery=v;} void setLogAbandoned(boolean v){logAbandoned=v;} void setRemoveAbandoned(boolean v){removeAbandoned=v;} void setRemoveAbandonedTimeout(int v){removeAbandonedTimeout=v;}
    }
    static class ObjectCacheDescriptor extends BaseAttributes { Class objectCache; void setObjectCache(Class v){objectCache=v;} }
    static class SequenceDescriptor extends BaseAttributes { JdbcConnectionDescriptor owner; Class sequenceManagerClass; SequenceDescriptor(JdbcConnectionDescriptor o){owner=o;} void setSequenceManagerClass(Class v){sequenceManagerClass=v;} }
    static class RepositoryTags { static final RepositoryTags I=new RepositoryTags(); final Map<String,Integer> ids=new HashMap<>(); final Map<Integer,String> tags=new HashMap<>(); static RepositoryTags getInstance(){return I;} RepositoryTags(){
        reg(JDBC_CONNECTION_DESCRIPTOR,"jdbc-connection-descriptor");reg(CONNECTION_POOL,"connection-pool");reg(OBJECT_CACHE,"object-cache");reg(SEQUENCE_MANAGER,"sequence-manager");reg(ATTRIBUTE,"attribute");
        reg(JCD_ALIAS,"jcd-alias");reg(DEFAULT_CONNECTION,"default-connection");reg(DBMS_NAME,"platform");reg(JDBC_LEVEL,"jdbc-level");reg(DRIVER_NAME,"driver");reg(URL_PROTOCOL,"protocol");reg(URL_SUBPROTOCOL,"subprotocol");reg(URL_DBALIAS,"dbalias");reg(DATASOURCE_NAME,"datasource-name");reg(USER_NAME,"user-name");reg(USER_PASSWD,"user-passwd");reg(EAGER_RELEASE,"eager-release");reg(BATCH_MODE,"batch-mode");reg(USE_AUTOCOMMIT,"use-autocommit");reg(IGNORE_AUTOCOMMIT_EXCEPTION,"ignore-autocommit-exceptions");reg(CON_MAX_ACTIVE,"max-active");reg(CON_MAX_IDLE,"max-idle");reg(CON_MAX_WAIT,"max-wait");reg(CON_MIN_EVICTABLE_IDLE_TIME_MILLIS,"min-evictable-idle-time-millis");reg(CON_NUM_TESTS_PER_EVICTION_RUN,"num-tests-per-eviction-run");reg(CON_TEST_ON_BORROW,"test-on-borrow");reg(CON_TEST_ON_RETURN,"test-on-return");reg(CON_TEST_WHILE_IDLE,"test-while-idle");reg(CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS,"time-between-eviction-runs-millis");reg(CON_WHEN_EXHAUSTED_ACTION,"when-exhausted-action");reg(CONNECTION_FACTORY,"connection-factory");reg(VALIDATION_QUERY,"validation-query");reg(CON_LOG_ABANDONED,"log-abandoned");reg(CON_REMOVE_ABANDONED,"remove-abandoned");reg(CON_REMOVE_ABANDONED_TIMEOUT,"remove-abandoned-timeout");reg(CLASS_NAME,"class");reg(SEQUENCE_MANAGER_CLASS,"class");reg(ATTRIBUTE_NAME,"attribute-name");reg(ATTRIBUTE_VALUE,"attribute-value"); } void reg(int i,String s){ids.put(s,i);tags.put(i,s);} int getIdByTag(String s){Integer i=ids.get(s);if(i==null)throw new MetadataException("unknown literal: "+s);return i;} String getTagById(int i){return tags.get(i);} }
    static class ClassHelper { static Class getClass(String s)throws ClassNotFoundException{return Class.forName(s);} }
    static class Logger { boolean isDebugEnabled(){return false;} void debug(Object o){} void info(Object o){} void error(Object o){} }
    static class LoggerFactory { static Logger getLogger(Class c){return new Logger();} }
    static class MetadataException extends RuntimeException { MetadataException(String s){super(s);} }
    static class PersistenceBrokerException extends RuntimeException { PersistenceBrokerException(Object e){super(String.valueOf(e));} }
}
