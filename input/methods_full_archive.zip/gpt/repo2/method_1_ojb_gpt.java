import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.DefaultHandler;






public class method_1_ojb_gpt extends DefaultHandler {
    static final int ACCEPT_LOCKS = 1;
    static final int ACCESS = 2;
    static final int ATTRIBUTE = 3;
    static final int ATTRIBUTE_NAME = 4;
    static final int ATTRIBUTE_VALUE = 5;
    static final int AUTO_DELETE = 6;
    static final int AUTO_INCREMENT = 7;
    static final int AUTO_RETRIEVE = 8;
    static final int AUTO_UPDATE = 9;
    static final int CLASS_DESCRIPTOR = 10;
    static final int CLASS_EXTENT = 11;
    static final int CLASS_NAME = 12;
    static final int CLASS_PROXY = 13;
    static final int CLD = 14;
    static final int COLLECTION_CLASS = 15;
    static final int COLLECTION_DESCRIPTOR = 16;
    static final int COLUMN_NAME = 17;
    static final int CONSTANT_ARGUMENT = 18;
    static final int DELETE_PROCEDURE = 19;
    static final int DYNAMIC_STR = 20;
    static final int EXTENDS = 21;
    static final int FACTORY_CLASS = 22;
    static final int FACTORY_METHOD = 23;
    static final int FIELD_CONVERSION = 24;
    static final int FIELD_DESCRIPTOR = 25;
    static final int FIELD_ID_REF = 26;
    static final int FIELD_NAME = 27;
    static final int FIELD_REF = 28;
    static final int FK_POINTING_TO_ITEMS_CLASS = 29;
    static final int FK_POINTING_TO_THIS_CLASS = 30;
    static final int FOREIGN_KEY = 31;
    static final int ID = 32;
    static final int INCLUDE_ALL_FIELDS = 33;
    static final int INCLUDE_PK_FIELDS_ONLY = 34;
    static final int INDEXED = 35;
    static final int INDEX_COLUMN = 36;
    static final int INDEX_DESCRIPTOR = 37;
    static final int INDIRECTION_TABLE = 38;
    static final int INITIALIZATION_METHOD = 39;
    static final int INSERT_PROCEDURE = 40;
    static final int INVERSE_FK = 41;
    static final int ISOLATION_LEVEL = 42;
    static final int ITEMS_CLASS = 43;
    static final int JDBC_TYPE = 44;
    static final int LENGTH = 45;
    static final int LOCKING = 46;
    static final int MAPPING_REPOSITORY = 47;
    static final int NAME = 48;
    static final int NULLABLE = 49;
    static final int OBJECT_CACHE = 50;
    static final int OJB = 51;
    static final int ORDERBY = 52;
    static final int OTM_DEPENDENT = 53;
    static final int PRECISION = 54;
    static final int PRIMARY_KEY = 55;
    static final int PROXY_PREFETCHING_LIMIT = 56;
    static final int PROXY_REFERENCE = 57;
    static final int QUERY_CUSTOMIZER = 58;
    static final int REFERENCED_CLASS = 59;
    static final int REFERENCE_DESCRIPTOR = 60;
    static final int REFRESH = 61;
    static final int REPOSITORY_VERSION = 62;
    static final int RETURN = 63;
    static final int RETURN_FIELD_REF = 64;
    static final int ROW_READER = 65;
    static final int RUNTIME_ARGUMENT = 66;
    static final int SCALE = 67;
    static final int SCHEMA_NAME = 68;
    static final int SEQUENCE_MANAGER = 69;
    static final int SEQUENCE_NAME = 70;
    static final int SM = 71;
    static final int SORT = 72;
    static final int TABLE_NAME = 73;
    static final int UNIQUE = 74;
    static final int UPDATE_LOCK = 75;
    static final int UPDATE_PROCEDURE = 76;
    static final int VALUE = 77;
    static final String TAG_ACCESS_ANONYMOUS = "anonymous";
    static final String TAG_SUPER = "super";
    interface RepositoryElements { String TAG_ACCESS_ANONYMOUS = "anonymous"; String TAG_SUPER = "super"; }
    private final Logger logger = LoggerFactory.getLogger(method_1_ojb_gpt.class);
    private DescriptorRepository m_repository;
    private ClassDescriptor m_CurrentCLD;
    private ProcedureDescriptor m_CurrentProcedure;
    private FieldDescriptor m_CurrentFLD;
    private ObjectReferenceDescriptor m_CurrentORD;
    private CollectionDescriptor m_CurrentCOD;
    private IndexDescriptor m_CurrentIndexDescriptor;
    private String m_CurrentString;
    private AttributeContainer m_CurrentAttrContainer;
    private int defProxyPrefetchingLimit = 50;
    private int m_lastId;
    private final RepositoryTags tags = RepositoryTags.getInstance();

    private int getLiteralId(String literal) throws MetadataException {
        try { return tags.getIdByTag(literal); }
        catch (NullPointerException e) { throw new MetadataException("Unknown repository literal: " + literal, e); }
    }

    public method_1_ojb_gpt(DescriptorRepository repository) {
        if (repository == null) throw new MetadataException("Given DescriptorRepository argument was null");
        this.m_repository = repository;
    }

    public void startDocument() { logger.debug("startDoc"); }
    public void endDocument() { logger.debug("endDoc"); }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void startElement(String uri, String name, String qName, Attributes atts)
        {
            boolean isDebug = logger.isDebugEnabled();

            m_CurrentString = null;
            try
            {
                switch (getLiteralId(qName))
                {
                    case MAPPING_REPOSITORY:
                        {
                            if (isDebug) logger.debug(" > " + tags.getTagById(MAPPING_REPOSITORY));
                            this.m_CurrentAttrContainer = m_repository;

                            String defIso = atts.getValue(tags.getTagById(ISOLATION_LEVEL));
                            this.m_repository.setDefaultIsolationLevel(LockHelper.getIsolationLevelFor(defIso));
                            if (isDebug) logger.debug("     " + tags.getTagById(ISOLATION_LEVEL) + ": " + defIso);


                            String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                            if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                            if (proxyPrefetchingLimit != null)
                            {
                                defProxyPrefetchingLimit = Integer.parseInt(proxyPrefetchingLimit);
                            }

                            
                            String version = atts.getValue(tags.getTagById(REPOSITORY_VERSION));
                            if (DescriptorRepository.getVersion().equals(version))
                            {
                                if (isDebug) logger.debug("     " + tags.getTagById(REPOSITORY_VERSION) + ": " + version);
                            }
                            else
                            {
                                throw new MetadataException("Repository version does not match. expected " +
                                        DescriptorRepository.getVersion() + " but found: " +
                                        version+". Please update your repository.dtd and your repository.xml"+
                                        " version attribute entry");
                            }
                            break;
                        }
                    case CLASS_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("  > " + tags.getTagById(CLASS_DESCRIPTOR));
                            m_CurrentCLD = new ClassDescriptor(m_repository);

                            
                            this.m_CurrentAttrContainer = this.m_CurrentCLD;

                            
                            String isoLevel = atts.getValue(tags.getTagById(ISOLATION_LEVEL));
                            if (isDebug) logger.debug("     " + tags.getTagById(ISOLATION_LEVEL) + ": " + isoLevel);
                            




                            if(checkString(isoLevel)) m_CurrentCLD.setIsolationLevel(LockHelper.getIsolationLevelFor(isoLevel));

                            
                            String classname = atts.getValue(tags.getTagById(CLASS_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + classname);
                            try
                            {
                                m_CurrentCLD.setClassOfObject(ClassHelper.getClass(classname));
                            }
                            catch (ClassNotFoundException e)
                            {
                                m_CurrentCLD = null;
                                throw new MetadataException("Class "+classname+" could not be found"
                                        +" in the classpath. This could cause unexpected behaviour of OJB,"+
                                        " please remove or comment out this class descriptor" +
                                        " in the repository.xml file.", e);
                            }

                            
                            String schema = atts.getValue(tags.getTagById(SCHEMA_NAME));
                            if (schema != null)
                            {
                                if (isDebug) logger.debug("     " + tags.getTagById(SCHEMA_NAME) + ": " + schema);
                                m_CurrentCLD.setSchema(schema);
                            }

                            
                            String proxy = atts.getValue(tags.getTagById(CLASS_PROXY));
                            if (isDebug) logger.debug("     " + tags.getTagById(CLASS_PROXY) + ": " + proxy);
                            if (checkString(proxy))
                            {
                                if (proxy.equalsIgnoreCase(ClassDescriptor.DYNAMIC_STR))
                                {
                                    m_CurrentCLD.setProxyClassName(ClassDescriptor.DYNAMIC_STR);
                                }
                                else
                                {
                                    m_CurrentCLD.setProxyClassName(proxy);
                                }
                            }

                            
                            String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                            if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                            if (proxyPrefetchingLimit == null)
                            {
                                m_CurrentCLD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                            }
                            else
                            {
                                m_CurrentCLD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                            }

                            
                            String table = atts.getValue(tags.getTagById(TABLE_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(TABLE_NAME) + ": " + table);
                            m_CurrentCLD.setTableName(table);
                            if (table == null)
                            {
                                m_CurrentCLD.setIsInterface(true);
                            }

                            
                            String rowreader = atts.getValue(tags.getTagById(ROW_READER));
                            if (isDebug) logger.debug("     " + tags.getTagById(ROW_READER) + ": " + rowreader);
                            if (rowreader != null)
                            {
                                m_CurrentCLD.setRowReader(rowreader);
                            }

                            
    
                            String extendsAtt = atts.getValue(tags.getTagById(EXTENDS));
                            if (isDebug) logger.debug("     " + tags.getTagById(EXTENDS) + ": " + extendsAtt);
                            if (checkString(extendsAtt))
                            {
                                m_CurrentCLD.setSuperClass(extendsAtt);
                            }

                            
                            String acceptLocks = atts.getValue(tags.getTagById(ACCEPT_LOCKS));
                            if (acceptLocks==null)
                                acceptLocks="true"; 
                            logger.debug("     " + tags.getTagById(ACCEPT_LOCKS) + ": " + acceptLocks);
                            if (isDebug) logger.debug("     " + tags.getTagById(ACCEPT_LOCKS) + ": " + acceptLocks);
                            boolean b = (Boolean.valueOf(acceptLocks)).booleanValue();
                            m_CurrentCLD.setAcceptLocks(b);

                            
                            String initializationMethod = atts.getValue(tags.getTagById(INITIALIZATION_METHOD));
                            if (isDebug) logger.debug("     " + tags.getTagById(INITIALIZATION_METHOD) + ": " + initializationMethod);
                            if (initializationMethod != null)
                            {
                                m_CurrentCLD.setInitializationMethod(initializationMethod);
                            }

                            
                            String factoryClass = atts.getValue(tags.getTagById(FACTORY_CLASS));
                            if (isDebug)
                                logger.debug("     " + tags.getTagById(FACTORY_CLASS) + ": " + factoryClass);
                            if (factoryClass != null)
                            {
                                m_CurrentCLD.setFactoryClass(factoryClass);
                            }

                            
                            String factoryMethod = atts.getValue(tags.getTagById(FACTORY_METHOD));
                            if (isDebug)
                                logger.debug("     " + tags.getTagById(FACTORY_METHOD) + ": " + factoryMethod);
                            if (factoryMethod != null)
                            {
                                m_CurrentCLD.setFactoryMethod(factoryMethod);
                            }

                            
                            String refresh = atts.getValue(tags.getTagById(REFRESH));
                            if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                            b = (Boolean.valueOf(refresh)).booleanValue();
                            m_CurrentCLD.setAlwaysRefresh(b);

                            
                            
    						String pfClassName = atts.getValue("persistent-field-class");
    						if (isDebug) logger.debug("     persistent-field-class: " + pfClassName);
    						m_CurrentCLD.setPersistentFieldClassName(pfClassName);

                            
                            m_repository.put(classname, m_CurrentCLD);
                            break;
                        }
                    case OBJECT_CACHE:
                        {
                            
                            
                            if(m_CurrentCLD != null)
                            {
                                String className = atts.getValue(tags.getTagById(CLASS_NAME));
                                if(checkString(className))
                                {
                                    if (isDebug) logger.debug("     > " + tags.getTagById(OBJECT_CACHE));
                                    ObjectCacheDescriptor ocd = new ObjectCacheDescriptor();
                                    this.m_CurrentAttrContainer = ocd;
                                    ocd.setObjectCache(ClassHelper.getClass(className));
                                    if(m_CurrentCLD != null)
                                    {
                                        m_CurrentCLD.setObjectCacheDescriptor(ocd);
                                    }
                                    if (isDebug) logger.debug("     " + tags.getTagById(CLASS_NAME) + ": " + className);
                                }
                            }
                            break;
                        }
                    case CLASS_EXTENT:
                        {
                            String classname = atts.getValue("class-ref");
                            if (isDebug) logger.debug("     " + tags.getTagById(CLASS_EXTENT) + ": " + classname);
                            m_CurrentCLD.addExtentClass(classname);
                            break;
                        }

                    case FIELD_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(FIELD_DESCRIPTOR));

                            String strId = atts.getValue(tags.getTagById(ID));
                            m_lastId = (strId == null ? m_lastId + 1 : Integer.parseInt(strId));

                            String strAccess = atts.getValue(tags.getTagById(ACCESS));

                            if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                            {
                                m_CurrentFLD = new AnonymousFieldDescriptor(m_CurrentCLD, m_lastId);
                            }
                            else
                            {
                                m_CurrentFLD = new FieldDescriptor(m_CurrentCLD, m_lastId);
                            }
                            m_CurrentFLD.setAccess(strAccess);
                            m_CurrentCLD.addFieldDescriptor(m_CurrentFLD);

                            
                            this.m_CurrentAttrContainer = this.m_CurrentFLD;

                            String fieldName = atts.getValue(tags.getTagById(FIELD_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + fieldName);

                            if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                            {
    							AnonymousFieldDescriptor anonymous = (AnonymousFieldDescriptor) m_CurrentFLD;
                                anonymous.setPersistentField(null,fieldName);
                            }
                            else
                            {
                                String classname = m_CurrentCLD.getClassNameOfObject();
    							PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),ClassHelper.getClass(classname),fieldName);
                                m_CurrentFLD.setPersistentField(pf);
                            }

                            String columnName = atts.getValue(tags.getTagById(COLUMN_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(COLUMN_NAME) + ": " + columnName);
                            m_CurrentFLD.setColumnName(columnName);

                            String jdbcType = atts.getValue(tags.getTagById(JDBC_TYPE));
                            if (isDebug) logger.debug("     " + tags.getTagById(JDBC_TYPE) + ": " + jdbcType);
                            m_CurrentFLD.setColumnType(jdbcType);

                            String primaryKey = atts.getValue(tags.getTagById(PRIMARY_KEY));
                            if (isDebug) logger.debug("     " + tags.getTagById(PRIMARY_KEY) + ": " + primaryKey);
                            boolean b = (Boolean.valueOf(primaryKey)).booleanValue();
                            m_CurrentFLD.setPrimaryKey(b);

                            String nullable = atts.getValue(tags.getTagById(NULLABLE));
                            if (nullable != null)
                            {
                                if (isDebug) logger.debug("     " + tags.getTagById(NULLABLE) + ": " + nullable);
                                b = !(Boolean.valueOf(nullable)).booleanValue();
                                m_CurrentFLD.setRequired(b);
                            }

                            String indexed = atts.getValue(tags.getTagById(INDEXED));
                            if (isDebug) logger.debug("     " + tags.getTagById(INDEXED) + ": " + indexed);
                            b = (Boolean.valueOf(indexed)).booleanValue();
                            m_CurrentFLD.setIndexed(b);

                            String autoincrement = atts.getValue(tags.getTagById(AUTO_INCREMENT));
                            if (isDebug) logger.debug("     " + tags.getTagById(AUTO_INCREMENT) + ": " + autoincrement);
                            b = (Boolean.valueOf(autoincrement)).booleanValue();
                            m_CurrentFLD.setAutoIncrement(b);

                            String sequenceName = atts.getValue(tags.getTagById(SEQUENCE_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(SEQUENCE_NAME) + ": " + sequenceName);
                            m_CurrentFLD.setSequenceName(sequenceName);

                            String locking = atts.getValue(tags.getTagById(LOCKING));
                            if (isDebug) logger.debug("     " + tags.getTagById(LOCKING) + ": " + locking);
                            b = (Boolean.valueOf(locking)).booleanValue();
                            m_CurrentFLD.setLocking(b);

                            String updateLock = atts.getValue(tags.getTagById(UPDATE_LOCK));
                            if (isDebug) logger.debug("     " + tags.getTagById(UPDATE_LOCK) + ": " + updateLock);
                            if(checkString(updateLock))
                            {
                                b = (Boolean.valueOf(updateLock)).booleanValue();
                                m_CurrentFLD.setUpdateLock(b);
                            }

                            String fieldConversion = atts.getValue(tags.getTagById(FIELD_CONVERSION));
                            if (isDebug) logger.debug("     " + tags.getTagById(FIELD_CONVERSION) + ": " + fieldConversion);
                            if (fieldConversion != null)
                            {
                                m_CurrentFLD.setFieldConversionClassName(fieldConversion);
                            }

                            
                            String length = atts.getValue(tags.getTagById(LENGTH));
                            if (length != null)
                            {
                                int i = Integer.parseInt(length);
                                if (isDebug) logger.debug("     " + tags.getTagById(LENGTH) + ": " + i);
                                m_CurrentFLD.setLength(i);
                                m_CurrentFLD.setLengthSpecified(true);
                            }

                            
                            String precision = atts.getValue(tags.getTagById(PRECISION));
                            if (precision != null)
                            {
                                int i = Integer.parseInt(precision);
                                if (isDebug) logger.debug("     " + tags.getTagById(PRECISION) + ": " + i);
                                m_CurrentFLD.setPrecision(i);
                                m_CurrentFLD.setPrecisionSpecified(true);
                            }

                            
                            String scale = atts.getValue(tags.getTagById(SCALE));
                            if (scale != null)
                            {
                                int i = Integer.parseInt(scale);
                                if (isDebug) logger.debug("     " + tags.getTagById(SCALE) + ": " + i);
                                m_CurrentFLD.setScale(i);
                                m_CurrentFLD.setScaleSpecified(true);
                            }

                            break;
                        }

                    case REFERENCE_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(REFERENCE_DESCRIPTOR));
                            
                            name = atts.getValue(tags.getTagById(FIELD_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);

                            
                            String classRef = atts.getValue(tags.getTagById(REFERENCED_CLASS));
                            if (isDebug) logger.debug("     " + tags.getTagById(REFERENCED_CLASS) + ": " + classRef);

                            ObjectReferenceDescriptor ord;
                            if (name.equals(TAG_SUPER))
                            {
                                
    
    
    
    
    

                                ord = new SuperReferenceDescriptor(m_CurrentCLD);
                            }
                            else
                            {
                                ord = new ObjectReferenceDescriptor(m_CurrentCLD);
                                PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                                ord.setPersistentField(pf);
                            }
                            m_CurrentORD = ord;

                            
                            m_CurrentCLD.addObjectReferenceDescriptor(m_CurrentORD);
                            m_CurrentORD.setItemClass(ClassHelper.getClass(classRef));

                            
                            this.m_CurrentAttrContainer = m_CurrentORD;

                            
                            String proxy = atts.getValue(tags.getTagById(PROXY_REFERENCE));
                            if (isDebug) logger.debug("     " + tags.getTagById(PROXY_REFERENCE) + ": " + proxy);
                            boolean b = (Boolean.valueOf(proxy)).booleanValue();
                            m_CurrentORD.setLazy(b);

                            
                            String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                            if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                            if (proxyPrefetchingLimit == null)
                            {
                                m_CurrentORD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                            }
                            else
                            {
                                m_CurrentORD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                            }

                            
                            String refresh = atts.getValue(tags.getTagById(REFRESH));
                            if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                            b = (Boolean.valueOf(refresh)).booleanValue();
                            m_CurrentORD.setRefresh(b);

                            
                            String autoRetrieve = atts.getValue(tags.getTagById(AUTO_RETRIEVE));
                            if (isDebug) logger.debug("     " + tags.getTagById(AUTO_RETRIEVE) + ": " + autoRetrieve);
                            b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                            m_CurrentORD.setCascadeRetrieve(b);

                            
                            String autoUpdate = atts.getValue(tags.getTagById(AUTO_UPDATE));
                            if (isDebug) logger.debug("     " + tags.getTagById(AUTO_UPDATE) + ": " + autoUpdate);
                            if(autoUpdate != null)
                            {
                                m_CurrentORD.setCascadingStore(autoUpdate);
                            }

                            
                            String autoDelete = atts.getValue(tags.getTagById(AUTO_DELETE));
                            if (isDebug) logger.debug("     " + tags.getTagById(AUTO_DELETE) + ": " + autoDelete);

                            if(autoDelete != null)
                            {
                                m_CurrentORD.setCascadingDelete(autoDelete);
                            }

                            
                            String otmDependent = atts.getValue(tags.getTagById(OTM_DEPENDENT));
                            if (isDebug) logger.debug("     " + tags.getTagById(OTM_DEPENDENT) + ": " + otmDependent);
                            b = (Boolean.valueOf(otmDependent)).booleanValue();
                            m_CurrentORD.setOtmDependent(b);

                            break;
                        }

                    case FOREIGN_KEY:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(FOREIGN_KEY));
                            String fieldIdRef = atts.getValue(tags.getTagById(FIELD_ID_REF));

                            if (fieldIdRef != null)
                            {
                                if (isDebug) logger.debug("      " + tags.getTagById(FIELD_ID_REF) + ": " + fieldIdRef);

                                try
                                {
                                    int fieldId;
                                    fieldId = Integer.parseInt(fieldIdRef);
                                    m_CurrentORD.addForeignKeyField(fieldId);
                                }
                                catch (NumberFormatException rex)
                                {
                                    throw new MetadataException(tags.getTagById(FIELD_ID_REF)
                                            + " attribute must be an int. Found: "
                                            + fieldIdRef + ". Please check your repository file.", rex);
                                }
                            }
                            else
                            {
                                String fieldRef = atts.getValue(tags.getTagById(FIELD_REF));
                                if (isDebug) logger.debug("      " + tags.getTagById(FIELD_REF) + ": " + fieldRef);
                                m_CurrentORD.addForeignKeyField(fieldRef);
                            }
                            break;
                        }

                    case COLLECTION_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(COLLECTION_DESCRIPTOR));
                            m_CurrentCOD = new CollectionDescriptor(m_CurrentCLD);


                            
                            this.m_CurrentAttrContainer = m_CurrentCOD;

                            
                            name = atts.getValue(tags.getTagById(FIELD_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);
    						PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                            m_CurrentCOD.setPersistentField(pf);

                            
                            String collectionClassName = atts.getValue(tags.getTagById(COLLECTION_CLASS));
                            if (collectionClassName != null)
                            {
                                if (isDebug) logger.debug("     " + tags.getTagById(COLLECTION_CLASS) + ": " + collectionClassName);
                                m_CurrentCOD.setCollectionClass(ClassHelper.getClass(collectionClassName));
                            }
                            
                            String elementClassRef = atts.getValue(tags.getTagById(ITEMS_CLASS));
                            if (isDebug) logger.debug("     " + tags.getTagById(ITEMS_CLASS) + ": " + elementClassRef);
                            if (elementClassRef != null)
                            {
                                m_CurrentCOD.setItemClass(ClassHelper.getClass(elementClassRef));
                            }

                            
                            String orderby = atts.getValue(tags.getTagById(ORDERBY));
                            String sort = atts.getValue(tags.getTagById(SORT));
                            if (isDebug) logger.debug("     " + tags.getTagById(SORT) + ": " + orderby + ", " + sort);
                            if (orderby != null)
                            {
                                m_CurrentCOD.addOrderBy(orderby, "ASC".equalsIgnoreCase(sort));
                            }

                            
                            String indirectionTable = atts.getValue(tags.getTagById(INDIRECTION_TABLE));
                            if (isDebug) logger.debug("     " + tags.getTagById(INDIRECTION_TABLE) + ": " + indirectionTable);
                            m_CurrentCOD.setIndirectionTable(indirectionTable);

                            
                            String proxy = atts.getValue(tags.getTagById(PROXY_REFERENCE));
                            if (isDebug) logger.debug("     " + tags.getTagById(PROXY_REFERENCE) + ": " + proxy);
                            boolean b = (Boolean.valueOf(proxy)).booleanValue();
                            m_CurrentCOD.setLazy(b);

                            
                            String proxyPrefetchingLimit = atts.getValue(tags.getTagById(PROXY_PREFETCHING_LIMIT));
                            if (isDebug) logger.debug("     " + tags.getTagById(PROXY_PREFETCHING_LIMIT) + ": " + proxyPrefetchingLimit);
                            if (proxyPrefetchingLimit == null)
                            {
                                m_CurrentCOD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                            }
                            else
                            {
                                m_CurrentCOD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                            }

                            
                            String refresh = atts.getValue(tags.getTagById(REFRESH));
                            if (isDebug) logger.debug("     " + tags.getTagById(REFRESH) + ": " + refresh);
                            b = (Boolean.valueOf(refresh)).booleanValue();
                            m_CurrentCOD.setRefresh(b);

                            
                            String autoRetrieve = atts.getValue(tags.getTagById(AUTO_RETRIEVE));
                            if (isDebug) logger.debug("     " + tags.getTagById(AUTO_RETRIEVE) + ": " + autoRetrieve);
                            b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                            m_CurrentCOD.setCascadeRetrieve(b);

                            
                            String autoUpdate = atts.getValue(tags.getTagById(AUTO_UPDATE));
                            if (isDebug) logger.debug("     " + tags.getTagById(AUTO_UPDATE) + ": " + autoUpdate);
                            if(autoUpdate != null)
                            {
                                m_CurrentCOD.setCascadingStore(autoUpdate);
                            }

                            
                            String autoDelete = atts.getValue(tags.getTagById(AUTO_DELETE));
                            if (isDebug) logger.debug("     " + tags.getTagById(AUTO_DELETE) + ": " + autoDelete);
                            if(autoDelete != null)
                            {
                                m_CurrentCOD.setCascadingDelete(autoDelete);
                            }

                            
                            String otmDependent = atts.getValue(tags.getTagById(OTM_DEPENDENT));
                            if (isDebug) logger.debug("     " + tags.getTagById(OTM_DEPENDENT) + ": " + otmDependent);
                            b = (Boolean.valueOf(otmDependent)).booleanValue();
                            m_CurrentCOD.setOtmDependent(b);

                            m_CurrentCLD.addCollectionDescriptor(m_CurrentCOD);

                            break;
                        }
                    case ORDERBY :
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(ORDERBY));
                            name = atts.getValue(tags.getTagById(FIELD_NAME));
                            if (isDebug) logger.debug("     " + tags.getTagById(FIELD_NAME) + ": " + name);
                            String sort = atts.getValue(tags.getTagById(SORT));
                            if (isDebug) logger.debug("     " + tags.getTagById(SORT) + ": " + name + ", " + sort);

                            m_CurrentCOD.addOrderBy(name, "ASC".equalsIgnoreCase(sort));
                            break;
                        }
                    case INVERSE_FK:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(INVERSE_FK));
                            String fieldIdRef = atts.getValue(tags.getTagById(FIELD_ID_REF));

                            if (fieldIdRef != null)
                            {
                                if (isDebug) logger.debug("      " + tags.getTagById(FIELD_ID_REF) + ": " + fieldIdRef);

                                try
                                {
                                    int fieldId;
                                    fieldId = Integer.parseInt(fieldIdRef);
                                    m_CurrentCOD.addForeignKeyField(fieldId);
                                }
                                catch (NumberFormatException rex)
                                {
                                    throw new MetadataException(tags.getTagById(FIELD_ID_REF)
                                            + " attribute must be an int. Found: "
                                            + fieldIdRef + " Please check your repository file.", rex);
                                }
                            }
                            else
                            {
                                String fieldRef = atts.getValue(tags.getTagById(FIELD_REF));
                                if (isDebug) logger.debug("      " + tags.getTagById(FIELD_REF) + ": " + fieldRef);
                                m_CurrentCOD.addForeignKeyField(fieldRef);
                            }
                            break;
                        }

                    case FK_POINTING_TO_THIS_CLASS:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(FK_POINTING_TO_THIS_CLASS));
                            String column = atts.getValue("column");
                            if (isDebug) logger.debug("      " + "column" + ": " + column);
                            m_CurrentCOD.addFkToThisClass(column);
                            break;
                        }

                    case FK_POINTING_TO_ITEMS_CLASS:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(FK_POINTING_TO_ITEMS_CLASS));
                            String column = atts.getValue("column");
                            if (isDebug) logger.debug("      " + "column" + ": " + column);
                            m_CurrentCOD.addFkToItemClass(column);
                            break;
                        }
                    case ATTRIBUTE:
                        {
                            
                            String attributeName = atts.getValue(tags.getTagById(ATTRIBUTE_NAME));
                            String attributeValue = atts.getValue(tags.getTagById(ATTRIBUTE_VALUE));
                            
                            if (this.m_CurrentAttrContainer != null)
                            {
                                if (isDebug) logger.debug("      > " + tags.getTagById(ATTRIBUTE));
                                if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_NAME) + ": " + attributeName);
                                if (isDebug) logger.debug("       " + tags.getTagById(ATTRIBUTE_VALUE) + ": " + attributeValue);
                                this.m_CurrentAttrContainer.addAttribute(attributeName, attributeValue);
                            }
                            else
                            {
    
    
                            }
                            break;
                        }
    
    
    
    
    
    
    
    
    
                        case QUERY_CUSTOMIZER:
                            {
                                
                                String className = atts.getValue("class");
                                QueryCustomizer queryCust;

                                if (className != null)
                                {
                                    if (isDebug) logger.debug("     " + "class" + ": " + className);
                                    queryCust = (QueryCustomizer)ClassHelper.newInstance(className);
                                    m_CurrentAttrContainer = queryCust;
                                    m_CurrentCOD.setQueryCustomizer(queryCust);
                                }
                                break;
                            }
                        case INDEX_DESCRIPTOR:
                            {
                                m_CurrentIndexDescriptor = new IndexDescriptor();
                                m_CurrentIndexDescriptor.setName(atts.getValue(tags.getTagById(NAME)));
                                m_CurrentIndexDescriptor.setUnique(Boolean.valueOf(atts.getValue(tags.getTagById(UNIQUE))).booleanValue());
                                break;
                            }
                        case INDEX_COLUMN:
                            {
                                m_CurrentIndexDescriptor.getIndexColumns().add(atts.getValue(tags.getTagById(NAME)));
                                break;
                            }
                        case INSERT_PROCEDURE:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(INSERT_PROCEDURE));

                            
                            String procName = atts.getValue(tags.getTagById(NAME));
                            String includeAllFields = atts.getValue(tags.getTagById(INCLUDE_ALL_FIELDS));
                            if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                      ": " + procName);
                            if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_ALL_FIELDS) +
                                                      ": " + includeAllFields);

                            
                            InsertProcedureDescriptor proc =
                                new InsertProcedureDescriptor(m_CurrentCLD,
                                                              procName,
                                                              Boolean.valueOf(includeAllFields).booleanValue());
                            m_CurrentProcedure = proc;

                            
                            
                            String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                            if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                      ": " + returnFieldRefName);
                            proc.setReturnValueFieldRef(returnFieldRefName);

                            break;
                        }
                    case UPDATE_PROCEDURE:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(UPDATE_PROCEDURE));

                            
                            String procName = atts.getValue(tags.getTagById(NAME));
                            String includeAllFields = atts.getValue(tags.getTagById(INCLUDE_ALL_FIELDS));
                            if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                      ": " + procName);
                            if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_ALL_FIELDS) +
                                                      ": " + includeAllFields);

                            
                            UpdateProcedureDescriptor proc =
                                new UpdateProcedureDescriptor(m_CurrentCLD,
                                                              procName,
                                                              Boolean.valueOf(includeAllFields).booleanValue());
                            m_CurrentProcedure = proc;

                            
                            
                            String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                            if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                      ": " + returnFieldRefName);
                            proc.setReturnValueFieldRef(returnFieldRefName);

                            break;
                        }
                    case DELETE_PROCEDURE:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(DELETE_PROCEDURE));

                            
                            String procName = atts.getValue(tags.getTagById(NAME));
                            String includeAllPkFields = atts.getValue(tags.getTagById(INCLUDE_PK_FIELDS_ONLY));
                            if (isDebug) logger.debug("     " + tags.getTagById(NAME) +
                                                      ": " + procName);
                            if (isDebug) logger.debug("     " + tags.getTagById(INCLUDE_PK_FIELDS_ONLY) +
                                                      ": " + includeAllPkFields);

                            
                            DeleteProcedureDescriptor proc =
                                new DeleteProcedureDescriptor(m_CurrentCLD,
                                                              procName,
                                                              Boolean.valueOf(includeAllPkFields).booleanValue());
                            m_CurrentProcedure = proc;

                            
                            
                            String returnFieldRefName = atts.getValue(tags.getTagById(RETURN_FIELD_REF));
                            if (isDebug) logger.debug("     " + tags.getTagById(RETURN_FIELD_REF) +
                                                      ": " + returnFieldRefName);
                            proc.setReturnValueFieldRef(returnFieldRefName);

                            break;

                        }
                    case CONSTANT_ARGUMENT:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(CONSTANT_ARGUMENT));
                            ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                            
                            String value = atts.getValue(tags.getTagById(VALUE));
                            if (isDebug) logger.debug("     " + tags.getTagById(VALUE) + ": " + value);

                            
                            arg.setValue(value);

                            
                            m_CurrentProcedure.addArgument(arg);
                            break;
                        }
                    case RUNTIME_ARGUMENT:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(RUNTIME_ARGUMENT));
                            ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                            
                            String fieldRefName = atts.getValue(tags.getTagById(FIELD_REF));
                            if (isDebug) logger.debug("     " + tags.getTagById(FIELD_REF) +
                                                      ": " + fieldRefName);

                            
                            String returnValue = atts.getValue(tags.getTagById(RETURN));
                            if (isDebug) logger.debug("     " + tags.getTagById(RETURN) +
                                                      ": " + returnValue);

                            
                            if ((fieldRefName != null) && (fieldRefName.trim().length() != 0)) {
                                arg.setValue(fieldRefName,
                                             Boolean.valueOf(returnValue).booleanValue());
                            }

                            
                            m_CurrentProcedure.addArgument(arg);
                            break;
                        }

                    default :
                        {
                            
                        }
                }
            }
            catch (Exception ex)
            {
                logger.error("Exception while read metadata", ex);
                if(ex instanceof MetadataException) throw (MetadataException)ex;
                else throw new MetadataException("Exception when reading metadata information,"+
                        " please check your repository.xml file", ex);
            }
        }

    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    private boolean checkString(String value) { return value != null && value.trim().length() > 0; }

    public static void main(String[] args) {
        DescriptorRepository repository = new DescriptorRepository();
        method_1_ojb_gpt handler = new method_1_ojb_gpt(repository);

        AttributesImpl repositoryAttributes = new AttributesImpl();
        repositoryAttributes.addAttribute("", "isolation-level", "isolation-level", "CDATA", "read-committed");
        repositoryAttributes.addAttribute("", "proxy-prefetching-limit", "proxy-prefetching-limit", "CDATA", "25");
        repositoryAttributes.addAttribute("", "repository-version", "repository-version", "CDATA", DescriptorRepository.getVersion());
        handler.startElement("", "mapping-repository", "mapping-repository", repositoryAttributes);

        AttributesImpl classAttributes = new AttributesImpl();
        classAttributes.addAttribute("", "class", "class", "CDATA", DemoPersistent.class.getName());
        classAttributes.addAttribute("", "table", "table", "CDATA", "DEMO_TABLE");
        classAttributes.addAttribute("", "accept-locks", "accept-locks", "CDATA", "true");
        classAttributes.addAttribute("", "refresh", "refresh", "CDATA", "false");
        handler.startElement("", "class-descriptor", "class-descriptor", classAttributes);

        AttributesImpl fieldAttributes = new AttributesImpl();
        fieldAttributes.addAttribute("", "name", "name", "CDATA", "id");
        fieldAttributes.addAttribute("", "column", "column", "CDATA", "ID");
        fieldAttributes.addAttribute("", "jdbc-type", "jdbc-type", "CDATA", "INTEGER");
        fieldAttributes.addAttribute("", "primarykey", "primarykey", "CDATA", "true");
        fieldAttributes.addAttribute("", "indexed", "indexed", "CDATA", "true");
        fieldAttributes.addAttribute("", "autoincrement", "autoincrement", "CDATA", "false");
        fieldAttributes.addAttribute("", "locking", "locking", "CDATA", "false");
        handler.startElement("", "field-descriptor", "field-descriptor", fieldAttributes);

        System.out.println("repository.defaultIsolation=" + repository.defaultIsolationLevel);
        System.out.println("repository.classDescriptors=" + repository.classes.size());
        System.out.println("class.table=" + handler.m_CurrentCLD.tableName);
        System.out.println("class.fields=" + handler.m_CurrentCLD.fields.size());
        System.out.println("field.column=" + handler.m_CurrentFLD.columnName);
        System.out.println("field.primaryKey=" + handler.m_CurrentFLD.primaryKey);
        System.out.println("proxy.prefetch.default=" + handler.defProxyPrefetchingLimit);
    }

    public static final class DemoPersistent { public int id; }

    static final class RepositoryTags {
        private static final RepositoryTags INSTANCE = new RepositoryTags();
        private final Map<String,Integer> ids = new HashMap<>();
        private final Map<Integer,String> tags = new HashMap<>();
        private RepositoryTags() {
            register(MAPPING_REPOSITORY,"mapping-repository"); register(CLASS_DESCRIPTOR,"class-descriptor");
            register(OBJECT_CACHE,"object-cache"); register(CLASS_EXTENT,"class-extent"); register(FIELD_DESCRIPTOR,"field-descriptor");
            register(REFERENCE_DESCRIPTOR,"reference-descriptor"); register(FOREIGN_KEY,"foreignkey"); register(COLLECTION_DESCRIPTOR,"collection-descriptor");
            register(ORDERBY,"orderby"); register(INVERSE_FK,"inverse-foreignkey"); register(FK_POINTING_TO_THIS_CLASS,"fk-pointing-to-this-class");
            register(FK_POINTING_TO_ITEMS_CLASS,"fk-pointing-to-items-class"); register(ATTRIBUTE,"attribute"); register(QUERY_CUSTOMIZER,"query-customizer");
            register(INDEX_DESCRIPTOR,"index-descriptor"); register(INDEX_COLUMN,"index-column"); register(INSERT_PROCEDURE,"insert-procedure");
            register(UPDATE_PROCEDURE,"update-procedure"); register(DELETE_PROCEDURE,"delete-procedure"); register(CONSTANT_ARGUMENT,"constant-argument"); register(RUNTIME_ARGUMENT,"runtime-argument");
            
            alias(ISOLATION_LEVEL,"isolation-level"); alias(PROXY_PREFETCHING_LIMIT,"proxy-prefetching-limit"); alias(REPOSITORY_VERSION,"repository-version");
            alias(CLASS_NAME,"class"); alias(TABLE_NAME,"table"); alias(ACCEPT_LOCKS,"accept-locks"); alias(REFRESH,"refresh");
            alias(FIELD_NAME,"name"); alias(COLUMN_NAME,"column"); alias(JDBC_TYPE,"jdbc-type"); alias(PRIMARY_KEY,"primarykey"); alias(INDEXED,"indexed");
            alias(AUTO_INCREMENT,"autoincrement"); alias(LOCKING,"locking"); alias(NAME,"name"); alias(UNIQUE,"unique");
            alias(INCLUDE_ALL_FIELDS,"include-all-fields"); alias(INCLUDE_PK_FIELDS_ONLY,"include-pk-fields-only"); alias(RETURN_FIELD_REF,"return-field-ref");
            alias(VALUE,"value"); alias(FIELD_REF,"field-ref"); alias(RETURN,"return");
        }
        private void register(int id,String tag) { ids.put(tag,id); tags.put(id,tag); }
        private void alias(int id,String tag) { tags.put(id,tag); }
        static RepositoryTags getInstance() { return INSTANCE; }
        int getIdByTag(String tag) { Integer id=ids.get(tag); if(id==null) throw new NullPointerException(tag); return id; }
        String getTagById(int id) { return tags.getOrDefault(id, "tag-"+id); }
    }

    static class MetadataException extends RuntimeException { MetadataException(String m){super(m);} MetadataException(String m,Throwable t){super(m,t);} }
    static final class Logger { boolean isDebugEnabled(){return false;} void debug(Object o){} void error(Object o){System.err.println(o);} void error(Object o,Throwable t){System.err.println(o+": "+t);} }
    static final class LoggerFactory { static Logger getLogger(Class<?> c){return new Logger();} }
    static final class LockHelper { static int getIsolationLevelFor(String s){return s==null?0:2;} }
    static final class ClassHelper { static Class<?> getClass(String n)throws ClassNotFoundException{return Class.forName(n);} static Object newInstance(String n)throws Exception{return getClass(n).getDeclaredConstructor().newInstance();} }

    static class AttributeContainer { final Map<String,String> attributes=new HashMap<>(); void addAttribute(String n,String v){attributes.put(n,v);} }
    static class DescriptorRepository extends AttributeContainer {
        static String getVersion(){return "1.0";} int defaultIsolationLevel; final Map<String,ClassDescriptor> classes=new HashMap<>();
        void setDefaultIsolationLevel(int v){defaultIsolationLevel=v;} void put(String n,ClassDescriptor c){classes.put(n,c);}
    }
    static class ClassDescriptor extends AttributeContainer {
        static final String DYNAMIC_STR="dynamic"; final DescriptorRepository repository; Class<?> objectClass; String tableName; String persistentFieldClassName;
        final List<FieldDescriptor> fields=new ArrayList<>(); final List<ObjectReferenceDescriptor> references=new ArrayList<>(); final List<CollectionDescriptor> collections=new ArrayList<>(); final List<IndexDescriptor> indexes=new ArrayList<>();
        ClassDescriptor(DescriptorRepository r){repository=r;} void setIsolationLevel(int v){} void setClassOfObject(Class<?> c){objectClass=c;} Class<?> getClassOfObject(){return objectClass;}
        String getClassNameOfObject(){return objectClass.getName();} void setSchema(String s){} void setProxyClassName(String s){} void setProxyPrefetchingLimit(int v){}
        void setTableName(String s){tableName=s;} void setIsInterface(boolean b){} void setRowReader(String s){} void setSuperClass(String s){} void setAcceptLocks(boolean b){}
        void setInitializationMethod(String s){} void setFactoryClass(String s){} void setFactoryMethod(String s){} void setAlwaysRefresh(boolean b){}
        void setPersistentFieldClassName(String s){persistentFieldClassName=s;} String getPersistentFieldClassName(){return persistentFieldClassName;}
        void setObjectCacheDescriptor(ObjectCacheDescriptor d){} void addExtentClass(String s){} void addFieldDescriptor(FieldDescriptor f){fields.add(f);}
        void addObjectReferenceDescriptor(ObjectReferenceDescriptor r){references.add(r);} void addCollectionDescriptor(CollectionDescriptor c){collections.add(c);}
        List<IndexDescriptor> getIndexes(){return indexes;} void setInsertProcedure(InsertProcedureDescriptor p){} void setUpdateProcedure(UpdateProcedureDescriptor p){} void setDeleteProcedure(DeleteProcedureDescriptor p){}
    }
    static class PersistentField { final Class<?> owner; final String name; PersistentField(Class<?> o,String n){owner=o;name=n;} }
    static final class PersistentFieldFactory { static PersistentField createPersistentField(String strategy,Class<?> c,String n){return new PersistentField(c,n);} }
    static class FieldDescriptor extends AttributeContainer {
        final ClassDescriptor owner; final int id; String columnName; boolean primaryKey; FieldDescriptor(ClassDescriptor o,int i){owner=o;id=i;}
        void setAccess(String s){} void setPersistentField(PersistentField p){} void setColumnName(String s){columnName=s;} void setColumnType(String s){}
        void setPrimaryKey(boolean b){primaryKey=b;} void setRequired(boolean b){} void setIndexed(boolean b){} void setAutoIncrement(boolean b){}
        void setSequenceName(String s){} void setLocking(boolean b){} void setUpdateLock(boolean b){} void setFieldConversionClassName(String s){}
        void setLength(int i){} void setLengthSpecified(boolean b){} void setPrecision(int i){} void setPrecisionSpecified(boolean b){} void setScale(int i){} void setScaleSpecified(boolean b){}
    }
    static class AnonymousFieldDescriptor extends FieldDescriptor { AnonymousFieldDescriptor(ClassDescriptor o,int i){super(o,i);} void setPersistentField(Object ignored,String n){} }
    static class ObjectCacheDescriptor extends AttributeContainer { void setObjectCache(Class<?> c){} }
    static class ObjectReferenceDescriptor extends AttributeContainer {
        final ClassDescriptor owner; ObjectReferenceDescriptor(ClassDescriptor o){owner=o;} void setPersistentField(PersistentField p){} void setItemClass(Class<?> c){}
        void setLazy(boolean b){} void setProxyPrefetchingLimit(int i){} void setRefresh(boolean b){} void setCascadeRetrieve(boolean b){}
        void setCascadingStore(String s){} void setCascadingDelete(String s){} void setOtmDependent(boolean b){} void addForeignKeyField(int i){} void addForeignKeyField(String s){}
    }
    static class SuperReferenceDescriptor extends ObjectReferenceDescriptor { SuperReferenceDescriptor(ClassDescriptor o){super(o);} }
    static class CollectionDescriptor extends AttributeContainer {
        final ClassDescriptor owner; CollectionDescriptor(ClassDescriptor o){owner=o;} void setPersistentField(PersistentField p){} void setCollectionClass(Class<?> c){} void setItemClass(Class<?> c){}
        void addOrderBy(String s,boolean a){} void setIndirectionTable(String s){} void setLazy(boolean b){} void setProxyPrefetchingLimit(int i){}
        void setRefresh(boolean b){} void setCascadeRetrieve(boolean b){} void setCascadingStore(String s){} void setCascadingDelete(String s){}
        void setOtmDependent(boolean b){} void addForeignKeyField(int i){} void addForeignKeyField(String s){} void addFkToThisClass(String s){} void addFkToItemClass(String s){}
        void setQueryCustomizer(QueryCustomizer q){}
    }
    static class QueryCustomizer extends AttributeContainer { }
    static class IndexDescriptor { String name; boolean unique; final List<String> columns=new ArrayList<>(); void setName(String s){name=s;} void setUnique(boolean b){unique=b;} List<String> getIndexColumns(){return columns;} }
    static class ProcedureDescriptor extends AttributeContainer { final ClassDescriptor owner; final String name; final boolean include; final List<ArgumentDescriptor> args=new ArrayList<>(); ProcedureDescriptor(ClassDescriptor o,String n,boolean i){owner=o;name=n;include=i;} void addArgument(ArgumentDescriptor a){args.add(a);} }
    static class InsertProcedureDescriptor extends ProcedureDescriptor { InsertProcedureDescriptor(ClassDescriptor o,String n,boolean i){super(o,n,i);} void setReturnValueFieldRef(String s){} }
    static class UpdateProcedureDescriptor extends ProcedureDescriptor { UpdateProcedureDescriptor(ClassDescriptor o,String n,boolean i){super(o,n,i);} void setReturnValueFieldRef(String s){} }
    static class DeleteProcedureDescriptor extends ProcedureDescriptor { DeleteProcedureDescriptor(ClassDescriptor o,String n,boolean i){super(o,n,i);} void setReturnValueFieldRef(String s){} }
    static class ArgumentDescriptor { final ProcedureDescriptor owner; ArgumentDescriptor(ProcedureDescriptor o){owner=o;} void setValue(String s){} void setValue(String s,boolean b){} }
}
