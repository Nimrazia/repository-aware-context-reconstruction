import java.util.*;

public class method_3_jbeanbox_gpt<V extends method_3_jbeanbox_gpt.Value> {
    static final int ACC_ABSTRACT=0x400, ACC_NATIVE=0x100, ACC_STATIC=8, GOTO=167, JSR=168, RET=169, ATHROW=191, IRETURN=172, RETURN=177, LLOAD=22,DLOAD=24,LSTORE=55,DSTORE=57;
    Interpreter<V> interpreter; int n,top;InsnList insns;List<TryCatchBlockNode>[]handlers;Frame<V>[]frames;Subroutine[]subroutines;boolean[]queued;int[]queue;
    method_3_jbeanbox_gpt(Interpreter<V> i){interpreter=i;}
    static class Value{}
    static class Type{String d;Type(String x){d=x;}static Type getReturnType(String d){return new Type("R");}static Type[]getArgumentTypes(String d){return new Type[0];}static Type getObjectType(String o){return new Type(o);}int getSize(){return 1;}}
    static abstract class AbstractInsnNode{static final int LABEL=8,LINE=15,FRAME=14;int opcode,type;AbstractInsnNode(int o,int t){opcode=o;type=t;}int getOpcode(){return opcode;}int getType(){return type;}}
    static class LabelNode extends AbstractInsnNode{LabelNode(){super(-1,LABEL);}}
    static class JumpInsnNode extends AbstractInsnNode{LabelNode label;JumpInsnNode(int o,LabelNode l){super(o,7);label=l;}}
    static class LookupSwitchInsnNode extends AbstractInsnNode{LabelNode dflt;List<LabelNode>labels=new ArrayList<>();LookupSwitchInsnNode(LabelNode d){super(171,12);dflt=d;}}
    static class TableSwitchInsnNode extends AbstractInsnNode{LabelNode dflt;List<LabelNode>labels=new ArrayList<>();TableSwitchInsnNode(LabelNode d){super(170,11);dflt=d;}}
    static class VarInsnNode extends AbstractInsnNode{int var;VarInsnNode(int o,int v){super(o,2);var=v;}}
    static class IincInsnNode extends AbstractInsnNode{int var;IincInsnNode(int v){super(132,10);var=v;}}
    static class SimpleInsnNode extends AbstractInsnNode{SimpleInsnNode(int o){super(o,0);}}
    static class InsnList{List<AbstractInsnNode>x=new ArrayList<>();int size(){return x.size();}int indexOf(AbstractInsnNode n){return x.indexOf(n);}AbstractInsnNode get(int i){return x.get(i);}void add(AbstractInsnNode n){x.add(n);}}
    static class TryCatchBlockNode{LabelNode start,end,handler;String type;TryCatchBlockNode(LabelNode s,LabelNode e,LabelNode h,String t){start=s;end=e;handler=h;type=t;}}
    static class MethodNode{int access,maxLocals,maxStack;String desc="()V";InsnList instructions=new InsnList();List<TryCatchBlockNode>tryCatchBlocks=new ArrayList<>();}
    static class Subroutine{LabelNode start;boolean[]access;List<JumpInsnNode>callers=new ArrayList<>();Subroutine(LabelNode s,int n,JumpInsnNode c){start=s;access=new boolean[n];if(c!=null)callers.add(c);}Subroutine copy(){Subroutine s=new Subroutine(start,access.length,null);s.access=access.clone();s.callers.addAll(callers);return s;}}
    static class AnalyzerException extends Exception{AbstractInsnNode node;AnalyzerException(AbstractInsnNode n,String m){super(m);node=n;}AnalyzerException(AbstractInsnNode n,String m,Throwable t){super(m,t);node=n;}}
    static class Interpreter<X extends Value>{X newValue(Type t){return null;}}
    static class Frame<X extends Value>{Object[]locals;List<X>stack=new ArrayList<>();Frame(int l,int s){locals=new Object[l];}Frame<X>init(Frame<X>f){locals=f.locals.clone();stack=new ArrayList<>(f.stack);return this;}void execute(AbstractInsnNode n,Interpreter<X>i){}void setReturn(X v){}void setLocal(int i,X v){locals[i]=v;}void clearStack(){stack.clear();}void push(X v){stack.add(v);}}
    Frame<V> newFrame(int l,int s){return new Frame<>(l,s);}
    void findSubroutine(int i,Subroutine s,List<AbstractInsnNode>calls){if(i>=0&&i<subroutines.length)subroutines[i]=s;}
    void merge(int i,Frame<V>f,Subroutine s){if(i>=0&&i<frames.length){if(frames[i]==null)frames[i]=new Frame<V>(f.locals.length,0).init(f);if(!queued[i]){queued[i]=true;queue[top++]=i;}}}
    void merge(int i,Frame<V>a,Frame<V>b,Subroutine x,boolean[]access){merge(i,b,x);}
    void init(String o,MethodNode m){}void newControlFlowEdge(int a,int b){}boolean newControlFlowExceptionEdge(int i,TryCatchBlockNode t){return true;}

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public Frame<V>[] analyze(final String owner, final MethodNode m)
                throws AnalyzerException {
            if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) != 0) {
                frames = (Frame<V>[]) new Frame<?>[0];
                return frames;
            }
            n = m.instructions.size();
            insns = m.instructions;
            handlers = (List<TryCatchBlockNode>[]) new List<?>[n];
            frames = (Frame<V>[]) new Frame<?>[n];
            subroutines = new Subroutine[n];
            queued = new boolean[n];
            queue = new int[n];
            top = 0;

            
            for (int i = 0; i < m.tryCatchBlocks.size(); ++i) {
                TryCatchBlockNode tcb = m.tryCatchBlocks.get(i);
                int begin = insns.indexOf(tcb.start);
                int end = insns.indexOf(tcb.end);
                for (int j = begin; j < end; ++j) {
                    List<TryCatchBlockNode> insnHandlers = handlers[j];
                    if (insnHandlers == null) {
                        insnHandlers = new ArrayList<TryCatchBlockNode>();
                        handlers[j] = insnHandlers;
                    }
                    insnHandlers.add(tcb);
                }
            }

            
            Subroutine main = new Subroutine(null, m.maxLocals, null);
            List<AbstractInsnNode> subroutineCalls = new ArrayList<AbstractInsnNode>();
            Map<LabelNode, Subroutine> subroutineHeads = new HashMap<LabelNode, Subroutine>();
            findSubroutine(0, main, subroutineCalls);
            while (!subroutineCalls.isEmpty()) {
                JumpInsnNode jsr = (JumpInsnNode) subroutineCalls.remove(0);
                Subroutine sub = subroutineHeads.get(jsr.label);
                if (sub == null) {
                    sub = new Subroutine(jsr.label, m.maxLocals, jsr);
                    subroutineHeads.put(jsr.label, sub);
                    findSubroutine(insns.indexOf(jsr.label), sub, subroutineCalls);
                } else {
                    sub.callers.add(jsr);
                }
            }
            for (int i = 0; i < n; ++i) {
                if (subroutines[i] != null && subroutines[i].start == null) {
                    subroutines[i] = null;
                }
            }

            
            Frame<V> current = newFrame(m.maxLocals, m.maxStack);
            Frame<V> handler = newFrame(m.maxLocals, m.maxStack);
            current.setReturn(interpreter.newValue(Type.getReturnType(m.desc)));
            Type[] args = Type.getArgumentTypes(m.desc);
            int local = 0;
            if ((m.access & ACC_STATIC) == 0) {
                Type ctype = Type.getObjectType(owner);
                current.setLocal(local++, interpreter.newValue(ctype));
            }
            for (int i = 0; i < args.length; ++i) {
                current.setLocal(local++, interpreter.newValue(args[i]));
                if (args[i].getSize() == 2) {
                    current.setLocal(local++, interpreter.newValue(null));
                }
            }
            while (local < m.maxLocals) {
                current.setLocal(local++, interpreter.newValue(null));
            }
            merge(0, current, null);

            init(owner, m);

            
            while (top > 0) {
                int insn = queue[--top];
                Frame<V> f = frames[insn];
                Subroutine subroutine = subroutines[insn];
                queued[insn] = false;

                AbstractInsnNode insnNode = null;
                try {
                    insnNode = m.instructions.get(insn);
                    int insnOpcode = insnNode.getOpcode();
                    int insnType = insnNode.getType();

                    if (insnType == AbstractInsnNode.LABEL
                            || insnType == AbstractInsnNode.LINE
                            || insnType == AbstractInsnNode.FRAME) {
                        merge(insn + 1, f, subroutine);
                        newControlFlowEdge(insn, insn + 1);
                    } else {
                        current.init(f).execute(insnNode, interpreter);
                        subroutine = subroutine == null ? null : subroutine.copy();

                        if (insnNode instanceof JumpInsnNode) {
                            JumpInsnNode j = (JumpInsnNode) insnNode;
                            if (insnOpcode != GOTO && insnOpcode != JSR) {
                                merge(insn + 1, current, subroutine);
                                newControlFlowEdge(insn, insn + 1);
                            }
                            int jump = insns.indexOf(j.label);
                            if (insnOpcode == JSR) {
                                merge(jump, current, new Subroutine(j.label,
                                        m.maxLocals, j));
                            } else {
                                merge(jump, current, subroutine);
                            }
                            newControlFlowEdge(insn, jump);
                        } else if (insnNode instanceof LookupSwitchInsnNode) {
                            LookupSwitchInsnNode lsi = (LookupSwitchInsnNode) insnNode;
                            int jump = insns.indexOf(lsi.dflt);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                            for (int j = 0; j < lsi.labels.size(); ++j) {
                                LabelNode label = lsi.labels.get(j);
                                jump = insns.indexOf(label);
                                merge(jump, current, subroutine);
                                newControlFlowEdge(insn, jump);
                            }
                        } else if (insnNode instanceof TableSwitchInsnNode) {
                            TableSwitchInsnNode tsi = (TableSwitchInsnNode) insnNode;
                            int jump = insns.indexOf(tsi.dflt);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                            for (int j = 0; j < tsi.labels.size(); ++j) {
                                LabelNode label = tsi.labels.get(j);
                                jump = insns.indexOf(label);
                                merge(jump, current, subroutine);
                                newControlFlowEdge(insn, jump);
                            }
                        } else if (insnOpcode == RET) {
                            if (subroutine == null) {
                                throw new AnalyzerException(insnNode,
                                        "RET instruction outside of a sub routine");
                            }
                            for (int i = 0; i < subroutine.callers.size(); ++i) {
                                JumpInsnNode caller = subroutine.callers.get(i);
                                int call = insns.indexOf(caller);
                                if (frames[call] != null) {
                                    merge(call + 1, frames[call], current,
                                            subroutines[call], subroutine.access);
                                    newControlFlowEdge(insn, call + 1);
                                }
                            }
                        } else if (insnOpcode != ATHROW
                                && (insnOpcode < IRETURN || insnOpcode > RETURN)) {
                            if (subroutine != null) {
                                if (insnNode instanceof VarInsnNode) {
                                    int var = ((VarInsnNode) insnNode).var;
                                    subroutine.access[var] = true;
                                    if (insnOpcode == LLOAD || insnOpcode == DLOAD
                                            || insnOpcode == LSTORE
                                            || insnOpcode == DSTORE) {
                                        subroutine.access[var + 1] = true;
                                    }
                                } else if (insnNode instanceof IincInsnNode) {
                                    int var = ((IincInsnNode) insnNode).var;
                                    subroutine.access[var] = true;
                                }
                            }
                            merge(insn + 1, current, subroutine);
                            newControlFlowEdge(insn, insn + 1);
                        }
                    }

                    List<TryCatchBlockNode> insnHandlers = handlers[insn];
                    if (insnHandlers != null) {
                        for (int i = 0; i < insnHandlers.size(); ++i) {
                            TryCatchBlockNode tcb = insnHandlers.get(i);
                            Type type;
                            if (tcb.type == null) {
                                type = Type.getObjectType("java/lang/Throwable");
                            } else {
                                type = Type.getObjectType(tcb.type);
                            }
                            int jump = insns.indexOf(tcb.handler);
                            if (newControlFlowExceptionEdge(insn, tcb)) {
                                handler.init(f);
                                handler.clearStack();
                                handler.push(interpreter.newValue(type));
                                merge(jump, handler, subroutine);
                            }
                        }
                    }
                } catch (AnalyzerException e) {
                    throw new AnalyzerException(e.node, "Error at instruction "
                            + insn + ": " + e.getMessage(), e);
                } catch (Exception e) {
                    throw new AnalyzerException(insnNode, "Error at instruction "
                            + insn + ": " + e.getMessage(), e);
                }
            }

            return frames;
        }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    static class DemoInterpreter extends Interpreter<Value>{public Value newValue(Type t){return new Value();}}
    public static void main(String[]a)throws Exception{MethodNode m=new MethodNode();m.maxLocals=1;m.maxStack=1;m.instructions.add(new SimpleInsnNode(RETURN));method_3_jbeanbox_gpt<Value> an=new method_3_jbeanbox_gpt<>(new DemoInterpreter());Frame<Value>[]f=an.analyze("Demo",m);System.out.println("frames="+f.length+", entryInitialized="+(f[0]!=null));}
}
