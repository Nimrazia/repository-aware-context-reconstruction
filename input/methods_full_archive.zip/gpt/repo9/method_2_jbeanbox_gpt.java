import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.Map.Entry;

public class method_2_jbeanbox_gpt {
    static class BeanBoxException extends RuntimeException{BeanBoxException(String s){super(s);}static Object throwEX(String s){throw new BeanBoxException(s);}static Object throwEX(String s,Throwable t){throw new BeanBoxException(s);}static Object throwEX(Throwable t){throw new BeanBoxException(t.toString());}static void assureNotNull(Object o,String s){if(o==null)throw new BeanBoxException(s);}}
    static class EMPTY{}
    @Retention(RetentionPolicy.RUNTIME)@Target({ElementType.TYPE,ElementType.CONSTRUCTOR,ElementType.FIELD,ElementType.METHOD,ElementType.PARAMETER})@interface INJECT{Class<?> value() default EMPTY.class;boolean pureValue()default false;boolean required()default true;}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.TYPE)@interface PROTOTYPE{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.ANNOTATION_TYPE)@interface AOP{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.METHOD)@interface POSTCONSTRUCT{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.METHOD)@interface PREDESTROY{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.METHOD)@interface PostConstruct{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.METHOD)@interface PreDestroy{}
    static class BeanBox {
     Class<?> beanClass;boolean singleton,pureValue,required=true;Object target,singletonId;Class<?> type;Constructor<?> constructor;BeanBox[] constructorParams;Method createMethod,configMethod,postConstruct,preDestroy;Map<Field,BeanBox> fieldInjects;Map<Method,BeanBox[]> methodInjects;List<Object[]> aopRules;Map<Method,Object> methodAops;
     void setBeanClass(Class<?>v){beanClass=v;}Class<?>getBeanClass(){return beanClass;}void setSingleton(boolean v){singleton=v;}boolean isSingleton(){return singleton;}void setPureValue(boolean v){pureValue=v;}boolean isPureValue(){return pureValue;}void setRequired(boolean v){required=v;}boolean isRequired(){return required;}void setTarget(Object v){target=v;}Object getTarget(){return target;}void setType(Class<?>v){type=v;}Class<?>getType(){return type;}void setConstructor(Constructor<?>v){constructor=v;}Constructor<?>getConstructor(){return constructor;}void setConstructorParams(BeanBox[]v){constructorParams=v;}BeanBox[]getConstructorParams(){return constructorParams;}Method getCreateMethod(){return createMethod;}Method getConfigMethod(){return configMethod;}Method getPostConstruct(){return postConstruct;}void setPostConstruct(Method m){postConstruct=m;}void setPreDestroy(Method m){preDestroy=m;}Object getSingletonId(){return singletonId;}void setSingletonId(Object o){singletonId=o;}
     void checkOrCreateFieldInjects(){if(fieldInjects==null)fieldInjects=new LinkedHashMap<>();}Map<Field,BeanBox>getFieldInjects(){return fieldInjects;}void checkOrCreateMethodInjects(){if(methodInjects==null)methodInjects=new LinkedHashMap<>();}Map<Method,BeanBox[]>getMethodInjects(){return methodInjects;}List<Object[]>getAopRules(){return aopRules;}Map<Method,Object>getMethodAops(){return methodAops;}
     void addBeanAop(Object a,String m){if(aopRules==null)aopRules=new ArrayList<>();aopRules.add(new Object[]{a,m});}void addMethodAop(Object a,Method m){if(methodAops==null)methodAops=new LinkedHashMap<>();methodAops.put(m,a);}
    }
    static class ReflectionUtils{
     static List<Field> getSelfAndSuperClassFields(Class<?>c){List<Field>r=new ArrayList<>();for(Class<?>x=c;x!=null;x=x.getSuperclass())r.addAll(Arrays.asList(x.getDeclaredFields()));return r;}
     static Method[] getAllDeclaredMethods(Class<?>c){List<Method>r=new ArrayList<>();for(Class<?>x=c;x!=null;x=x.getSuperclass())r.addAll(Arrays.asList(x.getDeclaredMethods()));return r.toArray(new Method[0]);}
     static void makeAccessible(AccessibleObject o){o.setAccessible(true);}static Object invokeMethod(Method m,Object b,Object...a){try{return m.invoke(b,a);}catch(Exception e){throw new RuntimeException(e);}}static void setField(Field f,Object b,Object v){try{f.setAccessible(true);f.set(b,v);}catch(Exception e){throw new RuntimeException(e);}}
    }
    static class AopUtils{static Object createProxyBean(Class<?>c,BeanBox b,method_2_jbeanbox_gpt x){try{return c.getDeclaredConstructor().newInstance();}catch(Exception e){throw new RuntimeException(e);}}}
    static class Caller{Caller(method_2_jbeanbox_gpt c,boolean r,Set<Object>h,Object b){}}
    interface ValueTranslator{Object translate(String s,Class<?>t);}

    boolean allowSpringJsrAnnotation=true,allowAnnotation=true;Map<BeanBox,Object>singletonCache=new HashMap<>();List<Object[]>aopRules;ValueTranslator valueTranslator=(s,t)->s;
    boolean isAllowAnnotation(){return allowAnnotation;}List<Object[]>getAopRules(){return aopRules;} static class BeanBoxUtils{static boolean nameMatch(String p,String n){return n.matches(p.replace("*",".*"));}}
    Object getBean(Object key,boolean required,Set<Object>history){if(key instanceof Class){BeanBox b=new BeanBox();b.setBeanClass((Class<?>)key);b.setSingleton(true);return getBeanFromBox(b,required,history);}return key;}
    Object notfoundOrException(Object x,boolean r){if(r)throw new BeanBoxException("Not found "+x);return EMPTY.class;}
    static Object[] param2RealObjects(method_2_jbeanbox_gpt c,Set<Object>h,BeanBox[]bs){Object[]r=new Object[bs.length];for(int i=0;i<bs.length;i++)r[i]=c.getBeanFromBox(bs[i],bs[i].isRequired(),h);return r;}

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private Object getBeanFromBox(BeanBox box, boolean required, Set<Object> history) {
    		
    		BeanBoxException.assureNotNull(box, "Fail to build instance for a null beanBox");
    		Object bean = null;
    		if (box.isSingleton()) { 
    			bean = singletonCache.get(box);
    			if (bean != null)
    				return bean;
    		}

    		if (box.isPureValue()) 
    			return box.getTarget();
    		if (box.getTarget() != null) {
    			if (EMPTY.class != box.getTarget())
    				return getBean(box.getTarget(), box.isRequired(), history);
    			if (box.getType() != null)
    				return getBean(box.getType(), box.isRequired(), history);
    			else
    				return notfoundOrException(box.getTarget(), box.isRequired());
    		}

    		boolean aopFound = false;
    		if (box.getAopRules() != null || box.getMethodAops() != null)
    			aopFound = true;
    		else if (this.getAopRules() != null && box.getBeanClass() != null)
    			for (Object[] aops : this.getAopRules()) 
    				if (BeanBoxUtils.nameMatch((String) aops[1], box.getBeanClass().getName())) {
    					aopFound = true;
    					break;
    				}
    		if (aopFound)
    			bean = AopUtils.createProxyBean(box.getBeanClass(), box, this);
    		else if (box.getCreateMethod() != null) 
    			try {
    				Method m = box.getCreateMethod();
    				if (m.getParameterTypes().length == 1) {
    					bean = m.invoke(box, new Caller(this, required, history, null));
    				} else if (m.getParameterTypes().length == 0)
    					bean = m.invoke(box);
    				else
    					BeanBoxException.throwEX("Create method can only have 0 or 1 parameter");
    				BeanBoxException.assureNotNull(bean, "Create method created a null object.");
    			} catch (Exception e) {
    				return BeanBoxException.throwEX(e);
    			}
    		else if (box.getConstructor() != null) { 
    			if (box.getConstructorParams() != null && box.getConstructorParams().length > 0) {
    				Object[] initargs = param2RealObjects(this, history, box.getConstructorParams());
    				try {
    					bean = box.getConstructor().newInstance(initargs);
    				} catch (Exception e) {
    					return BeanBoxException.throwEX(e);
    				}
    			} else 
    				try {
    					bean = box.getConstructor().newInstance();
    				} catch (Exception e) {
    					return BeanBoxException.throwEX(e);
    				}
    		} else if (box.getBeanClass() != null) { 
    			if (EMPTY.class == box.getBeanClass())
    				return notfoundOrException(EMPTY.class, required);
    			try {
    				bean = box.getBeanClass().newInstance();
    			} catch (Exception e) {
    				BeanBoxException.throwEX("Failed to call 0 parameter constructor of: " + box.getBeanClass(), e);
    			}
    		} else
    			return notfoundOrException(null, required); 

    		

    		
    		if (box.isSingleton()) {
    			Object id = box.getSingletonId();
    			if (id != null)
    				singletonCache.put(box, bean);
    		} 

    		if (box.getConfigMethod() != null) {
    			try {
    				Method m = box.getConfigMethod();
    				if (m.getParameterTypes().length == 2)
    					m.invoke(box, bean, new Caller(this, required, history, bean));
    				else if (m.getParameterTypes().length == 1)
    					m.invoke(box, bean);
    				else
    					BeanBoxException.throwEX("Config method can only have 1 or 2 parameters");
    			} catch (Exception e) {
    				return BeanBoxException.throwEX(e);
    			}
    		}

    		if (box.getPostConstruct() != null) 
    			ReflectionUtils.invokeMethod(box.getPostConstruct(), bean);

    		if (box.getFieldInjects() != null) 
    			for (Entry<Field, BeanBox> entry : box.getFieldInjects().entrySet()) {
    				Field f = entry.getKey();
    				BeanBox b = entry.getValue();
    				Object fieldValue = this.getBeanFromBox(b, false, history);
    				if (EMPTY.class == fieldValue) {
    					if (b.isRequired())
    						BeanBoxException.throwEX("Not found required value for field: " + f.getName() + " in "
    								+ f.getDeclaringClass().getName());
    				} else {
    					if (fieldValue != null && fieldValue instanceof String)
    						fieldValue = this.valueTranslator.translate((String) fieldValue, b.getType());
    					ReflectionUtils.setField(f, bean, fieldValue);
    				}
    			}

    		if (box.getMethodInjects() != null) { 
    			for (Entry<Method, BeanBox[]> methods : box.getMethodInjects().entrySet()) {
    				Method m = methods.getKey();
    				BeanBox[] paramBoxs = methods.getValue();
    				if (paramBoxs != null && paramBoxs.length > 0) {
    					Object[] methodParams = param2RealObjects(this, history, paramBoxs);
    					ReflectionUtils.invokeMethod(m, bean, methodParams);
    				} else 
    					ReflectionUtils.invokeMethod(m, bean);
    			}
    		}
    		return bean;
    	}
    
    // ORIGINAL CODESEARCHNET METHOD — END
    



    static class Service{String value="created";}
    public static void main(String[]a){method_2_jbeanbox_gpt c=new method_2_jbeanbox_gpt();BeanBox b=new BeanBox();b.setBeanClass(Service.class);b.setSingleton(true);Object x=c.getBeanFromBox(b,true,new HashSet<>());Object y=c.getBeanFromBox(b,true,new HashSet<>());System.out.println("bean="+x.getClass().getSimpleName()+", singletonSame="+(x==y));}
}
