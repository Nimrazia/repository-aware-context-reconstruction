import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.Map.Entry;

public class method_1_jbeanbox_gpt {
    static class BeanBoxException extends RuntimeException{BeanBoxException(String s){super(s);}static Object throwEX(String s){throw new BeanBoxException(s);}static Object throwEX(String s,Throwable t){throw new BeanBoxException(s);}static Object throwEX(Throwable t){throw new BeanBoxException(t.toString());}static void assureNotNull(Object o,String s){if(o==null)throw new BeanBoxException(s);}}
    static class EMPTY{}
    @Retention(RetentionPolicy.RUNTIME)@Target({ElementType.TYPE,ElementType.CONSTRUCTOR,ElementType.FIELD,ElementType.METHOD,ElementType.PARAMETER})@interface INJECT{Class<?> value() default EMPTY.class;boolean pureValue()default false;boolean required()default true;}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.TYPE)@interface PROTOTYPE{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.ANNOTATION_TYPE)@interface AOP{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.METHOD)@interface POSTCONSTRUCT{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.METHOD)@interface PREDESTROY{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.METHOD)@interface PostConstruct{}
    @Retention(RetentionPolicy.RUNTIME)@Target(ElementType.METHOD)@interface PreDestroy{}
    static class BeanBox {
     Class<?> beanClass;boolean singleton,pureValue,required=true;Object target,singletonId;Class<?> type;Constructor<?> constructor;BeanBox[] constructorParams;Method createMethod,configMethod,postConstruct,preDestroy;Map<Field,BeanBox> fieldInjects;Map<Method,BeanBox[]> methodInjects;List<Object[]> aopRules;Map<Method,Object> methodAops;
     void setBeanClass(Class<?>v){beanClass=v;}Class<?>getBeanClass(){return beanClass;}void setSingleton(boolean v){singleton=v;}boolean isSingleton(){return singleton;}void setPureValue(boolean v){pureValue=v;}boolean isPureValue(){return pureValue;}void setRequired(boolean v){required=v;}boolean isRequired(){return required;}void setTarget(Object v){target=v;}Object getTarget(){return target;}void setType(Class<?>v){type=v;}Class<?>getType(){return type;}void setConstructor(Constructor<?>v){constructor=v;}Constructor<?>getConstructor(){return constructor;}void setConstructorParams(BeanBox[]v){constructorParams=v;}BeanBox[]getConstructorParams(){return constructorParams;}Method getCreateMethod(){return createMethod;}Method getConfigMethod(){return configMethod;}Method getPostConstruct(){return postConstruct;}void setPostConstruct(Method m){postConstruct=m;}void setPreDestroy(Method m){preDestroy=m;}Object getSingletonId(){return singletonId;}void setSingletonId(Object o){singletonId=o;}
     void checkOrCreateFieldInjects(){if(fieldInjects==null)fieldInjects=new LinkedHashMap<>();}Map<Field,BeanBox>getFieldInjects(){return fieldInjects;}void checkOrCreateMethodInjects(){if(methodInjects==null)methodInjects=new LinkedHashMap<>();}Map<Method,BeanBox[]>getMethodInjects(){return methodInjects;}List<Object[]>getAopRules(){return aopRules;}Map<Method,Object>getMethodAops(){return methodAops;}
     void addBeanAop(Object a,String m){if(aopRules==null)aopRules=new ArrayList<>();aopRules.add(new Object[]{a,m});}void addMethodAop(Object a,Method m){if(methodAops==null)methodAops=new LinkedHashMap<>();methodAops.put(m,a);}
    }
    static class ReflectionUtils{
     static List<Field> getSelfAndSuperClassFields(Class<?>c){List<Field>r=new ArrayList<>();for(Class<?>x=c;x!=null;x=x.getSuperclass())r.addAll(Arrays.asList(x.getDeclaredFields()));return r;}
     static Method[] getAllDeclaredMethods(Class<?>c){List<Method>r=new ArrayList<>();for(Class<?>x=c;x!=null;x=x.getSuperclass())r.addAll(Arrays.asList(x.getDeclaredMethods()));return r.toArray(new Method[0]);}
     static void makeAccessible(AccessibleObject o){o.setAccessible(true);}static Object invokeMethod(Method m,Object b,Object...a){try{return m.invoke(b,a);}catch(Exception e){throw new RuntimeException(e);}}static void setField(Field f,Object b,Object v){try{f.setAccessible(true);f.set(b,v);}catch(Exception e){throw new RuntimeException(e);}}
    }
    static class AopUtils{static Object createProxyBean(Class<?>c,BeanBox b,BeanBoxContext x){try{return c.getDeclaredConstructor().newInstance();}catch(Exception e){throw new RuntimeException(e);}}}
    static class Caller{Caller(BeanBoxContext c,boolean r,Set<Object>h,Object b){}}
    interface ValueTranslator{Object translate(String s,Class<?>t);}
    static class BeanBoxContext{
     boolean allowSpringJsrAnnotation=true,allowAnnotation=true;Map<BeanBox,Object>singletonCache=new HashMap<>();List<Object[]>aopRules;ValueTranslator valueTranslator=(s,t)->s;
     boolean isAllowAnnotation(){return allowAnnotation;}List<Object[]>getAopRules(){return aopRules;}
     Object getBean(Object key,boolean required,Set<Object>history){if(key instanceof Class){BeanBox b=method_1_jbeanbox_gpt.doCreateBeanBox(this,(Class<?>)key);return getBeanFromBox(b,required,history);}return key;}
     Object notfoundOrException(Object x,boolean r){if(r)throw new BeanBoxException("Not found "+x);return EMPTY.class;}
     Object getBeanFromBox(BeanBox b,boolean r,Set<Object>h){try{return b.getBeanClass().getDeclaredConstructor().newInstance();}catch(Exception e){throw new RuntimeException(e);}} static Object[] param2RealObjects(BeanBoxContext c,Set<Object>h,BeanBox[]bs){Object[]r=new Object[bs.length];for(int i=0;i<bs.length;i++)r[i]=c.getBeanFromBox(bs[i],bs[i].isRequired(),h);return r;}

    }

    static boolean checkAnnoExist(AnnotatedElement e,Class<? extends Annotation>a){return e.isAnnotationPresent(a);}
    static Map<String,Object> getAnnoAsMap(AnnotatedElement e,String n){return null;}
    static Object[] getInjectAnnotationAsArray(AnnotatedElement e,boolean allow){INJECT i=e.getAnnotation(INJECT.class);return i==null?null:new Object[]{i.value(),i.pureValue(),i.required()};}
    static Map<String,Object> changeAnnotationValuesToMap(Annotation a){Map<String,Object>m=new HashMap<>();try{for(Method x:a.annotationType().getDeclaredMethods())m.put(x.getName(),x.invoke(a));}catch(Exception e){}return m;}
    static BeanBox[] getParameterInjectAsBeanBoxArray(Executable e,boolean allow){Class<?>[]ts=e.getParameterTypes();BeanBox[]r=new BeanBox[ts.length];for(int i=0;i<ts.length;i++){r[i]=new BeanBox();r[i].setType(ts[i]);r[i].setTarget(ts[i]);}return r;}

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private static BeanBox doCreateBeanBox(BeanBoxContext ctx, Class<?> clazz) {
    		BeanBox box = new BeanBox();
    		box.setBeanClass(clazz);
    		box.setSingleton(true);

    		if (!ctx.isAllowAnnotation())
    			return box;
    		boolean allowSpringJsrAnno = ctx.allowSpringJsrAnnotation;

    		
    		if (checkAnnoExist(clazz, PROTOTYPE.class))
    			box.setSingleton(false);
    		else if (allowSpringJsrAnno) {
    			Map<String, Object> m = getAnnoAsMap(clazz, "org.springframework.context.annotation.Scope");
    			if (m != null)
    				for (Entry<String, Object> entry : m.entrySet())
    					if ("value".equals(entry.getKey())) {
    						if ("prototype".equalsIgnoreCase(String.valueOf(entry.getValue())))
    							box.setSingleton(false);
    						else if ("singleton".equalsIgnoreCase(String.valueOf(entry.getValue())))
    							box.setSingleton(true);
    						else
    							BeanBoxException.throwEX("'prototype' or 'singleton' required in @Scope annotation");
    					}
    		}

    		
    		Object[] v = getInjectAnnotationAsArray(clazz, allowSpringJsrAnno);
    		if (v != null) {
    			box.setTarget(v[0]);
    			box.setPureValue((Boolean) v[1]);
    			box.setRequired((Boolean) v[2]);
    		}

    		
    		Annotation[] annos = clazz.getAnnotations();
    		for (Annotation anno : annos) {
    			if (anno.annotationType().isAnnotationPresent(AOP.class)) {
    				Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
    				Object aop = annoMap.get("value");
    				String methodNameRule = (String) annoMap.get("method");
    				if (methodNameRule != null && methodNameRule.length() > 0 && aop != null)
    					box.addBeanAop(aop, methodNameRule);
    			}
    		}

    		
    		Constructor<?>[] constrs = clazz.getConstructors();
    		for (Constructor<?> constr : constrs) {
    			v = getInjectAnnotationAsArray(constr, allowSpringJsrAnno);
    			if (v != null) {
    				box.setBeanClass(clazz);
    				if (v[0] != null && EMPTY.class != v[0]) {
    					BeanBox inject = new BeanBox();
    					inject.setTarget(v[0]);
    					inject.setPureValue((Boolean) v[1]);
    					inject.setRequired((Boolean) v[2]);
    					inject.setType(constr.getParameterTypes()[0]);
    					box.setConstructor(constr);
    					box.setConstructorParams(new BeanBox[] { inject });
    				} else { 
    					BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(constr, allowSpringJsrAnno);
    					box.setConstructor(constr);
    					box.setConstructorParams(paramInjects);
    				}
    			}
    		}

    		
    		
    		for (Field f : ReflectionUtils.getSelfAndSuperClassFields(clazz)) {
    			v = getInjectAnnotationAsArray(f, allowSpringJsrAnno);
    			if (v != null) {
    				box.checkOrCreateFieldInjects();
    				BeanBox inject = new BeanBox();
    				inject.setTarget(v[0]);
    				inject.setPureValue((Boolean) v[1]);
    				inject.setRequired((Boolean) v[2]);
    				inject.setType(f.getType());
    				ReflectionUtils.makeAccessible(f);
    				box.getFieldInjects().put(f, inject);
    			}
    		}

    		
    		Method[] methods = ReflectionUtils.getAllDeclaredMethods(clazz); 
    		for (Method m : methods) { 
    			
    			if (m.getAnnotation(POSTCONSTRUCT.class) != null || m.getAnnotation(PostConstruct.class) != null) {
    				if (m.getParameterTypes().length > 0)
    					BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
    				ReflectionUtils.makeAccessible(m);
    				box.setPostConstruct(m);
    			}
    			if (m.getAnnotation(PREDESTROY.class) != null || m.getAnnotation(PreDestroy.class) != null) {
    				if (m.getParameterTypes().length > 0)
    					BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
    				ReflectionUtils.makeAccessible(m);
    				box.setPreDestroy(m);
    			}

    			
    			Annotation[] mtdAnnos = m.getAnnotations();
    			for (Annotation anno : mtdAnnos)
    				if (anno.annotationType().isAnnotationPresent(AOP.class)) {
    					Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
    					Object aop = annoMap.get("value");
    					if (aop != null)
    						box.addMethodAop(aop, m);
    				}

    			
    			v = getInjectAnnotationAsArray(m, allowSpringJsrAnno);
    			if (v != null) {
    				ReflectionUtils.makeAccessible(m);
    				BeanBox oneParam = new BeanBox();
    				oneParam.setTarget(v[0]);
    				oneParam.setPureValue((Boolean) v[1]);
    				oneParam.setRequired((Boolean) v[2]);
    				boolean haveOneParameter = v[0] != null && EMPTY.class != v[0];
    				if (haveOneParameter)
    					oneParam.setType(m.getParameterTypes()[0]); 
    				
    				box.checkOrCreateMethodInjects();
    				if (haveOneParameter) 
    					box.getMethodInjects().put(m, new BeanBox[] { oneParam });
    				else { 
    					BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(m, allowSpringJsrAnno);
    					box.getMethodInjects().put(m, paramInjects);
    				}
    			}
    		}
    		return box;

    	}
    
    // ORIGINAL CODESEARCHNET METHOD — END
    



    static class DemoDependency{}
    static class DemoBean{ @INJECT DemoDependency dep; boolean started; @POSTCONSTRUCT void start(){started=true;} @INJECT public void configure(DemoDependency d){dep=d;} }
    public static void main(String[]a)throws Exception{BeanBoxContext c=new BeanBoxContext();BeanBox b=doCreateBeanBox(c,DemoBean.class);System.out.println("beanClass="+b.getBeanClass().getSimpleName()+", fields="+(b.getFieldInjects()==null?0:b.getFieldInjects().size())+", methods="+(b.getMethodInjects()==null?0:b.getMethodInjects().size()));}
}
