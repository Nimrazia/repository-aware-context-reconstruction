import java.util.*;
public class method_3_jeppetto_gpt{static class Pair<A,B>{A a;B b;Pair(A a,B b){this.a=a;this.b=b;}A getFirst(){return a;}B getSecond(){return b;}}static class KeySchemaElement{String n;KeySchemaElement(String n){this.n=n;}}static class Projection{String t;Projection(String t){this.t=t;}String getProjectionType(){return t;}}static class LocalSecondaryIndexDescription{String n;List<KeySchemaElement>k;Projection p;LocalSecondaryIndexDescription(String n,List<KeySchemaElement>k,Projection p){this.n=n;this.k=k;this.p=p;}String getIndexName(){return n;}List<KeySchemaElement>getKeySchema(){return k;}Projection getProjection(){return p;}}static class GlobalSecondaryIndexDescription extends LocalSecondaryIndexDescription{GlobalSecondaryIndexDescription(String n,List<KeySchemaElement>k,Projection p){super(n,k,p);}}static class TableDescription{List<LocalSecondaryIndexDescription>l;List<GlobalSecondaryIndexDescription>g;List<LocalSecondaryIndexDescription>getLocalSecondaryIndexes(){return l;}List<GlobalSecondaryIndexDescription>getGlobalSecondaryIndexes(){return g;}}static class ProjectionExpressionBuilder{boolean isCoveredBy(Projection p){return true;}}static class IndexData{String indexName;List<String>keyFields;boolean projectsOverEntity;IndexData(String n,List<String>k,boolean p){indexName=n;keyFields=k;projectsOverEntity=p;}public String toString(){return indexName+keyFields+"/"+projectsOverEntity;}}static class DynamoDBQueryModelDAO{String rangeKeyField="created";String hashKeyField="account";Pair<String,String>getKeyAttributeNames(List<KeySchemaElement>k){return new Pair<>(k.get(0).n,k.size()>1?k.get(1).n:null);}

// ORIGINAL CODESEARCHNET METHOD — START

private Map<String, Map<String, IndexData>> processIndexes(TableDescription tableDescription,
                                                               ProjectionExpressionBuilder projectionExpressionBuilder,
                                                               IndexData baseIndexData) {
        
        Map<String, IndexData> localIndexes;
        List<LocalSecondaryIndexDescription> localSecondaryIndexes = tableDescription.getLocalSecondaryIndexes();
        if (localSecondaryIndexes != null) {
            localIndexes = new HashMap<>(localSecondaryIndexes.size() + 2);

            
            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);

            for (LocalSecondaryIndexDescription description : localSecondaryIndexes) {
                String indexField = getKeyAttributeNames(description.getKeySchema()).getSecond();
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>(baseIndexData.keyFields);
                keyFields.add(indexField);

                localIndexes.put(indexField, new IndexData(description.getIndexName(), keyFields, projectsOverEntity));
            }
        } else if (rangeKeyField != null) {
            localIndexes = new HashMap<>(2);

            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);
        } else {
            localIndexes = Collections.singletonMap(null, baseIndexData);
        }

        
        List<GlobalSecondaryIndexDescription> globalSecondaryIndexes = tableDescription.getGlobalSecondaryIndexes();
        if (globalSecondaryIndexes != null) {
            Map<String, Map<String, IndexData>> indexes = new HashMap<>(globalSecondaryIndexes.size() + 1);

            for (GlobalSecondaryIndexDescription description : globalSecondaryIndexes) {
                Pair<String, String> indexFields = getKeyAttributeNames(description.getKeySchema());
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>();
                keyFields.add(indexFields.getFirst());
                if (indexFields.getSecond() != null) {
                    keyFields.add(indexFields.getSecond());
                }
                keyFields.add(hashKeyField);
                if (rangeKeyField != null) {
                    keyFields.add(rangeKeyField);
                }

                IndexData indexData = new IndexData(description.getIndexName(), keyFields, projectsOverEntity);

                if (!indexes.containsKey(indexFields.getFirst())) {
                    indexes.put(indexFields.getFirst(), new HashMap<String, IndexData>());
                }

                indexes.get(indexFields.getFirst()).put(indexFields.getSecond(), indexData);

                
                
                IndexData noRangeKeyIndexData = indexes.get(indexFields.getFirst()).get(null);
                if (noRangeKeyIndexData == null || !noRangeKeyIndexData.projectsOverEntity) {
                    indexes.get(indexFields.getFirst()).put(null, indexData);
                }
            }

            indexes.put(hashKeyField, localIndexes);

            return indexes;
        } else {
            return Collections.singletonMap(hashKeyField, localIndexes);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END

}public static void main(String[]a){DynamoDBQueryModelDAO d=new DynamoDBQueryModelDAO();TableDescription t=new TableDescription();t.l=List.of(new LocalSecondaryIndexDescription("local-created",List.of(new KeySchemaElement("account"),new KeySchemaElement("status")),new Projection("ALL")));t.g=List.of(new GlobalSecondaryIndexDescription("global-email",List.of(new KeySchemaElement("email"),new KeySchemaElement("created")),new Projection("KEYS_ONLY")));System.out.println(d.processIndexes(t,new ProjectionExpressionBuilder(),new IndexData("base",List.of("account","created"),true)));}}
