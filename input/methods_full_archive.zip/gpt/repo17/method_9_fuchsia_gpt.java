import java.util.*;
public class method_9_fuchsia_gpt {
    Logger logger=new Logger();boolean endpointsAreTheSameDeviceClass=true;Map<Integer,ZWaveEndpoint>endpoints=new LinkedHashMap<>();ZWaveNode node=new ZWaveNode();Controller controller=new Controller();method_9_fuchsia_gpt(){endpoints.put(1,new ZWaveEndpoint(1));}ZWaveNode getNode(){return node;}Controller getController(){return controller;}

// ORIGINAL CODESEARCHNET METHOD — START

private void handleMultiChannelCapabilityReportResponse(SerialMessage serialMessage, int offset) {
        logger.debug("Process Multi-channel capability Report");
        int receivedEndpointId = serialMessage.getMessagePayloadByte(offset) & 0x7F;
        boolean dynamic = ((serialMessage.getMessagePayloadByte(offset) & 0x80) != 0);
        int genericDeviceClass = serialMessage.getMessagePayloadByte(offset + 1);
        int specificDeviceClass = serialMessage.getMessagePayloadByte(offset + 2);
        logger.debug("Endpoints are the same device class = {}", endpointsAreTheSameDeviceClass ? "true" : false);
        int startId = this.endpointsAreTheSameDeviceClass ? 1 : receivedEndpointId;
        int endId = this.endpointsAreTheSameDeviceClass ? this.endpoints.size() : receivedEndpointId;
        boolean supportsBasicCommandClass = this.getNode().supportsCommandClass(CommandClass.BASIC);
        for (int endpointId = startId; endpointId <= endId; endpointId++) {
            ZWaveEndpoint endpoint = this.endpoints.get(endpointId);
            if (endpoint == null){ logger.error("Endpoint {} not found on node {}. Cannot set command classes.", endpoint, this.getNode().getNodeId()); continue; }
            ZWaveDeviceClass.Basic basic = this.getNode().getDeviceClass().getBasicDeviceClass();
            ZWaveDeviceClass.Generic generic = ZWaveDeviceClass.Generic.getGeneric(genericDeviceClass);
            if (generic == null) { logger.error(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.", endpoint, genericDeviceClass, specificDeviceClass)); continue; }
            ZWaveDeviceClass.Specific specific = ZWaveDeviceClass.Specific.getSpecific(generic, specificDeviceClass);
            if (specific == null) { logger.error(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.", endpoint, genericDeviceClass, specificDeviceClass)); continue; }
            logger.debug("Endpoint Id = {}", endpointId); logger.debug("Endpoints is dynamic = {}", dynamic ? "true" : false);
            ZWaveDeviceClass deviceClass = endpoint.getDeviceClass(); deviceClass.setBasicDeviceClass(basic); deviceClass.setGenericDeviceClass(generic); deviceClass.setSpecificDeviceClass(specific);
            if (supportsBasicCommandClass) { ZWaveCommandClass commandClass = new ZWaveBasicCommandClass(this.getNode(), this.getController(), endpoint); endpoint.addCommandClass(commandClass); }
            for (int i = 0; i < serialMessage.getMessagePayload().length - offset - 3; i++) {
                int data = serialMessage.getMessagePayloadByte(offset + 3 + i); if(data == 0xef ) break;
                ZWaveCommandClass commandClass = ZWaveCommandClass.getInstance(data, this.getNode(), this.getController(), endpoint); if (commandClass == null) continue;
                endpoint.addCommandClass(commandClass); ZWaveCommandClass parentClass = this.getNode().getCommandClass(commandClass.getCommandClass()); if (parentClass != null) commandClass.setVersion(parentClass.getVersion());
            }
        }
        if (this.endpointsAreTheSameDeviceClass) this.getNode().advanceNodeStage(); else { for (ZWaveEndpoint ep : this.endpoints.values()) { if (ep.getDeviceClass().getBasicDeviceClass() == ZWaveDeviceClass.Basic.NOT_KNOWN) return; } this.getNode().advanceNodeStage(); }
    }

// ORIGINAL CODESEARCHNET METHOD — END

    public static void main(String[]a){method_9_fuchsia_gpt x=new method_9_fuchsia_gpt();x.handleMultiChannelCapabilityReportResponse(new SerialMessage(new byte[]{1,1,1,2,3}),0);System.out.println("endpointClasses="+x.endpoints.get(1).classes.size()+", advanced="+x.node.advanced);}
    enum CommandClass{BASIC,OTHER}static class SerialMessage{byte[]p;SerialMessage(byte[]p){this.p=p;}int getMessagePayloadByte(int i){return p[i]&255;}byte[]getMessagePayload(){return p;}}static class Controller{}static class ZWaveNode{boolean advanced;ZWaveDeviceClass d=new ZWaveDeviceClass();boolean supportsCommandClass(CommandClass c){return true;}int getNodeId(){return 1;}ZWaveDeviceClass getDeviceClass(){return d;}ZWaveCommandClass getCommandClass(CommandClass c){return null;}void advanceNodeStage(){advanced=true;}}static class ZWaveEndpoint{int id;ZWaveDeviceClass d=new ZWaveDeviceClass();List<ZWaveCommandClass>classes=new ArrayList<>();ZWaveEndpoint(int i){id=i;}ZWaveDeviceClass getDeviceClass(){return d;}void addCommandClass(ZWaveCommandClass c){classes.add(c);}public String toString(){return String.valueOf(id);}}static class ZWaveCommandClass{CommandClass c=CommandClass.OTHER;int v;static ZWaveCommandClass getInstance(int d,ZWaveNode n,Controller c,ZWaveEndpoint e){return new ZWaveCommandClass();}CommandClass getCommandClass(){return c;}void setVersion(int v){this.v=v;}int getVersion(){return v;}}static class ZWaveBasicCommandClass extends ZWaveCommandClass{ZWaveBasicCommandClass(ZWaveNode n,Controller c,ZWaveEndpoint e){this.c=CommandClass.BASIC;}}static class ZWaveDeviceClass{Basic b=Basic.CONTROLLER;Generic g;Specific s;Basic getBasicDeviceClass(){return b;}void setBasicDeviceClass(Basic x){b=x;}void setGenericDeviceClass(Generic x){g=x;}void setSpecificDeviceClass(Specific x){s=x;}enum Basic{NOT_KNOWN,CONTROLLER;String getLabel(){return name();}int getKey(){return ordinal();}}enum Generic{GENERIC;static Generic getGeneric(int x){return GENERIC;}String getLabel(){return name();}int getKey(){return 1;}}enum Specific{SPECIFIC;static Specific getSpecific(Generic g,int x){return SPECIFIC;}String getLabel(){return name();}int getKey(){return 1;}}}static class Logger{void debug(String s,Object...o){}void error(String s,Object...o){}}

}
