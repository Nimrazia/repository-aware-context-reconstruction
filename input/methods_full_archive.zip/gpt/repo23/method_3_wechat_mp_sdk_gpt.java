import java.io.*;import java.util.*;
public class method_3_wechat_mp_sdk_gpt{static class Logger{void info(String f,Object o){System.out.println("INFO "+f.replace("{}",String.valueOf(o)));}void error(String m,Throwable t){System.out.println("ERROR "+m);}}static final Logger log=new Logger();static class ServletException extends Exception{}interface HttpServletRequest{String getParameter(String n);}interface HttpServletResponse{void write(String s);}static class Signature{String signature,timestamp,nonce,echostr;String getEchostr(){return echostr;}public String toString(){return "Signature{"+signature+","+echostr+"}";}}static boolean checkSignature(Signature s,HttpServletRequest r){s.signature=r.getParameter("signature");s.timestamp=r.getParameter("timestamp");s.nonce=r.getParameter("nonce");s.echostr=r.getParameter("echostr");return "valid".equals(s.signature);}static class WebUtil{static void outputString(HttpServletResponse r,String s){r.write(s);}}static class HttpServlet{protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{}}static class AccessServlet extends HttpServlet{

// ORIGINAL CODESEARCHNET METHOD — START

@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Signature signature = new Signature();
            boolean hasRights = checkSignature(signature, request);

            if (hasRights) {
                log.info("signature-success:{}", signature);
                WebUtil.outputString(response, signature.getEchostr());
            } else {
                log.info("signature-not-match:{}", signature);
            }
        } catch (Exception e) {
            log.error("signature-error", e);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END

}
 public static void main(String[]a)throws Exception{Map<String,String>m=Map.of("signature","valid","timestamp","1","nonce","n","echostr","challenge");StringBuilder out=new StringBuilder();new AccessServlet().doGet(m::get,out::append);System.out.println("response="+out);}
}
