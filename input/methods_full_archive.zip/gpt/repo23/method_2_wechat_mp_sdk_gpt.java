import java.io.*;import java.util.*;
public class method_2_wechat_mp_sdk_gpt{static List<Class<?>>getAllSuperTypes(Class<?>c){List<Class<?>>x=new ArrayList<>();for(Class<?>p=c;p!=null;p=p.getSuperclass())x.add(p);return x;}static class Lists{static<T>List<T>reverse(List<T>x){List<T>r=new ArrayList<>(x);Collections.reverse(r);return r;}}static class Iterables{static Class<?>[] toArray(List<Class<?>> x, Class<Class> c){return x.toArray(new Class<?>[0]);}}static class JAXBContext{Class<?>[]types;static JAXBContext newInstance(Class<?>[]t){JAXBContext c=new JAXBContext();c.types=t;return c;}Unmarshaller createUnmarshaller(){return new Unmarshaller();}}static class Unmarshaller{Object unmarshal(StringReader r)throws Exception{StringBuilder s=new StringBuilder();int c;while((c=r.read())!=-1)s.append((char)c);Message m=new Message();int a=s.indexOf("<content>")+9,b=s.indexOf("</content>");m.content=a>=9&&b>a?s.substring(a,b):"";return m;}}static class Message{String content;public String toString(){return "Message{"+content+"}";}}static class XmlUtil{

// ORIGINAL CODESEARCHNET METHOD — START

public static Object unmarshal(String message, Class<?> childClass) {
        try {
            Class<?>[] reverseAndToArray = Iterables.toArray(Lists.reverse(getAllSuperTypes(childClass)), Class.class);
            JAXBContext jaxbCtx = JAXBContext.newInstance(reverseAndToArray);
            Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();

            return unmarshaller.unmarshal(new StringReader(message));
        } catch (Exception e) {
        }

        return null;
    }

// ORIGINAL CODESEARCHNET METHOD — END

}public static void main(String[]a){System.out.println(XmlUtil.unmarshal("<message><content>Hello</content></message>",Message.class));}}
