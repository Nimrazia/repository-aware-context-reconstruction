import java.io.*;import java.net.*;import java.util.*;
public class method_1_wechat_mp_sdk_gpt{
 static class Logger{void info(String f,Object...a){System.out.println("INFO "+Arrays.toString(a));}void error(String m,Throwable t){System.out.println("ERROR "+m+" : "+t.getMessage());}}static final Logger log=new Logger();static class License{}enum MediaType{IMAGE("image"),VOICE("voice");String n;MediaType(String n){this.n=n;}String getName(){return n;}}static class MediaFile{File f;MediaType t;MediaFile(File f,MediaType t){this.f=f;this.t=t;}MediaType getMediaType(){return t;}File getFile(){return f;}public String toString(){return f.getName()+":"+t;}}static class MediaJsonRtn{boolean success;String mediaId;String error;public String toString(){return success?"mediaId="+mediaId:"error="+error;}}static class JsonRtnUtil{static<T>T buildFailureJsonRtn(Class<T>c,String m){try{T t=c.getDeclaredConstructor().newInstance();((MediaJsonRtn)t).error=m;return t;}catch(Exception e){throw new RuntimeException(e);}}static<T>T parseJsonRtn(String j,Class<T>c){try{T t=c.getDeclaredConstructor().newInstance();((MediaJsonRtn)t).success=true;((MediaJsonRtn)t).mediaId="MEDIA-123";return t;}catch(Exception e){throw new RuntimeException(e);}}}static class AccessTokenUtil{static String getAccessToken(License l){return "token-demo";}}enum WechatRequest{UPLOAD_MEDIA("https://api.weixin.qq.com/cgi-bin/media/upload");String u;WechatRequest(String u){this.u=u;}String getUrl(){return u;}}static class URIBuilder{String u;Map<String,String>q=new LinkedHashMap<>();URIBuilder(String u){this.u=u;}URIBuilder setParameter(String k,String v){q.put(k,v);return this;}URI build()throws Exception{return new URI(u+"?"+q.entrySet().stream().map(e->e.getKey()+"="+e.getValue()).reduce((a,b)->a+"&"+b).orElse(""));}}interface HttpEntity{}static class MultipartEntityBuilder{File f;static MultipartEntityBuilder create(){return new MultipartEntityBuilder();}MultipartEntityBuilder addBinaryBody(String n,File f){this.f=f;return this;}HttpEntity build(){return new HttpEntity(){};}}static class Request{static Post Post(URI u){return new Post(u);}static class Post{URI u;Post(URI u){this.u=u;}Post connectTimeout(int x){return this;}Post socketTimeout(int x){return this;}Post body(HttpEntity e){return this;}Exec execute(){return new Exec();}}static class Exec{String handleResponse(Object h){return "{\"media_id\":\"MEDIA-123\"}";}}}static class HttpUtil{static final int CONNECT_TIMEOUT=1000,SOCKET_TIMEOUT=1000;static final Object UTF8_CONTENT_HANDLER=new Object();}
 static class MediaUtil{

// ORIGINAL CODESEARCHNET METHOD — START

public static MediaJsonRtn uploadMedia(License license, MediaFile mediaFile) {
        if (mediaFile == null) {
            return JsonRtnUtil.buildFailureJsonRtn(MediaJsonRtn.class, "missing mediaFile");
        }
        

        String accessToken = AccessTokenUtil.getAccessToken(license);
        String url = WechatRequest.UPLOAD_MEDIA.getUrl();
        try {
            MediaType mediaType = mediaFile.getMediaType();
            URI uri = new URIBuilder(url)
                    .setParameter("access_token", accessToken)
                    .setParameter("type", mediaType.getName())
                    .build();

            HttpEntity httpEntity = MultipartEntityBuilder.create()
                    .addBinaryBody("body", mediaFile.getFile())
                    .build();

            String rtnJson = Request.Post(uri)
                    .connectTimeout(HttpUtil.CONNECT_TIMEOUT)
                    .socketTimeout(HttpUtil.SOCKET_TIMEOUT)
                    .body(httpEntity)
                    .execute().handleResponse(HttpUtil.UTF8_CONTENT_HANDLER);

            MediaJsonRtn jsonRtn = JsonRtnUtil.parseJsonRtn(rtnJson, MediaJsonRtn.class);
            log.info("upload media:\n url={},\n body={},\n rtn={},{}", uri, mediaFile, rtnJson, jsonRtn);
            return jsonRtn;
        } catch (Exception e) {
            String msg = "upload media failed:\n " +
                    "url=" + url + "?access_token=" + accessToken + ",\n body=" + mediaFile;
            log.error(msg, e);
            return JsonRtnUtil.buildFailureJsonRtn(MediaJsonRtn.class, "uploadMedia failed");
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END

 }
 public static void main(String[]a)throws Exception{File f=File.createTempFile("wechat",".jpg");System.out.println(MediaUtil.uploadMedia(new License(),new MediaFile(f,MediaType.IMAGE)));System.out.println(MediaUtil.uploadMedia(new License(),null));f.delete();}
}
