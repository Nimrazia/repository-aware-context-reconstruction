import java.util.*;import java.util.concurrent.*;import java.io.Serializable;
public class method_2_restcomm_cluster_gpt{static class Logger{boolean isDebugEnabled(){return true;}void debug(Object x){System.out.println("DEBUG "+x);}void error(Object x,Throwable t){System.out.println("ERROR "+x);}}static final Logger logger=new Logger();enum PeriodicScheduleStrategy{withFixedDelay,atFixedRate}static class TimerTaskData{Serializable id;long start,period;PeriodicScheduleStrategy s;Serializable getTaskID(){return id;}long getStartTime(){return start;}long getPeriod(){return period;}PeriodicScheduleStrategy getPeriodicScheduleStrategy(){return s;}}static class TimerTask implements Runnable{TimerTaskData d;SetTimerAfterTxCommitRunnable a;ScheduledFuture<?>f;int runs;TimerTaskData getData(){return d;}void setSetTimerTransactionalAction(SetTimerAfterTxCommitRunnable x){a=x;}void setScheduledFuture(ScheduledFuture<?>x){f=x;}public void run(){runs++;System.out.println("task-run "+d.id+" #"+runs);}}static class Scheduler{ConcurrentMap<Serializable,TimerTask>m=new ConcurrentHashMap<>();ScheduledExecutorService e=Executors.newSingleThreadScheduledExecutor();ConcurrentMap<Serializable,TimerTask>getLocalRunningTasksMap(){return m;}ScheduledExecutorService getExecutor(){return e;}void remove(Serializable id,boolean b){m.remove(id);}}static class SetTimerAfterTxCommitRunnable implements Runnable{TimerTask task;Scheduler scheduler;boolean canceled;

// ORIGINAL CODESEARCHNET METHOD — START

public void run() {
		
		task.setSetTimerTransactionalAction(null);
		
		if (!canceled) {
			
			TimerTask previousTask = scheduler.getLocalRunningTasksMap().putIfAbsent(task.getData().getTaskID(), task);
			if(previousTask != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("A task with id " + task.getData().getTaskID() + " has already been added to the local tasks, not rescheduling");
				}
			}
			
			final TimerTaskData taskData = task.getData();
			
			long delay = taskData.getStartTime() - System.currentTimeMillis();
			if (delay < 0) {
				delay = 0;
			}
			
			try {
				
				if (taskData.getPeriod() < 0) {
					if (logger.isDebugEnabled()) {
						logger.debug("Scheduling one-shot timer with id "
								+ task.getData().getTaskID() + ", delay " + delay);
					}
					task.setScheduledFuture(scheduler.getExecutor().schedule(task, delay, TimeUnit.MILLISECONDS));
				} else {
					if (logger.isDebugEnabled()) {
						logger.debug("Scheduling periodic timer with id "
								+ task.getData().getTaskID() + ", scheduling strategy " + taskData.getPeriodicScheduleStrategy() + ", delay " + delay + ", period " + taskData.getPeriod());
					}
					if (taskData.getPeriodicScheduleStrategy() == PeriodicScheduleStrategy.withFixedDelay) {
						task.setScheduledFuture(scheduler.getExecutor().scheduleWithFixedDelay(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
					}
					else {
						
						task.setScheduledFuture(scheduler.getExecutor().scheduleAtFixedRate(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
					}					
				}		
			} catch (Throwable e) {
				logger.error(e.getMessage(), e);
				scheduler.remove(taskData.getTaskID(),true);
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("Canceled scheduling periodic timer with id "
						+ task.getData().getTaskID());
			}
		}
	}

// ORIGINAL CODESEARCHNET METHOD — END

}
public static void main(String[]a)throws Exception{Scheduler s=new Scheduler();TimerTaskData d=new TimerTaskData();d.id="T1";d.start=System.currentTimeMillis();d.period=-1;d.s=PeriodicScheduleStrategy.atFixedRate;TimerTask t=new TimerTask();t.d=d;SetTimerAfterTxCommitRunnable r=new SetTimerAfterTxCommitRunnable();r.task=t;r.scheduler=s;r.run();Thread.sleep(50);s.e.shutdownNow();System.out.println("local="+s.m.keySet());}}
