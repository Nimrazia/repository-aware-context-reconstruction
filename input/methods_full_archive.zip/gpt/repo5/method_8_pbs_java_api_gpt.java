
















import java.text.ParseException;import java.util.*;import java.util.logging.*;import java.util.regex.*;
interface ParserQueues<T>{java.util.List<T> parse(String text) throws java.text.ParseException;}
public class method_8_pbs_java_api_gpt implements ParserQueues<method_8_pbs_java_api_gpt.Queue> { static final Logger LOGGER=Logger.getLogger("QstatQueuesParser"); static final Pattern PATTERN_QUEUE=Pattern.compile("(?i)queue:(.*)"); static final String CHAR_EQUALS="="; static class StringUtils{static boolean isNotBlank(String s){return s!=null&&!s.trim().isEmpty();}} static class Utils{static String[] splitFirst(String s,String x){int i=s.indexOf(x);return i<0?new String[]{s}:new String[]{s.substring(0,i),s.substring(i+x.length())};}} static class Queue{String name,queueType,stateCount,mtime;int priority,totalJobs,maxUserRun;boolean enabled,started;Map<String,String> resourcesMax=new LinkedHashMap<>(),resourcesMin=new LinkedHashMap<>(),resourcesAssigned=new LinkedHashMap<>(),resourcesDefault=new LinkedHashMap<>(); void setName(String v){name=v;}void setQueueType(String v){queueType=v;}void setPriority(int v){priority=v;}void setTotalJobs(int v){totalJobs=v;}void setStateCount(String v){stateCount=v;}void setMtime(String v){mtime=v;}void setMaxUserRun(int v){maxUserRun=v;}void setEnabled(boolean v){enabled=v;}void setStarted(boolean v){started=v;}Map<String,String>getResourcesMax(){return resourcesMax;}Map<String,String>getResourcesMin(){return resourcesMin;}Map<String,String>getResourcesAssigned(){return resourcesAssigned;}Map<String,String>getResourcesDefault(){return resourcesDefault;}public String toString(){return name+"/"+queueType+"/"+totalJobs+"/"+enabled+"/"+resourcesMax;}}


// ORIGINAL CODESEARCHNET METHOD — START

@Override
    public List<Queue> parse(String text) throws ParseException {
        final List<Queue> queues;
        if (StringUtils.isNotBlank(text)) {
            queues = new LinkedList<Queue>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Queue queue = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_QUEUE.matcher(line);
                if (matcher.matches()) {
                    if (queue != null) {
                        queues.add(queue);
                    }
                    queue = new Queue();
                    final String name = matcher.group(1);
                    queue.setName(name);
                } else if (StringUtils.isNotBlank(line)) {
                    String[] temp = Utils.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("queue_type".equals(key)) {
                            queue.setQueueType(value);
                        } else if ("priority".equals(key)) {
                            try {
                                queue.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue priority: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("total_jobs".equals(key)) {
                            try {
                                queue.setTotalJobs(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue total jobs: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("state_count".equals(key)) {
                            queue.setStateCount(value);
                        } else if ("mtime".equals(key)) {
                            queue.setMtime(value);
                        } else if ("max_user_run".equals(key)) {
                            try {
                                queue.setMaxUserRun(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue max user run: " + nfe.getMessage(),
                                        nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("enabled".equals(key)) {
                            queue.setEnabled(Boolean.parseBoolean(value));
                        } else if ("started".equals(key)) {
                            queue.setStarted(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resources_max.")) {
                            queue.getResourcesMax().put(key, value);
                        } else if (key.startsWith("resources_min.")) {
                            queue.getResourcesMin().put(key, value);
                        } else if (key.startsWith("resources_assigned.")) {
                            queue.getResourcesAssigned().put(key, value);
                        } else if (key.startsWith("resources_default.")) {
                            queue.getResourcesDefault().put(key, value);
                        } else {
                            LOGGER.info("Unmmaped key, value: " + key + ", " + value);
                        }
                    }
                }
            }
            if (queue != null) {
                queues.add(queue);
            }
            return queues;
        } else {
            return Collections.emptyList();
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END

public static void main(String[]x)throws Exception{String s="Queue: batch\n queue_type = Execution\n total_jobs = 3\n enabled = true\n resources_max.ncpus = 16";List<Queue>q=new method_8_pbs_java_api_gpt().parse(s);System.out.println("queues="+q.size());System.out.println(q.get(0));}}