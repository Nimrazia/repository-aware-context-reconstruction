
















import java.text.ParseException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

interface ParserJobs<T>{java.util.List<T> parse(String text) throws java.text.ParseException;}
public class method_7_pbs_java_api_gpt implements ParserJobs<method_7_pbs_java_api_gpt.Job> {
    private static final Logger LOGGER=Logger.getLogger("QstatJobsParser");
    private static final Pattern PATTERN_JOB=Pattern.compile("(?i)job\\s+(?i)i(?i)d:(.*)");
    private static final String CHAR_EQUALS="=";
    static final class StringUtils { static boolean isNotBlank(String s){return s!=null&&!s.trim().isEmpty();} static String replace(String s,String a,String b){return s.replace(a,b);} }
    static final class Utils { static String[] splitFirst(String s,String sep){int i=s.indexOf(sep); return i<0?new String[]{s}:new String[]{s.substring(0,i),s.substring(i+sep.length())};}}
    static class Job { String id,name,owner,state,queue,server,checkpoint,ctime,errorPath,execHost,execPort,holdTypes,joinPath,keepFiles,mailPoints,mailUsers,mtime,outputPath,qtime,etime,euser,egroup,hashName,queueType,comment,submitArgs,submitHost,startTime; int priority,sessionId,substate,queueRank,startCount,jobArrayId,radix; long walltimeRemaining; boolean rerunable,faultTolerant; Map<String,String> resourcesUsed=new LinkedHashMap<>(),resourceList=new LinkedHashMap<>(),variableList=new LinkedHashMap<>();
void setId(String v){this.id=v;}
void setName(String v){this.name=v;}
void setOwner(String v){this.owner=v;}
void setState(String v){this.state=v;}
void setQueue(String v){this.queue=v;}
void setServer(String v){this.server=v;}
void setCheckpoint(String v){this.checkpoint=v;}
void setCtime(String v){this.ctime=v;}
void setErrorPath(String v){this.errorPath=v;}
void setExecHost(String v){this.execHost=v;}
void setExecPort(String v){this.execPort=v;}
void setHoldTypes(String v){this.holdTypes=v;}
void setJoinPath(String v){this.joinPath=v;}
void setKeepFiles(String v){this.keepFiles=v;}
void setMailPoints(String v){this.mailPoints=v;}
void setMailUsers(String v){this.mailUsers=v;}
void setMtime(String v){this.mtime=v;}
void setOutputPath(String v){this.outputPath=v;}
void setQtime(String v){this.qtime=v;}
void setEtime(String v){this.etime=v;}
void setEuser(String v){this.euser=v;}
void setEgroup(String v){this.egroup=v;}
void setHashName(String v){this.hashName=v;}
void setQueueType(String v){this.queueType=v;}
void setComment(String v){this.comment=v;}
void setSubmitArgs(String v){this.submitArgs=v;}
void setSubmitHost(String v){this.submitHost=v;}
void setStartTime(String v){this.startTime=v;}

void setPriority(int v){priority=v;} void setSessionId(int v){sessionId=v;} void setSubstate(int v){substate=v;} void setQueueRank(int v){queueRank=v;} void setStartCount(int v){startCount=v;} void setJobArrayId(int v){jobArrayId=v;} void setRadix(int v){radix=v;} void setWalltimeRemaining(long v){walltimeRemaining=v;} void setRerunable(boolean v){rerunable=v;} void setFaultTolerant(boolean v){faultTolerant=v;} Map<String,String> getResourcesUsed(){return resourcesUsed;} Map<String,String> getResourceList(){return resourceList;} Map<String,String> getVariableList(){return variableList;} public String toString(){return id+"/"+name+"/"+state+"/"+priority+"/"+resourcesUsed;} }


// ORIGINAL CODESEARCHNET METHOD — START

@Override
    public List<Job> parse(String text) throws ParseException {
        final List<Job> jobs;
        if (StringUtils.isNotBlank(text)) {
            text = StringUtils.replace(text, "\n\t", "");
            jobs = new LinkedList<Job>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Job job = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_JOB.matcher(line);
                if (matcher.matches()) {
                    if (job != null) {
                        jobs.add(job);
                    }
                    job = new Job();
                    final String id = matcher.group(1).trim();
                    job.setId(id);
                } else if (StringUtils.isNotBlank(line)) {
                    String[] temp = Utils.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("job_name".equalsIgnoreCase(key)) {
                            job.setName(value);
                        } else if ("job_owner".equalsIgnoreCase(key)) {
                            job.setOwner(value);
                        } else if (key.startsWith("resources_used.")) {
                            job.getResourcesUsed().put(key, value);
                        } else if ("job_state".equalsIgnoreCase(key)) {
                            job.setState(value);
                        } else if ("queue".equalsIgnoreCase(key)) {
                            job.setQueue(value);
                        } else if ("server".equalsIgnoreCase(key)) {
                            job.setServer(value);
                        } else if ("checkpoint".equalsIgnoreCase(key)) {
                            job.setCheckpoint(value);
                        } else if ("ctime".equalsIgnoreCase(key)) {
                            job.setCtime(value);
                        } else if ("error_path".equalsIgnoreCase(key)) {
                            job.setErrorPath(value);
                        } else if ("exec_host".equalsIgnoreCase(key)) {
                            job.setExecHost(value);
                        } else if ("exec_port".equalsIgnoreCase(key)) {
                            job.setExecPort(value);
                        } else if ("hold_types".equalsIgnoreCase(key)) {
                            job.setHoldTypes(value);
                        } else if ("join_path".equalsIgnoreCase(key)) {
                            job.setJoinPath(value);
                        } else if ("keep_files".equalsIgnoreCase(key)) {
                            job.setKeepFiles(value);
                        } else if ("mail_points".equalsIgnoreCase(key)) {
                            job.setMailPoints(value);
                        } else if ("mail_users".equalsIgnoreCase(key)) {
                            job.setMailUsers(value);
                        } else if ("mtime".equalsIgnoreCase(key)) {
                            job.setMtime(value);
                        } else if ("output_path".equalsIgnoreCase(key)) {
                            job.setOutputPath(value);
                        } else if ("priority".equalsIgnoreCase(key)) {
                            try {
                                job.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job priority: " + nfe.getMessage(), nfe);
                                job.setPriority(-1);
                            }
                        } else if ("qtime".equalsIgnoreCase(key)) {
                            job.setQtime(value);
                        } else if ("rerunable".equalsIgnoreCase(key)) {
                            job.setRerunable(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resource_list.")) {
                            job.getResourceList().put(key, value);
                        } else if ("session_id".equalsIgnoreCase(key)) {
                            try {
                                job.setSessionId(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job session id: " + nfe.getMessage(), nfe);
                                job.setSessionId(-1);
                            }
                        } else if ("substate".equalsIgnoreCase(key)) {
                            try {
                                job.setSubstate(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job substate: " + nfe.getMessage(), nfe);
                                job.setSubstate(-1);
                            }
                        } else if (key.startsWith("variable_list")) {
                            job.getVariableList().put(key, value);
                        } else if ("etime".equalsIgnoreCase(key)) {
                            job.setEtime(value);
                        } else if ("euser".equalsIgnoreCase(key)) {
                            job.setEuser(value);
                        } else if ("egroup".equalsIgnoreCase(key)) {
                            job.setEgroup(value);
                        } else if ("hashname".equalsIgnoreCase(key)) {
                            job.setHashName(value);
                        } else if ("queue_rank".equalsIgnoreCase(key)) {
                            try {
                                job.setQueueRank(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job queue rank: " + nfe.getMessage(), nfe);
                                job.setQueueRank(-1);
                            }
                        } else if ("queue_type".equalsIgnoreCase(key)) {
                            job.setQueueType(value);
                        } else if ("comment".equalsIgnoreCase(key)) {
                            job.setComment(value);
                        } else if ("submit_args".equalsIgnoreCase(key)) {
                            job.setSubmitArgs(value);
                        } else if ("submit_host".equalsIgnoreCase(key)) {
                            job.setSubmitHost(value);
                        } else if ("start_time".equalsIgnoreCase(key)) {
                            job.setStartTime(value);
                        } else if ("start_count".equalsIgnoreCase(key)) {
                            try {
                                job.setStartCount(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job start count: " + nfe.getMessage(), nfe);
                                job.setStartCount(-1);
                            }
                        } else if ("fault_tolerant".equalsIgnoreCase(key)) {
                            job.setFaultTolerant(Boolean.parseBoolean(value));
                        } else if ("job_array_id".equalsIgnoreCase(key)) {
                            job.setJobArrayId(Integer.parseInt(value));
                        } else if ("job_radix".equalsIgnoreCase(key)) {
                            try {
                                job.setRadix(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job radix: " + nfe.getMessage(), nfe);
                                job.setRadix(-1);
                            }
                        } else if ("walltime.remaining".equalsIgnoreCase(key)) {
                            try {
                                job.setWalltimeRemaining(Long.parseLong(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job walltime remaining: " + nfe.getMessage(),
                                        nfe);
                                job.setWalltimeRemaining(-1L);
                            }
                        }
                    }
                }
            }
            if (job != null) {
                jobs.add(job);
            }
            return jobs;
        } else {
            return Collections.emptyList();
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END

public static void main(String[] a)throws Exception{String s="Job Id: 101.server\n    Job_Name = demo\n    job_state = R\n    priority = 7\n    resources_used.cput = 00:01:00\nJob Id: 102.server\n    Job_Name = second\n    priority = bad"; List<Job> j=new method_7_pbs_java_api_gpt().parse(s); System.out.println("jobs="+j.size()); for(Job x:j)System.out.println(x);}
}
