import java.io.InputStream;import java.io.IOException;import java.io.OutputStreamWriter;import java.net.HttpURLConnection;import java.net.MalformedURLException;import java.net.URL;import java.util.zip.GZIPInputStream;import java.util.zip.InflaterInputStream;import javax.net.SocketFactory;import javax.net.ssl.HttpsURLConnection;import javax.net.ssl.SSLContext;import javax.net.ssl.SSLSocketFactory;import javax.net.ssl.TrustManager;
public class method_10_nitro_gpt {String objectType="demo",objectName="item";String get_object_type(){return objectType;}String get_object_name(){return objectName;}

// ORIGINAL CODESEARCHNET METHOD — START

private base_response delete_request(nitro_service service, String req_args) throws Exception
	{
		StringBuilder responseStr = new StringBuilder();
		HttpURLConnection httpURLConnection = null;
		try
		{
			String urlstr;
			String ipaddress = service.get_ipaddress();
			String version = service.get_version();
			String sessionid = service.get_sessionid();
			String objtype = get_object_type();
			String protocol = service.get_protocol();

			
			urlstr = protocol + "://" + ipaddress + "/nitro/" + version + "/config/" + objtype;

			String name = this.get_object_name();
			if (name != null && name.length() > 0)
			{
				urlstr = urlstr+"/"+nitro_util.encode(nitro_util.encode(name));
			}

			if(req_args != null || (service.get_warning()!=null && service.get_warning())){
				urlstr = urlstr+"?";
				if(req_args != null)
				{
					urlstr = urlstr + "args=" + req_args;
				}
				if(service.get_warning()!=null && service.get_warning())
				{
					if (req_args != null)
					{
						urlstr = urlstr+"&";
					}
					urlstr = urlstr + "warning=yes";
				}
			}

			URL url = new URL(urlstr);
			httpURLConnection = (HttpURLConnection) url.openConnection();

			httpURLConnection.setRequestMethod("DELETE");

			httpURLConnection.setRequestProperty("Cookie", "sessionid=" + nitro_util.encode(sessionid));
			httpURLConnection.setRequestProperty("Accept-Encoding", "gzip, deflate");

			if (httpURLConnection instanceof HttpsURLConnection)
			{
				if (service.get_certvalidation()) {
					SocketFactory sslSocketFactory = SSLSocketFactory.getDefault();
					HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);	
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				} else {
					SSLContext sslContext = SSLContext.getInstance("SSL");
					
					
					
					sslContext.init(null, new TrustManager[]{new EmptyTrustManager()}, null);
					SocketFactory sslSocketFactory = sslContext.getSocketFactory();
					
					HttpsURLConnection secured = (HttpsURLConnection) httpURLConnection;
					secured.setSSLSocketFactory((SSLSocketFactory)sslSocketFactory);
					if (!service.get_hostnameverification()) {
						



						secured.setHostnameVerifier(new EmptyHostnameVerifier());
					}
				}
			}

			InputStream input;
			try {
				input = httpURLConnection.getInputStream();
			}
			catch (Exception e) {
				input = httpURLConnection.getErrorStream();	
			}
			String contentEncoding = httpURLConnection.getContentEncoding();
			
			if (contentEncoding != null)
			{
				if(contentEncoding.equalsIgnoreCase("gzip"))
					input = new GZIPInputStream(input); 
				else if(contentEncoding.equalsIgnoreCase("deflate"))
					input = new InflaterInputStream(input);
			}

			int numOfTotalBytesRead;
			byte [] buffer = new byte[1024];
			while ((numOfTotalBytesRead = input.read(buffer, 0, buffer.length)) != -1)
			{
				responseStr.append(new String(buffer, 0, numOfTotalBytesRead));
			}

			httpURLConnection.disconnect();
			input.close();
		}
		catch (MalformedURLException mue)
		{
			throw mue;
		}
		catch (IOException ioe)
		{
			throw ioe;
		}
		catch(Exception e)
		{
			throw e;
		}
		base_response result =(base_response) service.get_payload_formatter().string_to_resource(base_response.class, responseStr.toString());
        if (result.errorcode != 0) 
        {
			if (result.errorcode == 444) {
				service.clear_session();
			}
			if(result.severity != null)
			{
				if(result.severity.equals("ERROR"))
					throw new nitro_exception(result.message,result.errorcode);
			}
			else
			{
				throw new nitro_exception(result.message,result.errorcode);
			}
		}
		return result;
	}

// ORIGINAL CODESEARCHNET METHOD — END

 public static void main(String[]a)throws Exception{try(LocalServer s=new LocalServer()){nitro_service n=new nitro_service();n.ipaddress="127.0.0.1:"+s.port();method_10_nitro_gpt x=new method_10_nitro_gpt();base_response r=x.delete_request(n,"force=yes");System.out.println("DELETE response errorcode="+r.errorcode+", session="+n.sessionid);}}

 static class nitro_service {String ipaddress;String version="v1";String sessionid="sid";String protocol="http";Boolean warning=false;boolean cert=true,host=true;PayloadFormatter pf=new PayloadFormatter();String get_ipaddress(){return ipaddress;}String get_version(){return version;}String get_sessionid(){return sessionid;}String get_protocol(){return protocol;}Boolean get_warning(){return warning;}boolean get_certvalidation(){return cert;}boolean get_hostnameverification(){return host;}PayloadFormatter get_payload_formatter(){return pf;}void clear_session(){sessionid="";}}
 static class options{boolean compression;String query="";String to_string(){return query;}boolean get_compression(){return compression;}}
 static class base_response{int errorcode;String severity,message;}
 static class PayloadFormatter{Object string_to_resource(Class<?>c,String s){base_response r=new base_response();r.errorcode=0;r.message=s;return r;}}
 static class nitro_exception extends Exception{nitro_exception(String m,int c){super(m+" ("+c+")");}}
 static class nitro_util{static String encode(String s){try{return java.net.URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}}
 static class EmptyHostnameVerifier implements javax.net.ssl.HostnameVerifier{public boolean verify(String h,javax.net.ssl.SSLSession s){return true;}}
 static class EmptyTrustManager implements javax.net.ssl.X509TrustManager{public java.security.cert.X509Certificate[]getAcceptedIssuers(){return new java.security.cert.X509Certificate[0];}public void checkClientTrusted(java.security.cert.X509Certificate[]c,String a){}public void checkServerTrusted(java.security.cert.X509Certificate[]c,String a){}}
 static class LocalServer implements AutoCloseable{java.net.ServerSocket ss;Thread t;volatile boolean run=true;LocalServer()throws Exception{ss=new java.net.ServerSocket(0);t=new Thread(()->{while(run)try{java.net.Socket s=ss.accept();handle(s);}catch(Exception e){}});t.start();}int port(){return ss.getLocalPort();}void handle(java.net.Socket s)throws Exception{java.io.BufferedReader r=new java.io.BufferedReader(new java.io.InputStreamReader(s.getInputStream()));String first=r.readLine();int len=0;String line;while((line=r.readLine())!=null&&!line.isEmpty())if(line.toLowerCase().startsWith("content-length:"))len=Integer.parseInt(line.substring(15).trim());char[]b=new char[len];if(len>0)r.read(b);String body="{\"errorcode\":0,\"request\":\""+first+"\"}";byte[]out=body.getBytes();java.io.OutputStream o=s.getOutputStream();o.write(("HTTP/1.1 200 OK\r\nContent-Length: "+out.length+"\r\nConnection: close\r\n\r\n").getBytes());o.write(out);o.flush();s.close();}public void close()throws Exception{run=false;ss.close();t.join(100);}}
}
