
















import java.lang.annotation.*; import java.math.BigDecimal; import java.time.LocalDate; import java.util.*;
public class method_1_isis_excel_gpt {
 enum SemanticsOf{IDEMPOTENT} enum InvokeOn{OBJECT_AND_COLLECTION} @Retention(RetentionPolicy.RUNTIME) @interface Action{SemanticsOf semantics(); InvokeOn invokeOn();}
 static class Container{void warnUser(String s){System.out.println("WARN: "+s);}}
 static class ActionInvocationContext{InvokedOn invokedOn=new InvokedOn(); InvokedOn getInvokedOn(){return invokedOn;}} static class InvokedOn{boolean collection; boolean isCollection(){return collection;}}
 static class ExcelModuleDemoToDoItem{enum Category{WORK,HOME} enum Subcategory{GENERAL,URGENT} String description,notes,ownedBy; Category category; Subcategory subcategory; LocalDate dueBy; BigDecimal cost; boolean complete; void setDescription(String v){description=v;} void setCategory(Category v){category=v;} void setSubcategory(Subcategory v){subcategory=v;} void setDueBy(LocalDate v){dueBy=v;} void setCost(BigDecimal v){cost=v;} void setNotes(String v){notes=v;} void setOwnedBy(String v){ownedBy=v;} void setComplete(boolean v){complete=v;} public String toString(){return description+"/"+complete+"/"+cost;}}
 static class ExcelModuleDemoToDoItems{Map<String,ExcelModuleDemoToDoItem> db=new LinkedHashMap<>(); ExcelModuleDemoToDoItem findByDescription(String d){return db.get(d);} ExcelModuleDemoToDoItem newToDo(String d,ExcelModuleDemoToDoItem.Category c,ExcelModuleDemoToDoItem.Subcategory s,LocalDate due,BigDecimal cost){ExcelModuleDemoToDoItem i=new ExcelModuleDemoToDoItem();i.setDescription(d);i.setCategory(c);i.setSubcategory(s);i.setDueBy(due);i.setCost(cost);db.put(d,i);return i;}}
 ExcelModuleDemoToDoItem toDoItem; String description,notes,ownedBy; ExcelModuleDemoToDoItem.Category category; ExcelModuleDemoToDoItem.Subcategory subcategory; LocalDate dueBy; BigDecimal cost; boolean complete; ExcelModuleDemoToDoItems toDoItems=new ExcelModuleDemoToDoItems(); ActionInvocationContext actionInvocationContext=new ActionInvocationContext(); Container container=new Container();
 ExcelModuleDemoToDoItem getToDoItem(){return toDoItem;} String getDescription(){return description;} ExcelModuleDemoToDoItem.Category getCategory(){return category;} ExcelModuleDemoToDoItem.Subcategory getSubcategory(){return subcategory;} LocalDate getDueBy(){return dueBy;} BigDecimal getCost(){return cost;} String getNotes(){return notes;} String getOwnedBy(){return ownedBy;} boolean isComplete(){return complete;} Container getContainer(){return container;}
 
// ORIGINAL CODESEARCHNET METHOD — START

@Action(
            semantics = SemanticsOf.IDEMPOTENT,
            invokeOn = InvokeOn.OBJECT_AND_COLLECTION
    )
    public ExcelModuleDemoToDoItem apply() {
        ExcelModuleDemoToDoItem item = getToDoItem();
        if(item == null) {
            
            item = toDoItems.findByDescription(getDescription());
            if(item != null) {
                getContainer().warnUser("Item already exists with description '" + getDescription() + "'");
            } else {
                
                
                item = toDoItems.newToDo(getDescription(), getCategory(), getSubcategory(), getDueBy(), getCost());
                item.setNotes(getNotes());
                item.setOwnedBy(getOwnedBy());
                item.setComplete(isComplete());
            }
        } else {
            
            
            item.setDescription(getDescription());
            item.setCategory(getCategory());
            item.setSubcategory(getSubcategory());
            item.setDueBy(getDueBy());
            item.setCost(getCost());
            item.setNotes(getNotes());
            item.setOwnedBy(getOwnedBy());
            item.setComplete(isComplete());
        }
        return actionInvocationContext.getInvokedOn().isCollection()? null: item;
    }

// ORIGINAL CODESEARCHNET METHOD — END

 public static void main(String[] args) {
    method_1_isis_excel_gpt x = new method_1_isis_excel_gpt();
    x.description = "Write thesis";
    x.category = ExcelModuleDemoToDoItem.Category.WORK;
    x.subcategory = ExcelModuleDemoToDoItem.Subcategory.URGENT;
    x.dueBy = LocalDate.of(2026, 8, 1);
    x.cost = new BigDecimal("25.00");
    x.notes = "repo-aware";
    x.ownedBy = "nimra";
    x.complete = true;
    System.out.println("METHOD: ExcelModuleDemoToDoItemViewModel.apply");
    System.out.println("INPUT description=Write thesis, category=WORK, subcategory=URGENT, dueBy=2026-08-01, cost=25.00, complete=true");
    Object created = x.apply();
    System.out.println("RESULT created item: " + created);
    System.out.println("STATE repository item count after creation: " + x.toDoItems.db.size());
    x.actionInvocationContext.invokedOn.collection = true;
    Object collectionResult = x.apply();
    System.out.println("BRANCH collection invocation return: " + collectionResult);
    System.out.println("STATE duplicate retained as one repository entry: " + (x.toDoItems.db.size() == 1));
}
}