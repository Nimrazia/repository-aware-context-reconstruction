
















import java.lang.annotation.*;import java.util.*;import java.util.function.Predicate; public class method_4_isis_excel_gpt { @interface Collection{} static class ExcelModuleDemoToDoItem{String owner,category,subcategory;boolean complete;ExcelModuleDemoToDoItem(String o,boolean c,String ca,String s){owner=o;complete=c;category=ca;subcategory=s;}public String toString(){return owner+":"+category+":"+complete;}static class Predicates{static Predicate<ExcelModuleDemoToDoItem> thoseOwnedBy(String o){return x->x.owner.equals(o);}static Predicate<ExcelModuleDemoToDoItem> thoseCompleted(boolean c){return x->x.complete==c;}static Predicate<ExcelModuleDemoToDoItem> thoseCategorised(String c,String s){return x->x.category.equals(c)&&x.subcategory.equals(s);}}} static class Predicates{@SafeVarargs static <T> Predicate<T> and(Predicate<T>...p){return x->{for(Predicate<T>q:p)if(!q.test(x))return false;return true;};}} static class Container{List<ExcelModuleDemoToDoItem>items=new ArrayList<>();<T>List<T>allMatches(Class<T>c,Predicate<T>p){List<T>r=new ArrayList<>();for(Object o:items){T t=c.cast(o);if(p.test(t))r.add(t);}return r;}} Container container=new Container();boolean complete=true;String category="WORK",subcategory="GENERAL";String currentUserName(){return "nimra";}boolean isComplete(){return complete;}String getCategory(){return category;}String getSubcategory(){return subcategory;}
 
// ORIGINAL CODESEARCHNET METHOD — START

@SuppressWarnings("unchecked")
    @Collection
    public List<ExcelModuleDemoToDoItem> getToDoItems() {
        return container.allMatches(ExcelModuleDemoToDoItem.class,
                Predicates.and(
                    ExcelModuleDemoToDoItem.Predicates.thoseOwnedBy(currentUserName()),
                    ExcelModuleDemoToDoItem.Predicates.thoseCompleted(isComplete()),
                    ExcelModuleDemoToDoItem.Predicates.thoseCategorised(getCategory(), getSubcategory())));
    }

// ORIGINAL CODESEARCHNET METHOD — END

 public static void main(String[] args) {
    method_4_isis_excel_gpt x = new method_4_isis_excel_gpt();
    x.container.items.add(new ExcelModuleDemoToDoItem("nimra", true, "WORK", "GENERAL"));
    x.container.items.add(new ExcelModuleDemoToDoItem("other", true, "WORK", "GENERAL"));
    System.out.println("METHOD: ExcelModuleDemoToDoItemRepository.getToDoItems");
    System.out.println("INPUT current user: nimra");
    System.out.println("INPUT repository item count: " + x.container.items.size());
    List<ExcelModuleDemoToDoItem> result = x.getToDoItems();
    System.out.println("RESULT filtered items: " + result);
    System.out.println("RESULT filtered item count: " + result.size());
    System.out.println("RESULT ownership filter applied: " + result.get(0).toString().startsWith("nimra"));
} }