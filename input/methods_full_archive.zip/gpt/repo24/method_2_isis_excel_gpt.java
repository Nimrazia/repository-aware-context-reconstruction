
















import java.io.*; import java.lang.annotation.*; import java.util.*;
public class method_2_isis_excel_gpt { static final String XLSX_SUFFIX=".xlsx"; @interface Nullable{} interface Function<F,T>{T apply(F f);} static class ImmutableSet<T> extends LinkedHashSet<T>{ImmutableSet(Collection<T>c){super(c);}} static class FluentIterable<T>{List<T> l; FluentIterable(List<T>x){l=x;} static <T> FluentIterable<T> from(List<T>x){return new FluentIterable<>(x);} <R> FluentIterable<R> transform(Function<T,R> f){List<R>r=new ArrayList<>();for(T x:l)r.add(f.apply(x));return new FluentIterable<>(r);} ImmutableSet<T> toSet(){return new ImmutableSet<>(l);}}
 static class WorksheetSpec{String sheetName; RowFactory<?> factory=new RowFactory<>(); WorksheetSpec(String n){sheetName=n;} String getSheetName(){return sheetName;} RowFactory<?> getFactory(){return factory;} static class RowFactory<T>{}} static class WorksheetContent{WorksheetSpec spec;List<?> objects;WorksheetContent(String n,List<?>o){spec=new WorksheetSpec(n);objects=o;}WorksheetSpec getSpec(){return spec;}List<?> getDomainObjects(){return objects;}}
 static class XSSFWorkbook{List<String>sheets=new ArrayList<>();void write(OutputStream o)throws IOException{o.write(String.join("\n",sheets).getBytes());}} static class ExcelConverter{} void appendSheet(XSSFWorkbook w,List<?>o,WorksheetSpec.RowFactory<?>f,String n){w.sheets.add(n+":"+o.size());}
 
// ORIGINAL CODESEARCHNET METHOD — START

File appendSheet(final List<WorksheetContent> worksheetContents) throws IOException {
        final ImmutableSet<String> worksheetNames = FluentIterable.from(worksheetContents)
                .transform(new Function<WorksheetContent, String>() {
                    @Nullable @Override public String apply(@Nullable final WorksheetContent worksheetContent) {
                        return worksheetContent.getSpec().getSheetName();
                    }
                }).toSet();
        if(worksheetNames.size() < worksheetContents.size()) {
            throw new IllegalArgumentException("Sheet names must have distinct names");
        }
        for (final String worksheetName : worksheetNames) {
            if(worksheetName.length() > 30) {
                throw new IllegalArgumentException(
                        String.format("Sheet name cannot exceed 30 characters (invalid name: '%s')",
                                worksheetName));
            }
        }

        final XSSFWorkbook workbook = new XSSFWorkbook();
        final File tempFile =
                File.createTempFile(ExcelConverter.class.getName(), UUID.randomUUID().toString() + XLSX_SUFFIX);
        final FileOutputStream fos = new FileOutputStream(tempFile);

        for (WorksheetContent worksheetContent : worksheetContents) {
            final WorksheetSpec spec = worksheetContent.getSpec();
            appendSheet(workbook, worksheetContent.getDomainObjects(), spec.getFactory(), spec.getSheetName());
        }
        workbook.write(fos);
        fos.close();
        return tempFile;
    }

// ORIGINAL CODESEARCHNET METHOD — END

 public static void main(String[] args) throws Exception {
    method_2_isis_excel_gpt x = new method_2_isis_excel_gpt();
    List<WorksheetContent> sheets = Arrays.asList(
        new WorksheetContent("Tasks", Arrays.asList("A", "B")),
        new WorksheetContent("Costs", Arrays.asList(1, 2, 3)));
    System.out.println("METHOD: ExcelConverter.appendSheet");
    System.out.println("INPUT sheet count: " + sheets.size());
    System.out.println("INPUT sheet names: [Tasks, Costs]");
    File f = x.appendSheet(sheets);
    System.out.println("RESULT workbook file: " + f.getAbsolutePath());
    System.out.println("RESULT workbook exists: " + f.exists());
    System.out.println("RESULT workbook byte length: " + f.length());
}
}