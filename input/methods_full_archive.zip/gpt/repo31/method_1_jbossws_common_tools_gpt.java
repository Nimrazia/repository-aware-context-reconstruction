import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class method_1_jbossws_common_tools_gpt {

   
   static class InstallModulesTask extends Task
   {
      private String targetDir;
      private FileSet fileset;


// ORIGINAL CODESEARCHNET METHOD — START

@Override
   public void execute() throws BuildException
   {
      try
      {
         DirectoryScanner dsc = fileset.getDirectoryScanner(getProject());
         File baseDir = dsc.getBasedir();
         String[] files = dsc.getIncludedFiles();
         for (int i = 0; i < files.length; i++)
         {
            String currentFile = files[i];
            File moduleXml = new File(baseDir, currentFile);
            String modulePath = currentFile.substring(0, currentFile.lastIndexOf(File.separator));
            File libDir = new File(targetDir, modulePath);
            File destFile = new File(targetDir, currentFile);
            System.out.println("Processing descriptor for module " + modulePath);
            System.out.println("* Source module descriptor: " + moduleXml);
            System.out.println("* Destination module descriptor: " + destFile);
            String c = readFileContents(moduleXml);
            if (libDir.exists())
            {
               String[] libs = libDir.list(new FilenameFilter()
               {
                  @Override
                  public boolean accept(File dir, String name)
                  {
                     return name.endsWith(".jar") || name.endsWith(".ear") || name.endsWith(".sar")
                           || name.endsWith(".war");
                  }
               });
               BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
               out.write(updateContents(c, libs));
               out.close();
            }
            else
            {
               libDir.mkdirs();
               BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
               out.write(c);
               out.close();
            }
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new BuildException(e);
      }
   }

// ORIGINAL CODESEARCHNET METHOD — END


      private static String readFileContents(File file) throws Exception
      {
         StringBuilder sb = new StringBuilder();
         BufferedReader in = null;
         try
         {
            in = new BufferedReader(new FileReader(file));
            String line;
            while ((line = in.readLine()) != null)
            {
               sb.append(line);
               sb.append("\n");
            }
         }
         finally
         {
            if (in != null)
            {
               try
               {
                  in.close();
               }
               catch (Exception e)
               {
                  
               }
            }
         }
         return sb.toString();
      }

      private static String updateContents(String contents, String[] libs)
      {
         StringBuilder sb = new StringBuilder();
         for (String f : libs) {
            sb.append("<resource-root path=\"");
            sb.append(f);
            sb.append("\"/>\n        ");
         }
         return contents.replaceFirst("<!-- Insert resources here -->", sb.toString());
      }

      public FileSet createFileset()
      {
         this.fileset = new FileSet();
         return fileset;
      }

      public void setTargetDir(String targetDir)
      {
         this.targetDir = targetDir;
      }
   }

   
   static class Task {
      private final Project project = new Project();
      public Project getProject() { return project; }
      public void execute() throws BuildException { }
   }

   static class Project { }

   static class BuildException extends RuntimeException {
      BuildException(Throwable cause) { super(cause); }
   }

   static class FileSet {
      private File directory;
      private final List<String> includedFiles = new ArrayList<>();
      public void setDir(File directory) { this.directory = directory; }
      public void addIncludedFile(String relativePath) { includedFiles.add(relativePath); }
      public DirectoryScanner getDirectoryScanner(Project project) {
         if (directory == null) throw new IllegalStateException("fileset directory was not configured");
         return new DirectoryScanner(directory, includedFiles.toArray(new String[0]));
      }
   }

   static class DirectoryScanner {
      private final File basedir;
      private final String[] includedFiles;
      DirectoryScanner(File basedir, String[] includedFiles) {
         this.basedir = basedir;
         this.includedFiles = includedFiles;
      }
      public File getBasedir() { return basedir; }
      public String[] getIncludedFiles() { return includedFiles.clone(); }
   }

   public static void main(String[] args) throws Exception {
      File work = Files.createTempDirectory("jbossws-install-modules-").toFile();
      File descriptors = new File(work, "descriptors");
      File target = new File(work, "target-modules");
      String relative = "org" + File.separator + "example" + File.separator + "main" + File.separator + "module.xml";
      File sourceDescriptor = new File(descriptors, relative);
      sourceDescriptor.getParentFile().mkdirs();
      Files.writeString(sourceDescriptor.toPath(), "<module>\n  <resources>\n    <!-- Insert resources here -->\n  </resources>\n</module>\n");

      File targetModuleDir = new File(target, "org" + File.separator + "example" + File.separator + "main");
      targetModuleDir.mkdirs();
      Files.writeString(new File(targetModuleDir, "example.jar").toPath(), "jar-placeholder");
      Files.writeString(new File(targetModuleDir, "example.war").toPath(), "war-placeholder");
      Files.writeString(new File(targetModuleDir, "notes.txt").toPath(), "must be ignored");

      InstallModulesTask task = new InstallModulesTask();
      task.setTargetDir(target.getAbsolutePath());
      FileSet fileSet = task.createFileset();
      fileSet.setDir(descriptors);
      fileSet.addIncludedFile(relative);
      task.execute();

      File generated = new File(target, relative);
      System.out.println("Generated descriptor exists: " + generated.isFile());
      System.out.println("Generated descriptor contents:\n" + Files.readString(generated.toPath()));
      deleteRecursively(work);
   }

   private static void deleteRecursively(File file) throws IOException {
      if (file.isDirectory()) {
         File[] children = file.listFiles();
         if (children != null) for (File child : children) deleteRecursively(child);
      }
      Files.deleteIfExists(file.toPath());
   }
}
