import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

public class method_2_jbossws_common_tools_gpt {

   
   static final class SecurityActions
   {
      static ClassLoader getContextClassLoader()
      {
         SecurityManager sm = System.getSecurityManager();
         if (sm == null)
         {
            return Thread.currentThread().getContextClassLoader();
         }
         else
         {
            return AccessController.doPrivileged(new PrivilegedAction<ClassLoader>() {
               public ClassLoader run()
               {
                  return Thread.currentThread().getContextClassLoader();
               }
            });
         }
      }


// ORIGINAL CODESEARCHNET METHOD — START

static ClassLoader setContextClassLoader(final ClassLoader cl)
   {
      if (System.getSecurityManager() == null)
      {
         ClassLoader result = Thread.currentThread().getContextClassLoader();
         if (cl != null)
            Thread.currentThread().setContextClassLoader(cl);
         return result;
      }
      else
      {
         try
         {
            return AccessController.doPrivileged(new PrivilegedExceptionAction<ClassLoader>() {
               public ClassLoader run() throws Exception
               {
                  try
                  {
                     ClassLoader result = Thread.currentThread().getContextClassLoader();
                     if (cl != null)
                        Thread.currentThread().setContextClassLoader(cl);
                     return result;
                  }
                  catch (Exception e)
                  {
                     throw e;
                  }
                  catch (Error e)
                  {
                     throw e;
                  }
                  catch (Throwable e)
                  {
                     throw new RuntimeException("Error setting context classloader", e);
                  }
               }
            });
         }
         catch (PrivilegedActionException e)
         {
            throw new RuntimeException("Error running privileged action", e.getCause());
         }
      }
   }

// ORIGINAL CODESEARCHNET METHOD — END


      static ClassLoader getClassLoader(final Class<?> clazz)
      {
         SecurityManager sm = System.getSecurityManager();
         if (sm == null)
         {
            return clazz.getClassLoader();
         }
         else
         {
            return AccessController.doPrivileged(new PrivilegedAction<ClassLoader>() {
               public ClassLoader run()
               {
                  return clazz.getClassLoader();
               }
            });
         }
      }
   }

   static final class DemonstrationClassLoader extends ClassLoader {
      private final String name;
      DemonstrationClassLoader(String name, ClassLoader parent) {
         super(parent);
         this.name = name;
      }
      @Override public String toString() { return "DemonstrationClassLoader[" + name + "]"; }
   }

   public static void main(String[] args) {
      ClassLoader initial = SecurityActions.getContextClassLoader();
      ClassLoader replacement = new DemonstrationClassLoader("repository-test", initial);
      ClassLoader returnedPrevious = SecurityActions.setContextClassLoader(replacement);
      System.out.println("Returned previous loader matches initial: " + (returnedPrevious == initial));
      System.out.println("Current loader is replacement: " + (SecurityActions.getContextClassLoader() == replacement));
      ClassLoader beforeNullCall = SecurityActions.setContextClassLoader(null);
      System.out.println("Null input leaves loader unchanged: " + (SecurityActions.getContextClassLoader() == replacement));
      System.out.println("Null call returned current loader: " + (beforeNullCall == replacement));
      SecurityActions.setContextClassLoader(initial);
      System.out.println("Original loader restored: " + (SecurityActions.getContextClassLoader() == initial));
      System.out.println("Class loader lookup available: " + SecurityActions.getClassLoader(method_2_jbossws_common_tools_gpt.class));
   }
}
