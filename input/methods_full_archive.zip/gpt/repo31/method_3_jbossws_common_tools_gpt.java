import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class method_3_jbossws_common_tools_gpt {

   
   static final class Log4jOutputStream extends OutputStream
   {
      protected static final String LINE_SEPERATOR = System.getProperty("line.separator");
      protected boolean hasBeenClosed = false;
      protected byte[] buf;
      protected int count;
      private int bufLength;
      public static final int DEFAULT_BUFFER_LENGTH = 2048;
      protected Category category;
      protected Priority priority;

      @SuppressWarnings("unused")
      private Log4jOutputStream()
      {
         
      }

      public Log4jOutputStream(Category cat, Priority priority) throws IllegalArgumentException
      {
         if (cat == null)
         {
            throw new IllegalArgumentException("cat == null");
         }
         if (priority == null)
         {
            throw new IllegalArgumentException("priority == null");
         }
         this.priority = priority;
         category = cat;
         bufLength = DEFAULT_BUFFER_LENGTH;
         buf = new byte[DEFAULT_BUFFER_LENGTH];
         count = 0;
      }

      public void close()
      {
         flush();
         hasBeenClosed = true;
      }

      public void write(final int b) throws IOException
      {
         if (hasBeenClosed)
         {
            throw new IOException("The stream has been closed.");
         }
         
         if (b == 0)
         {
            return;
         }

         
         if (count == bufLength)
         {
            
            final int newBufLength = bufLength + DEFAULT_BUFFER_LENGTH;
            final byte[] newBuf = new byte[newBufLength];

            System.arraycopy(buf, 0, newBuf, 0, bufLength);

            buf = newBuf;
            bufLength = newBufLength;
         }

         buf[count] = (byte)b;
         count++;
      }


// ORIGINAL CODESEARCHNET METHOD — START

public void flush()
   {
      if (count == 0)
      {
         return;
      }

      
      if (count == LINE_SEPERATOR.length())
      {
         if (((char)buf[0]) == LINE_SEPERATOR.charAt(0) && ((count == 1) || 
               ((count == 2) && ((char)buf[1]) == LINE_SEPERATOR.charAt(1))))
         {
            reset();
            return;
         }
      }

      final byte[] theBytes = new byte[count];

      System.arraycopy(buf, 0, theBytes, 0, count);

      category.log(priority, new String(theBytes));

      reset();
   }

// ORIGINAL CODESEARCHNET METHOD — END


      private void reset()
      {
         
         
         count = 0;
      }
   }

   
   static final class Priority {
      static final Priority INFO = new Priority("INFO");
      static final Priority WARN = new Priority("WARN");
      private final String name;
      private Priority(String name) { this.name = name; }
      @Override public String toString() { return name; }
   }

   static final class Category {
      private final String name;
      private final List<LogEvent> events = new ArrayList<>();
      Category(String name) { this.name = name; }
      void log(Priority priority, String message) {
         events.add(new LogEvent(priority, message));
         System.out.println("[" + priority + "] " + name + " - " + message);
      }
      List<LogEvent> getEvents() { return Collections.unmodifiableList(events); }
   }

   static final class LogEvent {
      final Priority priority;
      final String message;
      LogEvent(Priority priority, String message) {
         this.priority = priority;
         this.message = message;
      }
   }

   public static void main(String[] args) throws Exception {
      Category category = new Category("jbossws.command");
      Log4jOutputStream stream = new Log4jOutputStream(category, Priority.INFO);

      stream.write("descriptor installed".getBytes(StandardCharsets.UTF_8));
      stream.flush();
      System.out.println("Events after message flush: " + category.getEvents().size());
      System.out.println("Buffered byte count after reset: " + stream.count);

      stream.write(Log4jOutputStream.LINE_SEPERATOR.getBytes(StandardCharsets.UTF_8));
      stream.flush();
      System.out.println("Blank line was suppressed: " + (category.getEvents().size() == 1));

      stream.close();
      try {
         stream.write('X');
      } catch (IOException expected) {
         System.out.println("Closed-stream protection: " + expected.getMessage());
      }
   }
}
