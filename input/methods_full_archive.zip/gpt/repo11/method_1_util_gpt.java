import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class method_1_util_gpt {
    private static final Logger LOG = new Logger();


// ORIGINAL CODESEARCHNET METHOD — START

private static PoolingDataSource<PoolableConnection> getPoolingDataSource(final String url,
                                                                              final ConcurrentMap<String, String> properties,
                                                                              final ConnectionProperties poolSpec) {

        
        assert url != null : "The url cannot be null";
        assert properties != null : "The properties cannot be null";
        assert poolSpec != null : "The pol spec cannot be null";

        LOG.debug("Creating new pooled data source for '" + url + "'");

        
        final Properties props = new Properties();
        props.putAll(properties);

        
        final GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
        poolConfig.setMaxTotal(poolSpec.getMaxTotal());
        poolConfig.setMaxIdle(poolSpec.getMaxIdle());
        poolConfig.setMinIdle(poolSpec.getMinIdle());
        poolConfig.setMaxWaitMillis(poolSpec.getMaxWaitMillis());
        poolConfig.setTestOnCreate(poolSpec.isTestOnCreate());
        poolConfig.setTestOnBorrow(poolSpec.isTestOnBorrow());
        poolConfig.setTestOnReturn(poolSpec.isTestOnReturn());
        poolConfig.setTestWhileIdle(poolSpec.isTestWhileIdle());
        poolConfig.setTimeBetweenEvictionRunsMillis(poolSpec.getTimeBetweenEvictionRunsMillis());
        poolConfig.setNumTestsPerEvictionRun(poolSpec.getNumTestsPerEvictionRun());
        poolConfig.setMinEvictableIdleTimeMillis(poolSpec.getMinEvictableIdleTimeMillis());
        poolConfig.setSoftMinEvictableIdleTimeMillis(poolSpec.getSoftMinEvictableIdleTimeMillis());
        poolConfig.setLifo(poolSpec.isLifo());


        
        final ConnectionFactory connFactory = new DriverManagerConnectionFactory(url, props);
        final PoolableConnectionFactory poolConnFactory = new PoolableConnectionFactory(connFactory, null);
        poolConnFactory.setDefaultAutoCommit(poolSpec.isDefaultAutoCommit());
        poolConnFactory.setDefaultReadOnly(poolSpec.isDefaultReadOnly());
        poolConnFactory.setDefaultTransactionIsolation(poolSpec.getDefaultTransactionIsolation());
        poolConnFactory.setCacheState(poolSpec.isCacheState());
        poolConnFactory.setValidationQuery(poolSpec.getValidationQuery());
        poolConnFactory.setMaxConnLifetimeMillis(poolSpec.getMaxConnLifetimeMillis());
        final GenericObjectPool<PoolableConnection> connPool = new GenericObjectPool<>(poolConnFactory, poolConfig);
        poolConnFactory.setPool(connPool);

        
        return new PoolingDataSource<>(connPool);
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        ConcurrentMap<String,String> props = new ConcurrentHashMap<>();
        props.put("user", "demo");
        props.put("password", "secret");
        ConnectionProperties spec = ConnectionProperties.sample();
        PoolingDataSource<PoolableConnection> ds = getPoolingDataSource("jdbc:demo:memory", props, spec);
        System.out.println("Pool URL: " + ds.pool.factory.connectionFactory.url);
        System.out.println("Pool maxTotal/maxIdle/minIdle: " + ds.pool.config.maxTotal + "/" + ds.pool.config.maxIdle + "/" + ds.pool.config.minIdle);
        System.out.println("Validation query: " + ds.pool.factory.validationQuery);
        System.out.println("Connection properties copied: " + ds.pool.factory.connectionFactory.properties.size());
    }

    static final class Logger { void debug(String s) { System.out.println("DEBUG " + s); } }
    static class PoolableConnection {}
    interface ConnectionFactory {}
    static class DriverManagerConnectionFactory implements ConnectionFactory {
        final String url; final Properties properties;
        DriverManagerConnectionFactory(String url, Properties properties) { this.url=url; this.properties=new Properties(); this.properties.putAll(properties); }
    }
    static class PoolableConnectionFactory {
        final DriverManagerConnectionFactory connectionFactory; GenericObjectPool<PoolableConnection> pool;
        boolean defaultAutoCommit, defaultReadOnly, cacheState; int defaultTransactionIsolation; String validationQuery; long maxConnLifetimeMillis;
        PoolableConnectionFactory(ConnectionFactory cf, Object ignored) { this.connectionFactory=(DriverManagerConnectionFactory)cf; }
        void setDefaultAutoCommit(boolean v){defaultAutoCommit=v;} void setDefaultReadOnly(boolean v){defaultReadOnly=v;}
        void setDefaultTransactionIsolation(int v){defaultTransactionIsolation=v;} void setCacheState(boolean v){cacheState=v;}
        void setValidationQuery(String v){validationQuery=v;} void setMaxConnLifetimeMillis(long v){maxConnLifetimeMillis=v;}
        void setPool(GenericObjectPool<PoolableConnection> v){pool=v;}
    }
    static class GenericObjectPoolConfig {
        int maxTotal,maxIdle,minIdle,numTestsPerEvictionRun; long maxWaitMillis,timeBetweenEvictionRunsMillis,minEvictableIdleTimeMillis,softMinEvictableIdleTimeMillis;
        boolean testOnCreate,testOnBorrow,testOnReturn,testWhileIdle,lifo;
        void setMaxTotal(int v){maxTotal=v;} void setMaxIdle(int v){maxIdle=v;} void setMinIdle(int v){minIdle=v;}
        void setMaxWaitMillis(long v){maxWaitMillis=v;} void setTestOnCreate(boolean v){testOnCreate=v;} void setTestOnBorrow(boolean v){testOnBorrow=v;}
        void setTestOnReturn(boolean v){testOnReturn=v;} void setTestWhileIdle(boolean v){testWhileIdle=v;}
        void setTimeBetweenEvictionRunsMillis(long v){timeBetweenEvictionRunsMillis=v;} void setNumTestsPerEvictionRun(int v){numTestsPerEvictionRun=v;}
        void setMinEvictableIdleTimeMillis(long v){minEvictableIdleTimeMillis=v;} void setSoftMinEvictableIdleTimeMillis(long v){softMinEvictableIdleTimeMillis=v;}
        void setLifo(boolean v){lifo=v;}
    }
    static class GenericObjectPool<T> { final PoolableConnectionFactory factory; final GenericObjectPoolConfig config; GenericObjectPool(PoolableConnectionFactory f, GenericObjectPoolConfig c){factory=f;config=c;} }
    static class PoolingDataSource<T> { final GenericObjectPool<T> pool; PoolingDataSource(GenericObjectPool<T> p){pool=p;} }
    static class ConnectionProperties {
        int maxTotal=8,maxIdle=4,minIdle=1,numTestsPerEvictionRun=3,defaultTransactionIsolation=2; long maxWaitMillis=1000,timeBetweenEvictionRunsMillis=5000,minEvictableIdleTimeMillis=60000,softMinEvictableIdleTimeMillis=30000,maxConnLifetimeMillis=300000;
        boolean testOnCreate=true,testOnBorrow=true,testOnReturn=false,testWhileIdle=true,lifo=true,defaultAutoCommit=true,defaultReadOnly=false,cacheState=true; String validationQuery="SELECT 1";
        static ConnectionProperties sample(){return new ConnectionProperties();}
        int getMaxTotal(){return maxTotal;} int getMaxIdle(){return maxIdle;} int getMinIdle(){return minIdle;} long getMaxWaitMillis(){return maxWaitMillis;}
        boolean isTestOnCreate(){return testOnCreate;} boolean isTestOnBorrow(){return testOnBorrow;} boolean isTestOnReturn(){return testOnReturn;} boolean isTestWhileIdle(){return testWhileIdle;}
        long getTimeBetweenEvictionRunsMillis(){return timeBetweenEvictionRunsMillis;} int getNumTestsPerEvictionRun(){return numTestsPerEvictionRun;}
        long getMinEvictableIdleTimeMillis(){return minEvictableIdleTimeMillis;} long getSoftMinEvictableIdleTimeMillis(){return softMinEvictableIdleTimeMillis;}
        boolean isLifo(){return lifo;} boolean isDefaultAutoCommit(){return defaultAutoCommit;} boolean isDefaultReadOnly(){return defaultReadOnly;}
        int getDefaultTransactionIsolation(){return defaultTransactionIsolation;} boolean isCacheState(){return cacheState;} String getValidationQuery(){return validationQuery;} long getMaxConnLifetimeMillis(){return maxConnLifetimeMillis;}
    }
}
