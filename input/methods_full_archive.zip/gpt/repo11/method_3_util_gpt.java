public class method_3_util_gpt {
    private static final Logger LOG=new Logger();
    private static final java.util.Map<String,Object> REGISTRY=new java.util.HashMap<>();


// ORIGINAL CODESEARCHNET METHOD — START

public static DataSource getDataSource(final String jndiName)
            throws FactoryException {

        Validate.notBlank(jndiName, "The validated character sequence 'jndiName' is null or empty");

        

        try {
            
            final Context context = new InitialContext();

            
            final Object namedObject = context.lookup(jndiName);
            if (DataSource.class.isInstance(namedObject)) {
                final DataSource dataSource = (DataSource) context.lookup(jndiName);
                context.close();

                return dataSource;
            } else {
                final String error = "The JNDI name '" + jndiName + "' does not reference a SQL DataSource."
                        + " This is a configuration issue.";
                LOG.warn(error);
                throw new FactoryException(error);
            }
        } catch (NamingException e) {
            final String error = "Error retrieving JDBC date source from JNDI: " + jndiName;
            LOG.warn(error);
            throw new FactoryException(error, e);
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) throws Exception {
        REGISTRY.put("java:/jdbc/demo", new DemoDataSource("demo-pool"));
        DataSource ds=getDataSource("java:/jdbc/demo");
        System.out.println("Resolved data source: "+ds);
        REGISTRY.put("java:/not-ds", "plain string");
        try { getDataSource("java:/not-ds"); } catch(FactoryException e) { System.out.println("Wrong-type branch: "+e.getMessage()); }
        try { getDataSource("java:/missing"); } catch(FactoryException e) { System.out.println("Missing-name branch: "+e.getMessage()); }
    }
    interface DataSource {}
    static final class DemoDataSource implements DataSource { final String name; DemoDataSource(String n){name=n;} public String toString(){return name;} }
    interface Context { Object lookup(String n)throws NamingException; void close()throws NamingException; }
    static final class InitialContext implements Context { public Object lookup(String n)throws NamingException{if(!REGISTRY.containsKey(n))throw new NamingException("Name not bound: "+n);return REGISTRY.get(n);} public void close(){} }
    static class NamingException extends Exception { NamingException(String m){super(m);} }
    static class FactoryException extends Exception { FactoryException(String m){super(m);} FactoryException(String m,Throwable t){super(m,t);} }
    static class Validate { static String notBlank(String s,String m){if(s==null)throw new NullPointerException(m);if(s.trim().isEmpty())throw new IllegalArgumentException(m);return s;} }
    static class Logger { void warn(String s){System.out.println("WARN "+s);} }
}
