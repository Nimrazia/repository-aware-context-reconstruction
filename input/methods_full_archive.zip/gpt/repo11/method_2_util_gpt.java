import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

public class method_2_util_gpt {
    private static final String KEY_DRIVER = "driver";
    private static final String KEY_URL = "url";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_MAX_TOTAL = "max_total";
    private static final String KEY_MAX_IDLE = "max_idle";
    private static final String KEY_MIN_IDLE = "min_idle";
    private static final String KEY_MAX_WAIT_MILLIS = "max_wait_millis";
    private static final String KEY_TEST_ON_CREATE = "test_on_create";
    private static final String KEY_TEST_ON_BORROW = "test_on_borrow";
    private static final String KEY_TEST_ON_RETURN = "test_on_return";
    private static final String KEY_TEST_WHILE_IDLE = "test_while_idle";
    private static final String KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS = "time_between_eviction_runs_millis";
    private static final String KEY_NUM_TESTS_PER_EVICTION_RUN = "num_tests_per_eviction_run";
    private static final String KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS = "min_evictable_idle_time_millis";
    private static final String KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS = "soft_min_evictable_idle_time_millis";
    private static final String KEY_LIFO = "lifo";
    private static final String KEY_AUTO_COMMIT = "auto_commit";
    private static final String KEY_READ_ONLY = "read_only";
    private static final String KEY_TRANSACTION_ISOLATION = "transaction_isolation";
    private static final String KEY_CACHE_STATE = "cache_state";
    private static final String KEY_VALIDATION_QUERY = "validation_query";
    private static final String KEY_MAX_CONN_LIFETIME_MILLIS = "max_conn_lifetime_millis";
    private static final String DEFAULT_DRIVER = null, DEFAULT_URL = null, DEFAULT_USERNAME = "", DEFAULT_PASSWORD = "", DEFAULT_VALIDATION_QUERY = "SELECT 1";
    private static final int DEFAULT_MAX_TOTAL=8, DEFAULT_MAX_IDLE=4, DEFAULT_MIN_IDLE=1, DEFAULT_NUM_TESTS_PER_EVICITON_RUN=3, DEFAULT_TRANSACTION_ISOLATION=2;
    private static final long DEFAULT_MAX_WAIT_MILLIS=1000, DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS=5000, DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS=60000, DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS=30000, DEFAULT_MAX_CONN_LIFETIME_MILLIS=300000;
    private static final boolean DEFAULT_TEST_ON_CREATE=false, DEFAULT_TEST_ON_BORROW=true, DEFAULT_TEST_ON_RETURN=false, DEFAULT_TEST_WHILE_IDLE=true, DEFAULT_LIFO=true, DEFAULT_AUTO_COMMIT=true, DEFAULT_READ_ONLY=false, DEFAULT_CACHE_STATE=true;
    private static final java.util.List<String> LOG = new java.util.ArrayList<>();
    private static void logValue(String key,String value){LOG.add(key+"="+value);}
    private static void logDefault(String key,String value){LOG.add(key+" default="+value);}
    private static void logDefault(String key,String supplied,String reason,String value){LOG.add(key+" supplied="+supplied+" ("+reason+") default="+value);}


// ORIGINAL CODESEARCHNET METHOD — START

@SuppressWarnings({"PMD.ExcessiveMethodLength", "PMD.NPathComplexity", "PMD.NcssMethodCount", "PMD.CyclomaticComplexity", "PMD.StdCyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity"})
    
    public static ConnectionProperties build(final Map<String, String> properties) {

        Validate.notNull(properties, "The validated object 'properties' is null");

        final ConnectionProperties connProps = new ConnectionProperties();
        String tmp = properties.get(KEY_DRIVER);
        if (StringUtils.isNotEmpty(tmp)) { 
            connProps.setDriver(tmp);
            logValue(KEY_DRIVER, tmp);
        } else {
            connProps.setDriver(DEFAULT_DRIVER);
            logDefault(KEY_DRIVER, DEFAULT_DRIVER);
        }

        tmp = properties.get(KEY_URL);
        if (StringUtils.isNotEmpty(tmp)) { 
            connProps.setUrl(tmp);
            logValue(KEY_URL, tmp);
        } else {
            connProps.setUrl(DEFAULT_URL);
            logDefault(KEY_URL, DEFAULT_URL);
        }

        tmp = properties.get(KEY_USERNAME);
        if (tmp == null) { 
            connProps.setUsername(DEFAULT_USERNAME);
            logDefault(KEY_USERNAME, DEFAULT_USERNAME);
        } else {
            connProps.setUsername(tmp);
            logValue(KEY_USERNAME, tmp);
        }

        tmp = properties.get(KEY_PASSWORD);
        if (tmp == null) { 
            connProps.setPassword(DEFAULT_PASSWORD);
            logDefault(KEY_PASSWORD, DEFAULT_PASSWORD);
        } else {
            connProps.setPassword(tmp);
            logValue(KEY_PASSWORD, tmp);
        }

        tmp = properties.get(KEY_MAX_TOTAL);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMaxTotal(Integer.decode(tmp));
                logValue(KEY_MAX_TOTAL, tmp);
            } else {
                connProps.setMaxTotal(DEFAULT_MAX_TOTAL);
                logDefault(KEY_MAX_TOTAL, tmp, "not numeric", String.valueOf(DEFAULT_MAX_TOTAL));
            }
        } else {
            connProps.setMaxTotal(DEFAULT_MAX_TOTAL);
            logDefault(KEY_MAX_TOTAL, String.valueOf(DEFAULT_MAX_TOTAL));
        }

        tmp = properties.get(KEY_MAX_IDLE);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMaxIdle(Integer.decode(tmp));
                logValue(KEY_MAX_IDLE, tmp);
            } else {
                connProps.setMaxIdle(DEFAULT_MAX_IDLE);
                logDefault(KEY_MAX_IDLE, tmp, "not numeric", String.valueOf(DEFAULT_MAX_IDLE));
            }
        } else {
            connProps.setMaxIdle(DEFAULT_MAX_IDLE);
            logDefault(KEY_MAX_IDLE, String.valueOf(DEFAULT_MAX_IDLE));
        }

        tmp = properties.get(KEY_MIN_IDLE);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMinIdle(Integer.decode(tmp));
                logValue(KEY_MIN_IDLE, tmp);
            } else {
                connProps.setMinIdle(DEFAULT_MIN_IDLE);
                logDefault(KEY_MIN_IDLE, tmp, "not numeric", String.valueOf(DEFAULT_MIN_IDLE));
            }
        } else {
            connProps.setMinIdle(DEFAULT_MIN_IDLE);
            logDefault(KEY_MIN_IDLE, String.valueOf(DEFAULT_MIN_IDLE));
        }

        tmp = properties.get(KEY_MAX_WAIT_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMaxWaitMillis(Long.decode(tmp));
                logValue(KEY_MAX_WAIT_MILLIS, tmp);
            } else {
                connProps.setMaxWaitMillis(DEFAULT_MAX_WAIT_MILLIS);
                logDefault(KEY_MAX_WAIT_MILLIS, tmp, "not numeric", String.valueOf(DEFAULT_MAX_WAIT_MILLIS));
            }
        } else {
            connProps.setMaxWaitMillis(DEFAULT_MAX_WAIT_MILLIS);
            logDefault(KEY_MAX_WAIT_MILLIS, String.valueOf(DEFAULT_MAX_WAIT_MILLIS));
        }

        tmp = properties.get(KEY_TEST_ON_CREATE);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setTestOnCreate(Boolean.parseBoolean(tmp));
            logValue(KEY_TEST_ON_CREATE, tmp);
        } else {
            connProps.setTestOnCreate(DEFAULT_TEST_ON_CREATE);
            logDefault(KEY_TEST_ON_CREATE, String.valueOf(DEFAULT_TEST_ON_CREATE));
        }

        tmp = properties.get(KEY_TEST_ON_BORROW);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setTestOnBorrow(Boolean.parseBoolean(tmp));
            logValue(KEY_TEST_ON_BORROW, tmp);
        } else {
            connProps.setTestOnBorrow(DEFAULT_TEST_ON_BORROW);
            logDefault(KEY_TEST_ON_BORROW, String.valueOf(DEFAULT_TEST_ON_BORROW));
        }

        tmp = properties.get(KEY_TEST_ON_RETURN);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setTestOnReturn(Boolean.parseBoolean(tmp));
            logValue(KEY_TEST_ON_RETURN, tmp);
        } else {
            connProps.setTestOnReturn(DEFAULT_TEST_ON_RETURN);
            logDefault(KEY_TEST_ON_RETURN, String.valueOf(DEFAULT_TEST_ON_RETURN));
        }

        tmp = properties.get(KEY_TEST_WHILE_IDLE);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setTestWhileIdle(Boolean.parseBoolean(tmp));
            logValue(KEY_TEST_WHILE_IDLE, tmp);
        } else {
            connProps.setTestWhileIdle(DEFAULT_TEST_WHILE_IDLE);
            logDefault(KEY_TEST_WHILE_IDLE, String.valueOf(DEFAULT_TEST_WHILE_IDLE));
        }

        tmp = properties.get(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setTimeBetweenEvictionRunsMillis(Long.decode(tmp));
                logValue(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS, tmp);
            } else {
                connProps.setTimeBetweenEvictionRunsMillis(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
                logDefault(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS, tmp, "not numeric",
                        String.valueOf(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
            }
        } else {
            connProps.setTimeBetweenEvictionRunsMillis(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
            logDefault(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS,
                    String.valueOf(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
        }

        tmp = properties.get(KEY_NUM_TESTS_PER_EVICTION_RUN);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setNumTestsPerEvictionRun(Integer.decode(tmp));
                logValue(KEY_NUM_TESTS_PER_EVICTION_RUN, tmp);
            } else {
                connProps.setNumTestsPerEvictionRun(DEFAULT_NUM_TESTS_PER_EVICITON_RUN);
                logDefault(KEY_NUM_TESTS_PER_EVICTION_RUN, tmp, "not numeric",
                        String.valueOf(DEFAULT_NUM_TESTS_PER_EVICITON_RUN));
            }
        } else {
            connProps.setNumTestsPerEvictionRun(DEFAULT_NUM_TESTS_PER_EVICITON_RUN);
            logDefault(KEY_NUM_TESTS_PER_EVICTION_RUN, String.valueOf(DEFAULT_NUM_TESTS_PER_EVICITON_RUN));
        }

        tmp = properties.get(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMinEvictableIdleTimeMillis(Long.decode(tmp));
                logValue(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp);
            } else {
                connProps.setMinEvictableIdleTimeMillis(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
                logDefault(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp, "not numeric",
                        String.valueOf(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
            }
        } else {
            connProps.setMinEvictableIdleTimeMillis(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
            logDefault(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, String.valueOf(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
        }

        tmp = properties.get(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setSoftMinEvictableIdleTimeMillis(Long.decode(tmp));
                logValue(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp);
            } else {
                connProps.setSoftMinEvictableIdleTimeMillis(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
                logDefault(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp, "not numeric",
                        String.valueOf(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
            }
        } else {
            connProps.setSoftMinEvictableIdleTimeMillis(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
            logDefault(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS,
                    String.valueOf(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
        }

        tmp = properties.get(KEY_LIFO);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setLifo(Boolean.parseBoolean(tmp));
            logValue(KEY_LIFO, tmp);
        } else {
            connProps.setLifo(DEFAULT_LIFO);
            logDefault(KEY_LIFO, String.valueOf(DEFAULT_LIFO));
        }

        tmp = properties.get(KEY_AUTO_COMMIT);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setDefaultAutoCommit(Boolean.parseBoolean(tmp));
            logValue(KEY_AUTO_COMMIT, tmp);
        } else {
            connProps.setDefaultAutoCommit(DEFAULT_AUTO_COMMIT);
            logDefault(KEY_AUTO_COMMIT, String.valueOf(DEFAULT_AUTO_COMMIT));
        }

        tmp = properties.get(KEY_READ_ONLY);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setDefaultReadOnly(Boolean.parseBoolean(tmp));
            logValue(KEY_READ_ONLY, tmp);
        } else {
            connProps.setDefaultReadOnly(DEFAULT_READ_ONLY);
            logDefault(KEY_READ_ONLY, String.valueOf(DEFAULT_READ_ONLY));
        }

        tmp = properties.get(KEY_TRANSACTION_ISOLATION);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setDefaultTransactionIsolation(Integer.decode(tmp));
                logValue(KEY_TRANSACTION_ISOLATION, tmp);
            } else {
                connProps.setDefaultTransactionIsolation(DEFAULT_TRANSACTION_ISOLATION);
                logDefault(KEY_TRANSACTION_ISOLATION, tmp, "not numeric",
                        String.valueOf(DEFAULT_TRANSACTION_ISOLATION));
            }
        } else {
            connProps.setDefaultTransactionIsolation(DEFAULT_TRANSACTION_ISOLATION);
            logDefault(KEY_TRANSACTION_ISOLATION, String.valueOf(DEFAULT_TRANSACTION_ISOLATION));
        }

        tmp = properties.get(KEY_CACHE_STATE);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setCacheState(Boolean.parseBoolean(tmp));
            logValue(KEY_CACHE_STATE, tmp);
        } else {
            connProps.setCacheState(DEFAULT_CACHE_STATE);
            logDefault(KEY_CACHE_STATE, String.valueOf(DEFAULT_CACHE_STATE));
        }

        tmp = properties.get(KEY_VALIDATION_QUERY);
        if (StringUtils.isNotEmpty(tmp)) {
            connProps.setValidationQuery(tmp);
            logValue(KEY_VALIDATION_QUERY, tmp);
        } else {
            connProps.setValidationQuery(DEFAULT_VALIDATION_QUERY);
            logDefault(KEY_VALIDATION_QUERY, DEFAULT_VALIDATION_QUERY);
        }

        tmp = properties.get(KEY_MAX_CONN_LIFETIME_MILLIS);
        if (StringUtils.isNotEmpty(tmp)) {
            if (StringUtils.isNumeric(tmp)) {
                connProps.setMaxConnLifetimeMillis(Long.decode(tmp));
                logValue(KEY_MAX_CONN_LIFETIME_MILLIS, tmp);
            } else {
                connProps.setMaxConnLifetimeMillis(DEFAULT_MAX_CONN_LIFETIME_MILLIS);
                logDefault(KEY_MAX_CONN_LIFETIME_MILLIS, tmp, "not numeric",
                        String.valueOf(DEFAULT_MAX_CONN_LIFETIME_MILLIS));
            }
        } else {
            connProps.setMaxConnLifetimeMillis(DEFAULT_MAX_CONN_LIFETIME_MILLIS);
            logDefault(KEY_MAX_CONN_LIFETIME_MILLIS, String.valueOf(DEFAULT_MAX_CONN_LIFETIME_MILLIS));
        }

        
        
        
        
        
        final Map<String, String> tempMap = new ConcurrentHashMap<>();
        for (final Map.Entry<String, String> entry : properties.entrySet()) {
            final String key = entry.getKey();
            final String value = entry.getValue();

            if (value != null) {
                tempMap.put(key, value);
            }
        }
        connProps.setAdditionalProperties(tempMap);

        return connProps;
    }

// ORIGINAL CODESEARCHNET METHOD — END


    public static void main(String[] args) {
        Map<String,String> p = new HashMap<>();
        p.put(KEY_DRIVER,"org.example.Driver"); p.put(KEY_URL,"jdbc:example:test"); p.put(KEY_MAX_TOTAL,"12");
        p.put(KEY_MAX_IDLE,"not-a-number"); p.put(KEY_TEST_ON_BORROW,"false"); p.put(KEY_VALIDATION_QUERY,"SELECT 42"); p.put("custom.flag","enabled");
        ConnectionProperties result=build(p);
        System.out.println(result);
        System.out.println("Max idle defaulted after invalid input: "+result.maxIdle);
        System.out.println("Additional custom flag: "+result.additionalProperties.get("custom.flag"));
        System.out.println("Configuration decisions logged: "+LOG.size());
    }
    static class Validate { static <T>T notNull(T v,String m){if(v==null)throw new NullPointerException(m);return v;} }
    static class StringUtils { static boolean isNotEmpty(String s){return s!=null&&!s.isEmpty();} static boolean isNumeric(String s){if(s==null||s.isEmpty())return false; for(int i=0;i<s.length();i++)if(!Character.isDigit(s.charAt(i)))return false; return true;} }
    static class ConnectionProperties {
        String driver,url,username,password,validationQuery; int maxTotal,maxIdle,minIdle,numTestsPerEvictionRun,defaultTransactionIsolation; long maxWaitMillis,timeBetweenEvictionRunsMillis,minEvictableIdleTimeMillis,softMinEvictableIdleTimeMillis,maxConnLifetimeMillis; boolean testOnCreate,testOnBorrow,testOnReturn,testWhileIdle,lifo,defaultAutoCommit,defaultReadOnly,cacheState; Map<String,String> additionalProperties;
        void setDriver(String v){driver=v;} void setUrl(String v){url=v;} void setUsername(String v){username=v;} void setPassword(String v){password=v;}
        void setMaxTotal(int v){maxTotal=v;} void setMaxIdle(int v){maxIdle=v;} void setMinIdle(int v){minIdle=v;} void setMaxWaitMillis(long v){maxWaitMillis=v;}
        void setTestOnCreate(boolean v){testOnCreate=v;} void setTestOnBorrow(boolean v){testOnBorrow=v;} void setTestOnReturn(boolean v){testOnReturn=v;} void setTestWhileIdle(boolean v){testWhileIdle=v;}
        void setTimeBetweenEvictionRunsMillis(long v){timeBetweenEvictionRunsMillis=v;} void setNumTestsPerEvictionRun(int v){numTestsPerEvictionRun=v;}
        void setMinEvictableIdleTimeMillis(long v){minEvictableIdleTimeMillis=v;} void setSoftMinEvictableIdleTimeMillis(long v){softMinEvictableIdleTimeMillis=v;}
        void setLifo(boolean v){lifo=v;} void setDefaultAutoCommit(boolean v){defaultAutoCommit=v;} void setDefaultReadOnly(boolean v){defaultReadOnly=v;}
        void setDefaultTransactionIsolation(int v){defaultTransactionIsolation=v;} void setCacheState(boolean v){cacheState=v;} void setValidationQuery(String v){validationQuery=v;}
        void setMaxConnLifetimeMillis(long v){maxConnLifetimeMillis=v;} void setAdditionalProperties(Map<String,String> v){additionalProperties=v;}
        public String toString(){return "ConnectionProperties{driver="+driver+", url="+url+", maxTotal="+maxTotal+", maxIdle="+maxIdle+", validationQuery="+validationQuery+", extras="+additionalProperties.size()+"}";}
    }
}
