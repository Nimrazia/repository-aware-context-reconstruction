import java.lang.annotation.*;import java.util.regex.*;
public class method_4_quality_check_gpt{@Retention(RetentionPolicy.RUNTIME)@interface Nonnull{}static class Check{static<T>T notNull(T x,String n){if(x==null)throw new NullPointerException(n);return x;}static String notEmpty(String x,String n){if(x.isEmpty())throw new IllegalArgumentException(n);return x;}static void stateIsTrue(boolean b,String m,Object...a){if(!b)throw new IllegalArgumentException(String.format(m,a));}}enum AccessorPrefix{GET("get"),IS("is");private final String p;AccessorPrefix(String p){this.p=p;}String getPrefix(){return p;}}static class MethodUtil{static final Pattern PATTERN=Pattern.compile("[A-Za-z][A-Za-z0-9_]*");

// ORIGINAL CODESEARCHNET METHOD — START

public static String determineAccessorName(@Nonnull final AccessorPrefix prefix, @Nonnull final String fieldName) {
		Check.notNull(prefix, "prefix");
		Check.notEmpty(fieldName, "fieldName");
		final Matcher m = PATTERN.matcher(fieldName);
		Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
		final String name = m.group();
		return prefix.getPrefix() + name.substring(0, 1).toUpperCase() + name.substring(1);
	}

// ORIGINAL CODESEARCHNET METHOD — END

}public static void main(String[]a){System.out.println(MethodUtil.determineAccessorName(AccessorPrefix.GET,"name"));}}
