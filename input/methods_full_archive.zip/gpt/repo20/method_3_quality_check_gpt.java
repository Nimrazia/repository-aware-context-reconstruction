import java.math.*;
public class method_3_quality_check_gpt{
 static class IllegalNumberArgumentException extends IllegalArgumentException{IllegalNumberArgumentException(String m){super(m);}}static class NumberInRange{static void checkByte(Number n){if(n.longValue()<Byte.MIN_VALUE||n.longValue()>Byte.MAX_VALUE)throw new IllegalNumberArgumentException("byte range");}static void checkDouble(Number n){}static void checkFloat(Number n){}static void checkInteger(Number n){if(new BigInteger(n.toString()).bitLength()>31)throw new IllegalNumberArgumentException("int range");}static void checkLong(Number n){}static void checkShort(Number n){if(n.longValue()<Short.MIN_VALUE||n.longValue()>Short.MAX_VALUE)throw new IllegalNumberArgumentException("short range");}}
 static class Check{

// ORIGINAL CODESEARCHNET METHOD — START

private static <T> Number checkNumberInRange(final String value, final Class<T> type) {
		final Number ret;
		if (type.equals(Byte.class)) {
			final Number number = new BigInteger(value);
			NumberInRange.checkByte(number);
			ret = Byte.valueOf(number.byteValue());
		} else if (type.equals(Double.class)) {
			final Number number = new BigDecimal(value);
			NumberInRange.checkDouble(number);
			ret = Double.valueOf(number.doubleValue());
		} else if (type.equals(Float.class)) {
			final Number number = new BigDecimal(value);
			NumberInRange.checkFloat(number);
			ret = Float.valueOf(number.floatValue());
		} else if (type.equals(Integer.class)) {
			final Number number = new BigInteger(value);
			NumberInRange.checkInteger(number);
			ret = Integer.valueOf(number.intValue());
		} else if (type.equals(Long.class)) {
			final Number number = new BigInteger(value);
			NumberInRange.checkLong(number);
			ret = Long.valueOf(number.longValue());
		} else if (type.equals(Short.class)) {
			final Number number = new BigInteger(value);
			NumberInRange.checkShort(number);
			ret = Short.valueOf(number.shortValue());
		} else if (type.equals(BigInteger.class)) {
			ret = new BigInteger(value);
		} else if (type.equals(BigDecimal.class)) {
			ret = new BigDecimal(value);
		} else {
			throw new IllegalNumberArgumentException("Return value is no known subclass of 'java.lang.Number': " + type.getName());
		}
		return ret;
	}

// ORIGINAL CODESEARCHNET METHOD — END

 }
 public static void main(String[]a){System.out.println(Check.checkNumberInRange("127",Byte.class));System.out.println(Check.checkNumberInRange("12.50",BigDecimal.class));}
}
