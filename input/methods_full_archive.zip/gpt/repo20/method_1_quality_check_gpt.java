import java.lang.annotation.*;import java.util.*;
public class method_1_quality_check_gpt{
 @Retention(RetentionPolicy.RUNTIME)@interface Nonnull{}
 static class Check{static<T>T notNull(T v,String n){if(v==null)throw new NullPointerException(n);return v;}static<T>List<T> notEmpty(List<T>v,String n){if(v.isEmpty())throw new IllegalArgumentException(n);return v;}static void stateIsTrue(boolean b,String m,Object...a){if(!b)throw new IllegalStateException(String.format(m,a));}}
 static class TypeDeclaration{}static class ClassOrInterfaceDeclaration extends TypeDeclaration{String name;List<Object>members=new ArrayList<>();List<Object>annotations=new ArrayList<>();ClassOrInterfaceDeclaration(String n){name=n;}String getName(){return name;}List<Object>getMembers(){return members;}List<Object>getAnnotations(){return annotations;}}
 static class NameExpr{String s;NameExpr(String s){this.s=s;}public String toString(){return s;}}static class PackageDeclaration{String n;PackageDeclaration(String n){this.n=n;}NameExpr getName(){return new NameExpr(n);}}
 static class CompilationUnit{List<TypeDeclaration>types=new ArrayList<>();List<String>imports=new ArrayList<>();PackageDeclaration pkg;List<TypeDeclaration>getTypes(){return types;}List<String>getImports(){return imports;}PackageDeclaration getPackage(){return pkg;}}
 static class Imports{List<String>x;Imports(List<String>x){this.x=x;}List<String>asList(){return x;}}static class Package{static final Package UNDEFINED=new Package("");String n;Package(String n){this.n=n;}public String toString(){return n;}}static class Annotation{}static class Interface{}static class Method{List<String>a=new ArrayList<>();List<String>getAttributes(){return a;}}
 interface InterfaceAnalysis{}static class ImmutableInterfaceAnalysis implements InterfaceAnalysis{String name;List<Method>methods;ImmutableInterfaceAnalysis(List<Annotation>a,List<Interface>e,List<String>i,String n,List<Method>m,Package p){name=n;methods=m;}public String toString(){return "InterfaceAnalysis{"+name+", methods="+methods.size()+"}";}}
 static class SourceCodeReader{static CompilationUnit parse(String c){CompilationUnit u=new CompilationUnit();String p=c.contains("package ")?c.substring(c.indexOf("package ")+8,c.indexOf(';')).trim():"";if(!p.isEmpty())u.pkg=new PackageDeclaration(p);String n=c.substring(c.indexOf("interface ")+10).split("[^A-Za-z0-9_]")[0];ClassOrInterfaceDeclaration d=new ClassOrInterfaceDeclaration(n);for(String s:c.split(";"))if(s.contains("()"))d.members.add(new Object());u.types.add(d);return u;}static Imports findImports(List<String>x){return new Imports(x);}static List<Annotation>findAnnotations(List<Object>x,Imports i){return new ArrayList<>();}static List<Method>findMethods(List<Object>x,Imports i){List<Method>m=new ArrayList<>();for(Object o:x)m.add(new Method());return m;}static List<Interface>findExtends(ClassOrInterfaceDeclaration t){return new ArrayList<>();}}
 static final class InterfaceAnalyzer{private static boolean hasPossibleMutatingMethods(List<Method>m){for(Method x:m)if(!x.getAttributes().isEmpty())return true;return false;}

// ORIGINAL CODESEARCHNET METHOD — START

@Nonnull
	public static InterfaceAnalysis analyze(@Nonnull final String code) {
		Check.notNull(code, "code");

		final CompilationUnit unit = Check.notNull(SourceCodeReader.parse(code), "compilationUnit");
		final List<TypeDeclaration> types = Check.notEmpty(unit.getTypes(), "typeDeclarations");
		Check.stateIsTrue(types.size() == 1, "only one interface declaration per analysis is supported");

		final ClassOrInterfaceDeclaration type = (ClassOrInterfaceDeclaration) types.get(0);

		final Imports imports = SourceCodeReader.findImports(unit.getImports());
		final Package pkg = unit.getPackage() != null ? new Package(unit.getPackage().getName().toString()) : Package.UNDEFINED;
		final List<Annotation> annotations = SourceCodeReader.findAnnotations(type.getAnnotations(), imports);
		final List<Method> methods = SourceCodeReader.findMethods(type.getMembers(), imports);
		Check.stateIsTrue(!hasPossibleMutatingMethods(methods), "The passed interface '%s' seems to have mutating methods", type.getName());
		final List<Interface> extendsInterfaces = SourceCodeReader.findExtends(type);
		final String interfaceName = type.getName();
		return new ImmutableInterfaceAnalysis(annotations, extendsInterfaces, imports.asList(), interfaceName, methods, pkg);
	}

// ORIGINAL CODESEARCHNET METHOD — END

 }
 public static void main(String[]a){System.out.println(InterfaceAnalyzer.analyze("package demo; interface Person { String getName(); }"));}
}
