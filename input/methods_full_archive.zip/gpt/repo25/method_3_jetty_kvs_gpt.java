
















import java.util.*; abstract class Base3<T> { protected abstract Object save(T session, Object version, boolean activateAfterSave); }
public class method_3_jetty_kvs_gpt extends Base3<method_3_jetty_kvs_gpt.NoSqlSession> { static class Logger{void debug(String s){System.out.println("DEBUG "+s);}void warn(Object s){System.out.println("WARN "+s);}} static class TranscoderException extends RuntimeException{TranscoderException(String s){super(s);}} interface ISerializableSession{long getVersion();void setVersion(long v);boolean isValid();String getId();String getDomain();String getPath();void setDomain(String s);void setPath(String s);long getCreationTime();long getAccessed();Enumeration<String> getAttributeNames();Object getAttribute(String n);Map<String,Object> getAttributeMap();} static class Data implements ISerializableSession{long version=1,created=1,accessed=2;boolean valid=true;String id,domain="*",path="*";Map<String,Object>attrs=new LinkedHashMap<>();Data(String i){id=i;}public long getVersion(){return version;}public void setVersion(long v){version=v;}public boolean isValid(){return valid;}public String getId(){return id;}public String getDomain(){return domain;}public String getPath(){return path;}public void setDomain(String s){domain=s;}public void setPath(String s){path=s;}public long getCreationTime(){return created;}public long getAccessed(){return accessed;}public Enumeration<String> getAttributeNames(){return Collections.enumeration(attrs.keySet());}public Object getAttribute(String n){return attrs.get(n);}public Map<String,Object> getAttributeMap(){return attrs;}public String toString(){return id+attrs;}} static class NoSqlSession{String id;boolean valid=true;Map<String,Object>attrs=new LinkedHashMap<>();NoSqlSession(String i){id=i;}String getClusterId(){return id;}String getId(){return id;}boolean isValid(){return valid;}void invalidate(){valid=false;}void willPassivate(){}void didActivate(){}Set<String>getNames(){return new LinkedHashSet<>(attrs.keySet());}void doPutOrRemove(String n,Object v){if(v==null)attrs.remove(n);else attrs.put(n,v);}void bindValue(String n,Object v){}void unbindValue(String n,Object v){}Object getAttribute(String n){return attrs.get(n);}void initializeAttribute(String n,Object v){attrs.put(n,v);}public String toString(){return id+attrs;}} static class SmarterNoSqlSession extends NoSqlSession{long version;SmarterNoSqlSession(Object m,long c,long a,String i,long v){super(i);version=v;}} interface SessionFactory{ISerializableSession create(NoSqlSession s);} Logger log=new Logger();Map<String,ISerializableSession>store=new LinkedHashMap<>();String _cookieDomain="example.com",_cookiePath="/";ISerializableSession getKey(String id){return store.get(id);}boolean setKey(String id,ISerializableSession d){store.put(id,d);return true;}void deleteKey(String id){store.remove(id);}SessionFactory getSessionFactory(){return s->{Data d=new Data(s.id);d.attrs.putAll(s.attrs);return d;};}
 
// ORIGINAL CODESEARCHNET METHOD — START

@Override
    protected Object save(final NoSqlSession session, final Object version, final boolean activateAfterSave)
    {
        try
        {
            log.debug("save:" + session);
            session.willPassivate();

            if (!session.isValid())
            {
                log.debug("save: skip saving invalidated session: id=" + session.getId());
                deleteKey(session.getId());
                return null;
            }

            ISerializableSession data;
            synchronized (session)
            {
                data = getSessionFactory().create(session);
            }
            data.setDomain(_cookieDomain);
            data.setPath(_cookiePath);
            long longVersion = 1; 
            if (version != null)
            {
                longVersion = (Long) version + 1L;
            }
            data.setVersion(longVersion);

            try
            {
                if (!setKey(session.getId(), data))
                {
                    throw (new RuntimeException("unable to set key: data=" + data));
                }
            }
            catch (TranscoderException error)
            {
                throw (new IllegalArgumentException("unable to serialize session: id=" + session.getId() + ", data="
                    + data, error));
            }
            log.debug("save:db.sessions.update(" + session.getId() + "," + data + ")");

            if (activateAfterSave)
            {
                session.didActivate();
            }

            return longVersion;
        }
        catch (Exception e)
        {
            log.warn(e);
        }
        return null;
    }

// ORIGINAL CODESEARCHNET METHOD — END

 public static void main(String[] args) {
    method_3_jetty_kvs_gpt x = new method_3_jetty_kvs_gpt();
    NoSqlSession s = new NoSqlSession("s1"); s.attrs.put("k", "v");
    System.out.println("METHOD: KVSNoSqlSessionManager.save");
    System.out.println("INPUT session: " + s);
    System.out.println("INPUT activateAfterSave: true");
    Object version = x.save(s, null, true);
    System.out.println("RESULT saved version: " + version);
    System.out.println("RESULT persisted record: " + x.store.get("s1"));
    System.out.println("STATE store contains session id: " + x.store.containsKey("s1"));
} }