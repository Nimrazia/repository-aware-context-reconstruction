import java.util.*;
class Plan { public void body(){} }
public class method_10_beasttool_gpt extends Plan {
    Logger logger=Logger.getLogger("ReceiveCallPlan");Beliefbase beliefs=new Beliefbase();method_10_beasttool_gpt(String language){beliefs.b.fact=new CallQueue(new Call(language));}Beliefbase getBeliefbase(){return beliefs;}Object getServiceContainer(){return this;}IGoal createGoal(String s){return new IGoal();}void dispatchSubgoalAndWait(IGoal g){g.results=new Object[]{new IDFComponentDescription()};}IMessageEvent createMessageEvent(String s){return new IMessageEvent();}void sendMessage(IMessageEvent m){System.out.println("sent="+m.p.value);}

// ORIGINAL CODESEARCHNET METHOD — START

@Override
    public void body() {
        CallQueue queue = (CallQueue) getBeliefbase().getBelief("queue").getFact();
        Call call = queue.getPendingCall();
        if (call.getCustormer().getLanguage().equalsIgnoreCase("English")) {
            String target_service = "report-service"; String msgContent = "NewRecordedCall";
            IDF df = (IDF) SServiceProvider.getService(getServiceContainer(), IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
            IDFServiceDescription sd = df.createDFServiceDescription(target_service, null, null);
            IDFComponentDescription dfadesc = df.createDFComponentDescription(null, sd);
            ISearchConstraints constraints = df.createSearchConstraints(-1, 0);
            IGoal ft = createGoal("dfcap.df_search"); ft.getParameter("description").setValue(dfadesc); ft.getParameter("constraints").setValue(constraints);
            dispatchSubgoalAndWait(ft); IDFComponentDescription[] agents = (IDFComponentDescription[]) ft.getParameterSet("result").getValues();
            if (agents.length > 0) { IMessageEvent msg = createMessageEvent("send_inform"); msg.getParameter(SFipa.CONTENT).setValue(msgContent); msg.getParameterSet(SFipa.RECEIVERS).addValue(agents[0].getName()); sendMessage(msg); logger.info("Message sent to: " + agents[0].getName().getLocalName()); } else logger.severe("Service " + target_service + " not found.");
        } else {
            System.out.println("Language: " + call.getCustormer().getLanguage()); String target_service = "helpdesk-service"; String msgContent = "UnknownLanguageCall";
            IDF df = (IDF) SServiceProvider.getService(getServiceContainer(), IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this); IDFServiceDescription sd = df.createDFServiceDescription(target_service, null, null); IDFComponentDescription dfadesc = df.createDFComponentDescription(null, sd); ISearchConstraints constraints = df.createSearchConstraints(-1, 0);
            IGoal ft = createGoal("dfcap.df_search"); ft.getParameter("description").setValue(dfadesc); ft.getParameter("constraints").setValue(constraints); dispatchSubgoalAndWait(ft); IDFComponentDescription[] agents = (IDFComponentDescription[]) ft.getParameterSet("result").getValues(); IMessageEvent msg = createMessageEvent("helpdesk-request"); msg.getParameter(SFipa.CONTENT).setValue(msgContent);
            if (agents.length > 0) { msg.getParameterSet(SFipa.RECEIVERS).addValue(agents[0].getName()); sendMessage(msg); System.out.println("Enviado"); } else { System.out.println("Service " + target_service + " not found."); logger.severe("Service " + target_service + " not found."); }
            logger.info("Message sent to: " + agents[0].getName());
        }
    }

// ORIGINAL CODESEARCHNET METHOD — END

    public static void main(String[]a){new method_10_beasttool_gpt("English").body();new method_10_beasttool_gpt("Spanish").body();}
    static class Beliefbase{Belief b=new Belief();Belief getBelief(String s){return b;}}static class Belief{Object fact;Object getFact(){return fact;}}static class CallQueue{Call c;CallQueue(Call c){this.c=c;}Call getPendingCall(){return c;}}static class Call{Customer c;Call(String l){c=new Customer(l);}Customer getCustormer(){return c;}}static class Customer{String l;Customer(String l){this.l=l;}String getLanguage(){return l;}}static class SServiceProvider{static Service getService(Object c,Class<?>k,String s){return new Service();}}static class Service{Object get(Object o){return new IDF();}}static class RequiredServiceInfo{static final String SCOPE_PLATFORM="platform";}static class SFipa{static final String CONTENT="content",RECEIVERS="receivers";}static class IDF{IDFServiceDescription createDFServiceDescription(String a,Object b,Object c){return new IDFServiceDescription();}IDFComponentDescription createDFComponentDescription(Object a,Object b){return new IDFComponentDescription();}ISearchConstraints createSearchConstraints(int a,int b){return new ISearchConstraints();}}static class IDFServiceDescription{}static class ISearchConstraints{}static class IDFComponentDescription{Name getName(){return new Name();}}static class Name{String getLocalName(){return "agent";}public String toString(){return getLocalName();}}static class Parameter{Object value;void setValue(Object v){value=v;}Object getValue(){return value;}}static class ParameterSet extends Parameter{List<Object>vals=new ArrayList<>();void addValue(Object v){vals.add(v);}Object[]getValues(){return vals.toArray(new IDFComponentDescription[0]);}}static class IGoal{Map<String,Parameter>p=new HashMap<>();Object[]results;Parameter getParameter(String s){return p.computeIfAbsent(s,k->new Parameter());}ParameterSet getParameterSet(String s){ParameterSet x=new ParameterSet();if(results!=null)x.vals.addAll(Arrays.asList(results));return x;}}static class IMessageEvent{Parameter p=new Parameter();ParameterSet ps=new ParameterSet();Parameter getParameter(String s){return p;}ParameterSet getParameterSet(String s){return ps;}}static class Logger{static Logger getLogger(String s){return new Logger();}void info(String s){System.out.println(s);}void severe(String s){System.out.println(s);}}

}
