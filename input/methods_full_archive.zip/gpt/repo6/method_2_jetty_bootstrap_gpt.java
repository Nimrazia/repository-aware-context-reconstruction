import java.io.*;import java.security.KeyStore;
public class method_2_jetty_bootstrap_gpt {static final Log LOG=new Log();static final File TEMP_DIRECTORY_DEFAULT=new File("build/tmp");static final String DEFAULT_KEYSTORE_FILENAME="keystore.jks";boolean isInitializedConfiguration;IJettyConfiguration iJettyConfiguration;method_2_jetty_bootstrap_gpt(IJettyConfiguration c){this.iJettyConfiguration=c;}static class Log{void debug(String s,Object...o){}void trace(String s,Object...o){}}static class JettyBootstrapException extends Exception{JettyBootstrapException(String s){super(s);}JettyBootstrapException(String s,Throwable t){super(s,t);}}enum JettyConnector{HTTP,HTTPS}static class FileUtils{static void deleteDirectory(File f)throws IOException{if(f.exists())for(File x:f.listFiles())x.delete();f.delete();}}static class JettyKeystoreException extends Exception{}static class JettyKeystoreGeneratorBuilder{void setAlgorithm(String s){}void setSignatureAlgorithm(String s){}void setRdnOuValue(String s){}void setRdnOValue(String s){}void setDateNotBeforeNumberOfDays(int i){}void setDateNotAfterNumberOfDays(int i){}KeyStore build(String d,String a,String p)throws JettyKeystoreException{return null;}static void saveKeyStore(KeyStore k,File f,String p)throws JettyKeystoreException{try{f.getParentFile().mkdirs();f.createNewFile();}catch(IOException e){throw new JettyKeystoreException();}}}interface IJettyConfiguration{File getTempDirectory();void setTempDirectory(File f);boolean isCleanTempDir();String getHost();boolean hasJettyConnector(JettyConnector j);KeyStore getSslKeyStore();String getSslPrivateKeyPath();String getSslCertificatePath();String getSslKeyStorePath();void setSslKeyStorePath(String s);String getSslKeyStoreAlgorithm();String getSslKeyStoreSignatureAlgorithm();String getSslKeyStoreRdnOuValue();String getSslKeyStoreRdnOValue();int getSslKeyStoreDateNotBeforeNumberOfDays();int getSslKeyStoreDateNotAfterNumberOfDays();String getSslKeyStoreDomainName();String getSslKeyStoreAlias();String getSslKeyStorePassword();boolean isRedirectWebAppsOnHttpsConnector();}

// ORIGINAL CODESEARCHNET METHOD — START

protected IJettyConfiguration getInitializedConfiguration() throws JettyBootstrapException {
        if (!isInitializedConfiguration) {
            LOG.debug("Init Configuration...");

            LOG.trace("Check Temp Directory...");
            if (iJettyConfiguration.getTempDirectory() == null) {
                iJettyConfiguration.setTempDirectory(TEMP_DIRECTORY_DEFAULT);
            }

            if (iJettyConfiguration.getTempDirectory().exists() && iJettyConfiguration.isCleanTempDir()) {
                LOG.trace("Clean Temp Directory...");

                try {
                    FileUtils.deleteDirectory(iJettyConfiguration.getTempDirectory());
                } catch (IOException e) {
                    throw new JettyBootstrapException("Can't clean temporary directory");
                }
            }
            if (!iJettyConfiguration.getTempDirectory().exists() && !iJettyConfiguration.getTempDirectory().mkdirs()) {
                throw new JettyBootstrapException("Can't create temporary directory");
            }

            LOG.trace("Check required properties...");
            if (iJettyConfiguration.getHost() == null || iJettyConfiguration.getHost().isEmpty()) {
                throw new JettyBootstrapException("Host not specified");
            }

            LOG.trace("Check connectors...");
            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {

                
                if (iJettyConfiguration.getSslKeyStore() == null &&
                    (iJettyConfiguration.getSslPrivateKeyPath() == null || iJettyConfiguration.getSslPrivateKeyPath().isEmpty() ||
                        iJettyConfiguration.getSslCertificatePath() == null || iJettyConfiguration.getSslCertificatePath().isEmpty())) {

                    
                    if (iJettyConfiguration.getSslKeyStorePath() == null || iJettyConfiguration.getSslKeyStorePath().isEmpty()) {
                        iJettyConfiguration.setSslKeyStorePath(iJettyConfiguration.getTempDirectory().getPath() + File.separator + DEFAULT_KEYSTORE_FILENAME);
                    }

                    
                    File keystoreFile = new File(iJettyConfiguration.getSslKeyStorePath());
                    if (!keystoreFile.exists()) {
                        try {
                            JettyKeystoreGeneratorBuilder jettyKeystoreGeneratorBuilder = new JettyKeystoreGeneratorBuilder();
                            jettyKeystoreGeneratorBuilder.setAlgorithm(iJettyConfiguration.getSslKeyStoreAlgorithm());
                            jettyKeystoreGeneratorBuilder.setSignatureAlgorithm(iJettyConfiguration.getSslKeyStoreSignatureAlgorithm());
                            jettyKeystoreGeneratorBuilder.setRdnOuValue(iJettyConfiguration.getSslKeyStoreRdnOuValue());
                            jettyKeystoreGeneratorBuilder.setRdnOValue(iJettyConfiguration.getSslKeyStoreRdnOValue());
                            jettyKeystoreGeneratorBuilder.setDateNotBeforeNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotBeforeNumberOfDays());
                            jettyKeystoreGeneratorBuilder.setDateNotAfterNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotAfterNumberOfDays());

                            KeyStore keyStore = jettyKeystoreGeneratorBuilder.build(iJettyConfiguration.getSslKeyStoreDomainName(), iJettyConfiguration.getSslKeyStoreAlias(),
                                    iJettyConfiguration.getSslKeyStorePassword());
                            JettyKeystoreGeneratorBuilder.saveKeyStore(keyStore, keystoreFile, iJettyConfiguration.getSslKeyStorePassword());
                        } catch (JettyKeystoreException e) {
                            throw new JettyBootstrapException("Can't generate keyStore", e);
                        }
                    }
                }
            }

            if (iJettyConfiguration.isRedirectWebAppsOnHttpsConnector() &&
                (!iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP) || !iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS))) {
                throw new JettyBootstrapException("You can't redirect all from HTTP to HTTPS Connector if both connectors are not setted");
            }

            isInitializedConfiguration = true;

            LOG.trace("Configuration : {}", iJettyConfiguration);
        }

        return iJettyConfiguration;
    }

// ORIGINAL CODESEARCHNET METHOD — END

static class C implements IJettyConfiguration{File t;String kp;public File getTempDirectory(){return t;}public void setTempDirectory(File f){t=f;}public boolean isCleanTempDir(){return true;}public String getHost(){return "localhost";}public boolean hasJettyConnector(JettyConnector j){return j==JettyConnector.HTTP;}public KeyStore getSslKeyStore(){return null;}public String getSslPrivateKeyPath(){return null;}public String getSslCertificatePath(){return null;}public String getSslKeyStorePath(){return kp;}public void setSslKeyStorePath(String s){kp=s;}public String getSslKeyStoreAlgorithm(){return "RSA";}public String getSslKeyStoreSignatureAlgorithm(){return "SHA256";}public String getSslKeyStoreRdnOuValue(){return "OU";}public String getSslKeyStoreRdnOValue(){return "O";}public int getSslKeyStoreDateNotBeforeNumberOfDays(){return 0;}public int getSslKeyStoreDateNotAfterNumberOfDays(){return 30;}public String getSslKeyStoreDomainName(){return "localhost";}public String getSslKeyStoreAlias(){return "a";}public String getSslKeyStorePassword(){return "p";}public boolean isRedirectWebAppsOnHttpsConnector(){return false;}}public static void main(String[]a)throws Exception{C c=new C();method_2_jetty_bootstrap_gpt b=new method_2_jetty_bootstrap_gpt(c);b.getInitializedConfiguration();System.out.println("initialized="+b.isInitializedConfiguration+", temp="+c.getTempDirectory());}}