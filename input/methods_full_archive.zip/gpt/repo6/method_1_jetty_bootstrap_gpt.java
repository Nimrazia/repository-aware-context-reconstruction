import java.io.*;import java.security.KeyStore;import java.util.*;
public class method_1_jetty_bootstrap_gpt { static final Log LOG=new Log(); static class Log{void trace(String s,Object...o){}void debug(String s,Object...o){}void warn(String s,Object...o){}} static class JettyBootstrapException extends Exception{JettyBootstrapException(String s){super(s);}JettyBootstrapException(String s,Throwable t){super(s,t);}} enum JettyConnector{HTTP,HTTPS} enum HttpScheme{HTTPS;String asString(){return "https";}} enum Format{PKCS8,PKCS12,UNKNOWN} interface Connector{} static class Server{} static class HttpConfiguration{long idle,blocking;int securePort;String scheme;void setSecurePort(int v){securePort=v;}void setSecureScheme(String v){scheme=v;}void setIdleTimeout(long v){idle=v;}void setBlockingTimeout(long v){blocking=v;}} static class HttpConnectionFactory{HttpConfiguration c;HttpConnectionFactory(){this(new HttpConfiguration());}HttpConnectionFactory(HttpConfiguration c){this.c=c;}HttpConfiguration getHttpConfiguration(){return c;}} static class ServerConnector implements Connector{long idle;String host;int port;List<Object> factories=new ArrayList<>();ServerConnector(Server s,Object...f){if(f.length==0)factories.add(new HttpConnectionFactory());else factories.addAll(Arrays.asList(f));}List<Object> getConnectionFactories(){return factories;}void setIdleTimeout(long v){idle=v;}void setHost(String v){host=v;}void setPort(int v){port=v;}public String toString(){return host+":"+port;}} static class SslContextFactory{KeyStore ks;String path,password;void setKeyStore(KeyStore k){ks=k;}void setKeyStorePath(String p){path=p;}void setKeyStorePassword(String p){password=p;}} static class JettyKeystoreException extends Exception{} static class JettyKeystoreConvertorBuilder{void setCertificateFromPKCS8(InputStream i){}void setCertificateFromPKCS12(InputStream i,String p){}void setPrivateKeyFromPKCS8(InputStream i){}void setPrivateKeyFromPKCS12(InputStream i,String p){}KeyStore build(String a,String p)throws JettyKeystoreException{return null;}} interface IJettyConfiguration{boolean hasJettyConnector(JettyConnector j);int getSslPort();long getIdleTimeout();long getBlockingTimeout();String getHost();int getPort();KeyStore getSslKeyStore();String getSslPrivateKeyPath();String getSslCertificatePath();Format getSslCertificateFormat();String getSslCertificatePassword();Format getSslPrivateKeyFormat();String getSslPrivateKeyPassword();String getSslKeyStoreAlias();String getSslKeyStorePassword();String getSslKeyStorePath();}

// ORIGINAL CODESEARCHNET METHOD — START

protected Connector[] createConnectors(IJettyConfiguration iJettyConfiguration, Server server) throws JettyBootstrapException {
        LOG.trace("Creating Jetty Connectors...");

        List<Connector> connectors = new ArrayList<>();

        if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP)) {
            LOG.trace("Adding HTTP Connector...");

            ServerConnector serverConnector;

            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
                HttpConfiguration httpConfiguration = new HttpConfiguration();
                httpConfiguration.setSecurePort(iJettyConfiguration.getSslPort());
                httpConfiguration.setSecureScheme(HttpScheme.HTTPS.asString());
                httpConfiguration.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
                httpConfiguration.setBlockingTimeout(iJettyConfiguration.getBlockingTimeout());

                HttpConnectionFactory httpConnectionFactory = new HttpConnectionFactory(httpConfiguration);

                serverConnector = new ServerConnector(server, httpConnectionFactory);
            } else {
                serverConnector = new ServerConnector(server);

                serverConnector.getConnectionFactories().stream()
                        .filter(HttpConnectionFactory.class::isInstance)
                        .map(HttpConnectionFactory.class::cast)
                        .forEach(httpConnectionFactory -> httpConnectionFactory.getHttpConfiguration().setBlockingTimeout(iJettyConfiguration.getBlockingTimeout()));
            }

            serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
            serverConnector.setHost(iJettyConfiguration.getHost());
            serverConnector.setPort(iJettyConfiguration.getPort());

            connectors.add(serverConnector);
        }
        if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
            LOG.trace("Adding HTTPS Connector...");

            SslContextFactory sslContextFactory = new SslContextFactory();

            if (iJettyConfiguration.getSslKeyStore() != null) { 
                sslContextFactory.setKeyStore(iJettyConfiguration.getSslKeyStore());
            } else if (iJettyConfiguration.getSslPrivateKeyPath() != null && !iJettyConfiguration.getSslPrivateKeyPath().isEmpty() &&
                iJettyConfiguration.getSslCertificatePath() != null && !iJettyConfiguration.getSslCertificatePath().isEmpty()) { 

                JettyKeystoreConvertorBuilder jettyKeystoreConvertorBuilder = new JettyKeystoreConvertorBuilder();
                try {
                    File sslPrivateKeyFile = new File(iJettyConfiguration.getSslPrivateKeyPath());
                    if (!sslPrivateKeyFile.exists() || !sslPrivateKeyFile.canRead()) {
                        throw new JettyBootstrapException("Private key not exists or unreadable");
                    }

                    File sslCertificateFile = new File(iJettyConfiguration.getSslCertificatePath());
                    if (!sslCertificateFile.exists() || !sslCertificateFile.canRead()) {
                        throw new JettyBootstrapException("Certificate not exists or unreadable");
                    }

                    try (InputStream sslPrivateKeyInputStream = new FileInputStream(sslPrivateKeyFile);
                            InputStream sslCertificateInputStream = new FileInputStream(sslCertificateFile)) {

                        switch (iJettyConfiguration.getSslCertificateFormat()) {
                            case PKCS8:
                                jettyKeystoreConvertorBuilder.setCertificateFromPKCS8(sslCertificateInputStream);
                                break;
                            case PKCS12:
                                jettyKeystoreConvertorBuilder.setCertificateFromPKCS12(sslCertificateInputStream, iJettyConfiguration.getSslCertificatePassword());
                                break;
                            case UNKNOWN:
                                throw new JettyBootstrapException("Unknown Certificate Format");
                            default:
                                throw new JettyBootstrapException("Certificate Format not setted");
                        }

                        switch (iJettyConfiguration.getSslPrivateKeyFormat()) {
                            case PKCS8:
                                jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS8(sslPrivateKeyInputStream);
                                break;
                            case PKCS12:
                                jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS12(sslPrivateKeyInputStream, iJettyConfiguration.getSslPrivateKeyPassword());
                                break;
                            case UNKNOWN:
                                throw new JettyBootstrapException("Unknown Private key Format");
                            default:
                                throw new JettyBootstrapException("Private key Format not setted");
                        }
                    }

                    KeyStore keyStore = jettyKeystoreConvertorBuilder.build(iJettyConfiguration.getSslKeyStoreAlias(), iJettyConfiguration.getSslKeyStorePassword());

                    sslContextFactory.setKeyStore(keyStore);
                } catch (JettyKeystoreException | IOException e) {
                    throw new JettyBootstrapException("Can not load SSL private key or SSL certificate", e);
                }
            } else { 
                sslContextFactory.setKeyStorePath(iJettyConfiguration.getSslKeyStorePath());
            }
            sslContextFactory.setKeyStorePassword(iJettyConfiguration.getSslKeyStorePassword());
            ServerConnector serverConnector = new ServerConnector(server, sslContextFactory);

            serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
            serverConnector.setHost(iJettyConfiguration.getHost());
            serverConnector.setPort(iJettyConfiguration.getSslPort());

            connectors.add(serverConnector);
        }

        return connectors.toArray(new Connector[connectors.size()]);
    }

// ORIGINAL CODESEARCHNET METHOD — END

static class Config implements IJettyConfiguration{Set<JettyConnector>s=EnumSet.of(JettyConnector.HTTP,JettyConnector.HTTPS);public boolean hasJettyConnector(JettyConnector j){return s.contains(j);}public int getSslPort(){return 8443;}public long getIdleTimeout(){return 30000;}public long getBlockingTimeout(){return 5000;}public String getHost(){return "127.0.0.1";}public int getPort(){return 8080;}public KeyStore getSslKeyStore(){return null;}public String getSslPrivateKeyPath(){return null;}public String getSslCertificatePath(){return null;}public Format getSslCertificateFormat(){return Format.UNKNOWN;}public String getSslCertificatePassword(){return "";}public Format getSslPrivateKeyFormat(){return Format.UNKNOWN;}public String getSslPrivateKeyPassword(){return "";}public String getSslKeyStoreAlias(){return "x";}public String getSslKeyStorePassword(){return "pwd";}public String getSslKeyStorePath(){return "demo.jks";}}public static void main(String[]a)throws Exception{Connector[]c=new method_1_jetty_bootstrap_gpt().createConnectors(new Config(),new Server());System.out.println("connectors="+c.length+" "+Arrays.toString(c));}}