import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicInteger;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

interface ParserContract { Object createTokenCollection(Reader reader) throws Exception; }

public class method_2_mtas_gpt implements ParserContract {
  
  

  private static final String MAPPING_TYPE_WORD = "word";
  private static final String MAPPING_TYPE_WORD_ANNOTATION = "wordAnnotation";
  private static final String MAPPING_TYPE_GROUP = "group";
  private static final String MAPPING_TYPE_GROUP_ANNOTATION = "groupAnnotation";
  private static final String MAPPING_TYPE_RELATION = "relation";
  private static final String MAPPING_TYPE_RELATION_ANNOTATION = "relationAnnotation";
  private static final String MAPPING_TYPE_REF = "ref";
  private static final String UPDATE_TYPE_VARIABLE = "variable";
  private static final String UPDATE_TYPE_OFFSET = "offset";
  private static final String UPDATE_TYPE_POSITION = "position";

  private String rootTag;
  private String contentTag = "text";
  private boolean allowNonContent = true;
  private boolean autorepair = true;
  private boolean makeunique = true;
  private MtasTokenCollection tokenCollection;
  private final Logger log = new Logger();
  private final Map<QName,MtasParserType<?>> variableTypes = new HashMap<>();
  private final Map<QName,MtasParserType<?>> relationTypes = new HashMap<>();
  private final Map<QName,MtasParserType<?>> relationAnnotationTypes = new HashMap<>();
  private final Map<QName,MtasParserType<?>> groupTypes = new HashMap<>();
  private final Map<QName,MtasParserType<?>> groupAnnotationTypes = new HashMap<>();
  private final Map<QName,MtasParserType<?>> wordTypes = new HashMap<>();
  private final Map<QName,MtasParserType<?>> wordAnnotationTypes = new HashMap<>();
  private final Map<QName,MtasParserType<?>> refTypes = new HashMap<>();
  private final Map<String,SortedSet<String>> relationKeyMap = new HashMap<>();

  public method_2_mtas_gpt() {
    wordTypes.put(getQName("w"), new MtasParserType<Object>("word", "ref"));
    wordAnnotationTypes.put(getQName("lemma"), new MtasParserType<Object>("lemma", "ref"));
    groupTypes.put(getQName("s"), new MtasParserType<Object>("group", "ref"));
    relationTypes.put(getQName("relation"), new MtasParserType<Object>("relation", "ref"));
    refTypes.put(getQName("ref"), new MtasParserType<Object>("ref", "target"));
  }

  private QName getQName(String name) { return new QName(name); }
  private Map<String,Map<Integer,Set<String>>> createUpdateList() {
    Map<String,Map<Integer,Set<String>>> m=new HashMap<>();
    m.put(UPDATE_TYPE_VARIABLE,new HashMap<>()); m.put(UPDATE_TYPE_OFFSET,new HashMap<>()); m.put(UPDATE_TYPE_POSITION,new HashMap<>()); return m;
  }
  private Map<String,List<MtasParserObject>> createCurrentList() {
    Map<String,List<MtasParserObject>> m=new HashMap<>();
    for(String k:new String[]{MAPPING_TYPE_WORD,MAPPING_TYPE_WORD_ANNOTATION,MAPPING_TYPE_GROUP,MAPPING_TYPE_GROUP_ANNOTATION,MAPPING_TYPE_RELATION,MAPPING_TYPE_RELATION_ANNOTATION,MAPPING_TYPE_REF}) m.put(k,new ArrayList<>());
    return m;
  }
  private Map<String,Map<String,String>> createVariables(){return new HashMap<>();}
  private void collectAttributes(MtasParserObject o, XMLStreamReader r){ for(int i=0;i<r.getAttributeCount();i++) o.attributes.put(r.getAttributeLocalName(i),r.getAttributeValue(i)); if(o.id==null)o.id=o.attributes.get("id"); }
  private void computeVariablesFromObject(MtasParserObject o, Map<String,List<MtasParserObject>> c, Map<String,Map<String,String>> v){}
  private boolean prevalidateObject(MtasParserObject o, Map<String,List<MtasParserObject>> c){return true;}
  private void computeMappingsFromObject(MtasTokenIdFactory f,MtasParserObject o,Map<String,List<MtasParserObject>> c,Map<String,Map<Integer,Set<String>>> u){
    if(o.type.name.equals("word")){ MtasToken t=new MtasToken(f.next(),o.text.toString().trim()); t.positions.addAll(o.positions); if(o.offsetStart!=null&&o.offsetEnd!=null)t.addOffset(o.offsetStart,o.offsetEnd); tokenCollection.add(t); }
  }
  private String decodeAndUpdateWithVariables(String p,String q,Map<String,Map<String,String>> v){return (p==null?"":p)+(q==null?"":q);}
  private Set<String> recursiveCollect(String id,Map<String,SortedSet<String>> m,int depth){ Set<String>s=new HashSet<>(); if(depth<=0)return s; SortedSet<String>x=m.get(id); if(x!=null)for(String y:x){if(s.add(y))s.addAll(recursiveCollect(y,m,depth-1));}return s; }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
@Override
  public MtasTokenCollection createTokenCollection(Reader reader)
      throws MtasParserException, MtasConfigException {
    Boolean hasRoot = rootTag == null ? true : false;
    Boolean parsingContent = contentTag == null ? true : false;
    String textContent = null;
    Integer unknownAncestors = 0;
    Integer lastOffset = 0;

    AtomicInteger position = new AtomicInteger(0);
    Map<String, Set<Integer>> idPositions = new HashMap<>();
    Map<String, Integer[]> idOffsets = new HashMap<>();

    Map<String, Map<Integer, Set<String>>> updateList = createUpdateList();
    Map<String, List<MtasParserObject>> currentList = createCurrentList();
    Map<String, Map<String, String>> variables = createVariables();

    tokenCollection = new MtasTokenCollection();
    MtasTokenIdFactory mtasTokenIdFactory = new MtasTokenIdFactory();
    XMLInputFactory factory = XMLInputFactory.newInstance();
    try {      
      XMLStreamReader streamReader = factory.createXMLStreamReader(reader);
      QName qname;
      try {
        int event = streamReader.getEventType();
        MtasParserType<?> currentType;
        MtasParserType<?> tmpCurrentType;
        MtasParserType<?> tmpVariableType;
        MtasParserObject currentObject = null;
        MtasParserObject variableObject = null;
        while (true) {
          switch (event) {
          case XMLStreamConstants.START_DOCUMENT:
            log.debug("start of document");
            String encodingScheme = streamReader.getCharacterEncodingScheme();
            if (encodingScheme == null) {
              
              log.info("No encodingScheme found, assume utf-8");
              
            } else if (!encodingScheme.equalsIgnoreCase("utf-8")) {
              throw new MtasParserException(
                  "XML not UTF-8 encoded but '" + encodingScheme + "'");
            }
            break;
          case XMLStreamConstants.END_DOCUMENT:
            log.debug("end of document");
            break;
          case XMLStreamConstants.SPACE:
            
            lastOffset = streamReader.getLocation().getCharacterOffset();
            break;
          case XMLStreamConstants.START_ELEMENT:
            
            qname = streamReader.getName();
            
            if (!hasRoot) {
              if (qname.equals(getQName(rootTag))) {
                hasRoot = true;
              } else {
                throw new MtasParserException("No " + rootTag);
              }
              
            } else {
              if ((tmpVariableType = variableTypes.get(qname)) != null) {
                variableObject = new MtasParserObject(tmpVariableType);
                collectAttributes(variableObject, streamReader);
                computeVariablesFromObject(variableObject, currentList,
                    variables);
              }
              if (parsingContent) {
                
                
                if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .isEmpty())
                    && (tmpCurrentType = relationTypes.get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_RELATION).add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (!currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (tmpCurrentType = relationAnnotationTypes
                        .get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                        .add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .isEmpty())
                    && (tmpCurrentType = groupTypes.get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_GROUP).add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (!currentList.get(MAPPING_TYPE_GROUP).isEmpty())
                    && (tmpCurrentType = groupAnnotationTypes
                        .get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .isEmpty())
                    && (currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (currentList.get(MAPPING_TYPE_WORD_ANNOTATION).isEmpty())
                    && (tmpCurrentType = wordTypes.get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setOffsetStart(lastOffset);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentObject.addPosition(position.getAndIncrement());
                    currentList.get(MAPPING_TYPE_WORD).add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                  
                } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                    && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                        .isEmpty())
                    && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())
                    && (tmpCurrentType = wordAnnotationTypes
                        .get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.addPositions(currentList.get(MAPPING_TYPE_WORD)
                      .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                      .getPositions());
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                        .add(currentObject);
                    unknownAncestors = 0;
                  }
                  
                } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()
                    && (tmpCurrentType = refTypes.get(qname)) != null) {
                  currentObject = new MtasParserObject(tmpCurrentType);
                  collectAttributes(currentObject, streamReader);
                  currentObject.setUnknownAncestorNumber(unknownAncestors);
                  currentObject.setRealOffsetStart(lastOffset);
                  if (!prevalidateObject(currentObject, currentList)) {
                    unknownAncestors++;
                  } else {
                    currentType = tmpCurrentType;
                    currentList.get(MAPPING_TYPE_REF).add(currentObject);
                    unknownAncestors = 0;
                    
                    for (MtasParserObject currentRelation : currentList
                        .get(MAPPING_TYPE_RELATION)) {
                      currentRelation.addRefId(currentObject
                          .getAttribute(currentType.getRefAttributeName()));
                      
                      SortedSet<String> keyMapList;
                      if (currentRelation.getId() != null) {
                        if (relationKeyMap
                            .containsKey(currentRelation.getId())) {
                          keyMapList = relationKeyMap
                              .get(currentRelation.getId());
                        } else {
                          keyMapList = new TreeSet<>();
                          relationKeyMap.put(currentRelation.getId(),
                              keyMapList);
                        }
                        keyMapList.add(currentObject
                            .getAttribute(currentType.getRefAttributeName()));
                      }
                    }
                  }
                } else {
                  unknownAncestors++;
                }
                
              } else if (qname.equals(getQName(contentTag))) {
                parsingContent = true;
                
              } else if (!allowNonContent) {
                throw new MtasParserException(
                    "Unexpected " + qname.getLocalPart() + " in document");
              }
            }
            
            lastOffset = streamReader.getLocation().getCharacterOffset();
            break;
          case XMLStreamConstants.END_ELEMENT:
            
            lastOffset = streamReader.getLocation().getCharacterOffset();
            
            qname = streamReader.getName();
            
            if (parsingContent) {
              if (unknownAncestors > 0) {
                unknownAncestors--;
                
                
              } else if (!currentList.get(MAPPING_TYPE_REF).isEmpty()) {
                if ((currentType = refTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_REF)
                      .remove(currentList.get(MAPPING_TYPE_REF).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
                
              } else if (!currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                  .isEmpty()) {
                if ((currentType = wordAnnotationTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                      .remove(
                          currentList.get(MAPPING_TYPE_WORD_ANNOTATION).size()
                              - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  
                  
                  if ((currentObject.getId() != null)
                      && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())) {
                    currentList.get(MAPPING_TYPE_WORD)
                        .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                        .addUpdateableIdWithOffset(currentObject.getId());
                  }
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
                
              } else if (!currentList.get(MAPPING_TYPE_WORD).isEmpty()) {
                if ((currentType = wordTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_WORD)
                      .remove(currentList.get(MAPPING_TYPE_WORD).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  currentObject.setOffsetEnd(lastOffset);
                  currentObject.setRealOffsetEnd(lastOffset);
                  
                  for (MtasParserObject currentGroup : currentList
                      .get(MAPPING_TYPE_GROUP)) {
                    currentGroup.addPositions(currentObject.getPositions());
                    currentGroup.addOffsetStart(currentObject.getOffsetStart());
                    currentGroup.addOffsetEnd(currentObject.getOffsetEnd());
                  }
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
                
              } else if (!currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                  .isEmpty()) {
                if ((currentType = groupAnnotationTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                      .remove(
                          currentList.get(MAPPING_TYPE_GROUP_ANNOTATION).size()
                              - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
              } else if (!currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                  .isEmpty()) {
                if ((currentType = relationAnnotationTypes
                    .get(qname)) != null) {
                  currentObject = currentList
                      .get(MAPPING_TYPE_RELATION_ANNOTATION).remove(currentList
                          .get(MAPPING_TYPE_RELATION_ANNOTATION).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
              } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()) {
                if ((currentType = relationTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_RELATION).remove(
                      currentList.get(MAPPING_TYPE_RELATION).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  
                }
                
              } else if (!currentList.get(MAPPING_TYPE_GROUP).isEmpty()) {
                if ((currentType = groupTypes.get(qname)) != null) {
                  currentObject = currentList.get(MAPPING_TYPE_GROUP)
                      .remove(currentList.get(MAPPING_TYPE_GROUP).size() - 1);
                  assert currentObject.getType()
                      .equals(currentType) : "object expected to be "
                          + currentObject.getType().getName() + ", not "
                          + currentType.getName();
                  assert unknownAncestors == 0 : "error in administration "
                      + currentObject.getType().getName();
                  
                  currentObject.setRealOffsetEnd(lastOffset);
                  idPositions.put(currentObject.getId(),
                      currentObject.getPositions());
                  idOffsets.put(currentObject.getId(),
                      currentObject.getOffset());
                  currentObject.updateMappings(idPositions, idOffsets);
                  unknownAncestors = currentObject.getUnknownAncestorNumber();
                  computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                      currentList, updateList);
                } else {
                  unknownAncestors--;
                }
              } else if (qname.equals(getQName("text"))) {
                parsingContent = false;
                assert unknownAncestors == 0 : "error in administration unknownAncestors";
                assert currentList.get(MAPPING_TYPE_REF)
                    .isEmpty() : "error in administration references";
                assert currentList.get(MAPPING_TYPE_GROUP)
                    .isEmpty() : "error in administration groups";
                assert currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                    .isEmpty() : "error in administration groupAnnotations";
                assert currentList.get(MAPPING_TYPE_WORD)
                    .isEmpty() : "error in administration words";
                assert currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                    .isEmpty() : "error in administration wordAnnotations";
                assert currentList.get(MAPPING_TYPE_RELATION)
                    .isEmpty() : "error in administration relations";
                assert currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                    .isEmpty() : "error in administration relationAnnotations";
              }
            }
            
            textContent = null;
            break;
          case XMLStreamConstants.CHARACTERS:
            
            lastOffset = streamReader.getLocation().getCharacterOffset();
            
            if (streamReader.hasText()) {
              textContent = streamReader.getText();
            }
            if (currentObject != null && unknownAncestors.equals(0)) {
              currentObject.addText(textContent);
            }
            break;
          default:
            break;
          }
          if (!streamReader.hasNext()) {
            break;
          }
          event = streamReader.next();
        }
      } finally {
        streamReader.close();
      }
      
      assert unknownAncestors == 0 : "error in administration unknownAncestors";
      assert hasRoot : "no " + rootTag;
    } catch (XMLStreamException e) {
      log.debug(e);      
      throw new MtasParserException("No valid XML: " + e.getMessage());
    }

    
    for (Entry<Integer, Set<String>> updateItem : updateList
        .get(UPDATE_TYPE_VARIABLE).entrySet()) {
      MtasToken token = tokenCollection.get(updateItem.getKey());
      String encodedPrefix = token.getPrefix();
      String encodedPostfix = token.getPostfix();
      token.setValue(decodeAndUpdateWithVariables(encodedPrefix, encodedPostfix,
          variables));
    }
    
    for (Entry<Integer, Set<String>> updateItem : updateList
        .get(UPDATE_TYPE_OFFSET).entrySet()) {
      Set<String> refIdList = new HashSet<>();
      for (String refId : updateItem.getValue()) {
        if (idPositions.containsKey(refId)) {
          refIdList.add(refId);
        }
        if (relationKeyMap.containsKey(refId)) {
          refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
        }
      }
      for (String refId : refIdList) {
        Integer[] refOffset = idOffsets.get(refId);
        Integer tokenId = updateItem.getKey();
        if (tokenId != null && refOffset != null) {
          MtasToken token = tokenCollection.get(tokenId);
          token.addOffset(refOffset[0], refOffset[1]);
        }
      }
    }
    
    for (Entry<Integer, Set<String>> updateItem : updateList
        .get(UPDATE_TYPE_POSITION).entrySet()) {
      HashSet<String> refIdList = new HashSet<>();
      for (String refId : updateItem.getValue()) {
        if (idPositions.containsKey(refId)) {
          refIdList.add(refId);
        }
        if (relationKeyMap.containsKey(refId)) {
          refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
        }
      }
      for (String refId : refIdList) {
        Set<Integer> refPositions = idPositions.get(refId);
        Integer tokenId = updateItem.getKey();
        if (tokenId != null && refPositions != null) {
          MtasToken token = tokenCollection.get(tokenId);
          token.addPositions(refPositions);
        }
      }
    }
    
    tokenCollection.check(autorepair, makeunique);
    return tokenCollection;
  }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  public static void main(String[] args) throws Exception {
    method_2_mtas_gpt parser=new method_2_mtas_gpt();
    String xml="<text><s id='s1'><w id='w1'>Hello</w><w id='w2'>world</w></s></text>";
    MtasTokenCollection result=parser.createTokenCollection(new StringReader(xml));
    System.out.println("tokens="+result.size());
    System.out.println("values="+result.values());
    System.out.println("positions="+result.positions());
    System.out.println("checked="+result.checked);
  }

  static class MtasParserException extends Exception { MtasParserException(String m){super(m);} }
  static class MtasConfigException extends Exception { MtasConfigException(String m){super(m);} }
  static class Logger { void debug(Object o){} void info(String s){} }
  static class MtasParserType<T>{ final String name; final String refAttributeName; MtasParserType(String n,String r){name=n;refAttributeName=r;} String getName(){return name;} String getRefAttributeName(){return refAttributeName;} }
  static class MtasParserObject {
    final MtasParserType<?> type; String id; final Map<String,String> attributes=new HashMap<>(); final Set<Integer> positions=new HashSet<>(); Integer offsetStart,offsetEnd,realOffsetStart,realOffsetEnd,unknownAncestorNumber=0; final StringBuilder text=new StringBuilder(); final List<String> refIds=new ArrayList<>(); final List<String> updateableIds=new ArrayList<>();
    MtasParserObject(MtasParserType<?> t){type=t;} MtasParserType<?> getType(){return type;} String getId(){return id;} String getAttribute(String n){return attributes.get(n);} void setUnknownAncestorNumber(Integer n){unknownAncestorNumber=n;} Integer getUnknownAncestorNumber(){return unknownAncestorNumber;} void setRealOffsetStart(Integer n){realOffsetStart=n;} void setRealOffsetEnd(Integer n){realOffsetEnd=n;} void setOffsetStart(Integer n){offsetStart=n;} void setOffsetEnd(Integer n){offsetEnd=n;} Integer getOffsetStart(){return offsetStart;} Integer getOffsetEnd(){return offsetEnd;} Integer[] getOffset(){return new Integer[]{offsetStart,offsetEnd};} void addPosition(int p){positions.add(p);} void addPositions(Set<Integer> p){positions.addAll(p);} Set<Integer> getPositions(){return positions;} void addOffsetStart(Integer n){if(n!=null&&(offsetStart==null||n<offsetStart))offsetStart=n;} void addOffsetEnd(Integer n){if(n!=null&&(offsetEnd==null||n>offsetEnd))offsetEnd=n;} void addText(String s){if(s!=null)text.append(s);} void addRefId(String s){if(s!=null)refIds.add(s);} void addUpdateableIdWithOffset(String s){updateableIds.add(s);} void updateMappings(Map<String,Set<Integer>> p,Map<String,Integer[]> o){}
  }
  static class MtasTokenIdFactory { int id; int next(){return id++;} }
  static class MtasToken { final int id; String value; String prefix="",postfix=""; final Set<Integer> positions=new HashSet<>(); Integer start,end; MtasToken(int i,String v){id=i;value=v;} String getPrefix(){return prefix;} String getPostfix(){return postfix;} void setValue(String v){value=v;} void addOffset(Integer s,Integer e){start=s;end=e;} void addPositions(Set<Integer> p){positions.addAll(p);} }
  static class MtasTokenCollection { final List<MtasToken> list=new ArrayList<>(); boolean checked; void add(MtasToken t){list.add(t);} MtasToken get(int i){return list.get(i);} int size(){return list.size();} void check(boolean a,boolean u){checked=true;} List<String> values(){List<String>r=new ArrayList<>();for(MtasToken t:list)r.add(t.value);return r;} List<Set<Integer>> positions(){List<Set<Integer>>r=new ArrayList<>();for(MtasToken t:list)r.add(t.positions);return r;} }
}
