import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class method_3_mtas_gpt {
  
  

  private static final String PARAM_MTAS_TERMVECTOR="mtas.termvector";
  private static final String NAME="termvector";
  private static final String NAME_MTAS_TERMVECTOR_BOUNDARY="boundary";
  private static final String NAME_MTAS_TERMVECTOR_FIELD="field";
  private static final String NAME_MTAS_TERMVECTOR_PREFIX="prefix";
  private static final String NAME_MTAS_TERMVECTOR_KEY="key";
  private static final String NAME_MTAS_TERMVECTOR_NUMBER="number";
  private static final String NAME_MTAS_TERMVECTOR_SORT_TYPE="sort.type";
  private static final String NAME_MTAS_TERMVECTOR_SORT_DIRECTION="sort.direction";
  private static final String NAME_MTAS_TERMVECTOR_TYPE="type";
  private static final String NAME_MTAS_TERMVECTOR_DISTANCE="distance";
  private static final String NAME_MTAS_TERMVECTOR_DISTANCE_TYPE="type";
  private static final String NAME_MTAS_TERMVECTOR_DISTANCE_BASE="base";
  private static final String NAME_MTAS_TERMVECTOR_DISTANCE_KEY="key";
  private static final String NAME_MTAS_TERMVECTOR_DISTANCE_MINIMUM="minimum";
  private static final String NAME_MTAS_TERMVECTOR_DISTANCE_MAXIMUM="maximum";
  private static final String NAME_MTAS_TERMVECTOR_DISTANCE_PARAMETER="parameter";
  private static final String NAME_MTAS_TERMVECTOR_FUNCTION="function";
  private static final String NAME_MTAS_TERMVECTOR_FUNCTION_EXPRESSION="expression";
  private static final String NAME_MTAS_TERMVECTOR_FUNCTION_KEY="key";
  private static final String NAME_MTAS_TERMVECTOR_FUNCTION_TYPE="type";
  private static final String NAME_MTAS_TERMVECTOR_REGEXP="regexp";
  private final Logger log=new Logger();
  private final Object searchComponent=new Object();

  
  private static ShardResponse sampleShard(String address,String key,double boundary,String[] terms,double[] values){
    MtasResult result=new MtasResult(); for(int i=0;i<terms.length;i++)result.comparatorList.put(terms[i],new MtasDataItemNumberComparator(values[i])); result.lastSortValue=new MtasDataItemNumberComparator(boundary);
    NamedList<Object> item=new NamedList<>(); item.add("key",key); item.add("field","contents"); item.add("list",new MtasSolrMtasResult(result));
    List<NamedList<Object>> list=new ArrayList<>(); list.add(item); NamedList<Object> mtas=new NamedList<>(); mtas.add(NAME,list); NamedList<Object> root=new NamedList<>(); root.add("mtas",mtas);
    return new ShardResponse(address,new SolrResponse(root));
  }


  
  // ORIGINAL CODESEARCHNET METHOD — START
  
private void distributedProcessMissingTop(ResponseBuilder rb,
      ComponentFields mtasFields) throws IOException {
    
    Map<String, SortedMap<String, MtasDataItemNumberComparator>> mergedComparatorLists = new HashMap<>();
    Map<String, MtasDataItemNumberComparator> mergedComparatorBoundaryList = new HashMap<>();
    Map<String, MtasDataItemNumberComparator> summedComparatorBoundaryList = new HashMap<>();
    Map<String, Map<String, MtasDataItemNumberComparator>> comparatorBoundariesList = new HashMap<>();
    
    for (String field : mtasFields.list.keySet()) {
      List<ComponentTermVector> tvList = mtasFields.list
          .get(field).termVectorList;
      if (tvList != null) {
        for (ComponentTermVector tv : tvList) {
          if (!tv.subComponentFunction.sortType.equals(CodecUtil.SORT_TERM)) {
            mergedComparatorLists.put(tv.key,
                new TreeMap<String, MtasDataItemNumberComparator>());
          }
        }
      }
    }
    
    
    for (ShardRequest sreq : rb.finished) {
      if (sreq.params.getBool(MtasSolrSearchComponent.PARAM_MTAS, false)
          && sreq.params.getBool(PARAM_MTAS_TERMVECTOR, false)) {
        for (ShardResponse shardResponse : sreq.responses) {
          SortedMap<String, MtasDataItemNumberComparator> mergedComparatorList;
          NamedList<Object> response = shardResponse.getSolrResponse()
              .getResponse();
          String key;
          MtasSolrMtasResult list;
          MtasDataItemNumberComparator comparatorLast;
          Map<String, MtasDataItemNumberComparator> comparatorList;
          try {
            List<NamedList<Object>> data = (List<NamedList<Object>>) response
                .findRecursive("mtas", NAME);
            if (data != null) {
              for (int i = 0; i < data.size(); i++) {
                NamedList<Object> dataItem = data.get(i);
                try {
                  key = (String) dataItem.get("key");
                  list = (MtasSolrMtasResult) dataItem.get("list");
                  if (list != null) {
                    comparatorLast = list.getResult().getLastSortValue();
                    comparatorList = list.getResult().getComparatorList();
                    if (key == null) {
                      dataItem.clear();
                    } else if (comparatorLast == null || comparatorList == null
                        || !mergedComparatorLists.containsKey(key)) {
                      
                    } else {
                      mergedComparatorList = mergedComparatorLists.get(key);
                      for (Entry<String, MtasDataItemNumberComparator> entry : comparatorList
                          .entrySet()) {
                        if (mergedComparatorList.containsKey(entry.getKey())) {
                          mergedComparatorList.get(entry.getKey())
                              .add(entry.getValue().getValue());
                        } else {
                          mergedComparatorList.put(entry.getKey(),
                              entry.getValue().clone());
                        }
                      }
                      if (!comparatorBoundariesList.containsKey(key)) {
                        comparatorBoundariesList.put(key,
                            new HashMap<String, MtasDataItemNumberComparator>());
                      }
                      comparatorBoundariesList.get(key)
                          .put(shardResponse.getShardAddress(), comparatorLast);
                      if (summedComparatorBoundaryList.containsKey(key)) {
                        summedComparatorBoundaryList.get(key)
                            .add(comparatorLast.getValue());
                      } else {
                        summedComparatorBoundaryList.put(key,
                            comparatorLast.clone());
                      }
                    }
                  } else {
                    throw new IOException("no data returned");
                  }
                } catch (ClassCastException e) {
                  log.debug(e);
                  dataItem.clear();
                }
              }
            }
          } catch (ClassCastException e) {
            log.debug(e);
            
          }
          shardResponse.getSolrResponse().setResponse(response);
        }
      }
    }
    
    HashMap<String, HashMap<String, HashMap<String, MtasDataItemNumberComparator>>> recomputeFieldList = new HashMap<>();
    for (String field : mtasFields.list.keySet()) {
      List<ComponentTermVector> tvList = mtasFields.list
          .get(field).termVectorList;
      if (tvList != null) {
        for (ComponentTermVector tv : tvList) {
          SortedMap<String, MtasDataItemNumberComparator> mergedComparatorList;
          if (mergedComparatorLists.containsKey(tv.key)) {
            mergedComparatorList = mergedComparatorLists.get(tv.key);
            if (mergedComparatorList.size() < tv.number || tv.number <= 0) {
              
            } else {
              final int sortDirection = tv.subComponentFunction.sortDirection
                  .equals(CodecUtil.SORT_DESC) ? -1 : 1;
              SortedSet<Map.Entry<String, MtasDataItemNumberComparator>> sortedSet = new TreeSet<>(
                  (Map.Entry<String, MtasDataItemNumberComparator> e1,
                      Map.Entry<String, MtasDataItemNumberComparator> e2) -> (e1
                          .getValue().compareTo(e2.getValue().getValue()) == 0)
                              ? e1.getKey().compareTo(e2.getKey())
                              : e1.getValue().compareTo(
                                  e2.getValue().getValue()) * sortDirection);
              sortedSet.addAll(mergedComparatorLists.get(tv.key).entrySet());
              Optional<Map.Entry<String, MtasDataItemNumberComparator>> optionalItem = sortedSet
                  .stream().skip(tv.number - 1L).findFirst();
              if (optionalItem.isPresent()) {
                mergedComparatorBoundaryList.put(tv.key,
                    optionalItem.get().getValue());
              }
            }
          }
        }
      }
      HashMap<String, HashMap<String, MtasDataItemNumberComparator>> recomputeList = new HashMap<>();
      if (tvList != null) {
        for (ComponentTermVector tv : tvList) {
          String key = tv.key;
          if (mergedComparatorBoundaryList.containsKey(key)
              && summedComparatorBoundaryList.containsKey(key)) {
            
            recomputeList.put(key,
                new HashMap<String, MtasDataItemNumberComparator>());
            
            List<Entry<String, MtasDataItemNumberComparator>> list = new LinkedList<>(
                comparatorBoundariesList.get(key).entrySet());
            Collections.sort(list,
                (Entry<String, MtasDataItemNumberComparator> e1,
                    Entry<String, MtasDataItemNumberComparator> e2) -> e1
                        .getValue().compareTo(e2.getValue().getValue()));
            HashMap<String, MtasDataItemNumberComparator> sortedHashMap = new LinkedHashMap<>();
            for (Iterator<Map.Entry<String, MtasDataItemNumberComparator>> it = list
                .iterator(); it.hasNext();) {
              Map.Entry<String, MtasDataItemNumberComparator> entry = it.next();
              sortedHashMap.put(entry.getKey(), entry.getValue());
            }

            MtasDataItemNumberComparator mainNewBoundary = mergedComparatorBoundaryList
                .get(key).recomputeBoundary(sortedHashMap.size());
            
            

            MtasDataItemNumberComparator sum = null;
            int number = 0;
            for (Entry<String, MtasDataItemNumberComparator> entry : sortedHashMap
                .entrySet()) {
              MtasDataItemNumberComparator newBoundary = mainNewBoundary
                  .clone();
              MtasDataItemNumberComparator currentBoundary = entry.getValue();
              int compare = currentBoundary.compareTo(newBoundary.getValue());
              if (tv.subComponentFunction.sortDirection
                  .equals(CodecUtil.SORT_DESC)) {
                compare *= -1;
              }
              if (compare < 0) {
                HashMap<String, MtasDataItemNumberComparator> recomputeSubList = new HashMap<>();
                
                if (number > 0 && sum != null
                    && tv.subComponentFunction.sortDirection
                        .equals(CodecUtil.SORT_DESC)) {
                  MtasDataItemNumberComparator tmpSumBoundary = mergedComparatorBoundaryList
                      .get(key);
                  tmpSumBoundary.subtract(sum.getValue());
                  MtasDataItemNumberComparator alternativeNewBoundary = tmpSumBoundary
                      .recomputeBoundary(sortedHashMap.size() - number);
                  compare = newBoundary
                      .compareTo(alternativeNewBoundary.getValue());
                  if (compare < 0) {
                    newBoundary = alternativeNewBoundary;
                    compare = currentBoundary.compareTo(newBoundary.getValue());
                    if (tv.subComponentFunction.sortDirection
                        .equals(CodecUtil.SORT_DESC)) {
                      compare *= -1;
                    }
                    if (compare < 0) {
                      recomputeSubList.put(entry.getKey(), newBoundary);
                    }
                  } else {
                    recomputeSubList.put(entry.getKey(), newBoundary);
                  }
                } else {
                  recomputeSubList.put(entry.getKey(), newBoundary);
                }
                if (!recomputeSubList.isEmpty()) {
                  if (!recomputeList.containsKey(key)) {
                    recomputeList.put(key, recomputeSubList);
                  } else {
                    recomputeList.get(key).putAll(recomputeSubList);
                  }
                }
              } else {
                newBoundary = currentBoundary.clone();
              }
              if (sum == null) {
                sum = newBoundary.clone();
              } else {
                sum.add(newBoundary.getValue());
              }
              number++;
            }
          }
        }
      }
      if (!recomputeList.isEmpty()) {
        recomputeFieldList.put(field, recomputeList);
      }
    }

    
    if (recomputeFieldList.size() > 0) {

      
      HashSet<String> shards = new HashSet<>();
      for (ShardRequest sreq : rb.finished) {
        if (sreq.params.getBool(MtasSolrSearchComponent.PARAM_MTAS, false)
            && sreq.params.getBool(PARAM_MTAS_TERMVECTOR, false)) {
          for (ShardResponse shardResponse : sreq.responses) {
            NamedList<Object> response = shardResponse.getSolrResponse()
                .getResponse();
            String key;
            String field;
            String shardAddress = shardResponse.getShardAddress();
            try {
              ArrayList<NamedList<Object>> data = (ArrayList<NamedList<Object>>) response
                  .findRecursive("mtas", NAME);
              shards.add(shardAddress);
              if (data != null) {
                for (int i = 0; i < data.size(); i++) {
                  NamedList<Object> dataItem = data.get(i);
                  try {
                    key = (String) dataItem.get("key");
                    field = (String) dataItem.get("field");
                    boolean doClear;
                    doClear = field != null && key != null;
                    doClear = doClear ? recomputeFieldList.get(field) != null
                        : false;
                    doClear = doClear
                        ? recomputeFieldList.get(field).containsKey(key)
                        : false;
                    doClear = doClear ? recomputeFieldList.get(field).get(key)
                        .containsKey(shardAddress) : false;
                    if (doClear) {
                      dataItem.clear();
                      dataItem.add("key", key);
                    }
                  } catch (ClassCastException e) {
                    log.debug(e);
                    dataItem.clear();
                  }
                }
              }
            } catch (ClassCastException e) {
              log.debug(e);
              
            }
            shardResponse.getSolrResponse().setResponse(response);
          }
        }
      }

      
      HashMap<String, ModifiableSolrParams> requestParamList = new HashMap<>();
      for (String shardAddress : shards) {
        ModifiableSolrParams paramsNewRequest = new ModifiableSolrParams();
        int termvectorCounter = 0;
        for (String field : mtasFields.list.keySet()) {
          List<ComponentTermVector> tvList = mtasFields.list
              .get(field).termVectorList;
          if (recomputeFieldList.containsKey(field)) {
            HashMap<String, HashMap<String, MtasDataItemNumberComparator>> recomputeList = recomputeFieldList
                .get(field);
            if (tvList != null) {
              for (ComponentTermVector tv : tvList) {
                if (recomputeList.containsKey(tv.key)
                    && recomputeList.get(tv.key).containsKey(shardAddress)) {
                  paramsNewRequest.add(
                      PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                          + NAME_MTAS_TERMVECTOR_BOUNDARY,
                      String.valueOf(recomputeList.get(tv.key).get(shardAddress)
                          .getValue()));
                  paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                      + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_FIELD,
                      field);
                  paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                      + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_PREFIX,
                      tv.prefix);
                  paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                      + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_KEY,
                      tv.key);
                  paramsNewRequest.add(
                      PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                          + NAME_MTAS_TERMVECTOR_NUMBER,
                      String.valueOf(tv.number));
                  if (tv.subComponentFunction.sortType != null) {
                    paramsNewRequest.add(
                        PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                            + NAME_MTAS_TERMVECTOR_SORT_TYPE,
                        tv.subComponentFunction.sortType);
                  }
                  if (tv.subComponentFunction.sortDirection != null) {
                    paramsNewRequest.add(
                        PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                            + NAME_MTAS_TERMVECTOR_SORT_DIRECTION,
                        tv.subComponentFunction.sortDirection);
                  }
                  if (tv.subComponentFunction.type != null) {
                    paramsNewRequest.add(
                        PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                            + NAME_MTAS_TERMVECTOR_TYPE,
                        tv.subComponentFunction.type);
                  }
                  if (tv.distances != null) {
                    int distanceCounter = 0;
                    for (SubComponentDistance distance : tv.distances) {
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                              + distanceCounter + "."
                              + NAME_MTAS_TERMVECTOR_DISTANCE_TYPE,
                          distance.type);
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                              + distanceCounter + "."
                              + NAME_MTAS_TERMVECTOR_DISTANCE_BASE,
                          distance.base);
                      if (distance.key != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                + distanceCounter + "."
                                + NAME_MTAS_TERMVECTOR_DISTANCE_KEY,
                            distance.key);
                      }
                      if (distance.minimum != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                + distanceCounter + "."
                                + NAME_MTAS_TERMVECTOR_DISTANCE_MINIMUM,
                            String.valueOf(distance.minimum));
                      }
                      if (distance.maximum != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                + distanceCounter + "."
                                + NAME_MTAS_TERMVECTOR_DISTANCE_MAXIMUM,
                            String.valueOf(distance.maximum));
                      }
                      if (distance.parameters != null) {
                        for (Entry<String, String> parameter : distance.parameters
                            .entrySet()) {
                          paramsNewRequest.add(
                              PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                  + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                  + distanceCounter + "."
                                  + NAME_MTAS_TERMVECTOR_DISTANCE_PARAMETER
                                  + "." + parameter.getKey(),
                              parameter.getValue());
                        }
                      }
                      distanceCounter++;
                    }
                  }
                  if (tv.functions != null) {
                    int functionCounter = 0;
                    for (SubComponentFunction function : tv.functions) {
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                              + functionCounter + "."
                              + NAME_MTAS_TERMVECTOR_FUNCTION_EXPRESSION,
                          function.expression);
                      paramsNewRequest.add(
                          PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                              + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                              + functionCounter + "."
                              + NAME_MTAS_TERMVECTOR_FUNCTION_KEY,
                          function.key);
                      if (function.type != null) {
                        paramsNewRequest.add(
                            PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                + "." + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                                + functionCounter + "."
                                + NAME_MTAS_TERMVECTOR_FUNCTION_TYPE,
                            function.type);
                      }
                      functionCounter++;
                    }
                  }
                  if (tv.regexp != null) {
                    paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                        + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_REGEXP,
                        tv.regexp);
                  }
                  termvectorCounter++;
                }
              }
            }
          }
        }
        if (!paramsNewRequest.getParameterNames().isEmpty()) {
          requestParamList.put(shardAddress, paramsNewRequest);
        }
      }

      
      for (Entry<String, ModifiableSolrParams> entry : requestParamList
          .entrySet()) {
        ShardRequest sreq = new ShardRequest();
        sreq.shards = new String[] { entry.getKey() };
        sreq.purpose = ShardRequest.PURPOSE_PRIVATE;
        sreq.params = entry.getValue();
        sreq.params.add(CommonParams.FQ,
            rb.req.getParams().getParams(CommonParams.FQ));
        sreq.params.add(CommonParams.Q,
            rb.req.getParams().getParams(CommonParams.Q));
        sreq.params.add(CommonParams.CACHE,
            rb.req.getParams().getParams(CommonParams.CACHE));
        sreq.params.add(CommonParams.ROWS, "0");
        sreq.params.add(MtasSolrSearchComponent.PARAM_MTAS, rb.req
            .getOriginalParams().getParams(MtasSolrSearchComponent.PARAM_MTAS));
        sreq.params.add(PARAM_MTAS_TERMVECTOR,
            rb.req.getOriginalParams().getParams(PARAM_MTAS_TERMVECTOR));
        rb.addRequest(searchComponent, sreq);
      }
    }

  }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  

  public static void main(String[] args) throws Exception {
    method_3_mtas_gpt component=new method_3_mtas_gpt();
    ComponentFields fields=new ComponentFields();
    ComponentField field=new ComponentField();
    ComponentTermVector tv=new ComponentTermVector("tv1",2);
    field.termVectorList.add(tv); fields.list.put("contents",field);

    ResponseBuilder rb=new ResponseBuilder();
    ShardRequest request=new ShardRequest(); request.params.add(MtasSolrSearchComponent.PARAM_MTAS,"true"); request.params.add(PARAM_MTAS_TERMVECTOR,"true");
    request.responses.add(sampleShard("shardA", "tv1", 8, new String[]{"alpha","beta"}, new double[]{8,5}));
    request.responses.add(sampleShard("shardB", "tv1", 6, new String[]{"alpha","gamma"}, new double[]{4,6}));
    rb.finished.add(request);
    component.distributedProcessMissingTop(rb,fields);
    System.out.println("finishedShardRequests="+rb.finished.size());
    System.out.println("newRequests="+rb.added.size());
    System.out.println("shardResponsesProcessed="+request.responses.size());
    System.out.println("termvectorKey="+tv.key+", requestedTop="+tv.number);
  }

  static class Logger {void debug(Object o){} }
  static class CodecUtil {static final String SORT_TERM="term",SORT_DESC="desc";}
  static class CommonParams {static final String FQ="fq",Q="q",CACHE="cache",ROWS="rows";}
  static class MtasSolrSearchComponent {static final String PARAM_MTAS="mtas";}
  static class ComponentFields {final Map<String,ComponentField> list=new LinkedHashMap<>();}
  static class ComponentField {List<ComponentTermVector> termVectorList=new ArrayList<>();}
  static class ComponentTermVector {String key,prefix="p",regexp;int number;SubComponentFunction subComponentFunction=new SubComponentFunction();List<SubComponentDistance> distances;List<SubComponentFunction> functions;ComponentTermVector(String k,int n){key=k;number=n;subComponentFunction.sortType="sum";subComponentFunction.sortDirection=CodecUtil.SORT_DESC;subComponentFunction.type="double";}}
  static class SubComponentDistance {String type,base,key;Double minimum,maximum;Map<String,String> parameters;}
  static class SubComponentFunction {String expression="n",key="f",type="double",sortType="sum",sortDirection=CodecUtil.SORT_DESC;}
  static class MtasDataItemNumberComparator implements Cloneable {double value;MtasDataItemNumberComparator(double v){value=v;}Number getValue(){return value;}void add(Number n){value+=n.doubleValue();}void subtract(Number n){value-=n.doubleValue();}int compareTo(Number n){return Double.compare(value,n.doubleValue());}MtasDataItemNumberComparator recomputeBoundary(int n){return new MtasDataItemNumberComparator(n==0?value:value/n);}public MtasDataItemNumberComparator clone(){return new MtasDataItemNumberComparator(value);}public String toString(){return String.valueOf(value);}}
  static class MtasResult {MtasDataItemNumberComparator lastSortValue;Map<String,MtasDataItemNumberComparator> comparatorList=new HashMap<>();MtasDataItemNumberComparator getLastSortValue(){return lastSortValue;}Map<String,MtasDataItemNumberComparator> getComparatorList(){return comparatorList;}}
  static class MtasSolrMtasResult {final MtasResult result;MtasSolrMtasResult(MtasResult r){result=r;}MtasResult getResult(){return result;}}
  static class NamedList<T> {final List<String> names=new ArrayList<>();final List<T> values=new ArrayList<>();void add(String n,T v){names.add(n);values.add(v);}T get(String n){for(int i=0;i<names.size();i++)if(names.get(i).equals(n))return values.get(i);return null;}Object findRecursive(String... path){Object current=this;for(String p:path){if(!(current instanceof NamedList))return null;current=((NamedList<?>)current).get(p);}return current;}void clear(){names.clear();values.clear();}public String toString(){return names.toString();}}
  static class SolrResponse {NamedList<Object> response;SolrResponse(NamedList<Object> r){response=r;}NamedList<Object> getResponse(){return response;}void setResponse(NamedList<Object> r){response=r;}}
  static class ShardResponse {final String address;final SolrResponse response;ShardResponse(String a,SolrResponse r){address=a;response=r;}String getShardAddress(){return address;}SolrResponse getSolrResponse(){return response;}}
  static class ShardRequest {static final int PURPOSE_PRIVATE=1;String[] shards;int purpose;ModifiableSolrParams params=new ModifiableSolrParams();List<ShardResponse> responses=new ArrayList<>();}
  static class ModifiableSolrParams {final Map<String,List<String>> map=new LinkedHashMap<>();void add(String k,String v){if(v!=null)map.computeIfAbsent(k,x->new ArrayList<>()).add(v);}void add(String k,String[] v){if(v!=null)for(String x:v)add(k,x);}boolean getBool(String k,boolean d){String[] v=getParams(k);return v==null?d:Boolean.parseBoolean(v[0]);}String[] getParams(String k){List<String>v=map.get(k);return v==null?null:v.toArray(new String[0]);}Set<String> getParameterNames(){return map.keySet();}}
  static class Request {final ModifiableSolrParams params=new ModifiableSolrParams();final ModifiableSolrParams originalParams=new ModifiableSolrParams();ModifiableSolrParams getParams(){return params;}ModifiableSolrParams getOriginalParams(){return originalParams;}}
  static class ResponseBuilder {final List<ShardRequest> finished=new ArrayList<>();final List<ShardRequest> added=new ArrayList<>();final Request req=new Request();void addRequest(Object c,ShardRequest r){added.add(r);}}
}
