import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TimeZone;
import java.util.TreeMap;


public class method_1_mtas_gpt {

  
  
  

  
  private static void createPositions(List<ComponentStatsPosition> list, Map<Integer,Integer> data, List<Integer> docs) {
    for (ComponentStatsPosition c : list) c.result = sumValues(data, docs);
  }
  private static void createTokens(List<ComponentStatsToken> list, Map<Integer,Integer> data, List<Integer> docs) {
    for (ComponentStatsToken c : list) c.result = sumValues(data, docs);
  }
  private static int sumValues(Map<Integer,Integer> data, List<Integer> docs) {
    int n=0; if(data!=null) for(Integer d: docs) n += data.getOrDefault(d,0); return n;
  }

  
  // ORIGINAL CODESEARCHNET METHOD — START
  
private static void collectSpansPositionsAndTokens(
      Map<MtasSpanQuery, SpanWeight> spansQueryWeight, IndexSearcher searcher,
      CodecInfo mtasCodecInfo, LeafReader r, LeafReaderContext lrc,
      String field, Terms t, List<Integer> docSet, List<Integer> docList,
      ComponentField fieldInfo, FieldInfos fieldInfos, Status status)
      throws IOException {

    boolean needSpans = false;
    boolean needPositions = false;
    boolean needTokens = false;

    
    Map<Integer, Integer> positionsData = null;
    Map<Integer, Integer> tokensData = null;
    Set<MtasSpanQuery> spansNumberByPositions = null;
    Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData = null;
    Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData = null;
    Map<String, SortedMap<String, int[]>> facetData = null;
    Map<String, String> facetDataType = null;

    
    if (!fieldInfo.statsPositionList.isEmpty()) {
      needPositions = true;
    }
    
    if (!fieldInfo.statsTokenList.isEmpty()) {
      needTokens = true;
    }
    if (!fieldInfo.termVectorList.isEmpty()) {
      for (ComponentTermVector ctv : fieldInfo.termVectorList) {
        if (!needPositions) {
          needPositions = (ctv.functions == null
              ? ctv.subComponentFunction.parserFunction.needPositions()
              : ctv.functionNeedPositions());
        }
      }
    }

    
    if (!fieldInfo.spanQueryList.isEmpty()) {
      
      spansNumberByPositions = new HashSet<>();
      spansNumberData = new HashMap<>();
      spansMatchData = new HashMap<>();
      facetData = new HashMap<>();
      facetDataType = new HashMap<>();
      
      if (!fieldInfo.statsSpanList.isEmpty()) {
        for (ComponentSpan cs : fieldInfo.statsSpanList) {
          needPositions = (!needPositions) ? cs.parser.needPositions()
              : needPositions;
          needPositions = (!needPositions) ? cs.functionNeedPositions()
              : needPositions;
          needSpans = (!needSpans) ? cs.parser.needArgumentsNumber() > 0
              : needSpans;
          HashSet<Integer> arguments = cs.parser.needArgument();
          arguments.addAll(cs.functionNeedArguments());
          for (int a : arguments) {
            if (cs.queries.length > a) {
              MtasSpanQuery q = cs.queries[a];
              if (!spansNumberData.containsKey(q)) {
                spansNumberData.put(q, new HashMap<Integer, Integer>());
              }
            }
          }
        }
      }
      
      if (!fieldInfo.kwicList.isEmpty()) {
        needSpans = true;
        for (ComponentKwic ck : fieldInfo.kwicList) {
          if (!spansMatchData.containsKey(ck.query)) {
            spansMatchData.put(ck.query, new HashMap<Integer, List<Match>>());
          }
        }
      }
      
      if (!fieldInfo.listList.isEmpty()) {
        needSpans = true;
        for (ComponentList cl : fieldInfo.listList) {
          if (!spansMatchData.containsKey(cl.spanQuery)) {
            if (cl.number > 0) {
              
              if (cl.position < (cl.start + cl.number)) {
                spansMatchData.put(cl.spanQuery,
                    new HashMap<Integer, List<Match>>());
              } else {
                spansNumberData.put(cl.spanQuery,
                    new HashMap<Integer, Integer>());
              }
            } else if (!spansNumberData.containsKey(cl.spanQuery)) {
              spansNumberData.put(cl.spanQuery,
                  new HashMap<Integer, Integer>());
            }
          }
        }
      }
      
      if (!fieldInfo.groupList.isEmpty()) {
        needSpans = true;
        for (ComponentGroup cg : fieldInfo.groupList) {
          if (!spansMatchData.containsKey(cg.spanQuery)) {
            spansMatchData.put(cg.spanQuery,
                new HashMap<Integer, List<Match>>());
          }
        }
      }
      
      if (!fieldInfo.facetList.isEmpty()) {
        for (ComponentFacet cf : fieldInfo.facetList) {
          needPositions = !needPositions ? cf.baseParserNeedPositions()
              : needPositions;
          needPositions = !needPositions ? cf.functionNeedPositions()
              : needPositions;
          for (int i = 0; i < cf.baseFields.length; i++) {
            needSpans = !needSpans ? cf.baseParsers[i].needArgumentsNumber() > 0
                : needSpans;
            HashSet<Integer> arguments = cf.baseParsers[i].needArgument();
            for (int a : arguments) {
              if (cf.spanQueries.length > a) {
                MtasSpanQuery q = cf.spanQueries[a];
                if (!spansNumberData.containsKey(q)) {
                  spansNumberData.put(q, new HashMap<Integer, Integer>());
                }
              }
            }
            for (MtasFunctionParserFunction function : cf.baseFunctionParserFunctions[i]) {
              needSpans = !needSpans ? function.needArgumentsNumber() > 0
                  : needSpans;
              arguments = function.needArgument();
              for (int a : arguments) {
                if (cf.spanQueries.length > a) {
                  MtasSpanQuery q = cf.spanQueries[a];
                  if (!spansNumberData.containsKey(q)) {
                    spansNumberData.put(q, new HashMap<Integer, Integer>());
                  }
                }
              }
            }
            if (!facetData.containsKey(cf.baseFields[i])) {
              facetData.put(cf.baseFields[i], new TreeMap<String, int[]>());
              facetDataType.put(cf.baseFields[i], cf.baseFieldTypes[i]);
            }
          }
        }
      }
      
      if (!fieldInfo.termVectorList.isEmpty()) {
        for (ComponentTermVector ctv : fieldInfo.termVectorList) {
          if ((ctv.subComponentFunction.parserFunction != null
              && ctv.subComponentFunction.parserFunction.needPositions())
              || (ctv.functions != null && ctv.functionNeedPositions())) {
            needPositions = true;
          }
        }
      }
    }

    if (needSpans) {
      Map<Integer, Integer> numberData;
      Map<Integer, List<Match>> matchData;
      
      for (Entry<String, SortedMap<String, int[]>> entry : facetData
          .entrySet()) {
        FieldInfo fi = fieldInfos.fieldInfo(entry.getKey());
        if (fi != null) {
          
          if (!fi.getDocValuesType().equals(DocValuesType.NONE)) {
            Iterator<Integer> docIterator = docSet.iterator();
            
            if (fi.getDocValuesType().equals(DocValuesType.NUMERIC)
                || fi.getDocValuesType().equals(DocValuesType.SORTED)
                || fi.getDocValuesType().equals(DocValuesType.SORTED_SET)
                || fi.getDocValuesType().equals(DocValuesType.SORTED_NUMERIC)
                || fi.getDocValuesType().equals(DocValuesType.BINARY)) {
              
              Map<Object, List<Integer>> facetDataSubList = new HashMap<>();
              
              if (fi.getDocValuesType().equals(DocValuesType.NUMERIC)) {
                NumericDocValues docValues = r.getContext().reader()
                    .getNumericDocValues(entry.getKey());
                int docId;
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docValues.advanceExact(docId)) {
                    long value = docValues.longValue();
                    if (!facetDataSubList.containsKey(value)) {
                      List<Integer> facetDataSubListItem = new ArrayList<>();
                      facetDataSubListItem.add(docId + lrc.docBase);
                      facetDataSubList.put(value, facetDataSubListItem);
                    } else {
                      facetDataSubList.get(value).add(docId + lrc.docBase);
                    }
                  }
                }
              
              } else if (fi.getDocValuesType().equals(DocValuesType.SORTED_NUMERIC)) {
                SortedNumericDocValues docValues = r.getContext().reader()
                    .getSortedNumericDocValues(entry.getKey());
                int docId;
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docValues.advanceExact(docId)) {
                    int n = docValues.docValueCount();
                    for(int i =0; i<n; i++) {
                      long value = docValues.nextValue();
                      if (!facetDataSubList.containsKey(value)) {
                        List<Integer> facetDataSubListItem = new ArrayList<>();
                        facetDataSubListItem.add(docId + lrc.docBase);
                        facetDataSubList.put(value, facetDataSubListItem);
                      } else {
                        facetDataSubList.get(value).add(docId + lrc.docBase);
                      }  
                    }                    
                  }
                }
             
              } else if (fi.getDocValuesType().equals(DocValuesType.SORTED_SET)) {
                SortedSetDocValues docValues = r.getContext().reader()
                    .getSortedSetDocValues(entry.getKey());
                int docId;
                Map<Long, String> dictionary = new HashMap<>();
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docValues.advanceExact(docId)) {
                    long tmpValue;
                    String value;
                    while((tmpValue=docValues.nextOrd()) != SortedSetDocValues.NO_MORE_ORDS) {
                      if(!dictionary.containsKey(tmpValue)) {
                        value = docValues.lookupOrd(tmpValue).utf8ToString();
                        dictionary.put(tmpValue, value);
                      } else {
                        value = dictionary.get(tmpValue);
                      }
                      if (!facetDataSubList.containsKey(value)) {
                        List<Integer> facetDataSubListItem = new ArrayList<>();
                        facetDataSubListItem.add(docId + lrc.docBase);
                        facetDataSubList.put(value, facetDataSubListItem);
                      } else {
                        facetDataSubList.get(value).add(docId + lrc.docBase);
                      }
                    }
                  }
                }
              
              } else if (fi.getDocValuesType().equals(DocValuesType.SORTED)) {
                SortedDocValues docValues = r.getContext().reader()
                    .getSortedDocValues(entry.getKey());
                int docId;
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docValues.advanceExact(docId)) {
                    String value = docValues.binaryValue().utf8ToString();
                    if (!facetDataSubList.containsKey(value)) {
                      List<Integer> facetDataSubListItem = new ArrayList<>();
                      facetDataSubListItem.add(docId + lrc.docBase);
                      facetDataSubList.put(value, facetDataSubListItem);
                    } else {
                      facetDataSubList.get(value).add(docId + lrc.docBase);
                    }
                  }
                }
              }
              if (!facetDataSubList.isEmpty()) {
                SortedMap<String, int[]> facetDataList = entry.getValue();
                SimpleDateFormat sdf = new SimpleDateFormat(
                    "yyyy-MM-dd'T'HH:mm:ss'Z'");
                sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
                for (Entry<Object, List<Integer>> facetEntry : facetDataSubList
                    .entrySet()) {
                  int[] docIdList = facetEntry.getValue().stream()
                      .mapToInt(i -> i).toArray();
                  String termValue;
                  if (facetDataType.get(entry.getKey())
                      .equals(NumberType.DATE.name())) {
                    Date date = new Date((Long) facetEntry.getKey());
                    termValue = sdf.format(date);
                  } else {
                    termValue = facetEntry.getKey().toString();
                  }
                  if (!facetDataList.containsKey(termValue)) {
                    facetDataList.put(termValue, docIdList);
                  } else {
                    int[] oldList = facetDataList.get(termValue);
                    int[] newList = new int[oldList.length + docIdList.length];
                    System.arraycopy(oldList, 0, newList, 0, oldList.length);
                    System.arraycopy(docIdList, 0, newList, oldList.length,
                        docIdList.length);
                    facetDataList.put(termValue, newList);
                  }
                }
              }
            } else {
              throw new IOException("facets for docValues of type "
                  + fi.getDocValuesType() + " not implemented");
            }
          } else if (!docSet.isEmpty()) {
            if (facetDataType.get(entry.getKey())
                .equals(ComponentFacet.TYPE_POINTFIELD_WITHOUT_DOCVALUES)) {
              throw new IOException(
                  "can't create facets for pointField without docValues");
            }
            Terms fft = r.terms(entry.getKey());
            if (fft != null) {
              TermsEnum termsEnum = fft.iterator();
              BytesRef term = null;
              PostingsEnum postingsEnum = null;
              SortedMap<String, int[]> facetDataList = entry.getValue();
              while ((term = termsEnum.next()) != null) {
                int docId;
                int termDocId = -1;
                int[] facetDataSublist = new int[docSet.size()];
                int facetDataSublistCounter = 0;
                Iterator<Integer> docIterator = docSet.iterator();
                postingsEnum = termsEnum.postings(postingsEnum);
                while (docIterator.hasNext()) {
                  docId = docIterator.next() - lrc.docBase;
                  if (docId >= termDocId
                      && ((docId == termDocId) || ((termDocId = postingsEnum
                          .advance(docId)) == docId))) {
                    facetDataSublist[facetDataSublistCounter] = docId
                        + lrc.docBase;
                    facetDataSublistCounter++;
                  }
                }
                if (facetDataSublistCounter > 0) {
                  String termValue = null;
                  if (facetDataType.get(entry.getKey())
                      .equals(NumberType.INTEGER.name())) {
                    
                    if (term.bytes[term.offset] == LegacyNumericUtils.SHIFT_START_INT) {
                      termValue = Integer
                          .toString(LegacyNumericUtils.prefixCodedToInt(term));
                    } else {
                      continue;
                    }
                  } else if (facetDataType.get(entry.getKey())
                      .equals(NumberType.LONG.name())) {
                    if (term.bytes[term.offset] == LegacyNumericUtils.SHIFT_START_LONG) {
                      termValue = Long
                          .toString(LegacyNumericUtils.prefixCodedToLong(term));
                    } else {
                      continue;
                    }
                  } else {
                    termValue = term.utf8ToString();
                  }
                  if (!facetDataList.containsKey(termValue)) {
                    facetDataList.put(termValue, Arrays.copyOf(facetDataSublist,
                        facetDataSublistCounter));
                  } else {
                    int[] oldList = facetDataList.get(termValue);
                    int[] newList = new int[oldList.length
                        + facetDataSublistCounter];
                    System.arraycopy(oldList, 0, newList, 0, oldList.length);
                    System.arraycopy(facetDataSublist, 0, newList,
                        oldList.length, facetDataSublistCounter);
                    facetDataList.put(termValue, newList);
                  }
                }
              }
            }
          }
        }
      }

      
      for (MtasSpanQuery sq : fieldInfo.spanQueryList) {
        
        if (spansNumberData.containsKey(sq)) {
          numberData = spansNumberData.get(sq);
        } else {
          numberData = null;
        }
        
        if (spansMatchData.containsKey(sq)) {
          matchData = spansMatchData.get(sq);
        } else {
          matchData = null;
        }
        boolean doNormalCollection = true;
        
        if ((numberData != null) && (matchData == null)) {
          if (sq.isMatchAllPositionsQuery()) {
            spansNumberByPositions.add(sq);
            needPositions = true;
            doNormalCollection = false;
          }
        }
        
        if (doNormalCollection
            && ((numberData != null) || (matchData != null))) {
          Spans spans = spansQueryWeight.get(sq).getSpans(lrc,
              SpanWeight.Postings.POSITIONS);
          if (spans != null) {
            Iterator<Integer> it;
            if (docSet != null) {
              it = docSet.iterator();
            } else {
              it = docList.iterator();
            }
            if (it.hasNext()) {
              int docId = it.next();
              int number;
              ArrayList<Match> matchDataList;
              Integer spansDocId = null;
              while (docId != DocIdSetIterator.NO_MORE_DOCS) {
                if (spans.advance(
                    (docId - lrc.docBase)) == DocIdSetIterator.NO_MORE_DOCS) {
                  break;
                }
                spansDocId = spans.docID() + lrc.docBase;
                while ((docId < spansDocId) && it.hasNext()) {
                  docId = it.next();
                }
                if (docId < spansDocId) {
                  break;
                }
                if (spansDocId.equals(docId)) {
                  number = 0;
                  matchDataList = new ArrayList<>();
                  int tmpStartPosition;
                  while ((tmpStartPosition = spans
                      .nextStartPosition()) != Spans.NO_MORE_POSITIONS) {
                    number++;
                    if (matchData != null) {
                      Match m = new Match(tmpStartPosition,
                          spans.endPosition());
                      matchDataList.add(m);
                    }
                  }
                  if ((numberData != null)) {
                    numberData.put(spansDocId, number);
                  }
                  if ((matchData != null)) {
                    matchData.put(spansDocId, matchDataList);
                  }
                  if (it.hasNext()) {
                    docId = it.next();
                  } else {
                    break;
                  }
                }
              }
            }
          }
        }
      }
    }

    
    if (needPositions) {
      if (mtasCodecInfo != null) {
        
        if (docSet.size() < Math.log(r.maxDoc())) {
          positionsData = new HashMap<>();
          for (int docId : docSet) {
            positionsData.put(docId, mtasCodecInfo.getNumberOfPositions(field,
                (docId - lrc.docBase)));
          }
          
        } else {
          positionsData = mtasCodecInfo.getAllNumberOfPositions(field,
              lrc.docBase);
          for (int docId : docSet) {
            if (!positionsData.containsKey(docId)) {
              positionsData.put(docId, 0);
            }
          }
        }
      } else {
        positionsData = new HashMap<>();
        for (int docId : docSet) {
          positionsData.put(docId, 0);
        }
      }
      if (spansNumberByPositions != null && spansNumberData != null) {        
        for (MtasSpanQuery sq : spansNumberByPositions) {
          Map<Integer,Integer> numberData = spansNumberData.get(sq);
          positionsData.forEach((k,v) -> numberData.put(k,v!=null?v:0));          
        }
      }
    }

    
    if (needTokens) {
      if (mtasCodecInfo != null) {
        
        if (docSet.size() < Math.log(r.maxDoc())) {
          tokensData = new HashMap<>();
          for (int docId : docSet) {
            tokensData.put(docId,
                mtasCodecInfo.getNumberOfTokens(field, (docId - lrc.docBase)));
          }
          
        } else {
          tokensData = mtasCodecInfo.getAllNumberOfTokens(field, lrc.docBase);
          for (int docId : docSet) {
            if (!tokensData.containsKey(docId)) {
              tokensData.put(docId, 0);
            }
          }
        }
      } else {
        tokensData = new HashMap<>();
        for (int docId : docSet) {
          tokensData.put(docId, 0);
        }
      }
    }

    if (!fieldInfo.statsPositionList.isEmpty()) {
      
      createPositions(fieldInfo.statsPositionList, positionsData, docSet);
    }

    if (!fieldInfo.statsTokenList.isEmpty()) {
      
      createTokens(fieldInfo.statsTokenList, tokensData, docSet);
    }

    if (!fieldInfo.documentList.isEmpty()) {
      
      createDocument(fieldInfo.documentList, docList, fieldInfo.uniqueKeyField,
          searcher, t, lrc);
    }
    if (!fieldInfo.spanQueryList.isEmpty()) {
      if (!fieldInfo.statsSpanList.isEmpty()) {
        
        createStats(fieldInfo.statsSpanList, positionsData, spansNumberData,
            docSet.toArray(new Integer[docSet.size()]));
      }
      if (!fieldInfo.listList.isEmpty()) {
        
        createList(fieldInfo.listList, spansNumberData, spansMatchData, docSet,
            field, lrc.docBase, fieldInfo.uniqueKeyField, mtasCodecInfo,
            searcher);
      }
      if (!fieldInfo.groupList.isEmpty()) {
        
        createGroup(fieldInfo.groupList, spansMatchData, docSet,
            fieldInfos.fieldInfo(field), field, lrc.docBase, mtasCodecInfo,
            searcher, lrc, status);
      }
      if (!fieldInfo.kwicList.isEmpty()) {
        
        createKwic(fieldInfo.kwicList, spansMatchData, docList, field,
            lrc.docBase, fieldInfo.uniqueKeyField, mtasCodecInfo, searcher);
      }
      if (!fieldInfo.facetList.isEmpty()) {
        
        createFacet(fieldInfo.facetList, positionsData, spansNumberData,
            facetData, docSet);
      }
    }
    if (!fieldInfo.termVectorList.isEmpty()) {
      createTermvectorFull(fieldInfo.termVectorList, positionsData, docSet, t,
          r, lrc);
      createTermvectorFirstRound(fieldInfo.termVectorList, positionsData,
          docSet, t, r, lrc);
    }
  }
  
  // ORIGINAL CODESEARCHNET METHOD — END
  


  
  
  
  
  
  
  
  

  private static void createDocument(List<ComponentDocument> list, List<Integer> docs, String uniqueKeyField,
      IndexSearcher searcher, Terms t, LeafReaderContext lrc) {
    for(ComponentDocument c:list) c.documents = new ArrayList<>(docs);
  }
  private static void createStats(List<ComponentSpan> list, Map<Integer,Integer> positions,
      Map<MtasSpanQuery,Map<Integer,Integer>> numbers, Integer[] docs) {
    for(ComponentSpan c:list) c.result = docs.length;
  }
  private static void createList(List<ComponentList> list,
      Map<MtasSpanQuery,Map<Integer,Integer>> numbers,
      Map<MtasSpanQuery,Map<Integer,List<Match>>> matches, List<Integer> docs,
      String field, int docBase, String uniqueKeyField, CodecInfo codecInfo,
      IndexSearcher searcher) {
    for(ComponentList c:list) c.collected = matches.getOrDefault(c.spanQuery, Collections.emptyMap());
  }
  private static void createGroup(List<ComponentGroup> list,
      Map<MtasSpanQuery,Map<Integer,List<Match>>> matches, List<Integer> docs,
      FieldInfo fieldInfo, String field, int docBase, CodecInfo codecInfo,
      IndexSearcher searcher, LeafReaderContext lrc, Status status) {
    for(ComponentGroup c:list) c.collected = matches.getOrDefault(c.spanQuery, Collections.emptyMap());
  }
  private static void createKwic(List<ComponentKwic> list,
      Map<MtasSpanQuery,Map<Integer,List<Match>>> matches, List<Integer> docs,
      String field, int docBase, String uniqueKeyField, CodecInfo codecInfo,
      IndexSearcher searcher) {
    for(ComponentKwic c:list) c.collected = matches.getOrDefault(c.query, Collections.emptyMap());
  }
  private static void createFacet(List<ComponentFacet> list, Map<Integer,Integer> positions,
      Map<MtasSpanQuery,Map<Integer,Integer>> numbers,
      Map<String,SortedMap<String,int[]>> facets, List<Integer> docs) {
    for(ComponentFacet c:list) c.result = facets;
  }
  private static void createTermvectorFull(List<ComponentTermVector> list,
      Map<Integer,Integer> positions, List<Integer> docs, Terms t, LeafReader r,
      LeafReaderContext lrc) { for(ComponentTermVector c:list) c.fullRoundExecuted=true; }
  private static void createTermvectorFirstRound(List<ComponentTermVector> list,
      Map<Integer,Integer> positions, List<Integer> docs, Terms t, LeafReader r,
      LeafReaderContext lrc) { for(ComponentTermVector c:list) c.firstRoundExecuted=true; }

  static final class Match {
    final int startPosition, endPosition;
    Match(int startPosition,int endPosition){this.startPosition=startPosition;this.endPosition=endPosition;}
    public String toString(){return startPosition+"-"+endPosition;}
  }
  static final class Status { }
  static class Parser {
    boolean needPositions; int argumentsNumber; HashSet<Integer> arguments=new HashSet<>();
    boolean needPositions(){return needPositions;}
    int needArgumentsNumber(){return argumentsNumber;}
    HashSet<Integer> needArgument(){return new HashSet<>(arguments);}
  }
  static final class MtasFunctionParserFunction extends Parser { }
  static final class SubComponentFunction { MtasFunctionParserFunction parserFunction = new MtasFunctionParserFunction(); }
  static final class ComponentStatsPosition { int result; }
  static final class ComponentStatsToken { int result; }
  static final class ComponentDocument { List<Integer> documents=Collections.emptyList(); }
  static final class ComponentSpan {
    Parser parser=new Parser(); MtasSpanQuery[] queries=new MtasSpanQuery[0]; int result;
    boolean functionNeedPositions(){return false;} HashSet<Integer> functionNeedArguments(){return new HashSet<>();}
  }
  static final class ComponentKwic { MtasSpanQuery query; Map<Integer,List<Match>> collected; ComponentKwic(MtasSpanQuery q){query=q;} }
  static final class ComponentList {
    MtasSpanQuery spanQuery; int number,position,start; Map<Integer,List<Match>> collected;
    ComponentList(MtasSpanQuery q){spanQuery=q;number=10;}
  }
  static final class ComponentGroup { MtasSpanQuery spanQuery; Map<Integer,List<Match>> collected; ComponentGroup(MtasSpanQuery q){spanQuery=q;} }
  static final class ComponentFacet {
    static final String TYPE_POINTFIELD_WITHOUT_DOCVALUES="POINTFIELD_WITHOUT_DOCVALUES";
    String[] baseFields=new String[0], baseFieldTypes=new String[0]; Parser[] baseParsers=new Parser[0];
    MtasSpanQuery[] spanQueries=new MtasSpanQuery[0]; MtasFunctionParserFunction[][] baseFunctionParserFunctions=new MtasFunctionParserFunction[0][];
    Map<String,SortedMap<String,int[]>> result;
    boolean baseParserNeedPositions(){return false;} boolean functionNeedPositions(){return false;}
  }
  static final class ComponentTermVector {
    Object[] functions; SubComponentFunction subComponentFunction=new SubComponentFunction(); boolean fullRoundExecuted,firstRoundExecuted;
    boolean functionNeedPositions(){return false;}
  }
  static final class ComponentField {
    List<ComponentStatsPosition> statsPositionList=new ArrayList<>();
    List<ComponentStatsToken> statsTokenList=new ArrayList<>();
    List<ComponentTermVector> termVectorList=new ArrayList<>();
    List<MtasSpanQuery> spanQueryList=new ArrayList<>();
    List<ComponentSpan> statsSpanList=new ArrayList<>();
    List<ComponentKwic> kwicList=new ArrayList<>();
    List<ComponentList> listList=new ArrayList<>();
    List<ComponentGroup> groupList=new ArrayList<>();
    List<ComponentFacet> facetList=new ArrayList<>();
    List<ComponentDocument> documentList=new ArrayList<>();
    String uniqueKeyField="id";
  }
  static final class MtasSpanQuery {
    final String name; final boolean matchAll; MtasSpanQuery(String n,boolean m){name=n;matchAll=m;}
    boolean isMatchAllPositionsQuery(){return matchAll;}
    public String toString(){return name;}
  }
  static class CodecInfo {
    Map<Integer,Integer> positions=new HashMap<>(),tokens=new HashMap<>();
    int getNumberOfPositions(String field,int doc){return positions.getOrDefault(doc,0);}
    Map<Integer,Integer> getAllNumberOfPositions(String field,int base){return shifted(positions,base);}
    int getNumberOfTokens(String field,int doc){return tokens.getOrDefault(doc,0);}
    Map<Integer,Integer> getAllNumberOfTokens(String field,int base){return shifted(tokens,base);}
    private Map<Integer,Integer> shifted(Map<Integer,Integer> m,int b){Map<Integer,Integer> r=new HashMap<>();m.forEach((k,v)->r.put(k+b,v));return r;}
  }
  static final class IndexSearcher { }
  static final class LeafReaderContext { final int docBase; final LeafReader reader; LeafReaderContext(LeafReader r,int b){reader=r;docBase=b;} LeafReader reader(){return reader;} }
  static class LeafReader {
    final int maxDoc; final LeafReaderContext context; final Map<String,FieldValues> values=new HashMap<>();
    LeafReader(int maxDoc){this.maxDoc=maxDoc;context=new LeafReaderContext(this,0);} int maxDoc(){return maxDoc;}
    LeafReaderContext getContext(){return context;} Terms terms(String field){return values.containsKey(field)?values.get(field).terms:null;}
    NumericDocValues getNumericDocValues(String f){return new NumericDocValues(values.get(f));}
    SortedNumericDocValues getSortedNumericDocValues(String f){return new SortedNumericDocValues(values.get(f));}
    SortedSetDocValues getSortedSetDocValues(String f){return new SortedSetDocValues(values.get(f));}
    SortedDocValues getSortedDocValues(String f){return new SortedDocValues(values.get(f));}
  }
  static final class FieldValues { DocValuesType type=DocValuesType.NONE; Map<Integer,List<Object>> byDoc=new HashMap<>(); Terms terms; }
  enum DocValuesType { NONE,NUMERIC,SORTED,SORTED_SET,SORTED_NUMERIC,BINARY }
  static final class FieldInfo { final DocValuesType type; FieldInfo(DocValuesType t){type=t;} DocValuesType getDocValuesType(){return type;} }
  static final class FieldInfos { final Map<String,FieldInfo> map=new HashMap<>(); FieldInfo fieldInfo(String n){return map.get(n);} }
  static class NumericDocValues { final FieldValues v; int doc; NumericDocValues(FieldValues v){this.v=v;} boolean advanceExact(int d){doc=d;return v!=null&&v.byDoc.containsKey(d);} long longValue(){return ((Number)v.byDoc.get(doc).get(0)).longValue();} }
  static class SortedNumericDocValues extends NumericDocValues { int i; SortedNumericDocValues(FieldValues v){super(v);} boolean advanceExact(int d){i=0;return super.advanceExact(d);} int docValueCount(){return v.byDoc.get(doc).size();} long nextValue(){return ((Number)v.byDoc.get(doc).get(i++)).longValue();} }
  static class SortedDocValues extends NumericDocValues { SortedDocValues(FieldValues v){super(v);} BytesRef binaryValue(){return new BytesRef(v.byDoc.get(doc).get(0).toString());} }
  static class SortedSetDocValues extends NumericDocValues { static final long NO_MORE_ORDS=-1; int i; List<String> cur; SortedSetDocValues(FieldValues v){super(v);} boolean advanceExact(int d){boolean b=super.advanceExact(d);i=0;if(b){cur=new ArrayList<>();for(Object o:v.byDoc.get(d))cur.add(o.toString());}return b;} long nextOrd(){return i<cur.size()?i++:NO_MORE_ORDS;} BytesRef lookupOrd(long ord){return new BytesRef(cur.get((int)ord));} }
  static final class BytesRef { byte[] bytes; int offset; BytesRef(String s){bytes=s.getBytes(java.nio.charset.StandardCharsets.UTF_8);} String utf8ToString(){return new String(bytes,java.nio.charset.StandardCharsets.UTF_8);} }
  static class Terms { TermsEnum iterator(){return new TermsEnum();} }
  static class TermsEnum { BytesRef next(){return null;} PostingsEnum postings(PostingsEnum reuse){return new PostingsEnum();} }
  static class PostingsEnum { int advance(int target){return DocIdSetIterator.NO_MORE_DOCS;} }
  static class DocIdSetIterator { static final int NO_MORE_DOCS=Integer.MAX_VALUE; }
  static class SpanWeight { enum Postings { POSITIONS } Spans spans; Spans getSpans(LeafReaderContext c,Postings p){return spans;} }
  static class Spans extends DocIdSetIterator { static final int NO_MORE_POSITIONS=Integer.MAX_VALUE; int docID(){return NO_MORE_DOCS;} int advance(int target){return NO_MORE_DOCS;} int nextStartPosition(){return NO_MORE_POSITIONS;} int endPosition(){return NO_MORE_POSITIONS;} }
  enum NumberType { DATE,INTEGER,LONG }
  static final class LegacyNumericUtils {
    static final byte SHIFT_START_INT=0,SHIFT_START_LONG=0;
    static int prefixCodedToInt(BytesRef b){return Integer.parseInt(b.utf8ToString());}
    static long prefixCodedToLong(BytesRef b){return Long.parseLong(b.utf8ToString());}
  }

  
  
  

  
  
  
  public static void main(String[] args) throws Exception {
    LeafReader reader=new LeafReader(3); LeafReaderContext lrc=reader.getContext();
    CodecInfo codec=new CodecInfo(); codec.positions.put(0,4);codec.positions.put(1,2); codec.tokens.put(0,7);codec.tokens.put(1,5);
    ComponentField field=new ComponentField();
    ComponentStatsPosition ps=new ComponentStatsPosition(); field.statsPositionList.add(ps);
    ComponentStatsToken ts=new ComponentStatsToken(); field.statsTokenList.add(ts);
    ComponentDocument ds=new ComponentDocument(); field.documentList.add(ds);
    ComponentTermVector tv=new ComponentTermVector(); field.termVectorList.add(tv);
    List<Integer> docs=Arrays.asList(0,1);
    collectSpansPositionsAndTokens(new HashMap<>(),new IndexSearcher(),codec,reader,lrc,"contents",new Terms(),docs,docs,field,new FieldInfos(),new Status());
    System.out.println("positions="+ps.result);
    System.out.println("tokens="+ts.result);
    System.out.println("documents="+ds.documents);
    System.out.println("termvectorFull="+tv.fullRoundExecuted+", firstRound="+tv.firstRoundExecuted);
  }
  
  
  
}
