
















import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class method_1_aerogear_pipe_gpt {
    static class JSONObject extends LinkedHashMap<String,Object> {}
    interface Pipe<T> {}
    static class HeaderAndBody { final Map<String,String> headers=new HashMap<>(); }
    static class ReadFilter { URI linkUri; JSONObject where; void setLinkUri(URI u){linkUri=u;} void setWhere(JSONObject w){where=w;} public String toString(){return String.valueOf(linkUri);} }
    static class WebLink { final String uri; final Map<String,String> parameters=new HashMap<>(); WebLink(String u,String rel){uri=u;parameters.put("rel",rel);} String getUri(){return uri;} Map<String,String> getParameters(){return parameters;} }
    static class WebLinkParser { static List<WebLink> parse(String raw)throws ParseException { List<WebLink> result=new ArrayList<>(); for(String part:raw.split(",")){String[] pieces=part.trim().split(";"); if(pieces.length<2)throw new ParseException(raw,0); String uri=pieces[0].replace("<","").replace(">",""); String rel=pieces[1].replace("rel=","").replace("\"",""); result.add(new WebLink(uri,rel));} return result;} }
    static class Log { static void e(String tag,String message,Exception ex){System.out.println(tag+": "+message);} }
    static class PageConfig { enum MetadataLocations {WEB_LINKING,HEADERS,BODY} MetadataLocations metadataLocation=MetadataLocations.WEB_LINKING; String getNextIdentifier(){return "next";} String getPreviousIdentifier(){return "prev";} MetadataLocations getMetadataLocation(){return metadataLocation;} Extractor getPageParameterExtractor(){return new Extractor();} static class Extractor { ReadFilter getNextFilter(HeaderAndBody h,PageConfig p){return null;} ReadFilter getPreviousFilter(HeaderAndBody h,PageConfig p){return null;} } }
    static class WrappingPagedList<T> extends ArrayList<T> { final ReadFilter next,previous; WrappingPagedList(Pipe<T> p,List<T> values,ReadFilter n,ReadFilter prev){super(values);next=n;previous=prev;} public String toString(){return super.toString()+" next="+next+" prev="+previous;} }
    static class RestAdapter<T> {
        static final String TAG="RestAdapter";
        final PageConfig pageConfig=new PageConfig();
        String getWebLinkHeader(HeaderAndBody response){return response.headers.get("Link");}
        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private List<T> computePagedList(List<T> result, HeaderAndBody httpResponse, JSONObject where, Pipe<T> requestingPipe) {
                ReadFilter previousRead = null;
                ReadFilter nextRead = null;
        
                if (PageConfig.MetadataLocations.WEB_LINKING.equals(pageConfig.getMetadataLocation())) {
                    String webLinksRaw = "";
                    final String relHeader = "rel";
                    final String nextIdentifier = pageConfig.getNextIdentifier();
                    final String prevIdentifier = pageConfig.getPreviousIdentifier();
                    try {
                        webLinksRaw = getWebLinkHeader(httpResponse);
                        if (webLinksRaw == null) { 
                            return result;
                        }
                        List<WebLink> webLinksParsed = WebLinkParser.parse(webLinksRaw);
                        for (WebLink link : webLinksParsed) {
                            if (nextIdentifier.equals(link.getParameters().get(relHeader))) {
                                nextRead = new ReadFilter();
                                nextRead.setLinkUri(new URI(link.getUri()));
                            } else if (prevIdentifier.equals(link.getParameters().get(relHeader))) {
                                previousRead = new ReadFilter();
                                previousRead.setLinkUri(new URI(link.getUri()));
                            }
        
                        }
                    } catch (URISyntaxException ex) {
                        Log.e(TAG, webLinksRaw + " did not contain a valid context URI", ex);
                        throw new RuntimeException(ex);
                    } catch (ParseException ex) {
                        Log.e(TAG, webLinksRaw + " could not be parsed as a web link header", ex);
                        throw new RuntimeException(ex);
                    }
                } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.HEADERS)) {
                    nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, RestAdapter.this.pageConfig);
                    previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, RestAdapter.this.pageConfig);
                } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.BODY)) {
                    nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, RestAdapter.this.pageConfig);
                    previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, RestAdapter.this.pageConfig);
                } else {
                    throw new IllegalStateException("Not supported");
                }
                if (nextRead != null) {
                    nextRead.setWhere(where);
                }
        
                if (previousRead != null) {
                    previousRead.setWhere(where);
                }
        
                return new WrappingPagedList<T>(requestingPipe, result, nextRead, previousRead);
            }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }
    public static void main(String[] args) {
    RestAdapter<String> adapter = new RestAdapter<>();
    HeaderAndBody response = new HeaderAndBody();
    response.headers.put("Link", "<https://api/items?page=2>;rel=\"next\", <https://api/items?page=0>;rel=\"prev\"");
    List<String> pageData = Arrays.asList("a", "b");
    System.out.println("METHOD: RestAdapter.computePagedList");
    System.out.println("INPUT page data: " + pageData);
    System.out.println("INPUT Link header: " + response.headers.get("Link"));
    List<String> result = adapter.computePagedList(pageData, response, new JSONObject(), new Pipe<String>(){});
    WrappingPagedList<String> paged = (WrappingPagedList<String>) result;
    System.out.println("RESULT paged list values: " + result);
    System.out.println("RESULT next-page URL: " + paged.next);
    System.out.println("RESULT previous-page URL: " + paged.previous);
}
}
