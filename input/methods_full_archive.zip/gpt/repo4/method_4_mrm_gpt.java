
















import java.io.*;import java.text.*;import java.util.*;
public class method_4_mrm_gpt {static class Metadata{String groupId,artifactId,version;List<Plugin>plugins;Versioning versioning;void setGroupId(String v){groupId=v;}String getGroupId(){return groupId;}void setArtifactId(String v){artifactId=v;}String getArtifactId(){return artifactId;}void setVersion(String v){version=v;}String getVersion(){return version;}void setPlugins(List<Plugin>v){plugins=v;}List<Plugin>getPlugins(){return plugins;}void addPlugin(Plugin p){if(plugins==null)plugins=new ArrayList<>();plugins.add(p);}void setVersioning(Versioning v){versioning=v;}Versioning getVersioning(){return versioning;}}static class Plugin{String artifactId,name,prefix;void setArtifactId(String v){artifactId=v;}String getArtifactId(){return artifactId;}void setName(String v){name=v;}void setPrefix(String v){prefix=v;}public String toString(){return artifactId+":"+prefix;}}static class Versioning{List<String>versions=new ArrayList<>();String latest,release,lastUpdated;Snapshot snapshot;List<SnapshotVersion>sv=new ArrayList<>();void addVersion(String v){versions.add(v);}List<String>getVersions(){return versions;}void setLatest(String v){latest=v;}String getLatest(){return latest;}void setRelease(String v){release=v;}String getRelease(){return release;}void setLastUpdated(String v){lastUpdated=v;}String getLastUpdated(){return lastUpdated;}void setLastUpdatedTimestamp(Date d){lastUpdated=new java.text.SimpleDateFormat("yyyyMMddHHmmss").format(d);}void setSnapshot(Snapshot s){snapshot=s;}Snapshot getSnapshot(){return snapshot;}List<SnapshotVersion>getSnapshotVersions(){return sv;}void addSnapshotVersion(SnapshotVersion x){sv.add(x);}}static class Snapshot{int buildNumber;String timestamp;void setBuildNumber(int v){buildNumber=v;}int getBuildNumber(){return buildNumber;}void setTimestamp(String v){timestamp=v;}String getTimestamp(){return timestamp;}}static class SnapshotVersion{String version,classifier,extension;String getVersion(){return version;}String getClassifier(){return classifier;}String getExtension(){return extension;}}static class MetadataNotFoundException extends Exception{MetadataNotFoundException(String s){super(s);}}static class ArtifactNotFoundException extends Exception{}static class Artifact{String g,a,v,t;Integer buildNumber;String timestamp;Artifact(String g,String a,String v,String t){this.g=g;this.a=a;this.v=v;this.t=t;}String getType(){return t;}Integer getBuildNumber(){return buildNumber;}String getTimestampString(){return timestamp;}public int hashCode(){return Objects.hash(g,a,v,t);}public boolean equals(Object o){if(!(o instanceof Artifact))return false;Artifact x=(Artifact)o;return Objects.equals(g,x.g)&&Objects.equals(a,x.a)&&Objects.equals(v,x.v)&&Objects.equals(t,x.t);}}static class Content{long lm;Content(long x){lm=x;}long getLastModified(){return lm;}}static class VersionComparator implements Comparator<String>{public int compare(String a,String b){return a.compareTo(b);}}static class StringUtils{static String stripStart(String s,String x){while(s.startsWith(x))s=s.substring(x.length());return s;}static String stripEnd(String s,String x){while(s.endsWith(x))s=s.substring(0,s.length()-x.length());return s;}static String removeStart(String s,String x){return s.startsWith(x)?s.substring(x.length()):s;}static String removeEnd(String s,String x){return s.endsWith(x)?s.substring(0,s.length()-x.length()):s;}static boolean isEmpty(String s){return s==null||s.isEmpty();}static String repeat(String s,int n){return s.repeat(n);}static String leftPad(String s,int n){return " ".repeat(Math.max(0,n-s.length()))+s;}}Map<String,Map<String,Map<String,Map<Artifact,Content>>>>contents=new HashMap<>();Map<String,Set<String>>ids=new HashMap<>();Map<String,Set<String>>vers=new HashMap<>();Set<String>getArtifactIds(String g){return ids.get(g);}Set<String>getVersions(String g,String a){return vers.get(g+":"+a);}InputStream get(Artifact a)throws ArtifactNotFoundException{return new ByteArrayInputStream(("<project><name>Demo Plugin</name><packaging>maven-plugin</packaging></project>").getBytes());}long getLastModified(Artifact a)throws ArtifactNotFoundException{return 1000L+Math.abs(a.v.hashCode());}static class XmlPullParserException extends Exception{}static class XmlStreamReader extends Reader{Reader r;XmlStreamReader(InputStream i){r=new InputStreamReader(i);}public int read(char[]c,int o,int l)throws IOException{return r.read(c,o,l);}public void close()throws IOException{r.close();}}static class Model{String name="Demo Plugin",packaging="maven-plugin";Build build;String getName(){return name;}String getPackaging(){return packaging;}Build getBuild(){return build;}}static class Build{List<PomPlugin>p;PluginManagement pm;List<PomPlugin>getPlugins(){return p;}PluginManagement getPluginManagement(){return pm;}}static class PomPlugin{}static class PluginManagement{List<PomPlugin>getPlugins(){return null;}}static class MavenXpp3Reader{Model read(Reader r)throws XmlPullParserException{return new Model();}}boolean setPluginGoalPrefixFromConfiguration(Plugin p,List<PomPlugin>x){return false;}static class IOUtils{static void closeQuietly(Closeable c){try{if(c!=null)c.close();}catch(Exception e){}}}static class Maven3{static void addSnapshotVersion(List<SnapshotVersion>s,Artifact a,String l){SnapshotVersion v=new SnapshotVersion();v.version=a.v;v.extension=a.t;s.add(v);}static void addSnapshotVersions(Versioning v,List<SnapshotVersion>s){for(SnapshotVersion x:s)v.addSnapshotVersion(x);}}


// ORIGINAL CODESEARCHNET METHOD — START

public synchronized Metadata getMetadata( String path )
        throws IOException, MetadataNotFoundException
    {
        Metadata metadata = new Metadata();
        boolean foundMetadata = false;
        path = StringUtils.stripEnd( StringUtils.stripStart( path, "/" ), "/" );
        String groupId = path.replace( '/', '.' );
        Set<String> pluginArtifactIds = getArtifactIds( groupId );
        if ( pluginArtifactIds != null )
        {
            List<Plugin> plugins = new ArrayList<Plugin>();
            for ( String artifactId : pluginArtifactIds )
            {
                Set<String> pluginVersions = getVersions( groupId, artifactId );
                if ( pluginVersions == null || pluginVersions.isEmpty() )
                {
                    continue;
                }
                String[] versions = pluginVersions.toArray( new String[pluginVersions.size()] );
                Arrays.sort( versions, new VersionComparator() );
                MavenXpp3Reader reader = new MavenXpp3Reader();
                for ( int j = versions.length - 1; j >= 0; j-- )
                {
                    InputStream inputStream = null;
                    try
                    {
                        inputStream = get( new Artifact( groupId, artifactId, versions[j], "pom" ) );
                        Model model = reader.read( new XmlStreamReader( inputStream ) );
                        if ( model == null || !"maven-plugin".equals( model.getPackaging() ) )
                        {
                            continue;
                        }
                        Plugin plugin = new Plugin();
                        plugin.setArtifactId( artifactId );
                        plugin.setName( model.getName() );
                        
                        
                        
                        boolean havePrefix = false;
                        final Build build = model.getBuild();
                        if ( build != null && build.getPlugins() != null )
                        {
                            havePrefix = setPluginGoalPrefixFromConfiguration( plugin, build.getPlugins() );
                        }
                        if ( !havePrefix && build != null && build.getPluginManagement() != null
                            && build.getPluginManagement().getPlugins() != null )
                        {
                            havePrefix = setPluginGoalPrefixFromConfiguration( plugin,
                                                                               build.getPluginManagement().getPlugins() );
                        }
                        if ( !havePrefix && artifactId.startsWith( "maven-" ) && artifactId.endsWith( "-plugin" ) )
                        {
                            plugin.setPrefix(
                                StringUtils.removeStart( StringUtils.removeEnd( artifactId, "-plugin" ), "maven-" ) );
                            havePrefix = true;
                        }
                        if ( !havePrefix && artifactId.endsWith( "-maven-plugin" ) )
                        {
                            plugin.setPrefix( StringUtils.removeEnd( artifactId, "-maven-plugin" ) );
                            havePrefix = true;
                        }
                        if ( !havePrefix )
                        {
                            plugin.setPrefix( artifactId );
                        }
                        plugins.add( plugin );
                        foundMetadata = true;
                        break;
                    }
                    catch ( ArtifactNotFoundException e )
                    {
                        
                    }
                    catch ( XmlPullParserException e )
                    {
                        
                    }
                    finally
                    {
                        IOUtils.closeQuietly( inputStream );
                    }
                }
            }
            if ( !plugins.isEmpty() )
            {
                metadata.setPlugins( plugins );
            }
        }
        int index = path.lastIndexOf( '/' );
        groupId = ( index == -1 ? groupId : groupId.substring( 0, index ) ).replace( '/', '.' );
        String artifactId = ( index == -1 ? null : path.substring( index + 1 ) );
        if ( artifactId != null )
        {
            Set<String> artifactVersions = getVersions( groupId, artifactId );
            if ( artifactVersions != null && !artifactVersions.isEmpty() )
            {
                metadata.setGroupId( groupId );
                metadata.setArtifactId( artifactId );
                Versioning versioning = new Versioning();
                List<String> versions = new ArrayList<String>( artifactVersions );
                Collections.sort( versions, new VersionComparator() ); 
                long lastUpdated = 0;
                for ( String version : versions )
                {
                    try
                    {
                        long lastModified = getLastModified( new Artifact( groupId, artifactId, version, "pom" ) );
                        versioning.addVersion( version );
                        if ( lastModified >= lastUpdated )
                        {
                            lastUpdated = lastModified;
                            versioning.setLastUpdatedTimestamp( new Date( lastModified ) );
                            versioning.setLatest( version );
                            if ( !version.endsWith( "-SNAPSHOT" ) )
                            {
                                versioning.setRelease( version );
                            }
                        }
                    }
                    catch ( ArtifactNotFoundException e )
                    {
                        
                    }
                }
                metadata.setVersioning( versioning );
                foundMetadata = true;
            }
        }

        int index2 = index == -1 ? -1 : path.lastIndexOf( '/', index - 1 );
        groupId = index2 == -1 ? groupId : groupId.substring( 0, index2 ).replace( '/', '.' );
        artifactId = index2 == -1 ? artifactId : path.substring( index2 + 1, index );
        String version = index2 == -1 ? null : path.substring( index + 1 );
        if ( version != null && version.endsWith( "-SNAPSHOT" ) )
        {
            Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get( groupId );
            Map<String, Map<Artifact, Content>> versionMap = ( artifactMap == null ? null : artifactMap.get( artifactId ) );
            Map<Artifact, Content> filesMap = ( versionMap == null ? null : versionMap.get( version ) );
            if ( filesMap != null )
            {
                List<SnapshotVersion> snapshotVersions = new ArrayList<SnapshotVersion>();
                int maxBuildNumber = 0;
                long lastUpdated = 0;
                String timestamp = null;
                boolean found = false;
                for ( final Map.Entry<Artifact, Content> entry : filesMap.entrySet() )
                {
                    final Artifact artifact = entry.getKey();
                    final Content content = entry.getValue();
                    SimpleDateFormat fmt = new SimpleDateFormat( "yyyyMMddHHmmss" );
                    fmt.setTimeZone( TimeZone.getTimeZone( "GMT" ) );
                    String lastUpdatedTime = fmt.format( new Date( content.getLastModified() ) );
                    try
                    {
                        Maven3.addSnapshotVersion( snapshotVersions, artifact, lastUpdatedTime );
                    }
                    catch ( LinkageError e )
                    {
                        
                    }
                    if ( "pom".equals( artifact.getType() ) )
                    {
                        if ( artifact.getBuildNumber() != null
                            && maxBuildNumber < artifact.getBuildNumber().intValue() )
                        {
                            maxBuildNumber = artifact.getBuildNumber().intValue();
                            timestamp = artifact.getTimestampString();
                        }
                        else
                        {
                            maxBuildNumber = Math.max( 1, maxBuildNumber );
                        }
                        lastUpdated = Math.max( lastUpdated, content.getLastModified() );
                        found = true;
                    }
                }

                if ( !snapshotVersions.isEmpty() || found )
                {
                    Versioning versioning = metadata.getVersioning();
                    if ( versioning == null )
                    {
                        versioning = new Versioning();
                    }
                    metadata.setGroupId( groupId );
                    metadata.setArtifactId( artifactId );
                    metadata.setVersion( version );
                    try
                    {
                        Maven3.addSnapshotVersions( versioning, snapshotVersions );
                    }
                    catch ( LinkageError e )
                    {
                        
                    }
                    if ( maxBuildNumber > 0 )
                    {
                        Snapshot snapshot = new Snapshot();
                        snapshot.setBuildNumber( maxBuildNumber );
                        snapshot.setTimestamp( timestamp );
                        versioning.setSnapshot( snapshot );
                    }
                    versioning.setLastUpdatedTimestamp( new Date( lastUpdated ) );
                    metadata.setVersioning( versioning );
                    foundMetadata = true;
                }
            }

        }
        if ( !foundMetadata )
        {
            throw new MetadataNotFoundException( path );
        }
        return metadata;
    }

// ORIGINAL CODESEARCHNET METHOD — END

public static void main(String[]a)throws Exception{method_4_mrm_gpt s=new method_4_mrm_gpt();s.ids.put("org.demo",new LinkedHashSet<>(Arrays.asList("maven-demo-plugin")));s.vers.put("org.demo:maven-demo-plugin",new LinkedHashSet<>(Arrays.asList("1.0","2.0")));Metadata m=s.getMetadata("org/demo");System.out.println("plugins="+m.getPlugins());}}