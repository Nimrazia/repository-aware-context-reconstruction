
















import java.io.*;import java.net.*;import java.text.*;import java.util.*;
public class method_5_mrm_gpt {static class FileSystemServlet{}static final int NAME_COL_WIDTH=32,SIZE_COL_WIDTH=12;String settingsServletPath="settings.xml";FileSystem fileSystem=new FileSystem();static class ServletException extends Exception{}interface HttpServletRequest{String getPathInfo();String getServletPath();String getContextPath();String getServerName();String getScheme();int getServerPort();}interface HttpServletResponse{void setContentType(String s);PrintWriter getWriter()throws IOException;void setContentLength(int n);OutputStream getOutputStream()throws IOException;void sendRedirect(String s)throws IOException;void sendError(int n)throws IOException;}static class ServletContext{String getMimeType(String n){return n.endsWith(".txt")?"text/plain":"application/octet-stream";}}ServletContext getServletContext(){return new ServletContext();}static class Entry{String name;Entry parent;long lm=1000;Entry(String n){name=n;}String getName(){return name;}Entry getParent(){return parent;}long getLastModified()throws IOException{return lm;}}static class FileEntry extends Entry{byte[]data;FileEntry(String n,String x){super(n);data=x.getBytes();}long getSize()throws IOException{return data.length;}InputStream getInputStream(){return new ByteArrayInputStream(data);}}static class DirectoryEntry extends Entry{List<Entry>children=new ArrayList<>();DirectoryEntry(String n){super(n);}}static class FileSystem{Map<String,Entry>m=new HashMap<>();Entry get(String p){return m.get(p);}Entry[]listEntries(DirectoryEntry d){return d.children.toArray(new Entry[0]);}}static class InterpolationFilterReader extends Reader{Reader r;InterpolationFilterReader(Reader r,Map<String,Object>m,String a,String b){this.r=r;}public int read(char[]c,int o,int l)throws IOException{return r.read(c,o,l);}public void close()throws IOException{r.close();}}static class IOUtil{static void copy(Reader r,Writer w)throws IOException{char[]b=new char[1024];int n;while((n=r.read(b))>=0)w.write(b,0,n);}static void close(Closeable c){try{if(c!=null)c.close();}catch(Exception e){}}}static class IOUtils{static void copy(InputStream i,OutputStream o)throws IOException{i.transferTo(o);}static void closeQuietly(Closeable c){try{if(c!=null)c.close();}catch(Exception e){}}}static class StringUtils{static String repeat(String s,int n){return s.repeat(n);}static String leftPad(String s,int n){return " ".repeat(Math.max(0,n-s.length()))+s;}}static class Utils{static String urlEncodePathSegment(String s){return s.replace(" ","%20");}}String formatName(String s){return s.length()>NAME_COL_WIDTH?s.substring(0,NAME_COL_WIDTH):s;}


// ORIGINAL CODESEARCHNET METHOD — START

protected void doGet( HttpServletRequest req, HttpServletResponse resp )
        throws ServletException, IOException
    {
        String path = req.getPathInfo();
        String context;
        if ( path == null )
        {
            path = req.getServletPath();
            context = req.getContextPath();
        }
        else
        {
            context = req.getContextPath() + req.getServletPath();
        }
        
        if ( path.equals( "/" + settingsServletPath ) )
        {
            resp.setContentType( "text/xml" );
            PrintWriter w = resp.getWriter();
            
            Reader settingsReader = null;
            try 
            {
                String hostAddress;
                try
                {
                    hostAddress = InetAddress.getLocalHost().getHostAddress();
                }
                catch ( UnknownHostException e )
                {
                    hostAddress = req.getServerName();
                }

                String repositoryProxyUrl = req.getScheme() + "://" + hostAddress + ":" + req.getServerPort(); 
                Reader in = new InputStreamReader( FileSystemServlet.class.getResourceAsStream( "/settings-mrm.xml" ) );
                settingsReader = new InterpolationFilterReader( in, Collections.<String, Object>singletonMap( "repository.proxy.url", repositoryProxyUrl ), "@", "@" );
                IOUtil.copy( settingsReader, w );
            }
            finally
            {
                IOUtil.close( settingsReader );
            }
            return;
        }
        
        Entry entry = fileSystem.get( path );
        if ( entry instanceof FileEntry )
        {
            FileEntry fileEntry = (FileEntry) entry;
            long size = fileEntry.getSize();
            if ( size >= 0 && size < Integer.MAX_VALUE )
            {
                resp.setContentLength( (int) size );
            }
            resp.setContentType( getServletContext().getMimeType( fileEntry.getName() ) );
            InputStream source = null;
            OutputStream destination = null;
            try
            {
                source = fileEntry.getInputStream();
                destination = resp.getOutputStream();
                IOUtils.copy( source, destination );
            }
            finally
            {
                IOUtils.closeQuietly( source );
                IOUtils.closeQuietly( destination );
            }
            return;
        }
        else if ( entry instanceof DirectoryEntry )
        {
            if ( !path.endsWith( "/" ) )
            {
                resp.sendRedirect( entry.getName() + "/" );
                return;
            }
            DirectoryEntry dirEntry = (DirectoryEntry) entry;
            Entry[] entries = fileSystem.listEntries( dirEntry );
            resp.setContentType( "text/html" );
            PrintWriter w = resp.getWriter();
            w.println( "<html>" );
            w.println( "  <head>" );
            w.println( "    <title>Index of " + context + path + "</title>" );
            w.println( "    <meta http-equiv=\"Content-Type\" repository=\"text/html; charset=utf-8\"/>" );
            w.println( "</head>" );
            w.println( "<body>" );
            w.println( "<h1>Index of " + context + path + "</h1>" );
            w.println( "  <hr/>" );
            w.write( "<pre>" );

            if ( dirEntry.getParent() != null )
            {
                w.println( "<a href='../'>../</a>" );
            }
            SimpleDateFormat format = new SimpleDateFormat( "dd-MMM-yyyy hh:mm" );
            if ( entries != null )
            {
                for ( int i = 0; i < entries.length; i++ )
                {
                    final String childName = entries[i].getName();
                    boolean directory = entries[i] instanceof DirectoryEntry;
                    if ( directory )
                    {
                        String dirName = childName + "/";
                        w.write(
                            "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "/\">" + formatName( dirName )
                                + "</a>" + StringUtils.repeat( " ",
                                                               Math.max( 0, NAME_COL_WIDTH - dirName.length() ) ) );
                    }
                    else
                    {
                        w.write(
                            "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "\">" + formatName( childName )
                                + "</a>" + StringUtils.repeat( " ",
                                                               Math.max( 0, NAME_COL_WIDTH - childName.length() ) ) );
                    }

                    long timestamp = 0;
                    try
                    {
                        timestamp = entries[i].getLastModified();
                    }
                    catch ( IOException e )
                    {
                        
                    }

                    w.write( " " );
                    w.write( format.format( timestamp != -1 ? new Date( timestamp ) : new Date() ) );
                    if ( directory )
                    {
                        w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                    }
                    else if ( entries[i] instanceof FileEntry )
                    {
                        FileEntry fileEntry = (FileEntry) entries[i];
                        try
                        {
                            long size = fileEntry.getSize();
                            if ( size >= 0 )
                            {
                                w.println( StringUtils.leftPad( Long.toString( size ), SIZE_COL_WIDTH ) );
                            }
                            else
                            {
                                w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                            }
                        }
                        catch ( IOException e )
                        {
                            w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                        }
                    }
                    else
                    {
                        w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                    }
                }
            }
            w.write( "</pre>" );
            w.println( "  <hr/>" );
            w.println( "</body>" );
            w.println( "</html>" );
            return;
        }

        resp.sendError( HttpURLConnection.HTTP_NOT_FOUND );
    }

// ORIGINAL CODESEARCHNET METHOD — END

static class Req implements HttpServletRequest{String p;Req(String p){this.p=p;}public String getPathInfo(){return p;}public String getServletPath(){return "/repo";}public String getContextPath(){return "";}public String getServerName(){return "localhost";}public String getScheme(){return "http";}public int getServerPort(){return 8080;}}static class Resp implements HttpServletResponse{ByteArrayOutputStream b=new ByteArrayOutputStream();PrintWriter w=new PrintWriter(b,true);int status;public void setContentType(String s){}public PrintWriter getWriter(){return w;}public void setContentLength(int n){}public OutputStream getOutputStream(){return b;}public void sendRedirect(String s){w.print("REDIRECT:"+s);}public void sendError(int n){status=n;}public String toString(){w.flush();return b.toString();}}public static void main(String[]a)throws Exception{method_5_mrm_gpt s=new method_5_mrm_gpt();DirectoryEntry d=new DirectoryEntry("repo");d.children.add(new FileEntry("a.txt","hello"));s.fileSystem.m.put("/",d);Resp r=new Resp();s.doGet(new Req("/"),r);System.out.println(r.toString().contains("a.txt"));}}