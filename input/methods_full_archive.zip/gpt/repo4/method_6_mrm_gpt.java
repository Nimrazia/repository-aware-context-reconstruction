
















import java.io.*;import java.util.*;public class method_6_mrm_gpt {static class Metadata{String groupId,artifactId,version;List<Plugin>plugins;Versioning versioning;void setGroupId(String v){groupId=v;}String getGroupId(){return groupId;}void setArtifactId(String v){artifactId=v;}String getArtifactId(){return artifactId;}void setVersion(String v){version=v;}String getVersion(){return version;}void setPlugins(List<Plugin>v){plugins=v;}List<Plugin>getPlugins(){return plugins;}void addPlugin(Plugin p){if(plugins==null)plugins=new ArrayList<>();plugins.add(p);}void setVersioning(Versioning v){versioning=v;}Versioning getVersioning(){return versioning;}}static class Plugin{String artifactId,name,prefix;void setArtifactId(String v){artifactId=v;}String getArtifactId(){return artifactId;}void setName(String v){name=v;}void setPrefix(String v){prefix=v;}public String toString(){return artifactId+":"+prefix;}}static class Versioning{List<String>versions=new ArrayList<>();String latest,release,lastUpdated;Snapshot snapshot;List<SnapshotVersion>sv=new ArrayList<>();void addVersion(String v){versions.add(v);}List<String>getVersions(){return versions;}void setLatest(String v){latest=v;}String getLatest(){return latest;}void setRelease(String v){release=v;}String getRelease(){return release;}void setLastUpdated(String v){lastUpdated=v;}String getLastUpdated(){return lastUpdated;}void setLastUpdatedTimestamp(Date d){lastUpdated=new java.text.SimpleDateFormat("yyyyMMddHHmmss").format(d);}void setSnapshot(Snapshot s){snapshot=s;}Snapshot getSnapshot(){return snapshot;}List<SnapshotVersion>getSnapshotVersions(){return sv;}void addSnapshotVersion(SnapshotVersion x){sv.add(x);}}static class Snapshot{int buildNumber;String timestamp;void setBuildNumber(int v){buildNumber=v;}int getBuildNumber(){return buildNumber;}void setTimestamp(String v){timestamp=v;}String getTimestamp(){return timestamp;}}static class SnapshotVersion{String version,classifier,extension;String getVersion(){return version;}String getClassifier(){return classifier;}String getExtension(){return extension;}}static class MetadataNotFoundException extends Exception{MetadataNotFoundException(String s){super(s);}}static class ArtifactNotFoundException extends Exception{}static class Artifact{String g,a,v,t;Integer buildNumber;String timestamp;Artifact(String g,String a,String v,String t){this.g=g;this.a=a;this.v=v;this.t=t;}String getType(){return t;}Integer getBuildNumber(){return buildNumber;}String getTimestampString(){return timestamp;}public int hashCode(){return Objects.hash(g,a,v,t);}public boolean equals(Object o){if(!(o instanceof Artifact))return false;Artifact x=(Artifact)o;return Objects.equals(g,x.g)&&Objects.equals(a,x.a)&&Objects.equals(v,x.v)&&Objects.equals(t,x.t);}}static class Content{long lm;Content(long x){lm=x;}long getLastModified(){return lm;}}static class VersionComparator implements Comparator<String>{public int compare(String a,String b){return a.compareTo(b);}}static class StringUtils{static String stripStart(String s,String x){while(s.startsWith(x))s=s.substring(x.length());return s;}static String stripEnd(String s,String x){while(s.endsWith(x))s=s.substring(0,s.length()-x.length());return s;}static String removeStart(String s,String x){return s.startsWith(x)?s.substring(x.length()):s;}static String removeEnd(String s,String x){return s.endsWith(x)?s.substring(0,s.length()-x.length()):s;}static boolean isEmpty(String s){return s==null||s.isEmpty();}static String repeat(String s,int n){return s.repeat(n);}static String leftPad(String s,int n){return " ".repeat(Math.max(0,n-s.length()))+s;}}interface ArtifactStore{Metadata getMetadata(String p)throws IOException,MetadataNotFoundException;}ArtifactStore[]stores;method_6_mrm_gpt(ArtifactStore...s){stores=s;}


// ORIGINAL CODESEARCHNET METHOD — START

public Metadata getMetadata( String path )
        throws IOException, MetadataNotFoundException
    {
        boolean found = false;
        Metadata result = new Metadata();
        Set<String> pluginArtifactIds = new HashSet<String>();
        Set<String> snapshotVersions = new HashSet<String>();
        for ( int i = 0; i < stores.length; i++ )
        {
            try
            {
                Metadata partial = stores[i].getMetadata( path );
                if ( StringUtils.isEmpty( result.getArtifactId() ) && !StringUtils.isEmpty( partial.getArtifactId() ) )
                {
                    result.setArtifactId( partial.getArtifactId() );
                    found = true;
                }
                if ( StringUtils.isEmpty( result.getGroupId() ) && !StringUtils.isEmpty( partial.getGroupId() ) )
                {
                    result.setGroupId( partial.getGroupId() );
                    found = true;
                }
                if ( StringUtils.isEmpty( result.getVersion() ) && !StringUtils.isEmpty( partial.getVersion() ) )
                {
                    result.setVersion( partial.getVersion() );
                    found = true;
                }
                if ( partial.getPlugins() != null && !partial.getPlugins().isEmpty() )
                {
                    for ( Plugin plugin : partial.getPlugins() )
                    {
                        if ( !pluginArtifactIds.contains( plugin.getArtifactId() ) )
                        {
                            result.addPlugin( plugin );
                            pluginArtifactIds.add( plugin.getArtifactId() );
                        }
                    }
                    found = true;
                }
                if ( partial.getVersioning() != null )
                {
                    Versioning rVers = result.getVersioning();
                    if ( rVers == null )
                    {
                        rVers = new Versioning();
                    }
                    Versioning pVers = partial.getVersioning();
                    String rLU = found ? rVers.getLastUpdated() : null;
                    String pLU = pVers.getLastUpdated();
                    if ( pLU != null && ( rLU == null || rLU.compareTo( pLU ) < 0 ) )
                    {
                        
                        if ( !StringUtils.isEmpty( pVers.getLatest() ) )
                        {
                            rVers.setLatest( pVers.getLatest() );
                        }

                        if ( !StringUtils.isEmpty( pVers.getRelease() ) )
                        {
                            rVers.setLatest( pVers.getRelease() );
                        }
                        rVers.setLastUpdated( pVers.getLastUpdated() );
                    }
                    for ( String version : pVers.getVersions() )
                    {
                        if ( !rVers.getVersions().contains( version ) )
                        {
                            rVers.addVersion( version );
                        }
                    }
                    if ( pVers.getSnapshot() != null )
                    {
                        if ( rVers.getSnapshot() == null
                            || pVers.getSnapshot().getBuildNumber() > rVers.getSnapshot().getBuildNumber() )
                        {
                            Snapshot snapshot = new Snapshot();
                            snapshot.setBuildNumber( pVers.getSnapshot().getBuildNumber() );
                            snapshot.setTimestamp( pVers.getSnapshot().getTimestamp() );
                            rVers.setSnapshot( snapshot );
                        }
                    }
                    try
                    {
                        if ( pVers.getSnapshotVersions() != null && !pVers.getSnapshotVersions().isEmpty() )
                        {
                            for ( SnapshotVersion snapshotVersion : pVers.getSnapshotVersions() )
                            {
                                String key = snapshotVersion.getVersion() + "-" + snapshotVersion.getClassifier() + "."
                                    + snapshotVersion.getExtension();
                                if ( !snapshotVersions.contains( key ) )
                                {
                                    rVers.addSnapshotVersion( snapshotVersion );
                                    snapshotVersions.add( key );
                                }
                            }
                        }
                    }
                    catch ( NoSuchMethodError e )
                    {
                        
                    }

                    result.setVersioning( rVers );
                    found = true;
                }
            }
            catch ( MetadataNotFoundException e )
            {
                
            }
        }
        if ( !found )
        {
            throw new MetadataNotFoundException( path );
        }
        return result;
    }

// ORIGINAL CODESEARCHNET METHOD — END

public static void main(String[]a)throws Exception{ArtifactStore s1=p->{Metadata m=new Metadata();m.setGroupId("g");m.setArtifactId("a");Versioning v=new Versioning();v.addVersion("1");v.setLatest("1");v.setLastUpdated("20260101");m.setVersioning(v);return m;};ArtifactStore s2=p->{Metadata m=new Metadata();Plugin x=new Plugin();x.setArtifactId("plug");m.addPlugin(x);return m;};Metadata m=new method_6_mrm_gpt(s1,s2).getMetadata("g/a");System.out.println(m.getGroupId()+":"+m.getArtifactId()+" versions="+m.getVersioning().getVersions()+" plugins="+m.getPlugins().size());}}