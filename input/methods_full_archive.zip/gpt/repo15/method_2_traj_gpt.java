import java.awt.geom.Point2D;
import java.util.*;

public class method_2_traj_gpt {
    private List<Point2D.Double> splineSupportPoints;
    private PolynomialSplineFunction spline = null;
    private Trajectory t;
    private int nSegments;
    private Trajectory rotatedTrajectory;
    private double angleRotated;
    private boolean successfull;
    public method_2_traj_gpt(Trajectory t,int nSegments){this.t=t;this.nSegments=nSegments;this.rotatedTrajectory=new Trajectory(2);}
    public method_2_traj_gpt(Trajectory t){this(t,7);}

    public double distancePointLine(Point2D.Double p1,Point2D.Double p2,Point2D.Double p){double dx=p2.x-p1.x,dy=p2.y-p1.y;double den=Math.hypot(dx,dy);return den==0?p.distance(p1):Math.abs(dy*p.x-dx*p.y+p2.x*p1.y-p2.y*p1.x)/den;}
    private boolean isLeft(Point2D.Double p1,Point2D.Double p2,Point2D.Double p){return ((p2.x-p1.x)*(p.y-p1.y)-(p2.y-p1.y)*(p.x-p1.x))>0;}
    public Point2D.Double projectPointToLine(Point2D.Double a,Point2D.Double b,Point2D.Double p){double dx=b.x-a.x,dy=b.y-a.y;double d=dx*dx+dy*dy;if(d==0)return new Point2D.Double(a.x,a.y);double u=((p.x-a.x)*dx+(p.y-a.y)*dy)/d;return new Point2D.Double(a.x+u*dx,a.y+u*dy);}
    public Point2D.Double minDistancePointToLine(Point2D.Double a,Point2D.Double b,List<Point2D.Double> points){Point2D.Double best=points.get(0);double bd=Double.MAX_VALUE;for(Point2D.Double p:points){double d=p.distance(a);if(d<bd){bd=d;best=p;}}return best;}
    
    // ORIGINAL CODESEARCHNET METHOD — START
    
public PolynomialSplineFunction calculateSpline(){
		
		
		


		ArrayList<Point2D.Double> points = new ArrayList<Point2D.Double>();
		for(int i = 0; i < t.size(); i++){
			Point2D.Double p = new Point2D.Double();
			p.setLocation(t.get(i).x, t.get(i).y);
			points.add(p);
		}
		Point2D.Double[] rect = null;
		try{
			rect = RotatingCalipers.getMinimumBoundingRectangle(points);
		}
		catch(IllegalArgumentException e)
		{
		
		}
		catch(EmptyStackException e){
		
		}
		
		


		
		Point2D.Double majorDirection = null;
		
		Point2D.Double p1 = rect[2]; 
		Point2D.Double p2 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[1] : rect[3]; 
		Point2D.Double p3 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[3] : rect[1]; 
		majorDirection = new Point2D.Double(p2.x-p1.x, p2.y-p1.y);
		double width = p1.distance(p2);
		double inRad = -1*Math.atan2(majorDirection.y, majorDirection.x);

		boolean doTransform = (Math.abs(Math.abs(inRad)-Math.PI)>0.001);

		if(doTransform)
		{
			angleRotated = inRad;
			for(int i = 0; i < t.size(); i++){
				double x = t.get(i).x;
				double y = t.get(i).y;
				double newX = x*Math.cos(inRad)-y*Math.sin(inRad);
				double newY = x*Math.sin(inRad)+y*Math.cos(inRad);
				rotatedTrajectory.add(newX, newY, 0);
				points.get(i).setLocation(newX, newY);
			}
			for(int i = 0; i < rect.length; i++){
				rect[i].setLocation(rect[i].x*Math.cos(inRad)-rect[i].y*Math.sin(inRad), rect[i].x*Math.sin(inRad)+rect[i].y*Math.cos(inRad));
			}

			p1 = rect[2]; 
			p2 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[1] : rect[3]; 
			p3 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[3] : rect[1]; 
		}
		else{
			angleRotated = 0;
			rotatedTrajectory = t;
		}
		
		






		List<List<Point2D.Double>> pointsInSegments =null;
		boolean allSegmentsContainingAtLeastTwoPoints = true;
		do{
			
			allSegmentsContainingAtLeastTwoPoints = true;
			double segmentWidth = p1.distance(p2)/nSegments;
			pointsInSegments = new ArrayList<List<Point2D.Double>>(nSegments);
			for(int i = 0; i < nSegments; i++){
				pointsInSegments.add(new ArrayList<Point2D.Double>());
			}
			for(int i = 0; i < points.size(); i++){
				Point2D.Double projPoint  = projectPointToLine(p1, p2, points.get(i));
				int index = (int)(p1.distance(projPoint)/segmentWidth);
				
				if(index>(nSegments-1)){
					index = (nSegments-1);
				}
				pointsInSegments.get(index).add(points.get(i));
			}
			
			for(int i = 0; i < pointsInSegments.size(); i++){
				if(pointsInSegments.get(i).size()<2){
					if(nSegments>2){
						nSegments--;
						i = pointsInSegments.size();
						allSegmentsContainingAtLeastTwoPoints = false;
				
					}
				}
			}
		}while(allSegmentsContainingAtLeastTwoPoints==false);
		
		
		


		
		Point2D.Double eMajorP1 = new Point2D.Double(p1.x - (p3.x-p1.x)/2.0,p1.y - (p3.y-p1.y)/2.0); 
		Point2D.Double eMajorP2 = new Point2D.Double(p2.x - (p3.x-p1.x)/2.0,p2.y - (p3.y-p1.y)/2.0); 
		double sumMean=0;
		int Nsum = 0;
		for(int i = 0; i < nSegments; i++){
			StandardDeviation sd = new StandardDeviation();
			double[] distances = new double[pointsInSegments.get(i).size()];
			for(int j = 0; j < pointsInSegments.get(i).size(); j++){
				int factor = 1;
				if(isLeft(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j))){
					factor = -1;
				}
				distances[j] = factor*distancePointLine(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j));
			}
			if(distances.length >0){
				sd.setData(distances);
	
				sumMean += sd.evaluate();
			
				Nsum++;
			}
		}
		double s = sumMean/Nsum;
		if(s<0.000000000001){
			s = width/nSegments;
		}
	
		


		KDTree<Point2D.Double> kdtree = new KDTree<Point2D.Double>(2);
		
		for(int i = 0; i< points.size(); i++){
			try {
				

				kdtree.insert(new double[]{points.get(i).x,points.get(i).y}, points.get(i));
			} catch (KeySizeException e) {
				e.printStackTrace();
			} catch (KeyDuplicateException e) {
				
			}
			
		}
		
		



		List<Point2D.Double> near = null;
		
		Point2D.Double first = minDistancePointToLine(p1, p3, points);
		double r1 = 3*s;
		try {
			
			near = kdtree.nearestEuclidean(new double[]{first.x ,first.y}, r1);
			
		} catch (KeySizeException e) {
			e.printStackTrace();
		} 

		double cx = 0;
		double cy = 0;
		for(int i = 0; i < near.size(); i++){
			cx += near.get(i).x;
			cy += near.get(i).y;
		}
		cx /= near.size();
		cy /= near.size();

		splineSupportPoints = new ArrayList<Point2D.Double>();
		splineSupportPoints.add(new Point2D.Double(cx, cy));
		
		





		
		


		
		
		



		int nCircleSegments = 100;
		double deltaRad = 2*Math.PI/nCircleSegments;
		boolean stop = false;
		int minN = 7;
		double tempr1 = r1;
		double allowedDeltaDirection = 0.5*Math.PI;
				
		while(stop==false){
			List<Point2D.Double> nearestr1 = null;
			List<Point2D.Double> nearest2xr1 = null;
			try {
				nearestr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},tempr1);
				nearest2xr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},2*tempr1);
			} catch (KeySizeException e) {
				
				e.printStackTrace();
			}
			nearest2xr1.removeAll(nearestr1);
			
			double lThreshRad = 0;
			double hThreshRad = Math.PI/2;
			double stopThresh = 2*Math.PI;
			if(splineSupportPoints.size()>1){
				double directionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				lThreshRad = directionInRad - allowedDeltaDirection/2 - Math.PI/4; 
				if(lThreshRad<0){
					lThreshRad = 2*Math.PI+lThreshRad;
				}
				if(lThreshRad>2*Math.PI){
					lThreshRad = lThreshRad - 2*Math.PI;
				}
				hThreshRad = directionInRad + allowedDeltaDirection/2 + Math.PI/4; 
				if(hThreshRad<0){
					hThreshRad = 2*Math.PI+hThreshRad;
				}
				if(hThreshRad>2*Math.PI){
					hThreshRad = hThreshRad - 2*Math.PI;
				}
				stopThresh = directionInRad + allowedDeltaDirection/2 - Math.PI/4; 
				if(stopThresh>2*Math.PI){
					stopThresh = stopThresh - 2*Math.PI;
				}
				
			}
			
			double newCx=0;
			double newCy=0;
			int newCN = 0;
			int candN = 0;
			
			
			double lastDist = 0;
			double newDist = 0;
			do{ 
				lastDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));

				candN=0;
				double candCx =0;
				double candCy =0;
			
				for(int i = 0; i < nearest2xr1.size(); i++){
					Point2D.Double centerOfCircle = splineSupportPoints.get(splineSupportPoints.size()-1);
					Vector2d relativeToCircle = new Vector2d(nearest2xr1.get(i).x-centerOfCircle.x,nearest2xr1.get(i).y-centerOfCircle.y);
					relativeToCircle.normalize();
					double angleInRadians = Math.atan2(relativeToCircle.y, relativeToCircle.x)+Math.PI;

					if(lThreshRad<hThreshRad){
						if(angleInRadians>lThreshRad && angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}	
					}
					else{
						if(angleInRadians>lThreshRad || angleInRadians < hThreshRad){
							candCx+=nearest2xr1.get(i).x;
							candCy+=nearest2xr1.get(i).y;
							candN++;
						}
					}
					
								
				}
				
				if(candN>0 && candN > newCN ){
					candCx /= candN;
					candCy /= candN;
					newCx = candCx;
					newCy = candCy;
					newCN = candN;
				}
				lThreshRad += deltaRad;
				hThreshRad += deltaRad;
				if(lThreshRad>2*Math.PI){
					lThreshRad = lThreshRad - 2*Math.PI;
				}
				if(hThreshRad>2*Math.PI){
					hThreshRad = hThreshRad - 2*Math.PI;
				}
				newDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));
			
			}while((newDist-lastDist)>0);
			
			
			
			if(splineSupportPoints.size()>1){
				double currentDirectionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y, 
						splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
				double candDirectionInRad = Math.atan2(newCy-splineSupportPoints.get(splineSupportPoints.size()-1).y,
						newCx-splineSupportPoints.get(splineSupportPoints.size()-1).x)+Math.PI;
				double dDir = Math.max(currentDirectionInRad, candDirectionInRad)-Math.min(currentDirectionInRad, candDirectionInRad);
				if(dDir>2*Math.PI){
					dDir = 2*Math.PI-dDir;
				}
				if(dDir>allowedDeltaDirection){

					stop = true;
				}
			}
			boolean enoughPoints = (newCN<minN);
			boolean isNormalRadius = Math.abs(tempr1-r1)<Math.pow(10, -18);
			boolean isExtendedRadius = Math.abs(tempr1-3*r1)<Math.pow(10, -18);
			
			if(enoughPoints&& isNormalRadius){
				
				tempr1 = 3*r1;
			}
			else if(enoughPoints && isExtendedRadius){
				
				stop = true;
			}
			else if(stop==false){
				splineSupportPoints.add(new Point2D.Double(newCx,newCy));
				tempr1 = r1;
			}
			
		}

		
				Collections.sort(splineSupportPoints, new Comparator<Point2D.Double>() {

					public int compare(Point2D.Double o1, Point2D.Double o2) {
						if(o1.x<o2.x){
							return -1;
						}
						if(o1.x>o2.x){
							return 1;
						}
						return 0;
					}
				});
				
	
		
		
		if(splineSupportPoints.size()>1){
			Vector2d start = new Vector2d(splineSupportPoints.get(0).x-splineSupportPoints.get(1).x, splineSupportPoints.get(0).y-splineSupportPoints.get(1).y);
			start.normalize();
			start.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+start.x, splineSupportPoints.get(0).y+start.y));
			
			Vector2d end = new Vector2d(splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x, 
					splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y);
			end.normalize();
			end.scale(r1*6);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+end.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+end.y));
		}
		else{
			Vector2d majordir = new Vector2d(-1, 0);
			majordir.normalize();
			majordir.scale(r1*8);
			splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+majordir.x, splineSupportPoints.get(0).y+majordir.y));
			majordir.scale(-1);
			splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+majordir.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+majordir.y));
		

		}
		
		
		
		
		
		double[] supX = new double[splineSupportPoints.size()];
		double[] supY = new double[splineSupportPoints.size()];
		for(int i = 0; i < splineSupportPoints.size(); i++){
			supX[i] = splineSupportPoints.get(i).x;
			supY[i] = splineSupportPoints.get(i).y;
		}
		
		SplineInterpolator sIinter = new SplineInterpolator();
		spline = sIinter.interpolate(supX, supY);
		
		return spline;
	}
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    static final class Trajectory {
        private final int dimension;
        private final List<Point3D> points = new ArrayList<Point3D>();
        Trajectory(int dimension){ this.dimension=dimension; }
        void add(double x,double y,double z){ points.add(new Point3D(x,y,z)); }
        Point3D get(int i){ return points.get(i); }
        int size(){ return points.size(); }
        int getDimension(){ return dimension; }
    }
    static final class Point3D { double x,y,z; Point3D(double x,double y,double z){this.x=x;this.y=y;this.z=z;} }
    static final class Vector2d { double x,y; Vector2d(double x,double y){this.x=x;this.y=y;} void normalize(){double n=Math.hypot(x,y); if(n!=0){x/=n;y/=n;}} void scale(double s){x*=s;y*=s;} }
    static final class Array2DRowRealMatrix { final double[][] data; Array2DRowRealMatrix(double[][] d){data=d;} }
    static final class RealVector { final double[] v; RealVector(double...v){this.v=v;} double getEntry(int i){return v[i];} }
    static final class EigenDecomposition { EigenDecomposition(Array2DRowRealMatrix m){} RealVector getEigenvector(int i){ return new RealVector(-1.0,0.0); } }
    static final class RadiusGyrationTensor2D {
        static Array2DRowRealMatrix getRadiusOfGyrationTensor(Trajectory t){
            double mx=0,my=0; for(int i=0;i<t.size();i++){mx+=t.get(i).x;my+=t.get(i).y;} mx/=t.size();my/=t.size();
            double xx=0,xy=0,yy=0; for(int i=0;i<t.size();i++){double dx=t.get(i).x-mx,dy=t.get(i).y-my;xx+=dx*dx;xy+=dx*dy;yy+=dy*dy;}
            return new Array2DRowRealMatrix(new double[][]{{xx,xy},{xy,yy}});
        }
    }
    static final class CenterOfGravityFeature { final Trajectory t; CenterOfGravityFeature(Trajectory t){this.t=t;} double[] evaluate(){double x=0,y=0;for(int i=0;i<t.size();i++){x+=t.get(i).x;y+=t.get(i).y;}return new double[]{x/t.size(),y/t.size()};} }
    static final class StandardDeviation { double[] data=new double[0]; void setData(double[] d){data=d;} double evaluate(){if(data.length==0)return Double.NaN;double m=0;for(double x:data)m+=x;m/=data.length;double s=0;for(double x:data)s+=(x-m)*(x-m);return Math.sqrt(s/data.length);} }
    static final class KeySizeException extends Exception { KeySizeException(String m){super(m);} }
    static final class KeyDuplicateException extends Exception { KeyDuplicateException(String m){super(m);} }
    static final class KDTree<T> {
        final int dims; final List<double[]> keys=new ArrayList<double[]>(); final List<T> values=new ArrayList<T>(); KDTree(int d){dims=d;}
        void insert(double[] k,T v)throws KeySizeException,KeyDuplicateException{if(k.length!=dims)throw new KeySizeException("dimension");for(double[] e:keys)if(Arrays.equals(e,k))throw new KeyDuplicateException("duplicate");keys.add(k.clone());values.add(v);}
        List<T> nearestEuclidean(double[] q,double r)throws KeySizeException{if(q.length!=dims)throw new KeySizeException("dimension");List<T> out=new ArrayList<T>();for(int i=0;i<keys.size();i++){double s=0;for(int j=0;j<dims;j++){double d=keys.get(i)[j]-q[j];s+=d*d;}if(Math.sqrt(s)<=r)out.add(values.get(i));}if(out.isEmpty()&&!values.isEmpty())out.add(values.get(0));return out;}
    }
    static final class PolynomialSplineFunction {
        final double[] knots, values; PolynomialSplineFunction(double[] x,double[] y){knots=x;values=y;}
        int getN(){return Math.max(0,knots.length-1);} double[] getKnots(){return knots.clone();}
        double value(double x){if(knots.length==0)return Double.NaN;if(x<=knots[0])return values[0];for(int i=0;i<knots.length-1;i++)if(x<=knots[i+1]){double d=knots[i+1]-knots[i];double a=d==0?0:(x-knots[i])/d;return values[i]*(1-a)+values[i+1]*a;}return values[values.length-1];}
    }
    static final class SplineInterpolator { PolynomialSplineFunction interpolate(double[] x,double[] y){double[] xx=x.clone(),yy=y.clone();for(int i=1;i<xx.length;i++)if(xx[i]<=xx[i-1])xx[i]=xx[i-1]+1e-9;return new PolynomialSplineFunction(xx,yy);} }
    static final class RotatingCalipers { static Point2D.Double[] getMinimumBoundingRectangle(List<Point2D.Double> p){double minx=Double.MAX_VALUE,maxx=-Double.MAX_VALUE,miny=Double.MAX_VALUE,maxy=-Double.MAX_VALUE;for(Point2D.Double q:p){minx=Math.min(minx,q.x);maxx=Math.max(maxx,q.x);miny=Math.min(miny,q.y);maxy=Math.max(maxy,q.y);}return new Point2D.Double[]{new Point2D.Double(minx,miny),new Point2D.Double(maxx,miny),new Point2D.Double(maxx,maxy),new Point2D.Double(minx,maxy)};} }
    static class Chart { final Map<String,Series> series=new LinkedHashMap<String,Series>(); Series addSeries(String n,double[]x,double[]y){Series s=new Series(n,x,y);series.put(n,s);return s;} }
    static final class QuickChart { static Chart getChart(String a,String b,String c,String d,double[]x,double[]y){Chart ch=new Chart();ch.addSeries(d,x,y);return ch;} }
    enum SeriesLineStyle { NONE,DASH_DASH } enum SeriesMarker { NONE } enum SeriesType { Line }
    static final class Series { final String name; final double[]x,y; Series(String n,double[]x,double[]y){name=n;this.x=x;this.y=y;} void setLineStyle(SeriesLineStyle s){} void setMarker(SeriesMarker m){} void setSeriesType(SeriesType t){} }
    static final class SwingWrapper { final Chart chart; SwingWrapper(Chart c){chart=c;} void displayChart(){System.out.println("Chart displayed with series: "+chart.series.keySet());} }
    public static void main(String[] args){Trajectory tr=new Trajectory(2);for(int i=1;i<=40;i++){double y=5+Math.sin(i*0.35)*1.5+(i%3)*0.08;tr.add(i,y,0);} method_2_traj_gpt fit=new method_2_traj_gpt(tr,2);PolynomialSplineFunction f=fit.calculateSpline();System.out.println("Spline segments: "+(f==null?"null":f.getN()));System.out.println("Support points: "+fit.splineSupportPoints.size());System.out.println("Rotation angle: "+fit.angleRotated);}
}
