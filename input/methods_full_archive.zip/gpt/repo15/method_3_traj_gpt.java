import java.awt.geom.Point2D;
import java.util.*;

public class method_3_traj_gpt {
    private List<Point2D.Double> splineSupportPoints;
    private PolynomialSplineFunction spline = null;
    private Trajectory t;
    private int nSegments;
    private Trajectory rotatedTrajectory;
    private double angleRotated;
    private boolean successfull;
    public method_3_traj_gpt(Trajectory t,int nSegments){this.t=t;this.nSegments=nSegments;this.rotatedTrajectory=new Trajectory(2);}
    public method_3_traj_gpt(Trajectory t){this(t,7);}

    public double distancePointLine(Point2D.Double p1,Point2D.Double p2,Point2D.Double p){double dx=p2.x-p1.x,dy=p2.y-p1.y;double den=Math.hypot(dx,dy);return den==0?p.distance(p1):Math.abs(dy*p.x-dx*p.y+p2.x*p1.y-p2.y*p1.x)/den;}
    private boolean isLeft(Point2D.Double p1,Point2D.Double p2,Point2D.Double p){return ((p2.x-p1.x)*(p.y-p1.y)-(p2.y-p1.y)*(p.x-p1.x))>0;}
    public Point2D.Double projectPointToLine(Point2D.Double a,Point2D.Double b,Point2D.Double p){double dx=b.x-a.x,dy=b.y-a.y;double d=dx*dx+dy*dy;if(d==0)return new Point2D.Double(a.x,a.y);double u=((p.x-a.x)*dx+(p.y-a.y)*dy)/d;return new Point2D.Double(a.x+u*dx,a.y+u*dy);}
    public Point2D.Double minDistancePointToLine(Point2D.Double a,Point2D.Double b,List<Point2D.Double> points){Point2D.Double best=points.get(0);double bd=Double.MAX_VALUE;for(Point2D.Double p:points){double d=p.distance(a);if(d<bd){bd=d;best=p;}}return best;}
    private void prepareDemo(){splineSupportPoints=new ArrayList<Point2D.Double>();splineSupportPoints.add(new Point2D.Double(0,0));splineSupportPoints.add(new Point2D.Double(2,1));splineSupportPoints.add(new Point2D.Double(4,0));spline=new SplineInterpolator().interpolate(new double[]{0,2,4},new double[]{0,1,0});rotatedTrajectory=t;}
    
    // ORIGINAL CODESEARCHNET METHOD — START
    
public void showTrajectoryAndSpline(){
		
		if(t.getDimension()==2){
		 	double[] xData = new double[rotatedTrajectory.size()];
		    double[] yData = new double[rotatedTrajectory.size()];
		    for(int i = 0; i < rotatedTrajectory.size(); i++){
		    	xData[i] = rotatedTrajectory.get(i).x;
		    	yData[i] = rotatedTrajectory.get(i).y;		    	
		    }
		    
		    Chart chart = QuickChart.getChart("Spline+Track", "X", "Y", "y(x)", xData, yData);
		    
		    
		    double[] subxData  = new double[splineSupportPoints.size()];
		    double[] subyData  = new double[splineSupportPoints.size()];
		    
		    for(int i = 0; i < splineSupportPoints.size(); i++){
		    	subxData[i] = splineSupportPoints.get(i).x;
		    	subyData[i] = splineSupportPoints.get(i).y;
		    }
		    Series s = chart.addSeries("Spline Support Points", subxData, subyData);
		    s.setLineStyle(SeriesLineStyle.NONE);
		    s.setSeriesType(SeriesType.Line);
		    
		    
		    int numberInterpolatedPointsPerSegment = 20;
		    int numberOfSplines = spline.getN();
		    double[] sxData = new double[numberInterpolatedPointsPerSegment*numberOfSplines];
		    
		    double[] syData = new double[numberInterpolatedPointsPerSegment*numberOfSplines];
		    double[] knots = spline.getKnots();
		    for(int i = 0; i < numberOfSplines; i++){
		    	double x = knots[i];
		   
		    	double stopx = knots[i+1];
		    	double dx = (stopx-x)/numberInterpolatedPointsPerSegment;
		    	
		    	for(int j = 0; j < numberInterpolatedPointsPerSegment; j++){

		    		sxData[i*numberInterpolatedPointsPerSegment+j] = x;
		    		syData[i*numberInterpolatedPointsPerSegment+j] = spline.value(x);
		    		x += dx;
		    	}
		    	
		    }
		    s = chart.addSeries("Spline", sxData, syData);
		    s.setLineStyle(SeriesLineStyle.DASH_DASH);
		    s.setMarker(SeriesMarker.NONE);
		    s.setSeriesType(SeriesType.Line);
		 
		    
		    
		    new SwingWrapper(chart).displayChart();
		} 
	}
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    static final class Trajectory {
        private final int dimension;
        private final List<Point3D> points = new ArrayList<Point3D>();
        Trajectory(int dimension){ this.dimension=dimension; }
        void add(double x,double y,double z){ points.add(new Point3D(x,y,z)); }
        Point3D get(int i){ return points.get(i); }
        int size(){ return points.size(); }
        int getDimension(){ return dimension; }
    }
    static final class Point3D { double x,y,z; Point3D(double x,double y,double z){this.x=x;this.y=y;this.z=z;} }
    static final class Vector2d { double x,y; Vector2d(double x,double y){this.x=x;this.y=y;} void normalize(){double n=Math.hypot(x,y); if(n!=0){x/=n;y/=n;}} void scale(double s){x*=s;y*=s;} }
    static final class Array2DRowRealMatrix { final double[][] data; Array2DRowRealMatrix(double[][] d){data=d;} }
    static final class RealVector { final double[] v; RealVector(double...v){this.v=v;} double getEntry(int i){return v[i];} }
    static final class EigenDecomposition { EigenDecomposition(Array2DRowRealMatrix m){} RealVector getEigenvector(int i){ return new RealVector(-1.0,0.0); } }
    static final class RadiusGyrationTensor2D {
        static Array2DRowRealMatrix getRadiusOfGyrationTensor(Trajectory t){
            double mx=0,my=0; for(int i=0;i<t.size();i++){mx+=t.get(i).x;my+=t.get(i).y;} mx/=t.size();my/=t.size();
            double xx=0,xy=0,yy=0; for(int i=0;i<t.size();i++){double dx=t.get(i).x-mx,dy=t.get(i).y-my;xx+=dx*dx;xy+=dx*dy;yy+=dy*dy;}
            return new Array2DRowRealMatrix(new double[][]{{xx,xy},{xy,yy}});
        }
    }
    static final class CenterOfGravityFeature { final Trajectory t; CenterOfGravityFeature(Trajectory t){this.t=t;} double[] evaluate(){double x=0,y=0;for(int i=0;i<t.size();i++){x+=t.get(i).x;y+=t.get(i).y;}return new double[]{x/t.size(),y/t.size()};} }
    static final class StandardDeviation { double[] data=new double[0]; void setData(double[] d){data=d;} double evaluate(){if(data.length==0)return Double.NaN;double m=0;for(double x:data)m+=x;m/=data.length;double s=0;for(double x:data)s+=(x-m)*(x-m);return Math.sqrt(s/data.length);} }
    static final class KeySizeException extends Exception { KeySizeException(String m){super(m);} }
    static final class KeyDuplicateException extends Exception { KeyDuplicateException(String m){super(m);} }
    static final class KDTree<T> {
        final int dims; final List<double[]> keys=new ArrayList<double[]>(); final List<T> values=new ArrayList<T>(); KDTree(int d){dims=d;}
        void insert(double[] k,T v)throws KeySizeException,KeyDuplicateException{if(k.length!=dims)throw new KeySizeException("dimension");for(double[] e:keys)if(Arrays.equals(e,k))throw new KeyDuplicateException("duplicate");keys.add(k.clone());values.add(v);}
        List<T> nearestEuclidean(double[] q,double r)throws KeySizeException{if(q.length!=dims)throw new KeySizeException("dimension");List<T> out=new ArrayList<T>();for(int i=0;i<keys.size();i++){double s=0;for(int j=0;j<dims;j++){double d=keys.get(i)[j]-q[j];s+=d*d;}if(Math.sqrt(s)<=r)out.add(values.get(i));}if(out.isEmpty()&&!values.isEmpty())out.add(values.get(0));return out;}
    }
    static final class PolynomialSplineFunction {
        final double[] knots, values; PolynomialSplineFunction(double[] x,double[] y){knots=x;values=y;}
        int getN(){return Math.max(0,knots.length-1);} double[] getKnots(){return knots.clone();}
        double value(double x){if(knots.length==0)return Double.NaN;if(x<=knots[0])return values[0];for(int i=0;i<knots.length-1;i++)if(x<=knots[i+1]){double d=knots[i+1]-knots[i];double a=d==0?0:(x-knots[i])/d;return values[i]*(1-a)+values[i+1]*a;}return values[values.length-1];}
    }
    static final class SplineInterpolator { PolynomialSplineFunction interpolate(double[] x,double[] y){double[] xx=x.clone(),yy=y.clone();for(int i=1;i<xx.length;i++)if(xx[i]<=xx[i-1])xx[i]=xx[i-1]+1e-9;return new PolynomialSplineFunction(xx,yy);} }
    static final class RotatingCalipers { static Point2D.Double[] getMinimumBoundingRectangle(List<Point2D.Double> p){double minx=Double.MAX_VALUE,maxx=-Double.MAX_VALUE,miny=Double.MAX_VALUE,maxy=-Double.MAX_VALUE;for(Point2D.Double q:p){minx=Math.min(minx,q.x);maxx=Math.max(maxx,q.x);miny=Math.min(miny,q.y);maxy=Math.max(maxy,q.y);}return new Point2D.Double[]{new Point2D.Double(minx,miny),new Point2D.Double(maxx,miny),new Point2D.Double(maxx,maxy),new Point2D.Double(minx,maxy)};} }
    static class Chart { final Map<String,Series> series=new LinkedHashMap<String,Series>(); Series addSeries(String n,double[]x,double[]y){Series s=new Series(n,x,y);series.put(n,s);return s;} }
    static final class QuickChart { static Chart getChart(String a,String b,String c,String d,double[]x,double[]y){Chart ch=new Chart();ch.addSeries(d,x,y);return ch;} }
    enum SeriesLineStyle { NONE,DASH_DASH } enum SeriesMarker { NONE } enum SeriesType { Line }
    static final class Series { final String name; final double[]x,y; Series(String n,double[]x,double[]y){name=n;this.x=x;this.y=y;} void setLineStyle(SeriesLineStyle s){} void setMarker(SeriesMarker m){} void setSeriesType(SeriesType t){} }
    static final class SwingWrapper { final Chart chart; SwingWrapper(Chart c){chart=c;} void displayChart(){System.out.println("Chart displayed with series: "+chart.series.keySet());} }
    public static void main(String[] args){Trajectory tr=new Trajectory(2);tr.add(0,0,0);tr.add(2,1,0);tr.add(4,0,0);method_3_traj_gpt fit=new method_3_traj_gpt(tr);fit.prepareDemo();fit.showTrajectoryAndSpline();System.out.println("Plotted points: "+fit.rotatedTrajectory.size());}
}
