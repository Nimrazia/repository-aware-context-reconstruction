import java.util.*;

public class method_8_logging_gpt extends TimeAndSizeRollingAppender {
    private boolean filterEmptyMessages=true;
    private CompositeRoller fileRollable;
    private LogFileScavenger logFileScavenger;
    private LogFileCompressor logFileCompressor;
    private TimeBasedRollEnforcer logRollEnforcer;
    private final FoundationProperties properties=new FoundationProperties();
    private final List<Object> filters=new ArrayList<Object>();
    private boolean deactivated;
    private boolean guestRegistered;
    private int rollCount;

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public synchronized final void activateOptions() {
        this.deactivateOptions();
        super.activateOptions();
        if (getFilterEmptyMessages()) {
            addFilter(new EmptyMessageFilter());
        }

        
        this.setFileRollable(new CompositeRoller(this, this.getProperties()));
        
        LogFileScavenger fileScavenger = this.getLogFileScavenger();
        if (fileScavenger == null) {
            fileScavenger = this.initLogFileScavenger(new DefaultLogFileScavenger());
        }
        fileScavenger.begin();
        
        final LogFileCompressor logFileCompressor = new LogFileCompressor(this, this.getProperties());
        this.setLogFileCompressor(logFileCompressor);
        this.getFileRollable().addFileRollEventListener(logFileCompressor);
        logFileCompressor.begin();
        
        this.registerGuestFileRollEventListener();
        
        final TimeBasedRollEnforcer logRollEnforcer = new TimeBasedRollEnforcer(this, this.getProperties());
        this.setLogRollEnforcer(logRollEnforcer);
        logRollEnforcer.begin();
        
        if (this.getProperties().shouldRollOnActivation()) {
            synchronized (this) {
                this.rollFile(new StartupFileRollEvent());
            }
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    void deactivateOptions(){deactivated=true;if(logFileScavenger!=null)logFileScavenger.stop();if(logFileCompressor!=null)logFileCompressor.stop();if(logRollEnforcer!=null)logRollEnforcer.stop();}
    boolean getFilterEmptyMessages(){return filterEmptyMessages;}
    void addFilter(Object filter){filters.add(filter);}
    void setFileRollable(CompositeRoller roller){fileRollable=roller;}
    CompositeRoller getFileRollable(){return fileRollable;}
    LogFileScavenger getLogFileScavenger(){return logFileScavenger;}
    LogFileScavenger initLogFileScavenger(LogFileScavenger scavenger){logFileScavenger=scavenger;return scavenger;}
    void setLogFileCompressor(LogFileCompressor compressor){logFileCompressor=compressor;}
    void registerGuestFileRollEventListener(){guestRegistered=true;}
    void setLogRollEnforcer(TimeBasedRollEnforcer enforcer){logRollEnforcer=enforcer;}
    FoundationProperties getProperties(){return properties;}
    void rollFile(StartupFileRollEvent event){rollCount++;fileRollable.fire(event);}

    public static void main(String[] args){
        method_8_logging_gpt appender=new method_8_logging_gpt();
        appender.properties.rollOnActivation=true;
        appender.activateOptions();
        System.out.println("SUPER_ACTIVATED="+appender.superActivated);
        System.out.println("EMPTY_FILTERS="+appender.filters.size());
        System.out.println("SCAVENGER_RUNNING="+((DefaultLogFileScavenger)appender.logFileScavenger).running);
        System.out.println("COMPRESSOR_RUNNING="+appender.logFileCompressor.running);
        System.out.println("ROLL_ENFORCER_RUNNING="+appender.logRollEnforcer.running);
        System.out.println("GUEST_LISTENER_REGISTERED="+appender.guestRegistered);
        System.out.println("STARTUP_ROLL_COUNT="+appender.rollCount);
        System.out.println("ROLL_LISTENERS="+appender.fileRollable.listeners.size());
    }
}

class TimeAndSizeRollingAppender { boolean superActivated; public void activateOptions(){superActivated=true;} }
class FoundationProperties { boolean rollOnActivation; boolean shouldRollOnActivation(){return rollOnActivation;} }
class EmptyMessageFilter { boolean accepts(String message){return message!=null&&!message.isEmpty();} }
interface FileRollEventListener { void onRoll(StartupFileRollEvent event); }
class CompositeRoller {
    final method_8_logging_gpt owner; final FoundationProperties properties; final List<FileRollEventListener> listeners=new ArrayList<FileRollEventListener>();
    CompositeRoller(method_8_logging_gpt owner,FoundationProperties properties){this.owner=owner;this.properties=properties;}
    void addFileRollEventListener(FileRollEventListener listener){listeners.add(listener);}
    void fire(StartupFileRollEvent event){for(FileRollEventListener l:listeners)l.onRoll(event);}
}
interface LogFileScavenger { void begin(); void stop(); }
class DefaultLogFileScavenger implements LogFileScavenger { boolean running; public void begin(){running=true;} public void stop(){running=false;} }
class LogFileCompressor implements FileRollEventListener {
    final method_8_logging_gpt owner; final FoundationProperties properties; boolean running; int compressedRolls;
    LogFileCompressor(method_8_logging_gpt owner,FoundationProperties properties){this.owner=owner;this.properties=properties;}
    void begin(){running=true;} void stop(){running=false;} public void onRoll(StartupFileRollEvent event){compressedRolls++;}
}
class TimeBasedRollEnforcer { final method_8_logging_gpt owner; final FoundationProperties properties; boolean running; TimeBasedRollEnforcer(method_8_logging_gpt owner,FoundationProperties properties){this.owner=owner;this.properties=properties;} void begin(){running=true;} void stop(){running=false;} }
class StartupFileRollEvent { public String toString(){return "startup";} }
