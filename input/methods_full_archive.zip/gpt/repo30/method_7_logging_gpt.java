import java.util.*;
import java.util.Map.Entry;

public class method_7_logging_gpt {
    static class Timer { private final long time; Timer(long time){this.time=time;} long getTime(){return time;} }
    static class Component {
        final String name; final long processingTime; final long invocations;
        Component(String name,long processingTime,long invocations){this.name=name;this.processingTime=processingTime;this.invocations=invocations;}
    }
    static class ComponentsMultiThread {
        final List<Component> components=new ArrayList<Component>();
        List<Component> getComponents(){return components;}
    }
    final Map<String,Component> components=new LinkedHashMap<String,Component>();
    ComponentsMultiThread componentsMultiThread;
    final Timer total=new Timer(1450);
    final Map<String,String> properties=new LinkedHashMap<String,String>();
    static final String TOTAL_COMPONENT="totalComponentProcessingTime";

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    protected void addPropertiesProcessingTime() {

        HashMap<String, Long> mapComponentTimes			= new HashMap<>();
        HashMap<String, Long> mapComponentInvocations	= new HashMap<>();

        
        if (this.componentsMultiThread != null) {
          for (Component component : this.componentsMultiThread.getComponents()) {
            addTimePerComponent(mapComponentTimes, component);
            addInvocationPerComponent(mapComponentInvocations, component);
          }
        }

        for (Component component : this.components.values()) {
          addTimePerComponent(mapComponentTimes, component);
        }

        for (Entry<String, Long> entry : mapComponentTimes.entrySet()) {
          putProperty(entry.getKey(), addDuration(entry.getValue()));
        }

        for (Entry<String, Long> entry : mapComponentInvocations.entrySet()) {
          putProperty(entry.getKey(), entry.getValue().toString());
        }
        putProperty(TOTAL_COMPONENT, addDuration(this.total.getTime()));
      }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    void addTimePerComponent(Map<String,Long> map,Component c){map.put(c.name+".duration",map.getOrDefault(c.name+".duration",0L)+c.processingTime);}
    void addInvocationPerComponent(Map<String,Long> map,Component c){map.put(c.name+".invocations",map.getOrDefault(c.name+".invocations",0L)+c.invocations);}
    String addDuration(long millis){return millis+"ms";}
    void putProperty(String key,String value){properties.put(key,value);}

    public static void main(String[] args){
        method_7_logging_gpt logger=new method_7_logging_gpt();
        logger.components.put("database",new Component("database",300,1));
        logger.components.put("cache",new Component("cache",70,1));
        logger.componentsMultiThread=new ComponentsMultiThread();
        logger.componentsMultiThread.components.add(new Component("database",220,2));
        logger.componentsMultiThread.components.add(new Component("remoteService",410,3));
        logger.addPropertiesProcessingTime();
        System.out.println("PROCESSING_PROPERTIES="+logger.properties);
    }
}
