
import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Executable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.Map.Entry;






public class method_1_jbeanbox_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    
    static @interface PROTOTYPE {}
    static @interface INJECT {}
    static @interface PARAM {}
    static @interface AOP {
        Class<?> value() default Object.class;
        String method() default "";
    }
    static @interface POSTCONSTRUCT {}
    static @interface PREDESTROY {}
    
    static @interface Scope {
        String value() default "";
    }
    static @interface PostConstruct {}
    static @interface PreDestroy {}
    static @interface Autowired {}
    static @interface Value {}

    

    static class BeanBoxException extends RuntimeException {
        public BeanBoxException(String msg) { super(msg); }
        public BeanBoxException(Throwable cause) { super(cause); }
        public BeanBoxException(String msg, Throwable cause) { super(msg, cause); }
        public static Object throwEX(String msg) { throw new BeanBoxException(msg); }
        public static Object throwEX(String msg, Throwable t) { throw new BeanBoxException(msg, t); }
        public static Object throwEX(Throwable t) { throw new BeanBoxException(t); }
        public static void assureNotNull(Object o, String msg) { if (o == null) throwEX(msg); }
    }

    static class BeanBoxContext {
        private boolean allowAnnotation = true;
        private boolean allowSpringJsrAnnotation = true;
        public boolean isAllowAnnotation() { return allowAnnotation; }
        public boolean allowSpringJsrAnnotation() { return allowSpringJsrAnnotation; }
        
    }

    static class BeanBox {
        private Class<?> beanClass;
        private boolean singleton = true;
        private Object target;
        private boolean pureValue;
        private boolean required;
        private Constructor<?> constructor;
        private BeanBox[] constructorParams;
        private Map<Field, BeanBox> fieldInjects;
        private Map<Method, BeanBox[]> methodInjects;
        private Method postConstruct;
        private Method preDestroy;
        private List<Object[]> aopRules = new ArrayList<>();
        private Map<Method, Object> methodAops = new HashMap<>();

        public Class<?> getBeanClass() { return beanClass; }
        public void setBeanClass(Class<?> clazz) { this.beanClass = clazz; }
        public boolean isSingleton() { return singleton; }
        public void setSingleton(boolean s) { this.singleton = s; }
        public Object getTarget() { return target; }
        public void setTarget(Object t) { this.target = t; }
        public boolean isPureValue() { return pureValue; }
        public void setPureValue(boolean p) { this.pureValue = p; }
        public boolean isRequired() { return required; }
        public void setRequired(boolean r) { this.required = r; }
        public Constructor<?> getConstructor() { return constructor; }
        public void setConstructor(Constructor<?> c) { this.constructor = c; }
        public BeanBox[] getConstructorParams() { return constructorParams; }
        public void setConstructorParams(BeanBox[] params) { this.constructorParams = params; }
        public Map<Field, BeanBox> getFieldInjects() { return fieldInjects; }
        public void setFieldInjects(Map<Field, BeanBox> map) { this.fieldInjects = map; }
        public void checkOrCreateFieldInjects() { if (fieldInjects == null) fieldInjects = new HashMap<>(); }
        public Map<Method, BeanBox[]> getMethodInjects() { return methodInjects; }
        public void checkOrCreateMethodInjects() { if (methodInjects == null) methodInjects = new HashMap<>(); }
        public Method getPostConstruct() { return postConstruct; }
        public void setPostConstruct(Method m) { this.postConstruct = m; }
        public Method getPreDestroy() { return preDestroy; }
        public void setPreDestroy(Method m) { this.preDestroy = m; }
        public List<Object[]> getAopRules() { return aopRules; }
        public Map<Method, Object> getMethodAops() { return methodAops; }
        public void addBeanAop(Object aop, String methodNameRule) { aopRules.add(new Object[]{aop, methodNameRule}); }
        public void addMethodAop(Object aop, Method m) { methodAops.put(m, aop); }
        public void setType(Class<?> type) {  }
    }

    static class ReflectionUtils {
        public static List<Field> getSelfAndSuperClassFields(Class<?> clazz) {
            List<Field> fields = new ArrayList<>();
            
            for (Field f : clazz.getDeclaredFields()) fields.add(f);
            if (clazz.getSuperclass() != null && clazz.getSuperclass() != Object.class) {
                fields.addAll(getSelfAndSuperClassFields(clazz.getSuperclass()));
            }
            return fields;
        }
        public static Method[] getAllDeclaredMethods(Class<?> clazz) {
            
            List<Method> methods = new ArrayList<>();
            for (Method m : clazz.getDeclaredMethods()) methods.add(m);
            if (clazz.getSuperclass() != null && clazz.getSuperclass() != Object.class) {
                for (Method m : clazz.getSuperclass().getDeclaredMethods()) methods.add(m);
            }
            return methods.toArray(new Method[0]);
        }
        public static void makeAccessible(AccessibleObject obj) { obj.setAccessible(true); }
        public static void invokeMethod(Method m, Object target, Object... args) {
            try { m.invoke(target, args); } catch (Exception e) { throw new BeanBoxException(e); }
        }
        public static void setField(Field f, Object target, Object value) {
            try { f.set(target, value); } catch (Exception e) { throw new BeanBoxException(e); }
        }
    }


    
    static class EMPTY { }

    
    @SuppressWarnings("unchecked")
    private static boolean checkAnnoExist(Class<?> clazz, Class<? extends Annotation> annoClass) {
        return clazz.getAnnotation(annoClass) != null;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> getAnnoAsMap(Class<?> clazz, String annoClassName) {
        
        if (clazz.getAnnotation(Scope.class) != null) {
            Map<String, Object> map = new HashMap<>();
            map.put("value", clazz.getAnnotation(Scope.class).value());
            return map;
        }
        return null;
    }

    private static Object[] getInjectAnnotationAsArray(Object annotated, boolean allowSpring) {
        
        if (annotated instanceof Class) {
            Class<?> clazz = (Class<?>) annotated;
            INJECT inject = clazz.getAnnotation(INJECT.class);
            if (inject != null) return new Object[]{EMPTY.class, false, true};
            if (allowSpring) {
                
                if (clazz.getAnnotation(Autowired.class) != null)
                    return new Object[]{EMPTY.class, false, true};
            }
        } else if (annotated instanceof Field) {
            Field f = (Field) annotated;
            INJECT inject = f.getAnnotation(INJECT.class);
            if (inject != null) return new Object[]{EMPTY.class, false, true};
            if (allowSpring) {
                if (f.getAnnotation(Autowired.class) != null) return new Object[]{EMPTY.class, false, true};
                if (f.getAnnotation(Value.class) != null) return new Object[]{EMPTY.class, false, true};
            }
        } else if (annotated instanceof Method) {
            Method m = (Method) annotated;
            INJECT inject = m.getAnnotation(INJECT.class);
            if (inject != null) return new Object[]{EMPTY.class, false, true};
            if (allowSpring) {
                if (m.getAnnotation(Autowired.class) != null) return new Object[]{EMPTY.class, false, true};
            }
        } else if (annotated instanceof Constructor<?>) {
            
            return new Object[]{EMPTY.class, false, true};
        }
        return null;
    }

    private static BeanBox[] getParameterInjectAsBeanBoxArray(Executable exec, boolean allowSpring) {
        
        Class<?>[] paramTypes = exec.getParameterTypes();
        BeanBox[] boxes = new BeanBox[paramTypes.length];
        for (int i = 0; i < paramTypes.length; i++) {
            BeanBox b = new BeanBox();
            b.setTarget(EMPTY.class);
            b.setRequired(true);
            boxes[i] = b;
        }
        return boxes;
    }

    private static Map<String, Object> changeAnnotationValuesToMap(Annotation anno) {
        Map<String, Object> map = new HashMap<>();
        
        Method[] methods = anno.annotationType().getDeclaredMethods();
        for (Method m : methods) {
            try {
                Object val = m.invoke(anno);
                map.put(m.getName(), val);
            } catch (Exception e) {  }
        }
        return map;
    }

    
    static class BeanBoxUtils {
        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private static BeanBox doCreateBeanBox(BeanBoxContext ctx, Class<?> clazz) {
            BeanBox box = new BeanBox();
            box.setBeanClass(clazz);
            box.setSingleton(true);

            if (!ctx.isAllowAnnotation())
                return box;
            boolean allowSpringJsrAnno = ctx.allowSpringJsrAnnotation();

            
            if (checkAnnoExist(clazz, PROTOTYPE.class))
                box.setSingleton(false);
            else if (allowSpringJsrAnno) {
                Map<String, Object> m = getAnnoAsMap(clazz, "org.springframework.context.annotation.Scope");
                if (m != null)
                    for (Entry<String, Object> entry : m.entrySet())
                        if ("value".equals(entry.getKey())) {
                            if ("prototype".equalsIgnoreCase(String.valueOf(entry.getValue())))
                                box.setSingleton(false);
                            else if ("singleton".equalsIgnoreCase(String.valueOf(entry.getValue())))
                                box.setSingleton(true);
                            else
                                BeanBoxException.throwEX("'prototype' or 'singleton' required in @Scope annotation");
                        }
            }

            
            Object[] v = getInjectAnnotationAsArray(clazz, allowSpringJsrAnno);
            if (v != null) {
                box.setTarget(v[0]);
                box.setPureValue((Boolean) v[1]);
                box.setRequired((Boolean) v[2]);
            }

            
            Annotation[] annos = clazz.getAnnotations();
            for (Annotation anno : annos) {
                if (anno.annotationType().isAnnotationPresent(AOP.class)) {
                    Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
                    Object aop = annoMap.get("value");
                    String methodNameRule = (String) annoMap.get("method");
                    if (methodNameRule != null && methodNameRule.length() > 0 && aop != null)
                        box.addBeanAop(aop, methodNameRule);
                }
            }

            
            Constructor<?>[] constrs = clazz.getConstructors();
            for (Constructor<?> constr : constrs) {
                v = getInjectAnnotationAsArray(constr, allowSpringJsrAnno);
                if (v != null) {
                    box.setBeanClass(clazz);
                    if (v[0] != null && EMPTY.class != v[0]) {
                        BeanBox inject = new BeanBox();
                        inject.setTarget(v[0]);
                        inject.setPureValue((Boolean) v[1]);
                        inject.setRequired((Boolean) v[2]);
                        inject.setType(constr.getParameterTypes()[0]);
                        box.setConstructor(constr);
                        box.setConstructorParams(new BeanBox[] { inject });
                    } else { 
                        BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(constr, allowSpringJsrAnno);
                        box.setConstructor(constr);
                        box.setConstructorParams(paramInjects);
                    }
                }
            }

            
            
            for (Field f : ReflectionUtils.getSelfAndSuperClassFields(clazz)) {
                v = getInjectAnnotationAsArray(f, allowSpringJsrAnno);
                if (v != null) {
                    box.checkOrCreateFieldInjects();
                    BeanBox inject = new BeanBox();
                    inject.setTarget(v[0]);
                    inject.setPureValue((Boolean) v[1]);
                    inject.setRequired((Boolean) v[2]);
                    inject.setType(f.getType());
                    ReflectionUtils.makeAccessible(f);
                    box.getFieldInjects().put(f, inject);
                }
            }

            
            Method[] methods = ReflectionUtils.getAllDeclaredMethods(clazz);
            for (Method m : methods) {
                
                if (m.getAnnotation(POSTCONSTRUCT.class) != null || m.getAnnotation(PostConstruct.class) != null) {
                    if (m.getParameterTypes().length > 0)
                        BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
                    ReflectionUtils.makeAccessible(m);
                    box.setPostConstruct(m);
                }
                if (m.getAnnotation(PREDESTROY.class) != null || m.getAnnotation(PreDestroy.class) != null) {
                    if (m.getParameterTypes().length > 0)
                        BeanBoxException.throwEX("In jBeanBox, PostConstruct should have no parameter.");
                    ReflectionUtils.makeAccessible(m);
                    box.setPreDestroy(m);
                }

                
                Annotation[] mtdAnnos = m.getAnnotations();
                for (Annotation anno : mtdAnnos)
                    if (anno.annotationType().isAnnotationPresent(AOP.class)) {
                        Map<String, Object> annoMap = changeAnnotationValuesToMap(anno);
                        Object aop = annoMap.get("value");
                        if (aop != null)
                            box.addMethodAop(aop, m);
                    }

                
                v = getInjectAnnotationAsArray(m, allowSpringJsrAnno);
                if (v != null) {
                    ReflectionUtils.makeAccessible(m);
                    BeanBox oneParam = new BeanBox();
                    oneParam.setTarget(v[0]);
                    oneParam.setPureValue((Boolean) v[1]);
                    oneParam.setRequired((Boolean) v[2]);
                    boolean haveOneParameter = v[0] != null && EMPTY.class != v[0];
                    if (haveOneParameter)
                        oneParam.setType(m.getParameterTypes()[0]); 
                    
                    box.checkOrCreateMethodInjects();
                    if (haveOneParameter) 
                        box.getMethodInjects().put(m, new BeanBox[] { oneParam });
                    else { 
                        BeanBox[] paramInjects = getParameterInjectAsBeanBoxArray(m, allowSpringJsrAnno);
                        box.getMethodInjects().put(m, paramInjects);
                    }
                }
            }
            return box;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }


    

    public static void main(String[] args) {
        System.out.println("=== Testing BeanBoxUtils.doCreateBeanBox ===\n");

        
        BeanBoxContext ctx = new BeanBoxContext();
        
        @PROTOTYPE
        class TestClass {
            @INJECT
            private String injectedField;

            @POSTCONSTRUCT
            public void init() { }

            @AOP(value = Object.class, method = "test")
            public void testMethod() { }
        }

        BeanBox box = BeanBoxUtils.doCreateBeanBox(ctx, TestClass.class);
        System.out.println("Created BeanBox for class: " + box.getBeanClass().getName());
        System.out.println("Singleton: " + box.isSingleton());
        System.out.println("Field injects count: " + (box.getFieldInjects() != null ? box.getFieldInjects().size() : 0));
        System.out.println("PostConstruct: " + (box.getPostConstruct() != null));
        System.out.println("PreDestroy: " + (box.getPreDestroy() != null));
        System.out.println("AOP rules: " + (box.getAopRules() != null ? box.getAopRules().size() : 0));

        System.out.println("\n=== Test completed ===");
    }
}
