
import java.util.*;






public class method_3_jbeanbox_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    static class AnalyzerException extends Exception {
        public AnalyzerException(String msg) { super(msg); }
        public AnalyzerException(Object node, String msg) { super(msg); }
        public AnalyzerException(Object node, String msg, Throwable cause) { super(msg, cause); }
        public Object node;
    }

    static class MethodNode {
        public int access;
        public String desc;
        public int maxLocals;
        public int maxStack;
        public InsnList instructions = new InsnList();
        public List<TryCatchBlockNode> tryCatchBlocks = new ArrayList<>();
    }

    static class InsnList {
        private List<AbstractInsnNode> list = new ArrayList<>();
        public int size() { return list.size(); }
        public AbstractInsnNode get(int index) { return list.get(index); }
        public int indexOf(AbstractInsnNode node) { return list.indexOf(node); }
        public void add(AbstractInsnNode insn) { list.add(insn); }
    }

    static abstract class AbstractInsnNode {
        public static final int LABEL = 1;
        public static final int LINE = 2;
        public static final int FRAME = 3;
        public static final int JUMP = 4;
        public static final int LOOKUPSWITCH = 5;
        public static final int TABLESWITCH = 6;
        public static final int VAR = 7;
        public static final int IINC = 8;
        
        public abstract int getOpcode();
        public abstract int getType();
    }

    static class JumpInsnNode extends AbstractInsnNode {
        public LabelNode label;
        public int opcode;
        public JumpInsnNode(int opcode, LabelNode label) { this.opcode = opcode; this.label = label; }
        public int getOpcode() { return opcode; }
        public int getType() { return JUMP; }
    }

    static class LookupSwitchInsnNode extends AbstractInsnNode {
        public LabelNode dflt;
        public List<LabelNode> labels = new ArrayList<>();
        public int getOpcode() { return -1; }
        public int getType() { return LOOKUPSWITCH; }
    }

    static class TableSwitchInsnNode extends AbstractInsnNode {
        public LabelNode dflt;
        public List<LabelNode> labels = new ArrayList<>();
        public int getOpcode() { return -1; }
        public int getType() { return TABLESWITCH; }
    }

    static class VarInsnNode extends AbstractInsnNode {
        public int var;
        public int opcode;
        public VarInsnNode(int opcode, int var) { this.opcode = opcode; this.var = var; }
        public int getOpcode() { return opcode; }
        public int getType() { return VAR; }
    }

    static class IincInsnNode extends AbstractInsnNode {
        public int var;
        public int opcode = 132;
        public IincInsnNode(int var, int inc) { this.var = var; }
        public int getOpcode() { return opcode; }
        public int getType() { return IINC; }
    }

    static class LabelNode extends AbstractInsnNode {
        public int getOpcode() { return -1; }
        public int getType() { return LABEL; }
    }

    static class TryCatchBlockNode {
        public LabelNode start, end, handler;
        public String type;
    }

    static class Frame<V> {
        public Frame<V> init(Frame<V> f) { return this; }
        public void clearStack() {  }
        public void push(V value) {  }
        public void execute(AbstractInsnNode insn, Interpreter<V> interp) throws AnalyzerException {  }
        public void setReturn(V value) {  }
        public void setLocal(int idx, V value) {  }
        public Frame<V> copy() { return new Frame<>(); }
        
    }

    static class Subroutine {
        public LabelNode start;
        public boolean[] access;
        public List<JumpInsnNode> callers = new ArrayList<>();
        public Subroutine(LabelNode start, int maxLocals, JumpInsnNode caller) {
            this.start = start;
            access = new boolean[maxLocals];
            if (caller != null) callers.add(caller);
        }
        public Subroutine copy() {
            Subroutine s = new Subroutine(start, access.length, null);
            s.callers.addAll(callers);
            System.arraycopy(access, 0, s.access, 0, access.length);
            return s;
        }
    }

    static class Interpreter<V> {
        public V newValue(Type type) { return null; }
        
    }

    static class Type {
        public static Type getReturnType(String desc) { return new Type(); }
        public static Type[] getArgumentTypes(String desc) { return new Type[0]; }
        public static Type getObjectType(String name) { return new Type(); }
        public int getSize() { return 1; }
    }

    

    static class Analyzer<V> {
        private Interpreter<V> interpreter;
        private Frame<V>[] frames;
        private InsnList insns;
        private List<TryCatchBlockNode>[] handlers;
        private Subroutine[] subroutines;
        private boolean[] queued;
        private int[] queue;
        private int top;
        private int n;

        public Analyzer(Interpreter<V> interpreter) { this.interpreter = interpreter; }

        
        private Frame<V> newFrame(int maxLocals, int maxStack) { return new Frame<>(); }
        private void merge(int insn, Frame<V> frame, Subroutine sub) {  }
        private void merge(int insn, Frame<V> frame, Frame<V> current, Subroutine sub, boolean[] access) {  }
        private void newControlFlowEdge(int from, int to) {  }
        private boolean newControlFlowExceptionEdge(int insn, TryCatchBlockNode tcb) { return true; }
        private void findSubroutine(int start, Subroutine sub, List<AbstractInsnNode> calls) {  }
        private void init(String owner, MethodNode m) {  }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public Frame<V>[] analyze(final String owner, final MethodNode m)
                throws AnalyzerException {
            if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) != 0) {
                frames = (Frame<V>[]) new Frame<?>[0];
                return frames;
            }
            n = m.instructions.size();
            insns = m.instructions;
            handlers = (List<TryCatchBlockNode>[]) new List<?>[n];
            frames = (Frame<V>[]) new Frame<?>[n];
            subroutines = new Subroutine[n];
            queued = new boolean[n];
            queue = new int[n];
            top = 0;

            
            for (int i = 0; i < m.tryCatchBlocks.size(); ++i) {
                TryCatchBlockNode tcb = m.tryCatchBlocks.get(i);
                int begin = insns.indexOf(tcb.start);
                int end = insns.indexOf(tcb.end);
                for (int j = begin; j < end; ++j) {
                    List<TryCatchBlockNode> insnHandlers = handlers[j];
                    if (insnHandlers == null) {
                        insnHandlers = new ArrayList<TryCatchBlockNode>();
                        handlers[j] = insnHandlers;
                    }
                    insnHandlers.add(tcb);
                }
            }

            
            Subroutine main = new Subroutine(null, m.maxLocals, null);
            List<AbstractInsnNode> subroutineCalls = new ArrayList<AbstractInsnNode>();
            Map<LabelNode, Subroutine> subroutineHeads = new HashMap<LabelNode, Subroutine>();
            findSubroutine(0, main, subroutineCalls);
            while (!subroutineCalls.isEmpty()) {
                JumpInsnNode jsr = (JumpInsnNode) subroutineCalls.remove(0);
                Subroutine sub = subroutineHeads.get(jsr.label);
                if (sub == null) {
                    sub = new Subroutine(jsr.label, m.maxLocals, jsr);
                    subroutineHeads.put(jsr.label, sub);
                    findSubroutine(insns.indexOf(jsr.label), sub, subroutineCalls);
                } else {
                    sub.callers.add(jsr);
                }
            }
            for (int i = 0; i < n; ++i) {
                if (subroutines[i] != null && subroutines[i].start == null) {
                    subroutines[i] = null;
                }
            }

            
            Frame<V> current = newFrame(m.maxLocals, m.maxStack);
            Frame<V> handler = newFrame(m.maxLocals, m.maxStack);
            current.setReturn(interpreter.newValue(Type.getReturnType(m.desc)));
            Type[] args = Type.getArgumentTypes(m.desc);
            int local = 0;
            if ((m.access & ACC_STATIC) == 0) {
                Type ctype = Type.getObjectType(owner);
                current.setLocal(local++, interpreter.newValue(ctype));
            }
            for (int i = 0; i < args.length; ++i) {
                current.setLocal(local++, interpreter.newValue(args[i]));
                if (args[i].getSize() == 2) {
                    current.setLocal(local++, interpreter.newValue(null));
                }
            }
            while (local < m.maxLocals) {
                current.setLocal(local++, interpreter.newValue(null));
            }
            merge(0, current, null);

            init(owner, m);

            
            while (top > 0) {
                int insn = queue[--top];
                Frame<V> f = frames[insn];
                Subroutine subroutine = subroutines[insn];
                queued[insn] = false;

                AbstractInsnNode insnNode = null;
                try {
                    insnNode = m.instructions.get(insn);
                    int insnOpcode = insnNode.getOpcode();
                    int insnType = insnNode.getType();

                    if (insnType == AbstractInsnNode.LABEL
                            || insnType == AbstractInsnNode.LINE
                            || insnType == AbstractInsnNode.FRAME) {
                        merge(insn + 1, f, subroutine);
                        newControlFlowEdge(insn, insn + 1);
                    } else {
                        current.init(f).execute(insnNode, interpreter);
                        subroutine = subroutine == null ? null : subroutine.copy();

                        if (insnNode instanceof JumpInsnNode) {
                            JumpInsnNode j = (JumpInsnNode) insnNode;
                            if (insnOpcode != GOTO && insnOpcode != JSR) {
                                merge(insn + 1, current, subroutine);
                                newControlFlowEdge(insn, insn + 1);
                            }
                            int jump = insns.indexOf(j.label);
                            if (insnOpcode == JSR) {
                                merge(jump, current, new Subroutine(j.label,
                                        m.maxLocals, j));
                            } else {
                                merge(jump, current, subroutine);
                            }
                            newControlFlowEdge(insn, jump);
                        } else if (insnNode instanceof LookupSwitchInsnNode) {
                            LookupSwitchInsnNode lsi = (LookupSwitchInsnNode) insnNode;
                            int jump = insns.indexOf(lsi.dflt);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                            for (int j = 0; j < lsi.labels.size(); ++j) {
                                LabelNode label = lsi.labels.get(j);
                                jump = insns.indexOf(label);
                                merge(jump, current, subroutine);
                                newControlFlowEdge(insn, jump);
                            }
                        } else if (insnNode instanceof TableSwitchInsnNode) {
                            TableSwitchInsnNode tsi = (TableSwitchInsnNode) insnNode;
                            int jump = insns.indexOf(tsi.dflt);
                            merge(jump, current, subroutine);
                            newControlFlowEdge(insn, jump);
                            for (int j = 0; j < tsi.labels.size(); ++j) {
                                LabelNode label = tsi.labels.get(j);
                                jump = insns.indexOf(label);
                                merge(jump, current, subroutine);
                                newControlFlowEdge(insn, jump);
                            }
                        } else if (insnOpcode == RET) {
                            if (subroutine == null) {
                                throw new AnalyzerException(insnNode,
                                        "RET instruction outside of a sub routine");
                            }
                            for (int i = 0; i < subroutine.callers.size(); ++i) {
                                JumpInsnNode caller = subroutine.callers.get(i);
                                int call = insns.indexOf(caller);
                                if (frames[call] != null) {
                                    merge(call + 1, frames[call], current,
                                            subroutines[call], subroutine.access);
                                    newControlFlowEdge(insn, call + 1);
                                }
                            }
                        } else if (insnOpcode != ATHROW
                                && (insnOpcode < IRETURN || insnOpcode > RETURN)) {
                            if (subroutine != null) {
                                if (insnNode instanceof VarInsnNode) {
                                    int var = ((VarInsnNode) insnNode).var;
                                    subroutine.access[var] = true;
                                    if (insnOpcode == LLOAD || insnOpcode == DLOAD
                                            || insnOpcode == LSTORE
                                            || insnOpcode == DSTORE) {
                                        subroutine.access[var + 1] = true;
                                    }
                                } else if (insnNode instanceof IincInsnNode) {
                                    int var = ((IincInsnNode) insnNode).var;
                                    subroutine.access[var] = true;
                                }
                            }
                            merge(insn + 1, current, subroutine);
                            newControlFlowEdge(insn, insn + 1);
                        }
                    }

                    List<TryCatchBlockNode> insnHandlers = handlers[insn];
                    if (insnHandlers != null) {
                        for (int i = 0; i < insnHandlers.size(); ++i) {
                            TryCatchBlockNode tcb = insnHandlers.get(i);
                            Type type;
                            if (tcb.type == null) {
                                type = Type.getObjectType("java/lang/Throwable");
                            } else {
                                type = Type.getObjectType(tcb.type);
                            }
                            int jump = insns.indexOf(tcb.handler);
                            if (newControlFlowExceptionEdge(insn, tcb)) {
                                handler.init(f);
                                handler.clearStack();
                                handler.push(interpreter.newValue(type));
                                merge(jump, handler, subroutine);
                            }
                        }
                    }
                } catch (AnalyzerException e) {
                    throw new AnalyzerException(e.node, "Error at instruction "
                            + insn + ": " + e.getMessage(), e);
                } catch (Exception e) {
                    throw new AnalyzerException(insnNode, "Error at instruction "
                            + insn + ": " + e.getMessage(), e);
                }
            }

            return frames;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        

        
        private static final int ACC_ABSTRACT = 0x0400;
        private static final int ACC_NATIVE = 0x0100;
        private static final int ACC_STATIC = 0x0008;
        private static final int GOTO = 167;
        private static final int JSR = 168;
        private static final int RET = 169;
        private static final int ATHROW = 191;
        private static final int IRETURN = 172;
        private static final int RETURN = 177;
        private static final int LLOAD = 22;
        private static final int DLOAD = 24;
        private static final int LSTORE = 55;
        private static final int DSTORE = 57;
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing Analyzer.analyze ===\n");

        
        MethodNode m = new MethodNode();
        m.access = 0; 
        m.desc = "()V";
        m.maxLocals = 1;
        m.maxStack = 1;
        
        InsnList insns = m.instructions;
        LabelNode label = new LabelNode();
        insns.add(label);
        
        AbstractInsnNode ret = new AbstractInsnNode() {
            public int getOpcode() { return 177; }
            public int getType() { return 0; }
        };
        insns.add(ret);

        
        Interpreter<Object> interpreter = new Interpreter<Object>() { };

        Analyzer<Object> analyzer = new Analyzer<>(interpreter);
        try {
            Frame<Object>[] frames = analyzer.analyze("TestClass", m);
            System.out.println("Analysis completed. Frames length: " + (frames != null ? frames.length : 0));
        } catch (AnalyzerException e) {
            System.err.println("Analysis exception: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}
