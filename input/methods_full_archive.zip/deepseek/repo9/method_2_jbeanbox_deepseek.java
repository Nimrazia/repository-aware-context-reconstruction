
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.Map.Entry;






public class method_2_jbeanbox_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    
    static @interface INJECT {}
    static @interface POSTCONSTRUCT {}
    static @interface PREDESTROY {}
    static @interface AOP { Class<?> value() default Object.class; String method() default ""; }
    static class EMPTY { }

    
    static class BeanBoxException extends RuntimeException {
        public BeanBoxException(String msg) { super(msg); }
        public BeanBoxException(Throwable cause) { super(cause); }
        public BeanBoxException(String msg, Throwable cause) { super(msg, cause); }
        public static Object throwEX(String msg) { throw new BeanBoxException(msg); }
        public static Object throwEX(Throwable t) { throw new BeanBoxException(t); }
        public static Object throwEX(String msg, Throwable t) { throw new BeanBoxException(msg, t); }
        public static void assureNotNull(Object o, String msg) { if (o == null) throwEX(msg); }
    }

    
    static class BeanBox {
        private Class<?> beanClass;
        private boolean singleton = true;
        private Object target;
        private boolean pureValue;
        private boolean required;
        private Constructor<?> constructor;
        private BeanBox[] constructorParams;
        private Map<Field, BeanBox> fieldInjects;
        private Map<Method, BeanBox[]> methodInjects;
        private Method postConstruct;
        private Method preDestroy;
        private List<Object[]> aopRules = new ArrayList<>();
        private Map<Method, Object> methodAops = new HashMap<>();
        private Method createMethod;
        private Method configMethod;
        private Object singletonId;
        private Class<?> type;

        public Class<?> getBeanClass() { return beanClass; }
        public void setBeanClass(Class<?> c) { this.beanClass = c; }
        public boolean isSingleton() { return singleton; }
        public void setSingleton(boolean s) { singleton = s; }
        public Object getTarget() { return target; }
        public void setTarget(Object t) { this.target = t; }
        public boolean isPureValue() { return pureValue; }
        public void setPureValue(boolean p) { pureValue = p; }
        public boolean isRequired() { return required; }
        public void setRequired(boolean r) { required = r; }
        public Constructor<?> getConstructor() { return constructor; }
        public void setConstructor(Constructor<?> c) { this.constructor = c; }
        public BeanBox[] getConstructorParams() { return constructorParams; }
        public void setConstructorParams(BeanBox[] p) { constructorParams = p; }
        public Map<Field, BeanBox> getFieldInjects() { return fieldInjects; }
        public void setFieldInjects(Map<Field, BeanBox> m) { fieldInjects = m; }
        public Map<Method, BeanBox[]> getMethodInjects() { return methodInjects; }
        public void setMethodInjects(Map<Method, BeanBox[]> m) { methodInjects = m; }
        public Method getPostConstruct() { return postConstruct; }
        public void setPostConstruct(Method m) { postConstruct = m; }
        public Method getPreDestroy() { return preDestroy; }
        public void setPreDestroy(Method m) { preDestroy = m; }
        public List<Object[]> getAopRules() { return aopRules; }
        public void setAopRules(List<Object[]> r) { aopRules = r; }
        public Map<Method, Object> getMethodAops() { return methodAops; }
        public Method getCreateMethod() { return createMethod; }
        public void setCreateMethod(Method m) { createMethod = m; }
        public Method getConfigMethod() { return configMethod; }
        public void setConfigMethod(Method m) { configMethod = m; }
        public Object getSingletonId() { return singletonId; }
        public void setSingletonId(Object id) { singletonId = id; }
        public void setType(Class<?> t) { this.type = t; }
        public Class<?> getType() { return type; }
        
        public void addBeanAop(Object aop, String rule) { aopRules.add(new Object[]{aop, rule}); }
        public void addMethodAop(Object aop, Method m) { methodAops.put(m, aop); }
    }

    static class BeanBoxContext {
        protected Map<BeanBox, Object> singletonCache = new HashMap<>();
        private List<Object[]> aopRules = new ArrayList<>();
        protected ValueTranslator valueTranslator = new ValueTranslator();

        public Map<BeanBox, Object> getSingletonCache() { return singletonCache; }
        public List<Object[]> getAopRules() { return aopRules; }
        public ValueTranslator getValueTranslator() { return valueTranslator; }

        
        public Object getBean(Object target, boolean required, Set<Object> history) {
            if (target == EMPTY.class) return EMPTY.class;
            return new Object(); 
        }
        public Object getBean(Class<?> type, boolean required, Set<Object> history) {
            return new Object(); 
        }
        public Object notfoundOrException(Object target, boolean required) {
            if (required) throw new BeanBoxException("Bean not found: " + target);
            return null;
        }

        
        private Object getBeanFromBox(BeanBox box, boolean required, Set<Object> history) {
            
            
            return null;
        }

        
        protected Object[] param2RealObjects(BeanBoxContext ctx, Set<Object> history, BeanBox[] paramBoxes) {
            Object[] objects = new Object[paramBoxes.length];
            for (int i = 0; i < paramBoxes.length; i++) {
                objects[i] = getBeanFromBox(paramBoxes[i], false, history);
            }
            return objects;
        }

        
        static class ValueTranslator {
            public Object translate(String str, Class<?> type) {
                if (type == String.class) return str;
                if (type == Integer.class) return Integer.parseInt(str);
                return str;
            }
        }
    }

    
    static class AopUtils {
        public static Object createProxyBean(Class<?> beanClass, BeanBox box, BeanBoxContext ctx) {
            
            try {
                return beanClass.newInstance();
            } catch (Exception e) {
                throw new BeanBoxException(e);
            }
        }
    }

    
    static class ReflectionUtils {
        public static void invokeMethod(Method m, Object target, Object... args) {
            try { m.invoke(target, args); } catch (Exception e) { throw new BeanBoxException(e); }
        }
        public static void setField(Field f, Object target, Object value) {
            try { f.set(target, value); } catch (Exception e) { throw new BeanBoxException(e); }
        }
    }

    
    static class BeanBoxUtils {
        public static boolean nameMatch(String pattern, String name) {
            
            return pattern.equals(name) || (pattern.endsWith("*") && name.startsWith(pattern.substring(0, pattern.length()-1)));
        }
    }

    
    static class Caller {
        public Caller(BeanBoxContext ctx, boolean required, Set<Object> history, Object bean) { }
    }

    

    static class BeanBoxContextWithMethod extends BeanBoxContext {
        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private Object getBeanFromBox(BeanBox box, boolean required, Set<Object> history) {
            
            BeanBoxException.assureNotNull(box, "Fail to build instance for a null beanBox");
            Object bean = null;
            if (box.isSingleton()) { 
                bean = singletonCache.get(box);
                if (bean != null)
                    return bean;
            }

            if (box.isPureValue()) 
                return box.getTarget();
            if (box.getTarget() != null) {
                if (EMPTY.class != box.getTarget())
                    return getBean(box.getTarget(), box.isRequired(), history);
                if (box.getType() != null)
                    return getBean(box.getType(), box.isRequired(), history);
                else
                    return notfoundOrException(box.getTarget(), box.isRequired());
            }

            boolean aopFound = false;
            if (box.getAopRules() != null || box.getMethodAops() != null)
                aopFound = true;
            else if (this.getAopRules() != null && box.getBeanClass() != null)
                for (Object[] aops : this.getAopRules()) 
                    if (BeanBoxUtils.nameMatch((String) aops[1], box.getBeanClass().getName())) {
                        aopFound = true;
                        break;
                    }
            if (aopFound)
                bean = AopUtils.createProxyBean(box.getBeanClass(), box, this);
            else if (box.getCreateMethod() != null) 
                try {
                    Method m = box.getCreateMethod();
                    if (m.getParameterTypes().length == 1) {
                        bean = m.invoke(box, new Caller(this, required, history, null));
                    } else if (m.getParameterTypes().length == 0)
                        bean = m.invoke(box);
                    else
                        BeanBoxException.throwEX("Create method can only have 0 or 1 parameter");
                    BeanBoxException.assureNotNull(bean, "Create method created a null object.");
                } catch (Exception e) {
                    return BeanBoxException.throwEX(e);
                }
            else if (box.getConstructor() != null) { 
                if (box.getConstructorParams() != null && box.getConstructorParams().length > 0) {
                    Object[] initargs = param2RealObjects(this, history, box.getConstructorParams());
                    try {
                        bean = box.getConstructor().newInstance(initargs);
                    } catch (Exception e) {
                        return BeanBoxException.throwEX(e);
                    }
                } else 
                    try {
                        bean = box.getConstructor().newInstance();
                    } catch (Exception e) {
                        return BeanBoxException.throwEX(e);
                    }
            } else if (box.getBeanClass() != null) { 
                if (EMPTY.class == box.getBeanClass())
                    return notfoundOrException(EMPTY.class, required);
                try {
                    bean = box.getBeanClass().newInstance();
                } catch (Exception e) {
                    BeanBoxException.throwEX("Failed to call 0 parameter constructor of: " + box.getBeanClass(), e);
                }
            } else
                return notfoundOrException(null, required); 

            

            
            if (box.isSingleton()) {
                Object id = box.getSingletonId();
                if (id != null)
                    singletonCache.put(box, bean);
            } 

            if (box.getConfigMethod() != null) {
                try {
                    Method m = box.getConfigMethod();
                    if (m.getParameterTypes().length == 2)
                        m.invoke(box, bean, new Caller(this, required, history, bean));
                    else if (m.getParameterTypes().length == 1)
                        m.invoke(box, bean);
                    else
                        BeanBoxException.throwEX("Config method can only have 1 or 2 parameters");
                } catch (Exception e) {
                    return BeanBoxException.throwEX(e);
                }
            }

            if (box.getPostConstruct() != null) 
                ReflectionUtils.invokeMethod(box.getPostConstruct(), bean);

            if (box.getFieldInjects() != null) 
                for (Entry<Field, BeanBox> entry : box.getFieldInjects().entrySet()) {
                    Field f = entry.getKey();
                    BeanBox b = entry.getValue();
                    Object fieldValue = this.getBeanFromBox(b, false, history);
                    if (EMPTY.class == fieldValue) {
                        if (b.isRequired())
                            BeanBoxException.throwEX("Not found required value for field: " + f.getName() + " in "
                                    + f.getDeclaringClass().getName());
                    } else {
                        if (fieldValue != null && fieldValue instanceof String)
                            fieldValue = this.valueTranslator.translate((String) fieldValue, b.getType());
                        ReflectionUtils.setField(f, bean, fieldValue);
                    }
                }

            if (box.getMethodInjects() != null) { 
                for (Entry<Method, BeanBox[]> methods : box.getMethodInjects().entrySet()) {
                    Method m = methods.getKey();
                    BeanBox[] paramBoxs = methods.getValue();
                    if (paramBoxs != null && paramBoxs.length > 0) {
                        Object[] methodParams = param2RealObjects(this, history, paramBoxs);
                        ReflectionUtils.invokeMethod(m, bean, methodParams);
                    } else 
                        ReflectionUtils.invokeMethod(m, bean);
                }
            }
            return bean;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing BeanBoxContext.getBeanFromBox ===\n");

        BeanBoxContextWithMethod ctx = new BeanBoxContextWithMethod();

        
        class TestClass { }
        BeanBox box = new BeanBox();
        box.setBeanClass(TestClass.class);
        box.setSingleton(true);

        Set<Object> history = new HashSet<>();

        Object bean = ctx.getBeanFromBox(box, true, history);
        System.out.println("Created bean: " + bean);
        System.out.println("Bean class: " + bean.getClass().getName());

        
        BeanBox pureBox = new BeanBox();
        pureBox.setPureValue(true);
        pureBox.setTarget("Hello");
        Object value = ctx.getBeanFromBox(pureBox, true, history);
        System.out.println("Pure value: " + value);

        
        BeanBox targetBox = new BeanBox();
        targetBox.setTarget(EMPTY.class); 
        try {
            ctx.getBeanFromBox(targetBox, true, history);
        } catch (BeanBoxException e) {
            System.out.println("Expected exception: " + e.getMessage());
        }

        System.out.println("\n=== Test completed ===");
    }
}
