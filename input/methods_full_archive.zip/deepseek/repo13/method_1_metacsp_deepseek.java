
import java.awt.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;


class JFreeChart {
    private String title;
    private CategoryPlot plot;
    private ChartTitle chartTitle;
    public JFreeChart(String title, CategoryPlot plot) { this.title = title; this.plot = plot; chartTitle = new ChartTitle(title); }
    public CategoryPlot getCategoryPlot() { return plot; }
    public ChartTitle getTitle() { return chartTitle; }
    static class ChartTitle {
        private String text;
        public ChartTitle(String t) { text = t; }
        public void setHorizontalAlignment(HorizontalAlignment align) {  }
        public String getText() { return text; }
    }
}

class ChartFactory {
    public static JFreeChart createStackedBarChart(String title, String domain, String range,
                                                    CategoryDataset dataset, PlotOrientation orientation,
                                                    boolean legend, boolean tooltips, boolean urls) {
        CategoryPlot plot = new CategoryPlot(dataset, new StackedBarRenderer(), new NumberAxis());
        return new JFreeChart(title, plot);
    }
}

interface CategoryDataset {
    int getRowCount();
    
}

class CategoryPlot {
    private CategoryDataset dataset;
    private CategoryItemRenderer renderer;
    private NumberAxis rangeAxis;
    private float foregroundAlpha = 1.0f;
    public CategoryPlot(CategoryDataset data, CategoryItemRenderer r, NumberAxis axis) {
        dataset = data; renderer = r; rangeAxis = axis;
    }
    public CategoryItemRenderer getRenderer() { return renderer; }
    public void setRenderer(CategoryItemRenderer r) { renderer = r; }
    public void setRangeAxisLocation(AxisLocation loc) {  }
    public NumberAxis getRangeAxis() { return rangeAxis; }
    public void setForegroundAlpha(float alpha) { foregroundAlpha = alpha; }
    public void setDomainAxis(CategoryAxis axis) {  }
    public void setRangeAxis(NumberAxis axis) { rangeAxis = axis; }
}

class CategoryItemRenderer {  }

class StackedBarRenderer extends CategoryItemRenderer {
    private boolean itemLabelsVisible = false;
    private ItemLabelGenerator generator;
    private ItemLabelPosition fallback;
    private java.util.Map<Integer, ItemLabelPosition> posMap = new java.util.HashMap<>();
    private ToolTipGenerator tooltipGenerator;
    private java.util.Map<Integer, Color> seriesPaints = new java.util.HashMap<>();
    private java.util.Map<Integer, Color> seriesOutlinePaints = new java.util.HashMap<>();
    private java.util.Map<Integer, Stroke> seriesStrokes = new java.util.HashMap<>();
    private boolean baseSeriesVisibleInLegend = true;

    public void setItemLabelsVisible(boolean visible) { itemLabelsVisible = visible; }
    public void setItemLabelGenerator(ItemLabelGenerator gen) { generator = gen; }
    public void setPositiveItemLabelPositionFallback(ItemLabelPosition pos) { fallback = pos; }
    public void setSeriesPositiveItemLabelPosition(int series, ItemLabelPosition pos) { posMap.put(series, pos); }
    public void setToolTipGenerator(ToolTipGenerator gen) { tooltipGenerator = gen; }
    public void setSeriesPaint(int series, Color color) { seriesPaints.put(series, color); }
    public void setSeriesOutlinePaint(int series, Color color) { seriesOutlinePaints.put(series, color); }
    public void setSeriesStroke(int series, Stroke stroke) { seriesStrokes.put(series, stroke); }
    public void setBaseSeriesVisibleInLegend(boolean visible, boolean notify) { baseSeriesVisibleInLegend = visible; }
    public void setBase(long baseVal) {  }
}

interface ItemLabelGenerator { }
interface ToolTipGenerator { }

class LabelGenerator implements ItemLabelGenerator {
    public LabelGenerator(boolean showLabels) {  }
}

class PlotBoxTooltip implements ToolTipGenerator { }

class ItemLabelPosition {
    public ItemLabelPosition(ItemLabelAnchor anchor, TextAnchor textAnchor) {  }
}

enum ItemLabelAnchor { INSIDE1 }
enum TextAnchor { TOP_RIGHT }
enum PlotOrientation { HORIZONTAL }
enum HorizontalAlignment { LEFT }
enum AxisLocation { BOTTOM_OR_RIGHT }

class CategoryAxis { }

class NumberAxis {
    public static NumberTickUnits createIntegerTickUnits() { return new NumberTickUnits(); }
    private NumberFormat numberFormatOverride;
    private double lowerMargin, upperMargin;
    private Range range;
    private boolean autoTickUnitSelection = true;
    public void setStandardTickUnits(NumberTickUnits units) {  }
    public void setLowerMargin(double margin) { lowerMargin = margin; }
    public void setUpperMargin(double margin) { upperMargin = margin; }
    public void setNumberFormatOverride(NumberFormat fmt) { numberFormatOverride = fmt; }
    public void setRange(Range r) { range = r; }
    public void setRange(double lower, double upper) { range = new Range(lower, upper); }
}

class NumberTickUnits { }

class Range {
    public Range(double lower, double upper) {  }
}

class Stroke { }

class BasicStroke extends Stroke {
    public BasicStroke(float width) {  }
}

class Color {
    public static final Color black = new Color(0,0,0);
    public Color(int r, int g, int b) {  }
}



interface STL {
    Long[] getPulses();
    boolean isInconsistent(Object val);
    boolean isCritical(Object val);
    boolean isUndetermined(Object val);
}



class PlotBoxTLSmall {
    private String name = "Test Chart";
    private STL stl;
    private Object[] values;
    private Long[] durations;
    private Range range = null;
    private boolean showlabels = true;
    private JFreeChart chart;

    public PlotBoxTLSmall(STL stl, Object[] values, Long[] durations) {
        this.stl = stl;
        this.values = values;
        this.durations = durations;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @SuppressWarnings("deprecation")
    private JFreeChart createChart(CategoryDataset dataset) {


        String s = null;
        String tit = null;
        String ax = null;





        tit = this.name;

        chart = ChartFactory.createStackedBarChart(
            tit,  
            s,                  
            ax,                     
            dataset,                     
            PlotOrientation.HORIZONTAL,    
            false,                        
            false,                       
            false                        
        );
        CategoryPlot plot = chart.getCategoryPlot();

        chart.getTitle().setHorizontalAlignment(HorizontalAlignment.LEFT);
        plot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_RIGHT);

        
        
        StackedBarRenderer renderer = (StackedBarRenderer) plot.getRenderer();
        renderer.setItemLabelsVisible(true);
        renderer.setItemLabelGenerator(new LabelGenerator(showlabels));
        ItemLabelPosition pos = new ItemLabelPosition(ItemLabelAnchor.INSIDE1, TextAnchor.TOP_RIGHT);
        renderer.setPositiveItemLabelPositionFallback(pos);
        for(int i = 0; i < dataset.getRowCount(); i++) {
            renderer.setSeriesPositiveItemLabelPosition(i, pos);
        }

        






        renderer.setToolTipGenerator(new PlotBoxTooltip());
        plot.setRenderer(renderer);
       
        plot.setForegroundAlpha(0.8f);

        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        rangeAxis.setLowerMargin(2.0);
        rangeAxis.setUpperMargin(2.0);

        
        
        long origin = stl.getPulses()[0].longValue();
        NumberFormat nf = new DecimalFormat();
        rangeAxis.setNumberFormatOverride ( nf );
        if (this.range != null) rangeAxis.setRange(range);
        

        
        renderer.setBase(origin);

        

        for (int i = 0; i < durations.length; i++) {
            if (stl.isInconsistent(values[i]))
                renderer.setSeriesPaint(i, new Color(198, 30, 69));
            else if (stl.isCritical(values[i]))
                    renderer.setSeriesPaint(i, new Color(238,234,111));
            else if (stl.isUndetermined(values[i]))
                renderer.setSeriesPaint(i, new Color(255,255,255));
            else renderer.setSeriesPaint(i, new Color(111,180,238));
            renderer.setSeriesOutlinePaint(i, Color.black);
        }

        renderer.setBaseSeriesVisibleInLegend(false, false);

        renderer.setSeriesStroke(0, new BasicStroke(40f));

        return chart;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_1_metacsp_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing PlotBoxTLSmall.createChart ===\n");

        
        STL stl = new STL() {
            public Long[] getPulses() { return new Long[]{1000L, 2000L}; }
            public boolean isInconsistent(Object val) { return false; }
            public boolean isCritical(Object val) { return true; }
            public boolean isUndetermined(Object val) { return false; }
        };

        Object[] values = new Object[]{"A", "B"};
        Long[] durations = new Long[]{10L, 20L};

        PlotBoxTLSmall plotBox = new PlotBoxTLSmall(stl, values, durations);

        
        CategoryDataset dataset = new CategoryDataset() {
            public int getRowCount() { return 2; }
        };

        JFreeChart chart;
        try {
            java.lang.reflect.Method createChart = PlotBoxTLSmall.class.getDeclaredMethod("createChart", CategoryDataset.class);
            createChart.setAccessible(true);
            chart = (JFreeChart) createChart.invoke(plotBox, dataset);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Chart created: " + chart);
        System.out.println("Chart title: " + chart.getTitle().getText());

        System.out.println("\n=== Test completed ===");
    }
}