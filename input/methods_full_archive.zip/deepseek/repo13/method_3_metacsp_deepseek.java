
import java.util.*;


class DirectedSparseMultigraph<V,E> {
    private Set<V> vertices = new HashSet<>();
    private Map<V, Set<E>> edges = new HashMap<>();
    public void addVertex(V v) { vertices.add(v); }
    public void addEdge(E edge, V source, V target) {
        edges.computeIfAbsent(source, k -> new HashSet<>()).add(edge);
        
    }
}


class ConstraintNetwork {
    private Constraint[] constraints;
    public ConstraintNetwork(Constraint[] cons) { constraints = cons; }
    public Constraint[] getConstraints() { return constraints; }
}

interface Constraint {
    Variable getFrom();
    Variable getTo();
}

class AllenIntervalConstraint implements Constraint {
    public enum Type { BeforeOrMeets }
    private Type[] types;
    private Variable from, to;
    public AllenIntervalConstraint(Variable from, Variable to, Type[] types) {
        this.from = from; this.to = to; this.types = types;
    }
    public Type[] getTypes() { return types; }
    public Variable getFrom() { return from; }
    public Variable getTo() { return to; }
}

interface Variable { }

class TrajectoryEnvelope implements Variable {
    private Trajectory trajectory;
    private TrajectoryEnvelope superEnvelope;
    private List<Variable> dependentVars = new ArrayList<>();
    private boolean hasSubEnvelopes = false;
    private int seqStart, seqEnd;

    public TrajectoryEnvelope(Trajectory traj, int start, int end) {
        this.trajectory = traj; seqStart = start; seqEnd = end;
    }
    public Trajectory getTrajectory() { return trajectory; }
    public TrajectoryEnvelope getSuperEnvelope() { return superEnvelope; }
    public boolean hasSuperEnvelope() { return superEnvelope != null; }
    public void setSuperEnvelope(TrajectoryEnvelope se) { superEnvelope = se; }
    public void addDependentVariable(Variable v) { dependentVars.add(v); }
    public Variable[] getRecursivelyDependentVariables() {
        return dependentVars.toArray(new Variable[0]);
    }
    public boolean hasSubEnvelopes() { return hasSubEnvelopes; }
    public int getSequenceNumberStart() { return seqStart; }
    public int getSequenceNumberEnd() { return seqEnd; }
    public void setHasSubEnvelopes(boolean b) { hasSubEnvelopes = b; }
}

class Trajectory {
    private int seqStart, seqEnd;
    public Trajectory(int start, int end) { seqStart = start; seqEnd = end; }
    public int getSequenceNumberStart() { return seqStart; }
    public int getSequenceNumberEnd() { return seqEnd; }
}



class TrajectoryEnvelopeScheduler {
    private ConstraintSolver[] constraintSolvers;
    public TrajectoryEnvelopeScheduler(ConstraintSolver... solvers) {
        constraintSolvers = solvers;
    }
    public ConstraintSolver[] getConstraintSolvers() { return constraintSolvers; }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> getCurrentDependencies() {
        DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> depGraph = new DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]>();
        ConstraintNetwork cn = this.getConstraintSolvers()[0].getConstraintNetwork();
        Constraint[] cons = cn.getConstraints();
        for (Constraint con : cons) {
            if (con instanceof AllenIntervalConstraint) {
                AllenIntervalConstraint aic = (AllenIntervalConstraint)con;
                if (aic.getTypes()[0].equals(AllenIntervalConstraint.Type.BeforeOrMeets)) {

                    
                    TrajectoryEnvelope mustWaitToStart = (TrajectoryEnvelope)aic.getTo();
                    TrajectoryEnvelope mustFinishBeforeOtherCanStart = (TrajectoryEnvelope)aic.getFrom();
                    TrajectoryEnvelope waitingEnvelope = null;

                    
                    TrajectoryEnvelope root = mustWaitToStart;
                    while (root.hasSuperEnvelope()) root = root.getSuperEnvelope();
                    for (Variable depVar : root.getRecursivelyDependentVariables()) {
                        TrajectoryEnvelope depTE = (TrajectoryEnvelope)depVar;
                        if (!depTE.hasSubEnvelopes() && depTE.getTrajectory().getSequenceNumberEnd() == mustWaitToStart.getSequenceNumberStart()-1) {
                            waitingEnvelope = depTE;
                            break;
                        }
                    }

                    
                    Integer thresholdPoint = mustFinishBeforeOtherCanStart.getTrajectory().getSequenceNumberEnd();
                    Integer waitingPoint = null;

                    
                    if (waitingEnvelope == null) {
                        
                        waitingPoint = mustWaitToStart.getTrajectory().getSequenceNumberStart();
                        waitingEnvelope = mustWaitToStart;
                    }
                    else {
                        waitingPoint = waitingEnvelope.getTrajectory().getSequenceNumberEnd();
                    }

                    
                    ArrayList<TrajectoryEnvelope> verts = new ArrayList<TrajectoryEnvelope>();
                    verts.add(waitingEnvelope);
                    verts.add(mustFinishBeforeOtherCanStart);
                    depGraph.addVertex(waitingEnvelope);
                    depGraph.addVertex(mustFinishBeforeOtherCanStart);
                    depGraph.addEdge(new Integer[] {waitingPoint,thresholdPoint}, waitingEnvelope, mustFinishBeforeOtherCanStart);
                }
            }
        }
        return depGraph;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}


interface ConstraintSolver {
    ConstraintNetwork getConstraintNetwork();
}



public class method_3_metacsp_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing TrajectoryEnvelopeScheduler.getCurrentDependencies ===\n");

        
        
        Trajectory trajA = new Trajectory(0, 10);
        Trajectory trajB = new Trajectory(11, 20);

        
        TrajectoryEnvelope teA = new TrajectoryEnvelope(trajA, 0, 10);
        TrajectoryEnvelope teB = new TrajectoryEnvelope(trajB, 11, 20);
        
        teA.addDependentVariable(teB);
        teA.setHasSubEnvelopes(false);
        teB.setHasSubEnvelopes(false);

        
        AllenIntervalConstraint.Type[] types = new AllenIntervalConstraint.Type[]{AllenIntervalConstraint.Type.BeforeOrMeets};
        AllenIntervalConstraint aic = new AllenIntervalConstraint(teA, teB, types);

        ConstraintNetwork cn = new ConstraintNetwork(new Constraint[]{aic});

        
        ConstraintSolver solver = new ConstraintSolver() {
            public ConstraintNetwork getConstraintNetwork() { return cn; }
        };

        TrajectoryEnvelopeScheduler scheduler = new TrajectoryEnvelopeScheduler(solver);

        DirectedSparseMultigraph<TrajectoryEnvelope,Integer[]> graph = scheduler.getCurrentDependencies();
        System.out.println("Dependency graph created: " + graph);

        System.out.println("\n=== Test completed ===");
    }
}