import java.util.logging.Logger;
import java.util.logging.Level;
import java.lang.reflect.Method;
import java.util.*;




interface IBelief {
    Object getFact();
    void setFact(Object fact);
}
interface IBeliefbase {
    IBelief getBelief(String name);
}
interface IInternalAccess {
    IBeliefbase getBeliefbase();
    Object getServiceContainer();
    IGoal createGoal(String type);
    IMessageEvent createMessageEvent(String type);
    void dispatchSubgoalAndWait(IGoal goal);
    void sendMessage(IMessageEvent msg);
}


class IGoal {
    private Map<String, Object> parameters = new HashMap<>();
    private Map<String, ParameterSet> parameterSets = new HashMap<>();
    public Parameter getParameter(String name) {
        if (!parameters.containsKey(name)) parameters.put(name, new Parameter());
        return (Parameter) parameters.get(name);
    }
    public ParameterSet getParameterSet(String name) {
        if (!parameterSets.containsKey(name)) parameterSets.put(name, new ParameterSet());
        return parameterSets.get(name);
    }
    static class Parameter {
        private Object value;
        public void setValue(Object val) { this.value = val; }
        public Object getValue() { return value; }
    }
    static class ParameterSet {
        private List<Object> values = new ArrayList<>();
        public void addValue(Object val) { values.add(val); }
        public Object[] getValues() {
            if (!values.isEmpty() && values.get(0) instanceof IDFComponentDescription) {
                return values.toArray(new IDFComponentDescription[0]);
            }
            return values.toArray();
        }
    }
}


class IMessageEvent {
    private Map<String, Object> parameters = new HashMap<>();
    private Map<String, ParameterSet> parameterSets = new HashMap<>();
    public Parameter getParameter(String name) {
        if (!parameters.containsKey(name)) parameters.put(name, new Parameter());
        return (Parameter) parameters.get(name);
    }
    public ParameterSet getParameterSet(String name) {
        if (!parameterSets.containsKey(name)) parameterSets.put(name, new ParameterSet());
        return parameterSets.get(name);
    }
    static class Parameter {
        private Object value;
        public void setValue(Object val) { this.value = val; }
        public Object getValue() { return value; }
    }
    static class ParameterSet {
        private List<Object> values = new ArrayList<>();
        public void addValue(Object val) { values.add(val); }
        public Object[] getValues() {
            if (!values.isEmpty() && values.get(0) instanceof IDFComponentDescription) {
                return values.toArray(new IDFComponentDescription[0]);
            }
            return values.toArray();
        }
    }
}


class IDFServiceDescription {
    private String name;
    public IDFServiceDescription(String name, Object type, Object ownership) {
        this.name = name;
    }
    public String getName() { return name; }
}
class AgentName { private final String localName; AgentName(String n){localName=n;} public String getLocalName(){return localName;} public String toString(){return localName;} }
class IDFComponentDescription {
    private AgentName name;
    private IDFServiceDescription sd;
    public IDFComponentDescription(Object name, IDFServiceDescription sd) {
        this.name = name instanceof AgentName ? (AgentName) name : new AgentName("targetAgent");
        this.sd = sd;
    }
    public AgentName getName() { return name; }
}
interface ISearchConstraints {}
class IDF {
    public IDFServiceDescription createDFServiceDescription(String name, Object type, Object ownership) {
        return new IDFServiceDescription(name, type, ownership);
    }
    public IDFComponentDescription createDFComponentDescription(Object name, IDFServiceDescription sd) {
        return new IDFComponentDescription(name, sd);
    }
    public ISearchConstraints createSearchConstraints(int max, int min) {
        return new ISearchConstraints() {};
    }
}

class SServiceProvider {
    public static SServiceProvider getService(Object container, Class<?> clazz, Object scope) {
        
        return new SServiceProvider();
    }
    public IDF get(IInternalAccess agent) { return new IDF(); }
}

class RequiredServiceInfo {
    public static final Object SCOPE_PLATFORM = "platform";
}


class SFipa {
    public static final String CONTENT = "content";
    public static final String RECEIVERS = "receivers";
}


class Customer {
    private String language;
    public Customer(String language) { this.language = language; }
    public String getLanguage() { return language; }
}
class Call {
    private Customer customer;
    public Call(Customer customer) { this.customer = customer; }
    public Customer getCustormer() { return customer; }
}
class CallQueue {
    private Call pendingCall;
    public CallQueue(Call pending) { this.pendingCall = pending; }
    public Call getPendingCall() { return pendingCall; }
}


class Plan implements IInternalAccess {
    public void body() { }
    private IBeliefbase beliefbase = new Beliefbase();
    private Object serviceContainer = new Object();
    protected Logger logger = Logger.getLogger(getClass().getName());

    public IBeliefbase getBeliefbase() { return beliefbase; }
    public Object getServiceContainer() { return serviceContainer; }
    public IGoal createGoal(String type) { return new IGoal(); }
    public IMessageEvent createMessageEvent(String type) { return new IMessageEvent(); }
    public void dispatchSubgoalAndWait(IGoal goal) {
        
        IDFComponentDescription[] agents = new IDFComponentDescription[1];
        agents[0] = new IDFComponentDescription(new AgentName("targetAgent"), null);
        goal.getParameterSet("result").addValue(agents[0]); 
        
    }
    public void sendMessage(IMessageEvent msg) {
        logger.info("Message sent (simulated)");
    }
}

class Beliefbase implements IBeliefbase {
    private Map<String, IBelief> beliefs = new HashMap<>();
    public IBelief getBelief(String name) {
        if (!beliefs.containsKey(name)) beliefs.put(name, new Belief());
        return beliefs.get(name);
    }
    class Belief implements IBelief {
        private Object fact;
        public Object getFact() { return fact; }
        public void setFact(Object fact) { this.fact = fact; }
    }
}


public class method_1_beast_deepseek extends Plan {

    
    

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Override
    public void body() {

        CallQueue queue = (CallQueue) getBeliefbase().getBelief("queue")
                .getFact();

        Call call = queue.getPendingCall();
        if (call.getCustormer().getLanguage().equalsIgnoreCase("English")) {

            String target_service = "report-service";
            String msgContent = "NewRecordedCall";

            
            IDF df = (IDF) SServiceProvider.getService(getServiceContainer(),
                    IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
            IDFServiceDescription sd = df.createDFServiceDescription(
                    target_service, null, null);
            IDFComponentDescription dfadesc = df.createDFComponentDescription(
                    null, sd);

            ISearchConstraints constraints = df.createSearchConstraints(-1, 0);

            
            IGoal ft = createGoal("dfcap.df_search");
            ft.getParameter("description").setValue(dfadesc);
            ft.getParameter("constraints").setValue(constraints);

            dispatchSubgoalAndWait(ft);
            IDFComponentDescription[] agents = (IDFComponentDescription[]) ft
                    .getParameterSet("result").getValues();

            if (agents.length > 0) {
                IMessageEvent msg = createMessageEvent("send_inform");
                msg.getParameter(SFipa.CONTENT).setValue(msgContent);
                msg.getParameterSet(SFipa.RECEIVERS).addValue(
                        agents[0].getName());
                sendMessage(msg);
                logger.info("Message sent to: "
                        + agents[0].getName().getLocalName());
            } else {
                logger.severe("Service " + target_service + " not found.");
            }

        } else {

            System.out.println("Language: " + call.getCustormer().getLanguage());
            String target_service = "helpdesk-service";
            String msgContent = "UnknownLanguageCall";

            
            IDF df = (IDF) SServiceProvider.getService(getServiceContainer(),
                    IDF.class, RequiredServiceInfo.SCOPE_PLATFORM).get(this);
            IDFServiceDescription sd = df.createDFServiceDescription(
                    target_service, null, null);
            IDFComponentDescription dfadesc = df.createDFComponentDescription(
                    null, sd);

            ISearchConstraints constraints = df.createSearchConstraints(-1, 0);

            
            IGoal ft = createGoal("dfcap.df_search");
            ft.getParameter("description").setValue(dfadesc);
            ft.getParameter("constraints").setValue(constraints);

            dispatchSubgoalAndWait(ft);
            IDFComponentDescription[] agents = (IDFComponentDescription[]) ft
                    .getParameterSet("result").getValues();

            IMessageEvent msg = createMessageEvent("helpdesk-request");
            msg.getParameter(SFipa.CONTENT).setValue(msgContent);
            if (agents.length > 0) {
                msg.getParameterSet(SFipa.RECEIVERS).addValue(
                        agents[0].getName());
                sendMessage(msg);
                System.out.println("Enviado");
            } else {
                System.out.println("Service " + target_service + " not found.");
                logger.severe("Service " + target_service + " not found.");
            }

            logger.info("Message sent to: " + agents[0].getName());

        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    public static void main(String[] args) throws Exception {
        method_1_beast_deepseek agent = new method_1_beast_deepseek();

        
        System.out.println("=== Test 1: English customer ===");
        Customer engCustomer = new Customer("English");
        Call engCall = new Call(engCustomer);
        CallQueue queueEng = new CallQueue(engCall);
        agent.getBeliefbase().getBelief("queue").setFact(queueEng);

        
        
        agent.body();

        System.out.println();

        
        System.out.println("=== Test 2: Spanish customer ===");
        Customer spaCustomer = new Customer("Spanish");
        Call spaCall = new Call(spaCustomer);
        CallQueue queueSpa = new CallQueue(spaCall);
        agent.getBeliefbase().getBelief("queue").setFact(queueSpa);
        agent.body();
    }
}