import javax.lang.model.element.Name;
import javax.tools.Diagnostic;
import java.util.*;
import java.util.regex.Pattern;
import java.lang.reflect.Method;


class MethodAndParameter {
    private Name methodName;
    private Object parameter; 
    public MethodAndParameter(Name methodName, Object parameter) {
        this.methodName = methodName; this.parameter = parameter;
    }
    public Name getMethodName() { return methodName; }
    public Object getParameter() { return parameter; }
}

class MethodInvocationTree {
    private List<Object> arguments;
    public MethodInvocationTree(List<Object> arguments) { this.arguments = arguments; }
    public List<Object> getArguments() { return arguments; }
}

class JCTree {
    static class JCLiteral {
        private Object value;
        public JCLiteral(Object value) { this.value = value; }
        public Object getValue() { return value; }
    }
}

class StatementInfo {
    private String statement;
    public StatementInfo(String statement) { this.statement = statement; }
    public String getStatement() { return statement; }
}

class StructLoggerFieldContext {
    private TypeMirror contextProvider;
    public StructLoggerFieldContext(TypeMirror contextProvider) { this.contextProvider = contextProvider; }
    public TypeMirror getContextProvider() { return contextProvider; }
}

class TypeMirror {
    private String name;
    public TypeMirror(String name) { this.name = name; }
    @Override public String toString() { return name; }
    @Override public boolean equals(Object o) {
        if (!(o instanceof TypeMirror)) return false;
        return name.equals(((TypeMirror)o).name);
    }
    @Override public int hashCode() { return name.hashCode(); }
}

class VariableContextProvider {
    private TypeMirror typeMirror;
    private List<Variable> variables;
    private boolean parametrize;
    public VariableContextProvider(TypeMirror typeMirror, List<Variable> variables, boolean parametrize) {
        this.typeMirror = typeMirror; this.variables = variables; this.parametrize = parametrize;
    }
    public List<Variable> getVariables() { return variables; }
    public TypeMirror getTypeMirror() { return typeMirror; }
    public boolean shouldParametrize() { return parametrize; }
}

class Variable {
    private Name name;
    private TypeMirror type; 
    public Variable(Name name, TypeMirror type) { this.name = name; }
    public Name getName() { return name; }
}

enum LogLevel {
    INFO("info", "infoEvent"),
    DEBUG("debug", "debugEvent"),
    ERROR("error", "errorEvent");
    private String levelMethod, logEventMethod;
    LogLevel(String levelMethod, String logEventMethod) { this.levelMethod = levelMethod; this.logEventMethod = logEventMethod; }
    public String getLevelMethodName() { return levelMethod; }
    public String getLogEventMethodName() { return logEventMethod; }
    public String getLevelName() { return levelMethod; }
}

class LoggingEvent {} 

class StringUtils {
    public static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
    public static int countMatches(String str, String sub) {
        if (str == null || sub == null) return 0;
        int count = 0;
        int idx = 0;
        while ((idx = str.indexOf(sub, idx)) != -1) { count++; idx += sub.length(); }
        return count;
    }
}

class ScannerParams {
    private Map<Name, StructLoggerFieldContext> fields;
    private Map<TypeMirror, VariableContextProvider> varsHashMap;
    private List<GeneratedClassInfo> generatedClassesInfo;
    private Object typeElement; 
    private Object compilationUnit;
    public ScannerParams(Object typeElement, Object compilationUnit,
                         Map<TypeMirror, VariableContextProvider> varsHashMap,
                         Map<Name, StructLoggerFieldContext> fields,
                         List<GeneratedClassInfo> generatedClassesInfo) {
        this.typeElement = typeElement;
        this.compilationUnit = compilationUnit;
        this.varsHashMap = varsHashMap;
        this.fields = fields;
        this.generatedClassesInfo = generatedClassesInfo;
    }
    public Map<Name, StructLoggerFieldContext> getFields() { return fields; }
    public Map<TypeMirror, VariableContextProvider> getVarsHashMap() { return varsHashMap; }
    public List<GeneratedClassInfo> getGeneratedClassesInfo() { return generatedClassesInfo; }
}

class JavaFile {
    static class TypeSpec { String name; }
    TypeSpec typeSpec = new TypeSpec();
    String packageName;
}

class GeneratedClassInfo {
    private String qualifiedName;
    private String className;
    private String literalValue;
    private List<VariableAndValue> usedVariables;
    private String packageName;
    public GeneratedClassInfo(String qualifiedName, String className, String literalValue,
                              List<VariableAndValue> usedVariables, String packageName) {
        this.qualifiedName = qualifiedName; this.className = className;
        this.literalValue = literalValue; this.usedVariables = usedVariables; this.packageName = packageName;
    }
    public String getQualifiedName() { return qualifiedName; }
    public List<VariableAndValue> getUsedVariables() { return usedVariables; }
    
}

class VariableAndValue {
    private Variable variable;
    private Object value;
    public VariableAndValue(Variable variable, Object value) { this.variable = variable; this.value = value; }
}

class PackageNameException extends Exception {}

class PojoService {
    public JavaFile createPojo(String eventName, JCTree.JCLiteral literal, List<VariableAndValue> usedVariables) throws PackageNameException {
        JavaFile javaFile = new JavaFile();
        
        String[] parts = eventName.split("\\.");
        javaFile.typeSpec.name = parts[parts.length-1];
        javaFile.packageName = eventName.contains(".") ? eventName.substring(0, eventName.lastIndexOf('.')) : "";
        return javaFile;
    }
    public void writeJavaFile(JavaFile javaFile) {  }
}

class Messager {
    public void printMessage(Diagnostic.Kind kind, String msg) {
        System.out.println("[" + kind + "] " + msg);
    }
}


public class method_1_structlogger_deepseek {

    
    private Messager messager = new Messager();
    private PojoService pojoService = new PojoService();

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private void handleStructLogExpression(final Stack<MethodAndParameter> stack,
                                           final MethodInvocationTree node,
                                           final Name name,
                                           final StatementInfo statementInfo,
                                           final ScannerParams scannerParams) {
        final java.util.List<VariableAndValue> usedVariables = new ArrayList<>();
        JCTree.JCLiteral literal = null;
        String level = null;
        String eventName = null;

        
        final StructLoggerFieldContext structLoggerFieldContext = scannerParams.getFields().get(name);
        final TypeMirror typeMirror = structLoggerFieldContext.getContextProvider();
        final VariableContextProvider variableContextProvider = scannerParams.getVarsHashMap().get(typeMirror);

        
        
        while (!stack.empty()) {
            
            boolean matched = false;
            final MethodAndParameter top = stack.pop();
            
            for (Variable variable : variableContextProvider.getVariables()) {
                final Name topMethodName = top.getMethodName();

                if (variable.getName().equals(topMethodName)) {
                    addToUsedVariables(usedVariables, top, variable);
                    matched = true;
                    break;
                }
                else {
                    for (LogLevel logLevel : LogLevel.values()) {
                        if (topMethodName.contentEquals(logLevel.getLevelMethodName())) {
                            if (!(node.getArguments().get(0) instanceof JCTree.JCLiteral)) {
                                printStatementMustHaveStringLiteralError(statementInfo, topMethodName);
                                return;
                            }
                            literal = (JCTree.JCLiteral) node.getArguments().get(0);
                            level = logLevel.getLevelName();
                            matched = true;
                            break;
                        }
                        else if (topMethodName.contentEquals(logLevel.getLogEventMethodName())) {
                            return; 
                        }
                    }
                }
            }

            if (top.getMethodName().contentEquals("log") && top.getParameter() != null) {
                if (!(top.getParameter() instanceof JCTree.JCLiteral)) {
                    printStatementMustHaveStringLiteralError(statementInfo, top.getMethodName());
                    return;
                }
                eventName = ((JCTree.JCLiteral) top.getParameter()).getValue().toString();
                if (!Pattern.compile("^(\\w+(\\.\\w+)*)+$").matcher(eventName).matches()) {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            formatWithStatementLocation(
                                    "qualified event name %s specified by %s statement is not valid",
                                    statementInfo,
                                    eventName,
                                    statementInfo.getStatement()
                            )
                    );
                    return;
                }
                matched = true;
            } else if (top.getMethodName().contentEquals("log") && top.getParameter() == null) {
                matched = true;
            }
            if (stack.empty() && !top.getMethodName().contentEquals("log")) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "statement %s must be ended by calling log() method",
                                statementInfo,
                                statementInfo.getStatement()
                        )
                );
                return;
            }
            if (!matched) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "variable %s in statement %s is not specified by variable context %s",
                                statementInfo,
                                top.getMethodName(),
                                statementInfo.getStatement(),
                                variableContextProvider.getTypeMirror()
                        )
                );
                return;
            }
        }

        
        if (variableContextProvider.shouldParametrize()) {
            final int countOfStringVariables = StringUtils.countMatches(literal.getValue().toString(), "{}");
            if (countOfStringVariables != usedVariables.size()) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "literal %s contains %d variables, but statement %s uses %d variables",
                                statementInfo,
                                literal.getValue().toString(),
                                countOfStringVariables,
                                statementInfo.getStatement(),
                                usedVariables.size()
                        )
                );
                return;
            }
        }

        
        JavaFile javaFile;
        try {
            javaFile = pojoService.createPojo(eventName, literal, usedVariables);
        } catch (PackageNameException e) {
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    formatWithStatementLocation(
                            "qualified event name %s generated by statement %s is not valid, please check specified event name and package does not contain java keyword or no subpackage or class name starts with number",
                            statementInfo,
                            eventName,
                            statementInfo.getStatement()
                    )
            );
            return;
        }
        final String className = javaFile.typeSpec.name;
        final String qualifiedName = StringUtils.isBlank(javaFile.packageName) ? className : javaFile.packageName + "." + className;
        final GeneratedClassInfo generatedClassInfo = new GeneratedClassInfo(qualifiedName, className, (String) literal.getValue(), usedVariables, javaFile.packageName);
        for (GeneratedClassInfo info : scannerParams.getGeneratedClassesInfo()) {
            if (info.getQualifiedName().equals(generatedClassInfo.getQualifiedName())
                    && !info.getUsedVariables().equals(generatedClassInfo.getUsedVariables())
                    ) {
                messager.printMessage(
                        Diagnostic.Kind.ERROR,
                        formatWithStatementLocation(
                                "Statement %s generates different event structure for same event name",
                                statementInfo,
                                statementInfo.getStatement()
                        )
                );
                return;
            }
        }
        scannerParams.getGeneratedClassesInfo().add(generatedClassInfo);

        pojoService.writeJavaFile(javaFile);

        
        replaceInCode(name.toString(), generatedClassInfo, statementInfo, usedVariables, literal, level, variableContextProvider);
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    private void addToUsedVariables(List<VariableAndValue> usedVariables, MethodAndParameter top, Variable variable) {
        
        usedVariables.add(new VariableAndValue(variable, null));
    }
    private void printStatementMustHaveStringLiteralError(StatementInfo info, Name methodName) {
        messager.printMessage(Diagnostic.Kind.ERROR, formatWithStatementLocation(
                "statement %s must have string literal argument for method %s",
                info, info.getStatement(), methodName));
    }
    private String formatWithStatementLocation(String format, StatementInfo info, Object... args) {
        return String.format(format, args);
    }
    private void replaceInCode(String name, GeneratedClassInfo genInfo, StatementInfo stmtInfo,
                               List<VariableAndValue> usedVars, JCTree.JCLiteral literal,
                               String level, VariableContextProvider vcp) {
        System.out.println("Replacing code for event: " + genInfo.getQualifiedName() + " with level: " + level);
    }

    
    public static void main(String[] args) throws Exception {
        method_1_structlogger_deepseek instance = new method_1_structlogger_deepseek();

        
        Name fieldName = new NameImpl("myLogger"); 
        TypeMirror contextTM = new TypeMirror("com.example.MyContext");
        StructLoggerFieldContext fieldCtx = new StructLoggerFieldContext(contextTM);
        Map<Name, StructLoggerFieldContext> fields = new HashMap<>();
        fields.put(fieldName, fieldCtx);

        
        Variable var1 = new Variable(new NameImpl("userId"), new TypeMirror("int"));
        VariableContextProvider vcp = new VariableContextProvider(contextTM, Arrays.asList(var1), true);
        Map<TypeMirror, VariableContextProvider> varsMap = new HashMap<>();
        varsMap.put(contextTM, vcp);

        List<GeneratedClassInfo> genList = new ArrayList<>();
        ScannerParams params = new ScannerParams(null, null, varsMap, fields, genList);

        
        
        
        
        
        
        
        JCTree.JCLiteral literal = new JCTree.JCLiteral("user {} logged in");
        MethodInvocationTree node = new MethodInvocationTree(Collections.singletonList(literal));

        Stack<MethodAndParameter> stack = new Stack<>();
        stack.push(new MethodAndParameter(new NameImpl("log"), new JCTree.JCLiteral("com.example.UserLoggedIn"))); 
        stack.push(new MethodAndParameter(new NameImpl("info"), literal)); 
        stack.push(new MethodAndParameter(new NameImpl("userId"), new JCTree.JCLiteral(123))); 

        StatementInfo stmtInfo = new StatementInfo("logger.info(\"user {} logged in\").userId(userId).log()");

        
        Method method = method_1_structlogger_deepseek.class.getDeclaredMethod("handleStructLogExpression",
                Stack.class, MethodInvocationTree.class, Name.class, StatementInfo.class, ScannerParams.class);
        method.setAccessible(true);
        method.invoke(instance, stack, node, fieldName, stmtInfo, params);

        System.out.println("Generated classes: " + genList.size());
        for (GeneratedClassInfo gci : genList) {
            System.out.println(" - " + gci.getQualifiedName());
        }
    }
}


class NameImpl implements Name {
    private String content;
    public NameImpl(String content) { this.content = content; }
    @Override public boolean contentEquals(CharSequence cs) { return content.equals(cs.toString()); }
    @Override public int length() { return content.length(); }
    @Override public char charAt(int index) { return content.charAt(index); }
    @Override public CharSequence subSequence(int start, int end) { return content.substring(start, end); }
    @Override public String toString() { return content; }
    @Override public boolean equals(Object o) {
        if (!(o instanceof Name)) return false;
        return content.equals(((Name)o).toString());
    }
    @Override public int hashCode() { return content.hashCode(); }
}