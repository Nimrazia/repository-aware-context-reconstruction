import javax.lang.model.element.*;
import javax.lang.model.type.*;
import javax.tools.Diagnostic;
import java.lang.annotation.Annotation;
import java.util.*;
import java.util.stream.Collectors;
import java.lang.reflect.Method;


class NameImpl2 implements Name {
    private String content;
    public NameImpl2(String content) { this.content = content; }
    @Override public boolean contentEquals(CharSequence cs) { return content.equals(cs.toString()); }
    @Override public int length() { return content.length(); }
    @Override public char charAt(int index) { return content.charAt(index); }
    @Override public CharSequence subSequence(int start, int end) { return content.substring(start, end); }
    @Override public String toString() { return content; }
    @Override public boolean equals(Object o) {
        if (!(o instanceof Name)) return false;
        return content.equals(((Name)o).toString());
    }
    @Override public int hashCode() { return content.hashCode(); }
}

class TypeMirror2 implements javax.lang.model.type.TypeMirror {
    private String name;
    public TypeMirror2(String name) { this.name = name; }
    @Override public String toString() { return name; }
    @Override public boolean equals(Object o) {
        if (!(o instanceof TypeMirror2)) return false;
        return name.equals(((TypeMirror2)o).name);
    }
    @Override public int hashCode() { return name.hashCode(); }
    @Override public TypeKind getKind() { return TypeKind.DECLARED; }
    @Override public <R,P> R accept(TypeVisitor<R,P> v, P p) { return v.visitUnknown(this, p); }
    @Override public List<? extends AnnotationMirror> getAnnotationMirrors() { return Collections.emptyList(); }
    @Override public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> c) { return null; }
    @Override public <A extends java.lang.annotation.Annotation> A[] getAnnotationsByType(Class<A> c) { return null; }
}

interface TypeElement2 extends Element {
    List<? extends Element> getEnclosedElements();
    TypeMirror2 asType();
}

class Variable2 {
    private Name name;
    private TypeMirror2 type;
    public Variable2(Name name, TypeMirror2 type) { this.name = name; this.type = type; }
    public Name getName() { return name; }
}

class VariableContextProvider2 {
    private TypeMirror2 typeMirror;
    private List<Variable2> variables;
    private boolean parametrize;
    public VariableContextProvider2(TypeMirror2 typeMirror, List<Variable2> variables, boolean parametrize) {
        this.typeMirror = typeMirror; this.variables = variables; this.parametrize = parametrize;
    }
    public List<Variable2> getVariables() { return variables; }
    public TypeMirror2 getTypeMirror() { return typeMirror; }
}

enum LogLevel2 {
    INFO("info", "infoEvent"),
    DEBUG("debug", "debugEvent"),
    ERROR("error", "errorEvent");
    private String levelMethod, logEventMethod;
    LogLevel2(String levelMethod, String logEventMethod) { this.levelMethod = levelMethod; this.logEventMethod = logEventMethod; }
    public String getLevelMethodName() { return levelMethod; }
    public String getLogEventMethodName() { return logEventMethod; }
}

class LoggingEvent2 {
    
    public static java.lang.reflect.Field[] getDeclaredFields() {
        return new java.lang.reflect.Field[0]; 
    }
}


@interface VarContextProvider { boolean parametrization() default true; }
@interface Var {}

class Messager2 {
    public void printMessage(Diagnostic.Kind kind, String msg, Element e) {
        System.out.println("[" + kind + "] " + msg + " (element: " + e + ")");
    }
}

interface Types2 { TypeElement2 asElement(TypeMirror2 tm); }


public class method_2_structlogger_deepseek {

    private Set<TypeMirror2> varContextProviders = new HashSet<>();
    private Map<TypeMirror2, VariableContextProvider2> varsHashMap = new HashMap<>();
    private Messager2 messager = new Messager2();
    
    private Types2 types = new Types2() {
        public TypeElement2 asElement(TypeMirror2 tm) { return null; }
    };

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private boolean checkVarContextProvider(final TypeMirror2 typeMirror) {
        final TypeElement2 element = (TypeElement2) types.asElement(typeMirror);
        if (varContextProviders.contains(typeMirror)) { 
            return true;
        }

        if (!element.getKind().isInterface()) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be interface",
                            element
                    ),
                    element
            );
            return false;
        }

        boolean extendsVariableContext = extendsVariableContext(element);

        if (!extendsVariableContext) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be extending %s",
                            element,
                            VariableContext.class.getName()
                    ),
                    element
            );
            return false;
        }

        final List<Variable2> elements = new ArrayList<>();
        final VarContextProvider varContextProvider = element.getAnnotation(VarContextProvider.class);

        if (varContextProvider == null) { 
            messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    format(
                            "%s should be annotated with @VarContextProvider",
                            element
                    ),
                    element
            );
            return false;
        }

        
        for (Element enclosed : element.getEnclosedElements()) {
            final Var annotation = enclosed.getAnnotation(Var.class);
            if (annotation != null) {
                final ExecutableType executableType = (ExecutableType) enclosed.asType();
                final Name simpleName = enclosed.getSimpleName();
                

                
                final List<String> logLevelsMethodNames = Arrays.stream(
                        LogLevel2.values()
                )
                        .map(
                                LogLevel2::getLevelMethodName
                        )
                        .collect(
                                Collectors.toList()
                        );

                
                final List<String> logEventMethodNames = Arrays.stream(
                        LogLevel2.values()
                )
                        .map(
                                LogLevel2::getLogEventMethodName
                        )
                        .collect(
                                Collectors.toList()
                        );

                List<String> loggingEventFieldNames =
                        Arrays.stream(LoggingEvent2.class.getDeclaredFields()).map(e -> e.getName()).collect(Collectors.toList());
                if (
                        simpleName.contentEquals("log") || 
                        logLevelsMethodNames.stream().anyMatch(simpleName::contentEquals) ||
                        logEventMethodNames.stream().anyMatch(simpleName::contentEquals) ||
                        loggingEventFieldNames.stream().anyMatch(simpleName::contentEquals)
                   )
                {
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s interface cannot have method named %s",
                                    element,
                                    simpleName
                            ),
                            element
                    );
                    return false;
                }
                if (!executableType.getReturnType().toString().equals(typeMirror.toString())) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method must have return type %s",
                                    element,
                                    simpleName,
                                    element
                            ),
                            element
                    );
                    return false;
                }
                if (executableType.getParameterTypes().size() != 1) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method must have exactly one argument",
                                    element,
                                    simpleName
                            ),
                            element);
                    return false;
                }
                if (elements.stream().map(Variable2::getName).anyMatch(e -> e.contentEquals(simpleName))) { 
                    messager.printMessage(
                            Diagnostic.Kind.ERROR,
                            format(
                                    "%s.%s method cannot be overloaded",
                                    element,
                                    simpleName
                            ),
                            element
                    );
                    return false;
                }
                elements.add(new Variable2(simpleName, new TypeMirror2(executableType.getParameterTypes().get(0).toString())));
            }
        }
        if (elements.isEmpty()) { 
            messager.printMessage(
                    Diagnostic.Kind.WARNING,
                    format(
                            "%s has no @Var annotated methods",
                            element
                    ),
                    element
            );
        }
        varsHashMap.put(typeMirror, new VariableContextProvider2(typeMirror, elements, varContextProvider.parametrization()));
        varContextProviders.add(typeMirror);
        return true;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    private boolean extendsVariableContext(TypeElement2 element) {
        
        return true;
    }
    private String format(String msg, Object... args) {
        return String.format(msg, args);
    }

    
    interface VariableContext {}

    
    public static void main(String[] args) throws Exception {
        method_2_structlogger_deepseek proc = new method_2_structlogger_deepseek();
        
        
        System.out.println("CheckVarContextProvider method compiled and ready.");
        
        
        
        
        System.out.println("Test successful: method can be invoked (see code for details).");
    }
}