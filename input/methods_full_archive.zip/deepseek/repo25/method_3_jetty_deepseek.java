import java.util.*;
import java.util.logging.*;



class Log {
    private Logger logger;
    public Log(String name) { logger = Logger.getLogger(name); }
    public void debug(String msg) { logger.fine(msg); }
    public void debug(String msg, Object... args) { logger.fine(String.format(msg, args)); }
    public void warn(String msg) { logger.warning(msg); }
    public void warn(Throwable e) { logger.log(Level.WARNING, e.getMessage(), e); }
}

interface ISessionFactory {
    ISerializableSession create(NoSqlSession session);
}

interface ISerializableSession {
    long getVersion();
    boolean isValid();
    String getId();
    String getDomain();
    String getPath();
    long getCreationTime();
    long getAccessed();
    Enumeration<String> getAttributeNames();
    Object getAttribute(String name);
    Map<String, Object> getAttributeMap();
    void setDomain(String domain);
    void setPath(String path);
    void setVersion(long version);
}

class SimpleSerializableSession implements ISerializableSession {
    private String id;
    private long version;
    private boolean valid = true;
    private Map<String, Object> attributes = new HashMap<>();
    private String domain = "*", path = "*";
    private long creationTime = System.currentTimeMillis();
    private long accessed = System.currentTimeMillis();

    public SimpleSerializableSession(String id, long version) {
        this.id = id; this.version = version;
    }
    public void addAttribute(String name, Object value) { attributes.put(name, value); }
    @Override public long getVersion() { return version; }
    @Override public boolean isValid() { return valid; }
    public void setValid(boolean v) { valid = v; }
    @Override public String getId() { return id; }
    @Override public String getDomain() { return domain; }
    @Override public String getPath() { return path; }
    @Override public long getCreationTime() { return creationTime; }
    @Override public long getAccessed() { return accessed; }
    @Override public Enumeration<String> getAttributeNames() { return Collections.enumeration(attributes.keySet()); }
    @Override public Object getAttribute(String name) { return attributes.get(name); }
    @Override public Map<String, Object> getAttributeMap() { return attributes; }
    @Override public void setDomain(String d) { domain = d; }
    @Override public void setPath(String p) { path = p; }
    @Override public void setVersion(long v) { version = v; }
}

class NoSqlSession {
    private String clusterId;
    private boolean valid = true;
    private Map<String, Object> attributes = new HashMap<>();
    private List<String> names = new ArrayList<>();

    public NoSqlSession(String clusterId) { this.clusterId = clusterId; }
    public String getClusterId() { return clusterId; }
    public boolean isValid() { return valid; }
    public void invalidate() { valid = false; }
    public void willPassivate() { }
    public void didActivate() { }
    public void doPutOrRemove(String name, Object value) { attributes.put(name, value); }
    public void bindValue(String name, Object value) { if (!names.contains(name)) names.add(name); }
    public void unbindValue(String name, Object value) { }
    public Object getAttribute(String name) { return attributes.get(name); }
    public List<String> getNames() { return new ArrayList<>(names); }
    public String getId() { return clusterId; }
}

class TranscoderException extends Exception {
    public TranscoderException(String msg, Throwable cause) { super(msg, cause); }
}


public class method_3_jetty_deepseek {

    
    private Log log = new Log(getClass().getName());
    private String _cookieDomain = "example.com";
    private String _cookiePath = "/";
    private ISessionFactory sessionFactory = new ISessionFactory() {
        public ISerializableSession create(NoSqlSession session) {
            
            SimpleSerializableSession data = new SimpleSerializableSession(session.getId(), 0);
            for (String name : session.getNames()) {
                data.addAttribute(name, session.getAttribute(name));
            }
            return data;
        }
    };

    
    private Map<String, ISerializableSession> store = new HashMap<>();

    
    private ISerializableSession getKey(String id) throws TranscoderException {
        return store.get(id);
    }
    private boolean setKey(String id, ISerializableSession data) throws TranscoderException {
        store.put(id, data);
        return true;
    }
    private void deleteKey(String id) {
        store.remove(id);
    }
    private ISessionFactory getSessionFactory() { return sessionFactory; }

    
    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    protected Object save(final NoSqlSession session, final Object version, final boolean activateAfterSave)
    {
        try
        {
            log.debug("save:" + session);
            session.willPassivate();

            if (!session.isValid())
            {
                log.debug("save: skip saving invalidated session: id=" + session.getId());
                deleteKey(session.getId());
                return null;
            }

            ISerializableSession data;
            synchronized (session)
            {
                data = getSessionFactory().create(session);
            }
            data.setDomain(_cookieDomain);
            data.setPath(_cookiePath);
            long longVersion = 1; 
            if (version != null)
            {
                longVersion = (Long) version + 1L;
            }
            data.setVersion(longVersion);

            try
            {
                if (!setKey(session.getId(), data))
                {
                    throw (new RuntimeException("unable to set key: data=" + data));
                }
            }
            catch (TranscoderException error)
            {
                throw (new IllegalArgumentException("unable to serialize session: id=" + session.getId() + ", data="
                    + data, error));
            }
            log.debug("save:db.sessions.update(" + session.getId() + "," + data + ")");

            if (activateAfterSave)
            {
                session.didActivate();
            }

            return longVersion;
        }
        catch (Exception e)
        {
            log.warn(e);
        }
        return null;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        method_3_jetty_deepseek manager = new method_3_jetty_deepseek();

        
        NoSqlSession session = new NoSqlSession("session-3");
        session.doPutOrRemove("username", "alice");
        session.bindValue("username", "alice");
        session.doPutOrRemove("theme", "dark");
        session.bindValue("theme", "dark");

        
        Object newVersion = manager.save(session, null, true);
        System.out.println("Saved new session, version: " + newVersion);

        
        try {
            ISerializableSession stored = manager.getKey("session-3");
            System.out.println("Stored domain: " + stored.getDomain());
            System.out.println("Stored attributes: " + Collections.list(stored.getAttributeNames()));
        } catch (TranscoderException e) {
            e.printStackTrace();
        }

        
        session.doPutOrRemove("language", "en");
        session.bindValue("language", "en");
        Object updatedVersion = manager.save(session, newVersion, false);
        System.out.println("Updated version: " + updatedVersion);
    }
}