import java.util.*;
import java.util.logging.*;
import java.util.regex.*;








class StringUtils {
    public static boolean isNotBlank(String str) {
        return str != null && !str.trim().isEmpty();
    }
    public static String replace(String text, String searchString, String replacement) {
        if (text == null || searchString == null || replacement == null) return text;
        return text.replace(searchString, replacement);
    }
}




class Utils {
    



    public static String[] splitFirst(String str, String separator) {
        int idx = str.indexOf(separator);
        if (idx < 0) return new String[] { str };
        return new String[] { str.substring(0, idx), str.substring(idx + separator.length()) };
    }
}




class ParseException extends Exception {
    public ParseException(String message) { super(message); }
    public ParseException(String message, Throwable cause) { super(message, cause); }
}




interface Parser<T> {
    List<T> parse(String text) throws ParseException;
}




class Job {
    private String id, name, owner, state, queue, server, checkpoint, ctime, errorPath,
                   execHost, execPort, holdTypes, joinPath, keepFiles, mailPoints, mailUsers,
                   mtime, outputPath, qtime, euser, egroup, hashName, queueType, comment,
                   submitArgs, submitHost, startTime, etime;
    private int priority = -1, sessionId = -1, substate = -1, queueRank = -1,
                startCount = -1, jobArrayId = -1, radix = -1;
    private long walltimeRemaining = -1L;
    private boolean rerunable, faultTolerant;
    private Map<String, String> resourcesUsed = new HashMap<>();
    private Map<String, String> resourceList = new HashMap<>();
    private Map<String, String> variableList = new HashMap<>();

    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
    public String getQueue() { return queue; }
    public void setQueue(String queue) { this.queue = queue; }
    public String getServer() { return server; }
    public void setServer(String server) { this.server = server; }
    public String getCheckpoint() { return checkpoint; }
    public void setCheckpoint(String checkpoint) { this.checkpoint = checkpoint; }
    public String getCtime() { return ctime; }
    public void setCtime(String ctime) { this.ctime = ctime; }
    public String getErrorPath() { return errorPath; }
    public void setErrorPath(String errorPath) { this.errorPath = errorPath; }
    public String getExecHost() { return execHost; }
    public void setExecHost(String execHost) { this.execHost = execHost; }
    public String getExecPort() { return execPort; }
    public void setExecPort(String execPort) { this.execPort = execPort; }
    public String getHoldTypes() { return holdTypes; }
    public void setHoldTypes(String holdTypes) { this.holdTypes = holdTypes; }
    public String getJoinPath() { return joinPath; }
    public void setJoinPath(String joinPath) { this.joinPath = joinPath; }
    public String getKeepFiles() { return keepFiles; }
    public void setKeepFiles(String keepFiles) { this.keepFiles = keepFiles; }
    public String getMailPoints() { return mailPoints; }
    public void setMailPoints(String mailPoints) { this.mailPoints = mailPoints; }
    public String getMailUsers() { return mailUsers; }
    public void setMailUsers(String mailUsers) { this.mailUsers = mailUsers; }
    public String getMtime() { return mtime; }
    public void setMtime(String mtime) { this.mtime = mtime; }
    public String getOutputPath() { return outputPath; }
    public void setOutputPath(String outputPath) { this.outputPath = outputPath; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public String getQtime() { return qtime; }
    public void setQtime(String qtime) { this.qtime = qtime; }
    public boolean isRerunable() { return rerunable; }
    public void setRerunable(boolean rerunable) { this.rerunable = rerunable; }
    public Map<String, String> getResourcesUsed() { return resourcesUsed; }
    public Map<String, String> getResourceList() { return resourceList; }
    public int getSessionId() { return sessionId; }
    public void setSessionId(int sessionId) { this.sessionId = sessionId; }
    public int getSubstate() { return substate; }
    public void setSubstate(int substate) { this.substate = substate; }
    public Map<String, String> getVariableList() { return variableList; }
    public String getEtime() { return etime; }
    public void setEtime(String etime) { this.etime = etime; }
    public String getEuser() { return euser; }
    public void setEuser(String euser) { this.euser = euser; }
    public String getEgroup() { return egroup; }
    public void setEgroup(String egroup) { this.egroup = egroup; }
    public String getHashName() { return hashName; }
    public void setHashName(String hashName) { this.hashName = hashName; }
    public int getQueueRank() { return queueRank; }
    public void setQueueRank(int queueRank) { this.queueRank = queueRank; }
    public String getQueueType() { return queueType; }
    public void setQueueType(String queueType) { this.queueType = queueType; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    public String getSubmitArgs() { return submitArgs; }
    public void setSubmitArgs(String submitArgs) { this.submitArgs = submitArgs; }
    public String getSubmitHost() { return submitHost; }
    public void setSubmitHost(String submitHost) { this.submitHost = submitHost; }
    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public int getStartCount() { return startCount; }
    public void setStartCount(int startCount) { this.startCount = startCount; }
    public boolean isFaultTolerant() { return faultTolerant; }
    public void setFaultTolerant(boolean faultTolerant) { this.faultTolerant = faultTolerant; }
    public int getJobArrayId() { return jobArrayId; }
    public void setJobArrayId(int jobArrayId) { this.jobArrayId = jobArrayId; }
    public int getRadix() { return radix; }
    public void setRadix(int radix) { this.radix = radix; }
    public long getWalltimeRemaining() { return walltimeRemaining; }
    public void setWalltimeRemaining(long walltimeRemaining) { this.walltimeRemaining = walltimeRemaining; }
}




public class method_1_pbs_java_api_deepseek implements Parser<Job> {

    private static final Logger LOGGER = Logger.getLogger(method_1_pbs_java_api_deepseek.class.getName());
    private static final String CHAR_EQUALS = " = ";
    private static final Pattern PATTERN_JOB = Pattern.compile("Job Id: (\\S+)");

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Override
    public List<Job> parse(String text) throws ParseException {
        final List<Job> jobs;
        if (StringUtils.isNotBlank(text)) {
            text = StringUtils.replace(text, "\n\t", "");
            jobs = new LinkedList<Job>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Job job = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_JOB.matcher(line);
                if (matcher.matches()) {
                    if (job != null) {
                        jobs.add(job);
                    }
                    job = new Job();
                    final String id = matcher.group(1).trim();
                    job.setId(id);
                } else if (StringUtils.isNotBlank(line)) {
                    String[] temp = Utils.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("job_name".equalsIgnoreCase(key)) {
                            job.setName(value);
                        } else if ("job_owner".equalsIgnoreCase(key)) {
                            job.setOwner(value);
                        } else if (key.startsWith("resources_used.")) {
                            job.getResourcesUsed().put(key, value);
                        } else if ("job_state".equalsIgnoreCase(key)) {
                            job.setState(value);
                        } else if ("queue".equalsIgnoreCase(key)) {
                            job.setQueue(value);
                        } else if ("server".equalsIgnoreCase(key)) {
                            job.setServer(value);
                        } else if ("checkpoint".equalsIgnoreCase(key)) {
                            job.setCheckpoint(value);
                        } else if ("ctime".equalsIgnoreCase(key)) {
                            job.setCtime(value);
                        } else if ("error_path".equalsIgnoreCase(key)) {
                            job.setErrorPath(value);
                        } else if ("exec_host".equalsIgnoreCase(key)) {
                            job.setExecHost(value);
                        } else if ("exec_port".equalsIgnoreCase(key)) {
                            job.setExecPort(value);
                        } else if ("hold_types".equalsIgnoreCase(key)) {
                            job.setHoldTypes(value);
                        } else if ("join_path".equalsIgnoreCase(key)) {
                            job.setJoinPath(value);
                        } else if ("keep_files".equalsIgnoreCase(key)) {
                            job.setKeepFiles(value);
                        } else if ("mail_points".equalsIgnoreCase(key)) {
                            job.setMailPoints(value);
                        } else if ("mail_users".equalsIgnoreCase(key)) {
                            job.setMailUsers(value);
                        } else if ("mtime".equalsIgnoreCase(key)) {
                            job.setMtime(value);
                        } else if ("output_path".equalsIgnoreCase(key)) {
                            job.setOutputPath(value);
                        } else if ("priority".equalsIgnoreCase(key)) {
                            try {
                                job.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job priority: " + nfe.getMessage(), nfe);
                                job.setPriority(-1);
                            }
                        } else if ("qtime".equalsIgnoreCase(key)) {
                            job.setQtime(value);
                        } else if ("rerunable".equalsIgnoreCase(key)) {
                            job.setRerunable(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resource_list.")) {
                            job.getResourceList().put(key, value);
                        } else if ("session_id".equalsIgnoreCase(key)) {
                            try {
                                job.setSessionId(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job session id: " + nfe.getMessage(), nfe);
                                job.setSessionId(-1);
                            }
                        } else if ("substate".equalsIgnoreCase(key)) {
                            try {
                                job.setSubstate(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job substate: " + nfe.getMessage(), nfe);
                                job.setSubstate(-1);
                            }
                        } else if (key.startsWith("variable_list")) {
                            job.getVariableList().put(key, value);
                        } else if ("etime".equalsIgnoreCase(key)) {
                            job.setEtime(value);
                        } else if ("euser".equalsIgnoreCase(key)) {
                            job.setEuser(value);
                        } else if ("egroup".equalsIgnoreCase(key)) {
                            job.setEgroup(value);
                        } else if ("hashname".equalsIgnoreCase(key)) {
                            job.setHashName(value);
                        } else if ("queue_rank".equalsIgnoreCase(key)) {
                            try {
                                job.setQueueRank(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job queue rank: " + nfe.getMessage(), nfe);
                                job.setQueueRank(-1);
                            }
                        } else if ("queue_type".equalsIgnoreCase(key)) {
                            job.setQueueType(value);
                        } else if ("comment".equalsIgnoreCase(key)) {
                            job.setComment(value);
                        } else if ("submit_args".equalsIgnoreCase(key)) {
                            job.setSubmitArgs(value);
                        } else if ("submit_host".equalsIgnoreCase(key)) {
                            job.setSubmitHost(value);
                        } else if ("start_time".equalsIgnoreCase(key)) {
                            job.setStartTime(value);
                        } else if ("start_count".equalsIgnoreCase(key)) {
                            try {
                                job.setStartCount(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job start count: " + nfe.getMessage(), nfe);
                                job.setStartCount(-1);
                            }
                        } else if ("fault_tolerant".equalsIgnoreCase(key)) {
                            job.setFaultTolerant(Boolean.parseBoolean(value));
                        } else if ("job_array_id".equalsIgnoreCase(key)) {
                            job.setJobArrayId(Integer.parseInt(value));
                        } else if ("job_radix".equalsIgnoreCase(key)) {
                            try {
                                job.setRadix(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job radix: " + nfe.getMessage(), nfe);
                                job.setRadix(-1);
                            }
                        } else if ("walltime.remaining".equalsIgnoreCase(key)) {
                            try {
                                job.setWalltimeRemaining(Long.parseLong(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing job walltime remaining: " + nfe.getMessage(),
                                        nfe);
                                job.setWalltimeRemaining(-1L);
                            }
                        }
                    }
                }
            }
            if (job != null) {
                jobs.add(job);
            }
            return jobs;
        } else {
            return Collections.emptyList();
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    


    public static void main(String[] args) throws Exception {
        String sampleOutput =
            "Job Id: 12345.server\n" +
            "job_name = test_job\n" +
            "job_owner = user@server\n" +
            "job_state = R\n" +
            "queue = workq\n" +
            "server = server\n" +
            "checkpoint = u\n" +
            "ctime = Mon Jun 13 12:00:00 2022\n" +
            "resources_used.cput = 00:01:00\n" +
            "resources_used.mem = 100kb\n" +
            "resource_list.ncpus = 4\n" +
            "session_id = 54321\n" +
            "substate = 42\n" +
            "priority = 50\n" +
            "walltime.remaining = 3600\n" +
            "Job Id: 67890.server\n" +
            "job_name = another_job\n" +
            "job_owner = user2@server\n" +
            "job_state = Q\n" +
            "queue = batch\n";

        method_1_pbs_java_api_deepseek parser = new method_1_pbs_java_api_deepseek();
        List<Job> jobs = parser.parse(sampleOutput);
        System.out.println("Parsed " + jobs.size() + " jobs:");
        for (Job job : jobs) {
            System.out.println("  ID: " + job.getId() + ", Name: " + job.getName() +
                               ", State: " + job.getState() + ", Queue: " + job.getQueue());
        }
    }
}