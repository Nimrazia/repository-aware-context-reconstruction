import java.util.*;
import java.util.logging.*;
import java.util.regex.*;



class StringUtils2 {
    public static boolean isNotBlank(String str) { return str != null && !str.trim().isEmpty(); }
    public static String replace(String text, String search, String replacement) {
        return text == null ? null : text.replace(search, replacement);
    }
}
class Utils2 {
    public static String[] splitFirst(String str, String sep) {
        int idx = str.indexOf(sep);
        return idx < 0 ? new String[]{str} : new String[]{str.substring(0, idx), str.substring(idx + sep.length())};
    }
}
class ParseException2 extends Exception {
    public ParseException2(String msg) { super(msg); }
}
interface Parser2<T> { List<T> parse(String text) throws ParseException2; }




class Queue {
    private String name, queueType, stateCount, mtime;
    private int priority = -1, totalJobs = -1, maxUserRun = -1;
    private boolean enabled, started;
    private Map<String, String> resourcesMax = new HashMap<>();
    private Map<String, String> resourcesMin = new HashMap<>();
    private Map<String, String> resourcesAssigned = new HashMap<>();
    private Map<String, String> resourcesDefault = new HashMap<>();

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getQueueType() { return queueType; }
    public void setQueueType(String queueType) { this.queueType = queueType; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public int getTotalJobs() { return totalJobs; }
    public void setTotalJobs(int totalJobs) { this.totalJobs = totalJobs; }
    public String getStateCount() { return stateCount; }
    public void setStateCount(String stateCount) { this.stateCount = stateCount; }
    public String getMtime() { return mtime; }
    public void setMtime(String mtime) { this.mtime = mtime; }
    public int getMaxUserRun() { return maxUserRun; }
    public void setMaxUserRun(int maxUserRun) { this.maxUserRun = maxUserRun; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public boolean isStarted() { return started; }
    public void setStarted(boolean started) { this.started = started; }
    public Map<String, String> getResourcesMax() { return resourcesMax; }
    public Map<String, String> getResourcesMin() { return resourcesMin; }
    public Map<String, String> getResourcesAssigned() { return resourcesAssigned; }
    public Map<String, String> getResourcesDefault() { return resourcesDefault; }
}

public class method_2_pbs_java_api_deepseek implements Parser2<Queue> {

    private static final Logger LOGGER = Logger.getLogger(method_2_pbs_java_api_deepseek.class.getName());
    private static final String CHAR_EQUALS = " = ";
    private static final Pattern PATTERN_QUEUE = Pattern.compile("Queue: (\\S+)");

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Override
    public List<Queue> parse(String text) throws ParseException2 {
        final List<Queue> queues;
        if (StringUtils2.isNotBlank(text)) {
            queues = new LinkedList<Queue>();
            String separator = "\n";
            if (text.indexOf("\r\n") > 0) {
                separator = "\r\n";
            }
            final String[] lines = text.split(separator);
            Queue queue = null;
            for (final String line : lines) {
                Matcher matcher = PATTERN_QUEUE.matcher(line);
                if (matcher.matches()) {
                    if (queue != null) {
                        queues.add(queue);
                    }
                    queue = new Queue();
                    final String name = matcher.group(1);
                    queue.setName(name);
                } else if (StringUtils2.isNotBlank(line)) {
                    String[] temp = Utils2.splitFirst(line, CHAR_EQUALS);
                    if (temp.length == 2) {
                        final String key = temp[0].trim().toLowerCase();
                        final String value = temp[1].trim();
                        if ("queue_type".equals(key)) {
                            queue.setQueueType(value);
                        } else if ("priority".equals(key)) {
                            try {
                                queue.setPriority(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue priority: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("total_jobs".equals(key)) {
                            try {
                                queue.setTotalJobs(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue total jobs: " + nfe.getMessage(), nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("state_count".equals(key)) {
                            queue.setStateCount(value);
                        } else if ("mtime".equals(key)) {
                            queue.setMtime(value);
                        } else if ("max_user_run".equals(key)) {
                            try {
                                queue.setMaxUserRun(Integer.parseInt(value));
                            } catch (NumberFormatException nfe) {
                                LOGGER.log(Level.WARNING, "Failed parsing queue max user run: " + nfe.getMessage(),
                                        nfe);
                                queue.setPriority(-1);
                            }
                        } else if ("enabled".equals(key)) {
                            queue.setEnabled(Boolean.parseBoolean(value));
                        } else if ("started".equals(key)) {
                            queue.setStarted(Boolean.parseBoolean(value));
                        } else if (key.startsWith("resources_max.")) {
                            queue.getResourcesMax().put(key, value);
                        } else if (key.startsWith("resources_min.")) {
                            queue.getResourcesMin().put(key, value);
                        } else if (key.startsWith("resources_assigned.")) {
                            queue.getResourcesAssigned().put(key, value);
                        } else if (key.startsWith("resources_default.")) {
                            queue.getResourcesDefault().put(key, value);
                        } else {
                            LOGGER.info("Unmmaped key, value: " + key + ", " + value);
                        }
                    }
                }
            }
            if (queue != null) {
                queues.add(queue);
            }
            return queues;
        } else {
            return Collections.emptyList();
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        String sampleOutput =
            "Queue: workq\n" +
            "\tqueue_type = Execution\n" +
            "\tPriority = 100\n" +
            "\ttotal_jobs = 5\n" +
            "\tstate_count = Transit:0 Queued:0 Held:0 Waiting:0 Running:5 Exiting:0 Begun:0\n" +
            "\tmtime = Mon Jun 13 12:00:00 2022\n" +
            "\tmax_user_run = 2\n" +
            "\tenabled = True\n" +
            "\tstarted = True\n" +
            "\tresources_max.ncpus = 8\n" +
            "\tresources_min.ncpus = 1\n";

        method_2_pbs_java_api_deepseek parser = new method_2_pbs_java_api_deepseek();
        List<Queue> queues = parser.parse(sampleOutput);
        System.out.println("Parsed " + queues.size() + " queues:");
        for (Queue q : queues) {
            System.out.println("  Name: " + q.getName() + ", Type: " + q.getQueueType() +
                               ", Priority: " + q.getPriority() + ", Total Jobs: " + q.getTotalJobs() +
                               ", Enabled: " + q.isEnabled() + ", Started: " + q.isStarted());
        }
    }
}