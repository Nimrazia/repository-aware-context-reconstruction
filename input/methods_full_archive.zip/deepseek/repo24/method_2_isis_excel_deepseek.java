import java.io.*;
import java.util.*;






class ImmutableSet<T> extends AbstractSet<T> {
    private final Set<T> data;
    public ImmutableSet(){ this.data = new LinkedHashSet<>(); }
    public ImmutableSet(Collection<T> c){ this.data = new LinkedHashSet<>(c); }
    public Iterator<T> iterator(){ return data.iterator(); }
    public int size(){ return data.size(); }
    public static <T> ImmutableSet<T> copyOf(Iterable<T> iter) {
        
        List<T> list = new ArrayList<>(); for (T t : iter) list.add(t); return new ImmutableSet<T>(list);
    }
}

class FluentIterable<T> {
    private Iterable<T> iter;
    public FluentIterable(Iterable<T> iter) { this.iter = iter; }
    public static <T> FluentIterable<T> from(Iterable<T> iter) { return new FluentIterable<>(iter); }
    public <V> FluentIterable<V> transform(Function<T, V> function) {
        List<V> list = new ArrayList<>();
        for (T t : iter) {
            V v = function.apply(t);
            if (v != null) list.add(v);
        }
        return new FluentIterable<>(list);
    }
    public ImmutableSet toSet() {
        
        return ImmutableSet.copyOf((Iterable) iter);
    }
}

interface Function<F, T> {
    T apply(F input);
}


class XSSFWorkbook {
    public void write(OutputStream out) throws IOException {  }
}


class WorksheetContent {
    private WorksheetSpec spec;
    private List<Object> domainObjects;
    public WorksheetContent(WorksheetSpec spec, List<Object> domainObjects) {
        this.spec = spec; this.domainObjects = domainObjects;
    }
    public WorksheetSpec getSpec() { return spec; }
    public List<Object> getDomainObjects() { return domainObjects; }
}

class WorksheetSpec {
    private String sheetName;
    private String factory;
    public WorksheetSpec(String sheetName, String factory) {
        this.sheetName = sheetName; this.factory = factory;
    }
    public String getSheetName() { return sheetName; }
    public String getFactory() { return factory; }
}





class ExcelConverter {
    private static final String XLSX_SUFFIX = ".xlsx";

    
    private void appendSheet(XSSFWorkbook workbook, List<Object> domainObjects, String factory, String sheetName) {
        
        System.out.println("Appending sheet: " + sheetName + " with " + domainObjects.size() + " objects");
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    File appendSheet(final List<WorksheetContent> worksheetContents) throws IOException {
        final ImmutableSet<String> worksheetNames = FluentIterable.from(worksheetContents)
                .transform(new Function<WorksheetContent, String>() {
                    @Override public String apply(final WorksheetContent worksheetContent) {
                        return worksheetContent.getSpec().getSheetName();
                    }
                }).toSet();
        if(worksheetNames.size() < worksheetContents.size()) {
            throw new IllegalArgumentException("Sheet names must have distinct names");
        }
        for (final String worksheetName : worksheetNames) {
            if(worksheetName.length() > 30) {
                throw new IllegalArgumentException(
                        String.format("Sheet name cannot exceed 30 characters (invalid name: '%s')",
                                worksheetName));
            }
        }

        final XSSFWorkbook workbook = new XSSFWorkbook();
        final File tempFile =
                File.createTempFile(ExcelConverter.class.getName(), UUID.randomUUID().toString() + XLSX_SUFFIX);
        final FileOutputStream fos = new FileOutputStream(tempFile);

        for (WorksheetContent worksheetContent : worksheetContents) {
            final WorksheetSpec spec = worksheetContent.getSpec();
            appendSheet(workbook, worksheetContent.getDomainObjects(), spec.getFactory(), spec.getSheetName());
        }
        workbook.write(fos);
        fos.close();
        return tempFile;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_2_isis_excel_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing ExcelConverter.appendSheet ===\n");

        
        List<WorksheetContent> contents = new ArrayList<>();
        contents.add(new WorksheetContent(new WorksheetSpec("Sheet1", "factory1"), Arrays.asList("obj1", "obj2")));
        contents.add(new WorksheetContent(new WorksheetSpec("Sheet2", "factory2"), Arrays.asList("obj3")));

        ExcelConverter converter = new ExcelConverter();
        try {
            File file = converter.appendSheet(contents);
            System.out.println("Created file: " + file.getAbsolutePath());
            
            file.deleteOnExit();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}