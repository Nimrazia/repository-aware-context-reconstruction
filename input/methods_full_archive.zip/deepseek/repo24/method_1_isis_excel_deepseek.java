import java.util.*;
import java.lang.annotation.*;






@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@interface Action {
    SemanticsOf semantics() default SemanticsOf.NON_IDEMPOTENT;
    InvokeOn invokeOn() default InvokeOn.OBJECT_ONLY;
}

enum SemanticsOf { IDEMPOTENT, NON_IDEMPOTENT }
enum InvokeOn { OBJECT_AND_COLLECTION, OBJECT_ONLY }

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@interface Collection {
    
}


class Container {
    public void warnUser(String msg) { System.out.println("[WARN] " + msg); }
    public <T> List<T> allMatches(Class<T> cls, Object predicate) {
        
        return new ArrayList<>();
    }
}


class ActionInvocationContext {
    private InvokedOn invokedOn;
    public ActionInvocationContext(Object invokedOn) { this.invokedOn = new InvokedOn(false); }
    public InvokedOn getInvokedOn() { return invokedOn; }
    static class InvokedOn { private final boolean collection; InvokedOn(boolean c){collection=c;} public boolean isCollection(){return collection;} }
}


class ExcelModuleDemoToDoItem {
    private String description;
    private String category;
    private String subcategory;
    private Date dueBy;
    private double cost;
    private String notes;
    private String ownedBy;
    private boolean complete;

    
    public String getDescription() { return description; }
    public void setDescription(String d) { description = d; }
    public String getCategory() { return category; }
    public void setCategory(String c) { category = c; }
    public String getSubcategory() { return subcategory; }
    public void setSubcategory(String s) { subcategory = s; }
    public Date getDueBy() { return dueBy; }
    public void setDueBy(Date d) { dueBy = d; }
    public double getCost() { return cost; }
    public void setCost(double c) { cost = c; }
    public String getNotes() { return notes; }
    public void setNotes(String n) { notes = n; }
    public String getOwnedBy() { return ownedBy; }
    public void setOwnedBy(String o) { ownedBy = o; }
    public boolean isComplete() { return complete; }
    public void setComplete(boolean c) { complete = c; }
}


class ExcelModuleDemoToDoItems {
    public ExcelModuleDemoToDoItem findByDescription(String desc) {
        
        return null;
    }
    public ExcelModuleDemoToDoItem newToDo(String desc, String cat, String sub, Date due, double cost) {
        ExcelModuleDemoToDoItem item = new ExcelModuleDemoToDoItem();
        item.setDescription(desc);
        item.setCategory(cat);
        item.setSubcategory(sub);
        item.setDueBy(due);
        item.setCost(cost);
        return item;
    }
}





class ExcelModuleDemoToDoItemBulkUpdateLineItem {
    private ExcelModuleDemoToDoItem toDoItem;
    private String description;
    private String category;
    private String subcategory;
    private Date dueBy;
    private double cost;
    private String notes;
    private String ownedBy;
    private boolean complete;

    private ExcelModuleDemoToDoItems toDoItems = new ExcelModuleDemoToDoItems();
    private Container container = new Container();
    private ActionInvocationContext actionInvocationContext = new ActionInvocationContext(this);

    
    public ExcelModuleDemoToDoItem getToDoItem() { return toDoItem; }
    public String getDescription() { return description; }
    public String getCategory() { return category; }
    public String getSubcategory() { return subcategory; }
    public Date getDueBy() { return dueBy; }
    public double getCost() { return cost; }
    public String getNotes() { return notes; }
    public String getOwnedBy() { return ownedBy; }
    public boolean isComplete() { return complete; }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Action(
            semantics = SemanticsOf.IDEMPOTENT,
            invokeOn = InvokeOn.OBJECT_AND_COLLECTION
    )
    public ExcelModuleDemoToDoItem apply() {
        ExcelModuleDemoToDoItem item = getToDoItem();
        if(item == null) {
            
            item = toDoItems.findByDescription(getDescription());
            if(item != null) {
                getContainer().warnUser("Item already exists with description '" + getDescription() + "'");
            } else {
                
                
                item = toDoItems.newToDo(getDescription(), getCategory(), getSubcategory(), getDueBy(), getCost());
                item.setNotes(getNotes());
                item.setOwnedBy(getOwnedBy());
                item.setComplete(isComplete());
            }
        } else {
            
            
            item.setDescription(getDescription());
            item.setCategory(getCategory());
            item.setSubcategory(getSubcategory());
            item.setDueBy(getDueBy());
            item.setCost(getCost());
            item.setNotes(getNotes());
            item.setOwnedBy(getOwnedBy());
            item.setComplete(isComplete());
        }
        return actionInvocationContext.getInvokedOn().isCollection()? null: item;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    private Container getContainer() { return container; }
}



public class method_1_isis_excel_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing ExcelModuleDemoToDoItemBulkUpdateLineItem.apply ===\n");

        
        ExcelModuleDemoToDoItemBulkUpdateLineItem lineItem = new ExcelModuleDemoToDoItemBulkUpdateLineItem();
        
        
        
        

        
        ExcelModuleDemoToDoItem result = lineItem.apply();
        System.out.println("Apply result: " + result);

        
        

        System.out.println("\n=== Test completed ===");
    }
}