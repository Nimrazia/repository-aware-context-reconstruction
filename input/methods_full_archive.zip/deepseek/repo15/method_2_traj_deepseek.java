import java.awt.geom.Point2D;
import java.util.*;
import java.util.EmptyStackException;

class Array2DRowRealMatrix extends RealMatrix {
    private double[][] data;
    public Array2DRowRealMatrix(double[][] data) { super(data); this.data = data; }
    public double[][] getData() { return data; }
}

class EigenDecomposition {
    private RealMatrix eigenVectors;
    public EigenDecomposition(RealMatrix matrix) {
        
    }
    public RealMatrix getEigenvector(int i) {
        return new RealMatrix(new double[][]{{1,0},{0,1}});
    }
}

class RealMatrix {
    private double[][] data;
    public RealMatrix(double[][] data) { this.data = data; }
    public double getEntry(int i, int j) { return data[i][j]; }
    public double getEntry(int i) { return data[i][0]; }
}

class SplineInterpolator {
    public PolynomialSplineFunction interpolate(double[] x, double[] y) {
        return new PolynomialSplineFunction(x, y);
    }
}

class PolynomialSplineFunction {
    private double[] knots;
    private double[] coefs;
    public PolynomialSplineFunction(double[] x, double[] y) {
        this.knots = x;
        this.coefs = y;
    }
    public int getN() { return knots.length - 1; }
    public double[] getKnots() { return knots; }
    public double value(double x) { return x; }
}


class Trajectory {
    private List<Point2D.Double> points = new ArrayList<>();
    private int dimension = 2;
    public Trajectory() {}
    public Trajectory(List<Point2D.Double> pts) { points.addAll(pts); }
    public int size() { return points.size(); }
    public Point2D.Double get(int i) { return points.get(i); }
    public void add(double x, double y, int z) { points.add(new Point2D.Double(x,y)); }
    public void add(Point2D.Double p) { points.add(p); }
    public int getDimension() { return dimension; }
}

class RadiusGyrationTensor2D {
    public static Array2DRowRealMatrix getRadiusOfGyrationTensor(Trajectory t) {
        return new Array2DRowRealMatrix(new double[][]{{1,0},{0,1}});
    }
}

class CenterOfGravityFeature {
    private Trajectory traj;
    public CenterOfGravityFeature(Trajectory traj) { this.traj = traj; }
    public double[] evaluate() {
        if (traj.size() == 0) return new double[]{0,0};
        double cx=0, cy=0;
        for (int i=0; i<traj.size(); i++) {
            cx += traj.get(i).x; cy += traj.get(i).y;
        }
        return new double[]{cx/traj.size(), cy/traj.size()};
    }
}

class StandardDeviation {
    private double[] data;
    public void setData(double[] data) { this.data = data; }
    public double evaluate() {
        if (data == null || data.length == 0) return 0;
        double mean=0; for (double d : data) mean+=d; mean/=data.length;
        double var=0; for (double d : data) var += (d-mean)*(d-mean);
        return Math.sqrt(var/data.length);
    }
}

class Vector2d {
    public double x, y;
    public Vector2d(double x, double y) { this.x = x; this.y = y; }
    public void normalize() {
        double len = Math.sqrt(x*x + y*y);
        if (len > 0) { x/=len; y/=len; }
    }
    public void scale(double s) { x*=s; y*=s; }
}


class KDTree<V> {
    private int dimension;
    public KDTree(int dim) { dimension = dim; }
    public void insert(double[] key, V value) throws KeyDuplicateException, KeySizeException {}
    public List<V> nearestEuclidean(double[] center, double radius) throws KeySizeException {
        List<V> list = new ArrayList<>();
        
        for (int i=0; i<10; i++) {
            list.add((V) new Point2D.Double(center[0]+i*0.1, center[1]+i*0.1));
        }
        return list;
    }
}

class KeySizeException extends Exception {}
class KeyDuplicateException extends Exception {}


class Utils {
    public static boolean isLeft(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        double cross = (p2.x - p1.x)*(p.y - p1.y) - (p2.y - p1.y)*(p.x - p1.x);
        return cross < 0;
    }
    public static double distancePointLine(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        double num = Math.abs((p2.x-p1.x)*(p.y-p1.y) - (p2.y-p1.y)*(p.x-p1.x));
        double den = Math.sqrt((p2.x-p1.x)*(p2.x-p1.x) + (p2.y-p1.y)*(p2.y-p1.y));
        if (den == 0) return 0;
        return num / den;
    }
    public static Point2D.Double minDistancePointToLine(Point2D.Double p1, Point2D.Double p2, List<Point2D.Double> points) {
        
        if (points.isEmpty()) return new Point2D.Double(0,0);
        double minDist = Double.MAX_VALUE;
        Point2D.Double best = points.get(0);
        for (Point2D.Double p : points) {
            double d = distancePointLine(p1, p2, p);
            if (d < minDist) { minDist = d; best = p; }
        }
        return best;
    }
    public static Point2D.Double projectPointToLine(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        
        double dx = p2.x - p1.x;
        double dy = p2.y - p1.y;
        double t = ((p.x-p1.x)*dx + (p.y-p1.y)*dy) / (dx*dx + dy*dy);
        return new Point2D.Double(p1.x + t*dx, p1.y + t*dy);
    }
}





class RotatingCalipers {
    public static Point2D.Double[] getMinimumBoundingRectangle(List<Point2D.Double> points) {
        
        if (points.isEmpty()) return new Point2D.Double[0];
        double minx=Double.MAX_VALUE, miny=Double.MAX_VALUE, maxx=-Double.MAX_VALUE, maxy=-Double.MAX_VALUE;
        for (Point2D.Double p : points) {
            if (p.x < minx) minx = p.x;
            if (p.y < miny) miny = p.y;
            if (p.x > maxx) maxx = p.x;
            if (p.y > maxy) maxy = p.y;
        }
        return new Point2D.Double[]{
            new Point2D.Double(minx, maxy), 
            new Point2D.Double(maxx, maxy),
            new Point2D.Double(maxx, miny),
            new Point2D.Double(minx, miny)
        };
    }
}


class LegacyUtils {
    public static Point2D.Double projectPointToLine(Point2D.Double p1, Point2D.Double p2, Point2D.Double p) {
        double dx = p2.x - p1.x;
        double dy = p2.y - p1.y;
        double t = ((p.x-p1.x)*dx + (p.y-p1.y)*dy) / (dx*dx + dy*dy);
        return new Point2D.Double(p1.x + t*dx, p1.y + t*dy);
    }
}



class TrajectorySplineFitLegacy {
    private Trajectory t;
    private int nSegments;
    private double angleRotated = 0;
    private Trajectory rotatedTrajectory = new Trajectory();
    private List<Point2D.Double> splineSupportPoints;
    private PolynomialSplineFunction spline;

    public TrajectorySplineFitLegacy(Trajectory t, int nSegments) {
        this.t = t;
        this.nSegments = nSegments;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public PolynomialSplineFunction calculateSpline(){


        


        ArrayList<Point2D.Double> points = new ArrayList<Point2D.Double>();
        for(int i = 0; i < t.size(); i++){
            Point2D.Double p = new Point2D.Double();
            p.setLocation(t.get(i).x, t.get(i).y);
            points.add(p);
        }
        Point2D.Double[] rect = null;
        try{
            rect = RotatingCalipers.getMinimumBoundingRectangle(points);
        }
        catch(IllegalArgumentException e)
        {

        }
        catch(EmptyStackException e){

        }

        



        Point2D.Double majorDirection = null;

        Point2D.Double p1 = rect[2]; 
        Point2D.Double p2 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[1] : rect[3]; 
        Point2D.Double p3 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[3] : rect[1]; 
        majorDirection = new Point2D.Double(p2.x-p1.x, p2.y-p1.y);
        double width = p1.distance(p2);
        double inRad = -1*Math.atan2(majorDirection.y, majorDirection.x);

        boolean doTransform = (Math.abs(Math.abs(inRad)-Math.PI)>0.001);

        if(doTransform)
        {
            angleRotated = inRad;
            for(int i = 0; i < t.size(); i++){
                double x = t.get(i).x;
                double y = t.get(i).y;
                double newX = x*Math.cos(inRad)-y*Math.sin(inRad);
                double newY = x*Math.sin(inRad)+y*Math.cos(inRad);
                rotatedTrajectory.add(newX, newY, 0);
                points.get(i).setLocation(newX, newY);
            }
            for(int i = 0; i < rect.length; i++){
                rect[i].setLocation(rect[i].x*Math.cos(inRad)-rect[i].y*Math.sin(inRad), rect[i].x*Math.sin(inRad)+rect[i].y*Math.cos(inRad));
            }

            p1 = rect[2]; 
            p2 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[1] : rect[3]; 
            p3 = p1.distance(rect[1]) > p1.distance(rect[3]) ? rect[3] : rect[1]; 
        }
        else{
            angleRotated = 0;
            rotatedTrajectory = t;
        }

        






        List<List<Point2D.Double>> pointsInSegments =null;
        boolean allSegmentsContainingAtLeastTwoPoints = true;
        do{

            allSegmentsContainingAtLeastTwoPoints = true;
            double segmentWidth = p1.distance(p2)/nSegments;
            pointsInSegments = new ArrayList<List<Point2D.Double>>(nSegments);
            for(int i = 0; i < nSegments; i++){
                pointsInSegments.add(new ArrayList<Point2D.Double>());
            }
            for(int i = 0; i < points.size(); i++){
                Point2D.Double projPoint  = LegacyUtils.projectPointToLine(p1, p2, points.get(i));
                int index = (int)(p1.distance(projPoint)/segmentWidth);

                if(index>(nSegments-1)){
                    index = (nSegments-1);
                }
                pointsInSegments.get(index).add(points.get(i));
            }

            for(int i = 0; i < pointsInSegments.size(); i++){
                if(pointsInSegments.get(i).size()<2){
                    if(nSegments>2){
                        nSegments--;
                        i = pointsInSegments.size();
                        allSegmentsContainingAtLeastTwoPoints = false;

                    }
                }
            }
        }while(allSegmentsContainingAtLeastTwoPoints==false);


        



        Point2D.Double eMajorP1 = new Point2D.Double(p1.x - (p3.x-p1.x)/2.0,p1.y - (p3.y-p1.y)/2.0);
        Point2D.Double eMajorP2 = new Point2D.Double(p2.x - (p3.x-p1.x)/2.0,p2.y - (p3.y-p1.y)/2.0);
        double sumMean=0;
        int Nsum = 0;
        for(int i = 0; i < nSegments; i++){
            StandardDeviation sd = new StandardDeviation();
            double[] distances = new double[pointsInSegments.get(i).size()];
            for(int j = 0; j < pointsInSegments.get(i).size(); j++){
                int factor = 1;
                if(Utils.isLeft(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j))){
                    factor = -1;
                }
                distances[j] = factor*Utils.distancePointLine(eMajorP1, eMajorP2, pointsInSegments.get(i).get(j));
            }
            if(distances.length >0){
                sd.setData(distances);

                sumMean += sd.evaluate();

                Nsum++;
            }
        }
        double s = sumMean/Nsum;
        if(s<0.000000000001){
            s = width/nSegments;
        }

        


        KDTree<Point2D.Double> kdtree = new KDTree<Point2D.Double>(2);

        for(int i = 0; i< points.size(); i++){
            try {
                

                kdtree.insert(new double[]{points.get(i).x,points.get(i).y}, points.get(i));
            } catch (KeySizeException e) {
                e.printStackTrace();
            } catch (KeyDuplicateException e) {
                
            }

        }

        



        List<Point2D.Double> near = null;

        Point2D.Double first = Utils.minDistancePointToLine(p1, p3, points);
        double r1 = 3*s;
        try {

            near = kdtree.nearestEuclidean(new double[]{first.x ,first.y}, r1);

        } catch (KeySizeException e) {
            e.printStackTrace();
        }

        double cx = 0;
        double cy = 0;
        for(int i = 0; i < near.size(); i++){
            cx += near.get(i).x;
            cy += near.get(i).y;
        }
        cx /= near.size();
        cy /= near.size();

        splineSupportPoints = new ArrayList<Point2D.Double>();
        splineSupportPoints.add(new Point2D.Double(cx, cy));

        






        




        



        int nCircleSegments = 100;
        double deltaRad = 2*Math.PI/nCircleSegments;
        boolean stop = false;
        int minN = 7;
        double tempr1 = r1;
        double allowedDeltaDirection = 0.5*Math.PI;

        while(stop==false){
            List<Point2D.Double> nearestr1 = null;
            List<Point2D.Double> nearest2xr1 = null;
            try {
                nearestr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},tempr1);
                nearest2xr1 = kdtree.nearestEuclidean(new double[]{splineSupportPoints.get(splineSupportPoints.size()-1).x, splineSupportPoints.get(splineSupportPoints.size()-1).y},2*tempr1);
            } catch (KeySizeException e) {
                
                e.printStackTrace();
            }
            nearest2xr1.removeAll(nearestr1);

            double lThreshRad = 0;
            double hThreshRad = Math.PI/2;
            double stopThresh = 2*Math.PI;
            if(splineSupportPoints.size()>1){
                double directionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y,
                        splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
                lThreshRad = directionInRad - allowedDeltaDirection/2 - Math.PI/4;
                if(lThreshRad<0){
                    lThreshRad = 2*Math.PI+lThreshRad;
                }
                if(lThreshRad>2*Math.PI){
                    lThreshRad = lThreshRad - 2*Math.PI;
                }
                hThreshRad = directionInRad + allowedDeltaDirection/2 + Math.PI/4;
                if(hThreshRad<0){
                    hThreshRad = 2*Math.PI+hThreshRad;
                }
                if(hThreshRad>2*Math.PI){
                    hThreshRad = hThreshRad - 2*Math.PI;
                }
                stopThresh = directionInRad + allowedDeltaDirection/2 - Math.PI/4;
                if(stopThresh>2*Math.PI){
                    stopThresh = stopThresh - 2*Math.PI;
                }

            }

            double newCx=0;
            double newCy=0;
            int newCN = 0;
            int candN = 0;

            
            double lastDist = 0;
            double newDist = 0;
            do{
                lastDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));

                candN=0;
                double candCx =0;
                double candCy =0;

                for(int i = 0; i < nearest2xr1.size(); i++){
                    Point2D.Double centerOfCircle = splineSupportPoints.get(splineSupportPoints.size()-1);
                    Vector2d relativeToCircle = new Vector2d(nearest2xr1.get(i).x-centerOfCircle.x,nearest2xr1.get(i).y-centerOfCircle.y);
                    relativeToCircle.normalize();
                    double angleInRadians = Math.atan2(relativeToCircle.y, relativeToCircle.x)+Math.PI;

                    if(lThreshRad<hThreshRad){
                        if(angleInRadians>lThreshRad && angleInRadians < hThreshRad){
                            candCx+=nearest2xr1.get(i).x;
                            candCy+=nearest2xr1.get(i).y;
                            candN++;
                        }
                    }
                    else{
                        if(angleInRadians>lThreshRad || angleInRadians < hThreshRad){
                            candCx+=nearest2xr1.get(i).x;
                            candCy+=nearest2xr1.get(i).y;
                            candN++;
                        }
                    }


                }

                if(candN>0 && candN > newCN ){
                    candCx /= candN;
                    candCy /= candN;
                    newCx = candCx;
                    newCy = candCy;
                    newCN = candN;
                }
                lThreshRad += deltaRad;
                hThreshRad += deltaRad;
                if(lThreshRad>2*Math.PI){
                    lThreshRad = lThreshRad - 2*Math.PI;
                }
                if(hThreshRad>2*Math.PI){
                    hThreshRad = hThreshRad - 2*Math.PI;
                }
                newDist=Math.min(Math.abs(lThreshRad-stopThresh), 2*Math.PI-Math.abs(lThreshRad-stopThresh));

            }while((newDist-lastDist)>0);


            
            if(splineSupportPoints.size()>1){
                double currentDirectionInRad = Math.atan2(splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y,
                        splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x)+Math.PI;
                double candDirectionInRad = Math.atan2(newCy-splineSupportPoints.get(splineSupportPoints.size()-1).y,
                        newCx-splineSupportPoints.get(splineSupportPoints.size()-1).x)+Math.PI;
                double dDir = Math.max(currentDirectionInRad, candDirectionInRad)-Math.min(currentDirectionInRad, candDirectionInRad);
                if(dDir>2*Math.PI){
                    dDir = 2*Math.PI-dDir;
                }
                if(dDir>allowedDeltaDirection){

                    stop = true;
                }
            }
            boolean enoughPoints = (newCN<minN);
            boolean isNormalRadius = Math.abs(tempr1-r1)<Math.pow(10, -18);
            boolean isExtendedRadius = Math.abs(tempr1-3*r1)<Math.pow(10, -18);

            if(enoughPoints&& isNormalRadius){
                
                tempr1 = 3*r1;
            }
            else if(enoughPoints && isExtendedRadius){
                
                stop = true;
            }
            else if(stop==false){
                splineSupportPoints.add(new Point2D.Double(newCx,newCy));
                tempr1 = r1;
            }

        }

        
        Collections.sort(splineSupportPoints, new Comparator<Point2D.Double>() {

            public int compare(Point2D.Double o1, Point2D.Double o2) {
                if(o1.x<o2.x){
                    return -1;
                }
                if(o1.x>o2.x){
                    return 1;
                }
                return 0;
            }
        });



        
        if(splineSupportPoints.size()>1){
            Vector2d start = new Vector2d(splineSupportPoints.get(0).x-splineSupportPoints.get(1).x, splineSupportPoints.get(0).y-splineSupportPoints.get(1).y);
            start.normalize();
            start.scale(r1*8);
            splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+start.x, splineSupportPoints.get(0).y+start.y));

            Vector2d end = new Vector2d(splineSupportPoints.get(splineSupportPoints.size()-1).x-splineSupportPoints.get(splineSupportPoints.size()-2).x,
                    splineSupportPoints.get(splineSupportPoints.size()-1).y-splineSupportPoints.get(splineSupportPoints.size()-2).y);
            end.normalize();
            end.scale(r1*6);
            splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+end.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+end.y));
        }
        else{
            Vector2d majordir = new Vector2d(-1, 0);
            majordir.normalize();
            majordir.scale(r1*8);
            splineSupportPoints.add(0, new Point2D.Double(splineSupportPoints.get(0).x+majordir.x, splineSupportPoints.get(0).y+majordir.y));
            majordir.scale(-1);
            splineSupportPoints.add(new Point2D.Double(splineSupportPoints.get(splineSupportPoints.size()-1).x+majordir.x, splineSupportPoints.get(splineSupportPoints.size()-1).y+majordir.y));


        }




        
        double[] supX = new double[splineSupportPoints.size()];
        double[] supY = new double[splineSupportPoints.size()];
        for(int i = 0; i < splineSupportPoints.size(); i++){
            supX[i] = splineSupportPoints.get(i).x;
            supY[i] = splineSupportPoints.get(i).y;
        }

        SplineInterpolator sIinter = new SplineInterpolator();
        spline = sIinter.interpolate(supX, supY);

        return spline;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_2_traj_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing TrajectorySplineFitLegacy.calculateSpline ===\n");

        Trajectory traj = new Trajectory();
        traj.add(0.0, 0.0, 0);
        traj.add(1.0, 1.0, 0);
        traj.add(2.0, 2.0, 0);
        traj.add(3.0, 3.0, 0);
        traj.add(4.0, 4.0, 0);
        traj.add(5.0, 5.0, 0);

        int nSegments = 3;
        TrajectorySplineFitLegacy fit = new TrajectorySplineFitLegacy(traj, nSegments);
        PolynomialSplineFunction spline = fit.calculateSpline();

        System.out.println("Spline computed: " + (spline != null ? "success" : "failed"));
        if (spline != null) {
            System.out.println("Number of spline segments: " + spline.getN());
            System.out.println("Value at x=2.5: " + spline.value(2.5));
        }

        System.out.println("\n=== Test completed ===");
    }
}