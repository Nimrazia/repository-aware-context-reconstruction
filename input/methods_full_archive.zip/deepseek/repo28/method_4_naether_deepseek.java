import java.io.File;
import java.util.*;






class DefaultServiceLocator {
    private Map<Class<?>, Object> services = new HashMap<>();
    public <T> void setServices(Class<T> cls, T impl) { services.put(cls, impl); }
    public <T> void addService(Class<T> cls, Class<? extends T> impl) {  }
    public <T> T getService(Class<T> cls) { return (T) services.get(cls); }
}


class SimpleLocalRepositoryManagerFactory {
    public void initService(DefaultServiceLocator locator) {  }
    public LocalRepositoryManager newInstance(LocalRepository repo) throws NoLocalRepositoryManagerException {
        return new LocalRepositoryManager() {
            public String getPathForLocalArtifact(Artifact a) {
                return a.getGroupId().replace('.', '/') + "/" + a.getArtifactId() + "/" + a.getVersion() + "/" + a.getArtifactId() + "-" + a.getVersion() + "." + a.getType();
            }
        };
    }
}

interface LocalRepositoryManager {
    String getPathForLocalArtifact(Artifact a);
}

class NoLocalRepositoryManagerException extends Exception {
    public NoLocalRepositoryManagerException(String msg) { super(msg); }
}


class LocalRepository {
    private String basedir;
    public LocalRepository(String path) { basedir = path; }
    public String getBasedir() { return basedir; }
}


class NaetherException extends Exception {
    public NaetherException(String msg) { super(msg); }
    public NaetherException(String msg, Throwable cause) { super(msg, cause); }
}


interface Artifact {
    String getGroupId();
    String getArtifactId();
    String getVersion();
    String getType();
}

class DefaultArtifact implements Artifact {
    private String groupId, artifactId, version, type = "jar", classifier;
    public DefaultArtifact(String coords) {
        String[] parts = coords.split(":");
        if (parts.length >= 3) {
            groupId = parts[0];
            artifactId = parts[1];
            version = parts[2];
            if (parts.length > 3 && !parts[3].isEmpty()) {
                
                
            }
        }
    }
    public String getGroupId() { return groupId; }
    public String getArtifactId() { return artifactId; }
    public String getVersion() { return version; }
    public String getType() { return "jar"; }
}


class Dependency {
    private Artifact artifact;
    private String scope;
    public Dependency(Artifact a, String scope) { this.artifact = a; this.scope = scope; }
    public Artifact getArtifact() { return artifact; }
}





class Notation {
    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public static List<String> getLocalPaths( String localRepoPath, List<String> notations ) throws NaetherException {
        DefaultServiceLocator locator = new DefaultServiceLocator();
        SimpleLocalRepositoryManagerFactory factory = new SimpleLocalRepositoryManagerFactory();
        factory.initService( locator );

        LocalRepository localRepo = new LocalRepository(localRepoPath);
        LocalRepositoryManager manager = null;
        try {
            manager = factory.newInstance( localRepo );
        } catch (NoLocalRepositoryManagerException e) {
            throw new NaetherException( "Failed to initial local repository manage", e  );
        }

        List<String> localPaths = new ArrayList<String>();

        for ( String notation : notations ) {
            Dependency dependency = new Dependency(new DefaultArtifact(notation), "compile");
            File path = new File( localRepo.getBasedir(), manager.getPathForLocalArtifact( dependency.getArtifact() ) );
            localPaths.add( path.toString() );
        }

        return localPaths;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_4_naether_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing Notation.getLocalPaths ===\n");

        List<String> notations = Arrays.asList("junit:junit:4.12", "org.slf4j:slf4j-api:1.7.25");
        String repoPath = "/tmp/repo";

        try {
            List<String> paths = Notation.getLocalPaths(repoPath, notations);
            System.out.println("Local paths:");
            for (String p : paths) {
                System.out.println("  " + p);
            }
        } catch (NaetherException e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}