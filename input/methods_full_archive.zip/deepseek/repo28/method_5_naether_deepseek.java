import java.io.File;
import java.util.List;






class Log {
    public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
    public void debug(String msg, Object... args) { System.out.println("[DEBUG] " + String.format(msg, args)); }
    public void error(String msg, Throwable t) { System.err.println("[ERROR] " + msg); t.printStackTrace(); }
}


class DeployArtifact {
    private String notation;
    private Artifact jarArtifact;
    private Artifact pomArtifact;
    private RemoteRepository remoteRepo;
    public String getNotation() { return notation; }
    public Artifact getJarArtifact() { return jarArtifact; }
    public Artifact getPomArtifact() { return pomArtifact; }
    public RemoteRepository getRemoteRepo() { return remoteRepo; }
    public void setNotation(String n) { notation = n; }
    public void setJarArtifact(Artifact a) { jarArtifact = a; }
    public void setPomArtifact(Artifact a) { pomArtifact = a; }
    public void setRemoteRepo(RemoteRepository r) { remoteRepo = r; }
}


class DeployRequest {
    private List<Artifact> artifacts = new java.util.ArrayList<>();
    private RemoteRepository repository;
    public void addArtifact(Artifact a) { artifacts.add(a); }
    public void setRepository(RemoteRepository r) { repository = r; }
    public List<Artifact> getArtifacts() { return artifacts; }
    public RemoteRepository getRepository() { return repository; }
}


class DeploymentException extends Exception {
    public DeploymentException(String msg, Throwable cause) { super(msg, cause); }
}


class DeployException extends Exception {
    public DeployException(Throwable cause) { super(cause); }
}


interface Artifact {
    String getGroupId();
    String getArtifactId();
    String getVersion();
    File getFile();
}

class DefaultArtifact implements Artifact {
    private String groupId, artifactId, version, type, classifier;
    private File file;
    public DefaultArtifact(String g, String a, String v, String type, File f) {
        this.groupId = g; this.artifactId = a; this.version = v; this.type = type; this.file = f;
    }
    public String getGroupId() { return groupId; }
    public String getArtifactId() { return artifactId; }
    public String getVersion() { return version; }
    public File getFile() { return file; }
}


class RemoteRepository {
    private String id, url;
    public RemoteRepository(String id, String url) { this.id = id; this.url = url; }
    public String getId() { return id; }
    public String getUrl() { return url; }
}


class RepositoryClient {
    private String localRepoPath;
    public RepositoryClient(String path) { localRepoPath = path; }
    public void deploy(DeployRequest req) throws DeploymentException {
        
        System.out.println("Deploying to " + req.getRepository().getUrl());
        for (Artifact a : req.getArtifacts()) {
            System.out.println("  " + a.getGroupId() + ":" + a.getArtifactId() + ":" + a.getVersion() + " from " + a.getFile());
        }
        if (req.getArtifacts().isEmpty()) {
            throw new DeploymentException("No artifacts to deploy", null);
        }
    }
}





class NaetherImpl {
    private Log log = new Log();
    private String localRepoPath = "/tmp/repo";

    public String getLocalRepoPath() { return localRepoPath; }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void deployArtifact(DeployArtifact deployArtifact) throws DeployException {
        log.debug("deploy artifact: {} ", deployArtifact.getNotation());

        RepositoryClient repoClient = new RepositoryClient(this.getLocalRepoPath());

        DeployRequest deployRequest = new DeployRequest();
        deployRequest.addArtifact(deployArtifact.getJarArtifact());
        if (deployArtifact.getPomArtifact() != null) {
            deployRequest.addArtifact(deployArtifact.getPomArtifact());
        }
        deployRequest.setRepository(deployArtifact.getRemoteRepo());

        log.debug("deploying artifact {}", deployArtifact.getNotation());
        try {
            repoClient.deploy(deployRequest);
        } catch (DeploymentException e) {
            log.error("Failed to deploy artifact", e);
            throw new DeployException(e);
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_5_naether_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing NaetherImpl.deployArtifact ===\n");

        
        DeployArtifact deploy = new DeployArtifact();
        deploy.setNotation("com.example:myapp:1.0");
        File jarFile = new File("/tmp/myapp.jar");
        File pomFile = new File("/tmp/myapp.pom");
        deploy.setJarArtifact(new DefaultArtifact("com.example", "myapp", "1.0", "jar", jarFile));
        deploy.setPomArtifact(new DefaultArtifact("com.example", "myapp", "1.0", "pom", pomFile));
        deploy.setRemoteRepo(new RemoteRepository("local", "file:///tmp/repo"));

        NaetherImpl naether = new NaetherImpl();
        try {
            naether.deployArtifact(deploy);
            System.out.println("Deployment completed.");
        } catch (DeployException e) {
            System.err.println("Deployment failed: " + e.getMessage());
        }

        System.out.println("\n=== Test completed ===");
    }
}