import java.io.File;
import java.util.*;






class Log {
    public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
    public void debug(String msg, Object... args) { System.out.println("[DEBUG] " + String.format(msg, args)); }
    public void warn(String msg) { System.out.println("[WARN] " + msg); }
    public void error(String msg, Throwable t) { System.err.println("[ERROR] " + msg); t.printStackTrace(); }
}


class NaetherException extends Exception {
    public NaetherException(String msg) { super(msg); }
    public NaetherException(String msg, Throwable cause) { super(msg, cause); }
}


class ResolveException extends NaetherException {
    public ResolveException(Throwable cause) { super("Resolution failed", cause); }
}


interface Artifact {
    File getFile();
    String getGroupId();
    String getArtifactId();
    String getVersion();
}

class DefaultArtifact implements Artifact {
    private String groupId, artifactId, version, classifier, type;
    private File file;
    public DefaultArtifact(String coords) {
        
        String[] parts = coords.split(":");
        if (parts.length >= 3) {
            groupId = parts[0];
            artifactId = parts[1];
            version = parts[2];
            if (parts.length > 3) classifier = parts[3];
        }
    }
    public DefaultArtifact(String g, String a, String v, String type, String classifier) {
        this.groupId = g; this.artifactId = a; this.version = v; this.type = type; this.classifier = classifier;
    }
    public File getFile() { return file; }
    public void setFile(File f) { file = f; }
    public String getGroupId() { return groupId; }
    public String getArtifactId() { return artifactId; }
    public String getVersion() { return version; }
    public String getType() { return type; }
}


class RemoteRepository {
    private String id, url;
    public RemoteRepository(String id, String url) { this.id = id; this.url = url; }
    public String getId() { return id; }
    public String getUrl() { return url; }
}


class ArtifactRequest {
    private Artifact artifact;
    private List<RemoteRepository> repositories = new ArrayList<>();
    public void setArtifact(Artifact a) { artifact = a; }
    public void addRepository(RemoteRepository repo) { repositories.add(repo); }
    public Artifact getArtifact() { return artifact; }
    public List<RemoteRepository> getRepositories() { return repositories; }
}


class ArtifactResult {
    private Artifact artifact;
    public ArtifactResult(Artifact a) { artifact = a; }
    public Artifact getArtifact() { return artifact; }
}


class ArtifactResolutionException extends Exception {
    public ArtifactResolutionException(String msg, Throwable cause) { super(msg, cause); }
}


class DeploymentException extends Exception {
    public DeploymentException(String msg, Throwable cause) { super(msg, cause); }
}


class RepositoryClient {
    private String localRepoPath;
    public RepositoryClient(String path) { localRepoPath = path; }
    public ArtifactResult resolveArtifact(ArtifactRequest req) throws ArtifactResolutionException {
        
        Artifact a = req.getArtifact();
        File f = new File(localRepoPath, a.getGroupId() + "/" + a.getArtifactId() + "/" + a.getVersion() + "/" + a.getArtifactId() + "-" + a.getVersion() + ".jar");
        
        if (!f.exists()) {
            try { f.getParentFile().mkdirs(); f.createNewFile(); } catch (Exception e) {  }
        }
        ((DefaultArtifact)a).setFile(f);
        return new ArtifactResult(a);
    }
}





class NaetherImpl {
    private Log log = new Log();
    private String localRepoPath = "/tmp/repo";
    private List<RemoteRepository> remoteRepos = new ArrayList<>();

    public NaetherImpl() {
        remoteRepos.add(new RemoteRepository("central", "https://repo.maven.apache.org/maven2"));
    }

    public String getLocalRepoPath() { return localRepoPath; }
    public List<RemoteRepository> getRemoteRepositories() { return remoteRepos; }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @SuppressWarnings("rawtypes")
    public List<File> downloadArtifacts( List artifactsOrNotations ) throws NaetherException {

        List<Artifact> artifacts = new ArrayList<Artifact>();

        for ( Object artifactsOrNotation : artifactsOrNotations ) {
            if ( artifactsOrNotation != null ) {
                if ( artifactsOrNotation instanceof String ) {
                    artifacts.add( new DefaultArtifact( (String) artifactsOrNotation ) );
                } else if ( artifactsOrNotation instanceof Artifact ) {
                    artifacts.add( (Artifact)artifactsOrNotation );
                } else {
                    throw new NaetherException( "Only String notations or Artifact instances allowed. Found " + artifactsOrNotation.getClass() );
                }
            } else {
                log.warn( "Null found in list of artifacts to download" );
            }
        }

        List<File> files = new ArrayList<File>();

        for ( Artifact artifact : artifacts ) {

            log.debug( "Downloading {}", artifact );

            ArtifactRequest artifactRequest = new ArtifactRequest();
            artifactRequest.setArtifact( artifact );
            for ( RemoteRepository repo : this.getRemoteRepositories() ) {
                artifactRequest.addRepository( repo );
            }

            RepositoryClient repoClient = new RepositoryClient(this.getLocalRepoPath());

            ArtifactResult artifactResult = null;
            try {
                artifactResult = repoClient.resolveArtifact(artifactRequest );
            } catch (ArtifactResolutionException e) {
                throw new ResolveException(e);
            }

            Artifact downloadedArtifact = artifactResult.getArtifact();
            files.add( downloadedArtifact.getFile() );
        }

        return files;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_2_naether_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing NaetherImpl.downloadArtifacts ===\n");

        NaetherImpl naether = new NaetherImpl();
        List<Object> notations = new ArrayList<>();
        notations.add("junit:junit:4.12");
        notations.add("org.slf4j:slf4j-api:1.7.25");

        try {
            List<File> files = naether.downloadArtifacts(notations);
            System.out.println("Downloaded " + files.size() + " files:");
            for (File f : files) {
                System.out.println("  " + f.getAbsolutePath());
            }
        } catch (NaetherException e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}