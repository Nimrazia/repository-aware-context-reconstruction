import java.io.*;
import java.util.*;
import java.util.function.Function;




interface Label {
    String value();
    void setValue(String v);
}
class StringLabel implements Label {
    String s;
    StringLabel(String s) { this.s = s; }
    public String value() { return s; }
    public void setValue(String v) { s = v; }
}
class CoreLabel2 extends StringLabel { 
    private final Map<Class<?>,Object> annotations = new HashMap<>();
    String word="", tag="";
    CoreLabel2(String s) { super(s); this.word=s; }
    static CoreLabel2 factory() { return new CoreLabel2(""); }
    String word() { return word; }
    String tag() { return tag; }
    <T> T get(Class<?> key) { return (T) annotations.getOrDefault(key, Integer.valueOf(0)); }
    void set(Class<?> key,Object value){ annotations.put(key,value); }
}
class CyclicCoreLabel extends CoreLabel2 { static CyclicCoreLabel factory() { return new CyclicCoreLabel(""); } CyclicCoreLabel(String s) { super(s); } }

class Tree implements Iterable<Tree> {
    Label label;
    List<Tree> children;
    Tree(Label label, Tree... children) { this.label = label; this.children = Arrays.asList(children); }
    Label label() { return label; }
    void setLabel(Label l) { this.label = l; }
    List<Tree> getChildrenAsList() { return children; }
    Tree firstChild() { return children.get(0); }
    boolean isLeaf() { return children.isEmpty(); }
    boolean isUnaryRewrite() { return children.size()==1 && !children.get(0).isLeaf(); }
    void pennPrint(PrintWriter pw) { pw.print(label.value()); if(!isLeaf()) { pw.print(" ("); for(Tree c:children) c.pennPrint(pw); pw.print(")"); } }
    void indentedListPrint(PrintWriter pw, boolean b) { pw.print(label.value()+" "); for(Tree c:children) c.indentedListPrint(pw,b); }
    ArrayList<Label> yield() { ArrayList<Label> y = new ArrayList<>(); for(Tree c:children) y.addAll(c.yield()); if(isLeaf()) y.add(label); return y; }
    ArrayList<TaggedWord> taggedYield() { ArrayList<TaggedWord> r=new ArrayList<>(); for(Label l:this.yield()) r.add(new TaggedWord(l.value(),"TAG")); return r; }
    List<CoreLabel2> taggedLabeledYield() { List<CoreLabel2> r=new ArrayList<>(); int i=1; for(Label l:this.yield()){ CoreLabel2 c=new CoreLabel2(l.value()); c.tag="TAG"; i++; r.add(c);} return r; }
    Tree prune(Object filter) { return this; }
    Tree deepCopy(Object tf, Object lf) { return this; }
    void indexLeaves() {}
    Set mapDependencies(Object filter, Object hf) { return new HashSet(); }
    Set mapDependencies(Object filter, Object hf, String root) { return new HashSet(); }
    Object treeFactory() { return new Object(); }
    List<Tree> getLeaves(){ List<Tree> r=new ArrayList<>(); if(isLeaf()) r.add(this); else for(Tree c:children) r.addAll(c.getLeaves()); return r; }
    Tree parent(Tree root){ return root==this?this:root; }
    public Iterator<Tree> iterator(){ List<Tree> all=new ArrayList<>(); collect(this,all); return all.iterator(); }
    private static void collect(Tree t,List<Tree> all){ all.add(t); for(Tree c:t.children) collect(c,all); }
    Tree treeSkeletonCopy() { return this; }
}

class TaggedWord { String word, tag; TaggedWord(String w,String t){word=w;tag=t;} String word(){return word;} String tag(){return tag;} }
class Sentence { static String listToString(List<?> y, boolean b) { StringBuilder sb = new StringBuilder(); for(Object o:y) sb.append(o instanceof Label ? ((Label)o).value() : o.toString()).append(" "); return sb.toString().trim(); } }
class XMLUtils { static String escapeXML(String s) { return s; } }
class PTBTokenizer { static String ptb2Text(String s) { return s; } static String ptbToken2Text(String s) { return s; } }
class BobChrisTreeNormalizer { static class EmptyFilter {} Tree normalizeWholeTree(Tree t,Object f){return t;} }
class TreebankLanguagePack { boolean isStartSymbol(String s){ return "ROOT".equals(s); } }
class TreeStemmer { void visitTree(Tree t){} }
class HeadFinder {} 
class GrammaticalStructureFactory { GrammaticalStructure newGrammaticalStructure(Tree t) { return new GrammaticalStructure(); } }
class GrammaticalStructure { Collection typedDependencies() { return new ArrayList(); } Collection allTypedDependencies() { return new ArrayList(); } Collection typedDependenciesCollapsed(boolean b) { return new ArrayList(); } Collection typedDependenciesCCprocessed(boolean b) { return new ArrayList(); } Collection typedDependenciesCollapsedTree() { return new ArrayList(); } }
class Dependency<G,D,N> {
    G governor; D dependent;
    Dependency(G g, D d) { governor=g; dependent=d; }
    G governor() { return governor; }
    D dependent() { return dependent; }
    String toString(String format) { return ""; }
}
class Dependencies { static Comparator dependencyIndexComparator() { return (a,b)->0; } }




public class method_2_LVTagger_deepseek {

    static class TreePrint {
        Map<String, Boolean> formats = new HashMap<>();
        boolean removeEmpty, ptb2text, lexicalize, markHeadNodes, transChinese;
        boolean basicDependencies, nonCollapsedDependencies, nonCollapsedDependenciesSeparated, collapsedDependencies, CCPropagatedDependencies, treeDependencies;
        String rootLabelOnlyFormat = "rootLabelOnly";
        TreebankLanguagePack tlp = new TreebankLanguagePack();
        TreeStemmer stemmer;
        HeadFinder hf = new HeadFinder();
        GrammaticalStructureFactory gsf = new GrammaticalStructureFactory();
        Object dependencyWordFilter;
        Object dependencyFilter;
        Properties options = new Properties();

        
        boolean propertyToBoolean(Properties p, String key) { return false; }
        Tree getCollocationProcessedTree(Tree t, HeadFinder hf) { return t; }
        Tree markHeadNodes(Tree t) { return t; }
        void print(Object o, String s, PrintWriter pw) { pw.println(o.toString()); }
        void print(Object o, PrintWriter pw) { pw.println(o.toString()); }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private void printTreeInternal(final Tree t, final PrintWriter pw, final boolean inXml) {
            Tree outputTree = t;

            if (formats.containsKey("conll2007") || removeEmpty) {
              outputTree = outputTree.prune(new BobChrisTreeNormalizer.EmptyFilter());
            }

            if (formats.containsKey("words")) {
              if (inXml) {
                ArrayList<Label> sentUnstemmed = outputTree.yield();
                pw.println("  <words>");
                int i = 1;
                for (Label w : sentUnstemmed) {
                  pw.println("    <word ind=\"" + i + "\">" + XMLUtils.escapeXML(w.value()) + "</word>");
                  i++;
                }
                pw.println("  </words>");
              } else {
                String sent = Sentence.listToString(outputTree.yield(), false);
                if(ptb2text) {
                  pw.println(PTBTokenizer.ptb2Text(sent));
                } else {
                  pw.println(sent);
                  pw.println();
                }
              }
            }

            if (propertyToBoolean(options, "removeTopBracket")) {
              String s = outputTree.label().value();
              if (tlp.isStartSymbol(s)) {
                if (outputTree.isUnaryRewrite()) {
                  outputTree = outputTree.firstChild();
                } else {
                  
                  
                  
                  System.err.println("TreePrint: can't remove top bracket: not unary");
                }
              }
              
              
              
              
            }
            if (stemmer != null) {
              stemmer.visitTree(outputTree);
            }
            if (lexicalize) {
              outputTree = Trees.lexicalize(outputTree, hf);
              Function<Tree, Tree> a =
                TreeFunctions.getLabeledToDescriptiveCoreLabelTreeFunction();
              outputTree = a.apply(outputTree);
            }

            if (formats.containsKey("collocations")) {
              outputTree = getCollocationProcessedTree(outputTree, hf);
            }

            if (!lexicalize) { 
              Function<Tree, Tree> a =
                TreeFunctions.getLabeledTreeToStringLabeledTreeFunction();
              outputTree = a.apply(outputTree);
            }

            Tree outputPSTree = outputTree;  

            if (markHeadNodes) {
              outputPSTree = markHeadNodes(outputPSTree);
            }

            if (transChinese) {
              TreeTransformer tt = new TreeTransformer() {
                public Tree transformTree(Tree t) {
                  t = t.treeSkeletonCopy();
                  for (Tree subtree : t) {
                    if (subtree.isLeaf()) {
                      Label oldLabel = subtree.label();
                      String translation = ChineseEnglishWordMap.getInstance().getFirstTranslation(oldLabel.value());
                      if (translation == null) translation = "[UNK]";
                      Label newLabel = new StringLabel(oldLabel.value() + ':' + translation);
                      subtree.setLabel(newLabel);
                    }
                  }
                  return t;
                }
              };
              outputPSTree = tt.transformTree(outputPSTree);
            }

            if (propertyToBoolean(options, "xml")) {
              if (formats.containsKey("wordsAndTags")) {
                ArrayList<TaggedWord> sent = outputTree.taggedYield();
                pw.println("  <words pos=\"true\">");
                int i = 1;
                for (TaggedWord tw : sent) {
                  pw.println("    <word ind=\"" + i + "\" pos=\"" + XMLUtils.escapeXML(tw.tag()) + "\">" + XMLUtils.escapeXML(tw.word()) + "</word>");
                  i++;
                }
                pw.println("  </words>");
              }
              if (formats.containsKey("penn")) {
                pw.println("  <tree style=\"penn\">");
                StringWriter sw = new StringWriter();
                PrintWriter psw = new PrintWriter(sw);
                outputPSTree.pennPrint(psw);
                pw.print(XMLUtils.escapeXML(sw.toString()));
                pw.println("  </tree>");
              }
              if (formats.containsKey("latexTree")) {
                pw.println("    <tree style=\"latexTrees\">");
                pw.println(".[");
                StringWriter sw = new StringWriter();
                PrintWriter psw = new PrintWriter(sw);
                outputTree.indentedListPrint(psw,false);
                pw.print(XMLUtils.escapeXML(sw.toString()));
                pw.println(".]");
                pw.println("  </tree>");
              }
              if (formats.containsKey("dependencies")) {
                Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                         CoreLabel2.factory());
                indexedTree.indexLeaves();
                Set<Dependency<Label, Label, Object>> depsSet = indexedTree.mapDependencies(dependencyWordFilter, hf);
                List<Dependency<Label, Label, Object>> sortedDeps = new ArrayList<Dependency<Label, Label, Object>>(depsSet);
                Collections.sort(sortedDeps, Dependencies.dependencyIndexComparator());
                pw.println("<dependencies style=\"untyped\">");
                for (Dependency<Label, Label, Object> d : sortedDeps) {
                  pw.println(d.toString("xml"));
                }
                pw.println("</dependencies>");
              }
              if (formats.containsKey("conll2007") || formats.containsKey("conllStyleDependencies")) {
                System.err.println("The \"conll2007\" and \"conllStyleDependencies\" formats are ignored in xml.");
              }
              if (formats.containsKey("typedDependencies")) {
                GrammaticalStructure gs = gsf.newGrammaticalStructure(outputTree);
                if (basicDependencies) {
                  print(gs.typedDependencies(), "xml", pw);
                }
                if (nonCollapsedDependencies || nonCollapsedDependenciesSeparated) {
                  print(gs.allTypedDependencies(), "xml", pw);
                }
                if (collapsedDependencies) {
                  print(gs.typedDependenciesCollapsed(true), "xml", pw);
                }
                if (CCPropagatedDependencies) {
                  print(gs.typedDependenciesCCprocessed(true), "xml", pw);
                }
                if(treeDependencies) {
                  print(gs.typedDependenciesCollapsedTree(), "xml", pw);
                }
              }
              if (formats.containsKey("typedDependenciesCollapsed")) {
                GrammaticalStructure gs = gsf.newGrammaticalStructure(outputTree);
                print(gs.typedDependenciesCCprocessed(true), "xml", pw);
              }

              
              
              
              
              
            } else {
              
              if (formats.containsKey("wordsAndTags")) {
                pw.println(Sentence.listToString(outputTree.taggedYield(), false));
                pw.println();
              }
              if (formats.containsKey("oneline")) {
                pw.println(outputPSTree.toString());
              }
              if (formats.containsKey("penn")) {
                outputPSTree.pennPrint(pw);
                pw.println();
              }
              if (formats.containsKey(rootLabelOnlyFormat)) {
                pw.println(outputTree.label());
              }
              if (formats.containsKey("latexTree")) {
                pw.println(".[");
                outputTree.indentedListPrint(pw,false);
                pw.println(".]");
              }
              if (formats.containsKey("dependencies")) {
                
                Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                         CyclicCoreLabel.factory());
                indexedTree.indexLeaves();
                Set<Dependency<Label, Label, Object>> depsSet = indexedTree.mapDependencies(dependencyWordFilter, hf);
                List<Dependency<Label, Label, Object>> sortedDeps = new ArrayList<Dependency<Label, Label, Object>>(depsSet);
                Collections.sort(sortedDeps, Dependencies.dependencyIndexComparator());
                for (Dependency<Label, Label, Object> d : sortedDeps) {
                  pw.println(d.toString("predicate"));
                }
                pw.println();
              }
              if (formats.containsKey("conll2007")) {
                
                
                
                
                

                Tree it = outputTree.deepCopy(outputTree.treeFactory(), CoreLabel2.factory());
                it.indexLeaves();

                List<CoreLabel2> tagged = it.taggedLabeledYield();
                Set<Dependency<Label, Label, Object>> depsSet2 = it.mapDependencies(dependencyFilter, hf, "root");
                List<Dependency<Label, Label, Object>> sortedDeps2 = new ArrayList<Dependency<Label, Label, Object>>(depsSet2);
                Collections.sort(sortedDeps2, Dependencies.dependencyIndexComparator());

                for (int i = 0; i < tagged.size(); i++) {
                  CoreLabel2 w = tagged.get(i);
                  Dependency<Label, Label, Object> d = sortedDeps2.get(i);
                  CoreMap dep = (CoreMap) d.dependent();
                  CoreMap gov = (CoreMap) d.governor();

                  Integer depi = dep.get(CoreAnnotations.IndexAnnotation.class);
                  Integer govi = gov.get(CoreAnnotations.IndexAnnotation.class);

                  
                  String tag = PTBTokenizer.ptbToken2Text(w.tag());

                  String word = PTBTokenizer.ptbToken2Text(w.word());
                  String lemma = "_";
                  String feats = "_";
                  String pHead = "_";
                  String pDepRel = "_";
                  String depRel = (govi == 0) ? "ROOT" : "NULL";

                  
                  pw.printf("%d\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\t%s%n", depi,word,lemma,tag,tag,feats,govi,depRel,pHead,pDepRel);
                }
                pw.println();
              }
              if (formats.containsKey("conllStyleDependencies")) {
                
                BobChrisTreeNormalizer tn = new BobChrisTreeNormalizer();
                Tree indexedTree = outputTree.deepCopy(outputTree.treeFactory(),
                                                         CoreLabel2.factory());
                
                for (Tree node : indexedTree) {
                  if (node.label().value().startsWith("NML")) {
                    node.label().setValue("NP");
                  }
                }

                indexedTree = tn.normalizeWholeTree(indexedTree, outputTree.treeFactory());
                indexedTree.indexLeaves();
                Set<Dependency<Label, Label, Object>> depsSet3 = null;
                boolean failed = false;
                try {
                  depsSet3 = indexedTree.mapDependencies(dependencyFilter, hf);
                } catch (Exception e) {
                  failed = true;
                }
                if (failed) {
                  System.err.println("failed: ");
                  System.err.println(t);
                  System.err.println();
                } else {
                  Map<Integer,Integer> deps = new HashMap<Integer, Integer>();
                  for (Dependency<Label, Label, Object> dep : depsSet3) {
                    CoreLabel2 child = (CoreLabel2)dep.dependent();
                    CoreLabel2 parent = (CoreLabel2)dep.governor();
                    Integer childIndex =
                      child.get(CoreAnnotations.IndexAnnotation.class);
                    Integer parentIndex =
                      parent.get(CoreAnnotations.IndexAnnotation.class);
        
                    deps.put(childIndex, parentIndex);
                  }
                  boolean foundRoot = false;
                  int index = 1;
                  for (Tree node : indexedTree.getLeaves()) {
                    String word = node.label().value();
                    String tag = node.parent(indexedTree).label().value();
                    int parent = 0;
                    if (deps.containsKey(index)) {
                      parent = deps.get(index);
                    } else {
                      if (foundRoot) { throw new RuntimeException(); }
                      foundRoot = true;
                    }
                    pw.println(index+"\t"+word+"\t"+tag+"\t"+parent);
                    index++;
                  }
                  pw.println();
                }
              }
              if (formats.containsKey("typedDependencies")) {
                GrammaticalStructure gs = gsf.newGrammaticalStructure(outputTree);
                if (basicDependencies) {
                  print(gs.typedDependencies(), pw);
                }
                if (nonCollapsedDependencies) {
                  print(gs.allTypedDependencies(), pw);
                }
                if (nonCollapsedDependenciesSeparated) {
                  print(gs.allTypedDependencies(), "separator", pw);
                }
                if (collapsedDependencies) {
                  print(gs.typedDependenciesCollapsed(true), pw);
                }
                if (CCPropagatedDependencies) {
                  print(gs.typedDependenciesCCprocessed(true), pw);
                }
                if (treeDependencies) {
                  print(gs.typedDependenciesCollapsedTree(), pw);
                }
              }
              if (formats.containsKey("typedDependenciesCollapsed")) {
                GrammaticalStructure gs = gsf.newGrammaticalStructure(outputTree);
                print(gs.typedDependenciesCCprocessed(true), pw);
              }
              
              
              
              
              
            }

            
            pw.flush();
          }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    
    static class Trees { static Tree lexicalize(Tree t, HeadFinder hf) { return t; } }
    static class TreeFunctions {
        static Function<Tree,Tree> getLabeledToDescriptiveCoreLabelTreeFunction() { return t -> t; }
        static Function<Tree,Tree> getLabeledTreeToStringLabeledTreeFunction() { return t -> t; }
    }
    interface Function<T,R> { R apply(T t); }
    interface TreeTransformer { Tree transformTree(Tree t); }
    static class ChineseEnglishWordMap { static ChineseEnglishWordMap getInstance() { return new ChineseEnglishWordMap(); } String getFirstTranslation(String w) { return null; } }
    static class CoreMap {
        Map<Class, Integer> map = new HashMap<>();
        Integer get(Class c) { return map.get(c); }
        void set(Class c, Integer v) { map.put(c,v); }
    }
    static class CoreAnnotations { static class IndexAnnotation {} }
    static class TreebankLanguagePack { boolean isStartSymbol(String s) { return s.equals("ROOT"); } }

    public static void main(String[] args) {
        System.out.println("=== TreePrint.printTreeInternal test ===");
        TreePrint printer = new TreePrint();
        printer.formats.put("words", true);
        printer.ptb2text = false;
        
        Tree john = new Tree(new StringLabel("John"));
        Tree np1 = new Tree(new StringLabel("NP"), john);
        Tree mary = new Tree(new StringLabel("Mary"));
        Tree np2 = new Tree(new StringLabel("NP"), mary);
        Tree loves = new Tree(new StringLabel("loves"));
        Tree vp = new Tree(new StringLabel("VP"), loves, np2);
        Tree s = new Tree(new StringLabel("S"), np1, vp);
        Tree root = new Tree(new StringLabel("ROOT"), s);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        printer.printTreeInternal(root, pw, false);
        pw.flush();
        System.out.println("Output:");
        System.out.print(sw.toString());
        System.out.println("=== Done. ===");
    }
}