import java.util.*;



class Geometry {
    private String type;
    private double area = 100.0;
    public Geometry(String type) { this.type = type; }
    public Geometry buffer(double distance) { return this; } 
    public double getArea() { return area; }
    public Geometry intersection(Geometry other) {
        return new Geometry("Polygon"); 
    }
    @Override public String toString() { return type; }
}

class Crs {
    private String code;
    public Crs(String code) { this.code = code; }
    public String getCode() { return code; }
}

class Filter {}

interface FilterCreator {
    Filter createIntersectsFilter(Geometry geom, String geomName);
    Filter createContainsFilter(Geometry geom, String geomName);
    Filter createTouchesFilter(Geometry geom, String geomName);
    Filter createWithinFilter(Geometry geom, String geomName);
    Filter parseFilter(String filterString);
    Filter createAndFilter(Filter f1, Filter f2);
}

class InternalFeature {
    private Geometry geometry;
    private String id;
    public InternalFeature(String id, Geometry geom) { this.id = id; this.geometry = geom; }
    public Geometry getGeometry() { return geometry; }
    public String getId() { return id; }
}

class Feature {
    private String id;
    private String crs;
    public Feature(String id) { this.id = id; }
    public void setCrs(String crs) { this.crs = crs; }
    @Override public String toString() { return id; }
}

interface DtoConverter {
    Geometry toInternal(Object location);
    Feature toDto(InternalFeature feature);
}

interface GeoService {
    Crs getCrs2(String code);
    Geometry transform(Geometry geometry, Crs source, Crs target);
}

interface LayerService {
    Crs getCrs(Object layer);
    List<InternalFeature> getFeatures(String serverLayerId, Crs crs, Filter filter, Object style, Object includes);
}

interface ConfigurationService {
    VectorLayer getVectorLayer(String serverLayerId);
}

class VectorLayer {
    private LayerInfo layerInfo = new LayerInfo();
    public LayerInfo getLayerInfo() { return layerInfo; }
}
class LayerInfo {
    private FeatureInfo featureInfo = new FeatureInfo();
    public FeatureInfo getFeatureInfo() { return featureInfo; }
}
class FeatureInfo {
    private GeometryType geometryType = new GeometryType();
    public GeometryType getGeometryType() { return geometryType; }
}
class GeometryType {
    private String name = "MultiPolygon";
    public String getName() { return name; }
}

class GeomajasException extends Exception {
    public GeomajasException(String msg) { super(msg); }
    public GeomajasException(Throwable cause, int code) { super(cause); }
    public GeomajasException(int code, String param) { super("Missing parameter: " + param); }
}

class ExceptionCode {
    public static final int PARAMETER_MISSING = 1;
    public static final int RENDER_DIMENSION_MISMATCH = 2;
}

class SearchByLocationRequest {
    public static final int QUERY_INTERSECTS = 0;
    public static final int QUERY_CONTAINS = 1;
    public static final int QUERY_TOUCHES = 2;
    public static final int QUERY_WITHIN = 3;
    public static final int SEARCH_FIRST_LAYER = 1;

    private String[] layerIds;
    private String crs;
    private Object location;
    private int queryType;
    private double ratio;
    private int searchType;
    private double buffer;
    private Map<String, String> serverLayerIdMap = new HashMap<>();
    private Map<String, String> layerFilters = new HashMap<>();
    private String globalFilter;
    private Object featureIncludes;

    public String[] getLayerIds() { return layerIds; }
    public String getCrs() { return crs; }
    public Object getLocation() { return location; }
    public int getQueryType() { return queryType; }
    public double getRatio() { return ratio; }
    public int getSearchType() { return searchType; }
    public double getBuffer() { return buffer; }
    public String getServerLayerId(String clientId) { return serverLayerIdMap.get(clientId); }
    public String getFilter(String clientId) { return layerFilters.get(clientId); }
    public String getFilter() { return globalFilter; }
    public Object getFeatureIncludes() { return featureIncludes; }

    
    public void setLayerIds(String[] ids) { this.layerIds = ids; }
    public void setCrs(String crs) { this.crs = crs; }
    public void setLocation(Object loc) { this.location = loc; }
    public void setQueryType(int qt) { this.queryType = qt; }
    public void setRatio(double r) { this.ratio = r; }
    public void setSearchType(int st) { this.searchType = st; }
    public void setBuffer(double b) { this.buffer = b; }
    public void setServerLayerIdMapping(String clientId, String serverId) { serverLayerIdMap.put(clientId, serverId); }
    public void setLayerFilter(String clientId, String filter) { layerFilters.put(clientId, filter); }
    public void setGlobalFilter(String filter) { this.globalFilter = filter; }
    public void setFeatureIncludes(Object includes) { this.featureIncludes = includes; }
}

class SearchByLocationResponse {
    private Map<String, List<Feature>> layers = new HashMap<>();
    public void addLayer(String clientLayerId, List<Feature> features) { layers.put(clientLayerId, features); }
    public Map<String, List<Feature>> getLayerFeatures() { return layers; }
}

interface SecurityContext {
    boolean isLayerVisible(String layerId);
    boolean isLayerCreateAuthorized(String layerId);
    boolean isLayerUpdateAuthorized(String layerId);
    boolean isLayerDeleteAuthorized(String layerId);
    boolean isAttributeReadable(String layerId, String attributePath, String attributeName);
}

interface SearchByLocationCommandContract {
    void execute(SearchByLocationRequest request, SearchByLocationResponse response) throws Exception;
}

class SimpleLogger {
    void debug(String message) { System.out.println("[DEBUG] " + message); }
    void trace(String message) { System.out.println("[TRACE] " + message); }
}


public class method_3_geomajas_deepseek implements SearchByLocationCommandContract {
    private SecurityContext securityContext;
    private DtoConverter converter;
    private GeoService geoService;
    private FilterCreator filterCreator;
    private LayerService layerService;
    private ConfigurationService configurationService;

    private static final SimpleLogger log = new SimpleLogger();

    public method_3_geomajas_deepseek(SecurityContext sc, DtoConverter cv, GeoService gs, FilterCreator fc,
                                  LayerService ls, ConfigurationService cs) {
        this.securityContext = sc;
        this.converter = cv;
        this.geoService = gs;
        this.filterCreator = fc;
        this.layerService = ls;
        this.configurationService = cs;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Override
    public void execute(SearchByLocationRequest request, SearchByLocationResponse response) throws Exception {
        if (null == request.getLayerIds()) {
            throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, "layerIds");
        }
        String crsCode = request.getCrs();
        if (null == crsCode) {
            throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, "crs");
        }
        Geometry location = converter.toInternal(request.getLocation());
        int queryType = request.getQueryType();
        double ratio = request.getRatio();
        int searchType = request.getSearchType();
        Crs crs = geoService.getCrs2(request.getCrs());

        
        Geometry geometry = location;
        if (request.getBuffer() > 0) {
            geometry = location.buffer(request.getBuffer());
        }
        log.debug("search by location " + geometry);

        for (String clientLayerId : request.getLayerIds()) {
            String serverLayerId = request.getServerLayerId(clientLayerId);
            if (null == serverLayerId) {
                throw new GeomajasException(ExceptionCode.PARAMETER_MISSING, 
                                "serverLayerId for clientLayerId " + clientLayerId);
            }
            if (securityContext.isLayerVisible(serverLayerId)) {
                VectorLayer vectorLayer = configurationService.getVectorLayer(serverLayerId);
                if (vectorLayer != null) {
                    String geomName = vectorLayer.getLayerInfo().getFeatureInfo().getGeometryType().getName();

                    
                    Geometry layerGeometry = geoService.transform(geometry, crs, layerService.getCrs(vectorLayer));
                    log.trace("on layer " + serverLayerId + " use " + layerGeometry);

                    
                    Filter f = null;
                    switch (queryType) {
                        case SearchByLocationRequest.QUERY_INTERSECTS:
                            f = filterCreator.createIntersectsFilter(layerGeometry, geomName);
                            break;
                        case SearchByLocationRequest.QUERY_CONTAINS:
                            f = filterCreator.createContainsFilter(layerGeometry, geomName);
                            break;
                        case SearchByLocationRequest.QUERY_TOUCHES:
                            f = filterCreator.createTouchesFilter(layerGeometry, geomName);
                            break;
                        case SearchByLocationRequest.QUERY_WITHIN:
                            f = filterCreator.createWithinFilter(layerGeometry, geomName);
                            break;
                        default:
                            throw new IllegalArgumentException("Unknown query type " + queryType);
                    }
                    
                    if (null != request.getFilter(clientLayerId)) {
                        if (null == f) {
                            f = filterCreator.parseFilter(request.getFilter(clientLayerId));
                        } else {
                            f = filterCreator.createAndFilter(
                                    filterCreator.parseFilter(request.getFilter(clientLayerId)), f);
                        }
                    }
                    
                    if (null != request.getFilter()) {
                        if (null == f) {
                            f = filterCreator.parseFilter(request.getFilter());
                        } else {
                            f = filterCreator.createAndFilter(filterCreator.parseFilter(request.getFilter()), f);
                        }
                    }

                    
                    List<InternalFeature> temp = layerService.getFeatures(serverLayerId, crs, f, null, request
                            .getFeatureIncludes());
                    if (temp.size() > 0) {
                        List<Feature> features = new ArrayList<Feature>();

                        
                        if (queryType == SearchByLocationRequest.QUERY_INTERSECTS && ratio >= 0 && ratio < 1) {
                            for (InternalFeature feature : temp) {
                                double minimalOverlap = feature.getGeometry().getArea() * ratio;
                                Geometry overlap = geometry.intersection(feature.getGeometry());
                                double effectiveOverlap = overlap.getArea();
                                if (minimalOverlap <= effectiveOverlap) {
                                    log.trace("found " + feature);
                                    Feature dto = converter.toDto(feature);
                                    dto.setCrs(crsCode);
                                    features.add(dto);
                                }
                            }
                        } else {
                            for (InternalFeature feature : temp) {
                                log.trace("found " + feature);
                                Feature dto = converter.toDto(feature);
                                dto.setCrs(crsCode);
                                features.add(dto);
                            }
                        }

                        
                        if (features.size() > 0) {
                            
                            response.addLayer(clientLayerId, features);

                            
                            if (searchType == SearchByLocationRequest.SEARCH_FIRST_LAYER) {
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        
        SecurityContext sc = new SecurityContext() {
            public boolean isLayerVisible(String id) { return true; }
            public boolean isLayerCreateAuthorized(String id) { return true; }
            public boolean isLayerUpdateAuthorized(String id) { return true; }
            public boolean isLayerDeleteAuthorized(String id) { return true; }
            public boolean isAttributeReadable(String layerId, String path, String name) { return true; }
        };
        DtoConverter conv = new DtoConverter() {
            public Geometry toInternal(Object loc) { return new Geometry("Point"); }
            public Feature toDto(InternalFeature f) { return new Feature(f.getId()); }
        };
        GeoService gs = new GeoService() {
            public Crs getCrs2(String code) { return new Crs(code); }
            public Geometry transform(Geometry geom, Crs from, Crs to) { return geom; } 
        };
        FilterCreator fc = new FilterCreator() {
            public Filter createIntersectsFilter(Geometry g, String n) { return new Filter(); }
            public Filter createContainsFilter(Geometry g, String n) { return new Filter(); }
            public Filter createTouchesFilter(Geometry g, String n) { return new Filter(); }
            public Filter createWithinFilter(Geometry g, String n) { return new Filter(); }
            public Filter parseFilter(String s) { return new Filter(); }
            public Filter createAndFilter(Filter f1, Filter f2) { return new Filter(); }
        };
        LayerService ls = new LayerService() {
            public Crs getCrs(Object layer) { return new Crs("EPSG:4326"); }
            public List<InternalFeature> getFeatures(String id, Crs crs, Filter f, Object style, Object inc) {
                return Arrays.asList(
                    new InternalFeature("feat1", new Geometry("Polygon")),
                    new InternalFeature("feat2", new Geometry("Polygon"))
                );
            }
        };
        ConfigurationService cs = new ConfigurationService() {
            public VectorLayer getVectorLayer(String id) { return new VectorLayer(); }
        };

        method_3_geomajas_deepseek cmd = new method_3_geomajas_deepseek(sc, conv, gs, fc, ls, cs);

        SearchByLocationRequest req = new SearchByLocationRequest();
        req.setLayerIds(new String[] {"parcels_client"});
        req.setCrs("EPSG:4326");
        req.setLocation("POINT(1 2)");
        req.setQueryType(SearchByLocationRequest.QUERY_INTERSECTS);
        req.setRatio(0.5);
        req.setSearchType(0); 
        req.setBuffer(0);
        req.setServerLayerIdMapping("parcels_client", "parcels");
        req.setFeatureIncludes(null);

        SearchByLocationResponse resp = new SearchByLocationResponse();
        cmd.execute(req, resp);
        System.out.println("Response layers: " + resp.getLayerFeatures().size());
        for (Map.Entry<String, List<Feature>> e : resp.getLayerFeatures().entrySet()) {
            System.out.println("Layer " + e.getKey() + " has " + e.getValue().size() + " features.");
        }
    }
}