import java.util.*;


interface ClientWidgetInfo {}
interface ServerSideOnlyInfo extends ClientWidgetInfo {}

public class method_1_geomajas_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public Map<String, ClientWidgetInfo> securityClone(Map<String, ClientWidgetInfo> widgetInfo) {
        Map<String, ClientWidgetInfo> res = new HashMap<String, ClientWidgetInfo>();
        for (Map.Entry<String, ClientWidgetInfo> entry : widgetInfo.entrySet()) {
            ClientWidgetInfo value = entry.getValue();
            if (!(value instanceof ServerSideOnlyInfo)) {
                res.put(entry.getKey(), value);
            }
        }
        return res;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        method_1_geomajas_deepseek cmd = new method_1_geomajas_deepseek();
        Map<String, ClientWidgetInfo> input = new HashMap<>();
        input.put("w1", new ClientWidgetInfo() {});
        input.put("w2", new ServerSideOnlyInfo() {});
        input.put("w3", new ClientWidgetInfo() {});
        Map<String, ClientWidgetInfo> result = cmd.securityClone(input);
        System.out.println("Original size: " + input.size() + ", Filtered size: " + result.size());
        for (String key : result.keySet()) {
            System.out.println(" - " + key);
        }
    }
}