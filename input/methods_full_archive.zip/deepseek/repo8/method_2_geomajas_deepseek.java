import java.util.*;


interface ClientWidgetInfo {}
interface ServerSideOnlyInfo extends ClientWidgetInfo {}

class SerializationUtils {
    @SuppressWarnings("unchecked")
    public static <T> T clone(T object) {
        
        return object;
    }
}

interface SecurityContext {
    boolean isLayerVisible(String layerId);
    boolean isLayerCreateAuthorized(String layerId);
    boolean isLayerUpdateAuthorized(String layerId);
    boolean isLayerDeleteAuthorized(String layerId);
    boolean isAttributeReadable(String layerId, String attributePath, String attributeName);
}

class LayerInfo {
    private Map<String, Object> extraInfo = new HashMap<>();
    public Map<String, Object> getExtraInfo() { return extraInfo; }
    public void setExtraInfo(Map<String, Object> extraInfo) { this.extraInfo = extraInfo; }
}

class AttributeInfo {
    private String name;
    public AttributeInfo(String name) { this.name = name; }
    public String getName() { return name; }
}

class FeatureInfo {
    private List<AttributeInfo> attributes = new ArrayList<>();
    public List<AttributeInfo> getAttributes() { return attributes; }
    public void setAttributes(List<AttributeInfo> attributes) { this.attributes = attributes; }
}

class ClientLayerInfo {
    protected String serverLayerId;
    protected Map<String, ClientWidgetInfo> widgetInfo = new HashMap<>();
    protected LayerInfo layerInfo = new LayerInfo();

    public String getServerLayerId() { return serverLayerId; }
    public void setServerLayerId(String id) { this.serverLayerId = id; }
    public Map<String, ClientWidgetInfo> getWidgetInfo() { return widgetInfo; }
    public void setWidgetInfo(Map<String, ClientWidgetInfo> info) { this.widgetInfo = info; }
    public LayerInfo getLayerInfo() { return layerInfo; }
}

class ClientVectorLayerInfo extends ClientLayerInfo {
    private FeatureInfo featureInfo = new FeatureInfo();
    private boolean creatable, updatable, deletable;

    public FeatureInfo getFeatureInfo() { return featureInfo; }
    public void setCreatable(boolean b) { this.creatable = b; }
    public void setUpdatable(boolean b) { this.updatable = b; }
    public void setDeletable(boolean b) { this.deletable = b; }
}


public class method_2_geomajas_deepseek {
    private SecurityContext securityContext;

    public method_2_geomajas_deepseek(SecurityContext ctx) { this.securityContext = ctx; }

    
    public Map<String, ClientWidgetInfo> securityClone(Map<String, ClientWidgetInfo> widgetInfo) {
        Map<String, ClientWidgetInfo> res = new HashMap<>();
        for (Map.Entry<String, ClientWidgetInfo> entry : widgetInfo.entrySet()) {
            ClientWidgetInfo value = entry.getValue();
            if (!(value instanceof ServerSideOnlyInfo)) {
                res.put(entry.getKey(), value);
            }
        }
        return res;
    }

    
    private Map<String, Object> securityCloneLayerExtraInfo(Map<String, Object> extraInfo) {
        return new HashMap<>(extraInfo); 
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public ClientLayerInfo securityClone(ClientLayerInfo original) {
        
        if (null == original) {
            return null;
        }
        ClientLayerInfo client = null;
        String layerId = original.getServerLayerId();
        if (securityContext.isLayerVisible(layerId)) {
            client = (ClientLayerInfo) SerializationUtils.clone(original);
            client.setWidgetInfo(securityClone(original.getWidgetInfo()));
            client.getLayerInfo().setExtraInfo(securityCloneLayerExtraInfo(original.getLayerInfo().getExtraInfo()));
            if (client instanceof ClientVectorLayerInfo) {
                ClientVectorLayerInfo vectorLayer = (ClientVectorLayerInfo) client;
                
                vectorLayer.setCreatable(securityContext.isLayerCreateAuthorized(layerId));
                vectorLayer.setUpdatable(securityContext.isLayerUpdateAuthorized(layerId));
                vectorLayer.setDeletable(securityContext.isLayerDeleteAuthorized(layerId));
                
                FeatureInfo featureInfo = vectorLayer.getFeatureInfo();
                List<AttributeInfo> originalAttr = featureInfo.getAttributes();
                List<AttributeInfo> filteredAttr = new ArrayList<AttributeInfo>();
                featureInfo.setAttributes(filteredAttr);
                for (AttributeInfo ai : originalAttr) {
                    if (securityContext.isAttributeReadable(layerId, null, ai.getName())) {
                        filteredAttr.add(ai);
                    }
                }
            }
        }
        return client;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        
        SecurityContext ctx = new SecurityContext() {
            public boolean isLayerVisible(String id) { return true; }
            public boolean isLayerCreateAuthorized(String id) { return true; }
            public boolean isLayerUpdateAuthorized(String id) { return true; }
            public boolean isLayerDeleteAuthorized(String id) { return true; }
            public boolean isAttributeReadable(String layerId, String path, String name) {
                return !"secret".equals(name);
            }
        };
        method_2_geomajas_deepseek cmd = new method_2_geomajas_deepseek(ctx);

        
        ClientVectorLayerInfo original = new ClientVectorLayerInfo();
        original.setServerLayerId("parcels");
        original.getWidgetInfo().put("legend", new ClientWidgetInfo() {});
        original.getWidgetInfo().put("private", new ServerSideOnlyInfo() {});
        original.getLayerInfo().getExtraInfo().put("key", "value");
        FeatureInfo fi = original.getFeatureInfo();
        fi.setAttributes(new ArrayList<>(Arrays.asList(
                new AttributeInfo("id"),
                new AttributeInfo("name"),
                new AttributeInfo("secret")
        )));

        ClientLayerInfo cloned = cmd.securityClone(original);
        if (cloned != null) {
            System.out.println("Cloned layer: " + cloned.getServerLayerId());
            System.out.println("Widget count: " + cloned.getWidgetInfo().size()); 
            System.out.println("Attributes: " + (cloned instanceof ClientVectorLayerInfo ?
                    ((ClientVectorLayerInfo)cloned).getFeatureInfo().getAttributes().size() : 0));
            System.out.println("Create/Update/Delete: true");
        } else {
            System.out.println("Layer not visible.");
        }
    }
}