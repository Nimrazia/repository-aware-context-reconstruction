
import java.util.*;






class Logger {
    public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
    public void debug(String msg, Object... args) { System.out.println("[DEBUG] " + format(msg, args)); }
    public void error(String msg) { System.err.println("[ERROR] " + msg); }
    public void error(String msg, Object... args) { System.err.println("[ERROR] " + format(msg, args)); }
    public void trace(String msg) { System.out.println("[TRACE] " + msg); }
    private String format(String msg, Object... args) { for (Object arg : args) msg = msg.replaceFirst("\\{\\}", java.util.regex.Matcher.quoteReplacement(String.valueOf(arg))); return msg; }
}


class SerialMessage {
    private byte[] payload;
    public SerialMessage(byte[] payload) { this.payload = payload; }
    public byte[] getMessagePayload() { return payload; }
    public int getMessagePayloadByte(int offset) { return payload[offset] & 0xFF; }
}


class ZWaveCommandClass {
    public enum CommandClass { BASIC, MULTI_INSTANCE, SWITCH_BINARY }
    private CommandClass commandClass;
    private int version = 1;
    private ZWaveNode node;
    private ZWaveController controller;
    private ZWaveEndpoint endpoint;

    public ZWaveCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        this.node = node; this.controller = controller; this.endpoint = endpoint;
    }
    public ZWaveCommandClass(ZWaveNode node, ZWaveController controller) {
        this(node, controller, null);
    }
    public CommandClass getCommandClass() { return commandClass; }
    public void setCommandClass(CommandClass cc) { this.commandClass = cc; }
    public int getVersion() { return version; }
    public void setVersion(int v) { version = v; }
    public ZWaveNode getNode() { return node; }
    public ZWaveController getController() { return controller; }
    public ZWaveEndpoint getEndpoint() { return endpoint; }
    public static ZWaveCommandClass getInstance(int data, ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        
        if (data == 0x20) return new ZWaveCommandClass(node, controller, endpoint);
        return null;
    }
}


class ZWaveBasicCommandClass extends ZWaveCommandClass {
    public ZWaveBasicCommandClass(ZWaveNode node, ZWaveController controller, ZWaveEndpoint endpoint) {
        super(node, controller, endpoint);
        setCommandClass(CommandClass.BASIC);
    }
}


class ZWaveNode {
    private int nodeId;
    private ZWaveDeviceClass deviceClass = new ZWaveDeviceClass();
    private Map<ZWaveCommandClass.CommandClass, ZWaveCommandClass> supported = new HashMap<>();
    public ZWaveNode(int id) { nodeId = id; }
    public int getNodeId() { return nodeId; }
    public ZWaveDeviceClass getDeviceClass() { return deviceClass; }
    public boolean supportsCommandClass(ZWaveCommandClass.CommandClass cc) {
        return supported.containsKey(cc);
    }
    public ZWaveCommandClass getCommandClass(ZWaveCommandClass.CommandClass cc) {
        return supported.get(cc);
    }
    public void addCommandClass(ZWaveCommandClass cc) {
        supported.put(cc.getCommandClass(), cc);
    }
    public void advanceNodeStage() {
        System.out.println("[ZWaveNode] Advancing node stage.");
    }
}


class ZWaveController {
    
}


class ZWaveDeviceClass {
    public enum Basic {
        NOT_KNOWN(0, "NOT_KNOWN"), BASIC(1, "BASIC");
        private final int key; private final String label;
        Basic(int key, String label) { this.key = key; this.label = label; }
        public int getKey() { return key; } public String getLabel() { return label; }
    }
    public enum Generic {
        NOT_KNOWN(0, "NOT_KNOWN"), GENERIC(2, "GENERIC");
        private final int key; private final String label;
        Generic(int key, String label) { this.key = key; this.label = label; }
        public int getKey() { return key; } public String getLabel() { return label; }
        public static Generic getGeneric(int key) { for (Generic g : values()) if (g.key == key) return g; return GENERIC; }
    }
    public enum Specific {
        NOT_KNOWN(0, "NOT_KNOWN"), SPECIFIC(3, "SPECIFIC");
        private final int key; private final String label;
        Specific(int key, String label) { this.key = key; this.label = label; }
        public int getKey() { return key; } public String getLabel() { return label; }
        public static Specific getSpecific(Generic generic, int key) { for (Specific s : values()) if (s.key == key) return s; return SPECIFIC; }
    }
    private Basic basic = Basic.NOT_KNOWN;
    private Generic generic = Generic.NOT_KNOWN;
    private Specific specific = Specific.NOT_KNOWN;
    public void setBasicDeviceClass(Basic b) { basic = b; }
    public void setGenericDeviceClass(Generic g) { generic = g; }
    public void setSpecificDeviceClass(Specific s) { specific = s; }
    public Basic getBasicDeviceClass() { return basic; }
    public Generic getGenericDeviceClass() { return generic; }
    public Specific getSpecificDeviceClass() { return specific; }
}


class ZWaveEndpoint {
    private int endpointId;
    private ZWaveNode node;
    private ZWaveController controller;
    private ZWaveDeviceClass deviceClass = new ZWaveDeviceClass();
    private List<ZWaveCommandClass> commandClasses = new ArrayList<>();
    public ZWaveEndpoint(int id, ZWaveNode node, ZWaveController controller) {
        this.endpointId = id; this.node = node; this.controller = controller;
    }
    public int getEndpointId() { return endpointId; }
    public ZWaveDeviceClass getDeviceClass() { return deviceClass; }
    public void addCommandClass(ZWaveCommandClass cc) { commandClasses.add(cc); }
    public List<ZWaveCommandClass> getCommandClasses() { return commandClasses; }
    public ZWaveNode getNode() { return node; }
}





class ZWaveMultiInstanceCommandClass extends ZWaveCommandClass {
    private Logger logger = new Logger();
    private boolean endpointsAreTheSameDeviceClass = false;
    private Map<Integer, ZWaveEndpoint> endpoints = new HashMap<>();
    private ZWaveNode node;
    private ZWaveController controller;

    public ZWaveMultiInstanceCommandClass(ZWaveNode node, ZWaveController controller) {
        super(node, controller);
        this.node = node;
        this.controller = controller;
        setCommandClass(CommandClass.MULTI_INSTANCE);
        
        ZWaveEndpoint ep = new ZWaveEndpoint(1, node, controller);
        endpoints.put(1, ep);
    }

    public ZWaveNode getNode() { return node; }
    public Map<Integer, ZWaveEndpoint> getEndpoints() { return endpoints; }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private void handleMultiChannelCapabilityReportResponse(SerialMessage serialMessage, int offset) {
        logger.debug("Process Multi-channel capability Report");
        int receivedEndpointId = serialMessage.getMessagePayloadByte(offset) & 0x7F;
        boolean dynamic = ((serialMessage.getMessagePayloadByte(offset) & 0x80) != 0);
        int genericDeviceClass = serialMessage.getMessagePayloadByte(offset + 1);
        int specificDeviceClass = serialMessage.getMessagePayloadByte(offset + 2);

        logger.debug("Endpoints are the same device class = {}", endpointsAreTheSameDeviceClass ? "true" : false);

        
        
        int startId = this.endpointsAreTheSameDeviceClass ? 1 : receivedEndpointId;
        int endId = this.endpointsAreTheSameDeviceClass ? this.endpoints.size() : receivedEndpointId;

        boolean supportsBasicCommandClass = this.getNode().supportsCommandClass(ZWaveCommandClass.CommandClass.BASIC);

        for (int endpointId = startId; endpointId <= endId; endpointId++) {
            ZWaveEndpoint endpoint = this.endpoints.get(endpointId);

            if (endpoint == null){
                logger.error("Endpoint {} not found on node {}. Cannot set command classes.", endpoint, this.getNode().getNodeId());
                continue;
            }

            ZWaveDeviceClass.Basic basic = this.getNode().getDeviceClass().getBasicDeviceClass();
            ZWaveDeviceClass.Generic generic = ZWaveDeviceClass.Generic.getGeneric(genericDeviceClass);
            if (generic == null) {
                logger.error(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.",
                        endpoint, genericDeviceClass, specificDeviceClass));
                continue;
            }
            ZWaveDeviceClass.Specific specific = ZWaveDeviceClass.Specific.getSpecific(generic, specificDeviceClass);
            if (specific == null) {
                logger.error(String.format("Endpoint %d has invalid device class. generic = 0x%02x, specific = 0x%02x.",
                        endpoint, genericDeviceClass, specificDeviceClass));
                continue;
            }

            logger.debug("Endpoint Id = {}", endpointId);
            logger.debug("Endpoints is dynamic = {}", dynamic ? "true" : false);
            logger.debug(String.format("Basic = %s 0x%02x", basic.getLabel(), basic.getKey()));
            logger.debug(String.format("Generic = %s 0x%02x", generic.getLabel(), generic.getKey()));
            logger.debug(String.format("Specific = %s 0x%02x", specific.getLabel(), specific.getKey()));

            ZWaveDeviceClass deviceClass = endpoint.getDeviceClass();
            deviceClass.setBasicDeviceClass(basic);
            deviceClass.setGenericDeviceClass(generic);
            deviceClass.setSpecificDeviceClass(specific);

            
            if (supportsBasicCommandClass) {
                ZWaveCommandClass commandClass = new ZWaveBasicCommandClass(this.getNode(), this.controller, endpoint);
                endpoint.addCommandClass(commandClass);
            }

            for (int i = 0; i < serialMessage.getMessagePayload().length - offset - 3; i++) {
                int data = serialMessage.getMessagePayloadByte(offset + 3 + i);
                if(data == 0xef )  {
                    
                    break;
                }
                logger.debug(String.format("Adding command class 0x%02X to the list of supported command classes.", data));
                ZWaveCommandClass commandClass = ZWaveCommandClass.getInstance(data, this.getNode(), this.controller, endpoint);
                if (commandClass == null) {
                    continue;
                }

                endpoint.addCommandClass(commandClass);
                ZWaveCommandClass parentClass = this.getNode().getCommandClass(commandClass.getCommandClass());

                
                if (parentClass != null) {
                    commandClass.setVersion(parentClass.getVersion());
                }
            }
        }

        if (this.endpointsAreTheSameDeviceClass)
            
            this.getNode().advanceNodeStage();
        else {
            for (ZWaveEndpoint ep : this.endpoints.values())
            {
                if (ep.getDeviceClass().getBasicDeviceClass() == ZWaveDeviceClass.Basic.NOT_KNOWN) 
                    return;
            }
            
            this.getNode().advanceNodeStage();
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}


class ZWaveDeviceClassExtensions {
    static {
        
        
        
    }
}






class ZWaveDeviceClassFinal {
    
    
}






public class method_3_fuchsia_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing ZWaveMultiInstanceCommandClass.handleMultiChannelCapabilityReportResponse ===\n");

        ZWaveNode node = new ZWaveNode(1);
        ZWaveController controller = new ZWaveController();
        ZWaveMultiInstanceCommandClass mi = new ZWaveMultiInstanceCommandClass(node, controller);

        
        byte[] payload = new byte[]{
                0x01, 
                0x02, 
                0x03, 
                0x20, 
                0x25, 
                (byte) 0xef  
        };
        SerialMessage msg = new SerialMessage(payload);
        try {
            java.lang.reflect.Method method = ZWaveMultiInstanceCommandClass.class
                    .getDeclaredMethod("handleMultiChannelCapabilityReportResponse", SerialMessage.class, int.class);
            method.setAccessible(true);
            method.invoke(mi, msg, 0);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        System.out.println("\n=== Test completed ===");
    }
}