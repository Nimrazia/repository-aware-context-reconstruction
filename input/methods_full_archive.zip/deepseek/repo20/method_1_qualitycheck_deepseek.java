import java.util.*;


class Check {
    public static <T> T notNull(T obj, String paramName) {
        if (obj == null) throw new IllegalArgumentException(paramName + " must not be null");
        return obj;
    }
    public static <T extends Collection<?>> T notEmpty(T col, String name) {
        if (col == null || col.isEmpty()) throw new IllegalArgumentException(name + " must not be empty");
        return col;
    }
    public static void stateIsTrue(boolean condition, String msg, Object... args) {
        if (!condition) throw new IllegalStateException(String.format(msg, args));
    }
    public static String notEmpty(String str, String name) {
        if (str == null || str.isEmpty()) throw new IllegalArgumentException(name + " must not be empty");
        return str;
    }
}


class SourceCodeReader {
    public static CompilationUnit parse(String code) {
        
        return new CompilationUnit();
    }
    public static Imports findImports(List<ImportDeclaration> importDecls) {
        return new Imports();
    }
    public static List<Annotation> findAnnotations(List<AnnotationExpr> annExprs, Imports imports) {
        return new ArrayList<>();
    }
    public static List<Method> findMethods(List<BodyDeclaration> members, Imports imports) {
        return new ArrayList<>();
    }
    public static List<Interface> findExtends(ClassOrInterfaceDeclaration type) {
        return new ArrayList<>();
    }
}


class CompilationUnit {
    public List<TypeDeclaration> getTypes() { return Arrays.asList(new ClassOrInterfaceDeclaration()); }
    public List<ImportDeclaration> getImports() { return new ArrayList<>(); }
    public PackageDeclaration getPackage() {
        return new PackageDeclaration() {
            @Override
            public Name getName() { return new Name() { @Override public String toString() { return "com.example"; } }; }
        };
    }
}
interface TypeDeclaration {}
class ClassOrInterfaceDeclaration implements TypeDeclaration {
    private String name = "MyInterface";
    private List<AnnotationExpr> annotations = new ArrayList<>();
    private List<BodyDeclaration> members = new ArrayList<>();
    public String getName() { return name; }
    public List<AnnotationExpr> getAnnotations() { return annotations; }
    public List<BodyDeclaration> getMembers() { return members; }
    
    public List<ClassOrInterfaceType> getExtends() { return new ArrayList<>(); }
}
interface ImportDeclaration {}
interface AnnotationExpr {}
interface BodyDeclaration {}
class ClassOrInterfaceType {}
interface PackageDeclaration { Name getName(); }
interface Name { String toString(); }
class ImportDeclarationImpl implements ImportDeclaration {}


class Imports {
    public List<String> asList() { return new ArrayList<>(); }
}
class Package {
    public static final Package UNDEFINED = new Package("undefined");
    private String name;
    public Package(String name) { this.name = name; }
    public String getName() { return name; }
}
interface Interface {}
class Annotation {}
class Method {}
interface InterfaceAnalysis {}
class ImmutableInterfaceAnalysis implements InterfaceAnalysis {
    private List<Annotation> annotations;
    private List<Interface> extendsInterfaces;
    private List<String> imports;
    private String interfaceName;
    private List<Method> methods;
    private Package pkg;
    public ImmutableInterfaceAnalysis(List<Annotation> annotations, List<Interface> extendsInterfaces,
                                      List<String> imports, String interfaceName, List<Method> methods, Package pkg) {
        this.annotations = annotations;
        this.extendsInterfaces = extendsInterfaces;
        this.imports = imports;
        this.interfaceName = interfaceName;
        this.methods = methods;
        this.pkg = pkg;
    }
    public String getInterfaceName() { return interfaceName; }
    
}


class InterfaceAnalyzerHelper {
    static boolean hasPossibleMutatingMethods(List<Method> methods) { return false; }
}


public class method_1_qualitycheck_deepseek {

    
    
    static class InterfaceAnalyzer {
        
        public static boolean hasPossibleMutatingMethods(List<Method> methods) {
            return InterfaceAnalyzerHelper.hasPossibleMutatingMethods(methods);
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
                public static InterfaceAnalysis analyze(final String code) {
            Check.notNull(code, "code");

            final CompilationUnit unit = Check.notNull(SourceCodeReader.parse(code), "compilationUnit");
            final List<TypeDeclaration> types = Check.notEmpty(unit.getTypes(), "typeDeclarations");
            Check.stateIsTrue(types.size() == 1, "only one interface declaration per analysis is supported");

            final ClassOrInterfaceDeclaration type = (ClassOrInterfaceDeclaration) types.get(0);

            final Imports imports = SourceCodeReader.findImports(unit.getImports());
            final Package pkg = unit.getPackage() != null ? new Package(unit.getPackage().getName().toString()) : Package.UNDEFINED;
            final List<Annotation> annotations = SourceCodeReader.findAnnotations(type.getAnnotations(), imports);
            final List<Method> methods = SourceCodeReader.findMethods(type.getMembers(), imports);
            Check.stateIsTrue(!hasPossibleMutatingMethods(methods), "The passed interface '%s' seems to have mutating methods", type.getName());
            final List<Interface> extendsInterfaces = SourceCodeReader.findExtends(type);
            final String interfaceName = type.getName();
            return new ImmutableInterfaceAnalysis(annotations, extendsInterfaces, imports.asList(), interfaceName, methods, pkg);
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    public static void main(String[] args) {
        String code = "public interface MyInterface {}";
        InterfaceAnalysis analysis = InterfaceAnalyzer.analyze(code);
        if (analysis instanceof ImmutableInterfaceAnalysis) {
            System.out.println("Interface name: " + ((ImmutableInterfaceAnalysis)analysis).getInterfaceName());
        } else {
            System.out.println("Analysis completed.");
        }
    }
}