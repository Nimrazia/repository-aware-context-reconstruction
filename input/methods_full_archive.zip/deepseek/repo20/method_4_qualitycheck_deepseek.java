import java.util.regex.Pattern;
import java.util.regex.Matcher;








final class Check {
    private Check() {} 

    public static <T> T notNull(final T obj, final String paramName) {
        if (obj == null) {
            throw new IllegalArgumentException(String.format("'%s' must not be null", paramName));
        }
        return obj;
    }

    public static String notEmpty(final String str, final String paramName) {
        if (str == null || str.isEmpty()) {
            throw new IllegalArgumentException(String.format("'%s' must not be empty", paramName));
        }
        return str;
    }

    public static void stateIsTrue(final boolean condition, final String message, final Object... args) {
        if (!condition) {
            throw new IllegalStateException(String.format(message, args));
        }
    }
}





enum AccessorPrefix {
    GET("get"),
    IS("is"),
    HAS("has");

    private final String prefix;

    AccessorPrefix(final String prefix) {
        this.prefix = prefix;
    }

    public String getPrefix() {
        return prefix;
    }
}






public final class method_4_qualitycheck_deepseek {

    
    static class MethodUtil {
        







        private static final Pattern PATTERN = Pattern.compile("^[a-zA-Z_$][a-zA-Z0-9_$]*$");

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public static String determineAccessorName(final AccessorPrefix prefix, final String fieldName) {
            Check.notNull(prefix, "prefix");
            Check.notEmpty(fieldName, "fieldName");
            final Matcher m = PATTERN.matcher(fieldName);
            Check.stateIsTrue(m.find(), "passed field name '%s' is not applicable", fieldName);
            final String name = m.group();
            return prefix.getPrefix() + name.substring(0, 1).toUpperCase() + name.substring(1);
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    




    public static void main(String[] args) {
        System.out.println("=== Testing MethodUtil.determineAccessorName ===\n");

        
        String result = MethodUtil.determineAccessorName(AccessorPrefix.GET, "myField");
        System.out.printf("GET + 'myField'  -> '%s'\n", result);   

        
        result = MethodUtil.determineAccessorName(AccessorPrefix.IS, "visible");
        System.out.printf("IS  + 'visible'  -> '%s'\n", result);   

        
        result = MethodUtil.determineAccessorName(AccessorPrefix.HAS, "children");
        System.out.printf("HAS + 'children' -> '%s'\n", result);   

        
        result = MethodUtil.determineAccessorName(AccessorPrefix.GET, "field_name");
        System.out.printf("GET + 'field_name' -> '%s'\n", result); 

        
        try {
            MethodUtil.determineAccessorName(AccessorPrefix.GET, "123abc");
        } catch (IllegalStateException e) {
            System.out.println("\nError (digit start): " + e.getMessage());
        }

        
        try {
            MethodUtil.determineAccessorName(AccessorPrefix.GET, "");
        } catch (IllegalArgumentException e) {
            System.out.println("Error (empty field): " + e.getMessage());
        }

        
        try {
            MethodUtil.determineAccessorName(AccessorPrefix.GET, null);
        } catch (IllegalArgumentException e) {
            System.out.println("Error (null field): " + e.getMessage());
        }

        
        try {
            MethodUtil.determineAccessorName(null, "field");
        } catch (IllegalArgumentException e) {
            System.out.println("Error (null prefix): " + e.getMessage());
        }

        System.out.println("\n=== All tests completed. ===");
    }
}