import java.math.BigDecimal;
import java.math.BigInteger;


class NumberInRange {
    static void checkByte(Number n) {}
    static void checkDouble(Number n) {}
    static void checkFloat(Number n) {}
    static void checkInteger(Number n) {}
    static void checkLong(Number n) {}
    static void checkShort(Number n) {}
}

class IllegalNumberArgumentException extends RuntimeException {
    public IllegalNumberArgumentException(String msg) { super(msg); }
}


public class method_3_qualitycheck_deepseek {

    
    
    

    
    static class Check {
        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private static <T> Number checkNumberInRange(final String value, final Class<T> type) {
            final Number ret;
            if (type.equals(Byte.class)) {
                final Number number = new BigInteger(value);
                NumberInRange.checkByte(number);
                ret = Byte.valueOf(number.byteValue());
            } else if (type.equals(Double.class)) {
                final Number number = new BigDecimal(value);
                NumberInRange.checkDouble(number);
                ret = Double.valueOf(number.doubleValue());
            } else if (type.equals(Float.class)) {
                final Number number = new BigDecimal(value);
                NumberInRange.checkFloat(number);
                ret = Float.valueOf(number.floatValue());
            } else if (type.equals(Integer.class)) {
                final Number number = new BigInteger(value);
                NumberInRange.checkInteger(number);
                ret = Integer.valueOf(number.intValue());
            } else if (type.equals(Long.class)) {
                final Number number = new BigInteger(value);
                NumberInRange.checkLong(number);
                ret = Long.valueOf(number.longValue());
            } else if (type.equals(Short.class)) {
                final Number number = new BigInteger(value);
                NumberInRange.checkShort(number);
                ret = Short.valueOf(number.shortValue());
            } else if (type.equals(BigInteger.class)) {
                ret = new BigInteger(value);
            } else if (type.equals(BigDecimal.class)) {
                ret = new BigDecimal(value);
            } else {
                throw new IllegalNumberArgumentException("Return value is no known subclass of 'java.lang.Number': " + type.getName());
            }
            return ret;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    public static void main(String[] args) throws Exception {
        
        java.lang.reflect.Method m = Check.class.getDeclaredMethod("checkNumberInRange", String.class, Class.class);
        m.setAccessible(true);
        Number result = (Number) m.invoke(null, "42", Integer.class);
        System.out.println("Result for Integer 42: " + result + " (type " + result.getClass().getName() + ")");

        result = (Number) m.invoke(null, "3.14", Double.class);
        System.out.println("Result for Double 3.14: " + result);

        result = (Number) m.invoke(null, "1000000000", BigInteger.class);
        System.out.println("Result for BigInteger: " + result);
    }
}