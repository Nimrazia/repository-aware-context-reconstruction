
import java.util.*;






class TableDescription {
    private List<LocalSecondaryIndexDescription> localSecondaryIndexes;
    private List<GlobalSecondaryIndexDescription> globalSecondaryIndexes;
    public void setLocalSecondaryIndexes(List<LocalSecondaryIndexDescription> ls) { localSecondaryIndexes = ls; }
    public void setGlobalSecondaryIndexes(List<GlobalSecondaryIndexDescription> gs) { globalSecondaryIndexes = gs; }
    public List<LocalSecondaryIndexDescription> getLocalSecondaryIndexes() { return localSecondaryIndexes; }
    public List<GlobalSecondaryIndexDescription> getGlobalSecondaryIndexes() { return globalSecondaryIndexes; }
}

class LocalSecondaryIndexDescription {
    private String indexName;
    private KeySchema keySchema;
    private Projection projection;
    public LocalSecondaryIndexDescription(String name, KeySchema schema, Projection proj) {
        indexName = name; keySchema = schema; projection = proj;
    }
    public String getIndexName() { return indexName; }
    public KeySchema getKeySchema() { return keySchema; }
    public Projection getProjection() { return projection; }
}

class GlobalSecondaryIndexDescription {
    private String indexName;
    private KeySchema keySchema;
    private Projection projection;
    public GlobalSecondaryIndexDescription(String name, KeySchema schema, Projection proj) {
        indexName = name; keySchema = schema; projection = proj;
    }
    public String getIndexName() { return indexName; }
    public KeySchema getKeySchema() { return keySchema; }
    public Projection getProjection() { return projection; }
}

class KeySchema {
    private List<KeySchemaElement> elements;
    public KeySchema(KeySchemaElement... elems) { elements = Arrays.asList(elems); }
    public List<KeySchemaElement> getElements() { return elements; }
}

class KeySchemaElement {
    private String attributeName;
    public KeySchemaElement(String attr) { attributeName = attr; }
    public String getAttributeName() { return attributeName; }
}

class Projection {
    private String projectionType;
    public Projection(String type) { projectionType = type; }
    public String getProjectionType() { return projectionType; }
}


class ProjectionExpressionBuilder {
    public boolean isCoveredBy(Projection proj) {
        
        return true;
    }
}

class IndexData {
    public List<String> keyFields;
    public boolean projectsOverEntity;
    public String indexName;
    public IndexData(String name, List<String> keys, boolean projects) {
        this.indexName = name; this.keyFields = keys; this.projectsOverEntity = projects;
    }
}


class Pair<F, S> {
    private F first; private S second;
    public Pair(F f, S s) { first = f; second = s; }
    public F getFirst() { return first; }
    public S getSecond() { return second; }
}





class DynamoDBQueryModelDAO {
    private String hashKeyField = "id";
    private String rangeKeyField = "timestamp";

    private Pair<String, String> getKeyAttributeNames(KeySchema keySchema) {
        List<KeySchemaElement> elements = keySchema.getElements();
        String first = elements.get(0).getAttributeName();
        String second = elements.size() > 1 ? elements.get(1).getAttributeName() : null;
        return new Pair<>(first, second);
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private Map<String, Map<String, IndexData>> processIndexes(TableDescription tableDescription,
                                                               ProjectionExpressionBuilder projectionExpressionBuilder,
                                                               IndexData baseIndexData) {
        
        Map<String, IndexData> localIndexes;
        List<LocalSecondaryIndexDescription> localSecondaryIndexes = tableDescription.getLocalSecondaryIndexes();
        if (localSecondaryIndexes != null) {
            localIndexes = new HashMap<>(localSecondaryIndexes.size() + 2);

            
            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);

            for (LocalSecondaryIndexDescription description : localSecondaryIndexes) {
                String indexField = getKeyAttributeNames(description.getKeySchema()).getSecond();
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>(baseIndexData.keyFields);
                keyFields.add(indexField);

                localIndexes.put(indexField, new IndexData(description.getIndexName(), keyFields, projectsOverEntity));
            }
        } else if (rangeKeyField != null) {
            localIndexes = new HashMap<>(2);

            localIndexes.put(rangeKeyField, baseIndexData);
            localIndexes.put(null, baseIndexData);
        } else {
            localIndexes = Collections.singletonMap(null, baseIndexData);
        }

        
        List<GlobalSecondaryIndexDescription> globalSecondaryIndexes = tableDescription.getGlobalSecondaryIndexes();
        if (globalSecondaryIndexes != null) {
            Map<String, Map<String, IndexData>> indexes = new HashMap<>(globalSecondaryIndexes.size() + 1);

            for (GlobalSecondaryIndexDescription description : globalSecondaryIndexes) {
                Pair<String, String> indexFields = getKeyAttributeNames(description.getKeySchema());
                boolean projectsOverEntity = description.getProjection().getProjectionType().equals("ALL")
                                             || projectionExpressionBuilder != null
                                                && projectionExpressionBuilder.isCoveredBy(description.getProjection());

                List<String> keyFields = new ArrayList<>();
                keyFields.add(indexFields.getFirst());
                if (indexFields.getSecond() != null) {
                    keyFields.add(indexFields.getSecond());
                }
                keyFields.add(hashKeyField);
                if (rangeKeyField != null) {
                    keyFields.add(rangeKeyField);
                }

                IndexData indexData = new IndexData(description.getIndexName(), keyFields, projectsOverEntity);

                if (!indexes.containsKey(indexFields.getFirst())) {
                    indexes.put(indexFields.getFirst(), new HashMap<String, IndexData>());
                }

                indexes.get(indexFields.getFirst()).put(indexFields.getSecond(), indexData);

                
                
                IndexData noRangeKeyIndexData = indexes.get(indexFields.getFirst()).get(null);
                if (noRangeKeyIndexData == null || !noRangeKeyIndexData.projectsOverEntity) {
                    indexes.get(indexFields.getFirst()).put(null, indexData);
                }
            }

            indexes.put(hashKeyField, localIndexes);

            return indexes;
        } else {
            return Collections.singletonMap(hashKeyField, localIndexes);
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_3_jeppetto_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing DynamoDBQueryModelDAO.processIndexes ===\n");

        
        TableDescription tableDesc = new TableDescription();

        
        KeySchema localSchema = new KeySchema(new KeySchemaElement("id"), new KeySchemaElement("timestamp"));
        Projection localProj = new Projection("ALL");
        LocalSecondaryIndexDescription lsi = new LocalSecondaryIndexDescription("localIndex", localSchema, localProj);
        tableDesc.setLocalSecondaryIndexes(Collections.singletonList(lsi));

        
        KeySchema globalSchema = new KeySchema(new KeySchemaElement("name"), new KeySchemaElement("id"));
        Projection globalProj = new Projection("KEYS_ONLY");
        GlobalSecondaryIndexDescription gsi = new GlobalSecondaryIndexDescription("globalIndex", globalSchema, globalProj);
        tableDesc.setGlobalSecondaryIndexes(Collections.singletonList(gsi));

        
        IndexData base = new IndexData("base", Arrays.asList("id"), true);

        DynamoDBQueryModelDAO dao = new DynamoDBQueryModelDAO();
        ProjectionExpressionBuilder builder = new ProjectionExpressionBuilder();

        Map<String, Map<String, IndexData>> result;
        try {
            java.lang.reflect.Method m = DynamoDBQueryModelDAO.class.getDeclaredMethod("processIndexes", TableDescription.class, ProjectionExpressionBuilder.class, IndexData.class);
            m.setAccessible(true);
            result = (Map<String, Map<String, IndexData>>) m.invoke(dao, tableDesc, builder, base);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        System.out.println("Indexes processed:");
        for (Map.Entry<String, Map<String, IndexData>> entry : result.entrySet()) {
            System.out.println("  Hash key: " + entry.getKey());
            for (Map.Entry<String, IndexData> inner : entry.getValue().entrySet()) {
                System.out.println("    Range key: " + inner.getKey() + " -> index: " + inner.getValue().indexName + ", projects: " + inner.getValue().projectsOverEntity);
            }
        }

        System.out.println("\n=== Test completed ===");
    }
}