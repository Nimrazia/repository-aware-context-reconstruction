
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;






interface DBObject {
    
}

class BasicDBObject implements DBObject {
    
}

class BasicDBList implements DBObject {
    
}


class Logger {
    public void warn(String msg) { System.out.println("[WARN] " + msg); }
    public void warn(String msg, Object... args) { System.out.println("[WARN] " + String.format(msg, args)); }
    public void info(String msg) { System.out.println("[INFO] " + msg); }
    public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
}


class EnhancerHelper {
    public static class Enhancer {
        private Class enhancedClass;
        public Enhancer(Class clazz) { enhancedClass = clazz; }
        public Class getEnhancedClass() { return enhancedClass; }
    }
    public static Enhancer getDirtyableDBObjectEnhancer(Class clazz) {
        
        return new Enhancer(clazz);
    }
}


class DBObjectUtil {
    public static boolean needsNoConversion(Class clazz) {
        
        return clazz == String.class || clazz == Integer.class || clazz == Boolean.class;
    }
}





class MongoDBCallback {
    private Logger logger = new Logger();
    private Class rootClass;
    private Map<String, Class> classCache = new ConcurrentHashMap<>();
    void registerCachedClass(String path, Class clazz) { classCache.put(path, clazz); }
    private static final List<String> EXPLAIN_PATHS_TO_IGNORE = Arrays.asList("_id", "__v");

    public MongoDBCallback(Class rootClass) {
        this.rootClass = rootClass;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private Class deriveClass1(String path, String lastPathPart, boolean array) {
        Class containerClass;

        if (path.equals(lastPathPart)) {
            containerClass = rootClass;
        } else {
            containerClass = classCache.get(rootClass.getSimpleName() + "." + path.substring(0, path.lastIndexOf('.')));
        }

        if (containerClass != null && DBObject.class.isAssignableFrom(containerClass)) {
            try {
                Method m = containerClass.getMethod("__getPreEnhancedClass");

                containerClass = (Class) m.invoke(null);
            } catch (Exception e) {
                logger.warn("DBObject without __getPreEnhancedClass() method.  Was the container class enhanced?");
            }
        }

        
        
        if (containerClass == null) {
            return array ? BasicDBList.class : BasicDBObject.class;
        }

        Method getter;

        try {
            
            getter = containerClass.getMethod("get" + Character.toUpperCase(lastPathPart.charAt(0)) + lastPathPart.substring(1));
        } catch (NoSuchMethodException e) {
            if (!EXPLAIN_PATHS_TO_IGNORE.contains(lastPathPart) && !lastPathPart.startsWith("__")) {
                logger.warn("No getter for: {} ({})", lastPathPart, e.getMessage());
            }

            return array ? BasicDBList.class : BasicDBObject.class;
        }

        Type returnType = getter.getGenericReturnType();
        String qualifiedPath = rootClass.getSimpleName() + "." + path;

        if (Class.class.isAssignableFrom(returnType.getClass())) {
            
            Class enhancedClass = EnhancerHelper.getDirtyableDBObjectEnhancer((Class) returnType).getEnhancedClass();

            classCache.put(qualifiedPath, enhancedClass);

            return enhancedClass;
        } else if (ParameterizedType.class.isAssignableFrom(returnType.getClass())) {
            ParameterizedType parameterizedType = (ParameterizedType) returnType;
            Class rawType = (Class) parameterizedType.getRawType();
            Class rawClass;
            Class enhancedClass;

            if (Map.class.isAssignableFrom(rawType)) {
                rawClass = (Class) parameterizedType.getActualTypeArguments()[1];
            } else if (Iterable.class.isAssignableFrom(rawType)) {
                rawClass = (Class) parameterizedType.getActualTypeArguments()[0];
            } else {
                throw new RuntimeException("unknown type: " + rawType);
            }

            classCache.put(qualifiedPath, rawType);

            if (!DBObjectUtil.needsNoConversion(rawClass)) {
                
                enhancedClass = EnhancerHelper.getDirtyableDBObjectEnhancer(rawClass).getEnhancedClass();

                classCache.put(qualifiedPath + ".", enhancedClass);
            }

            return rawType;
        } else {
            throw new RuntimeException("Don't know how to handle: " + qualifiedPath);
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_1_jeppetto_deepseek {
    private static Class invokeDerive(MongoDBCallback callback, String path, String last, boolean array) {
        try {
            Method m = MongoDBCallback.class.getDeclaredMethod("deriveClass1", String.class, String.class, boolean.class);
            m.setAccessible(true);
            return (Class) m.invoke(callback, path, last, array);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        System.out.println("=== Testing MongoDBCallback.deriveClass1 ===\n");

        
        class Person {
            private String name;
            private List<String> hobbies;

            public String getName() { return name; }
            public void setName(String name) { this.name = name; }
            public List<String> getHobbies() { return hobbies; }
            public void setHobbies(List<String> hobbies) { this.hobbies = hobbies; }
        }

        MongoDBCallback callback = new MongoDBCallback(Person.class);

        
        Class result1 = invokeDerive(callback, "name", "name", false);
        System.out.println("Result for 'name': " + result1.getSimpleName());

        
        
        
        class DummyContainer implements DBObject {
            public static Class __getPreEnhancedClass() { return Person.class; }
            public String getNested() { return "nested"; }
        }
        
        callback.registerCachedClass("Person." + "container", DummyContainer.class);

        
        Class result2 = invokeDerive(callback, "container.nested", "nested", false);
        System.out.println("Result for 'container.nested': " + result2.getSimpleName());

        
        Class result3 = invokeDerive(callback, "hobbies", "hobbies", true);
        System.out.println("Result for 'hobbies' (array): " + result3.getSimpleName());

        
        Class result4 = invokeDerive(callback, "unknown", "unknown", false);
        System.out.println("Result for 'unknown': " + result4.getSimpleName());

        System.out.println("\n=== Test completed ===");
    }
}