import java.util.concurrent.*;
import java.io.Serializable;



enum PeriodicScheduleStrategy { withFixedDelay }

class TimerTaskData {
    private final Serializable taskID;
    private final long startTime;
    private final long period;
    private final PeriodicScheduleStrategy strategy;
    public TimerTaskData(Serializable id, long start, long per, PeriodicScheduleStrategy s) {
        taskID = id; startTime = start; period = per; strategy = s;
    }
    public Serializable getTaskID() { return taskID; }
    public long getStartTime() { return startTime; }
    public long getPeriod() { return period; }
    public PeriodicScheduleStrategy getPeriodicScheduleStrategy() { return strategy; }
}

class TimerTask implements Runnable {
    private TimerTaskData data;
    private ScheduledFuture<?> future;
    private Object setTimerTransactionalAction;
    public TimerTask(TimerTaskData data) { this.data = data; }
    public TimerTaskData getData() { return data; }
    public void setScheduledFuture(ScheduledFuture<?> f) { future = f; }
    public void setSetTimerTransactionalAction(Object a) { setTimerTransactionalAction = a; }
    public Object getSetTimerTransactionalAction() { return setTimerTransactionalAction; }
    public void run() { System.out.println("Executing task " + data.getTaskID()); }
}

class FaultTolerantScheduler2 {
    private final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
    private final ConcurrentMap<Serializable, TimerTask> localRunningTasksMap = new ConcurrentHashMap<>();
    public ScheduledExecutorService getExecutor() { return executor; }
    public ConcurrentMap<Serializable, TimerTask> getLocalRunningTasksMap() { return localRunningTasksMap; }
}


public class method_2_restcomm_deepseek {
    static class Logger {
        boolean isDebugEnabled() { return true; }
        void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        void error(String msg, Throwable t) { System.err.println("[ERROR] " + msg); }
    }
    private static final Logger logger = new Logger();

    private boolean canceled;
    private TimerTask task;
    private FaultTolerantScheduler2 scheduler;

    public method_2_restcomm_deepseek(boolean canceled, TimerTask task, FaultTolerantScheduler2 scheduler) {
        this.canceled = canceled; this.task = task; this.scheduler = scheduler;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void run() {
        
        task.setSetTimerTransactionalAction(null);
        
        if (!canceled) {
            
            TimerTask previousTask = scheduler.getLocalRunningTasksMap().putIfAbsent(task.getData().getTaskID(), task);
            if(previousTask != null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("A task with id " + task.getData().getTaskID() + " has already been added to the local tasks, not rescheduling");
                }
            }
            
            final TimerTaskData taskData = task.getData();
            
            long delay = taskData.getStartTime() - System.currentTimeMillis();
            if (delay < 0) {
                delay = 0;
            }
            
            try {
                
                if (taskData.getPeriod() < 0) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Scheduling one-shot timer with id "
                                + task.getData().getTaskID() + ", delay " + delay);
                    }
                    task.setScheduledFuture(scheduler.getExecutor().schedule(task, delay, TimeUnit.MILLISECONDS));
                } else {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Scheduling periodic timer with id "
                                + task.getData().getTaskID() + ", scheduling strategy " + taskData.getPeriodicScheduleStrategy() + ", delay " + delay + ", period " + taskData.getPeriod());
                    }
                    if (taskData.getPeriodicScheduleStrategy() == PeriodicScheduleStrategy.withFixedDelay) {
                        task.setScheduledFuture(scheduler.getExecutor().scheduleWithFixedDelay(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
                    }
                    else {
                        
                        task.setScheduledFuture(scheduler.getExecutor().scheduleAtFixedRate(task, delay, taskData.getPeriod(),TimeUnit.MILLISECONDS));
                    }                   
                }       
            } catch (Throwable e) {
                logger.error(e.getMessage(), e);
                
                
                
            }
        } else {
            if (logger.isDebugEnabled()) {
                logger.debug("Canceled scheduling periodic timer with id "
                        + task.getData().getTaskID());
            }
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    
    static class ExtendedScheduler extends FaultTolerantScheduler2 {
        public void remove(Serializable id, boolean flag) {  }
    }

    public static void main(String[] args) {
        ExtendedScheduler scheduler = new ExtendedScheduler();
        TimerTaskData data = new TimerTaskData("task1", System.currentTimeMillis() + 1000, -1, PeriodicScheduleStrategy.withFixedDelay);
        TimerTask task = new TimerTask(data);
        method_2_restcomm_deepseek runnable = new method_2_restcomm_deepseek(false, task, scheduler);
        runnable.run();
        System.out.println("Timer scheduled. Task ID: " + task.getData().getTaskID());
        scheduler.getExecutor().shutdown();
    }
}