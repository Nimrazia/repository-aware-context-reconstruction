import java.util.concurrent.*;
import java.util.*;
import java.io.Serializable;


class TransactionContext {
    private final Map<Serializable, AfterTxCommitRunnable> map = new HashMap<>();
    public void put(Serializable id, AfterTxCommitRunnable r) { map.put(id, r); }
    public AfterTxCommitRunnable remove(Serializable id) { return map.remove(id); }
}
class TransactionSynchronization {
    public TransactionSynchronization(TransactionContext ctx) {  }
}

class Transaction {
    public void registerSynchronization(TransactionSynchronization sync) {  }
}

interface TransactionManager {
    Transaction getTransaction() throws Exception;
}

class TransactionContextThreadLocal {
    private static final ThreadLocal<TransactionContext> holder = new ThreadLocal<>();
    public static TransactionContext getTransactionContext() { return holder.get(); }
    public static void setTransactionContext(TransactionContext ctx) { holder.set(ctx); }
}

abstract class AfterTxCommitRunnable implements Runnable {
    public final TimerTask2 task;
    public AfterTxCommitRunnable(TimerTask2 task) { this.task = task; }
    public abstract void run();
}

class CancelTimerAfterTxCommitRunnable extends AfterTxCommitRunnable {
    private final method_3_restcomm_deepseek scheduler;
    public CancelTimerAfterTxCommitRunnable(TimerTask2 task, method_3_restcomm_deepseek scheduler) {
        super(task); this.scheduler = scheduler;
    }
    public void run() {
        
        System.out.println("Cancelling task " + task.getData().getTaskID());
    }
}

class TimerTaskCacheData {
    private final Serializable id;
    private final String baseFqn;
    private final Object cluster;
    public TimerTaskCacheData(Serializable id, String baseFqn, Object cluster) {
        this.id = id; this.baseFqn = baseFqn; this.cluster = cluster;
    }
    public void remove() {  }
}

class SetTimerAfterTxCommitRunnable {
    private boolean canceled;
    public void cancel() { canceled = true; }
}


enum PeriodicScheduleStrategy2 { withFixedDelay }
class TimerTaskData2 {
    private final Serializable taskID;
    public TimerTaskData2(Serializable id) { taskID = id; }
    public Serializable getTaskID() { return taskID; }
    
}
class TimerTask2 {
    private TimerTaskData2 data;
    private SetTimerAfterTxCommitRunnable setAction;
    public TimerTask2(TimerTaskData2 data) { this.data = data; }
    public TimerTaskData2 getData() { return data; }
    public SetTimerAfterTxCommitRunnable getSetTimerTransactionalAction() { return setAction; }
    public void setSetTimerTransactionalAction(SetTimerAfterTxCommitRunnable a) { setAction = a; }
}


public class method_3_restcomm_deepseek {
    static class Logger {
        boolean isDebugEnabled() { return true; }
        void debug(String msg) { System.out.println("[DEBUG] " + msg); }
    }
    private static final Logger logger = new Logger();

    
    private ConcurrentMap<Serializable, TimerTask2> localRunningTasks = new ConcurrentHashMap<>();
    private String baseFqn = "default";
    private Object cluster = new Object();
    private TransactionManager txManager;

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public TimerTask2 cancel(Serializable taskID) {
        
        if (logger.isDebugEnabled()) {
            logger.debug("Canceling task with timer id "+taskID);
        }
        
        TimerTask2 task = localRunningTasks.get(taskID);
        if (task != null) {
            
            new TimerTaskCacheData(taskID, baseFqn, cluster).remove();

            final SetTimerAfterTxCommitRunnable setAction = task.getSetTimerTransactionalAction();
            if (setAction != null) {
                
                setAction.cancel();
            }
            else {
                
                AfterTxCommitRunnable runnable = new CancelTimerAfterTxCommitRunnable(task,this);
                if (txManager != null) {
                    try {
                        Transaction tx = txManager.getTransaction();
                        if (tx != null) {
                            TransactionContext txContext = TransactionContextThreadLocal.getTransactionContext();
                            if (txContext == null) {
                                txContext = new TransactionContext();
                                tx.registerSynchronization(new TransactionSynchronization(txContext));
                            }
                            txContext.put(taskID, runnable);                    
                        }
                        else {
                            runnable.run();
                        }
                    }
                    catch (Throwable e) {
                        throw new RuntimeException("Unable to register tx synchronization object",e);
                    }
                }
                else {
                    runnable.run();
                }           
            }       
        }
        else {
            
            
            if (txManager != null) {
                try {
                    Transaction tx = txManager.getTransaction();
                    if (tx != null) {
                        TransactionContext txContext = TransactionContextThreadLocal.getTransactionContext();
                        if (txContext != null) {
                            final AfterTxCommitRunnable r = txContext.remove(taskID);
                            if (r != null) {
                                task = r.task;
                                
                                new TimerTaskCacheData(taskID, baseFqn, cluster).remove();
                            }                           
                        }                                           
                    }
                }
                catch (Throwable e) {
                    throw new RuntimeException("Failed to check tx context.",e);
                }
            }           
        }
        
        return task;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        method_3_restcomm_deepseek scheduler = new method_3_restcomm_deepseek();
        
        TimerTaskData2 data = new TimerTaskData2("task1");
        TimerTask2 task = new TimerTask2(data);
        scheduler.localRunningTasks.put("task1", task);

        
        TimerTask2 cancelled = scheduler.cancel("task1");
        System.out.println("Cancelled task: " + (cancelled != null ? cancelled.getData().getTaskID() : "null"));
    }
}