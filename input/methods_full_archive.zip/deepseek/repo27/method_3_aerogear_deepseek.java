import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



interface Callback<T> {
    void onSuccess(T data);
    void onFailure(Exception e);
}

class RestRunner {
    public void onRemove(String id) throws Exception {
        System.out.println("Removing item with id: " + id);
    }
}


public class method_3_aerogear_deepseek {
    private static final ExecutorService THREAD_POOL_EXECUTOR = Executors.newSingleThreadExecutor();
    private RestRunner restRunner = new RestRunner();

    public method_3_aerogear_deepseek() {}
    public method_3_aerogear_deepseek(RestRunner runner) { this.restRunner = runner; }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void remove(final String id, final Callback<Void> callback) {

        THREAD_POOL_EXECUTOR.execute(new Runnable() {
            Exception exception = null;

            @Override
            public void run() {
                try {
                    method_3_aerogear_deepseek.this.restRunner.onRemove(id);
                } catch (Exception e) {
                    exception = e;
                }
                if (exception == null) {
                    callback.onSuccess(null);
                } else {
                    callback.onFailure(exception);
                }
            }
        });

    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws InterruptedException {
        method_3_aerogear_deepseek adapter = new method_3_aerogear_deepseek();
        adapter.remove("123", new Callback<Void>() {
            @Override public void onSuccess(Void data) { System.out.println("Success callback"); }
            @Override public void onFailure(Exception e) { System.err.println("Failure: " + e.getMessage()); }
        });
        
        Thread.sleep(500);
        System.out.println("Done.");
        THREAD_POOL_EXECUTOR.shutdown();
    }
}