import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;




class Log {
    public static final String TAG = "RestAdapter";
    public static void e(String tag, String msg, Throwable tr) {
        System.err.println("ERROR[" + tag + "]: " + msg + " " + tr);
    }
}


class PageConfig {
    enum MetadataLocations { WEB_LINKING, HEADERS, BODY }
    private MetadataLocations metadataLocation;
    private String nextIdentifier;
    private String previousIdentifier;
    private PageParameterExtractor pageParameterExtractor;

    public PageConfig(MetadataLocations location, String next, String prev, PageParameterExtractor extractor) {
        this.metadataLocation = location;
        this.nextIdentifier = next;
        this.previousIdentifier = prev;
        this.pageParameterExtractor = extractor;
    }
    public MetadataLocations getMetadataLocation() { return metadataLocation; }
    public String getNextIdentifier() { return nextIdentifier; }
    public String getPreviousIdentifier() { return previousIdentifier; }
    public PageParameterExtractor getPageParameterExtractor() { return pageParameterExtractor; }
}

interface PageParameterExtractor {
    ReadFilter getNextFilter(HeaderAndBody response, PageConfig config);
    ReadFilter getPreviousFilter(HeaderAndBody response, PageConfig config);
}


class ReadFilter {
    private URI linkUri;
    private JSONObject where;
    public void setLinkUri(URI uri) { this.linkUri = uri; }
    public URI getLinkUri() { return linkUri; }
    public void setWhere(JSONObject where) { this.where = where; }
    public JSONObject getWhere() { return where; }
    @Override public String toString() { return "ReadFilter[uri=" + linkUri + "]"; }
}


class HeaderAndBody {
    private Map<String, List<String>> headers;
    private String body;
    public HeaderAndBody(Map<String, List<String>> headers, String body) {
        this.headers = headers; this.body = body;
    }
    public String getHeader(String name) {
        List<String> values = headers.get(name.toLowerCase());
        return values != null && !values.isEmpty() ? values.get(0) : null;
    }
    public String getBody() { return body; }
}


class JSONObject {}


class WebLink {
    private String uri;
    private Map<String, String> parameters;
    public WebLink(String uri, Map<String, String> params) { this.uri = uri; this.parameters = params; }
    public String getUri() { return uri; }
    public Map<String, String> getParameters() { return parameters; }
}

class WebLinkParser {
    public static List<WebLink> parse(String raw) throws ParseException {
        List<WebLink> links = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return links;
        String[] parts = raw.split(",");
        for (String part : parts) {
            part = part.trim();
            int semi = part.indexOf(';');
            String uri = (semi > 0) ? part.substring(0, semi).trim() : part;
            if (uri.startsWith("<") && uri.endsWith(">")) {
                uri = uri.substring(1, uri.length() - 1);
            }
            Map<String, String> params = new HashMap<>();
            if (semi > 0) {
                String paramStr = part.substring(semi+1).trim();
                if (paramStr.startsWith("rel=\"")) {
                    int endQuote = paramStr.indexOf('"', 5);
                    if (endQuote > 0) {
                        String relValue = paramStr.substring(5, endQuote);
                        params.put("rel", relValue);
                    }
                }
            }
            links.add(new WebLink(uri, params));
        }
        return links;
    }
}

class ParseException extends Exception {
    public ParseException(String msg) { super(msg); }
}


interface Pipe<T> {}


class WrappingPagedList<T> extends ArrayList<T> {
    private Pipe<T> pipe;
    private ReadFilter nextFilter, previousFilter;
    public WrappingPagedList(Pipe<T> pipe, List<T> result, ReadFilter next, ReadFilter prev) {
        super(result);
        this.pipe = pipe;
        this.nextFilter = next;
        this.previousFilter = prev;
    }
    public ReadFilter getNextFilter() { return nextFilter; }
    public ReadFilter getPreviousFilter() { return previousFilter; }
}


public class method_1_aerogear_deepseek {

    private static final String TAG = "RestAdapter";

    private PageConfig pageConfig;

    public method_1_aerogear_deepseek(PageConfig config) { this.pageConfig = config; }

    
    private String getWebLinkHeader(HeaderAndBody response) {
        return response.getHeader("link");
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private List<String> computePagedList(List<String> result, HeaderAndBody httpResponse, JSONObject where, Pipe<String> requestingPipe) {
        ReadFilter previousRead = null;
        ReadFilter nextRead = null;

        if (PageConfig.MetadataLocations.WEB_LINKING.equals(pageConfig.getMetadataLocation())) {
            String webLinksRaw = "";
            final String relHeader = "rel";
            final String nextIdentifier = pageConfig.getNextIdentifier();
            final String prevIdentifier = pageConfig.getPreviousIdentifier();
            try {
                webLinksRaw = getWebLinkHeader(httpResponse);
                if (webLinksRaw == null) { 
                    return result;
                }
                List<WebLink> webLinksParsed = WebLinkParser.parse(webLinksRaw);
                for (WebLink link : webLinksParsed) {
                    if (nextIdentifier.equals(link.getParameters().get(relHeader))) {
                        nextRead = new ReadFilter();
                        nextRead.setLinkUri(new URI(link.getUri()));
                    } else if (prevIdentifier.equals(link.getParameters().get(relHeader))) {
                        previousRead = new ReadFilter();
                        previousRead.setLinkUri(new URI(link.getUri()));
                    }
                }
            } catch (URISyntaxException ex) {
                Log.e(TAG, webLinksRaw + " did not contain a valid context URI", ex);
                throw new RuntimeException(ex);
            } catch (ParseException ex) {
                Log.e(TAG, webLinksRaw + " could not be parsed as a web link header", ex);
                throw new RuntimeException(ex);
            }
        } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.HEADERS)) {
            nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, this.pageConfig);
            previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, this.pageConfig);
        } else if (pageConfig.getMetadataLocation().equals(PageConfig.MetadataLocations.BODY)) {
            nextRead = pageConfig.getPageParameterExtractor().getNextFilter(httpResponse, this.pageConfig);
            previousRead = pageConfig.getPageParameterExtractor().getPreviousFilter(httpResponse, this.pageConfig);
        } else {
            throw new IllegalStateException("Not supported");
        }
        if (nextRead != null) {
            nextRead.setWhere(where);
        }
        if (previousRead != null) {
            previousRead.setWhere(where);
        }

        return new WrappingPagedList<String>(requestingPipe, result, nextRead, previousRead);
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        
        PageConfig config = new PageConfig(PageConfig.MetadataLocations.WEB_LINKING, "next", "prev", null);
        method_1_aerogear_deepseek adapter = new method_1_aerogear_deepseek(config);

        
        Map<String, List<String>> headers = new HashMap<>();
        headers.put("link", Arrays.asList("<http://example.com/next>; rel=\"next\", <http://example.com/prev>; rel=\"prev\""));
        HeaderAndBody response = new HeaderAndBody(headers, "");
        List<String> data = Arrays.asList("item1", "item2");
        Pipe<String> pipe = new Pipe<String>() {};
        JSONObject where = new JSONObject();

        
        java.lang.reflect.Method method = method_1_aerogear_deepseek.class.getDeclaredMethod("computePagedList",
                List.class, HeaderAndBody.class, JSONObject.class, Pipe.class);
        method.setAccessible(true);
        List<String> paged = (List<String>) method.invoke(adapter, data, response, where, pipe);

        System.out.println("Result class: " + paged.getClass().getSimpleName());
        if (paged instanceof WrappingPagedList) {
            WrappingPagedList<String> wpl = (WrappingPagedList<String>) paged;
            System.out.println("Next filter: " + wpl.getNextFilter());
            System.out.println("Prev filter: " + wpl.getPreviousFilter());
        }
    }
}