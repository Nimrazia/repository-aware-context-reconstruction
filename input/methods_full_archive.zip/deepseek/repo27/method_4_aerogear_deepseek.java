import java.net.HttpURLConnection;
import java.net.URL;
import java.net.ProtocolException;
import java.io.*;
import java.util.*;



class HeaderAndBody {
    private Map<String, List<String>> headers;
    private String body;
    public HeaderAndBody(Map<String, List<String>> headers, String body) { this.headers = headers; this.body = body; }
    public String getBody() { return body; }
    public Map<String, List<String>> getHeaders() { return headers; }
}

class HttpException extends Exception {
    public HttpException(String msg) { super(msg); }
}

class Log {
    public static final String TAG = "HttpRestProvider";
    public static void e(String tag, String msg, Throwable tr) {
        System.err.println("ERROR[" + tag + "]: " + msg + " " + tr);
    }
}


public class method_4_aerogear_deepseek {

    private static final String TAG = "HttpRestProvider";

    private String url;

    public method_4_aerogear_deepseek(String url) { this.url = url; }

    
    private HttpURLConnection prepareConnection() throws IOException {
        
        return new MockHttpURLConnection(new URL(url));
    }

    private HeaderAndBody getHeaderAndBody(HttpURLConnection conn) throws IOException {
        int status = conn.getResponseCode();
        Map<String, List<String>> headers = conn.getHeaderFields();
        InputStream input = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        Scanner scanner = new Scanner(input, "UTF-8").useDelimiter("\\A");
        String body = scanner.hasNext() ? scanner.next() : "";
        scanner.close();
        return new HeaderAndBody(headers, body);
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public HeaderAndBody get() throws HttpException {
        HttpURLConnection urlConnection = null;
        try {
            urlConnection = prepareConnection();
            return getHeaderAndBody(urlConnection);

        } catch (IOException e) {
            Log.e(TAG, "Error on GET of " + url, e);
            throw new RuntimeException(e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    static class MockHttpURLConnection extends HttpURLConnection {
        private Map<String, List<String>> headers = new HashMap<>();
        private String responseBody = "{\"result\": \"ok\"}";
        private int responseCode = 200;

        protected MockHttpURLConnection(URL url) {
            super(url);
        }

        @Override public void connect() { }

        @Override public void disconnect() { }

        @Override public boolean usingProxy() { return false; }

        @Override public int getResponseCode() throws IOException { return responseCode; }

        @Override public InputStream getInputStream() throws IOException {
            return new ByteArrayInputStream(responseBody.getBytes());
        }

        @Override public InputStream getErrorStream() {
            return new ByteArrayInputStream("".getBytes());
        }

        @Override public Map<String, List<String>> getHeaderFields() { return headers; }

        
        @Override public void setRequestMethod(String method) throws ProtocolException { }
        @Override public String getRequestMethod() { return "GET"; }
        @Override public void setDoOutput(boolean dooutput) { }
        @Override public void setDoInput(boolean doinput) { }
        @Override public void setUseCaches(boolean usecaches) { }
        @Override public void setConnectTimeout(int timeout) { }
        @Override public void setReadTimeout(int timeout) { }
        @Override public void setRequestProperty(String key, String value) { }
        @Override public String getRequestProperty(String key) { return null; }
        @Override public void setInstanceFollowRedirects(boolean followRedirects) { }
        @Override public boolean getInstanceFollowRedirects() { return false; }
        @Override public void setChunkedStreamingMode(int chunklen) { }
        @Override public void setFixedLengthStreamingMode(long contentLength) { }
        @Override public OutputStream getOutputStream() throws IOException { return null; }
        @Override public String getHeaderField(String name) { return null; }
        @Override public Map<String, List<String>> getRequestProperties() { return Collections.emptyMap(); }
    }

    public static void main(String[] args) throws Exception {
        method_4_aerogear_deepseek provider = new method_4_aerogear_deepseek("http://mock.example.com");
        HeaderAndBody response = provider.get();
        System.out.println("Response body: " + response.getBody());
    }
}