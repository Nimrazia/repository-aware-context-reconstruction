import java.net.URI;
import java.util.*;



class ModuleFields {
    private List<Pair<String, String>> headers = new ArrayList<>();
    private List<Pair<String, String>> queryParams = new ArrayList<>();

    public void addHeader(String key, String value) { headers.add(new Pair<>(key, value)); }
    public void addQueryParameter(String key, String value) { queryParams.add(new Pair<>(key, value)); }
    public List<Pair<String, String>> getHeaders() { return headers; }
    public List<Pair<String, String>> getQueryParameters() { return queryParams; }
}

class Pair<F, S> {
    public final F first;
    public final S second;
    public Pair(F first, S second) { this.first = first; this.second = second; }
}

interface PipeModule {
    ModuleFields loadModule(URI relativeURI, String httpMethod, byte[] requestBody);
}


class TestModule implements PipeModule {
    private Map<String, String> headers = new HashMap<>();
    private Map<String, String> queryParams = new HashMap<>();

    public TestModule(Map<String, String> headers, Map<String, String> queryParams) {
        this.headers = headers; this.queryParams = queryParams;
    }

    @Override
    public ModuleFields loadModule(URI relativeURI, String httpMethod, byte[] requestBody) {
        ModuleFields fields = new ModuleFields();
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            fields.addHeader(entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, String> entry : queryParams.entrySet()) {
            fields.addQueryParameter(entry.getKey(), entry.getValue());
        }
        return fields;
    }
}


public class method_2_aerogear_deepseek {

    private List<PipeModule> modules;

    public method_2_aerogear_deepseek(List<PipeModule> modules) { this.modules = modules; }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private ModuleFields loadAuth(URI relativeURI, String httpMethod) {

        ModuleFields authFields = new ModuleFields();

        for (PipeModule module : modules) {
            ModuleFields moduleFields = module.loadModule(relativeURI, httpMethod, new byte[] {});
            if (!moduleFields.getHeaders().isEmpty()) {
                for (Pair<String, String> header : moduleFields.getHeaders()) {
                    authFields.addHeader(header.first, header.second);
                }
            }

            if (!moduleFields.getQueryParameters().isEmpty()) {
                for (Pair<String, String> header : moduleFields.getQueryParameters()) {
                    authFields.addQueryParameter(header.first, header.second);
                }
            }

        }

        return authFields;

    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        
        Map<String, String> h1 = new HashMap<>();
        h1.put("Authorization", "Bearer token123");
        Map<String, String> q1 = new HashMap<>();
        q1.put("apikey", "key123");
        TestModule module1 = new TestModule(h1, q1);

        Map<String, String> h2 = new HashMap<>();
        h2.put("X-Custom", "customValue");
        TestModule module2 = new TestModule(h2, new HashMap<>());

        method_2_aerogear_deepseek runner = new method_2_aerogear_deepseek(Arrays.asList(module1, module2));

        
        java.lang.reflect.Method method = method_2_aerogear_deepseek.class.getDeclaredMethod("loadAuth",
                URI.class, String.class);
        method.setAccessible(true);
        ModuleFields auth = (ModuleFields) method.invoke(runner, new URI("/test"), "GET");

        System.out.println("Auth headers: ");
        for (Pair<String, String> h : auth.getHeaders()) {
            System.out.println("  " + h.first + ": " + h.second);
        }
        System.out.println("Auth query parameters: ");
        for (Pair<String, String> q : auth.getQueryParameters()) {
            System.out.println("  " + q.first + "=" + q.second);
        }
    }
}