
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Collectors;






public class method_1_sherdogparser_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    static class Fighter {
        private String sherdogUrl;
        private String name;
        private String nickname;
        private Date birthday;
        private String height;
        private String weight;
        private int wins;
        private int losses;
        private int draws;
        private int nc;
        private int winsKo, winsSub, winsDec, winsOther;
        private int lossesKo, lossesSub, lossesDec, lossesOther;
        private List<Fight> fights = new ArrayList<>();
        private String picture;

        
        public String getSherdogUrl() { return sherdogUrl; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getNickname() { return nickname; }
        public void setNickname(String nickname) { this.nickname = nickname; }
        public Date getBirthday() { return birthday; }
        public void setBirthday(Date birthday) { this.birthday = birthday; }
        public String getHeight() { return height; }
        public void setHeight(String height) { this.height = height; }
        public String getWeight() { return weight; }
        public void setWeight(String weight) { this.weight = weight; }
        public int getWins() { return wins; }
        public void setWins(int wins) { this.wins = wins; }
        public int getLosses() { return losses; }
        public void setLosses(int losses) { this.losses = losses; }
        public int getDraws() { return draws; }
        public void setDraws(int draws) { this.draws = draws; }
        public int getNc() { return nc; }
        public void setNc(int nc) { this.nc = nc; }
        public int getWinsKo() { return winsKo; }
        public void setWinsKo(int winsKo) { this.winsKo = winsKo; }
        public int getWinsSub() { return winsSub; }
        public void setWinsSub(int winsSub) { this.winsSub = winsSub; }
        public int getWinsDec() { return winsDec; }
        public void setWinsDec(int winsDec) { this.winsDec = winsDec; }
        public int getWinsOther() { return winsOther; }
        public void setWinsOther(int winsOther) { this.winsOther = winsOther; }
        public int getLossesKo() { return lossesKo; }
        public void setLossesKo(int lossesKo) { this.lossesKo = lossesKo; }
        public int getLossesSub() { return lossesSub; }
        public void setLossesSub(int lossesSub) { this.lossesSub = lossesSub; }
        public int getLossesDec() { return lossesDec; }
        public void setLossesDec(int lossesDec) { this.lossesDec = lossesDec; }
        public int getLossesOther() { return lossesOther; }
        public void setLossesOther(int lossesOther) { this.lossesOther = lossesOther; }
        public List<Fight> getFights() { return fights; }
        public void setFights(List<Fight> fights) { this.fights = fights; }
        public String getPicture() { return picture; }
        public void setPicture(String picture) { this.picture = picture; }
    }

    static class Fight {
        private SherdogBaseObject event;
        private SherdogBaseObject fighter1;
        private SherdogBaseObject fighter2;
        private String result;
        private String winMethod;
        private int winRound;
        private String winTime;
        private Date date;
        private FightType type;

        
        public SherdogBaseObject getEvent() { return event; }
        public void setEvent(SherdogBaseObject event) { this.event = event; }
        public SherdogBaseObject getFighter1() { return fighter1; }
        public void setFighter1(SherdogBaseObject fighter1) { this.fighter1 = fighter1; }
        public SherdogBaseObject getFighter2() { return fighter2; }
        public void setFighter2(SherdogBaseObject fighter2) { this.fighter2 = fighter2; }
        public String getResult() { return result; }
        public void setResult(String result) { this.result = result; }
        public String getWinMethod() { return winMethod; }
        public void setWinMethod(String winMethod) { this.winMethod = winMethod; }
        public int getWinRound() { return winRound; }
        public void setWinRound(int winRound) { this.winRound = winRound; }
        public String getWinTime() { return winTime; }
        public void setWinTime(String winTime) { this.winTime = winTime; }
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
        public FightType getType() { return type; }
        public void setType(FightType type) { this.type = type; }
    }

    static class SherdogBaseObject {
        private String name;
        private String sherdogUrl;

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSherdogUrl() { return sherdogUrl; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
    }

    enum FightType {
        MMA, BOXING, KICKBOXING, OTHER;
        public static FightType fromString(String s) {
            if (s == null) return OTHER;
            String u = s.toUpperCase();
            if (u.contains("MMA")) return MMA;
            if (u.contains("BOXING")) return BOXING;
            if (u.contains("KICKBOXING")) return KICKBOXING;
            return OTHER;
        }
    }

    

    static class ParserUtils {
        public static String getSherdogPageUrl(Object doc) {
            return "http://www.sherdog.com/fighter/test";
        }
        public static String getFightResult(Element element) {
            
            return "Win";
        }
    }

    static class PictureProcessor {
        public String process(String url, Fighter fighter) {
            
            return url;
        }
    }

    

    static class Document {
        private String html;
        public Document(String html) { this.html = html; }
        public Elements select(String cssQuery) {
            
            
            
            
            List<Element> elements = new ArrayList<>();
            
            if (cssQuery.contains("h1 span.fn")) {
                elements.add(new Element("John Doe"));
            } else if (cssQuery.contains("span.nickname em")) {
                elements.add(new Element("The Beast"));
            } else if (cssQuery.contains("span[itemprop=\"birthDate\"]")) {
                elements.add(new Element("1980-01-01"));
            } else if (cssQuery.contains(".size_info .height strong")) {
                elements.add(new Element("6'0\""));
            } else if (cssQuery.contains(".size_info .weight strong")) {
                elements.add(new Element("185 lbs"));
            } else if (cssQuery.contains(".bio_graph .counter")) {
                elements.add(new Element("10"));
            } else if (cssQuery.contains(".bio_graph:first-of-type .graph_tag")) {
                elements.add(new Element("5 KO"));
                elements.add(new Element("3 SUB"));
                elements.add(new Element("2 DEC"));
                elements.add(new Element("0 OTHER"));
            } else if (cssQuery.contains(".bio_graph.loser .counter")) {
                elements.add(new Element("2"));
            } else if (cssQuery.contains(".bio_graph.loser .graph_tag")) {
                elements.add(new Element("1 KO"));
                elements.add(new Element("0 SUB"));
                elements.add(new Element("1 DEC"));
                elements.add(new Element("0 OTHER"));
            } else if (cssQuery.contains(".right_side .bio_graph .card")) {
                elements.add(new Element("<span class=\"result\">Draws</span><span class=\"counter\">1</span>"));
                elements.add(new Element("<span class=\"result\">N/C</span><span class=\"counter\">0</span>"));
            } else if (cssQuery.contains(".bio_fighter .content img[itemprop=\"image\"]")) {
                elements.add(new Element().attr("src", "/fighter.jpg"));
            } else if (cssQuery.contains(".fight_history")) {
                elements.add(new Element("<div class=\"module_header\"><h2>FIGHT HISTORY - MMA</h2></div><div class=\"table\"><table><tr><td>Fight1</td><td>Opponent</td></tr></table></div>"));
            }
            return new Elements(elements);
        }
    }

    static class Elements extends ArrayList<Element> {
        public Elements() { super(); }
        public Elements(Collection<Element> c) { super(c); }
        public String html() { return isEmpty() ? "" : get(0).html(); }
        public String attr(String key) { return isEmpty() ? "" : get(0).attr(key); }
        public Elements select(String cssQuery) {
            
            List<Element> result = new ArrayList<>();
            if (cssQuery.contains(".module_header h2")) {
                result.add(new Element("FIGHT HISTORY - MMA"));
            } else if (cssQuery.contains(".table table tr")) {
                result.add(new Element("<tr><td>Fight1</td></tr>"));
            }
            return new Elements(result);
        }
    }

    static class Element {
        private String html;
        private Map<String, String> attributes = new HashMap<>();
        public Element() {}
        public Element(String html) { this.html = html; }
        public String html() { return html; }
        public Element attr(String key, String value) { attributes.put(key, value); return this; }
        public String attr(String key) { return attributes.getOrDefault(key, ""); }
        public Elements select(String cssQuery) {
            
            return new Elements();
        }
        public Element first() { return this; }
    }

    

    static class Logger {
        public void info(String msg) { System.out.println("[INFO] " + msg); }
        public void info(String msg, Object... args) { System.out.println("[INFO] " + String.format(msg, args)); }
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
        public void error(String msg) { System.err.println("[ERROR] " + msg); }
        public void error(String msg, Throwable t) { System.err.println("[ERROR] " + msg); t.printStackTrace(); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    

    static class FighterParser {
        private static final Logger logger = LoggerFactory.getLogger(FighterParser.class);
        private static final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        private static final int METHOD_KO = 0;
        private static final int METHOD_SUBMISSION = 1;
        private static final int METHOD_DECISION = 2;
        private static final int METHOD_OTHERS = 3;
        private static final PictureProcessor PROCESSOR = new PictureProcessor();

        
        private List<Fight> getFights(Elements trs, Fighter fighter) {
            
            List<Fight> fights = new ArrayList<>();
            Fight f = new Fight();
            f.setDate(new Date());
            f.setResult("Win");
            f.setWinMethod("KO");
            f.setWinRound(1);
            f.setWinTime("2:30");
            f.setFighter1(new SherdogBaseObject());
            f.getFighter1().setName(fighter.getName());
            f.getFighter1().setSherdogUrl(fighter.getSherdogUrl());
            SherdogBaseObject opponent = new SherdogBaseObject();
            opponent.setName("Opponent");
            opponent.setSherdogUrl("http://example.com/opponent");
            f.setFighter2(opponent);
            SherdogBaseObject eventObj = new SherdogBaseObject();
            eventObj.setName("UFC 300");
            eventObj.setSherdogUrl("http://example.com/event");
            f.setEvent(eventObj);
            fights.add(f);
            return fights;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public Fighter parseDocument(Document doc) throws IOException {
            Fighter fighter = new Fighter();
            fighter.setSherdogUrl(ParserUtils.getSherdogPageUrl(doc));

            logger.info("Refreshing fighter {}", fighter.getSherdogUrl());

            try {
                Elements name = doc.select(".bio_fighter h1 span.fn");
                fighter.setName(name.get(0).html());
            } catch (Exception e) {
                
            }

            
            try {
                Elements nickname = doc.select(".bio_fighter span.nickname em");
                fighter.setNickname(nickname.get(0).html());
            } catch (Exception e) {
                
            }

            
            try {
                Elements birthday = doc.select("span[itemprop=\"birthDate\"]");
                fighter.setBirthday(df.parse(birthday.get(0).html()));
            } catch (Exception e) {
                
            }
            
            try {
                Elements height = doc.select(".size_info .height strong");
                fighter.setHeight(height.get(0).html());
            } catch (Exception e) {
                
            }
            
            try {
                Elements weight = doc.select(".size_info .weight strong");
                fighter.setWeight(weight.get(0).html());
            } catch (Exception e) {
                
            }
            
            try {
                Elements wins = doc.select(".bio_graph .counter");
                fighter.setWins(Integer.parseInt(wins.get(0).html()));
            } catch (Exception e) {
                
            }
            Elements winsMethods = doc.select(".bio_graph:first-of-type .graph_tag");
            try {
                fighter.setWinsKo(Integer.parseInt(winsMethods.get(METHOD_KO).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setWinsSub(Integer.parseInt(winsMethods.get(METHOD_SUBMISSION).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setWinsDec(Integer.parseInt(winsMethods.get(METHOD_DECISION).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setWinsOther(Integer.parseInt(winsMethods.get(METHOD_OTHERS).html().split(" ")[0]));
            } catch (Exception e) {
                
            }
            
            try {
                Elements losses = doc.select(".bio_graph.loser .counter");
                fighter.setLosses(Integer.parseInt(losses.get(0).html()));
            } catch (Exception e) {
                
            }

            Elements lossesMethods = doc.select(".bio_graph.loser .graph_tag");

            try {
                fighter.setLossesKo((Integer.parseInt(lossesMethods.get(METHOD_KO).html().split(" ")[0])));
            } catch (Exception e) {
                
            }

            try {
                fighter.setLossesSub(Integer.parseInt(lossesMethods.get(METHOD_SUBMISSION).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setLossesDec(Integer.parseInt(lossesMethods.get(METHOD_DECISION).html().split(" ")[0]));
            } catch (Exception e) {
                
            }

            try {
                fighter.setLossesOther(Integer.parseInt(lossesMethods.get(METHOD_OTHERS).html().split(" ")[0]));
            } catch (Exception e) {
                
            }
            
            Elements drawsNc = doc.select(".right_side .bio_graph .card");
            for (Element element : drawsNc) {
                String result = element.select("span.result").html();
                String counter = element.select("span.counter").html();
                if (result.equals("Draws")) {
                    fighter.setDraws(Integer.parseInt(counter));
                } else if (result.equals("N/C")) {
                    fighter.setNc(Integer.parseInt(counter));
                }
            }

            Elements picture = doc.select(".bio_fighter .content img[itemprop=\"image\"]");
            String pictureUrl = "https://www.sherdog.com" + picture.attr("src").trim();

            Elements fightTables = doc.select(".fight_history");
            logger.info("Found {} fight history tables", fightTables.size());

            fightTables.stream()
                    
                    .filter(div -> !div.select(".module_header h2").html().trim().contains("Upcoming"))
                    .collect(Collectors.groupingBy(div -> {
                        String categoryName = div.select(".module_header h2").html().trim().replaceAll("(?i)FIGHT HISTORY - ", "").trim();
                        return FightType.fromString(categoryName);
                    }))
                    .forEach((key, div) -> div.stream()
                            .map(d -> d.select(".table table tr"))
                            .filter(tdList -> tdList.size() > 0)
                            .findFirst()
                            .ifPresent(tdList -> {
                                List<Fight> f = getFights(tdList, fighter);
                                f.forEach(fight -> fight.setType(key));
                                fighter.getFights().addAll(f);
                            }));

            List<Fight> sorted = fighter.getFights()
                    .stream()
                    .sorted(Comparator.comparing(Fight::getDate, Comparator.nullsFirst(Comparator.naturalOrder())))
                    .collect(Collectors.toList());

            fighter.setFights(sorted);

            logger.info("Found {} fights for {}", fighter.getFights().size(), fighter.getName());

            
            if (pictureUrl.length() > 0) {
                fighter.setPicture(PROCESSOR.process(pictureUrl, fighter));
            }

            return fighter;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing FighterParser.parseDocument ===\n");

        
        String html = "<html><body>" +
                "<div class=\"bio_fighter\"><h1><span class=\"fn\">John Doe</span></h1>" +
                "<span class=\"nickname\"><em>The Beast</em></span>" +
                "<div class=\"content\"><img itemprop=\"image\" src=\"/fighter.jpg\"/></div>" +
                "</div>" +
                "<span itemprop=\"birthDate\">1980-01-01</span>" +
                "<div class=\"size_info\"><div class=\"height\"><strong>6'0\"</strong></div><div class=\"weight\"><strong>185 lbs</strong></div></div>" +
                "<div class=\"bio_graph\"><span class=\"counter\">10</span>" +
                "<span class=\"graph_tag\">5 KO</span><span class=\"graph_tag\">3 SUB</span><span class=\"graph_tag\">2 DEC</span><span class=\"graph_tag\">0 OTHER</span></div>" +
                "<div class=\"bio_graph loser\"><span class=\"counter\">2</span>" +
                "<span class=\"graph_tag\">1 KO</span><span class=\"graph_tag\">0 SUB</span><span class=\"graph_tag\">1 DEC</span><span class=\"graph_tag\">0 OTHER</span></div>" +
                "<div class=\"right_side\"><div class=\"bio_graph\"><div class=\"card\"><span class=\"result\">Draws</span><span class=\"counter\">1</span></div>" +
                "<div class=\"card\"><span class=\"result\">N/C</span><span class=\"counter\">0</span></div></div></div>" +
                "<div class=\"fight_history\"><div class=\"module_header\"><h2>FIGHT HISTORY - MMA</h2></div>" +
                "<div class=\"table\"><table><tr><td>Fight1</td></tr></table></div></div>" +
                "</body></html>";

        Document doc = new Document(html);
        FighterParser parser = new FighterParser();
        try {
            Fighter fighter = parser.parseDocument(doc);
            System.out.println("Parsed fighter: " + fighter.getName());
            System.out.println("Nickname: " + fighter.getNickname());
            System.out.println("Birthday: " + fighter.getBirthday());
            System.out.println("Height: " + fighter.getHeight());
            System.out.println("Weight: " + fighter.getWeight());
            System.out.println("Wins: " + fighter.getWins() + " (KO: " + fighter.getWinsKo() + ", SUB: " + fighter.getWinsSub() + ", DEC: " + fighter.getWinsDec() + ", OTHER: " + fighter.getWinsOther() + ")");
            System.out.println("Losses: " + fighter.getLosses() + " (KO: " + fighter.getLossesKo() + ", SUB: " + fighter.getLossesSub() + ", DEC: " + fighter.getLossesDec() + ", OTHER: " + fighter.getLossesOther() + ")");
            System.out.println("Draws: " + fighter.getDraws() + ", NC: " + fighter.getNc());
            System.out.println("Picture URL: " + fighter.getPicture());
            System.out.println("Fights count: " + fighter.getFights().size());
            if (!fighter.getFights().isEmpty()) {
                Fight f = fighter.getFights().get(0);
                System.out.println("First fight: vs " + f.getFighter2().getName() + " at " + f.getEvent().getName() + " result: " + f.getResult());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}