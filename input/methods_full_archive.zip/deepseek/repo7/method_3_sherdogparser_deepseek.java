
import java.util.*;






public class method_3_sherdogparser_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    static class Fighter {
        private String name;
        private String sherdogUrl;
        private List<Fight> fights = new ArrayList<>();
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSherdogUrl() { return sherdogUrl; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
        public List<Fight> getFights() { return fights; }
        public void setFights(List<Fight> fights) { this.fights = fights; }
    }

    static class Fight {
        private SherdogBaseObject fighter1;
        private SherdogBaseObject fighter2;
        private SherdogBaseObject event;
        private String result;
        private String winMethod;
        private int winRound;
        private String winTime;
        private Date date;

        public SherdogBaseObject getFighter1() { return fighter1; }
        public void setFighter1(SherdogBaseObject fighter1) { this.fighter1 = fighter1; }
        public SherdogBaseObject getFighter2() { return fighter2; }
        public void setFighter2(SherdogBaseObject fighter2) { this.fighter2 = fighter2; }
        public SherdogBaseObject getEvent() { return event; }
        public void setEvent(SherdogBaseObject event) { this.event = event; }
        public String getResult() { return result; }
        public void setResult(String result) { this.result = result; }
        public String getWinMethod() { return winMethod; }
        public void setWinMethod(String winMethod) { this.winMethod = winMethod; }
        public int getWinRound() { return winRound; }
        public void setWinRound(int winRound) { this.winRound = winRound; }
        public String getWinTime() { return winTime; }
        public void setWinTime(String winTime) { this.winTime = winTime; }
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
    }

    static class SherdogBaseObject {
        private String name;
        private String sherdogUrl;
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSherdogUrl() { return sherdogUrl; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
    }

    static class Date {  }

    

    static class Element {
        private String html;
        private Map<String, String> attrs = new HashMap<>();
        public Element() { }
        public Element(String html) { this.html = html; }
        public String html() { return html; }
        public Element attr(String key, String value) { attrs.put(key, value); return this; }
        public String attr(String key) { return attrs.getOrDefault(key, ""); }
        public Elements select(String cssQuery) {
            
            List<Element> list = new ArrayList<>();
            if (cssQuery.equals("td")) {
                
                String[] parts = html.split("</td>");
                for (String part : parts) {
                    int start = part.lastIndexOf("<td>");
                    if (start >= 0) {
                        String content = part.substring(start + 4);
                        list.add(new Element(content));
                    }
                }
            }
            return new Elements(list);
        }
    }

    static class Elements extends ArrayList<Element> {
        public Elements() { super(); }
        public Elements(Collection<Element> c) { super(c); }
        public Element get(int index) { return super.get(index); }
        public void forEach(java.util.function.Consumer<? super Element> action) { super.forEach(action); }
        public Elements select(String cssQuery) {
            
            if (!isEmpty()) {
                return get(0).select(cssQuery);
            }
            return new Elements();
        }
    }

    

    static class Logger {
        public void info(String msg) { System.out.println("[INFO] " + msg); }
        public void info(String msg, Object... args) { System.out.println("[INFO] " + String.format(msg, args)); }
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    

    static class FighterParser {
        private static final Logger logger = LoggerFactory.getLogger(FighterParser.class);

        
        private static final int COLUMN_RESULT = 0;
        private static final int COLUMN_OPPONENT = 1;
        private static final int COLUMN_EVENT = 2;
        private static final int COLUMN_METHOD = 3;
        private static final int COLUMN_ROUND = 4;
        private static final int COLUMN_TIME = 5;

        
        private String getFightResult(Element td) {
            String text = td.html().trim();
            
            if (text.contains("Win")) return "Win";
            if (text.contains("Loss")) return "Loss";
            return "Draw";
        }

        private SherdogBaseObject getOpponent(Element td) {
            String text = td.html().trim();
            SherdogBaseObject obj = new SherdogBaseObject();
            obj.setName(text);
            obj.setSherdogUrl("http://example.com/opponent/" + text.replace(" ", "_"));
            return obj;
        }

        private SherdogBaseObject getEvent(Element td) {
            String text = td.html().trim();
            SherdogBaseObject obj = new SherdogBaseObject();
            obj.setName(text);
            obj.setSherdogUrl("http://example.com/event/" + text.replace(" ", "_"));
            return obj;
        }

        private Date getDate(Element td) {
            
            return new Date();
        }

        private String getWinMethod(Element td) {
            return td.html().trim();
        }

        private int getWinRound(Element td) {
            try {
                return Integer.parseInt(td.html().trim());
            } catch (NumberFormatException e) {
                return 0;
            }
        }

        private String getWinTime(Element td) {
            return td.html().trim();
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private List<Fight> getFights(Elements trs, Fighter fighter) throws ArrayIndexOutOfBoundsException {
            List<Fight> fights = new ArrayList<>();

            logger.info("{} TRs to parse through", trs.size());

            SherdogBaseObject sFighter = new SherdogBaseObject();
            sFighter.setName(fighter.getName());
            sFighter.setSherdogUrl(fighter.getSherdogUrl());

            
            if (trs.size() > 0) {
                trs.remove(0);

                trs.forEach(tr -> {
                    Fight fight = new Fight();
                    fight.setFighter1(sFighter);

                    Elements tds = tr.select("td");
                    fight.setResult(getFightResult(tds.get(COLUMN_RESULT)));
                    fight.setFighter2(getOpponent(tds.get(COLUMN_OPPONENT)));
                    fight.setEvent(getEvent(tds.get(COLUMN_EVENT)));
                    fight.setDate(getDate(tds.get(COLUMN_EVENT)));
                    fight.setWinMethod(getWinMethod(tds.get(COLUMN_METHOD)));
                    fight.setWinRound(getWinRound(tds.get(COLUMN_ROUND)));
                    fight.setWinTime(getWinTime(tds.get(COLUMN_TIME)));
                    fights.add(fight);
                    logger.info("{}", fight);
                });
            }

            return fights;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing FighterParser.getFights ===\n");

        
        Elements trs = new Elements();
        
        Element header = new Element("<tr><td>Result</td><td>Opponent</td><td>Event</td><td>Method</td><td>Round</td><td>Time</td></tr>");
        trs.add(header);
        
        Element row1 = new Element("<tr><td>Win</td><td>Fighter A</td><td>UFC 300</td><td>KO</td><td>3</td><td>2:30</td></tr>");
        trs.add(row1);
        
        Element row2 = new Element("<tr><td>Loss</td><td>Fighter B</td><td>UFC 301</td><td>SUB</td><td>2</td><td>4:15</td></tr>");
        trs.add(row2);

        Fighter fighter = new Fighter();
        fighter.setName("Test Fighter");
        fighter.setSherdogUrl("http://example.com/fighter");

        FighterParser parser = new FighterParser();
        List<Fight> fights = parser.getFights(trs, fighter);

        System.out.println("Parsed " + fights.size() + " fights:");
        for (Fight f : fights) {
            System.out.println("  vs " + f.getFighter2().getName() + " at " + f.getEvent().getName() + " result: " + f.getResult() + ", method: " + f.getWinMethod());
        }

        System.out.println("\n=== Test completed ===");
    }
}