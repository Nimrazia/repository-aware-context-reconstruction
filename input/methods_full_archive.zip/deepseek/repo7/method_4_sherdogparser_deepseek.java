
import java.util.*;






public class method_4_sherdogparser_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    static class Event {
        private String name;
        private String sherdogUrl;
        private Date date;
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSherdogUrl() { return sherdogUrl; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
    }

    static class Fight {
        private SherdogBaseObject event;
        private SherdogBaseObject fighter1;
        private SherdogBaseObject fighter2;
        private String result;
        private String winMethod;
        private int winRound;
        private String winTime;
        private Date date;

        public SherdogBaseObject getEvent() { return event; }
        public void setEvent(SherdogBaseObject event) { this.event = event; }
        public SherdogBaseObject getFighter1() { return fighter1; }
        public void setFighter1(SherdogBaseObject fighter1) { this.fighter1 = fighter1; }
        public SherdogBaseObject getFighter2() { return fighter2; }
        public void setFighter2(SherdogBaseObject fighter2) { this.fighter2 = fighter2; }
        public String getResult() { return result; }
        public void setResult(String result) { this.result = result; }
        public String getWinMethod() { return winMethod; }
        public void setWinMethod(String winMethod) { this.winMethod = winMethod; }
        public int getWinRound() { return winRound; }
        public void setWinRound(int winRound) { this.winRound = winRound; }
        public String getWinTime() { return winTime; }
        public void setWinTime(String winTime) { this.winTime = winTime; }
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
    }

    static class SherdogBaseObject {
        private String name;
        private String sherdogUrl;
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSherdogUrl() { return sherdogUrl; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
    }

    static class Date {  }

    

    static class Element {
        private String html;
        public Element() { }
        public Element(String html) { this.html = html; }
        public String html() { return html; }
        public Elements select(String cssQuery) {
            
            List<Element> list = new ArrayList<>();
            if (cssQuery.equals("td")) {
                String[] parts = html.split("</td>");
                for (String part : parts) {
                    int start = part.lastIndexOf("<td>");
                    if (start >= 0) {
                        String content = part.substring(start + 4);
                        list.add(new Element(content));
                    }
                }
            }
            return new Elements(list);
        }
    }

    static class Elements extends ArrayList<Element> {
        public Elements() { super(); }
        public Elements(Collection<Element> c) { super(c); }
        public Element get(int index) { return super.get(index); }
        public void forEach(java.util.function.Consumer<? super Element> action) { super.forEach(action); }
        public Elements select(String cssQuery) {
            if (!isEmpty()) {
                return get(0).select(cssQuery);
            }
            return new Elements();
        }
    }

    

    static class Logger {
        public void info(String msg) { System.out.println("[INFO] " + msg); }
        public void info(String msg, Object... args) { System.out.println("[INFO] " + String.format(msg, args)); }
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    

    static class EventParser {
        private static final Logger logger = LoggerFactory.getLogger(EventParser.class);

        
        private static final int FIGHTER1_COLUMN = 0;
        private static final int FIGHTER2_COLUMN = 1;
        private static final int METHOD_COLUMN = 2;
        private static final int ROUND_COLUMN = 3;
        private static final int TIME_COLUMN = 4;

        
        private SherdogBaseObject getFighter(Element td) {
            String text = td.html().trim();
            SherdogBaseObject obj = new SherdogBaseObject();
            obj.setName(text);
            obj.setSherdogUrl("http://example.com/fighter/" + text.replace(" ", "_"));
            return obj;
        }

        private String getResult(Element td) {
            
            String text = td.html().trim();
            if (text.contains("Win")) return "Win";
            if (text.contains("Loss")) return "Loss";
            return "Draw";
        }

        private String getMethod(Element td) {
            return td.html().trim();
        }

        private int getRound(Element td) {
            try {
                return Integer.parseInt(td.html().trim());
            } catch (NumberFormatException e) {
                return 0;
            }
        }

        private String getTime(Element td) {
            return td.html().trim();
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private List<Fight> parseEventFights(Elements trs, Event event) {
            SherdogBaseObject sEvent = new SherdogBaseObject();
            sEvent.setName(event.getName());
            sEvent.setSherdogUrl(event.getSherdogUrl());

            List<Fight> fights = new ArrayList<>();

            if (trs.size() > 0) {
                trs.remove(0);

                trs.forEach(tr -> {
                    Fight fight = new Fight();
                    fight.setEvent(sEvent);
                    fight.setDate(event.getDate());
                    Elements tds = tr.select("td");

                    fight.setFighter1(getFighter(tds.get(FIGHTER1_COLUMN)));
                    fight.setFighter2(getFighter(tds.get(FIGHTER2_COLUMN)));

                    
                    if (tds.size() == 7) {
                        fight.setResult(getResult(tds.get(FIGHTER1_COLUMN)));
                        fight.setWinMethod(getMethod(tds.get(METHOD_COLUMN)));
                        fight.setWinRound(getRound(tds.get(ROUND_COLUMN)));
                        fight.setWinTime(getTime(tds.get(TIME_COLUMN)));
                    }

                    fights.add(fight);
                    logger.info("Fight added: {}", fight);
                });
            }

            return fights;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing EventParser.parseEventFights ===\n");

        
        Elements trs = new Elements();
        Element header = new Element("<tr><td>Fighter1</td><td>Fighter2</td><td>Method</td><td>Round</td><td>Time</td><td>Extra1</td><td>Extra2</td></tr>");
        trs.add(header);
        Element row1 = new Element("<tr><td>Win</td><td>Fighter A</td><td>KO</td><td>3</td><td>2:30</td><td>extra</td><td>extra</td></tr>");
        trs.add(row1);
        Element row2 = new Element("<tr><td>Loss</td><td>Fighter B</td><td>SUB</td><td>2</td><td>4:15</td><td>extra</td><td>extra</td></tr>");
        trs.add(row2);

        Event event = new Event();
        event.setName("UFC 300");
        event.setSherdogUrl("http://example.com/event");
        event.setDate(new Date());

        EventParser parser = new EventParser();
        List<Fight> fights = parser.parseEventFights(trs, event);

        System.out.println("Parsed " + fights.size() + " fights:");
        for (Fight f : fights) {
            System.out.println("  " + f.getFighter1().getName() + " vs " + f.getFighter2().getName() +
                    ", result: " + f.getResult() + ", method: " + f.getWinMethod() +
                    ", round: " + f.getWinRound() + ", time: " + f.getWinTime());
        }

        System.out.println("\n=== Test completed ===");
    }
}