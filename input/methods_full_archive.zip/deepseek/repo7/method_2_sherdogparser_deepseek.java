
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.regex.*;






public class method_2_sherdogparser_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    static class Event {
        private String name;
        private String sherdogUrl;
        private Date date;
        private List<Fight> fights = new ArrayList<>();

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSherdogUrl() { return sherdogUrl; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
        public List<Fight> getFights() { return fights; }
        public void setFights(List<Fight> fights) { this.fights = fights; }
    }

    static class Fight {
        private SherdogBaseObject event;
        private SherdogBaseObject fighter1;
        private SherdogBaseObject fighter2;
        private String result;
        private String winMethod;
        private int winRound;
        private String winTime;
        private Date date;

        public SherdogBaseObject getEvent() { return event; }
        public void setEvent(SherdogBaseObject event) { this.event = event; }
        public SherdogBaseObject getFighter1() { return fighter1; }
        public void setFighter1(SherdogBaseObject fighter1) { this.fighter1 = fighter1; }
        public SherdogBaseObject getFighter2() { return fighter2; }
        public void setFighter2(SherdogBaseObject fighter2) { this.fighter2 = fighter2; }
        public String getResult() { return result; }
        public void setResult(String result) { this.result = result; }
        public String getWinMethod() { return winMethod; }
        public void setWinMethod(String winMethod) { this.winMethod = winMethod; }
        public int getWinRound() { return winRound; }
        public void setWinRound(int winRound) { this.winRound = winRound; }
        public String getWinTime() { return winTime; }
        public void setWinTime(String winTime) { this.winTime = winTime; }
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
    }

    static class SherdogBaseObject {
        private String name;
        private String sherdogUrl;
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSherdogUrl() { return sherdogUrl; }
        public void setSherdogUrl(String sherdogUrl) { this.sherdogUrl = sherdogUrl; }
    }

    static class Date {  }

    

    static class ParserUtils {
        public static String getFightResult(Element element) {
            return "Win";
        }
    }

    

    static class Document {
        public Elements select(String cssQuery) {
            
            List<Element> elements = new ArrayList<>();
            if (cssQuery.equals(".content.event")) {
                Element e = new Element();
                
                
                e.html = "<h3><a href=\"/fighter1\" abs:href=\"http://www.sherdog.com/fighter1\"><span itemprop=\"name\">Fighter One</span></a></h3>" +
                         "<h3><a href=\"/fighter2\" abs:href=\"http://www.sherdog.com/fighter2\"><span itemprop=\"name\">Fighter Two</span></a></h3>" +
                         "<td>Result</td><td>KO</td><td>Unused</td><td>3</td><td>2:30</td>";
                elements.add(e);
            } else if (cssQuery.equals(".event_match table tr")) {
                
                Element row = new Element();
                row.html = "<tr><td>Fighter A</td><td>Fighter B</td></tr>";
                elements.add(row);
            }
            return new Elements(elements);
        }
    }

    static class Elements extends ArrayList<Element> {
        public Elements(Collection<Element> c) { super(c); }
        public Elements() { super(); }
        public String html() { return isEmpty() ? "" : get(0).html(); }
        public Element first() { return isEmpty() ? null : get(0); }
        public Elements select(String cssQuery) {
            
            if (!isEmpty()) {
                Element e = get(0);
                if (cssQuery.equals("h3 a")) {
                    
                    List<Element> links = new ArrayList<>();
                    Pattern p = Pattern.compile("<h3><a href=\"([^\"]+)\" abs:href=\"([^\"]+)\"><span itemprop=\"name\">([^<]+)</span></a></h3>");
                    Matcher m = p.matcher(e.html);
                    while (m.find()) {
                        Element link = new Element();
                        link.attr("abs:href", m.group(2));
                        link.html = "<span itemprop=\"name\">" + m.group(3) + "</span>";
                        links.add(link);
                    }
                    return new Elements(links);
                } else if (cssQuery.equals("td")) {
                    
                    List<Element> tds = new ArrayList<>();
                    Pattern p = Pattern.compile("<td>([^<]+)(?:<em[^>]*>([^<]+)</em>)?</td>");
                    Matcher m = p.matcher(e.html);
                    while (m.find()) {
                        Element td = new Element();
                        String content = m.group(1) + (m.group(2) != null ? m.group(2) : "");
                        td.html = content;
                        tds.add(td);
                    }
                    return new Elements(tds);
                }
            }
            return new Elements();
        }
    }

    static class Element {
        private String html;
        private Map<String, String> attrs = new HashMap<>();
        public Element() { }
        public Element(String html) { this.html = html; }
        public String html() { return html; }
        public Element first() { return this; }
        public String attr(String key) { return attrs.getOrDefault(key, ""); }
        public Element attr(String key, String value) { attrs.put(key, value); return this; }
        public Elements select(String cssQuery) {
            
            if (cssQuery.equals("span[itemprop=\"name\"]")) {
                Pattern p = Pattern.compile("<span itemprop=\"name\">([^<]+)</span>");
                Matcher m = p.matcher(html);
                if (m.find()) {
                    Element span = new Element(m.group(1));
                    return new Elements(Collections.singletonList(span));
                }
            }
            return new Elements();
        }
    }

    

    static class Logger {
        public void info(String msg) { System.out.println("[INFO] " + msg); }
        public void info(String msg, Object... args) { System.out.println("[INFO] " + String.format(msg, args)); }
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
        public void error(String msg) { System.err.println("[ERROR] " + msg); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    

    static class EventParser {
        private static final Logger logger = LoggerFactory.getLogger(EventParser.class);

        
        private List<Fight> parseEventFights(Elements trs, Event event) {
            
            List<Fight> fights = new ArrayList<>();
            if (trs.size() > 0) {
                
                Fight f = new Fight();
                f.setEvent(new SherdogBaseObject());
                f.getEvent().setName(event.getName());
                f.getEvent().setSherdogUrl(event.getSherdogUrl());
                f.setDate(event.getDate());
                SherdogBaseObject f1 = new SherdogBaseObject();
                f1.setName("Fighter A");
                f1.setSherdogUrl("http://example.com/a");
                SherdogBaseObject f2 = new SherdogBaseObject();
                f2.setName("Fighter B");
                f2.setSherdogUrl("http://example.com/b");
                f.setFighter1(f1);
                f.setFighter2(f2);
                f.setResult("Win");
                f.setWinMethod("KO");
                f.setWinRound(1);
                f.setWinTime("1:30");
                fights.add(f);
            }
            return fights;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private void getFights(Document doc, Event event) {
            logger.info("Getting fights for event #{}[{}]", event.getSherdogUrl(), event.getName());

            SherdogBaseObject sEvent = new SherdogBaseObject();
            sEvent.setName(event.getName());
            sEvent.setSherdogUrl(event.getSherdogUrl());

            List<Fight> fights = new ArrayList<>();

            
            Elements mainFightElement = doc.select(".content.event");

            Elements fighters = mainFightElement.select("h3 a");
            
            SherdogBaseObject mainFighter1 = new SherdogBaseObject();
            Element mainFighter1Element = fighters.get(0);
            mainFighter1.setSherdogUrl(mainFighter1Element.attr("abs:href"));
            mainFighter1.setName(mainFighter1Element.select("span[itemprop=\"name\"]").html());

            
            SherdogBaseObject mainFighter2 = new SherdogBaseObject();
            Element mainFighter2Element = fighters.get(1);
            mainFighter2.setSherdogUrl(mainFighter2Element.attr("abs:href"));
            mainFighter2.setName(mainFighter2Element.select("span[itemprop=\"name\"]").html());

            Fight mainFight = new Fight();
            mainFight.setEvent(sEvent);
            mainFight.setFighter1(mainFighter1);
            mainFight.setFighter2(mainFighter2);
            mainFight.setResult(ParserUtils.getFightResult(mainFightElement.first()));

            
            Elements mainTd = mainFightElement.select("td");
            if (mainTd.size() > 0) {
                mainFight.setWinMethod(mainTd.get(1).html().replaceAll("<em(.*)<br>", "").trim());
                mainFight.setWinRound(Integer.parseInt(mainTd.get(3).html().replaceAll("<em(.*)<br>", "").trim()));
                mainFight.setWinTime(mainTd.get(4).html().replaceAll("<em(.*)<br>", "").trim());
            }
            mainFight.setDate(event.getDate());

            fights.add(mainFight);
            logger.info("Fight added: {}", mainFight);
            

            logger.info("Found {} fights", fights.size());

            Elements tds = doc.select(".event_match table tr");

            fights.addAll(parseEventFights(tds, event));

            event.setFights(fights);
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing EventParser.getFights ===\n");

        
        Document doc = new Document();
        Event event = new Event();
        event.setName("UFC 300");
        event.setSherdogUrl("http://www.sherdog.com/events/ufc-300");
        event.setDate(new Date());

        EventParser parser = new EventParser();
        parser.getFights(doc, event);

        System.out.println("Event fights count: " + event.getFights().size());
        if (!event.getFights().isEmpty()) {
            Fight f = event.getFights().get(0);
            System.out.println("Main fight: " + f.getFighter1().getName() + " vs " + f.getFighter2().getName());
            System.out.println("Result: " + f.getResult() + ", Method: " + f.getWinMethod() + ", Round: " + f.getWinRound() + ", Time: " + f.getWinTime());
        }

        System.out.println("\n=== Test completed ===");
    }
}