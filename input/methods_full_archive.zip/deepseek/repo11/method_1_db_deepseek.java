
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentMap;





public class method_1_db_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    
    static class Logger {
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void debug(String msg, Object... args) { System.out.println("[DEBUG] " + String.format(msg, args)); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
        public void error(String msg) { System.err.println("[ERROR] " + msg); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    
    static class GenericObjectPoolConfig {
        private int maxTotal = 8;
        private int maxIdle = 8;
        private int minIdle = 0;
        private long maxWaitMillis = -1;
        private boolean testOnCreate = false;
        private boolean testOnBorrow = false;
        private boolean testOnReturn = false;
        private boolean testWhileIdle = false;
        private long timeBetweenEvictionRunsMillis = -1;
        private int numTestsPerEvictionRun = 3;
        private long minEvictableIdleTimeMillis = 1000 * 60 * 30;
        private long softMinEvictableIdleTimeMillis = -1;
        private boolean lifo = true;

        public void setMaxTotal(int max) { maxTotal = max; }
        public void setMaxIdle(int max) { maxIdle = max; }
        public void setMinIdle(int min) { minIdle = min; }
        public void setMaxWaitMillis(long wait) { maxWaitMillis = wait; }
        public void setTestOnCreate(boolean b) { testOnCreate = b; }
        public void setTestOnBorrow(boolean b) { testOnBorrow = b; }
        public void setTestOnReturn(boolean b) { testOnReturn = b; }
        public void setTestWhileIdle(boolean b) { testWhileIdle = b; }
        public void setTimeBetweenEvictionRunsMillis(long time) { timeBetweenEvictionRunsMillis = time; }
        public void setNumTestsPerEvictionRun(int num) { numTestsPerEvictionRun = num; }
        public void setMinEvictableIdleTimeMillis(long time) { minEvictableIdleTimeMillis = time; }
        public void setSoftMinEvictableIdleTimeMillis(long time) { softMinEvictableIdleTimeMillis = time; }
        public void setLifo(boolean lifo) { this.lifo = lifo; }
    }

    
    static class PoolableConnection { }

    static class PoolingDataSource<T> {
        private GenericObjectPool<T> pool;
        public PoolingDataSource(GenericObjectPool<T> pool) { this.pool = pool; }
        public GenericObjectPool<T> getPool() { return pool; }
    }

    static class DriverManagerConnectionFactory implements ConnectionFactory {
        private String url;
        private Properties props;
        public DriverManagerConnectionFactory(String url, Properties props) { this.url = url; this.props = props; }
        public Connection createConnection() { return null; }
    }

    interface ConnectionFactory {
        Connection createConnection();
    }

    static class Connection { }

    static class PoolableConnectionFactory {
        private ConnectionFactory connFactory;
        private GenericObjectPool<PoolableConnection> pool;
        private boolean defaultAutoCommit;
        private boolean defaultReadOnly;
        private int defaultTransactionIsolation;
        private boolean cacheState;
        private String validationQuery;
        private long maxConnLifetimeMillis;

        public PoolableConnectionFactory(ConnectionFactory connFactory, GenericObjectPool<PoolableConnection> pool) {
            this.connFactory = connFactory;
            this.pool = pool;
        }
        public void setDefaultAutoCommit(boolean autoCommit) { this.defaultAutoCommit = autoCommit; }
        public void setDefaultReadOnly(boolean readOnly) { this.defaultReadOnly = readOnly; }
        public void setDefaultTransactionIsolation(int isolation) { this.defaultTransactionIsolation = isolation; }
        public void setCacheState(boolean cacheState) { this.cacheState = cacheState; }
        public void setValidationQuery(String query) { this.validationQuery = query; }
        public void setMaxConnLifetimeMillis(long lifetime) { this.maxConnLifetimeMillis = lifetime; }
        public void setPool(GenericObjectPool<PoolableConnection> pool) { this.pool = pool; }
    }

    static class GenericObjectPool<T> {
        private PoolableConnectionFactory factory;
        private GenericObjectPoolConfig config;
        public GenericObjectPool(PoolableConnectionFactory factory, GenericObjectPoolConfig config) {
            this.factory = factory;
            this.config = config;
        }
    }

    
    static class ConnectionProperties {
        private int maxTotal;
        private int maxIdle;
        private int minIdle;
        private long maxWaitMillis;
        private boolean testOnCreate;
        private boolean testOnBorrow;
        private boolean testOnReturn;
        private boolean testWhileIdle;
        private long timeBetweenEvictionRunsMillis;
        private int numTestsPerEvictionRun;
        private long minEvictableIdleTimeMillis;
        private long softMinEvictableIdleTimeMillis;
        private boolean lifo;
        private boolean defaultAutoCommit;
        private boolean defaultReadOnly;
        private int defaultTransactionIsolation;
        private boolean cacheState;
        private String validationQuery;
        private long maxConnLifetimeMillis;

        
        public int getMaxTotal() { return maxTotal; }
        public int getMaxIdle() { return maxIdle; }
        public int getMinIdle() { return minIdle; }
        public long getMaxWaitMillis() { return maxWaitMillis; }
        public boolean isTestOnCreate() { return testOnCreate; }
        public boolean isTestOnBorrow() { return testOnBorrow; }
        public boolean isTestOnReturn() { return testOnReturn; }
        public boolean isTestWhileIdle() { return testWhileIdle; }
        public long getTimeBetweenEvictionRunsMillis() { return timeBetweenEvictionRunsMillis; }
        public int getNumTestsPerEvictionRun() { return numTestsPerEvictionRun; }
        public long getMinEvictableIdleTimeMillis() { return minEvictableIdleTimeMillis; }
        public long getSoftMinEvictableIdleTimeMillis() { return softMinEvictableIdleTimeMillis; }
        public boolean isLifo() { return lifo; }
        public boolean isDefaultAutoCommit() { return defaultAutoCommit; }
        public boolean isDefaultReadOnly() { return defaultReadOnly; }
        public int getDefaultTransactionIsolation() { return defaultTransactionIsolation; }
        public boolean isCacheState() { return cacheState; }
        public String getValidationQuery() { return validationQuery; }
        public long getMaxConnLifetimeMillis() { return maxConnLifetimeMillis; }

        
        public void setMaxTotal(int maxTotal) { this.maxTotal = maxTotal; }
        public void setMaxIdle(int maxIdle) { this.maxIdle = maxIdle; }
        public void setMinIdle(int minIdle) { this.minIdle = minIdle; }
        public void setMaxWaitMillis(long maxWaitMillis) { this.maxWaitMillis = maxWaitMillis; }
        public void setTestOnCreate(boolean testOnCreate) { this.testOnCreate = testOnCreate; }
        public void setTestOnBorrow(boolean testOnBorrow) { this.testOnBorrow = testOnBorrow; }
        public void setTestOnReturn(boolean testOnReturn) { this.testOnReturn = testOnReturn; }
        public void setTestWhileIdle(boolean testWhileIdle) { this.testWhileIdle = testWhileIdle; }
        public void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis) { this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis; }
        public void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) { this.numTestsPerEvictionRun = numTestsPerEvictionRun; }
        public void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis) { this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis; }
        public void setSoftMinEvictableIdleTimeMillis(long softMinEvictableIdleTimeMillis) { this.softMinEvictableIdleTimeMillis = softMinEvictableIdleTimeMillis; }
        public void setLifo(boolean lifo) { this.lifo = lifo; }
        public void setDefaultAutoCommit(boolean defaultAutoCommit) { this.defaultAutoCommit = defaultAutoCommit; }
        public void setDefaultReadOnly(boolean defaultReadOnly) { this.defaultReadOnly = defaultReadOnly; }
        public void setDefaultTransactionIsolation(int defaultTransactionIsolation) { this.defaultTransactionIsolation = defaultTransactionIsolation; }
        public void setCacheState(boolean cacheState) { this.cacheState = cacheState; }
        public void setValidationQuery(String validationQuery) { this.validationQuery = validationQuery; }
        public void setMaxConnLifetimeMillis(long maxConnLifetimeMillis) { this.maxConnLifetimeMillis = maxConnLifetimeMillis; }
    }

    

    static class DataSourceFactory {
        private static final Logger LOG = LoggerFactory.getLogger(DataSourceFactory.class);

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private static PoolingDataSource<PoolableConnection> getPoolingDataSource(final String url,
                                                                                  final ConcurrentMap<String, String> properties,
                                                                                  final ConnectionProperties poolSpec) {

            
            assert url != null : "The url cannot be null";
            assert properties != null : "The properties cannot be null";
            assert poolSpec != null : "The pol spec cannot be null";

            LOG.debug("Creating new pooled data source for '" + url + "'");

            
            final Properties props = new Properties();
            props.putAll(properties);

            
            final GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
            poolConfig.setMaxTotal(poolSpec.getMaxTotal());
            poolConfig.setMaxIdle(poolSpec.getMaxIdle());
            poolConfig.setMinIdle(poolSpec.getMinIdle());
            poolConfig.setMaxWaitMillis(poolSpec.getMaxWaitMillis());
            poolConfig.setTestOnCreate(poolSpec.isTestOnCreate());
            poolConfig.setTestOnBorrow(poolSpec.isTestOnBorrow());
            poolConfig.setTestOnReturn(poolSpec.isTestOnReturn());
            poolConfig.setTestWhileIdle(poolSpec.isTestWhileIdle());
            poolConfig.setTimeBetweenEvictionRunsMillis(poolSpec.getTimeBetweenEvictionRunsMillis());
            poolConfig.setNumTestsPerEvictionRun(poolSpec.getNumTestsPerEvictionRun());
            poolConfig.setMinEvictableIdleTimeMillis(poolSpec.getMinEvictableIdleTimeMillis());
            poolConfig.setSoftMinEvictableIdleTimeMillis(poolSpec.getSoftMinEvictableIdleTimeMillis());
            poolConfig.setLifo(poolSpec.isLifo());

            
            final ConnectionFactory connFactory = new DriverManagerConnectionFactory(url, props);
            final PoolableConnectionFactory poolConnFactory = new PoolableConnectionFactory(connFactory, null);
            poolConnFactory.setDefaultAutoCommit(poolSpec.isDefaultAutoCommit());
            poolConnFactory.setDefaultReadOnly(poolSpec.isDefaultReadOnly());
            poolConnFactory.setDefaultTransactionIsolation(poolSpec.getDefaultTransactionIsolation());
            poolConnFactory.setCacheState(poolSpec.isCacheState());
            poolConnFactory.setValidationQuery(poolSpec.getValidationQuery());
            poolConnFactory.setMaxConnLifetimeMillis(poolSpec.getMaxConnLifetimeMillis());
            final GenericObjectPool<PoolableConnection> connPool = new GenericObjectPool<>(poolConnFactory, poolConfig);
            poolConnFactory.setPool(connPool);

            
            return new PoolingDataSource<>(connPool);
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing DataSourceFactory.getPoolingDataSource ===\n");

        
        ConcurrentMap<String, String> props = new java.util.concurrent.ConcurrentHashMap<>();
        props.put("user", "test");
        props.put("password", "secret");

        
        ConnectionProperties poolSpec = new ConnectionProperties();
        poolSpec.setMaxTotal(10);
        poolSpec.setMaxIdle(5);
        poolSpec.setMinIdle(2);
        poolSpec.setMaxWaitMillis(10000);
        poolSpec.setTestOnBorrow(true);
        poolSpec.setTestWhileIdle(true);
        poolSpec.setTimeBetweenEvictionRunsMillis(60000);
        poolSpec.setNumTestsPerEvictionRun(3);
        poolSpec.setMinEvictableIdleTimeMillis(300000);
        poolSpec.setSoftMinEvictableIdleTimeMillis(180000);
        poolSpec.setLifo(true);
        poolSpec.setDefaultAutoCommit(true);
        poolSpec.setDefaultReadOnly(false);
        poolSpec.setDefaultTransactionIsolation(2);
        poolSpec.setCacheState(true);
        poolSpec.setValidationQuery("SELECT 1");
        poolSpec.setMaxConnLifetimeMillis(600000);

        
        PoolingDataSource<PoolableConnection> ds = DataSourceFactory.getPoolingDataSource("jdbc:test", props, poolSpec);
        System.out.println("DataSource created: " + ds);
        System.out.println("Pool: " + ds.getPool());

        System.out.println("\n=== Test completed ===");
    }
}
