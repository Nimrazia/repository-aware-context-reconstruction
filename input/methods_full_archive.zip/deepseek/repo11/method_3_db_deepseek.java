import java.util.*;






public class method_3_db_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    
    static class Logger {
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
        public void error(String msg) { System.err.println("[ERROR] " + msg); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    
    static class Validate {
        public static void notBlank(String str, String msg) {
            if (str == null || str.trim().isEmpty()) throw new IllegalArgumentException(msg);
        }
    }

    
    static class FactoryException extends Exception {
        public FactoryException(String msg) { super(msg); }
        public FactoryException(String msg, Throwable cause) { super(msg, cause); }
    }

    
    interface Context {
        Object lookup(String name) throws NamingException;
        void close() throws NamingException;
    }

    static class InitialContext implements Context {
        private Map<String, Object> bindings = new java.util.concurrent.ConcurrentHashMap<>();

        public InitialContext() {
            
            bindings.put("java:comp/env/jdbc/test", new DataSource() { });
        }

        public Object lookup(String name) throws NamingException {
            if (bindings.containsKey(name)) {
                return bindings.get(name);
            }
            throw new NamingException("Name not found: " + name);
        }

        public void close() throws NamingException {
            
        }
    }

    static class NamingException extends Exception {
        public NamingException(String msg) { super(msg); }
    }

    
    interface DataSource { }

    

    static class DataSourceFactory {
        private static final Logger LOG = LoggerFactory.getLogger(DataSourceFactory.class);

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public static DataSource getDataSource(final String jndiName)
                throws FactoryException {

            Validate.notBlank(jndiName, "The validated character sequence 'jndiName' is null or empty");

            

            try {
                
                final Context context = new InitialContext();

                
                final Object namedObject = context.lookup(jndiName);
                if (DataSource.class.isInstance(namedObject)) {
                    final DataSource dataSource = (DataSource) context.lookup(jndiName);
                    context.close();

                    return dataSource;
                } else {
                    final String error = "The JNDI name '" + jndiName + "' does not reference a SQL DataSource."
                            + " This is a configuration issue.";
                    LOG.warn(error);
                    throw new FactoryException(error);
                }
            } catch (NamingException e) {
                final String error = "Error retrieving JDBC date source from JNDI: " + jndiName;
                LOG.warn(error);
                throw new FactoryException(error, e);
            }
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing DataSourceFactory.getDataSource ===\n");

        try {
            
            DataSource ds = DataSourceFactory.getDataSource("java:comp/env/jdbc/test");
            System.out.println("DataSource retrieved: " + ds);

            
            try {
                DataSourceFactory.getDataSource("invalid");
            } catch (FactoryException e) {
                System.out.println("Expected exception for invalid name: " + e.getMessage());
            }

            
            try {
                DataSourceFactory.getDataSource("");
            } catch (IllegalArgumentException e) {
                System.out.println("Expected exception for empty name: " + e.getMessage());
            }
        } catch (FactoryException e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}
