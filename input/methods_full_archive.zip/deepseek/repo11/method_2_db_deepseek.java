
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;





public class method_2_db_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    
    static class Logger {
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void debug(String msg, Object... args) { System.out.println("[DEBUG] " + String.format(msg, args)); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
        public void error(String msg) { System.err.println("[ERROR] " + msg); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    
    static class StringUtils {
        public static boolean isNotEmpty(String str) { return str != null && !str.isEmpty(); }
        public static boolean isNumeric(String str) {
            if (str == null || str.isEmpty()) return false;
            for (char c : str.toCharArray()) {
                if (!Character.isDigit(c)) return false;
            }
            return true;
        }
        
    }

    static class Validate {
        public static void notNull(Object obj, String msg) {
            if (obj == null) throw new IllegalArgumentException(msg);
        }
        
    }

    
    static class ConnectionProperties {
        
        
        
        private String driver;
        private String url;
        private String username;
        private String password;
        private int maxTotal;
        private int maxIdle;
        private int minIdle;
        private long maxWaitMillis;
        private boolean testOnCreate;
        private boolean testOnBorrow;
        private boolean testOnReturn;
        private boolean testWhileIdle;
        private long timeBetweenEvictionRunsMillis;
        private int numTestsPerEvictionRun;
        private long minEvictableIdleTimeMillis;
        private long softMinEvictableIdleTimeMillis;
        private boolean lifo;
        private boolean defaultAutoCommit;
        private boolean defaultReadOnly;
        private int defaultTransactionIsolation;
        private boolean cacheState;
        private String validationQuery;
        private long maxConnLifetimeMillis;
        private Map<String, String> additionalProperties;

        
        public String getDriver() { return driver; }
        public void setDriver(String driver) { this.driver = driver; }
        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public int getMaxTotal() { return maxTotal; }
        public void setMaxTotal(int maxTotal) { this.maxTotal = maxTotal; }
        public int getMaxIdle() { return maxIdle; }
        public void setMaxIdle(int maxIdle) { this.maxIdle = maxIdle; }
        public int getMinIdle() { return minIdle; }
        public void setMinIdle(int minIdle) { this.minIdle = minIdle; }
        public long getMaxWaitMillis() { return maxWaitMillis; }
        public void setMaxWaitMillis(long maxWaitMillis) { this.maxWaitMillis = maxWaitMillis; }
        public boolean isTestOnCreate() { return testOnCreate; }
        public void setTestOnCreate(boolean testOnCreate) { this.testOnCreate = testOnCreate; }
        public boolean isTestOnBorrow() { return testOnBorrow; }
        public void setTestOnBorrow(boolean testOnBorrow) { this.testOnBorrow = testOnBorrow; }
        public boolean isTestOnReturn() { return testOnReturn; }
        public void setTestOnReturn(boolean testOnReturn) { this.testOnReturn = testOnReturn; }
        public boolean isTestWhileIdle() { return testWhileIdle; }
        public void setTestWhileIdle(boolean testWhileIdle) { this.testWhileIdle = testWhileIdle; }
        public long getTimeBetweenEvictionRunsMillis() { return timeBetweenEvictionRunsMillis; }
        public void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis) { this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis; }
        public int getNumTestsPerEvictionRun() { return numTestsPerEvictionRun; }
        public void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) { this.numTestsPerEvictionRun = numTestsPerEvictionRun; }
        public long getMinEvictableIdleTimeMillis() { return minEvictableIdleTimeMillis; }
        public void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis) { this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis; }
        public long getSoftMinEvictableIdleTimeMillis() { return softMinEvictableIdleTimeMillis; }
        public void setSoftMinEvictableIdleTimeMillis(long softMinEvictableIdleTimeMillis) { this.softMinEvictableIdleTimeMillis = softMinEvictableIdleTimeMillis; }
        public boolean isLifo() { return lifo; }
        public void setLifo(boolean lifo) { this.lifo = lifo; }
        public boolean isDefaultAutoCommit() { return defaultAutoCommit; }
        public void setDefaultAutoCommit(boolean defaultAutoCommit) { this.defaultAutoCommit = defaultAutoCommit; }
        public boolean isDefaultReadOnly() { return defaultReadOnly; }
        public void setDefaultReadOnly(boolean defaultReadOnly) { this.defaultReadOnly = defaultReadOnly; }
        public int getDefaultTransactionIsolation() { return defaultTransactionIsolation; }
        public void setDefaultTransactionIsolation(int defaultTransactionIsolation) { this.defaultTransactionIsolation = defaultTransactionIsolation; }
        public boolean isCacheState() { return cacheState; }
        public void setCacheState(boolean cacheState) { this.cacheState = cacheState; }
        public String getValidationQuery() { return validationQuery; }
        public void setValidationQuery(String validationQuery) { this.validationQuery = validationQuery; }
        public long getMaxConnLifetimeMillis() { return maxConnLifetimeMillis; }
        public void setMaxConnLifetimeMillis(long maxConnLifetimeMillis) { this.maxConnLifetimeMillis = maxConnLifetimeMillis; }
        public Map<String, String> getAdditionalProperties() { return additionalProperties; }
        public void setAdditionalProperties(Map<String, String> additionalProperties) { this.additionalProperties = additionalProperties; }
    }

    

    static class MapBasedConnPropsBuilder {
        private static final Logger LOG = LoggerFactory.getLogger(MapBasedConnPropsBuilder.class);

        
        private static final String DEFAULT_DRIVER = "org.h2.Driver";
        private static final String DEFAULT_URL = "jdbc:h2:mem:test";
        private static final String DEFAULT_USERNAME = "sa";
        private static final String DEFAULT_PASSWORD = "";
        private static final int DEFAULT_MAX_TOTAL = 8;
        private static final int DEFAULT_MAX_IDLE = 8;
        private static final int DEFAULT_MIN_IDLE = 0;
        private static final long DEFAULT_MAX_WAIT_MILLIS = -1;
        private static final boolean DEFAULT_TEST_ON_CREATE = false;
        private static final boolean DEFAULT_TEST_ON_BORROW = false;
        private static final boolean DEFAULT_TEST_ON_RETURN = false;
        private static final boolean DEFAULT_TEST_WHILE_IDLE = false;
        private static final long DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS = -1;
        private static final int DEFAULT_NUM_TESTS_PER_EVICITON_RUN = 3;
        private static final long DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS = 1000 * 60 * 30;
        private static final long DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS = -1;
        private static final boolean DEFAULT_LIFO = true;
        private static final boolean DEFAULT_AUTO_COMMIT = true;
        private static final boolean DEFAULT_READ_ONLY = false;
        private static final int DEFAULT_TRANSACTION_ISOLATION = 2; 
        private static final boolean DEFAULT_CACHE_STATE = true;
        private static final String DEFAULT_VALIDATION_QUERY = "SELECT 1";
        private static final long DEFAULT_MAX_CONN_LIFETIME_MILLIS = -1;

        
        private static final String KEY_DRIVER = "driver";
        private static final String KEY_URL = "url";
        private static final String KEY_USERNAME = "username";
        private static final String KEY_PASSWORD = "password";
        private static final String KEY_MAX_TOTAL = "maxTotal";
        private static final String KEY_MAX_IDLE = "maxIdle";
        private static final String KEY_MIN_IDLE = "minIdle";
        private static final String KEY_MAX_WAIT_MILLIS = "maxWaitMillis";
        private static final String KEY_TEST_ON_CREATE = "testOnCreate";
        private static final String KEY_TEST_ON_BORROW = "testOnBorrow";
        private static final String KEY_TEST_ON_RETURN = "testOnReturn";
        private static final String KEY_TEST_WHILE_IDLE = "testWhileIdle";
        private static final String KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS = "timeBetweenEvictionRunsMillis";
        private static final String KEY_NUM_TESTS_PER_EVICTION_RUN = "numTestsPerEvictionRun";
        private static final String KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS = "minEvictableIdleTimeMillis";
        private static final String KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS = "softMinEvictableIdleTimeMillis";
        private static final String KEY_LIFO = "lifo";
        private static final String KEY_AUTO_COMMIT = "defaultAutoCommit";
        private static final String KEY_READ_ONLY = "defaultReadOnly";
        private static final String KEY_TRANSACTION_ISOLATION = "defaultTransactionIsolation";
        private static final String KEY_CACHE_STATE = "cacheState";
        private static final String KEY_VALIDATION_QUERY = "validationQuery";
        private static final String KEY_MAX_CONN_LIFETIME_MILLIS = "maxConnLifetimeMillis";

        
        private static void logValue(String key, String value) {
            LOG.debug("Set " + key + " = " + value);
        }
        private static void logDefault(String key, String value) {
            LOG.debug("Default " + key + " = " + value);
        }
        private static void logDefault(String key, String value, String reason, String def) {
            LOG.debug("Default " + key + " = " + def + " because " + reason + " for value " + value);
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        @SuppressWarnings({"PMD.ExcessiveMethodLength", "PMD.NPathComplexity", "PMD.NcssMethodCount", "PMD.CyclomaticComplexity", "PMD.StdCyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity"})
        public static ConnectionProperties build(final Map<String, String> properties) {

            Validate.notNull(properties, "The validated object 'properties' is null");

            final ConnectionProperties connProps = new ConnectionProperties();
            String tmp = properties.get(KEY_DRIVER);
            if (StringUtils.isNotEmpty(tmp)) { 
                connProps.setDriver(tmp);
                logValue(KEY_DRIVER, tmp);
            } else {
                connProps.setDriver(DEFAULT_DRIVER);
                logDefault(KEY_DRIVER, DEFAULT_DRIVER);
            }

            tmp = properties.get(KEY_URL);
            if (StringUtils.isNotEmpty(tmp)) { 
                connProps.setUrl(tmp);
                logValue(KEY_URL, tmp);
            } else {
                connProps.setUrl(DEFAULT_URL);
                logDefault(KEY_URL, DEFAULT_URL);
            }

            tmp = properties.get(KEY_USERNAME);
            if (tmp == null) { 
                connProps.setUsername(DEFAULT_USERNAME);
                logDefault(KEY_USERNAME, DEFAULT_USERNAME);
            } else {
                connProps.setUsername(tmp);
                logValue(KEY_USERNAME, tmp);
            }

            tmp = properties.get(KEY_PASSWORD);
            if (tmp == null) { 
                connProps.setPassword(DEFAULT_PASSWORD);
                logDefault(KEY_PASSWORD, DEFAULT_PASSWORD);
            } else {
                connProps.setPassword(tmp);
                logValue(KEY_PASSWORD, tmp);
            }

            tmp = properties.get(KEY_MAX_TOTAL);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setMaxTotal(Integer.decode(tmp));
                    logValue(KEY_MAX_TOTAL, tmp);
                } else {
                    connProps.setMaxTotal(DEFAULT_MAX_TOTAL);
                    logDefault(KEY_MAX_TOTAL, tmp, "not numeric", String.valueOf(DEFAULT_MAX_TOTAL));
                }
            } else {
                connProps.setMaxTotal(DEFAULT_MAX_TOTAL);
                logDefault(KEY_MAX_TOTAL, String.valueOf(DEFAULT_MAX_TOTAL));
            }

            tmp = properties.get(KEY_MAX_IDLE);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setMaxIdle(Integer.decode(tmp));
                    logValue(KEY_MAX_IDLE, tmp);
                } else {
                    connProps.setMaxIdle(DEFAULT_MAX_IDLE);
                    logDefault(KEY_MAX_IDLE, tmp, "not numeric", String.valueOf(DEFAULT_MAX_IDLE));
                }
            } else {
                connProps.setMaxIdle(DEFAULT_MAX_IDLE);
                logDefault(KEY_MAX_IDLE, String.valueOf(DEFAULT_MAX_IDLE));
            }

            tmp = properties.get(KEY_MIN_IDLE);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setMinIdle(Integer.decode(tmp));
                    logValue(KEY_MIN_IDLE, tmp);
                } else {
                    connProps.setMinIdle(DEFAULT_MIN_IDLE);
                    logDefault(KEY_MIN_IDLE, tmp, "not numeric", String.valueOf(DEFAULT_MIN_IDLE));
                }
            } else {
                connProps.setMinIdle(DEFAULT_MIN_IDLE);
                logDefault(KEY_MIN_IDLE, String.valueOf(DEFAULT_MIN_IDLE));
            }

            tmp = properties.get(KEY_MAX_WAIT_MILLIS);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setMaxWaitMillis(Long.decode(tmp));
                    logValue(KEY_MAX_WAIT_MILLIS, tmp);
                } else {
                    connProps.setMaxWaitMillis(DEFAULT_MAX_WAIT_MILLIS);
                    logDefault(KEY_MAX_WAIT_MILLIS, tmp, "not numeric", String.valueOf(DEFAULT_MAX_WAIT_MILLIS));
                }
            } else {
                connProps.setMaxWaitMillis(DEFAULT_MAX_WAIT_MILLIS);
                logDefault(KEY_MAX_WAIT_MILLIS, String.valueOf(DEFAULT_MAX_WAIT_MILLIS));
            }

            tmp = properties.get(KEY_TEST_ON_CREATE);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setTestOnCreate(Boolean.parseBoolean(tmp));
                logValue(KEY_TEST_ON_CREATE, tmp);
            } else {
                connProps.setTestOnCreate(DEFAULT_TEST_ON_CREATE);
                logDefault(KEY_TEST_ON_CREATE, String.valueOf(DEFAULT_TEST_ON_CREATE));
            }

            tmp = properties.get(KEY_TEST_ON_BORROW);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setTestOnBorrow(Boolean.parseBoolean(tmp));
                logValue(KEY_TEST_ON_BORROW, tmp);
            } else {
                connProps.setTestOnBorrow(DEFAULT_TEST_ON_BORROW);
                logDefault(KEY_TEST_ON_BORROW, String.valueOf(DEFAULT_TEST_ON_BORROW));
            }

            tmp = properties.get(KEY_TEST_ON_RETURN);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setTestOnReturn(Boolean.parseBoolean(tmp));
                logValue(KEY_TEST_ON_RETURN, tmp);
            } else {
                connProps.setTestOnReturn(DEFAULT_TEST_ON_RETURN);
                logDefault(KEY_TEST_ON_RETURN, String.valueOf(DEFAULT_TEST_ON_RETURN));
            }

            tmp = properties.get(KEY_TEST_WHILE_IDLE);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setTestWhileIdle(Boolean.parseBoolean(tmp));
                logValue(KEY_TEST_WHILE_IDLE, tmp);
            } else {
                connProps.setTestWhileIdle(DEFAULT_TEST_WHILE_IDLE);
                logDefault(KEY_TEST_WHILE_IDLE, String.valueOf(DEFAULT_TEST_WHILE_IDLE));
            }

            tmp = properties.get(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setTimeBetweenEvictionRunsMillis(Long.decode(tmp));
                    logValue(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS, tmp);
                } else {
                    connProps.setTimeBetweenEvictionRunsMillis(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
                    logDefault(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS, tmp, "not numeric",
                            String.valueOf(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
                }
            } else {
                connProps.setTimeBetweenEvictionRunsMillis(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS);
                logDefault(KEY_TIME_BETWEEN_EVICTION_RUNS_MILLIS,
                        String.valueOf(DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS));
            }

            tmp = properties.get(KEY_NUM_TESTS_PER_EVICTION_RUN);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setNumTestsPerEvictionRun(Integer.decode(tmp));
                    logValue(KEY_NUM_TESTS_PER_EVICTION_RUN, tmp);
                } else {
                    connProps.setNumTestsPerEvictionRun(DEFAULT_NUM_TESTS_PER_EVICITON_RUN);
                    logDefault(KEY_NUM_TESTS_PER_EVICTION_RUN, tmp, "not numeric",
                            String.valueOf(DEFAULT_NUM_TESTS_PER_EVICITON_RUN));
                }
            } else {
                connProps.setNumTestsPerEvictionRun(DEFAULT_NUM_TESTS_PER_EVICITON_RUN);
                logDefault(KEY_NUM_TESTS_PER_EVICTION_RUN, String.valueOf(DEFAULT_NUM_TESTS_PER_EVICITON_RUN));
            }

            tmp = properties.get(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setMinEvictableIdleTimeMillis(Long.decode(tmp));
                    logValue(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp);
                } else {
                    connProps.setMinEvictableIdleTimeMillis(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
                    logDefault(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp, "not numeric",
                            String.valueOf(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
                }
            } else {
                connProps.setMinEvictableIdleTimeMillis(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
                logDefault(KEY_MIN_EVICTABLE_IDLE_TIME_MILLIS, String.valueOf(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
            }

            tmp = properties.get(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setSoftMinEvictableIdleTimeMillis(Long.decode(tmp));
                    logValue(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp);
                } else {
                    connProps.setSoftMinEvictableIdleTimeMillis(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
                    logDefault(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS, tmp, "not numeric",
                            String.valueOf(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
                }
            } else {
                connProps.setSoftMinEvictableIdleTimeMillis(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
                logDefault(KEY_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS,
                        String.valueOf(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS));
            }

            tmp = properties.get(KEY_LIFO);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setLifo(Boolean.parseBoolean(tmp));
                logValue(KEY_LIFO, tmp);
            } else {
                connProps.setLifo(DEFAULT_LIFO);
                logDefault(KEY_LIFO, String.valueOf(DEFAULT_LIFO));
            }

            tmp = properties.get(KEY_AUTO_COMMIT);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setDefaultAutoCommit(Boolean.parseBoolean(tmp));
                logValue(KEY_AUTO_COMMIT, tmp);
            } else {
                connProps.setDefaultAutoCommit(DEFAULT_AUTO_COMMIT);
                logDefault(KEY_AUTO_COMMIT, String.valueOf(DEFAULT_AUTO_COMMIT));
            }

            tmp = properties.get(KEY_READ_ONLY);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setDefaultReadOnly(Boolean.parseBoolean(tmp));
                logValue(KEY_READ_ONLY, tmp);
            } else {
                connProps.setDefaultReadOnly(DEFAULT_READ_ONLY);
                logDefault(KEY_READ_ONLY, String.valueOf(DEFAULT_READ_ONLY));
            }

            tmp = properties.get(KEY_TRANSACTION_ISOLATION);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setDefaultTransactionIsolation(Integer.decode(tmp));
                    logValue(KEY_TRANSACTION_ISOLATION, tmp);
                } else {
                    connProps.setDefaultTransactionIsolation(DEFAULT_TRANSACTION_ISOLATION);
                    logDefault(KEY_TRANSACTION_ISOLATION, tmp, "not numeric",
                            String.valueOf(DEFAULT_TRANSACTION_ISOLATION));
                }
            } else {
                connProps.setDefaultTransactionIsolation(DEFAULT_TRANSACTION_ISOLATION);
                logDefault(KEY_TRANSACTION_ISOLATION, String.valueOf(DEFAULT_TRANSACTION_ISOLATION));
            }

            tmp = properties.get(KEY_CACHE_STATE);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setCacheState(Boolean.parseBoolean(tmp));
                logValue(KEY_CACHE_STATE, tmp);
            } else {
                connProps.setCacheState(DEFAULT_CACHE_STATE);
                logDefault(KEY_CACHE_STATE, String.valueOf(DEFAULT_CACHE_STATE));
            }

            tmp = properties.get(KEY_VALIDATION_QUERY);
            if (StringUtils.isNotEmpty(tmp)) {
                connProps.setValidationQuery(tmp);
                logValue(KEY_VALIDATION_QUERY, tmp);
            } else {
                connProps.setValidationQuery(DEFAULT_VALIDATION_QUERY);
                logDefault(KEY_VALIDATION_QUERY, DEFAULT_VALIDATION_QUERY);
            }

            tmp = properties.get(KEY_MAX_CONN_LIFETIME_MILLIS);
            if (StringUtils.isNotEmpty(tmp)) {
                if (StringUtils.isNumeric(tmp)) {
                    connProps.setMaxConnLifetimeMillis(Long.decode(tmp));
                    logValue(KEY_MAX_CONN_LIFETIME_MILLIS, tmp);
                } else {
                    connProps.setMaxConnLifetimeMillis(DEFAULT_MAX_CONN_LIFETIME_MILLIS);
                    logDefault(KEY_MAX_CONN_LIFETIME_MILLIS, tmp, "not numeric",
                            String.valueOf(DEFAULT_MAX_CONN_LIFETIME_MILLIS));
                }
            } else {
                connProps.setMaxConnLifetimeMillis(DEFAULT_MAX_CONN_LIFETIME_MILLIS);
                logDefault(KEY_MAX_CONN_LIFETIME_MILLIS, String.valueOf(DEFAULT_MAX_CONN_LIFETIME_MILLIS));
            }

            
            
            final Map<String, String> tempMap = new ConcurrentHashMap<>();
            for (final Map.Entry<String, String> entry : properties.entrySet()) {
                final String key = entry.getKey();
                final String value = entry.getValue();

                if (value != null) {
                    tempMap.put(key, value);
                }
            }
            connProps.setAdditionalProperties(tempMap);

            return connProps;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing MapBasedConnPropsBuilder.build ===\n");

        
        Map<String, String> props = new ConcurrentHashMap<>();
        props.put("driver", "org.postgresql.Driver");
        props.put("url", "jdbc:postgresql://localhost/test");
        props.put("username", "testuser");
        props.put("password", "testpass");
        props.put("maxTotal", "20");
        props.put("maxIdle", "10");
        props.put("testOnBorrow", "true");
        props.put("defaultAutoCommit", "false");

        ConnectionProperties connProps = MapBasedConnPropsBuilder.build(props);
        System.out.println("Built ConnectionProperties:");
        System.out.println("  Driver: " + connProps.getDriver());
        System.out.println("  URL: " + connProps.getUrl());
        System.out.println("  Username: " + connProps.getUsername());
        System.out.println("  MaxTotal: " + connProps.getMaxTotal());
        System.out.println("  MaxIdle: " + connProps.getMaxIdle());
        System.out.println("  TestOnBorrow: " + connProps.isTestOnBorrow());
        System.out.println("  DefaultAutoCommit: " + connProps.isDefaultAutoCommit());
        System.out.println("  AdditionalProperties size: " + connProps.getAdditionalProperties().size());

        System.out.println("\n=== Test completed ===");
    }
}
