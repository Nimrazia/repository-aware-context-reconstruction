
import org.xml.sax.Attributes;
import java.util.*;






public class method_1_ojb_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    
    static class Logger {
        public boolean isDebugEnabled() { return true; }
        public void debug(Object msg) { System.out.println("[DEBUG] " + msg); }
        public void error(Object msg) { System.err.println("[ERROR] " + msg); }
        public void error(Object msg, Throwable t) { System.err.println("[ERROR] " + msg); t.printStackTrace(); }
        public void info(Object msg) { System.out.println("[INFO] " + msg); }
    }

    
    static class MetadataException extends RuntimeException {
        public MetadataException(String msg) { super(msg); }
        public MetadataException(String msg, Throwable cause) { super(msg, cause); }
    }

    
    interface AttributeContainer {
        void addAttribute(String name, String value);
    }

    
    static class TagConstants {
        
        public static final int MAPPING_REPOSITORY = 1;
        public static final int CLASS_DESCRIPTOR = 2;
        public static final int OBJECT_CACHE = 3;
        public static final int CLASS_EXTENT = 4;
        public static final int FIELD_DESCRIPTOR = 5;
        public static final int REFERENCE_DESCRIPTOR = 6;
        public static final int FOREIGN_KEY = 7;
        public static final int COLLECTION_DESCRIPTOR = 8;
        public static final int ORDERBY = 9;
        public static final int INVERSE_FK = 10;
        public static final int FK_POINTING_TO_THIS_CLASS = 11;
        public static final int FK_POINTING_TO_ITEMS_CLASS = 12;
        public static final int ATTRIBUTE = 13;
        public static final int QUERY_CUSTOMIZER = 14;
        public static final int INDEX_DESCRIPTOR = 15;
        public static final int INDEX_COLUMN = 16;
        public static final int INSERT_PROCEDURE = 17;
        public static final int UPDATE_PROCEDURE = 18;
        public static final int DELETE_PROCEDURE = 19;
        public static final int CONSTANT_ARGUMENT = 20;
        public static final int RUNTIME_ARGUMENT = 21;
        

        public String getTagById(int id) {
            switch (id) {
                case MAPPING_REPOSITORY: return "mapping-repository";
                case CLASS_DESCRIPTOR: return "class-descriptor";
                case OBJECT_CACHE: return "object-cache";
                case CLASS_EXTENT: return "class-extent";
                case FIELD_DESCRIPTOR: return "field-descriptor";
                case REFERENCE_DESCRIPTOR: return "reference-descriptor";
                case FOREIGN_KEY: return "foreign-key";
                case COLLECTION_DESCRIPTOR: return "collection-descriptor";
                case ORDERBY: return "orderby";
                case INVERSE_FK: return "inverse-fk";
                case FK_POINTING_TO_THIS_CLASS: return "fk-pointing-to-this-class";
                case FK_POINTING_TO_ITEMS_CLASS: return "fk-pointing-to-items-class";
                case ATTRIBUTE: return "attribute";
                case QUERY_CUSTOMIZER: return "query-customizer";
                case INDEX_DESCRIPTOR: return "index-descriptor";
                case INDEX_COLUMN: return "index-column";
                case INSERT_PROCEDURE: return "insert-procedure";
                case UPDATE_PROCEDURE: return "update-procedure";
                case DELETE_PROCEDURE: return "delete-procedure";
                case CONSTANT_ARGUMENT: return "constant-argument";
                case RUNTIME_ARGUMENT: return "runtime-argument";
                default: return "unknown";
            }
        }
    }

    
    static class RepositoryElements {
        public static final String TAG_ACCESS_ANONYMOUS = "anonymous";
    }

    
    static class LockHelper {
        public static int getIsolationLevelFor(String iso) {
            if (iso == null) return 0;
            if (iso.equalsIgnoreCase("READ_COMMITTED")) return 1;
            if (iso.equalsIgnoreCase("SERIALIZABLE")) return 2;
            return 0;
        }
    }

    
    static class ClassHelper {
        public static Class getClass(String className) throws ClassNotFoundException {
            try {
                return Class.forName(className);
            } catch (ClassNotFoundException e) {
                
                return Object.class;
            }
        }
        public static Object newInstance(String className) {
            try {
                return Class.forName(className).newInstance();
            } catch (Exception e) {
                return null;
            }
        }
        public static Object newInstance(Class clazz) {
            try {
                return clazz.newInstance();
            } catch (Exception e) {
                return null;
            }
        }
    }

    
    static class PersistentField {
        
    }

    
    static class PersistentFieldFactory {
        public static PersistentField createPersistentField(String pfClassName, Class clazz, String fieldName) {
            return new PersistentField();
        }
    }

    
    static class DescriptorRepository implements AttributeContainer {
        private int defaultIsolationLevel;
        private Map<String, ClassDescriptor> classMap = new HashMap<>();
        private Map<String, String> attributes = new HashMap<>();

        public void setDefaultIsolationLevel(int level) { this.defaultIsolationLevel = level; }
        public void put(String className, ClassDescriptor cld) { classMap.put(className, cld); }
        public ClassDescriptor get(String className) { return classMap.get(className); }
        public void addAttribute(String name, String value) { attributes.put(name, value); }
        public static String getVersion() { return "1.0"; } 
    }

    
    static class Descriptor implements AttributeContainer {
        private Map<String, String> attributes = new HashMap<>();
        public void addAttribute(String name, String value) { attributes.put(name, value); }
        public Map<String, String> getAttributes() { return attributes; }
    }

    
    static class ClassDescriptor extends Descriptor {
        public static final String DYNAMIC_STR = "dynamic";
        private DescriptorRepository repository;
        private Class classOfObject;
        private String tableName;
        private int isolationLevel;
        private String proxyClassName;
        private int proxyPrefetchingLimit;
        private String rowReader;
        private String superClass;
        private boolean acceptLocks;
        private String initializationMethod;
        private String factoryClass;
        private String factoryMethod;
        private boolean alwaysRefresh;
        private String persistentFieldClassName;
        private ObjectCacheDescriptor objectCacheDescriptor;
        private List<String> extentClasses = new ArrayList<>();
        private List<FieldDescriptor> fieldDescriptors = new ArrayList<>();
        private List<ObjectReferenceDescriptor> objectReferenceDescriptors = new ArrayList<>();
        private List<CollectionDescriptor> collectionDescriptors = new ArrayList<>();
        private boolean isInterface;
        private String schema;

        public ClassDescriptor(DescriptorRepository repo) { this.repository = repo; }

        public void setClassOfObject(Class clazz) { this.classOfObject = clazz; }
        public Class getClassOfObject() { return classOfObject; }
        public String getClassNameOfObject() { return classOfObject != null ? classOfObject.getName() : null; }
        public void setTableName(String table) { this.tableName = table; }
        public void setIsolationLevel(int level) { this.isolationLevel = level; }
        public void setProxyClassName(String proxy) { this.proxyClassName = proxy; }
        public void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
        public void setRowReader(String reader) { this.rowReader = reader; }
        public void setSuperClass(String sc) { this.superClass = sc; }
        public void setAcceptLocks(boolean b) { this.acceptLocks = b; }
        public void setInitializationMethod(String method) { this.initializationMethod = method; }
        public void setFactoryClass(String fc) { this.factoryClass = fc; }
        public void setFactoryMethod(String fm) { this.factoryMethod = fm; }
        public void setAlwaysRefresh(boolean b) { this.alwaysRefresh = b; }
        public void setPersistentFieldClassName(String pf) { this.persistentFieldClassName = pf; }
        public String getPersistentFieldClassName() { return persistentFieldClassName; }
        public void setObjectCacheDescriptor(ObjectCacheDescriptor ocd) { this.objectCacheDescriptor = ocd; }
        public void addExtentClass(String clazz) { extentClasses.add(clazz); }
        public void addFieldDescriptor(FieldDescriptor fd) { fieldDescriptors.add(fd); }
        public void addObjectReferenceDescriptor(ObjectReferenceDescriptor ord) { objectReferenceDescriptors.add(ord); }
        public void addCollectionDescriptor(CollectionDescriptor cd) { collectionDescriptors.add(cd); }
        public void setIsInterface(boolean b) { isInterface = b; }
        public int getProxyPrefetchingLimit() { return proxyPrefetchingLimit; }
        public void setSchema(String schema) { this.schema = schema; }
    }

    
    static class FieldDescriptor extends Descriptor {
        private ClassDescriptor parent;
        private int id;
        private String access;
        private PersistentField persistentField;
        private String columnName;
        private String columnType;
        private boolean primaryKey;
        private boolean required;
        private boolean indexed;
        private boolean autoIncrement;
        private String sequenceName;
        private boolean locking;
        private boolean updateLock;
        private String fieldConversionClassName;
        private int length = -1;
        private boolean lengthSpecified;
        private int precision = -1;
        private boolean precisionSpecified;
        private int scale = -1;
        private boolean scaleSpecified;

        public FieldDescriptor(ClassDescriptor parent, int id) { this.parent = parent; this.id = id; }
        public void setAccess(String access) { this.access = access; }
        public void setPersistentField(PersistentField pf) { this.persistentField = pf; }
        public void setColumnName(String col) { this.columnName = col; }
        public void setColumnType(String type) { this.columnType = type; }
        public void setPrimaryKey(boolean pk) { this.primaryKey = pk; }
        public void setRequired(boolean req) { this.required = req; }
        public void setIndexed(boolean idx) { this.indexed = idx; }
        public void setAutoIncrement(boolean ai) { this.autoIncrement = ai; }
        public void setSequenceName(String seq) { this.sequenceName = seq; }
        public void setLocking(boolean lock) { this.locking = lock; }
        public void setUpdateLock(boolean ul) { this.updateLock = ul; }
        public void setFieldConversionClassName(String fcc) { this.fieldConversionClassName = fcc; }
        public void setLength(int len) { this.length = len; }
        public void setLengthSpecified(boolean s) { this.lengthSpecified = s; }
        public void setPrecision(int p) { this.precision = p; }
        public void setPrecisionSpecified(boolean s) { this.precisionSpecified = s; }
        public void setScale(int s) { this.scale = s; }
        public void setScaleSpecified(boolean s) { this.scaleSpecified = s; }
    }

    
    static class AnonymousFieldDescriptor extends FieldDescriptor {
        public AnonymousFieldDescriptor(ClassDescriptor parent, int id) { super(parent, id); }
        public void setPersistentField(PersistentField pf, String fieldName) {
            setPersistentField(pf);
        }
    }

    
    static class ObjectReferenceDescriptor extends Descriptor {
        private ClassDescriptor parent;
        private PersistentField persistentField;
        private Class itemClass;
        private boolean lazy;
        private int proxyPrefetchingLimit;
        private boolean refresh;
        private boolean cascadeRetrieve;
        private String cascadingStore;
        private String cascadingDelete;
        private boolean otmDependent;
        private List<Object> foreignKeys = new ArrayList<>();

        public ObjectReferenceDescriptor(ClassDescriptor parent) { this.parent = parent; }
        public void setPersistentField(PersistentField pf) { this.persistentField = pf; }
        public void setItemClass(Class clazz) { this.itemClass = clazz; }
        public void setLazy(boolean lazy) { this.lazy = lazy; }
        public void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
        public void setRefresh(boolean ref) { this.refresh = ref; }
        public void setCascadeRetrieve(boolean cr) { this.cascadeRetrieve = cr; }
        public void setCascadingStore(String cs) { this.cascadingStore = cs; }
        public void setCascadingDelete(String cd) { this.cascadingDelete = cd; }
        public void setOtmDependent(boolean od) { this.otmDependent = od; }
        public void addForeignKeyField(int id) { foreignKeys.add(id); }
        public void addForeignKeyField(String ref) { foreignKeys.add(ref); }
    }

    
    static class SuperReferenceDescriptor extends ObjectReferenceDescriptor {
        public SuperReferenceDescriptor(ClassDescriptor parent) { super(parent); }
    }

    
    static class CollectionDescriptor extends Descriptor {
        private ClassDescriptor parent;
        private PersistentField persistentField;
        private Class collectionClass;
        private Class itemClass;
        private List<OrderBy> orderBys = new ArrayList<>();
        private String indirectionTable;
        private boolean lazy;
        private int proxyPrefetchingLimit;
        private boolean refresh;
        private boolean cascadeRetrieve;
        private String cascadingStore;
        private String cascadingDelete;
        private boolean otmDependent;
        private QueryCustomizer queryCustomizer;
        private List<Object> foreignKeys = new ArrayList<>();
        private List<String> fkToThisClass = new ArrayList<>();
        private List<String> fkToItemClass = new ArrayList<>();

        public CollectionDescriptor(ClassDescriptor parent) { this.parent = parent; }
        public void setPersistentField(PersistentField pf) { this.persistentField = pf; }
        public void setCollectionClass(Class clazz) { this.collectionClass = clazz; }
        public void setItemClass(Class clazz) { this.itemClass = clazz; }
        public void addOrderBy(String field, boolean asc) { orderBys.add(new OrderBy(field, asc)); }
        public void setIndirectionTable(String table) { this.indirectionTable = table; }
        public void setLazy(boolean lazy) { this.lazy = lazy; }
        public void setProxyPrefetchingLimit(int limit) { this.proxyPrefetchingLimit = limit; }
        public void setRefresh(boolean ref) { this.refresh = ref; }
        public void setCascadeRetrieve(boolean cr) { this.cascadeRetrieve = cr; }
        public void setCascadingStore(String cs) { this.cascadingStore = cs; }
        public void setCascadingDelete(String cd) { this.cascadingDelete = cd; }
        public void setOtmDependent(boolean od) { this.otmDependent = od; }
        public void setQueryCustomizer(QueryCustomizer qc) { this.queryCustomizer = qc; }
        public void addForeignKeyField(int id) { foreignKeys.add(id); }
        public void addForeignKeyField(String ref) { foreignKeys.add(ref); }
        public void addFkToThisClass(String col) { fkToThisClass.add(col); }
        public void addFkToItemClass(String col) { fkToItemClass.add(col); }

        static class OrderBy {
            String field; boolean asc;
            OrderBy(String f, boolean a) { field = f; asc = a; }
        }
    }

    
    static class IndexDescriptor extends Descriptor {
        private String name;
        private boolean unique;
        private List<String> indexColumns = new ArrayList<>();
        public void setName(String n) { this.name = n; }
        public void setUnique(boolean u) { this.unique = u; }
        public List<String> getIndexColumns() { return indexColumns; }
    }

    
    static class ObjectCacheDescriptor extends Descriptor {
        private Class objectCache;
        public void setObjectCache(Class clazz) { this.objectCache = clazz; }
    }

    
    interface QueryCustomizer extends AttributeContainer { }

    
    static class ProcedureDescriptor extends Descriptor {
        protected ClassDescriptor classDescriptor;
        protected String procedureName;
        protected boolean includeAllFields;
        protected String returnValueFieldRef;
        protected List<ArgumentDescriptor> arguments = new ArrayList<>();

        public ProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAll) {
            this.classDescriptor = cld;
            this.procedureName = name;
            this.includeAllFields = includeAll;
        }
        public void setReturnValueFieldRef(String ref) { this.returnValueFieldRef = ref; }
        public void addArgument(ArgumentDescriptor arg) { arguments.add(arg); }
    }

    static class InsertProcedureDescriptor extends ProcedureDescriptor {
        public InsertProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAll) {
            super(cld, name, includeAll);
        }
    }
    static class UpdateProcedureDescriptor extends ProcedureDescriptor {
        public UpdateProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAll) {
            super(cld, name, includeAll);
        }
    }
    static class DeleteProcedureDescriptor extends ProcedureDescriptor {
        public DeleteProcedureDescriptor(ClassDescriptor cld, String name, boolean includeAllPk) {
            super(cld, name, includeAllPk);
        }
    }

    static class ArgumentDescriptor extends Descriptor {
        private ProcedureDescriptor procedure;
        private Object value;
        public ArgumentDescriptor(ProcedureDescriptor proc) { this.procedure = proc; }
        public void setValue(Object val) { this.value = val; }
        public void setValue(String fieldRef, boolean isReturn) {  }
    }

    
    static class AttributesStub implements Attributes {
        private Map<String, String> attrs = new HashMap<>();

        public void setAttribute(String qName, String value) { attrs.put(qName, value); }

        @Override public int getLength() { return attrs.size(); }
        @Override public String getURI(int index) { return null; }
        @Override public String getLocalName(int index) { return null; }
        @Override public String getQName(int index) { return (String) attrs.keySet().toArray()[index]; }
        @Override public String getType(int index) { return "CDATA"; }
        @Override public String getValue(int index) { return (String) attrs.values().toArray()[index]; }
        @Override public int getIndex(String uri, String localName) { return -1; }
        @Override public int getIndex(String qName) { return -1; }
        @Override public String getType(String uri, String localName) { return "CDATA"; }
        @Override public String getType(String qName) { return "CDATA"; }
        @Override public String getValue(String uri, String localName) { return attrs.get(localName); }
        @Override public String getValue(String qName) { return attrs.get(qName); }
    }

    

    
    static class RepositoryXmlHandler {
        private static Logger logger = new Logger(); 
        private TagConstants tags = new TagConstants(); 
        private DescriptorRepository m_repository = new DescriptorRepository();
        private ClassDescriptor m_CurrentCLD;
        private FieldDescriptor m_CurrentFLD;
        private ObjectReferenceDescriptor m_CurrentORD;
        private CollectionDescriptor m_CurrentCOD;
        private ProcedureDescriptor m_CurrentProcedure;
        private IndexDescriptor m_CurrentIndexDescriptor;
        private AttributeContainer m_CurrentAttrContainer;
        private int m_lastId = 0;
        private int defProxyPrefetchingLimit = 10;
        private String m_CurrentString;

        private boolean checkString(String s) {
            return s != null && !s.trim().isEmpty();
        }

        private int getLiteralId(String qName) {
            
            switch (qName) {
                case "mapping-repository": return TagConstants.MAPPING_REPOSITORY;
                case "class-descriptor": return TagConstants.CLASS_DESCRIPTOR;
                case "object-cache": return TagConstants.OBJECT_CACHE;
                case "class-extent": return TagConstants.CLASS_EXTENT;
                case "field-descriptor": return TagConstants.FIELD_DESCRIPTOR;
                case "reference-descriptor": return TagConstants.REFERENCE_DESCRIPTOR;
                case "foreign-key": return TagConstants.FOREIGN_KEY;
                case "collection-descriptor": return TagConstants.COLLECTION_DESCRIPTOR;
                case "orderby": return TagConstants.ORDERBY;
                case "inverse-fk": return TagConstants.INVERSE_FK;
                case "fk-pointing-to-this-class": return TagConstants.FK_POINTING_TO_THIS_CLASS;
                case "fk-pointing-to-items-class": return TagConstants.FK_POINTING_TO_ITEMS_CLASS;
                case "attribute": return TagConstants.ATTRIBUTE;
                case "query-customizer": return TagConstants.QUERY_CUSTOMIZER;
                case "index-descriptor": return TagConstants.INDEX_DESCRIPTOR;
                case "index-column": return TagConstants.INDEX_COLUMN;
                case "insert-procedure": return TagConstants.INSERT_PROCEDURE;
                case "update-procedure": return TagConstants.UPDATE_PROCEDURE;
                case "delete-procedure": return TagConstants.DELETE_PROCEDURE;
                case "constant-argument": return TagConstants.CONSTANT_ARGUMENT;
                case "runtime-argument": return TagConstants.RUNTIME_ARGUMENT;
                default: return -1;
            }
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public void startElement(String uri, String name, String qName, Attributes atts)
        {
            boolean isDebug = logger.isDebugEnabled();

            m_CurrentString = null;
            try
            {
                switch (getLiteralId(qName))
                {
                    case TagConstants.MAPPING_REPOSITORY:
                        {
                            if (isDebug) logger.debug(" > " + tags.getTagById(TagConstants.MAPPING_REPOSITORY));
                            this.m_CurrentAttrContainer = m_repository;

                            String defIso = atts.getValue("isolation-level");
                            this.m_repository.setDefaultIsolationLevel(LockHelper.getIsolationLevelFor(defIso));
                            if (isDebug) logger.debug("     isolation-level: " + defIso);


                            String proxyPrefetchingLimit = atts.getValue("proxy-prefetching-limit");
                            if (isDebug) logger.debug("     proxy-prefetching-limit: " + proxyPrefetchingLimit);
                            if (proxyPrefetchingLimit != null)
                            {
                                defProxyPrefetchingLimit = Integer.parseInt(proxyPrefetchingLimit);
                            }

                            
                            String version = atts.getValue("repository-version");
                            if (DescriptorRepository.getVersion().equals(version))
                            {
                                if (isDebug) logger.debug("     repository-version: " + version);
                            }
                            else
                            {
                                throw new MetadataException("Repository version does not match. expected " +
                                        DescriptorRepository.getVersion() + " but found: " +
                                        version+". Please update your repository.dtd and your repository.xml"+
                                        " version attribute entry");
                            }
                            break;
                        }
                    case TagConstants.CLASS_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("  > " + tags.getTagById(TagConstants.CLASS_DESCRIPTOR));
                            m_CurrentCLD = new ClassDescriptor(m_repository);

                            
                            this.m_CurrentAttrContainer = this.m_CurrentCLD;

                            
                            String isoLevel = atts.getValue("isolation-level");
                            if (isDebug) logger.debug("     isolation-level: " + isoLevel);
                            




                            if(checkString(isoLevel)) m_CurrentCLD.setIsolationLevel(LockHelper.getIsolationLevelFor(isoLevel));

                            
                            String classname = atts.getValue("class");
                            if (isDebug) logger.debug("     class: " + classname);
                            try
                            {
                                m_CurrentCLD.setClassOfObject(ClassHelper.getClass(classname));
                            }
                            catch (ClassNotFoundException e)
                            {
                                m_CurrentCLD = null;
                                throw new MetadataException("Class "+classname+" could not be found"
                                        +" in the classpath. This could cause unexpected behaviour of OJB,"+
                                        " please remove or comment out this class descriptor" +
                                        " in the repository.xml file.", e);
                            }

                            
                            String schema = atts.getValue("schema");
                            if (schema != null)
                            {
                                if (isDebug) logger.debug("     schema: " + schema);
                                m_CurrentCLD.setSchema(schema);
                            }

                            
                            String proxy = atts.getValue("proxy");
                            if (isDebug) logger.debug("     proxy: " + proxy);
                            if (checkString(proxy))
                            {
                                if (proxy.equalsIgnoreCase(ClassDescriptor.DYNAMIC_STR))
                                {
                                    m_CurrentCLD.setProxyClassName(ClassDescriptor.DYNAMIC_STR);
                                }
                                else
                                {
                                    m_CurrentCLD.setProxyClassName(proxy);
                                }
                            }

                            
                            String proxyPrefetchingLimit = atts.getValue("proxy-prefetching-limit");
                            if (isDebug) logger.debug("     proxy-prefetching-limit: " + proxyPrefetchingLimit);
                            if (proxyPrefetchingLimit == null)
                            {
                                m_CurrentCLD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                            }
                            else
                            {
                                m_CurrentCLD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                            }

                            
                            String table = atts.getValue("table");
                            if (isDebug) logger.debug("     table: " + table);
                            m_CurrentCLD.setTableName(table);
                            if (table == null)
                            {
                                m_CurrentCLD.setIsInterface(true);
                            }

                            
                            String rowreader = atts.getValue("row-reader");
                            if (isDebug) logger.debug("     row-reader: " + rowreader);
                            if (rowreader != null)
                            {
                                m_CurrentCLD.setRowReader(rowreader);
                            }

                            

                            String extendsAtt = atts.getValue("extends");
                            if (isDebug) logger.debug("     extends: " + extendsAtt);
                            if (checkString(extendsAtt))
                            {
                                m_CurrentCLD.setSuperClass(extendsAtt);
                            }

                            
                            String acceptLocks = atts.getValue("accept-locks");
                            if (acceptLocks==null)
                                acceptLocks="true"; 
                            logger.debug("     accept-locks: " + acceptLocks);
                            if (isDebug) logger.debug("     accept-locks: " + acceptLocks);
                            boolean b = (Boolean.valueOf(acceptLocks)).booleanValue();
                            m_CurrentCLD.setAcceptLocks(b);

                            
                            String initializationMethod = atts.getValue("initialization-method");
                            if (isDebug) logger.debug("     initialization-method: " + initializationMethod);
                            if (initializationMethod != null)
                            {
                                m_CurrentCLD.setInitializationMethod(initializationMethod);
                            }

                            
                            String factoryClass = atts.getValue("factory-class");
                            if (isDebug)
                                logger.debug("     factory-class: " + factoryClass);
                            if (factoryClass != null)
                            {
                                m_CurrentCLD.setFactoryClass(factoryClass);
                            }

                            
                            String factoryMethod = atts.getValue("factory-method");
                            if (isDebug)
                                logger.debug("     factory-method: " + factoryMethod);
                            if (factoryMethod != null)
                            {
                                m_CurrentCLD.setFactoryMethod(factoryMethod);
                            }

                            
                            String refresh = atts.getValue("refresh");
                            if (isDebug) logger.debug("     refresh: " + refresh);
                            b = (Boolean.valueOf(refresh)).booleanValue();
                            m_CurrentCLD.setAlwaysRefresh(b);

                            
                            
                            String pfClassName = atts.getValue("persistent-field-class");
                            if (isDebug) logger.debug("     persistent-field-class: " + pfClassName);
                            m_CurrentCLD.setPersistentFieldClassName(pfClassName);

                            
                            m_repository.put(classname, m_CurrentCLD);
                            break;
                        }
                    case TagConstants.OBJECT_CACHE:
                        {
                            
                            
                            if(m_CurrentCLD != null)
                            {
                                String className = atts.getValue("class");
                                if(checkString(className))
                                {
                                    if (isDebug) logger.debug("     > " + tags.getTagById(TagConstants.OBJECT_CACHE));
                                    ObjectCacheDescriptor ocd = new ObjectCacheDescriptor();
                                    this.m_CurrentAttrContainer = ocd;
                                    ocd.setObjectCache(ClassHelper.getClass(className));
                                    if(m_CurrentCLD != null)
                                    {
                                        m_CurrentCLD.setObjectCacheDescriptor(ocd);
                                    }
                                    if (isDebug) logger.debug("     class: " + className);
                                }
                            }
                            break;
                        }
                    case TagConstants.CLASS_EXTENT:
                        {
                            String classname = atts.getValue("class-ref");
                            if (isDebug) logger.debug("     " + tags.getTagById(TagConstants.CLASS_EXTENT) + ": " + classname);
                            m_CurrentCLD.addExtentClass(classname);
                            break;
                        }

                    case TagConstants.FIELD_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.FIELD_DESCRIPTOR));

                            String strId = atts.getValue("id");
                            m_lastId = (strId == null ? m_lastId + 1 : Integer.parseInt(strId));

                            String strAccess = atts.getValue("access");

                            if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                            {
                                m_CurrentFLD = new AnonymousFieldDescriptor(m_CurrentCLD, m_lastId);
                            }
                            else
                            {
                                m_CurrentFLD = new FieldDescriptor(m_CurrentCLD, m_lastId);
                            }
                            m_CurrentFLD.setAccess(strAccess);
                            m_CurrentCLD.addFieldDescriptor(m_CurrentFLD);

                            
                            this.m_CurrentAttrContainer = this.m_CurrentFLD;

                            String fieldName = atts.getValue("name");
                            if (isDebug) logger.debug("     name: " + fieldName);

                            if (RepositoryElements.TAG_ACCESS_ANONYMOUS.equalsIgnoreCase(strAccess))
                            {
                                AnonymousFieldDescriptor anonymous = (AnonymousFieldDescriptor) m_CurrentFLD;
                                anonymous.setPersistentField(null,fieldName);
                            }
                            else
                            {
                                String classname = m_CurrentCLD.getClassNameOfObject();
                                PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),ClassHelper.getClass(classname),fieldName);
                                m_CurrentFLD.setPersistentField(pf);
                            }

                            String columnName = atts.getValue("column");
                            if (isDebug) logger.debug("     column: " + columnName);
                            m_CurrentFLD.setColumnName(columnName);

                            String jdbcType = atts.getValue("jdbc-type");
                            if (isDebug) logger.debug("     jdbc-type: " + jdbcType);
                            m_CurrentFLD.setColumnType(jdbcType);

                            String primaryKey = atts.getValue("primary-key");
                            if (isDebug) logger.debug("     primary-key: " + primaryKey);
                            boolean b = (Boolean.valueOf(primaryKey)).booleanValue();
                            m_CurrentFLD.setPrimaryKey(b);

                            String nullable = atts.getValue("nullable");
                            if (nullable != null)
                            {
                                if (isDebug) logger.debug("     nullable: " + nullable);
                                b = !(Boolean.valueOf(nullable)).booleanValue();
                                m_CurrentFLD.setRequired(b);
                            }

                            String indexed = atts.getValue("indexed");
                            if (isDebug) logger.debug("     indexed: " + indexed);
                            b = (Boolean.valueOf(indexed)).booleanValue();
                            m_CurrentFLD.setIndexed(b);

                            String autoincrement = atts.getValue("autoincrement");
                            if (isDebug) logger.debug("     autoincrement: " + autoincrement);
                            b = (Boolean.valueOf(autoincrement)).booleanValue();
                            m_CurrentFLD.setAutoIncrement(b);

                            String sequenceName = atts.getValue("sequence-name");
                            if (isDebug) logger.debug("     sequence-name: " + sequenceName);
                            m_CurrentFLD.setSequenceName(sequenceName);

                            String locking = atts.getValue("locking");
                            if (isDebug) logger.debug("     locking: " + locking);
                            b = (Boolean.valueOf(locking)).booleanValue();
                            m_CurrentFLD.setLocking(b);

                            String updateLock = atts.getValue("update-lock");
                            if (isDebug) logger.debug("     update-lock: " + updateLock);
                            if(checkString(updateLock))
                            {
                                b = (Boolean.valueOf(updateLock)).booleanValue();
                                m_CurrentFLD.setUpdateLock(b);
                            }

                            String fieldConversion = atts.getValue("field-conversion");
                            if (isDebug) logger.debug("     field-conversion: " + fieldConversion);
                            if (fieldConversion != null)
                            {
                                m_CurrentFLD.setFieldConversionClassName(fieldConversion);
                            }

                            
                            String length = atts.getValue("length");
                            if (length != null)
                            {
                                int i = Integer.parseInt(length);
                                if (isDebug) logger.debug("     length: " + i);
                                m_CurrentFLD.setLength(i);
                                m_CurrentFLD.setLengthSpecified(true);
                            }

                            
                            String precision = atts.getValue("precision");
                            if (precision != null)
                            {
                                int i = Integer.parseInt(precision);
                                if (isDebug) logger.debug("     precision: " + i);
                                m_CurrentFLD.setPrecision(i);
                                m_CurrentFLD.setPrecisionSpecified(true);
                            }

                            
                            String scale = atts.getValue("scale");
                            if (scale != null)
                            {
                                int i = Integer.parseInt(scale);
                                if (isDebug) logger.debug("     scale: " + i);
                                m_CurrentFLD.setScale(i);
                                m_CurrentFLD.setScaleSpecified(true);
                            }

                            break;
                        }

                    case TagConstants.REFERENCE_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.REFERENCE_DESCRIPTOR));
                            
                            name = atts.getValue("name");
                            if (isDebug) logger.debug("     name: " + name);

                            
                            String classRef = atts.getValue("class-ref");
                            if (isDebug) logger.debug("     class-ref: " + classRef);

                            ObjectReferenceDescriptor ord;
                            if (name.equals("super"))
                            {
                                ord = new SuperReferenceDescriptor(m_CurrentCLD);
                            }
                            else
                            {
                                ord = new ObjectReferenceDescriptor(m_CurrentCLD);
                                PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                                ord.setPersistentField(pf);
                            }
                            m_CurrentORD = ord;

                            
                            m_CurrentCLD.addObjectReferenceDescriptor(m_CurrentORD);
                            m_CurrentORD.setItemClass(ClassHelper.getClass(classRef));

                            
                            this.m_CurrentAttrContainer = m_CurrentORD;

                            
                            String proxy = atts.getValue("proxy");
                            if (isDebug) logger.debug("     proxy: " + proxy);
                            boolean b = (Boolean.valueOf(proxy)).booleanValue();
                            m_CurrentORD.setLazy(b);

                            
                            String proxyPrefetchingLimit = atts.getValue("proxy-prefetching-limit");
                            if (isDebug) logger.debug("     proxy-prefetching-limit: " + proxyPrefetchingLimit);
                            if (proxyPrefetchingLimit == null)
                            {
                                m_CurrentORD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                            }
                            else
                            {
                                m_CurrentORD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                            }

                            
                            String refresh = atts.getValue("refresh");
                            if (isDebug) logger.debug("     refresh: " + refresh);
                            b = (Boolean.valueOf(refresh)).booleanValue();
                            m_CurrentORD.setRefresh(b);

                            
                            String autoRetrieve = atts.getValue("auto-retrieve");
                            if (isDebug) logger.debug("     auto-retrieve: " + autoRetrieve);
                            b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                            m_CurrentORD.setCascadeRetrieve(b);

                            
                            String autoUpdate = atts.getValue("auto-update");
                            if (isDebug) logger.debug("     auto-update: " + autoUpdate);
                            if(autoUpdate != null)
                            {
                                m_CurrentORD.setCascadingStore(autoUpdate);
                            }

                            
                            String autoDelete = atts.getValue("auto-delete");
                            if (isDebug) logger.debug("     auto-delete: " + autoDelete);

                            if(autoDelete != null)
                            {
                                m_CurrentORD.setCascadingDelete(autoDelete);
                            }

                            
                            String otmDependent = atts.getValue("otm-dependent");
                            if (isDebug) logger.debug("     otm-dependent: " + otmDependent);
                            b = (Boolean.valueOf(otmDependent)).booleanValue();
                            m_CurrentORD.setOtmDependent(b);

                            break;
                        }

                    case TagConstants.FOREIGN_KEY:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.FOREIGN_KEY));
                            String fieldIdRef = atts.getValue("field-id-ref");

                            if (fieldIdRef != null)
                            {
                                if (isDebug) logger.debug("      field-id-ref: " + fieldIdRef);

                                try
                                {
                                    int fieldId;
                                    fieldId = Integer.parseInt(fieldIdRef);
                                    m_CurrentORD.addForeignKeyField(fieldId);
                                }
                                catch (NumberFormatException rex)
                                {
                                    throw new MetadataException("field-id-ref"
                                            + " attribute must be an int. Found: "
                                            + fieldIdRef + ". Please check your repository file.", rex);
                                }
                            }
                            else
                            {
                                String fieldRef = atts.getValue("field-ref");
                                if (isDebug) logger.debug("      field-ref: " + fieldRef);
                                m_CurrentORD.addForeignKeyField(fieldRef);
                            }
                            break;
                        }

                    case TagConstants.COLLECTION_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.COLLECTION_DESCRIPTOR));
                            m_CurrentCOD = new CollectionDescriptor(m_CurrentCLD);


                            
                            this.m_CurrentAttrContainer = m_CurrentCOD;

                            
                            name = atts.getValue("name");
                            if (isDebug) logger.debug("     name: " + name);
                            PersistentField pf = PersistentFieldFactory.createPersistentField(m_CurrentCLD.getPersistentFieldClassName(),m_CurrentCLD.getClassOfObject(),name);
                            m_CurrentCOD.setPersistentField(pf);

                            
                            String collectionClassName = atts.getValue("collection-class");
                            if (collectionClassName != null)
                            {
                                if (isDebug) logger.debug("     collection-class: " + collectionClassName);
                                m_CurrentCOD.setCollectionClass(ClassHelper.getClass(collectionClassName));
                            }
                            
                            String elementClassRef = atts.getValue("element-class-ref");
                            if (isDebug) logger.debug("     element-class-ref: " + elementClassRef);
                            if (elementClassRef != null)
                            {
                                m_CurrentCOD.setItemClass(ClassHelper.getClass(elementClassRef));
                            }

                            
                            String orderby = atts.getValue("orderby");
                            String sort = atts.getValue("sort");
                            if (isDebug) logger.debug("     sort: " + orderby + ", " + sort);
                            if (orderby != null)
                            {
                                m_CurrentCOD.addOrderBy(orderby, "ASC".equalsIgnoreCase(sort));
                            }

                            
                            String indirectionTable = atts.getValue("indirection-table");
                            if (isDebug) logger.debug("     indirection-table: " + indirectionTable);
                            m_CurrentCOD.setIndirectionTable(indirectionTable);

                            
                            String proxy = atts.getValue("proxy");
                            if (isDebug) logger.debug("     proxy: " + proxy);
                            boolean b = (Boolean.valueOf(proxy)).booleanValue();
                            m_CurrentCOD.setLazy(b);

                            
                            String proxyPrefetchingLimit = atts.getValue("proxy-prefetching-limit");
                            if (isDebug) logger.debug("     proxy-prefetching-limit: " + proxyPrefetchingLimit);
                            if (proxyPrefetchingLimit == null)
                            {
                                m_CurrentCOD.setProxyPrefetchingLimit(defProxyPrefetchingLimit);
                            }
                            else
                            {
                                m_CurrentCOD.setProxyPrefetchingLimit(Integer.parseInt(proxyPrefetchingLimit));
                            }

                            
                            String refresh = atts.getValue("refresh");
                            if (isDebug) logger.debug("     refresh: " + refresh);
                            b = (Boolean.valueOf(refresh)).booleanValue();
                            m_CurrentCOD.setRefresh(b);

                            
                            String autoRetrieve = atts.getValue("auto-retrieve");
                            if (isDebug) logger.debug("     auto-retrieve: " + autoRetrieve);
                            b = (Boolean.valueOf(autoRetrieve)).booleanValue();
                            m_CurrentCOD.setCascadeRetrieve(b);

                            
                            String autoUpdate = atts.getValue("auto-update");
                            if (isDebug) logger.debug("     auto-update: " + autoUpdate);
                            if(autoUpdate != null)
                            {
                                m_CurrentCOD.setCascadingStore(autoUpdate);
                            }

                            
                            String autoDelete = atts.getValue("auto-delete");
                            if (isDebug) logger.debug("     auto-delete: " + autoDelete);
                            if(autoDelete != null)
                            {
                                m_CurrentCOD.setCascadingDelete(autoDelete);
                            }

                            
                            String otmDependent = atts.getValue("otm-dependent");
                            if (isDebug) logger.debug("     otm-dependent: " + otmDependent);
                            b = (Boolean.valueOf(otmDependent)).booleanValue();
                            m_CurrentCOD.setOtmDependent(b);

                            m_CurrentCLD.addCollectionDescriptor(m_CurrentCOD);

                            break;
                        }
                    case TagConstants.ORDERBY :
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.ORDERBY));
                            name = atts.getValue("name");
                            if (isDebug) logger.debug("     name: " + name);
                            String sort = atts.getValue("sort");
                            if (isDebug) logger.debug("     sort: " + name + ", " + sort);

                            m_CurrentCOD.addOrderBy(name, "ASC".equalsIgnoreCase(sort));
                            break;
                        }
                    case TagConstants.INVERSE_FK:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.INVERSE_FK));
                            String fieldIdRef = atts.getValue("field-id-ref");

                            if (fieldIdRef != null)
                            {
                                if (isDebug) logger.debug("      field-id-ref: " + fieldIdRef);

                                try
                                {
                                    int fieldId;
                                    fieldId = Integer.parseInt(fieldIdRef);
                                    m_CurrentCOD.addForeignKeyField(fieldId);
                                }
                                catch (NumberFormatException rex)
                                {
                                    throw new MetadataException("field-id-ref"
                                            + " attribute must be an int. Found: "
                                            + fieldIdRef + " Please check your repository file.", rex);
                                }
                            }
                            else
                            {
                                String fieldRef = atts.getValue("field-ref");
                                if (isDebug) logger.debug("      field-ref: " + fieldRef);
                                m_CurrentCOD.addForeignKeyField(fieldRef);
                            }
                            break;
                        }

                    case TagConstants.FK_POINTING_TO_THIS_CLASS:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.FK_POINTING_TO_THIS_CLASS));
                            String column = atts.getValue("column");
                            if (isDebug) logger.debug("      column: " + column);
                            m_CurrentCOD.addFkToThisClass(column);
                            break;
                        }

                    case TagConstants.FK_POINTING_TO_ITEMS_CLASS:
                        {
                            if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.FK_POINTING_TO_ITEMS_CLASS));
                            String column = atts.getValue("column");
                            if (isDebug) logger.debug("      column: " + column);
                            m_CurrentCOD.addFkToItemClass(column);
                            break;
                        }
                    case TagConstants.ATTRIBUTE:
                        {
                            
                            String attributeName = atts.getValue("name");
                            String attributeValue = atts.getValue("value");
                            
                            if (this.m_CurrentAttrContainer != null)
                            {
                                if (isDebug) logger.debug("      > " + tags.getTagById(TagConstants.ATTRIBUTE));
                                if (isDebug) logger.debug("       name: " + attributeName);
                                if (isDebug) logger.debug("       value: " + attributeValue);
                                this.m_CurrentAttrContainer.addAttribute(attributeName, attributeValue);
                            }
                            break;
                        }
                    case TagConstants.QUERY_CUSTOMIZER:
                        {
                            
                            String className = atts.getValue("class");
                            QueryCustomizer queryCust;

                            if (className != null)
                            {
                                if (isDebug) logger.debug("     class: " + className);
                                queryCust = (QueryCustomizer)ClassHelper.newInstance(className);
                                m_CurrentAttrContainer = queryCust;
                                m_CurrentCOD.setQueryCustomizer(queryCust);
                            }
                            break;
                        }
                    case TagConstants.INDEX_DESCRIPTOR:
                        {
                            m_CurrentIndexDescriptor = new IndexDescriptor();
                            m_CurrentIndexDescriptor.setName(atts.getValue("name"));
                            m_CurrentIndexDescriptor.setUnique(Boolean.valueOf(atts.getValue("unique")).booleanValue());
                            break;
                        }
                    case TagConstants.INDEX_COLUMN:
                        {
                            m_CurrentIndexDescriptor.getIndexColumns().add(atts.getValue("name"));
                            break;
                        }
                    case TagConstants.INSERT_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.INSERT_PROCEDURE));

                        
                        String procName = atts.getValue("name");
                        String includeAllFields = atts.getValue("include-all-fields");
                        if (isDebug) logger.debug("     name: " + procName);
                        if (isDebug) logger.debug("     include-all-fields: " + includeAllFields);

                        
                        InsertProcedureDescriptor proc =
                            new InsertProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue("return-field-ref");
                        if (isDebug) logger.debug("     return-field-ref: " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;
                    }
                case TagConstants.UPDATE_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.UPDATE_PROCEDURE));

                        
                        String procName = atts.getValue("name");
                        String includeAllFields = atts.getValue("include-all-fields");
                        if (isDebug) logger.debug("     name: " + procName);
                        if (isDebug) logger.debug("     include-all-fields: " + includeAllFields);

                        
                        UpdateProcedureDescriptor proc =
                            new UpdateProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue("return-field-ref");
                        if (isDebug) logger.debug("     return-field-ref: " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;
                    }
                case TagConstants.DELETE_PROCEDURE:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.DELETE_PROCEDURE));

                        
                        String procName = atts.getValue("name");
                        String includeAllPkFields = atts.getValue("include-pk-fields-only");
                        if (isDebug) logger.debug("     name: " + procName);
                        if (isDebug) logger.debug("     include-pk-fields-only: " + includeAllPkFields);

                        
                        DeleteProcedureDescriptor proc =
                            new DeleteProcedureDescriptor(m_CurrentCLD,
                                                          procName,
                                                          Boolean.valueOf(includeAllPkFields).booleanValue());
                        m_CurrentProcedure = proc;

                        
                        
                        String returnFieldRefName = atts.getValue("return-field-ref");
                        if (isDebug) logger.debug("     return-field-ref: " + returnFieldRefName);
                        proc.setReturnValueFieldRef(returnFieldRefName);

                        break;

                    }
                case TagConstants.CONSTANT_ARGUMENT:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.CONSTANT_ARGUMENT));
                        ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                        
                        String value = atts.getValue("value");
                        if (isDebug) logger.debug("     value: " + value);

                        
                        arg.setValue(value);

                        
                        m_CurrentProcedure.addArgument(arg);
                        break;
                    }
                case TagConstants.RUNTIME_ARGUMENT:
                    {
                        if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.RUNTIME_ARGUMENT));
                        ArgumentDescriptor arg = new ArgumentDescriptor(m_CurrentProcedure);

                        
                        String fieldRefName = atts.getValue("field-ref");
                        if (isDebug) logger.debug("     field-ref: " + fieldRefName);

                        
                        String returnValue = atts.getValue("return");
                        if (isDebug) logger.debug("     return: " + returnValue);

                        
                        if ((fieldRefName != null) && (fieldRefName.trim().length() != 0)) {
                            arg.setValue(fieldRefName,
                                         Boolean.valueOf(returnValue).booleanValue());
                        }

                        
                        m_CurrentProcedure.addArgument(arg);
                        break;
                    }

                default :
                    {
                        
                    }
                }
            }
            catch (Exception ex)
            {
                logger.error("Exception while read metadata", ex);
                if(ex instanceof MetadataException) throw (MetadataException)ex;
                else throw new MetadataException("Exception when reading metadata information,"+
                        " please check your repository.xml file", ex);
            }
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing RepositoryXmlHandler.startElement ===\n");

        RepositoryXmlHandler handler = new RepositoryXmlHandler();

        
        System.out.println("--- Test 1: mapping-repository ---");
        AttributesStub attrs1 = new AttributesStub();
        attrs1.setAttribute("isolation-level", "READ_COMMITTED");
        attrs1.setAttribute("proxy-prefetching-limit", "20");
        attrs1.setAttribute("repository-version", "1.0");
        handler.startElement(null, null, "mapping-repository", attrs1);
        System.out.println("Repository version check passed.");

        
        System.out.println("\n--- Test 2: class-descriptor ---");
        AttributesStub attrs2 = new AttributesStub();
        attrs2.setAttribute("isolation-level", "SERIALIZABLE");
        attrs2.setAttribute("class", "java.lang.String");
        attrs2.setAttribute("table", "STRINGS");
        attrs2.setAttribute("proxy", "dynamic");
        attrs2.setAttribute("proxy-prefetching-limit", "15");
        attrs2.setAttribute("accept-locks", "true");
        attrs2.setAttribute("refresh", "false");
        attrs2.setAttribute("persistent-field-class", "org.apache.ojb.broker.PersistentField");
        handler.startElement(null, null, "class-descriptor", attrs2);

        
        System.out.println("\n--- Test 3: field-descriptor ---");
        AttributesStub attrs3 = new AttributesStub();
        attrs3.setAttribute("id", "1");
        attrs3.setAttribute("name", "value");
        attrs3.setAttribute("column", "VAL");
        attrs3.setAttribute("jdbc-type", "VARCHAR");
        attrs3.setAttribute("primary-key", "false");
        attrs3.setAttribute("nullable", "false");
        attrs3.setAttribute("length", "255");
        handler.startElement(null, null, "field-descriptor", attrs3);

        
        System.out.println("\n--- Test 4: reference-descriptor ---");
        AttributesStub attrs4 = new AttributesStub();
        attrs4.setAttribute("name", "owner");
        attrs4.setAttribute("class-ref", "org.example.Owner");
        attrs4.setAttribute("proxy", "true");
        attrs4.setAttribute("auto-retrieve", "true");
        handler.startElement(null, null, "reference-descriptor", attrs4);

        
        System.out.println("\n--- Test 5: collection-descriptor ---");
        AttributesStub attrs5 = new AttributesStub();
        attrs5.setAttribute("name", "items");
        attrs5.setAttribute("element-class-ref", "org.example.Item");
        attrs5.setAttribute("collection-class", "java.util.ArrayList");
        attrs5.setAttribute("orderby", "name");
        attrs5.setAttribute("sort", "ASC");
        attrs5.setAttribute("proxy", "false");
        handler.startElement(null, null, "collection-descriptor", attrs5);

        
        System.out.println("\n--- Test 6: attribute ---");
        AttributesStub attrs6 = new AttributesStub();
        attrs6.setAttribute("name", "customAttr");
        attrs6.setAttribute("value", "someValue");
        handler.startElement(null, null, "attribute", attrs6);

        System.out.println("\n=== All tests completed successfully ===");
    }
}
