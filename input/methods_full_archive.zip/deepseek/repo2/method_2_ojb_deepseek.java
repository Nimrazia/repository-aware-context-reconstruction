
import org.xml.sax.Attributes;
import java.util.*;






public class method_2_ojb_deepseek {

    interface AttributeContainer { void addAttribute(String name, String value); }
    static class Descriptor implements AttributeContainer {
        private final Map<String,String> attributes = new HashMap<>();
        public void addAttribute(String name, String value) { attributes.put(name, value); }
    }
    static class ObjectCacheDescriptor extends Descriptor {
        private Class objectCache;
        public void setObjectCache(Class c) { objectCache = c; }
    }
    static class Logger {
        boolean isDebugEnabled() { return true; }
        void debug(Object o) { System.out.println("[DEBUG] " + o); }
        void info(Object o) { System.out.println("[INFO] " + o); }
        void error(Object o) { System.err.println("[ERROR] " + o); }
    }
    static class MetadataException extends RuntimeException { MetadataException(String m){super(m);} }
    static class PersistenceBrokerException extends RuntimeException { PersistenceBrokerException(Throwable t){super(t);} }
    static class ClassHelper {
        static Class getClass(String name) {
            try { return Class.forName(name); } catch (Exception e) { return Object.class; }
        }
    }
    static class AttributesStub implements Attributes {
        private final Map<String,String> attrs = new LinkedHashMap<>();
        void setAttribute(String name, String value) { attrs.put(name, value); }
        public int getLength(){ return attrs.size(); }
        public String getURI(int i){ return ""; }
        public String getLocalName(int i){ return getQName(i); }
        public String getQName(int i){ return new ArrayList<>(attrs.keySet()).get(i); }
        public String getType(int i){ return "CDATA"; }
        public String getValue(int i){ return new ArrayList<>(attrs.values()).get(i); }
        public int getIndex(String uri,String local){ return getIndex(local); }
        public int getIndex(String q){ return new ArrayList<>(attrs.keySet()).indexOf(q); }
        public String getType(String uri,String local){ return "CDATA"; }
        public String getType(String q){ return "CDATA"; }
        public String getValue(String uri,String local){ return attrs.get(local); }
        public String getValue(String q){ return attrs.get(q); }
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    
    
    
    

    
    static class TagConstants {
        public static final int JDBC_CONNECTION_DESCRIPTOR = 1;
        public static final int CONNECTION_POOL = 2;
        public static final int OBJECT_CACHE = 3;
        public static final int SEQUENCE_MANAGER = 4;
        public static final int ATTRIBUTE = 5;
        

        public String getTagById(int id) {
            switch (id) {
                case JDBC_CONNECTION_DESCRIPTOR: return "jdbc-connection-descriptor";
                case CONNECTION_POOL: return "connection-pool";
                case OBJECT_CACHE: return "object-cache";
                case SEQUENCE_MANAGER: return "sequence-manager";
                case ATTRIBUTE: return "attribute";
                default: return "unknown";
            }
        }
        
        public String getTagById(String name) { return name; }
    }

    static class ConnectionPoolDescriptor extends Descriptor {
        private int maxActive = -1;
        private int maxIdle = -1;
        private int maxWait = -1;
        private long minEvictableIdleTimeMillis = -1;
        private int numTestsPerEvictionRun = -1;
        private boolean testOnBorrow;
        private boolean testOnReturn;
        private boolean testWhileIdle;
        private long timeBetweenEvictionRunsMillis = -1;
        private byte whenExhaustedAction;
        private Class connectionFactory;
        private String validationQuery;
        private boolean logAbandoned;
        private boolean removeAbandoned;
        private int removeAbandonedTimeout = -1;

        public void setMaxActive(int max) { this.maxActive = max; }
        public void setMaxIdle(int max) { this.maxIdle = max; }
        public void setMaxWait(int max) { this.maxWait = max; }
        public void setMinEvictableIdleTimeMillis(long t) { this.minEvictableIdleTimeMillis = t; }
        public void setNumTestsPerEvictionRun(int n) { this.numTestsPerEvictionRun = n; }
        public void setTestOnBorrow(boolean b) { this.testOnBorrow = b; }
        public void setTestOnReturn(boolean b) { this.testOnReturn = b; }
        public void setTestWhileIdle(boolean b) { this.testWhileIdle = b; }
        public void setTimeBetweenEvictionRunsMillis(long t) { this.timeBetweenEvictionRunsMillis = t; }
        public void setWhenExhaustedAction(byte b) { this.whenExhaustedAction = b; }
        public void setConnectionFactory(Class clazz) { this.connectionFactory = clazz; }
        public void setValidationQuery(String query) { this.validationQuery = query; }
        public void setLogAbandoned(boolean b) { this.logAbandoned = b; }
        public void setRemoveAbandoned(boolean b) { this.removeAbandoned = b; }
        public void setRemoveAbandonedTimeout(int t) { this.removeAbandonedTimeout = t; }
    }

    static class JdbcConnectionDescriptor extends Descriptor {
        private String jcdAlias;
        private boolean defaultConnection;
        private String dbms;
        private String jdbcLevel;
        private String driver;
        private String protocol;
        private String subProtocol;
        private String dbAlias;
        private String datasourceName;
        private String userName;
        private String passWord;
        private boolean eagerRelease;
        private boolean batchMode;
        private int useAutoCommit;
        private boolean ignoreAutoCommitExceptions;
        private ConnectionPoolDescriptor connectionPoolDescriptor = new ConnectionPoolDescriptor();
        private ObjectCacheDescriptor objectCacheDescriptor = new ObjectCacheDescriptor();
        private SequenceDescriptor sequenceDescriptor;

        public void setJcdAlias(String alias) { this.jcdAlias = alias; }
        public void setDefaultConnection(boolean def) { this.defaultConnection = def; }
        public void setDbms(String db) { this.dbms = db; }
        public void setJdbcLevel(String level) { this.jdbcLevel = level; }
        public void setDriver(String driver) { this.driver = driver; }
        public void setProtocol(String proto) { this.protocol = proto; }
        public void setSubProtocol(String sub) { this.subProtocol = sub; }
        public void setDbAlias(String alias) { this.dbAlias = alias; }
        public void setDatasourceName(String ds) { this.datasourceName = ds; }
        public void setUserName(String user) { this.userName = user; }
        public void setPassWord(String pwd) { this.passWord = pwd; }
        public void setEagerRelease(boolean er) { this.eagerRelease = er; }
        public void setBatchMode(boolean bm) { this.batchMode = bm; }
        public void setUseAutoCommit(int uac) { this.useAutoCommit = uac; }
        public void setIgnoreAutoCommitExceptions(boolean iae) { this.ignoreAutoCommitExceptions = iae; }
        public ConnectionPoolDescriptor getConnectionPoolDescriptor() { return connectionPoolDescriptor; }
        public ObjectCacheDescriptor getObjectCacheDescriptor() { return objectCacheDescriptor; }
        public void setSequenceDescriptor(SequenceDescriptor sd) { this.sequenceDescriptor = sd; }
        public String getJcdAlias() { return jcdAlias; }
        public boolean isDefaultConnection() { return defaultConnection; }
    }

    static class SequenceDescriptor extends Descriptor {
        private Object owner;
        private Class sequenceManagerClass;
        SequenceDescriptor() {}
        SequenceDescriptor(Object owner) { this.owner = owner; }
        public void setSequenceManagerClass(Class clazz) { this.sequenceManagerClass = clazz; }
    }

    

    static class ConnectionDescriptorXmlHandler {
        private Logger logger = new Logger();
        private TagConstants tags = new TagConstants();
        private JdbcConnectionDescriptor m_CurrentJCD;
        private AttributeContainer currentAttributeContainer;
        private SequenceDescriptor currentSequenceDescriptor;
        private List<JdbcConnectionDescriptor> conDesList = new ArrayList<>();
        private boolean defaultConnectionFound = false;

        private boolean checkString(String s) {
            return s != null && !s.trim().isEmpty();
        }

        private int getLiteralId(String qName) {
            switch (qName) {
                case "jdbc-connection-descriptor": return TagConstants.JDBC_CONNECTION_DESCRIPTOR;
                case "connection-pool": return TagConstants.CONNECTION_POOL;
                case "object-cache": return TagConstants.OBJECT_CACHE;
                case "sequence-manager": return TagConstants.SEQUENCE_MANAGER;
                case "attribute": return TagConstants.ATTRIBUTE;
                default: return -1;
            }
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public void startElement(String uri, String name, String qName, Attributes atts)
        {
            boolean isDebug = logger.isDebugEnabled();
            try
            {
                switch (getLiteralId(qName))
                {
                    case TagConstants.JDBC_CONNECTION_DESCRIPTOR:
                        {
                            if (isDebug) logger.debug("   > " + tags.getTagById(TagConstants.JDBC_CONNECTION_DESCRIPTOR));
                            JdbcConnectionDescriptor newJcd = new JdbcConnectionDescriptor();
                            currentAttributeContainer = newJcd;

                            conDesList.add(newJcd);
                            m_CurrentJCD = newJcd;

                            
                            String jcdAlias = atts.getValue("jcd-alias");
                            if (isDebug) logger.debug("     jcd-alias: " + jcdAlias);
                            m_CurrentJCD.setJcdAlias(jcdAlias);

                            
                            String defaultConnection = atts.getValue("default-connection");
                            if (isDebug) logger.debug("     default-connection: " + defaultConnection);
                            m_CurrentJCD.setDefaultConnection(Boolean.valueOf(defaultConnection).booleanValue());
                            if (m_CurrentJCD.isDefaultConnection())
                            {
                                if (defaultConnectionFound)
                                {
                                    throw new MetadataException("Found two jdbc-connection-descriptor elements with default-connection=\"true\"");
                                }
                                else
                                {
                                    defaultConnectionFound = true;
                                }
                            }

                            
                            String platform = atts.getValue("platform");
                            if (isDebug) logger.debug("     platform: " + platform);
                            m_CurrentJCD.setDbms(platform);

                            
                            String level = atts.getValue("jdbc-level");
                            if (isDebug) logger.debug("     jdbc-level: " + level);
                            m_CurrentJCD.setJdbcLevel(level);

                            
                            String driver = atts.getValue("driver");
                            if (isDebug) logger.debug("     driver: " + driver);
                            m_CurrentJCD.setDriver(driver);

                            
                            String protocol = atts.getValue("protocol");
                            if (isDebug) logger.debug("     protocol: " + protocol);
                            m_CurrentJCD.setProtocol(protocol);

                            
                            String subprotocol = atts.getValue("subprotocol");
                            if (isDebug) logger.debug("     subprotocol: " + subprotocol);
                            m_CurrentJCD.setSubProtocol(subprotocol);

                            
                            String dbalias = atts.getValue("dbalias");
                            if (isDebug) logger.debug("     dbalias: " + dbalias);
                            m_CurrentJCD.setDbAlias(dbalias);

                            
                            String datasource = atts.getValue("datasource");
                            
                            if(datasource != null && datasource.trim().equals("")) datasource = null;
                            if (isDebug) logger.debug("     datasource: " + datasource);
                            m_CurrentJCD.setDatasourceName(datasource);

                            
                            String user = atts.getValue("user");
                            if (isDebug) logger.debug("     user: " + user);
                            m_CurrentJCD.setUserName(user);

                            
                            String password = atts.getValue("password");
                            if (isDebug) logger.debug("     password: " + password);
                            m_CurrentJCD.setPassWord(password);

                            
                            String eagerRelease = atts.getValue("eager-release");
                            if (isDebug) logger.debug("     eager-release: " + eagerRelease);
                            m_CurrentJCD.setEagerRelease(Boolean.valueOf(eagerRelease).booleanValue());

                            
                            String batchMode = atts.getValue("batch-mode");
                            if (isDebug) logger.debug("     batch-mode: " + batchMode);
                            m_CurrentJCD.setBatchMode(Boolean.valueOf(batchMode).booleanValue());

                            
                            String useAutoCommit = atts.getValue("use-autocommit");
                            if (isDebug) logger.debug("     use-autocommit: " + useAutoCommit);
                            m_CurrentJCD.setUseAutoCommit(Integer.valueOf(useAutoCommit).intValue());

                            
                            String ignoreAutoCommitExceptions = atts.getValue("ignore-autocommit-exception");
                            if (isDebug) logger.debug("     ignore-autocommit-exception: " + ignoreAutoCommitExceptions);
                            m_CurrentJCD.setIgnoreAutoCommitExceptions(Boolean.valueOf(ignoreAutoCommitExceptions).booleanValue());

                            break;
                        }
                    case TagConstants.CONNECTION_POOL:
                        {
                            if (m_CurrentJCD != null)
                            {
                                if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.CONNECTION_POOL));
                                final ConnectionPoolDescriptor m_CurrentCPD = m_CurrentJCD.getConnectionPoolDescriptor();
                                this.currentAttributeContainer = m_CurrentCPD;

                                String maxActive = atts.getValue("max-active");
                                if (isDebug) logger.debug("     max-active: " + maxActive);
                                if (checkString(maxActive)) m_CurrentCPD.setMaxActive(Integer.parseInt(maxActive));

                                String maxIdle = atts.getValue("max-idle");
                                if (isDebug) logger.debug("     max-idle: " + maxIdle);
                                if (checkString(maxIdle)) m_CurrentCPD.setMaxIdle(Integer.parseInt(maxIdle));

                                String maxWait = atts.getValue("max-wait");
                                if (isDebug) logger.debug("     max-wait: " + maxWait);
                                if (checkString(maxWait)) m_CurrentCPD.setMaxWait(Integer.parseInt(maxWait));

                                String minEvictableIdleTimeMillis = atts.getValue("min-evictable-idle-time-millis");
                                if (isDebug) logger.debug("     min-evictable-idle-time-millis: " + minEvictableIdleTimeMillis);
                                if (checkString(minEvictableIdleTimeMillis)) m_CurrentCPD.setMinEvictableIdleTimeMillis(Long.parseLong(minEvictableIdleTimeMillis));

                                String numTestsPerEvictionRun = atts.getValue("num-tests-per-eviction-run");
                                if (isDebug) logger.debug("     num-tests-per-eviction-run: " + numTestsPerEvictionRun);
                                if (checkString(numTestsPerEvictionRun)) m_CurrentCPD.setNumTestsPerEvictionRun(Integer.parseInt(numTestsPerEvictionRun));

                                String testOnBorrow = atts.getValue("test-on-borrow");
                                if (isDebug) logger.debug("     test-on-borrow: " + testOnBorrow);
                                if (checkString(testOnBorrow)) m_CurrentCPD.setTestOnBorrow(Boolean.valueOf(testOnBorrow).booleanValue());

                                String testOnReturn = atts.getValue("test-on-return");
                                if (isDebug) logger.debug("     test-on-return: " + testOnReturn);
                                if (checkString(testOnReturn)) m_CurrentCPD.setTestOnReturn(Boolean.valueOf(testOnReturn).booleanValue());

                                String testWhileIdle = atts.getValue("test-while-idle");
                                if (isDebug) logger.debug("     test-while-idle: " + testWhileIdle);
                                if (checkString(testWhileIdle)) m_CurrentCPD.setTestWhileIdle(Boolean.valueOf(testWhileIdle).booleanValue());

                                String timeBetweenEvictionRunsMillis = atts.getValue("time-between-eviction-runs-millis");
                                if (isDebug) logger.debug("     time-between-eviction-runs-millis: " + timeBetweenEvictionRunsMillis);
                                if (checkString(timeBetweenEvictionRunsMillis)) m_CurrentCPD.setTimeBetweenEvictionRunsMillis(Long.parseLong(timeBetweenEvictionRunsMillis));

                                String whenExhaustedAction = atts.getValue("when-exhausted-action");
                                if (isDebug) logger.debug("     when-exhausted-action: " + whenExhaustedAction);
                                if (checkString(whenExhaustedAction)) m_CurrentCPD.setWhenExhaustedAction(Byte.parseByte(whenExhaustedAction));

                                String connectionFactoryStr = atts.getValue("connection-factory");
                                if (isDebug) logger.debug("     connection-factory: " + connectionFactoryStr);
                                if (checkString(connectionFactoryStr)) m_CurrentCPD.setConnectionFactory(ClassHelper.getClass(connectionFactoryStr));

                                String validationQuery = atts.getValue("validation-query");
                                if (isDebug) logger.debug("     validation-query: " + validationQuery);
                                if (checkString(validationQuery)) m_CurrentCPD.setValidationQuery(validationQuery);

                                
                                String logAbandoned = atts.getValue("log-abandoned");
                                if (isDebug) logger.debug("     log-abandoned: " + logAbandoned);
                                if (checkString(logAbandoned)) m_CurrentCPD.setLogAbandoned(Boolean.valueOf(logAbandoned).booleanValue());

                                String removeAbandoned = atts.getValue("remove-abandoned");
                                if (isDebug) logger.debug("     remove-abandoned: " + removeAbandoned);
                                if (checkString(removeAbandoned)) m_CurrentCPD.setRemoveAbandoned(Boolean.valueOf(removeAbandoned).booleanValue());

                                String removeAbandonedTimeout = atts.getValue("remove-abandoned-timeout");
                                if (isDebug) logger.debug("     remove-abandoned-timeout: " + removeAbandonedTimeout);
                                if (checkString(removeAbandonedTimeout)) m_CurrentCPD.setRemoveAbandonedTimeout(Integer.parseInt(removeAbandonedTimeout));
                            }
                            break;
                        }

                    case TagConstants.OBJECT_CACHE:
                        {
                            String className = atts.getValue("class");
                            if(checkString(className) && m_CurrentJCD != null)
                            {
                                ObjectCacheDescriptor ocd = m_CurrentJCD.getObjectCacheDescriptor();
                                this.currentAttributeContainer = ocd;
                                ocd.setObjectCache(ClassHelper.getClass(className));
                                if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.OBJECT_CACHE));
                                if (isDebug) logger.debug("     class: " + className);
                            }
                            break;
                        }
                    case TagConstants.SEQUENCE_MANAGER:
                        {
                            String className = atts.getValue("sequence-manager-class");
                            if(checkString(className))
                            {
                                this.currentSequenceDescriptor = new SequenceDescriptor(this.m_CurrentJCD);
                                this.currentAttributeContainer = currentSequenceDescriptor;
                                this.m_CurrentJCD.setSequenceDescriptor(this.currentSequenceDescriptor);
                                if (isDebug) logger.debug("    > " + tags.getTagById(TagConstants.SEQUENCE_MANAGER));
                                if (isDebug) logger.debug("     sequence-manager-class: " + className);
                                if (checkString(className)) currentSequenceDescriptor.setSequenceManagerClass(ClassHelper.getClass(className));
                            }
                            break;
                        }
                    case TagConstants.ATTRIBUTE:
                        {
                            
                            String attributeName = atts.getValue("name");
                            String attributeValue = atts.getValue("value");

                            
                            if (this.currentAttributeContainer != null)
                            {

                                if (checkString(attributeName))
                                {
                                    if (isDebug) logger.debug("      > " + tags.getTagById(TagConstants.ATTRIBUTE));
                                    if (isDebug) logger.debug("       name: " + attributeName
                                            + "  value: " + attributeValue);
                                    this.currentAttributeContainer.addAttribute(attributeName, attributeValue);
                                }
                                else
                                {
                                    logger.info("Found 'null' or 'empty' attribute object for element "+currentAttributeContainer.getClass() +
                                            " attribute-name=" + attributeName + ", attribute-value=" + attributeValue+
                                            " See jdbc-connection-descriptor with jcdAlias '"+m_CurrentJCD.getJcdAlias()+"'");
                                }
                            }
                            break;
                        }
                    default :
                        {
                            
                        }
                }
            }
            catch (Exception ex)
            {
                logger.error(ex);
                throw new PersistenceBrokerException(ex);
            }
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing ConnectionDescriptorXmlHandler.startElement ===\n");

        ConnectionDescriptorXmlHandler handler = new ConnectionDescriptorXmlHandler();

        
        System.out.println("--- Test 1: jdbc-connection-descriptor ---");
        AttributesStub attrs1 = new AttributesStub();
        attrs1.setAttribute("jcd-alias", "myDB");
        attrs1.setAttribute("default-connection", "true");
        attrs1.setAttribute("platform", "Oracle");
        attrs1.setAttribute("jdbc-level", "2.0");
        attrs1.setAttribute("driver", "oracle.jdbc.OracleDriver");
        attrs1.setAttribute("protocol", "jdbc");
        attrs1.setAttribute("subprotocol", "oracle");
        attrs1.setAttribute("dbalias", "thin:localhost:1521:xe");
        attrs1.setAttribute("datasource", "java:comp/env/jdbc/myDB");
        attrs1.setAttribute("user", "scott");
        attrs1.setAttribute("password", "tiger");
        attrs1.setAttribute("eager-release", "true");
        attrs1.setAttribute("batch-mode", "true");
        attrs1.setAttribute("use-autocommit", "1");
        attrs1.setAttribute("ignore-autocommit-exception", "false");
        handler.startElement(null, null, "jdbc-connection-descriptor", attrs1);

        
        System.out.println("\n--- Test 2: connection-pool ---");
        AttributesStub attrs2 = new AttributesStub();
        attrs2.setAttribute("max-active", "10");
        attrs2.setAttribute("max-idle", "5");
        attrs2.setAttribute("max-wait", "3000");
        attrs2.setAttribute("test-on-borrow", "true");
        attrs2.setAttribute("validation-query", "SELECT 1");
        handler.startElement(null, null, "connection-pool", attrs2);

        
        System.out.println("\n--- Test 3: object-cache ---");
        AttributesStub attrs3 = new AttributesStub();
        attrs3.setAttribute("class", "org.apache.ojb.broker.cache.ObjectCacheDefault");
        handler.startElement(null, null, "object-cache", attrs3);

        
        System.out.println("\n--- Test 4: sequence-manager ---");
        AttributesStub attrs4 = new AttributesStub();
        attrs4.setAttribute("sequence-manager-class", "org.apache.ojb.broker.sequence.SequenceManagerDefault");
        handler.startElement(null, null, "sequence-manager", attrs4);

        
        System.out.println("\n--- Test 5: attribute ---");
        AttributesStub attrs5 = new AttributesStub();
        attrs5.setAttribute("name", "pool.extra");
        attrs5.setAttribute("value", "some-value");
        handler.startElement(null, null, "attribute", attrs5);

        System.out.println("\n=== All tests completed successfully ===");
    }
}
