import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;






public class method_2_mrm_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    
    static class HttpServletRequest {
        public String getPathInfo() { return null; }
        public String getServletPath() { return ""; }
        public String getContextPath() { return ""; }
        public String getScheme() { return "http"; }
        public String getServerName() { return "localhost"; }
        public int getServerPort() { return 8080; }
    }

    static class HttpServletResponse {
        private int status;
        private String contentType;
        private ByteArrayOutputStream baos = new ByteArrayOutputStream();
        private PrintWriter writer;
        public void setContentType(String type) { contentType = type; }
        public void setContentLength(int len) {  }
        public PrintWriter getWriter() { if (writer == null) writer = new PrintWriter(baos); return writer; }
        public OutputStream getOutputStream() { return baos; }
        public void sendRedirect(String location) throws IOException {  }
        public void sendError(int code) throws IOException { status = code; }
        public int getStatus() { return status; }
        public String getContent() { return baos.toString(); }
        public byte[] getContentBytes() { return baos.toByteArray(); }
    }

    static class ServletException extends Exception {
        public ServletException(String msg) { super(msg); }
        public ServletException(String msg, Throwable cause) { super(msg, cause); }
    }

    
    static class Entry {
        private String name;
        private Entry parent;
        public Entry(String name, Entry parent) { this.name = name; this.parent = parent; }
        public String getName() { return name; }
        public Entry getParent() { return parent; }
        public long getLastModified() throws IOException { return System.currentTimeMillis(); }
    }

    static class DirectoryEntry extends Entry {
        public DirectoryEntry(String name, Entry parent) { super(name, parent); }
    }

    static class FileEntry extends Entry {
        private byte[] data;
        private long size;
        public FileEntry(String name, Entry parent, byte[] data) { super(name, parent); this.data = data; this.size = data.length; }
        public long getSize() throws IOException { return size; }
        public InputStream getInputStream() { return new ByteArrayInputStream(data); }
    }

    static class FileSystem {
        private DirectoryEntry root;
        private Map<String, Entry> entries = new HashMap<>();

        public FileSystem() {
            root = new DirectoryEntry("", null);
            entries.put("/", root);
            
            DirectoryEntry dir = new DirectoryEntry("test", root);
            entries.put("/test", dir);
            FileEntry file = new FileEntry("test.txt", dir, "Hello".getBytes());
            entries.put("/test/test.txt", file);
            
            FileEntry settings = new FileEntry("settings-mrm.xml", root, 
                "<settings><proxy><id>@repository.proxy.url@</id></proxy></settings>".getBytes());
            entries.put("/settings-mrm.xml", settings);
        }

        public Entry get(String path) {
            if (path.startsWith("/")) path = path.substring(1);
            if (path.isEmpty()) return root;
            
            if (path.endsWith("/")) path = path.substring(0, path.length()-1);
            return entries.get("/" + path);
        }

        public Entry[] listEntries(DirectoryEntry dir) throws IOException {
            List<Entry> list = new ArrayList<>();
            String base = null;
            for (String key : entries.keySet()) {
                if (key.startsWith("/") && key.length() > 1) {
                    String[] parts = key.substring(1).split("/");
                    if (parts.length == 1) {
                        Entry e = entries.get(key);
                        if (e.getParent() == dir) {
                            list.add(e);
                        }
                    }
                }
            }
            return list.toArray(new Entry[0]);
        }
    }

    
    static class Utils {
        public static String urlEncodePathSegment(String segment) {
            try {
                return URLEncoder.encode(segment, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                return segment;
            }
        }
    }

    
    static class InterpolationFilterReader extends Reader {
        private String input;
        private int index = 0;
        public InterpolationFilterReader(Reader in, Map<String, Object> context, String start, String end) throws IOException {
            StringBuilder sb = new StringBuilder();
            int ch;
            while ((ch = in.read()) != -1) sb.append((char)ch);
            String content = sb.toString();
            for (Map.Entry<String, Object> e : context.entrySet()) {
                String key = start + e.getKey() + end;
                content = content.replace(key, e.getValue().toString());
            }
            this.input = content;
        }
        public int read(char[] cbuf, int off, int len) throws IOException {
            if (index >= input.length()) return -1;
            int toCopy = Math.min(len, input.length() - index);
            input.getChars(index, index+toCopy, cbuf, off);
            index += toCopy;
            return toCopy;
        }
        public void close() {  }
    }

    
    
    

    static class StringUtils {
        public static String stripEnd(String str, String stripChars) {
            if (str == null) return null;
            int end = str.length();
            while (end > 0 && stripChars.indexOf(str.charAt(end-1)) != -1) end--;
            return str.substring(0, end);
        }
        public static String stripStart(String str, String stripChars) {
            if (str == null) return null;
            int start = 0;
            while (start < str.length() && stripChars.indexOf(str.charAt(start)) != -1) start++;
            return str.substring(start);
        }
        public static String repeat(String str, int repeat) {
            if (str == null) return null;
            StringBuilder sb = new StringBuilder(str.length() * repeat);
            for (int i = 0; i < repeat; i++) sb.append(str);
            return sb.toString();
        }
        public static String leftPad(String str, int size) {
            if (str == null) return null;
            if (str.length() >= size) return str;
            StringBuilder sb = new StringBuilder(size);
            for (int i = 0; i < size - str.length(); i++) sb.append(' ');
            sb.append(str);
            return sb.toString();
        }
        public static String leftPad(long num, int size) { return leftPad(Long.toString(num), size); }
    }

    
    static class IOUtils {
        public static void closeQuietly(Closeable c) { try { if (c != null) c.close(); } catch (IOException e) {} }
        public static void closeQuietly(InputStream is) { closeQuietly((Closeable)is); }
        public static void copy(InputStream in, OutputStream out) throws IOException {
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) != -1) out.write(buf, 0, len);
        }
    }

    static class IOUtil {
        public static void close(Reader r) { try { if (r != null) r.close(); } catch (IOException e) {} }
        public static void copy(Reader in, Writer out) throws IOException {
            char[] buf = new char[8192];
            int len;
            while ((len = in.read(buf)) != -1) out.write(buf, 0, len);
        }
    }

    

    static class FileSystemServlet extends HttpServlet {
        private FileSystem fileSystem = new FileSystem();
        private String settingsServletPath = "settings";

        
        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        protected void doGet( HttpServletRequest req, HttpServletResponse resp )
                throws ServletException, IOException
        {
            String path = req.getPathInfo();
            String context;
            if ( path == null )
            {
                path = req.getServletPath();
                context = req.getContextPath();
            }
            else
            {
                context = req.getContextPath() + req.getServletPath();
            }

            if ( path.equals( "/" + settingsServletPath ) )
            {
                resp.setContentType( "text/xml" );
                PrintWriter w = resp.getWriter();

                Reader settingsReader = null;
                try
                {
                    String hostAddress;
                    try
                    {
                        hostAddress = InetAddress.getLocalHost().getHostAddress();
                    }
                    catch ( UnknownHostException e )
                    {
                        hostAddress = req.getServerName();
                    }

                    String repositoryProxyUrl = req.getScheme() + "://" + hostAddress + ":" + req.getServerPort();
                    InputStream settingsStream = FileSystemServlet.class.getResourceAsStream( "/settings-mrm.xml" );
                    Reader in = settingsStream == null
                        ? new StringReader("<settings><proxy><id>@repository.proxy.url@</id></proxy></settings>")
                        : new InputStreamReader(settingsStream);
                    settingsReader = new InterpolationFilterReader( in, Collections.<String, Object>singletonMap( "repository.proxy.url", repositoryProxyUrl ), "@", "@" );
                    IOUtil.copy( settingsReader, w );
                }
                finally
                {
                    IOUtil.close( settingsReader );
                }
                return;
            }

            Entry entry = fileSystem.get( path );
            if ( entry instanceof FileEntry )
            {
                FileEntry fileEntry = (FileEntry) entry;
                long size = fileEntry.getSize();
                if ( size >= 0 && size < Integer.MAX_VALUE )
                {
                    resp.setContentLength( (int) size );
                }
                resp.setContentType( "text/plain" ); 
                InputStream source = null;
                OutputStream destination = null;
                try
                {
                    source = fileEntry.getInputStream();
                    destination = resp.getOutputStream();
                    IOUtils.copy( source, destination );
                }
                finally
                {
                    IOUtils.closeQuietly( source );
                    IOUtils.closeQuietly( destination );
                }
                return;
            }
            else if ( entry instanceof DirectoryEntry )
            {
                if ( !path.endsWith( "/" ) )
                {
                    resp.sendRedirect( entry.getName() + "/" );
                    return;
                }
                DirectoryEntry dirEntry = (DirectoryEntry) entry;
                Entry[] entries = fileSystem.listEntries( dirEntry );
                resp.setContentType( "text/html" );
                PrintWriter w = resp.getWriter();
                w.println( "<html>" );
                w.println( "  <head>" );
                w.println( "    <title>Index of " + context + path + "</title>" );
                w.println( "    <meta http-equiv=\"Content-Type\" repository=\"text/html; charset=utf-8\"/>" );
                w.println( "</head>" );
                w.println( "<body>" );
                w.println( "<h1>Index of " + context + path + "</h1>" );
                w.println( "  <hr/>" );
                w.write( "<pre>" );

                if ( dirEntry.getParent() != null )
                {
                    w.println( "<a href='../'>../</a>" );
                }
                SimpleDateFormat format = new SimpleDateFormat( "dd-MMM-yyyy hh:mm" );
                if ( entries != null )
                {
                    for ( int i = 0; i < entries.length; i++ )
                    {
                        final String childName = entries[i].getName();
                        boolean directory = entries[i] instanceof DirectoryEntry;
                        if ( directory )
                        {
                            String dirName = childName + "/";
                            w.write(
                                "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "/\">" + formatName( dirName )
                                    + "</a>" + StringUtils.repeat( " ",
                                                                   Math.max( 0, NAME_COL_WIDTH - dirName.length() ) ) );
                        }
                        else
                        {
                            w.write(
                                "<a href=\"./" + Utils.urlEncodePathSegment( childName ) + "\">" + formatName( childName )
                                    + "</a>" + StringUtils.repeat( " ",
                                                                   Math.max( 0, NAME_COL_WIDTH - childName.length() ) ) );
                        }

                        long timestamp = 0;
                        try
                        {
                            timestamp = entries[i].getLastModified();
                        }
                        catch ( IOException e )
                        {
                            
                        }

                        w.write( " " );
                        w.write( format.format( timestamp != -1 ? new Date( timestamp ) : new Date() ) );
                        if ( directory )
                        {
                            w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                        }
                        else if ( entries[i] instanceof FileEntry )
                        {
                            FileEntry fileEntry = (FileEntry) entries[i];
                            try
                            {
                                long size = fileEntry.getSize();
                                if ( size >= 0 )
                                {
                                    w.println( StringUtils.leftPad( Long.toString( size ), SIZE_COL_WIDTH ) );
                                }
                                else
                                {
                                    w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                                }
                            }
                            catch ( IOException e )
                            {
                                w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                            }
                        }
                        else
                        {
                            w.println( StringUtils.leftPad( "-", SIZE_COL_WIDTH ) );
                        }
                    }
                }
                w.write( "</pre>" );
                w.println( "  <hr/>" );
                w.println( "</body>" );
                w.println( "</html>" );
                return;
            }

            resp.sendError( 404 );
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        

        
        private static final int NAME_COL_WIDTH = 30;
        private static final int SIZE_COL_WIDTH = 12;

        private String formatName(String name) {
            
            return name;
        }
    }

    
    static class HttpServlet {
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing FileSystemServlet.doGet ===\n");

        FileSystemServlet servlet = new FileSystemServlet();
        HttpServletRequest req = new HttpServletRequest() {
            @Override public String getPathInfo() { return "/test/test.txt"; }
            @Override public String getServletPath() { return ""; }
            @Override public String getContextPath() { return ""; }
        };
        HttpServletResponse resp = new HttpServletResponse();

        try {
            servlet.doGet(req, resp);
            System.out.println("Response status: " + resp.getStatus());
            System.out.println("Response content type: " + resp.contentType);
            System.out.println("Response body (first 100 chars):");
            String content = resp.getContent();
            if (content != null && content.length() > 100) {
                System.out.println(content.substring(0, 100) + "...");
            } else {
                System.out.println(content);
            }

            
            System.out.println("\n--- Testing directory listing ---");
            req = new HttpServletRequest() {
                @Override public String getPathInfo() { return "/test/"; }
                @Override public String getServletPath() { return ""; }
                @Override public String getContextPath() { return ""; }
            };
            resp = new HttpServletResponse();
            servlet.doGet(req, resp);
            System.out.println("Directory listing status: " + resp.getStatus());
            
            String html = resp.getContent();
            if (html != null && html.length() > 200) {
                System.out.println(html.substring(0, 200) + "...");
            } else {
                System.out.println(html);
            }

            
            System.out.println("\n--- Testing settings endpoint ---");
            req = new HttpServletRequest() {
                @Override public String getPathInfo() { return "/settings"; }
                @Override public String getServletPath() { return ""; }
                @Override public String getContextPath() { return ""; }
            };
            resp = new HttpServletResponse();
            servlet.doGet(req, resp);
            System.out.println("Settings response status: " + resp.getStatus());
            System.out.println("Settings content:\n" + resp.getContent());

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}