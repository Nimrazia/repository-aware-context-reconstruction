import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.net.URL;






public class method_1_mrm_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    

    
    static class Artifact {
        private String groupId, artifactId, version, type, classifier;
        private Integer buildNumber;
        private String timestampString;

        public Artifact(String g, String a, String v, String t) { this.groupId=g; this.artifactId=a; this.version=v; this.type=t; }
        public Artifact(String g, String a, String v, String t, String c) { this(g,a,v,t); this.classifier=c; }
        public String getGroupId() { return groupId; }
        public String getArtifactId() { return artifactId; }
        public String getVersion() { return version; }
        public String getType() { return type; }
        public String getClassifier() { return classifier; }
        public Integer getBuildNumber() { return buildNumber; }
        public String getTimestampString() { return timestampString; }
        public void setBuildNumber(Integer bn) { this.buildNumber = bn; }
        public void setTimestampString(String ts) { this.timestampString = ts; }
        @Override public String toString() { return groupId+":"+artifactId+":"+version+":"+type; }
    }

    static class ArtifactNotFoundException extends Exception {
        public ArtifactNotFoundException(String msg) { super(msg); }
        public ArtifactNotFoundException(String msg, Throwable cause) { super(msg, cause); }
    }


    static class MetadataNotFoundException extends Exception {
        MetadataNotFoundException(String path) { super("Metadata not found: " + path); }
    }
    static class Metadata {
        private String groupId, artifactId, version;
        private List<Plugin> plugins = new ArrayList<>();
        private Versioning versioning;

        public void setGroupId(String g) { this.groupId = g; }
        public void setArtifactId(String a) { this.artifactId = a; }
        public void setVersion(String v) { this.version = v; }
        public void setPlugins(List<Plugin> p) { this.plugins = p; }
        public void addPlugin(Plugin p) { plugins.add(p); }
        public void setVersioning(Versioning v) { this.versioning = v; }
        public String getGroupId() { return groupId; }
        public String getArtifactId() { return artifactId; }
        public String getVersion() { return version; }
        public List<Plugin> getPlugins() { return plugins; }
        public Versioning getVersioning() { return versioning; }
    }

    static class Plugin {
        private String artifactId, prefix, name;
        public void setArtifactId(String a) { this.artifactId = a; }
        public void setPrefix(String p) { this.prefix = p; }
        public void setName(String n) { this.name = n; }
        public String getArtifactId() { return artifactId; }
        public String getPrefix() { return prefix; }
        public String getName() { return name; }
    }

    static class Versioning {
        private String latest, release, lastUpdated;
        private List<String> versions = new ArrayList<>();
        private Snapshot snapshot;
        private List<SnapshotVersion> snapshotVersions = new ArrayList<>();

        public void setLatest(String l) { latest = l; }
        public void setRelease(String r) { release = r; }
        public void setLastUpdated(String lu) { lastUpdated = lu; }
        public void setLastUpdatedTimestamp(Date d) { lastUpdated = new SimpleDateFormat("yyyyMMddHHmmss").format(d); }
        public void addVersion(String v) { versions.add(v); }
        public void setSnapshot(Snapshot s) { snapshot = s; }
        public void addSnapshotVersion(SnapshotVersion sv) { snapshotVersions.add(sv); }
        public String getLatest() { return latest; }
        public String getRelease() { return release; }
        public String getLastUpdated() { return lastUpdated; }
        public List<String> getVersions() { return versions; }
        public Snapshot getSnapshot() { return snapshot; }
        public List<SnapshotVersion> getSnapshotVersions() { return snapshotVersions; }
    }

    static class Snapshot {
        private int buildNumber;
        private String timestamp;
        public void setBuildNumber(int b) { buildNumber = b; }
        public void setTimestamp(String t) { timestamp = t; }
        public int getBuildNumber() { return buildNumber; }
        public String getTimestamp() { return timestamp; }
    }

    static class SnapshotVersion {
        private String version, classifier, extension;
        public void setVersion(String v) { version = v; }
        public void setClassifier(String c) { classifier = c; }
        public void setExtension(String e) { extension = e; }
        public String getVersion() { return version; }
        public String getClassifier() { return classifier; }
        public String getExtension() { return extension; }
    }

    static class Content {
        private long lastModified;
        public Content(long lm) { lastModified = lm; }
        public long getLastModified() { return lastModified; }
    }

    static class VersionComparator implements Comparator<String> {
        
        public int compare(String a, String b) { return a.compareTo(b); }
    }

    
    static class Model {
        private String packaging;
        private String name;
        private Build build;
        public void setPackaging(String p) { packaging = p; }
        public void setName(String n) { name = n; }
        public void setBuild(Build b) { build = b; }
        public String getPackaging() { return packaging; }
        public String getName() { return name; }
        public Build getBuild() { return build; }
    }

    static class Build {
        private List<MavenPlugin> plugins;
        private Build pluginManagement;
        public void setPlugins(List<MavenPlugin> p) { plugins = p; }
        public void setPluginManagement(Build pm) { pluginManagement = pm; }
        public List<MavenPlugin> getPlugins() { return plugins; }
        public Build getPluginManagement() { return pluginManagement; }
    }

    static class MavenPlugin {
        private String artifactId;
        private Map<String, Object> configuration = new HashMap<>();
        public void setArtifactId(String a) { artifactId = a; }
        public String getArtifactId() { return artifactId; }
        public Map<String, Object> getConfiguration() { return configuration; }
        public void setConfiguration(Map<String, Object> conf) { configuration = conf; }
        
    }

    static class MavenXpp3Reader {
        public Model read(Reader reader) throws Exception {
            
            Model model = new Model();
            model.setPackaging("maven-plugin");
            model.setName("Test Plugin");
            Build build = new Build();
            List<MavenPlugin> plugins = new ArrayList<>();
            MavenPlugin mp = new MavenPlugin();
            mp.setArtifactId("maven-plugin-plugin");
            Map<String,Object> config = new HashMap<>();
            config.put("goalPrefix", "test");
            mp.setConfiguration(config);
            plugins.add(mp);
            build.setPlugins(plugins);
            model.setBuild(build);
            return model;
        }
    }

    static class XmlStreamReader extends Reader {
        private Reader delegate;
        public XmlStreamReader(InputStream in) { delegate = new InputStreamReader(in); }
        public int read(char[] cbuf, int off, int len) throws IOException { return delegate.read(cbuf, off, len); }
        public void close() throws IOException { delegate.close(); }
    }

    
    static class StringUtils {
        public static String stripEnd(String str, String stripChars) {
            if (str == null) return null;
            int end = str.length();
            while (end > 0 && stripChars.indexOf(str.charAt(end-1)) != -1) end--;
            return str.substring(0, end);
        }
        public static String stripStart(String str, String stripChars) {
            if (str == null) return null;
            int start = 0;
            while (start < str.length() && stripChars.indexOf(str.charAt(start)) != -1) start++;
            return str.substring(start);
        }
        public static String removeStart(String str, String remove) {
            if (str == null || !str.startsWith(remove)) return str;
            return str.substring(remove.length());
        }
        public static String removeEnd(String str, String remove) {
            if (str == null || !str.endsWith(remove)) return str;
            return str.substring(0, str.length() - remove.length());
        }
        public static String repeat(String str, int repeat) {
            if (str == null) return null;
            StringBuilder sb = new StringBuilder(str.length() * repeat);
            for (int i = 0; i < repeat; i++) sb.append(str);
            return sb.toString();
        }
        public static String leftPad(String str, int size) {
            if (str == null) return null;
            if (str.length() >= size) return str;
            StringBuilder sb = new StringBuilder(size);
            for (int i = 0; i < size - str.length(); i++) sb.append(' ');
            sb.append(str);
            return sb.toString();
        }
        public static String leftPad(long num, int size) { return leftPad(Long.toString(num), size); }
    }

    
    static class IOUtils {
        public static void closeQuietly(Closeable c) { try { if (c != null) c.close(); } catch (IOException e) {} }
        public static void closeQuietly(InputStream is) { closeQuietly((Closeable)is); }
    }

    
    static class Maven3 {
        public static void addSnapshotVersion(List<SnapshotVersion> list, Artifact artifact, String timestamp) {
            SnapshotVersion sv = new SnapshotVersion();
            sv.setVersion(artifact.getVersion());
            sv.setClassifier(artifact.getClassifier());
            sv.setExtension(artifact.getType());
            list.add(sv);
        }
        public static void addSnapshotVersions(Versioning versioning, List<SnapshotVersion> list) {
            for (SnapshotVersion sv : list) versioning.addSnapshotVersion(sv);
        }
    }

    

    static class MockArtifactStore {
        private Map<String, Map<String, Map<String, Map<Artifact, Content>>>> contents = new HashMap<>();
        private Map<String, Set<String>> artifactIds = new HashMap<>();
        private Map<String, Map<String, Set<String>>> versionsMap = new HashMap<>();

        
        public Set<String> getArtifactIds(String groupId) {
            return artifactIds.get(groupId);
        }
        public Set<String> getVersions(String groupId, String artifactId) {
            Map<String, Set<String>> map = versionsMap.get(groupId);
            return map == null ? null : map.get(artifactId);
        }
        public InputStream get(Artifact artifact) throws ArtifactNotFoundException {
            
            String pom = "<project><modelVersion>4.0.0</modelVersion><groupId>test</groupId><artifactId>test</artifactId><version>1.0</version><packaging>maven-plugin</packaging><name>Test Plugin</name></project>";
            return new ByteArrayInputStream(pom.getBytes());
        }
        public long getLastModified(Artifact artifact) throws ArtifactNotFoundException {
            return System.currentTimeMillis();
        }
        private boolean setPluginGoalPrefixFromConfiguration(Plugin plugin, List<MavenPlugin> mavenPlugins) {
            for (MavenPlugin mp : mavenPlugins) {
                if (mp.getConfiguration() != null && mp.getConfiguration().containsKey("goalPrefix")) {
                    plugin.setPrefix((String) mp.getConfiguration().get("goalPrefix"));
                    return true;
                }
            }
            return false;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public synchronized Metadata getMetadata( String path )
                throws IOException, MetadataNotFoundException
        {
            Metadata metadata = new Metadata();
            boolean foundMetadata = false;
            path = StringUtils.stripEnd( StringUtils.stripStart( path, "/" ), "/" );
            String groupId = path.replace( '/', '.' );
            Set<String> pluginArtifactIds = getArtifactIds( groupId );
            if ( pluginArtifactIds != null )
            {
                List<Plugin> plugins = new ArrayList<Plugin>();
                for ( String artifactId : pluginArtifactIds )
                {
                    Set<String> pluginVersions = getVersions( groupId, artifactId );
                    if ( pluginVersions == null || pluginVersions.isEmpty() )
                    {
                        continue;
                    }
                    String[] versions = pluginVersions.toArray( new String[pluginVersions.size()] );
                    Arrays.sort( versions, new VersionComparator() );
                    MavenXpp3Reader reader = new MavenXpp3Reader();
                    for ( int j = versions.length - 1; j >= 0; j-- )
                    {
                        InputStream inputStream = null;
                        try
                        {
                            inputStream = get( new Artifact( groupId, artifactId, versions[j], "pom" ) );
                            Model model = reader.read( new XmlStreamReader( inputStream ) );
                            if ( model == null || !"maven-plugin".equals( model.getPackaging() ) )
                            {
                                continue;
                            }
                            Plugin plugin = new Plugin();
                            plugin.setArtifactId( artifactId );
                            plugin.setName( model.getName() );
                            
                            
                            
                            boolean havePrefix = false;
                            final Build build = model.getBuild();
                            if ( build != null && build.getPlugins() != null )
                            {
                                havePrefix = setPluginGoalPrefixFromConfiguration( plugin, build.getPlugins() );
                            }
                            if ( !havePrefix && build != null && build.getPluginManagement() != null
                                && build.getPluginManagement().getPlugins() != null )
                            {
                                havePrefix = setPluginGoalPrefixFromConfiguration( plugin,
                                                                                   build.getPluginManagement().getPlugins() );
                            }
                            if ( !havePrefix && artifactId.startsWith( "maven-" ) && artifactId.endsWith( "-plugin" ) )
                            {
                                plugin.setPrefix(
                                    StringUtils.removeStart( StringUtils.removeEnd( artifactId, "-plugin" ), "maven-" ) );
                                havePrefix = true;
                            }
                            if ( !havePrefix && artifactId.endsWith( "-maven-plugin" ) )
                            {
                                plugin.setPrefix( StringUtils.removeEnd( artifactId, "-maven-plugin" ) );
                                havePrefix = true;
                            }
                            if ( !havePrefix )
                            {
                                plugin.setPrefix( artifactId );
                            }
                            plugins.add( plugin );
                            foundMetadata = true;
                            break;
                        }
                        catch ( ArtifactNotFoundException e )
                        {
                            
                        }
                        catch ( Exception e )
                        {
                            
                        }
                        finally
                        {
                            IOUtils.closeQuietly( inputStream );
                        }
                    }
                }
                if ( !plugins.isEmpty() )
                {
                    metadata.setPlugins( plugins );
                }
            }
            int index = path.lastIndexOf( '/' );
            groupId = ( index == -1 ? groupId : groupId.substring( 0, index ) ).replace( '/', '.' );
            String artifactId = ( index == -1 ? null : path.substring( index + 1 ) );
            if ( artifactId != null )
            {
                Set<String> artifactVersions = getVersions( groupId, artifactId );
                if ( artifactVersions != null && !artifactVersions.isEmpty() )
                {
                    metadata.setGroupId( groupId );
                    metadata.setArtifactId( artifactId );
                    Versioning versioning = new Versioning();
                    List<String> versions = new ArrayList<String>( artifactVersions );
                    Collections.sort( versions, new VersionComparator() ); 
                    long lastUpdated = 0;
                    for ( String version : versions )
                    {
                        try
                        {
                            long lastModified = getLastModified( new Artifact( groupId, artifactId, version, "pom" ) );
                            versioning.addVersion( version );
                            if ( lastModified >= lastUpdated )
                            {
                                lastUpdated = lastModified;
                                versioning.setLastUpdatedTimestamp( new Date( lastModified ) );
                                versioning.setLatest( version );
                                if ( !version.endsWith( "-SNAPSHOT" ) )
                                {
                                    versioning.setRelease( version );
                                }
                            }
                        }
                        catch ( ArtifactNotFoundException e )
                        {
                            
                        }
                    }
                    metadata.setVersioning( versioning );
                    foundMetadata = true;
                }
            }

            int index2 = index == -1 ? -1 : path.lastIndexOf( '/', index - 1 );
            groupId = index2 == -1 ? groupId : groupId.substring( 0, index2 ).replace( '/', '.' );
            artifactId = index2 == -1 ? artifactId : path.substring( index2 + 1, index );
            String version = index2 == -1 ? null : path.substring( index + 1 );
            if ( version != null && version.endsWith( "-SNAPSHOT" ) )
            {
                Map<String, Map<String, Map<Artifact, Content>>> artifactMap = contents.get( groupId );
                Map<String, Map<Artifact, Content>> versionMap = ( artifactMap == null ? null : artifactMap.get( artifactId ) );
                Map<Artifact, Content> filesMap = ( versionMap == null ? null : versionMap.get( version ) );
                if ( filesMap != null )
                {
                    List<SnapshotVersion> snapshotVersions = new ArrayList<SnapshotVersion>();
                    int maxBuildNumber = 0;
                    long lastUpdated = 0;
                    String timestamp = null;
                    boolean found = false;
                    for ( final Map.Entry<Artifact, Content> entry : filesMap.entrySet() )
                    {
                        final Artifact artifact = entry.getKey();
                        final Content content = entry.getValue();
                        SimpleDateFormat fmt = new SimpleDateFormat( "yyyyMMddHHmmss" );
                        fmt.setTimeZone( TimeZone.getTimeZone( "GMT" ) );
                        String lastUpdatedTime = fmt.format( new Date( content.getLastModified() ) );
                        try
                        {
                            Maven3.addSnapshotVersion( snapshotVersions, artifact, lastUpdatedTime );
                        }
                        catch ( LinkageError e )
                        {
                            
                        }
                        if ( "pom".equals( artifact.getType() ) )
                        {
                            if ( artifact.getBuildNumber() != null
                                && maxBuildNumber < artifact.getBuildNumber().intValue() )
                            {
                                maxBuildNumber = artifact.getBuildNumber().intValue();
                                timestamp = artifact.getTimestampString();
                            }
                            else
                            {
                                maxBuildNumber = Math.max( 1, maxBuildNumber );
                            }
                            lastUpdated = Math.max( lastUpdated, content.getLastModified() );
                            found = true;
                        }
                    }

                    if ( !snapshotVersions.isEmpty() || found )
                    {
                        Versioning versioning = metadata.getVersioning();
                        if ( versioning == null )
                        {
                            versioning = new Versioning();
                        }
                        metadata.setGroupId( groupId );
                        metadata.setArtifactId( artifactId );
                        metadata.setVersion( version );
                        try
                        {
                            Maven3.addSnapshotVersions( versioning, snapshotVersions );
                        }
                        catch ( LinkageError e )
                        {
                            
                        }
                        if ( maxBuildNumber > 0 )
                        {
                            Snapshot snapshot = new Snapshot();
                            snapshot.setBuildNumber( maxBuildNumber );
                            snapshot.setTimestamp( timestamp );
                            versioning.setSnapshot( snapshot );
                        }
                        versioning.setLastUpdatedTimestamp( new Date( lastUpdated ) );
                        metadata.setVersioning( versioning );
                        foundMetadata = true;
                    }
                }

            }
            if ( !foundMetadata )
            {
                throw new MetadataNotFoundException( path );
            }
            return metadata;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing MockArtifactStore.getMetadata ===\n");

        MockArtifactStore store = new MockArtifactStore();

        
        
        Map<String, Map<String, Map<String, Map<Artifact, Content>>>> contents = store.contents;
        Map<String, Map<Artifact, Content>> artifactMap = new HashMap<>();
        Map<Artifact, Content> versionMap = new HashMap<>();
        Artifact pomArtifact = new Artifact("org.test", "test-plugin", "1.0-SNAPSHOT", "pom");
        pomArtifact.setBuildNumber(5);
        pomArtifact.setTimestampString("20230101120000");
        versionMap.put(pomArtifact, new Content(System.currentTimeMillis()));
        Artifact jarArtifact = new Artifact("org.test", "test-plugin", "1.0-SNAPSHOT", "jar");
        versionMap.put(jarArtifact, new Content(System.currentTimeMillis() - 1000));
        Map<String, Map<Artifact, Content>> versionMapWrapper = new HashMap<>();
        versionMapWrapper.put("1.0-SNAPSHOT", versionMap);
        Map<String, Map<String, Map<Artifact, Content>>> artifactMapWrapper = new HashMap<>();
        artifactMapWrapper.put("test-plugin", versionMapWrapper);
        contents.put("org.test", artifactMapWrapper);

        
        Set<String> pluginArtifactIds = new HashSet<>();
        pluginArtifactIds.add("test-plugin");
        store.artifactIds.put("org.test", pluginArtifactIds);
        Map<String, Set<String>> versionsMap = new HashMap<>();
        Set<String> versions = new HashSet<>();
        versions.add("1.0");
        versions.add("1.0-SNAPSHOT");
        versionsMap.put("test-plugin", versions);
        store.versionsMap.put("org.test", versionsMap);

        try {
            
            String path1 = "org/test/test-plugin/1.0-SNAPSHOT";
            Metadata meta1 = store.getMetadata(path1);
            System.out.println("Metadata for path: " + path1);
            System.out.println("  GroupId: " + meta1.getGroupId());
            System.out.println("  ArtifactId: " + meta1.getArtifactId());
            System.out.println("  Version: " + meta1.getVersion());
            if (meta1.getPlugins() != null && !meta1.getPlugins().isEmpty()) {
                for (Plugin p : meta1.getPlugins()) {
                    System.out.println("  Plugin: " + p.getArtifactId() + " prefix=" + p.getPrefix() + " name=" + p.getName());
                }
            }
            if (meta1.getVersioning() != null) {
                Versioning v = meta1.getVersioning();
                System.out.println("  Versioning: latest=" + v.getLatest() + ", release=" + v.getRelease() + ", lastUpdated=" + v.getLastUpdated());
                System.out.println("  Versions: " + v.getVersions());
                if (v.getSnapshot() != null) {
                    System.out.println("  Snapshot: build=" + v.getSnapshot().getBuildNumber() + ", timestamp=" + v.getSnapshot().getTimestamp());
                }
            }

            
            String path2 = "non/existent/path";
            try {
                store.getMetadata(path2);
            } catch (MetadataNotFoundException e) {
                System.out.println("\nExpected exception for non-existent path: " + e.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}