import java.io.IOException;
import java.util.*;






public class method_3_mrm_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    
    
    

    static class Metadata {
        private String groupId, artifactId, version;
        private List<Plugin> plugins = new ArrayList<>();
        private Versioning versioning;

        public void setGroupId(String g) { this.groupId = g; }
        public void setArtifactId(String a) { this.artifactId = a; }
        public void setVersion(String v) { this.version = v; }
        public void setPlugins(List<Plugin> p) { this.plugins = p; }
        public void addPlugin(Plugin p) { plugins.add(p); }
        public void setVersioning(Versioning v) { this.versioning = v; }
        public String getGroupId() { return groupId; }
        public String getArtifactId() { return artifactId; }
        public String getVersion() { return version; }
        public List<Plugin> getPlugins() { return plugins; }
        public Versioning getVersioning() { return versioning; }
    }

    static class Plugin {
        private String artifactId, prefix, name;
        public void setArtifactId(String a) { this.artifactId = a; }
        public void setPrefix(String p) { this.prefix = p; }
        public void setName(String n) { this.name = n; }
        public String getArtifactId() { return artifactId; }
        public String getPrefix() { return prefix; }
        public String getName() { return name; }
    }

    static class Versioning {
        private String latest, release, lastUpdated;
        private List<String> versions = new ArrayList<>();
        private Snapshot snapshot;
        private List<SnapshotVersion> snapshotVersions = new ArrayList<>();

        public void setLatest(String l) { latest = l; }
        public void setRelease(String r) { release = r; }
        public void setLastUpdated(String lu) { lastUpdated = lu; }
        public void addVersion(String v) { versions.add(v); }
        public void setSnapshot(Snapshot s) { snapshot = s; }
        public void addSnapshotVersion(SnapshotVersion sv) { snapshotVersions.add(sv); }
        public String getLatest() { return latest; }
        public String getRelease() { return release; }
        public String getLastUpdated() { return lastUpdated; }
        public List<String> getVersions() { return versions; }
        public Snapshot getSnapshot() { return snapshot; }
        public List<SnapshotVersion> getSnapshotVersions() { return snapshotVersions; }
    }

    static class Snapshot {
        private int buildNumber;
        private String timestamp;
        public void setBuildNumber(int b) { buildNumber = b; }
        public void setTimestamp(String t) { timestamp = t; }
        public int getBuildNumber() { return buildNumber; }
        public String getTimestamp() { return timestamp; }
    }

    static class SnapshotVersion {
        private String version, classifier, extension;
        public void setVersion(String v) { version = v; }
        public void setClassifier(String c) { classifier = c; }
        public void setExtension(String e) { extension = e; }
        public String getVersion() { return version; }
        public String getClassifier() { return classifier; }
        public String getExtension() { return extension; }
    }

    static class MetadataNotFoundException extends Exception {
        public MetadataNotFoundException(String path) { super("Metadata not found for " + path); }
    }

    static class ArtifactStore {
        
        public Metadata getMetadata(String path) throws IOException, MetadataNotFoundException {
            
            throw new MetadataNotFoundException(path);
        }
    }

    
    static class StringUtils {
        public static boolean isEmpty(String str) { return str == null || str.isEmpty(); }
        public static boolean isNotEmpty(String str) { return !isEmpty(str); }
        public static String stripEnd(String str, String stripChars) {
            if (str == null) return null;
            int end = str.length();
            while (end > 0 && stripChars.indexOf(str.charAt(end-1)) != -1) end--;
            return str.substring(0, end);
        }
        public static String stripStart(String str, String stripChars) {
            if (str == null) return null;
            int start = 0;
            while (start < str.length() && stripChars.indexOf(str.charAt(start)) != -1) start++;
            return str.substring(start);
        }
        
    }

    

    static class CompositeArtifactStore extends ArtifactStore {
        private ArtifactStore[] stores;

        public CompositeArtifactStore(ArtifactStore... stores) {
            this.stores = stores;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public Metadata getMetadata( String path )
                throws IOException, MetadataNotFoundException
        {
            boolean found = false;
            Metadata result = new Metadata();
            Set<String> pluginArtifactIds = new HashSet<String>();
            Set<String> snapshotVersions = new HashSet<String>();
            for ( int i = 0; i < stores.length; i++ )
            {
                try
                {
                    Metadata partial = stores[i].getMetadata( path );
                    if ( StringUtils.isEmpty( result.getArtifactId() ) && !StringUtils.isEmpty( partial.getArtifactId() ) )
                    {
                        result.setArtifactId( partial.getArtifactId() );
                        found = true;
                    }
                    if ( StringUtils.isEmpty( result.getGroupId() ) && !StringUtils.isEmpty( partial.getGroupId() ) )
                    {
                        result.setGroupId( partial.getGroupId() );
                        found = true;
                    }
                    if ( StringUtils.isEmpty( result.getVersion() ) && !StringUtils.isEmpty( partial.getVersion() ) )
                    {
                        result.setVersion( partial.getVersion() );
                        found = true;
                    }
                    if ( partial.getPlugins() != null && !partial.getPlugins().isEmpty() )
                    {
                        for ( Plugin plugin : partial.getPlugins() )
                        {
                            if ( !pluginArtifactIds.contains( plugin.getArtifactId() ) )
                            {
                                result.addPlugin( plugin );
                                pluginArtifactIds.add( plugin.getArtifactId() );
                            }
                        }
                        found = true;
                    }
                    if ( partial.getVersioning() != null )
                    {
                        Versioning rVers = result.getVersioning();
                        if ( rVers == null )
                        {
                            rVers = new Versioning();
                        }
                        Versioning pVers = partial.getVersioning();
                        String rLU = found ? rVers.getLastUpdated() : null;
                        String pLU = pVers.getLastUpdated();
                        if ( pLU != null && ( rLU == null || rLU.compareTo( pLU ) < 0 ) )
                        {
                            
                            if ( !StringUtils.isEmpty( pVers.getLatest() ) )
                            {
                                rVers.setLatest( pVers.getLatest() );
                            }

                            if ( !StringUtils.isEmpty( pVers.getRelease() ) )
                            {
                                rVers.setLatest( pVers.getRelease() );
                            }
                            rVers.setLastUpdated( pVers.getLastUpdated() );
                        }
                        for ( String version : pVers.getVersions() )
                        {
                            if ( !rVers.getVersions().contains( version ) )
                            {
                                rVers.addVersion( version );
                            }
                        }
                        if ( pVers.getSnapshot() != null )
                        {
                            if ( rVers.getSnapshot() == null
                                || pVers.getSnapshot().getBuildNumber() > rVers.getSnapshot().getBuildNumber() )
                            {
                                Snapshot snapshot = new Snapshot();
                                snapshot.setBuildNumber( pVers.getSnapshot().getBuildNumber() );
                                snapshot.setTimestamp( pVers.getSnapshot().getTimestamp() );
                                rVers.setSnapshot( snapshot );
                            }
                        }
                        try
                        {
                            if ( pVers.getSnapshotVersions() != null && !pVers.getSnapshotVersions().isEmpty() )
                            {
                                for ( SnapshotVersion snapshotVersion : pVers.getSnapshotVersions() )
                                {
                                    String key = snapshotVersion.getVersion() + "-" + snapshotVersion.getClassifier() + "."
                                        + snapshotVersion.getExtension();
                                    if ( !snapshotVersions.contains( key ) )
                                    {
                                        rVers.addSnapshotVersion( snapshotVersion );
                                        snapshotVersions.add( key );
                                    }
                                }
                            }
                        }
                        catch ( NoSuchMethodError e )
                        {
                            
                        }

                        result.setVersioning( rVers );
                        found = true;
                    }
                }
                catch ( MetadataNotFoundException e )
                {
                    
                }
            }
            if ( !found )
            {
                throw new MetadataNotFoundException( path );
            }
            return result;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing CompositeArtifactStore.getMetadata ===\n");

        
        ArtifactStore store1 = new ArtifactStore() {
            @Override
            public Metadata getMetadata(String path) throws IOException, MetadataNotFoundException {
                Metadata meta = new Metadata();
                if (path.equals("/org/test/test-plugin")) {
                    meta.setGroupId("org.test");
                    meta.setArtifactId("test-plugin");
                    meta.setVersion("1.0");
                    Versioning v = new Versioning();
                    v.addVersion("1.0");
                    v.addVersion("1.1");
                    v.setLatest("1.1");
                    v.setRelease("1.0");
                    v.setLastUpdated("20230101120000");
                    meta.setVersioning(v);
                    return meta;
                } else if (path.equals("/org/test/test-plugin/1.0-SNAPSHOT")) {
                    meta.setGroupId("org.test");
                    meta.setArtifactId("test-plugin");
                    meta.setVersion("1.0-SNAPSHOT");
                    Versioning v = new Versioning();
                    v.addVersion("1.0-SNAPSHOT");
                    Snapshot snap = new Snapshot();
                    snap.setBuildNumber(5);
                    snap.setTimestamp("20230101120000");
                    v.setSnapshot(snap);
                    meta.setVersioning(v);
                    return meta;
                }
                throw new MetadataNotFoundException(path);
            }
        };

        ArtifactStore store2 = new ArtifactStore() {
            @Override
            public Metadata getMetadata(String path) throws IOException, MetadataNotFoundException {
                Metadata meta = new Metadata();
                if (path.equals("/org/test/test-plugin")) {
                    
                    Plugin plugin = new Plugin();
                    plugin.setArtifactId("test-plugin");
                    plugin.setPrefix("test");
                    plugin.setName("Test Plugin from store2");
                    meta.addPlugin(plugin);
                    Versioning v = new Versioning();
                    v.addVersion("1.2");
                    v.setLatest("1.2");
                    v.setRelease("1.2");
                    v.setLastUpdated("20230102120000");
                    meta.setVersioning(v);
                    return meta;
                }
                throw new MetadataNotFoundException(path);
            }
        };

        CompositeArtifactStore composite = new CompositeArtifactStore(store1, store2);

        try {
            String path = "/org/test/test-plugin";
            Metadata result = composite.getMetadata(path);
            System.out.println("Metadata for path: " + path);
            System.out.println("  GroupId: " + result.getGroupId());
            System.out.println("  ArtifactId: " + result.getArtifactId());
            System.out.println("  Version: " + result.getVersion());
            if (result.getPlugins() != null && !result.getPlugins().isEmpty()) {
                for (Plugin p : result.getPlugins()) {
                    System.out.println("  Plugin: " + p.getArtifactId() + " prefix=" + p.getPrefix() + " name=" + p.getName());
                }
            }
            if (result.getVersioning() != null) {
                Versioning v = result.getVersioning();
                System.out.println("  Versioning: latest=" + v.getLatest() + ", release=" + v.getRelease() + ", lastUpdated=" + v.getLastUpdated());
                System.out.println("  Versions: " + v.getVersions());
                if (v.getSnapshot() != null) {
                    System.out.println("  Snapshot: build=" + v.getSnapshot().getBuildNumber() + ", timestamp=" + v.getSnapshot().getTimestamp());
                }
            }

            
            String path2 = "/org/test/test-plugin/1.0-SNAPSHOT";
            Metadata result2 = composite.getMetadata(path2);
            System.out.println("\nMetadata for path: " + path2);
            System.out.println("  Version: " + result2.getVersion());
            if (result2.getVersioning() != null && result2.getVersioning().getSnapshot() != null) {
                System.out.println("  Snapshot build: " + result2.getVersioning().getSnapshot().getBuildNumber());
            }

            
            String path3 = "/non/existent";
            try {
                composite.getMetadata(path3);
            } catch (MetadataNotFoundException e) {
                System.out.println("\nExpected exception for non-existent path: " + e.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}