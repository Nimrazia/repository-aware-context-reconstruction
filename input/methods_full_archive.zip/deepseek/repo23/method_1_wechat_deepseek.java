import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;




class License {
    private final String appId;
    public License(String appId) { this.appId = appId; }
    public String getAppId() { return appId; }
}


enum MediaType {
    IMAGE("image"), VOICE("voice"), VIDEO("video"), THUMB("thumb");
    private final String name;
    MediaType(String name) { this.name = name; }
    public String getName() { return name; }
}


class MediaFile {
    private final MediaType mediaType;
    private final File file;
    public MediaFile(MediaType type, File file) { this.mediaType = type; this.file = file; }
    public MediaType getMediaType() { return mediaType; }
    public File getFile() { return file; }
    @Override public String toString() { return "MediaFile[" + mediaType + "," + file.getName() + "]"; }
}


class AccessTokenUtil {
    public static String getAccessToken(License license) {
        return "fake_access_token_" + license.getAppId();
    }
}


enum WechatRequest {
    UPLOAD_MEDIA("https://api.weixin.qq.com/cgi-bin/media/upload?");
    private final String url;
    WechatRequest(String url) { this.url = url; }
    public String getUrl() { return url; }
}


class URIBuilder {
    private final String base;
    private String query = "";
    public URIBuilder(String base) { this.base = base; }
    public URIBuilder setParameter(String name, String value) {
        if (!query.isEmpty()) query += "&";
        query += name + "=" + value;
        return this;
    }
    public URI build() { return URI.create(base + (query.isEmpty() ? "" : "?" + query)); }
}

class HttpEntity {
    private final byte[] body;
    public HttpEntity(byte[] body) { this.body = body; }
    public byte[] getContent() { return body; }
}

class MultipartEntityBuilder {
    private final List<BodyPart> parts = new ArrayList<>();
    static class BodyPart {
        String name; byte[] content;
        BodyPart(String name, byte[] content) { this.name = name; this.content = content; }
    }
    public static MultipartEntityBuilder create() { return new MultipartEntityBuilder(); }
    public MultipartEntityBuilder addBinaryBody(String name, File file) {
        parts.add(new BodyPart(name, ("dummy content for " + file.getName()).getBytes()));
        return this;
    }
    public HttpEntity build() {
        StringBuilder sb = new StringBuilder();
        for (BodyPart p : parts) sb.append(p.name).append(":").append(new String(p.content)).append("\n");
        return new HttpEntity(sb.toString().getBytes());
    }
}


class Request {
    private final URI uri;
    private int connectTimeout = 5000;
    private int socketTimeout = 5000;
    private HttpEntity body;

    public static Request Post(URI uri) { return new Request(uri); }
    private Request(URI uri) { this.uri = uri; }

    public Request connectTimeout(int timeout) { this.connectTimeout = timeout; return this; }
    public Request socketTimeout(int timeout) { this.socketTimeout = timeout; return this; }
    public Request body(HttpEntity entity) { this.body = entity; return this; }

    public Response execute() throws IOException {
        
        String jsonResponse = "{\"errcode\":0,\"errmsg\":\"ok\",\"type\":\"image\",\"media_id\":\"MEDIA_ID_123\"}";
        return new Response(jsonResponse);
    }

    public static class Response {
        private final String content;
        public Response(String content) { this.content = content; }
        public String handleResponse(Object handler) { return content; }
    }
}

class HttpUtil {
    public static final int CONNECT_TIMEOUT = 3000;
    public static final int SOCKET_TIMEOUT = 5000;
    public static final Object UTF8_CONTENT_HANDLER = new Object() {
        @Override public String toString() { return "UTF8_CONTENT_HANDLER"; }
    };
}


class JsonRtn {
    protected boolean success;
    protected String message;
    public void setSuccess(boolean s) { this.success = s; }
    public void setMessage(String m) { this.message = m; }
    @Override public String toString() { return success + ": " + message; }
}
class MediaJsonRtn extends JsonRtn {
    private String mediaId;
    public String getMediaId() { return mediaId; }
    public void setMediaId(String id) { this.mediaId = id; }
    @Override public String toString() { return super.toString() + " [mediaId=" + mediaId + "]"; }
}

class JsonRtnUtil {
    public static <T extends JsonRtn> T buildFailureJsonRtn(Class<T> clazz, String msg) {
        try {
            T t = clazz.newInstance();
            t.setSuccess(false);
            t.setMessage(msg);
            return t;
        } catch (Exception e) { throw new RuntimeException(e); }
    }
    public static <T extends JsonRtn> T parseJsonRtn(String json, Class<T> clazz) {
        try {
            
            T t = clazz.newInstance();
            t.setSuccess(true);
            if (clazz == MediaJsonRtn.class && json.contains("media_id")) {
                ((MediaJsonRtn)t).setMediaId("MEDIA_ID_123");
            }
            return t;
        } catch (Exception e) { return buildFailureJsonRtn(clazz, "parse error"); }
    }
}


class Log {
    public void info(String format, Object... args) { System.out.println("INFO: " + String.format(format, args)); }
    public void error(String format, Object... args) { System.err.println("ERROR: " + String.format(format, args)); }
}


public class method_1_wechat_deepseek {
    private static final Log log = new Log();

    
    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public static MediaJsonRtn uploadMedia(License license, MediaFile mediaFile) {
        if (mediaFile == null) {
            return JsonRtnUtil.buildFailureJsonRtn(MediaJsonRtn.class, "missing mediaFile");
        }
        

        String accessToken = AccessTokenUtil.getAccessToken(license);
        String url = WechatRequest.UPLOAD_MEDIA.getUrl();
        try {
            MediaType mediaType = mediaFile.getMediaType();
            URI uri = new URIBuilder(url)
                    .setParameter("access_token", accessToken)
                    .setParameter("type", mediaType.getName())
                    .build();

            HttpEntity httpEntity = MultipartEntityBuilder.create()
                    .addBinaryBody("body", mediaFile.getFile())
                    .build();

            String rtnJson = Request.Post(uri)
                    .connectTimeout(HttpUtil.CONNECT_TIMEOUT)
                    .socketTimeout(HttpUtil.SOCKET_TIMEOUT)
                    .body(httpEntity)
                    .execute().handleResponse(HttpUtil.UTF8_CONTENT_HANDLER);

            MediaJsonRtn jsonRtn = JsonRtnUtil.parseJsonRtn(rtnJson, MediaJsonRtn.class);
            log.info("upload media:\n url={},\n body={},\n rtn={},{}", uri, mediaFile, rtnJson, jsonRtn);
            return jsonRtn;
        } catch (Exception e) {
            String msg = "upload media failed:\n " +
                    "url=" + url + "?access_token=" + accessToken + ",\n body=" + mediaFile;
            log.error(msg, e);
            return JsonRtnUtil.buildFailureJsonRtn(MediaJsonRtn.class, "uploadMedia failed");
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        License lic = new License("testApp");
        MediaFile file = new MediaFile(MediaType.IMAGE, new File("dummy.jpg"));
        MediaJsonRtn result = uploadMedia(lic, file);
        System.out.println("Result: " + result);
        
        MediaJsonRtn failResult = uploadMedia(lic, null);
        System.out.println("Fail result: " + failResult);
    }
}