import java.io.*;

class ServletException extends Exception {
    public ServletException() {}
    public ServletException(String message) { super(message); }
}

interface HttpServletRequest { }
interface HttpServletResponse { PrintWriter getWriter() throws IOException; }

class HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { }
}

class SimpleLog {
    void info(String format, Object value) {
        System.out.println("[INFO] " + format.replace("{}", String.valueOf(value)));
    }
    void error(String message, Throwable error) {
        System.err.println("[ERROR] " + message + ": " + error.getMessage());
    }
}

class Signature {
    private String echostr;
    public String getEchostr() { return echostr; }
    public void setEchostr(String value) { echostr = value; }
    @Override public String toString() { return "Signature{echostr=" + echostr + "}"; }
}

class WebUtil {
    public static void outputString(HttpServletResponse response, String content) throws IOException {
        response.getWriter().write(content);
        response.getWriter().flush();
    }
}

class AccessServlet extends HttpServlet {
    private static final SimpleLog log = new SimpleLog();

    protected boolean checkSignature(Signature signature, HttpServletRequest request) {
        signature.setEchostr("test_echo_string_123");
        return true;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Signature signature = new Signature();
            boolean hasRights = checkSignature(signature, request);

            if (hasRights) {
                log.info("signature-success:{}", signature);
                WebUtil.outputString(response, signature.getEchostr());
            } else {
                log.info("signature-not-match:{}", signature);
            }
        } catch (Exception e) {
            log.error("signature-error", e);
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}

public class method_3_wechat_deepseek {
    public static void main(String[] args) throws Exception {
        AccessServlet servlet = new AccessServlet();
        HttpServletRequest request = new HttpServletRequest() { };
        StringWriter output = new StringWriter();
        HttpServletResponse response = new HttpServletResponse() {
            private final PrintWriter writer = new PrintWriter(output);
            public PrintWriter getWriter() { return writer; }
        };

        servlet.doGet(request, response);
        System.out.println("Response: " + output);
        System.out.println("AccessServlet doGet completed.");
    }
}
