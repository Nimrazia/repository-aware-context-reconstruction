import java.util.*;



class OWLAxiom {
    private String id;
    public OWLAxiom(String id) { this.id = id; }
    @Override public boolean equals(Object o) { return o instanceof OWLAxiom && id.equals(((OWLAxiom)o).id); }
    @Override public int hashCode() { return id.hashCode(); }
    @Override public String toString() { return id; }
}

class Explanation<E> {
    private E entailment; private Set<OWLAxiom> axioms;
    public Explanation(E e, Set<OWLAxiom> ax) { entailment = e; axioms = ax; }
    public Set<OWLAxiom> getAxioms() { return axioms; }
    public E getEntailment() { return entailment; }
}

interface ExplanationGenerator<E> {
    Set<Explanation<E>> getExplanations(E entailment) throws OWLException, ExplanationGeneratorInterruptedException;
}
interface ExplanationGeneratorFactory<E> {
    ExplanationGenerator<E> createExplanationGenerator(Set<OWLAxiom> axioms, Object monitor);
}

class OWLOntology {
    private Set<OWLAxiom> logicalAxioms = new HashSet<>();
    public Set<OWLAxiom> getLogicalAxioms() { return logicalAxioms; }
}

class ExplanationGeneratorInterruptedException extends RuntimeException {}
class OWLException extends Exception {}


public class method_6_owlexp_deepseek {

    private int limit;
    private Set<Explanation<OWLAxiom>> foundLaconicJustifications = new HashSet<>();
    private Set<Explanation<OWLAxiom>> allPreviouslyFoundJustifications = new HashSet<>();
    private Set<Explanation<OWLAxiom>> lastRegularJusts = new HashSet<>();
    private OWLOntology ont = new OWLOntology();
    private Set<OWLAxiom> axioms = new HashSet<>();
    private ExplanationGeneratorFactory<OWLAxiom> explanationGeneratorFactory = new ExplanationGeneratorFactory<OWLAxiom>() {
        public ExplanationGenerator<OWLAxiom> createExplanationGenerator(Set<OWLAxiom> axs, Object monitor) {
            return entailment -> {
                
                Set<Explanation<OWLAxiom>> justs = new HashSet<>();
                justs.add(new Explanation<>(entailment, new HashSet<>(Arrays.asList(new OWLAxiom("C")))));
                return justs;
            };
        }
    };
    private boolean cancelled = false;

    private boolean isCancelled() { return cancelled; }

    private Set<OWLAxiom> computeOPlus(Set<OWLAxiom> axs) { return new HashSet<>(axs); } 

    
    
    
    
    private Set<Explanation<OWLAxiom>> getReconstitutedLaconicJustifications() {
        
        return new HashSet<>(foundLaconicJustifications);
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public Set<Explanation<OWLAxiom>> computePreciseJustsOptimised(OWLAxiom entailment, int limit) throws OWLException {
        this.limit = limit;
        foundLaconicJustifications.clear();
        ExplanationGenerator<OWLAxiom> gen = explanationGeneratorFactory.createExplanationGenerator(axioms, this);
        Set<Explanation<OWLAxiom>> regularJusts = null;
        try {
            regularJusts = gen.getExplanations(entailment);
        }
        catch (ExplanationGeneratorInterruptedException e) {
            
            return foundLaconicJustifications;
        }
        if (isCancelled()) {
            return foundLaconicJustifications;
        }
        lastRegularJusts.clear();

        
        allPreviouslyFoundJustifications = new HashSet<Explanation<OWLAxiom>>();
        allPreviouslyFoundJustifications.addAll(regularJusts);




        Set<OWLAxiom> axiomsInPreviousOntology = new HashSet<OWLAxiom>();

        
        while (true) {

            if (isCancelled()) {
                return getReconstitutedLaconicJustifications();
            }
            
            

            Set<OWLAxiom> unionOfAllJustifications = new HashSet<OWLAxiom>();
            for (Explanation<OWLAxiom> exp : allPreviouslyFoundJustifications) {
                unionOfAllJustifications.addAll(exp.getAxioms());
            }
            Set<OWLAxiom> oPlus = computeOPlus(unionOfAllJustifications);

            
            Set<OWLAxiom> augmentedAxioms = new HashSet<OWLAxiom>(oPlus);

            
            
            

            
            
            
            
            
            
            
            
            for (OWLAxiom ax : ont.getLogicalAxioms()) {
                
                
                if (unionOfAllJustifications.contains(ax) && !oPlus.contains(ax)) {
                    continue;
                }
                augmentedAxioms.add(ax);
            }

            
            

            


            if (augmentedAxioms.equals(axiomsInPreviousOntology)) {
                break;
            }

            ExplanationGenerator<OWLAxiom> gen2 = explanationGeneratorFactory.createExplanationGenerator(augmentedAxioms, this);

            axiomsInPreviousOntology.clear();
            axiomsInPreviousOntology.addAll(augmentedAxioms);

            Set<Explanation> allPrevJustsCopy = new HashSet<Explanation>(allPreviouslyFoundJustifications);

            
            Set<Explanation<OWLAxiom>> currentJustifications = null;
            try {
                currentJustifications = gen2.getExplanations(entailment);
            }
            catch (ExplanationGeneratorInterruptedException e) {
                return getReconstitutedLaconicJustifications();
            }
            if (isCancelled()) {
                return getReconstitutedLaconicJustifications();
            }
            allPreviouslyFoundJustifications.addAll(currentJustifications);
            if (allPreviouslyFoundJustifications.equals(allPrevJustsCopy)) {
                break;
            }
            
            

















        }


















        return getReconstitutedLaconicJustifications();
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws OWLException {
        method_6_owlexp_deepseek gen = new method_6_owlexp_deepseek();
        OWLAxiom entailment = new OWLAxiom("E");
        
        gen.ont.getLogicalAxioms().add(new OWLAxiom("A"));
        gen.axioms.add(new OWLAxiom("A"));

        Set<Explanation<OWLAxiom>> result = gen.computePreciseJustsOptimised(entailment, 10);
        System.out.println("Precise justifications count: " + result.size());
    }
}