import java.util.*;



class OWLAxiom {
    private String id;
    public OWLAxiom(String id) { this.id = id; }
    @Override public boolean equals(Object o) { return o instanceof OWLAxiom && id.equals(((OWLAxiom)o).id); }
    @Override public int hashCode() { return id.hashCode(); }
    @Override public String toString() { return id; }
}

class OWLClassExpression extends OWLAxiom {
    public OWLClassExpression(String id) { super(id); }
    public boolean isAnonymous() { return !(this instanceof OWLClass); }
    public OWLClass asOWLClass() { return (OWLClass) this; }
}

class OWLClass extends OWLClassExpression {
    public OWLClass(String id) { super(id); }
    @Override public boolean isAnonymous() { return false; }
    @Override public OWLClass asOWLClass() { return this; }
}

class OWLSubClassOfAxiom extends OWLClassExpression {
    private OWLClassExpression subClass, superClass;
    public OWLSubClassOfAxiom(OWLClassExpression sub, OWLClassExpression sup) {
        super(sub.toString() + "->" + sup.toString());
        this.subClass = sub; this.superClass = sup;
    }
    public OWLClassExpression getSubClass() { return subClass; }
    public OWLClassExpression getSuperClass() { return superClass; }
}

class OWLObjectIntersectionOf extends OWLClassExpression {
    public OWLObjectIntersectionOf(Set<OWLClassExpression> operands) { super("intersection"); }
}

class OWLOntology {
    private Set<OWLAxiom> axioms = new HashSet<>();
    public boolean containsAxiom(OWLAxiom ax) { return axioms.contains(ax); }
    public void addAxiom(OWLAxiom ax) { axioms.add(ax); }
}

class Explanation<E> {
    private E entailment; private Set<OWLAxiom> axioms;
    public Explanation(E e, Set<OWLAxiom> ax) { entailment = e; axioms = ax; }
    public Set<OWLAxiom> getAxioms() { return axioms; }
    public E getEntailment() { return entailment; }
}


public class method_2_owlexp_deepseek {

    
    private Set<Explanation<OWLAxiom>> allPreviouslyFoundJustifications = new HashSet<>();
    private Set<Explanation<OWLAxiom>> foundLaconicJustifications = new HashSet<>();
    private OWLOntology ont = new OWLOntology();
    private OWLDataFactory man = new OWLDataFactory(); 

    
    private Set<OWLAxiom> computeOPlus(Set<OWLAxiom> axioms) {
        return new HashSet<>(axioms);
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private Set<Explanation<OWLAxiom>> getReconstitutedLaconicJustifications() {
        

        
        
        
        
        Map<OWLAxiom, Set<OWLAxiom>> sourceAxioms2OPlus = new HashMap<OWLAxiom, Set<OWLAxiom>>();

        for (Explanation<OWLAxiom> exp : allPreviouslyFoundJustifications) {
            for (OWLAxiom ax : exp.getAxioms()) {
                if (ont.containsAxiom(ax)) {
                    sourceAxioms2OPlus.put(ax, computeOPlus(Collections.singleton(ax)));
                }
            }
        }

        Set<Explanation<OWLAxiom>> reconstituedExplanations = new HashSet<Explanation<OWLAxiom>>();
        for (Explanation<OWLAxiom> laconicExp : foundLaconicJustifications) {
            
            Map<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>> lhs2SubClassAxiom = new HashMap<OWLClass, Map<OWLAxiom, Set<OWLSubClassOfAxiom>>>();

            Set<OWLAxiom> reconstituedAxioms = new HashSet<OWLAxiom>();
            for (OWLAxiom laconicAx : laconicExp.getAxioms()) {
                if (laconicAx instanceof OWLSubClassOfAxiom) {
                    OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) laconicAx;
                    if (sca.getSubClass().isAnonymous()) {
                        
                        reconstituedAxioms.add(sca);
                        continue;
                    }
                    Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2AxiomMap = lhs2SubClassAxiom.get(sca.getSubClass().asOWLClass());
                    if (source2AxiomMap == null) {
                        source2AxiomMap = new HashMap<OWLAxiom, Set<OWLSubClassOfAxiom>>();
                        lhs2SubClassAxiom.put(sca.getSubClass().asOWLClass(), source2AxiomMap);
                    }
                    for (OWLAxiom sourceAx : sourceAxioms2OPlus.keySet()) {
                        if (sourceAxioms2OPlus.get(sourceAx).contains(sca)) {
                            Set<OWLSubClassOfAxiom> subClassAxioms = source2AxiomMap.get(sourceAx);
                            if (subClassAxioms == null) {
                                subClassAxioms = new HashSet<OWLSubClassOfAxiom>();
                                source2AxiomMap.put(sourceAx, subClassAxioms);
                            }
                            subClassAxioms.add(sca);
                        }
                    }
                }
                else {
                    reconstituedAxioms.add(laconicAx);
                }
            }
            
            Set<OWLSubClassOfAxiom> consumedAxioms = new HashSet<OWLSubClassOfAxiom>();
            for (OWLClass lhs : lhs2SubClassAxiom.keySet()) {
                Map<OWLAxiom, Set<OWLSubClassOfAxiom>> source2SubClassAxiom = lhs2SubClassAxiom.get(lhs);
                for (OWLAxiom source : source2SubClassAxiom.keySet()) {
                    Set<OWLClassExpression> rightHandSides = new HashSet<OWLClassExpression>();
                    for (OWLSubClassOfAxiom subClassAx : source2SubClassAxiom.get(source)) {
                        if (!consumedAxioms.contains(subClassAx)) {
                            rightHandSides.add(subClassAx.getSuperClass());
                            consumedAxioms.add(subClassAx);
                        }
                    }
                    if (rightHandSides.size() == 1) {
                        reconstituedAxioms.add(man.getOWLSubClassOfAxiom(lhs, rightHandSides.iterator().next()));
                    }
                    else if (rightHandSides.size() > 1) {
                        OWLObjectIntersectionOf conjunction = man.getOWLObjectIntersectionOf(rightHandSides);
                        reconstituedAxioms.add(man.getOWLSubClassOfAxiom(lhs, conjunction));
                    }
                }
            }
            Explanation<OWLAxiom> explanation = new Explanation<OWLAxiom>(laconicExp.getEntailment(), reconstituedAxioms);
            reconstituedExplanations.add(explanation);

        }
        return reconstituedExplanations;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    static class OWLDataFactory {
        public OWLSubClassOfAxiom getOWLSubClassOfAxiom(OWLClassExpression sub, OWLClassExpression sup) {
            return new OWLSubClassOfAxiom(sub, sup);
        }
        public OWLObjectIntersectionOf getOWLObjectIntersectionOf(Set<OWLClassExpression> operands) {
            return new OWLObjectIntersectionOf(operands);
        }
    }
    private OWLDataFactory getDataFactory() { return man; }

    public static void main(String[] args) {
        method_2_owlexp_deepseek gen = new method_2_owlexp_deepseek();
        
        OWLClass A = new OWLClass("A");
        OWLClassExpression B = new OWLClassExpression("B");
        OWLClassExpression C = new OWLClassExpression("C");
        OWLSubClassOfAxiom sca1 = new OWLSubClassOfAxiom(A, B);
        OWLSubClassOfAxiom sca2 = new OWLSubClassOfAxiom(A, C);
        
        gen.ont.addAxiom(sca1);
        gen.ont.addAxiom(sca2);
        
        Set<OWLAxiom> laconicAx = new HashSet<>(Arrays.asList(sca1, sca2));
        Explanation<OWLAxiom> laconicExp = new Explanation<>(A, laconicAx);
        gen.foundLaconicJustifications.add(laconicExp);
        gen.allPreviouslyFoundJustifications.add(laconicExp);

        Set<Explanation<OWLAxiom>> recon = gen.getReconstitutedLaconicJustifications();
        System.out.println("Reconstituted explanations count: " + recon.size());
        for (Explanation<OWLAxiom> e : recon) {
            System.out.println("  Axioms: " + e.getAxioms());
        }
    }
}