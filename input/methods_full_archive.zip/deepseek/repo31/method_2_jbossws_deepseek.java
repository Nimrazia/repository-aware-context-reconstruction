import java.security.*;




interface PrivilegedExceptionAction<T> {
    T run() throws Exception;
}


class AccessController {
    public static <T> T doPrivileged(PrivilegedExceptionAction<T> action) throws PrivilegedActionException {
        try {
            return action.run();
        } catch (Exception e) {
            throw new PrivilegedActionException(e);
        }
    }
}


class PrivilegedActionException extends Exception {
    public PrivilegedActionException(Exception cause) { super(cause); }
    public Throwable getCause() { return super.getCause(); }
}


public class method_2_jbossws_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    static ClassLoader setContextClassLoader(final ClassLoader cl)
    {
        if (System.getSecurityManager() == null)
        {
            ClassLoader result = Thread.currentThread().getContextClassLoader();
            if (cl != null)
                Thread.currentThread().setContextClassLoader(cl);
            return result;
        }
        else
        {
            try
            {
                return AccessController.doPrivileged(new PrivilegedExceptionAction<ClassLoader>() {
                    public ClassLoader run() throws Exception
                    {
                        try
                        {
                            ClassLoader result = Thread.currentThread().getContextClassLoader();
                            if (cl != null)
                                Thread.currentThread().setContextClassLoader(cl);
                            return result;
                        }
                        catch (Exception e)
                        {
                            throw e;
                        }
                        catch (Error e)
                        {
                            throw e;
                        }
                        catch (Throwable e)
                        {
                            throw new RuntimeException("Error setting context classloader", e);
                        }
                    }
                });
            }
            catch (PrivilegedActionException e)
            {
                throw new RuntimeException("Error running privileged action", e.getCause());
            }
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        
        ClassLoader original = Thread.currentThread().getContextClassLoader();
        ClassLoader prev = setContextClassLoader(ClassLoader.getSystemClassLoader());
        System.out.println("Previous CL: " + prev);
        Thread.currentThread().setContextClassLoader(original);
        
        System.out.println("SecurityManager branch skipped on JDK 21.");
    }
}