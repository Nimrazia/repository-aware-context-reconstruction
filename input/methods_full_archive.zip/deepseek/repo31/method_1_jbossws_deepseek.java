import java.io.*;
import java.util.*;




class BuildException extends RuntimeException {
    public BuildException(Throwable cause) { super(cause); }
}


class Project {
    public File getBaseDir() { return new File("."); }
}


class FileSet {
    private File dir;
    private List<String> includes = new ArrayList<>();

    public FileSet(File dir, String... includePatterns) {
        this.dir = dir;
        this.includes.addAll(Arrays.asList(includePatterns));
    }

    public DirectoryScanner getDirectoryScanner(Project project) {
        return new DirectoryScanner(dir, includes);
    }
}


class DirectoryScanner {
    private File baseDir;
    private List<String> includes;
    private List<String> includedFiles = new ArrayList<>();

    public DirectoryScanner(File baseDir, List<String> includes) {
        this.baseDir = baseDir;
        this.includes = includes;
        for (String pattern : includes) {
            File patternDir = new File(baseDir, pattern);
            if (patternDir.exists() && patternDir.isDirectory()) {
                File[] files = patternDir.listFiles();
                if (files != null) {
                    for (File f : files) {
                        if (f.isFile()) {
                            includedFiles.add(pattern + File.separator + f.getName());
                        }
                    }
                }
            }
        }
    }

    public File getBasedir() { return baseDir; }
    public String[] getIncludedFiles() { return includedFiles.toArray(new String[0]); }
}


public class method_1_jbossws_deepseek {

    private FileSet fileset;
    private File targetDir;

    public method_1_jbossws_deepseek(FileSet fileset, File targetDir) {
        this.fileset = fileset;
        this.targetDir = targetDir;
    }

    
    private Project getProject() { return new Project(); }

    private String readFileContents(File file) throws IOException {
        
        return "<!-- module descriptor: " + file.getName() + " -->";
    }

    private String updateContents(String originalContent, String[] libs) {
        return originalContent + "\n<!-- libraries: " + Arrays.toString(libs) + " -->";
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void execute() throws BuildException
    {
        try
        {
            DirectoryScanner dsc = fileset.getDirectoryScanner(getProject());
            File baseDir = dsc.getBasedir();
            String[] files = dsc.getIncludedFiles();
            for (int i = 0; i < files.length; i++)
            {
                String currentFile = files[i];
                File moduleXml = new File(baseDir, currentFile);
                String modulePath = currentFile.substring(0, currentFile.lastIndexOf(File.separator));
                File libDir = new File(targetDir, modulePath);
                File destFile = new File(targetDir, currentFile);
                System.out.println("Processing descriptor for module " + modulePath);
                System.out.println("* Source module descriptor: " + moduleXml);
                System.out.println("* Destination module descriptor: " + destFile);
                String c = readFileContents(moduleXml);
                if (libDir.exists())
                {
                    String[] libs = libDir.list(new FilenameFilter()
                    {
                        @Override
                        public boolean accept(File dir, String name)
                        {
                            return name.endsWith(".jar") || name.endsWith(".ear") || name.endsWith(".sar")
                                    || name.endsWith(".war");
                        }
                    });
                    BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
                    out.write(updateContents(c, libs));
                    out.close();
                }
                else
                {
                    libDir.mkdirs();
                    BufferedWriter out = new BufferedWriter(new FileWriter(destFile));
                    out.write(c);
                    out.close();
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new BuildException(e);
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        
        File baseDir = new File("test_basedir");
        baseDir.mkdirs();
        File moduleDir = new File(baseDir, "myModule");
        moduleDir.mkdirs();
        File xmlFile = new File(moduleDir, "module.xml");
        xmlFile.createNewFile();

        File targetDir = new File("test_target");
        targetDir.mkdirs();

        
        FileSet fs = new FileSet(baseDir, "myModule");
        method_1_jbossws_deepseek task = new method_1_jbossws_deepseek(fs, targetDir);
        task.execute();

        
        xmlFile.delete();
        moduleDir.delete();
        baseDir.delete();
        targetDir.delete();
        System.out.println("Execution completed.");
    }
}