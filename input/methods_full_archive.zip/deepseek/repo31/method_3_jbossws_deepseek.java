import java.util.logging.Level;
import java.util.logging.Logger;




class Category {
    private Logger logger;
    public Category(Logger logger) { this.logger = logger; }
    public void log(Priority priority, String message) {
        logger.log(Level.INFO, "[" + priority + "] " + message);
    }
}


class Priority {
    public static final Priority INFO = new Priority("INFO");
    private String name;
    public Priority(String name) { this.name = name; }
    @Override public String toString() { return name; }
}


public class method_3_jbossws_deepseek {

    
    private byte[] buf = new byte[256];
    private int count;
    private static final String LINE_SEPERATOR = System.getProperty("line.separator");
    private Category category;
    private Priority priority;

    public method_3_jbossws_deepseek(Category category, Priority priority) {
        this.category = category;
        this.priority = priority;
    }

    
    public void write(byte[] b) {
        System.arraycopy(b, 0, buf, count, b.length);
        count += b.length;
    }

    private void reset() {
        count = 0;
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void flush()
    {
        if (count == 0)
        {
            return;
        }

        
        if (count == LINE_SEPERATOR.length())
        {
            if (((char)buf[0]) == LINE_SEPERATOR.charAt(0) && ((count == 1) || 
                    ((count == 2) && ((char)buf[1]) == LINE_SEPERATOR.charAt(1))))
            {
                reset();
                return;
            }
        }

        final byte[] theBytes = new byte[count];

        System.arraycopy(buf, 0, theBytes, 0, count);

        category.log(priority, new String(theBytes));

        reset();
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) {
        Logger logger = Logger.getLogger("TestLogger");
        Category cat = new Category(logger);
        method_3_jbossws_deepseek stream = new method_3_jbossws_deepseek(cat, Priority.INFO);

        
        stream.write("Hello World".getBytes());
        stream.flush();   

        
        byte[] lineSep = System.lineSeparator().getBytes();
        stream.write(lineSep);
        stream.flush();   

        
        stream.write("some data".getBytes());
        stream.flush();   

        System.out.println("Flush tests completed.");
    }
}