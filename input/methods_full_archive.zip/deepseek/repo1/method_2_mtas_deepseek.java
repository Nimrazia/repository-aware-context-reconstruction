import javax.xml.stream.*;
import javax.xml.stream.events.*;
import javax.xml.namespace.QName;
import java.io.*;
import java.lang.reflect.Method;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;


class MtasTokenCollection {
    List<MtasToken> tokens = new ArrayList<>();
    void check(boolean autorepair, boolean makeunique) {}
    MtasToken get(int id) { return tokens.get(id-1); }
    int size() { return tokens.size(); }
}
class MtasToken {
    int id;
    String prefix="", postfix="", value="";
    int offsetStart, offsetEnd;
    Set<Integer> positions = new HashSet<>();
    List<int[]> offsets = new ArrayList<>();
    int getId() { return id; }
    String getPrefix() { return prefix; }
    String getPostfix() { return postfix; }
    void setValue(String v) { value=v; }
    void addOffset(int s, int e) { offsets.add(new int[]{s,e}); }
    void addPositions(Set<Integer> pos) { positions.addAll(pos); }
    int getOffsetStart() { return offsetStart; }
    int getOffsetEnd() { return offsetEnd; }
}
class MtasTokenIdFactory {
    int nextId=1;
    int createTokenId() { return nextId++; }
}
class MtasParserType<T> {
    String name;
    String refAttributeName;
    MtasParserType(String name) { this.name=name; }
    String getName() { return name; }
    String getRefAttributeName() { return "ref"; }
}
class MtasParserObject {
    MtasParserType<?> type;
    Map<String,String> attributes = new HashMap<>();
    Set<Integer> positions = new HashSet<>();
    int offsetStart, offsetEnd, realOffsetStart, realOffsetEnd;
    String id;
    List<String> refIds = new ArrayList<>();
    int unknownAncestorNumber;
    String text;
    MtasParserObject(MtasParserType<?> t) { this.type=t; }
    MtasParserType<?> getType() { return type; }
    void setAttribute(String k, String v) { attributes.put(k,v); if("id".equals(k)) id=v; }
    String getAttribute(String k) { return attributes.get(k); }
    void addPosition(int p) { positions.add(p); }
    void addPositions(Set<Integer> ps) { positions.addAll(ps); }
    Set<Integer> getPositions() { return positions; }
    void setOffsetStart(int v) { offsetStart=v; }
    void setOffsetEnd(int v) { offsetEnd=v; }
    void setRealOffsetStart(int v) { realOffsetStart=v; }
    void setRealOffsetEnd(int v) { realOffsetEnd=v; }
    void addOffsetStart(int v) { if(offsetStart==0 || v<offsetStart) offsetStart=v; }
    void addOffsetEnd(int v) { if(v>offsetEnd) offsetEnd=v; }
    int getOffsetStart() { return offsetStart; }
    int getOffsetEnd() { return offsetEnd; }
    Integer[] getOffset() { return new Integer[]{offsetStart, offsetEnd}; }
    void setUnknownAncestorNumber(int v) { unknownAncestorNumber=v; }
    int getUnknownAncestorNumber() { return unknownAncestorNumber; }
    String getId() { return id; }
    void addRefId(String rid) { refIds.add(rid); }
    void addText(String t) { this.text=t; }
    void updateMappings(Map<String,Set<Integer>> idPositions, Map<String,Integer[]> idOffsets) {}
    void addUpdateableIdWithOffset(String id) {}
}

class MtasConfigException extends Exception {}
class MtasParserException extends Exception {
    public MtasParserException(String msg) { super(msg); }
}


class QNameHelper {
    static QName getQName(String localPart) { return new QName(localPart); }
}




public class method_2_mtas_deepseek {

    static class MtasXMLParser {
        
        private static final String MAPPING_TYPE_WORD = "word";
        private static final String MAPPING_TYPE_WORD_ANNOTATION = "wordAnnotation";
        private static final String MAPPING_TYPE_GROUP = "group";
        private static final String MAPPING_TYPE_GROUP_ANNOTATION = "groupAnnotation";
        private static final String MAPPING_TYPE_RELATION = "relation";
        private static final String MAPPING_TYPE_RELATION_ANNOTATION = "relationAnnotation";
        private static final String MAPPING_TYPE_REF = "ref";

        private String rootTag = "teiHeader";
        private String contentTag = "text";
        private boolean allowNonContent = false;
        private boolean autorepair = false;
        private boolean makeunique = false;

        
        private Map<QName, MtasParserType<?>> wordTypes = new HashMap<>();
        private Map<QName, MtasParserType<?>> wordAnnotationTypes = new HashMap<>();
        private Map<QName, MtasParserType<?>> groupTypes = new HashMap<>();
        private Map<QName, MtasParserType<?>> groupAnnotationTypes = new HashMap<>();
        private Map<QName, MtasParserType<?>> relationTypes = new HashMap<>();
        private Map<QName, MtasParserType<?>> relationAnnotationTypes = new HashMap<>();
        private Map<QName, MtasParserType<?>> refTypes = new HashMap<>();
        private Map<QName, MtasParserType<?>> variableTypes = new HashMap<>();
        private Map<String, SortedSet<String>> relationKeyMap = new HashMap<>();

        private MtasTokenCollection tokenCollection;

        
        private Map<String, Map<Integer, Set<String>>> createUpdateList() {
            Map<String, Map<Integer, Set<String>>> map = new HashMap<>();
            map.put("variable", new HashMap<>());
            map.put("offset", new HashMap<>());
            map.put("position", new HashMap<>());
            return map;
        }
        private Map<String, List<MtasParserObject>> createCurrentList() {
            Map<String, List<MtasParserObject>> map = new HashMap<>();
            map.put(MAPPING_TYPE_WORD, new ArrayList<>());
            map.put(MAPPING_TYPE_WORD_ANNOTATION, new ArrayList<>());
            map.put(MAPPING_TYPE_GROUP, new ArrayList<>());
            map.put(MAPPING_TYPE_GROUP_ANNOTATION, new ArrayList<>());
            map.put(MAPPING_TYPE_RELATION, new ArrayList<>());
            map.put(MAPPING_TYPE_RELATION_ANNOTATION, new ArrayList<>());
            map.put(MAPPING_TYPE_REF, new ArrayList<>());
            return map;
        }
        private Map<String, Map<String, String>> createVariables() { return new HashMap<>(); }
        private void collectAttributes(MtasParserObject obj, XMLStreamReader reader) {
            for (int i=0; i<reader.getAttributeCount(); i++) {
                obj.setAttribute(reader.getAttributeLocalName(i), reader.getAttributeValue(i));
            }
        }
        private boolean prevalidateObject(MtasParserObject obj, Map<String, List<MtasParserObject>> currentList) {
            return true;
        }
        private void computeVariablesFromObject(MtasParserObject obj, Map<String, List<MtasParserObject>> currentList, Map<String, Map<String, String>> variables) {}
        private void computeMappingsFromObject(MtasTokenIdFactory factory, MtasParserObject obj, Map<String, List<MtasParserObject>> currentList, Map<String, Map<Integer, Set<String>>> updateList) {}
        private String decodeAndUpdateWithVariables(String prefix, String postfix, Map<String, Map<String, String>> variables) { return ""; }
        private Set<String> recursiveCollect(String refId, Map<String, SortedSet<String>> map, int depth) { return new HashSet<>(); }
        private QName getQName(String localPart) { return QNameHelper.getQName(localPart); }

        
        private static class Logger { void debug(String m) {} void debug(Throwable t) {} void info(String m) {} }
        private Logger log = new Logger();

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        public MtasTokenCollection createTokenCollection(Reader reader)
              throws MtasParserException, MtasConfigException {
            Boolean hasRoot = rootTag == null ? true : false;
            Boolean parsingContent = contentTag == null ? true : false;
            String textContent = null;
            Integer unknownAncestors = 0;
            Integer lastOffset = 0;

            AtomicInteger position = new AtomicInteger(0);
            Map<String, Set<Integer>> idPositions = new HashMap<>();
            Map<String, Integer[]> idOffsets = new HashMap<>();

            Map<String, Map<Integer, Set<String>>> updateList = createUpdateList();
            Map<String, List<MtasParserObject>> currentList = createCurrentList();
            Map<String, Map<String, String>> variables = createVariables();

            tokenCollection = new MtasTokenCollection();
            MtasTokenIdFactory mtasTokenIdFactory = new MtasTokenIdFactory();
            XMLInputFactory factory = XMLInputFactory.newInstance();
            try {      
              XMLStreamReader streamReader = factory.createXMLStreamReader(reader);
              QName qname;
              try {
                int event = streamReader.getEventType();
                MtasParserType<?> currentType;
                MtasParserType<?> tmpCurrentType;
                MtasParserType<?> tmpVariableType;
                MtasParserObject currentObject = null;
                MtasParserObject variableObject = null;
                while (true) {
                  switch (event) {
                  case XMLStreamConstants.START_DOCUMENT:
                    log.debug("start of document");
                    String encodingScheme = streamReader.getCharacterEncodingScheme();
                    if (encodingScheme == null) {
                      
                      log.info("No encodingScheme found, assume utf-8");
                      
                    } else if (!encodingScheme.equalsIgnoreCase("utf-8")) {
                      throw new MtasParserException(
                          "XML not UTF-8 encoded but '" + encodingScheme + "'");
                    }
                    break;
                  case XMLStreamConstants.END_DOCUMENT:
                    log.debug("end of document");
                    break;
                  case XMLStreamConstants.SPACE:
                    
                    lastOffset = streamReader.getLocation().getCharacterOffset();
                    break;
                  case XMLStreamConstants.START_ELEMENT:
                    
                    qname = streamReader.getName();
                    
                    if (!hasRoot) {
                      if (qname.equals(getQName(rootTag))) {
                        hasRoot = true;
                      } else {
                        throw new MtasParserException("No " + rootTag);
                      }
                      
                    } else {
                      if ((tmpVariableType = variableTypes.get(qname)) != null) {
                        variableObject = new MtasParserObject(tmpVariableType);
                        collectAttributes(variableObject, streamReader);
                        computeVariablesFromObject(variableObject, currentList,
                            variables);
                      }
                      if (parsingContent) {
                        
                        
                        if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                            && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                                .isEmpty())
                            && (tmpCurrentType = relationTypes.get(qname)) != null) {
                          currentObject = new MtasParserObject(tmpCurrentType);
                          collectAttributes(currentObject, streamReader);
                          currentObject.setUnknownAncestorNumber(unknownAncestors);
                          currentObject.setRealOffsetStart(lastOffset);
                          if (!prevalidateObject(currentObject, currentList)) {
                            unknownAncestors++;
                          } else {
                            currentType = tmpCurrentType;
                            currentList.get(MAPPING_TYPE_RELATION).add(currentObject);
                            unknownAncestors = 0;
                          }
                          
                          
                        } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                            && (!currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                            && (tmpCurrentType = relationAnnotationTypes
                                .get(qname)) != null) {
                          currentObject = new MtasParserObject(tmpCurrentType);
                          collectAttributes(currentObject, streamReader);
                          currentObject.setUnknownAncestorNumber(unknownAncestors);
                          currentObject.setRealOffsetStart(lastOffset);
                          if (!prevalidateObject(currentObject, currentList)) {
                            unknownAncestors++;
                          } else {
                            currentType = tmpCurrentType;
                            currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                                .add(currentObject);
                            unknownAncestors = 0;
                          }
                          
                          
                        } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                            && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                            && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                                .isEmpty())
                            && (tmpCurrentType = groupTypes.get(qname)) != null) {
                          currentObject = new MtasParserObject(tmpCurrentType);
                          collectAttributes(currentObject, streamReader);
                          currentObject.setUnknownAncestorNumber(unknownAncestors);
                          currentObject.setRealOffsetStart(lastOffset);
                          if (!prevalidateObject(currentObject, currentList)) {
                            unknownAncestors++;
                          } else {
                            currentType = tmpCurrentType;
                            currentList.get(MAPPING_TYPE_GROUP).add(currentObject);
                            unknownAncestors = 0;
                          }
                          
                          
                        } else if ((currentList.get(MAPPING_TYPE_WORD).isEmpty())
                            && (currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                            && (!currentList.get(MAPPING_TYPE_GROUP).isEmpty())
                            && (tmpCurrentType = groupAnnotationTypes
                                .get(qname)) != null) {
                          currentObject = new MtasParserObject(tmpCurrentType);
                          collectAttributes(currentObject, streamReader);
                          currentObject.setUnknownAncestorNumber(unknownAncestors);
                          currentObject.setRealOffsetStart(lastOffset);
                          if (!prevalidateObject(currentObject, currentList)) {
                            unknownAncestors++;
                          } else {
                            currentType = tmpCurrentType;
                            currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                                .add(currentObject);
                            unknownAncestors = 0;
                          }
                          
                          
                        } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                            && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                                .isEmpty())
                            && (currentList.get(MAPPING_TYPE_WORD).isEmpty())
                            && (currentList.get(MAPPING_TYPE_WORD_ANNOTATION).isEmpty())
                            && (tmpCurrentType = wordTypes.get(qname)) != null) {
                          currentObject = new MtasParserObject(tmpCurrentType);
                          collectAttributes(currentObject, streamReader);
                          currentObject.setUnknownAncestorNumber(unknownAncestors);
                          currentObject.setOffsetStart(lastOffset);
                          currentObject.setRealOffsetStart(lastOffset);
                          if (!prevalidateObject(currentObject, currentList)) {
                            unknownAncestors++;
                          } else {
                            currentType = tmpCurrentType;
                            currentObject.addPosition(position.getAndIncrement());
                            currentList.get(MAPPING_TYPE_WORD).add(currentObject);
                            unknownAncestors = 0;
                          }
                          
                          
                        } else if ((currentList.get(MAPPING_TYPE_RELATION).isEmpty())
                            && (currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                                .isEmpty())
                            && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())
                            && (tmpCurrentType = wordAnnotationTypes
                                .get(qname)) != null) {
                          currentObject = new MtasParserObject(tmpCurrentType);
                          collectAttributes(currentObject, streamReader);
                          currentObject.addPositions(currentList.get(MAPPING_TYPE_WORD)
                              .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                              .getPositions());
                          currentObject.setUnknownAncestorNumber(unknownAncestors);
                          currentObject.setRealOffsetStart(lastOffset);
                          if (!prevalidateObject(currentObject, currentList)) {
                            unknownAncestors++;
                          } else {
                            currentType = tmpCurrentType;
                            currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                                .add(currentObject);
                            unknownAncestors = 0;
                          }
                          
                        } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()
                            && (tmpCurrentType = refTypes.get(qname)) != null) {
                          currentObject = new MtasParserObject(tmpCurrentType);
                          collectAttributes(currentObject, streamReader);
                          currentObject.setUnknownAncestorNumber(unknownAncestors);
                          currentObject.setRealOffsetStart(lastOffset);
                          if (!prevalidateObject(currentObject, currentList)) {
                            unknownAncestors++;
                          } else {
                            currentType = tmpCurrentType;
                            currentList.get(MAPPING_TYPE_REF).add(currentObject);
                            unknownAncestors = 0;
                            
                            for (MtasParserObject currentRelation : currentList
                                .get(MAPPING_TYPE_RELATION)) {
                              currentRelation.addRefId(currentObject
                                  .getAttribute(currentType.getRefAttributeName()));
                              
                              SortedSet<String> keyMapList;
                              if (currentRelation.getId() != null) {
                                if (relationKeyMap
                                    .containsKey(currentRelation.getId())) {
                                  keyMapList = relationKeyMap
                                      .get(currentRelation.getId());
                                } else {
                                  keyMapList = new TreeSet<>();
                                  relationKeyMap.put(currentRelation.getId(),
                                      keyMapList);
                                }
                                keyMapList.add(currentObject
                                    .getAttribute(currentType.getRefAttributeName()));
                              }
                            }
                          }
                        } else {
                          unknownAncestors++;
                        }
                        
                      } else if (qname.equals(getQName(contentTag))) {
                        parsingContent = true;
                        
                      } else if (!allowNonContent) {
                        throw new MtasParserException(
                            "Unexpected " + qname.getLocalPart() + " in document");
                      }
                    }
                    
                    lastOffset = streamReader.getLocation().getCharacterOffset();
                    break;
                  case XMLStreamConstants.END_ELEMENT:
                    
                    lastOffset = streamReader.getLocation().getCharacterOffset();
                    
                    qname = streamReader.getName();
                    
                    if (parsingContent) {
                      if (unknownAncestors > 0) {
                        unknownAncestors--;
                        
                        
                      } else if (!currentList.get(MAPPING_TYPE_REF).isEmpty()) {
                        if ((currentType = refTypes.get(qname)) != null) {
                          currentObject = currentList.get(MAPPING_TYPE_REF)
                              .remove(currentList.get(MAPPING_TYPE_REF).size() - 1);
                          assert currentObject.getType()
                              .equals(currentType) : "object expected to be "
                                  + currentObject.getType().getName() + ", not "
                                  + currentType.getName();
                          assert unknownAncestors == 0 : "error in administration "
                              + currentObject.getType().getName();
                          
                          idPositions.put(currentObject.getId(),
                              currentObject.getPositions());
                          idOffsets.put(currentObject.getId(),
                              currentObject.getOffset());
                          currentObject.updateMappings(idPositions, idOffsets);
                          unknownAncestors = currentObject.getUnknownAncestorNumber();
                          computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                              currentList, updateList);
                        } else {
                          
                        }
                        
                        
                      } else if (!currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                          .isEmpty()) {
                        if ((currentType = wordAnnotationTypes.get(qname)) != null) {
                          currentObject = currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                              .remove(
                                  currentList.get(MAPPING_TYPE_WORD_ANNOTATION).size()
                                      - 1);
                          assert currentObject.getType()
                              .equals(currentType) : "object expected to be "
                                  + currentObject.getType().getName() + ", not "
                                  + currentType.getName();
                          assert unknownAncestors == 0 : "error in administration "
                              + currentObject.getType().getName();
                          currentObject.setRealOffsetEnd(lastOffset);
                          idPositions.put(currentObject.getId(),
                              currentObject.getPositions());
                          idOffsets.put(currentObject.getId(),
                              currentObject.getOffset());
                          
                          
                          if ((currentObject.getId() != null)
                              && (!currentList.get(MAPPING_TYPE_WORD).isEmpty())) {
                            currentList.get(MAPPING_TYPE_WORD)
                                .get((currentList.get(MAPPING_TYPE_WORD).size() - 1))
                                .addUpdateableIdWithOffset(currentObject.getId());
                          }
                          currentObject.updateMappings(idPositions, idOffsets);
                          unknownAncestors = currentObject.getUnknownAncestorNumber();
                          computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                              currentList, updateList);
                        } else {
                          
                        }
                        
                        
                      } else if (!currentList.get(MAPPING_TYPE_WORD).isEmpty()) {
                        if ((currentType = wordTypes.get(qname)) != null) {
                          currentObject = currentList.get(MAPPING_TYPE_WORD)
                              .remove(currentList.get(MAPPING_TYPE_WORD).size() - 1);
                          assert currentObject.getType()
                              .equals(currentType) : "object expected to be "
                                  + currentObject.getType().getName() + ", not "
                                  + currentType.getName();
                          assert unknownAncestors == 0 : "error in administration "
                              + currentObject.getType().getName();
                          currentObject.setOffsetEnd(lastOffset);
                          currentObject.setRealOffsetEnd(lastOffset);
                          
                          for (MtasParserObject currentGroup : currentList
                              .get(MAPPING_TYPE_GROUP)) {
                            currentGroup.addPositions(currentObject.getPositions());
                            currentGroup.addOffsetStart(currentObject.getOffsetStart());
                            currentGroup.addOffsetEnd(currentObject.getOffsetEnd());
                          }
                          idPositions.put(currentObject.getId(),
                              currentObject.getPositions());
                          idOffsets.put(currentObject.getId(),
                              currentObject.getOffset());
                          currentObject.updateMappings(idPositions, idOffsets);
                          unknownAncestors = currentObject.getUnknownAncestorNumber();
                          computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                              currentList, updateList);
                        } else {
                          
                        }
                        
                        
                      } else if (!currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                          .isEmpty()) {
                        if ((currentType = groupAnnotationTypes.get(qname)) != null) {
                          currentObject = currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                              .remove(
                                  currentList.get(MAPPING_TYPE_GROUP_ANNOTATION).size()
                                      - 1);
                          assert currentObject.getType()
                              .equals(currentType) : "object expected to be "
                                  + currentObject.getType().getName() + ", not "
                                  + currentType.getName();
                          assert unknownAncestors == 0 : "error in administration "
                              + currentObject.getType().getName();
                          currentObject.setRealOffsetEnd(lastOffset);
                          idPositions.put(currentObject.getId(),
                              currentObject.getPositions());
                          idOffsets.put(currentObject.getId(),
                              currentObject.getOffset());
                          currentObject.updateMappings(idPositions, idOffsets);
                          unknownAncestors = currentObject.getUnknownAncestorNumber();
                          computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                              currentList, updateList);
                        } else {
                          
                        }
                        
                      } else if (!currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                          .isEmpty()) {
                        if ((currentType = relationAnnotationTypes
                            .get(qname)) != null) {
                          currentObject = currentList
                              .get(MAPPING_TYPE_RELATION_ANNOTATION).remove(currentList
                                  .get(MAPPING_TYPE_RELATION_ANNOTATION).size() - 1);
                          assert currentObject.getType()
                              .equals(currentType) : "object expected to be "
                                  + currentObject.getType().getName() + ", not "
                                  + currentType.getName();
                          assert unknownAncestors == 0 : "error in administration "
                              + currentObject.getType().getName();
                          currentObject.setRealOffsetEnd(lastOffset);
                          idPositions.put(currentObject.getId(),
                              currentObject.getPositions());
                          idOffsets.put(currentObject.getId(),
                              currentObject.getOffset());
                          currentObject.updateMappings(idPositions, idOffsets);
                          unknownAncestors = currentObject.getUnknownAncestorNumber();
                          computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                              currentList, updateList);
                        } else {
                          
                        }
                        
                      } else if (!currentList.get(MAPPING_TYPE_RELATION).isEmpty()) {
                        if ((currentType = relationTypes.get(qname)) != null) {
                          currentObject = currentList.get(MAPPING_TYPE_RELATION).remove(
                              currentList.get(MAPPING_TYPE_RELATION).size() - 1);
                          assert currentObject.getType()
                              .equals(currentType) : "object expected to be "
                                  + currentObject.getType().getName() + ", not "
                                  + currentType.getName();
                          assert unknownAncestors == 0 : "error in administration "
                              + currentObject.getType().getName();
                          
                          currentObject.setRealOffsetEnd(lastOffset);
                          idPositions.put(currentObject.getId(),
                              currentObject.getPositions());
                          idOffsets.put(currentObject.getId(),
                              currentObject.getOffset());
                          currentObject.updateMappings(idPositions, idOffsets);
                          unknownAncestors = currentObject.getUnknownAncestorNumber();
                          computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                              currentList, updateList);
                        } else {
                          
                        }
                        
                      } else if (!currentList.get(MAPPING_TYPE_GROUP).isEmpty()) {
                        if ((currentType = groupTypes.get(qname)) != null) {
                          currentObject = currentList.get(MAPPING_TYPE_GROUP)
                              .remove(currentList.get(MAPPING_TYPE_GROUP).size() - 1);
                          assert currentObject.getType()
                              .equals(currentType) : "object expected to be "
                                  + currentObject.getType().getName() + ", not "
                                  + currentType.getName();
                          assert unknownAncestors == 0 : "error in administration "
                              + currentObject.getType().getName();
                          
                          currentObject.setRealOffsetEnd(lastOffset);
                          idPositions.put(currentObject.getId(),
                              currentObject.getPositions());
                          idOffsets.put(currentObject.getId(),
                              currentObject.getOffset());
                          currentObject.updateMappings(idPositions, idOffsets);
                          unknownAncestors = currentObject.getUnknownAncestorNumber();
                          computeMappingsFromObject(mtasTokenIdFactory, currentObject,
                              currentList, updateList);
                        } else {
                          unknownAncestors--;
                        }
                      } else if (qname.equals(getQName("text"))) {
                        parsingContent = false;
                        assert unknownAncestors == 0 : "error in administration unknownAncestors";
                        assert currentList.get(MAPPING_TYPE_REF)
                            .isEmpty() : "error in administration references";
                        assert currentList.get(MAPPING_TYPE_GROUP)
                            .isEmpty() : "error in administration groups";
                        assert currentList.get(MAPPING_TYPE_GROUP_ANNOTATION)
                            .isEmpty() : "error in administration groupAnnotations";
                        assert currentList.get(MAPPING_TYPE_WORD)
                            .isEmpty() : "error in administration words";
                        assert currentList.get(MAPPING_TYPE_WORD_ANNOTATION)
                            .isEmpty() : "error in administration wordAnnotations";
                        assert currentList.get(MAPPING_TYPE_RELATION)
                            .isEmpty() : "error in administration relations";
                        assert currentList.get(MAPPING_TYPE_RELATION_ANNOTATION)
                            .isEmpty() : "error in administration relationAnnotations";
                      }
                    }
                    
                    textContent = null;
                    break;
                  case XMLStreamConstants.CHARACTERS:
                    
                    lastOffset = streamReader.getLocation().getCharacterOffset();
                    
                    if (streamReader.hasText()) {
                      textContent = streamReader.getText();
                    }
                    if (currentObject != null && unknownAncestors.equals(0)) {
                      currentObject.addText(textContent);
                    }
                    break;
                  default:
                    break;
                  }
                  if (!streamReader.hasNext()) {
                    break;
                  }
                  event = streamReader.next();
                }
              } finally {
                streamReader.close();
              }
              
              assert unknownAncestors == 0 : "error in administration unknownAncestors";
              assert hasRoot : "no " + rootTag;
            } catch (XMLStreamException e) {
              log.debug(e);      
              throw new MtasParserException("No valid XML: " + e.getMessage());
            }

            
            for (Entry<Integer, Set<String>> updateItem : updateList
                .get("variable").entrySet()) {
              MtasToken token = tokenCollection.get(updateItem.getKey());
              String encodedPrefix = token.getPrefix();
              String encodedPostfix = token.getPostfix();
              token.setValue(decodeAndUpdateWithVariables(encodedPrefix, encodedPostfix,
                  variables));
            }
            
            for (Entry<Integer, Set<String>> updateItem : updateList
                .get("offset").entrySet()) {
              Set<String> refIdList = new HashSet<>();
              for (String refId : updateItem.getValue()) {
                if (idPositions.containsKey(refId)) {
                  refIdList.add(refId);
                }
                if (relationKeyMap.containsKey(refId)) {
                  refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
                }
              }
              for (String refId : refIdList) {
                Integer[] refOffset = idOffsets.get(refId);
                Integer tokenId = updateItem.getKey();
                if (tokenId != null && refOffset != null) {
                  MtasToken token = tokenCollection.get(tokenId);
                  token.addOffset(refOffset[0], refOffset[1]);
                }
              }
            }
            
            for (Entry<Integer, Set<String>> updateItem : updateList
                .get("position").entrySet()) {
              HashSet<String> refIdList = new HashSet<>();
              for (String refId : updateItem.getValue()) {
                if (idPositions.containsKey(refId)) {
                  refIdList.add(refId);
                }
                if (relationKeyMap.containsKey(refId)) {
                  refIdList.addAll(recursiveCollect(refId, relationKeyMap, 10));
                }
              }
              for (String refId : refIdList) {
                Set<Integer> refPositions = idPositions.get(refId);
                Integer tokenId = updateItem.getKey();
                if (tokenId != null && refPositions != null) {
                  MtasToken token = tokenCollection.get(tokenId);
                  token.addPositions(refPositions);
                }
              }
            }
            
            tokenCollection.check(autorepair, makeunique);
            return tokenCollection;
          }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Starting MtasXMLParser.createTokenCollection test ===");
        MtasXMLParser parser = new MtasXMLParser();
        
        QName wQName = new QName("w");
        parser.wordTypes.put(wQName, new MtasParserType<>("w"));
        
        String xml = "<teiHeader><text><w>woord</w></text></teiHeader>";
        Reader reader = new StringReader(xml);
        System.out.println("Parsing XML with root 'teiHeader' and content 'text'...");
        MtasTokenCollection coll = parser.createTokenCollection(reader);
        System.out.println("Tokens created: " + coll.size());
        System.out.print("Token IDs: ");
        for (int i=0; i<coll.size(); i++) {
            System.out.print(coll.tokens.get(i).getId() + " ");
        }
        System.out.println();
        System.out.print("Token values: ");
        for (int i=0; i<coll.size(); i++) {
            System.out.print(coll.tokens.get(i).value + " ");
        }
        System.out.println();
        System.out.print("Token offsets: ");
        for (int i=0; i<coll.size(); i++) {
            MtasToken t = coll.tokens.get(i);
            System.out.print("(" + t.getOffsetStart() + "," + t.getOffsetEnd() + ") ");
        }
        System.out.println();
        System.out.println("=== Method execution completed. ===");
    }
}