import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.Map.Entry;
import java.util.AbstractMap.SimpleEntry;
import java.util.stream.Collectors;


class MtasDataItemNumberComparator implements Comparable<MtasDataItemNumberComparator> {
    double value;
    MtasDataItemNumberComparator(double v) { this.value = v; }
    void add(double v) { value += v; }
    void subtract(double v) { value -= v; }
    double getValue() { return value; }
    public MtasDataItemNumberComparator clone() { return new MtasDataItemNumberComparator(value); }
    MtasDataItemNumberComparator recomputeBoundary(int size) { return new MtasDataItemNumberComparator(value / size); }
    @Override public int compareTo(MtasDataItemNumberComparator o) { return Double.compare(value, o.value); }
    public int compareTo(double v) { return Double.compare(value, v); }
    @Override public String toString() { return String.valueOf(value); }
}

class MtasSolrMtasResult {
    
    private MtasDataItemNumberComparator lastSortValue;
    private Map<String, MtasDataItemNumberComparator> comparatorList;
    MtasDataItemNumberComparator getLastSortValue() { return lastSortValue; }
    Map<String, MtasDataItemNumberComparator> getComparatorList() { return comparatorList; }
    MtasSolrMtasResult getResult() { return this; }
}

class ComponentTermVector {
    String key;
    String prefix;
    int number;
    SubComponentFunction subComponentFunction = new SubComponentFunction();
    List<SubComponentFunction> functions;
    List<SubComponentDistance> distances;
    String regexp;
}
class SubComponentFunction {
    String sortType;
    String sortDirection;
    String type;
    String expression;
    String key;
}
class SubComponentDistance {
    String type, base, key;
    Integer minimum, maximum;
    Map<String,String> parameters = new HashMap<>();
}
class ComponentFields {
    Map<String, FieldEntry> list = new HashMap<>();
    static class FieldEntry {
        List<ComponentTermVector> termVectorList;
    }
}
class CodecUtil {
    static final String SORT_TERM = "term";
    static final String SORT_DESC = "desc";
}
class ShardRequest {
    static final int PURPOSE_PRIVATE = 1;
    String[] shards;
    int purpose;
    NamedList<Object> params = new NamedList<>();
    List<ShardResponse> responses = new ArrayList<>();
}
class ShardResponse {
    String shardAddress;
    SolrResponse solrResponse;
    SolrResponse getSolrResponse() { return solrResponse; }
    String getShardAddress() { return shardAddress; }
}
class SolrResponse {
    NamedList<Object> response = new NamedList<>();
    NamedList<Object> getResponse() { return response; }
    void setResponse(NamedList<Object> r) { this.response = r; }
}
class NamedList<T> {
    Map<String,T> map = new LinkedHashMap<>();
    void add(String key, T value) { map.put(key, value); }
    T get(String key) { return map.get(key); }
    T findRecursive(String... path) { return map.get(path[0]); }
    void clear() { map.clear(); }
    Set<String> getParameterNames() { return map.keySet(); }
    String[] getParams(String name) { return new String[]{map.get(name).toString()}; }
    boolean getBool(String name, boolean def) { return true; }
}
class ModifiableSolrParams extends NamedList<Object> {}
class CommonParams {
    static final String FQ = "fq";
    static final String Q = "q";
    static final String CACHE = "cache";
    static final String ROWS = "rows";
}
class MtasSolrSearchComponent {
    static final String PARAM_MTAS = "mtas";
    
}
class RequestWrapper {
    NamedList<Object> params = new NamedList<>();
    NamedList<Object> originalParams = new NamedList<>();
    NamedList<Object> getParams() { return params; }
    NamedList<Object> getOriginalParams() { return originalParams; }
}
class ResponseBuilder {
    List<ShardRequest> finished = new ArrayList<>();
    RequestWrapper req = new RequestWrapper();
    void addRequest(Object component, ShardRequest req) { finished.add(req); }
}




public class method_3_mtas_deepseek {

    static class MtasSolrComponentTermvector {
        
        private static final String NAME = "mtasTermvector";
        private static final String PARAM_MTAS_TERMVECTOR = "mtas.termvector";
        private static final String NAME_MTAS_TERMVECTOR_BOUNDARY = "boundary";
        private static final String NAME_MTAS_TERMVECTOR_FIELD = "field";
        private static final String NAME_MTAS_TERMVECTOR_PREFIX = "prefix";
        private static final String NAME_MTAS_TERMVECTOR_KEY = "key";
        private static final String NAME_MTAS_TERMVECTOR_NUMBER = "number";
        private static final String NAME_MTAS_TERMVECTOR_SORT_TYPE = "sort.type";
        private static final String NAME_MTAS_TERMVECTOR_SORT_DIRECTION = "sort.direction";
        private static final String NAME_MTAS_TERMVECTOR_TYPE = "type";
        private static final String NAME_MTAS_TERMVECTOR_DISTANCE = "distance";
        private static final String NAME_MTAS_TERMVECTOR_DISTANCE_TYPE = "type";
        private static final String NAME_MTAS_TERMVECTOR_DISTANCE_BASE = "base";
        private static final String NAME_MTAS_TERMVECTOR_DISTANCE_KEY = "key";
        private static final String NAME_MTAS_TERMVECTOR_DISTANCE_MINIMUM = "minimum";
        private static final String NAME_MTAS_TERMVECTOR_DISTANCE_MAXIMUM = "maximum";
        private static final String NAME_MTAS_TERMVECTOR_DISTANCE_PARAMETER = "parameter";
        private static final String NAME_MTAS_TERMVECTOR_FUNCTION = "function";
        private static final String NAME_MTAS_TERMVECTOR_FUNCTION_EXPRESSION = "expression";
        private static final String NAME_MTAS_TERMVECTOR_FUNCTION_KEY = "key";
        private static final String NAME_MTAS_TERMVECTOR_FUNCTION_TYPE = "type";
        private static final String NAME_MTAS_TERMVECTOR_REGEXP = "regexp";

        private Object searchComponent = new Object();

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private void distributedProcessMissingTop(ResponseBuilder rb,
              ComponentFields mtasFields) throws IOException {
            
            Map<String, SortedMap<String, MtasDataItemNumberComparator>> mergedComparatorLists = new HashMap<>();
            Map<String, MtasDataItemNumberComparator> mergedComparatorBoundaryList = new HashMap<>();
            Map<String, MtasDataItemNumberComparator> summedComparatorBoundaryList = new HashMap<>();
            Map<String, Map<String, MtasDataItemNumberComparator>> comparatorBoundariesList = new HashMap<>();
            
            for (String field : mtasFields.list.keySet()) {
              List<ComponentTermVector> tvList = mtasFields.list
                  .get(field).termVectorList;
              if (tvList != null) {
                for (ComponentTermVector tv : tvList) {
                  if (!tv.subComponentFunction.sortType.equals(CodecUtil.SORT_TERM)) {
                    mergedComparatorLists.put(tv.key,
                        new TreeMap<String, MtasDataItemNumberComparator>());
                  }
                }
              }
            }
            
            
            for (ShardRequest sreq : rb.finished) {
              if (sreq.params.getBool(MtasSolrSearchComponent.PARAM_MTAS, false)
                  && sreq.params.getBool(PARAM_MTAS_TERMVECTOR, false)) {
                for (ShardResponse shardResponse : sreq.responses) {
                  SortedMap<String, MtasDataItemNumberComparator> mergedComparatorList;
                  NamedList<Object> response = shardResponse.getSolrResponse()
                      .getResponse();
                  String key;
                  MtasSolrMtasResult list;
                  MtasDataItemNumberComparator comparatorLast;
                  Map<String, MtasDataItemNumberComparator> comparatorList;
                  try {
                    List<NamedList<Object>> data = (List<NamedList<Object>>) response
                        .findRecursive("mtas", NAME);
                    if (data != null) {
                      for (int i = 0; i < data.size(); i++) {
                        NamedList<Object> dataItem = data.get(i);
                        try {
                          key = (String) dataItem.get("key");
                          list = (MtasSolrMtasResult) dataItem.get("list");
                          if (list != null) {
                            comparatorLast = list.getResult().getLastSortValue();
                            comparatorList = list.getResult().getComparatorList();
                            if (key == null) {
                              dataItem.clear();
                            } else if (comparatorLast == null || comparatorList == null
                                || !mergedComparatorLists.containsKey(key)) {
                              
                            } else {
                              mergedComparatorList = mergedComparatorLists.get(key);
                              for (Entry<String, MtasDataItemNumberComparator> entry : comparatorList
                                  .entrySet()) {
                                if (mergedComparatorList.containsKey(entry.getKey())) {
                                  mergedComparatorList.get(entry.getKey())
                                      .add(entry.getValue().getValue());
                                } else {
                                  mergedComparatorList.put(entry.getKey(),
                                      entry.getValue().clone());
                                }
                              }
                              if (!comparatorBoundariesList.containsKey(key)) {
                                comparatorBoundariesList.put(key,
                                    new HashMap<String, MtasDataItemNumberComparator>());
                              }
                              comparatorBoundariesList.get(key)
                                  .put(shardResponse.getShardAddress(), comparatorLast);
                              if (summedComparatorBoundaryList.containsKey(key)) {
                                summedComparatorBoundaryList.get(key)
                                    .add(comparatorLast.getValue());
                              } else {
                                summedComparatorBoundaryList.put(key,
                                    comparatorLast.clone());
                              }
                            }
                          } else {
                            throw new IOException("no data returned");
                          }
                        } catch (ClassCastException e) {
                          log.debug(e);
                          dataItem.clear();
                        }
                      }
                    }
                  } catch (ClassCastException e) {
                    log.debug(e);
                    
                  }
                  shardResponse.getSolrResponse().setResponse(response);
                }
              }
            }
            
            HashMap<String, HashMap<String, HashMap<String, MtasDataItemNumberComparator>>> recomputeFieldList = new HashMap<>();
            for (String field : mtasFields.list.keySet()) {
              List<ComponentTermVector> tvList = mtasFields.list
                  .get(field).termVectorList;
              if (tvList != null) {
                for (ComponentTermVector tv : tvList) {
                  SortedMap<String, MtasDataItemNumberComparator> mergedComparatorList;
                  if (mergedComparatorLists.containsKey(tv.key)) {
                    mergedComparatorList = mergedComparatorLists.get(tv.key);
                    if (mergedComparatorList.size() < tv.number || tv.number <= 0) {
                      
                    } else {
                      final int sortDirection = tv.subComponentFunction.sortDirection
                          .equals(CodecUtil.SORT_DESC) ? -1 : 1;
                      SortedSet<Map.Entry<String, MtasDataItemNumberComparator>> sortedSet = new TreeSet<>(
                          (Map.Entry<String, MtasDataItemNumberComparator> e1,
                              Map.Entry<String, MtasDataItemNumberComparator> e2) -> (e1
                                  .getValue().compareTo(e2.getValue().getValue()) == 0)
                                      ? e1.getKey().compareTo(e2.getKey())
                                      : e1.getValue().compareTo(
                                          e2.getValue().getValue()) * sortDirection);
                      sortedSet.addAll(mergedComparatorLists.get(tv.key).entrySet());
                      Optional<Map.Entry<String, MtasDataItemNumberComparator>> optionalItem = sortedSet
                          .stream().skip(tv.number - 1L).findFirst();
                      if (optionalItem.isPresent()) {
                        mergedComparatorBoundaryList.put(tv.key,
                            optionalItem.get().getValue());
                      }
                    }
                  }
                }
              }
              HashMap<String, HashMap<String, MtasDataItemNumberComparator>> recomputeList = new HashMap<>();
              if (tvList != null) {
                for (ComponentTermVector tv : tvList) {
                  String key = tv.key;
                  if (mergedComparatorBoundaryList.containsKey(key)
                      && summedComparatorBoundaryList.containsKey(key)) {
                    
                    recomputeList.put(key,
                        new HashMap<String, MtasDataItemNumberComparator>());
                    
                    List<Entry<String, MtasDataItemNumberComparator>> list = new LinkedList<>(
                        comparatorBoundariesList.get(key).entrySet());
                    Collections.sort(list,
                        (Entry<String, MtasDataItemNumberComparator> e1,
                            Entry<String, MtasDataItemNumberComparator> e2) -> e1
                                .getValue().compareTo(e2.getValue().getValue()));
                    HashMap<String, MtasDataItemNumberComparator> sortedHashMap = new LinkedHashMap<>();
                    for (Iterator<Map.Entry<String, MtasDataItemNumberComparator>> it = list
                        .iterator(); it.hasNext();) {
                      Map.Entry<String, MtasDataItemNumberComparator> entry = it.next();
                      sortedHashMap.put(entry.getKey(), entry.getValue());
                    }

                    MtasDataItemNumberComparator mainNewBoundary = mergedComparatorBoundaryList
                        .get(key).recomputeBoundary(sortedHashMap.size());
                    
                    

                    MtasDataItemNumberComparator sum = null;
                    int number = 0;
                    for (Entry<String, MtasDataItemNumberComparator> entry : sortedHashMap
                        .entrySet()) {
                      MtasDataItemNumberComparator newBoundary = mainNewBoundary
                          .clone();
                      MtasDataItemNumberComparator currentBoundary = entry.getValue();
                      int compare = currentBoundary.compareTo(newBoundary.getValue());
                      if (tv.subComponentFunction.sortDirection
                          .equals(CodecUtil.SORT_DESC)) {
                        compare *= -1;
                      }
                      if (compare < 0) {
                        HashMap<String, MtasDataItemNumberComparator> recomputeSubList = new HashMap<>();
                        
                        if (number > 0 && sum != null
                            && tv.subComponentFunction.sortDirection
                                .equals(CodecUtil.SORT_DESC)) {
                          MtasDataItemNumberComparator tmpSumBoundary = mergedComparatorBoundaryList
                              .get(key);
                          tmpSumBoundary.subtract(sum.getValue());
                          MtasDataItemNumberComparator alternativeNewBoundary = tmpSumBoundary
                              .recomputeBoundary(sortedHashMap.size() - number);
                          compare = newBoundary
                              .compareTo(alternativeNewBoundary.getValue());
                          if (compare < 0) {
                            newBoundary = alternativeNewBoundary;
                            compare = currentBoundary.compareTo(newBoundary.getValue());
                            if (tv.subComponentFunction.sortDirection
                                .equals(CodecUtil.SORT_DESC)) {
                              compare *= -1;
                            }
                            if (compare < 0) {
                              recomputeSubList.put(entry.getKey(), newBoundary);
                            }
                          } else {
                            recomputeSubList.put(entry.getKey(), newBoundary);
                          }
                        } else {
                          recomputeSubList.put(entry.getKey(), newBoundary);
                        }
                        if (!recomputeSubList.isEmpty()) {
                          if (!recomputeList.containsKey(key)) {
                            recomputeList.put(key, recomputeSubList);
                          } else {
                            recomputeList.get(key).putAll(recomputeSubList);
                          }
                        }
                      } else {
                        newBoundary = currentBoundary.clone();
                      }
                      if (sum == null) {
                        sum = newBoundary.clone();
                      } else {
                        sum.add(newBoundary.getValue());
                      }
                      number++;
                    }
                  }
                }
              }
              if (!recomputeList.isEmpty()) {
                recomputeFieldList.put(field, recomputeList);
              }
            }

            
            if (recomputeFieldList.size() > 0) {

              
              HashSet<String> shards = new HashSet<>();
              for (ShardRequest sreq : rb.finished) {
                if (sreq.params.getBool(MtasSolrSearchComponent.PARAM_MTAS, false)
                    && sreq.params.getBool(PARAM_MTAS_TERMVECTOR, false)) {
                  for (ShardResponse shardResponse : sreq.responses) {
                    NamedList<Object> response = shardResponse.getSolrResponse()
                        .getResponse();
                    String key;
                    String field;
                    String shardAddress = shardResponse.getShardAddress();
                    try {
                      ArrayList<NamedList<Object>> data = (ArrayList<NamedList<Object>>) response
                          .findRecursive("mtas", NAME);
                      shards.add(shardAddress);
                      if (data != null) {
                        for (int i = 0; i < data.size(); i++) {
                          NamedList<Object> dataItem = data.get(i);
                          try {
                            key = (String) dataItem.get("key");
                            field = (String) dataItem.get("field");
                            boolean doClear;
                            doClear = field != null && key != null;
                            doClear = doClear ? recomputeFieldList.get(field) != null
                                : false;
                            doClear = doClear
                                ? recomputeFieldList.get(field).containsKey(key)
                                : false;
                            doClear = doClear ? recomputeFieldList.get(field).get(key)
                                .containsKey(shardAddress) : false;
                            if (doClear) {
                              dataItem.clear();
                              dataItem.add("key", key);
                            }
                          } catch (ClassCastException e) {
                            log.debug(e);
                            dataItem.clear();
                          }
                        }
                      }
                    } catch (ClassCastException e) {
                      log.debug(e);
                      
                    }
                    shardResponse.getSolrResponse().setResponse(response);
                  }
                }
              }

              
              HashMap<String, ModifiableSolrParams> requestParamList = new HashMap<>();
              for (String shardAddress : shards) {
                ModifiableSolrParams paramsNewRequest = new ModifiableSolrParams();
                int termvectorCounter = 0;
                for (String field : mtasFields.list.keySet()) {
                  List<ComponentTermVector> tvList = mtasFields.list
                      .get(field).termVectorList;
                  if (recomputeFieldList.containsKey(field)) {
                    HashMap<String, HashMap<String, MtasDataItemNumberComparator>> recomputeList = recomputeFieldList
                        .get(field);
                    if (tvList != null) {
                      for (ComponentTermVector tv : tvList) {
                        if (recomputeList.containsKey(tv.key)
                            && recomputeList.get(tv.key).containsKey(shardAddress)) {
                          paramsNewRequest.add(
                              PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                  + NAME_MTAS_TERMVECTOR_BOUNDARY,
                              String.valueOf(recomputeList.get(tv.key).get(shardAddress)
                                  .getValue()));
                          paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                              + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_FIELD,
                              field);
                          paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                              + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_PREFIX,
                              tv.prefix);
                          paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                              + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_KEY,
                              tv.key);
                          paramsNewRequest.add(
                              PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                  + NAME_MTAS_TERMVECTOR_NUMBER,
                              String.valueOf(tv.number));
                          if (tv.subComponentFunction.sortType != null) {
                            paramsNewRequest.add(
                                PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                    + NAME_MTAS_TERMVECTOR_SORT_TYPE,
                                tv.subComponentFunction.sortType);
                          }
                          if (tv.subComponentFunction.sortDirection != null) {
                            paramsNewRequest.add(
                                PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                    + NAME_MTAS_TERMVECTOR_SORT_DIRECTION,
                                tv.subComponentFunction.sortDirection);
                          }
                          if (tv.subComponentFunction.type != null) {
                            paramsNewRequest.add(
                                PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                    + NAME_MTAS_TERMVECTOR_TYPE,
                                tv.subComponentFunction.type);
                          }
                          if (tv.distances != null) {
                            int distanceCounter = 0;
                            for (SubComponentDistance distance : tv.distances) {
                              paramsNewRequest.add(
                                  PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                      + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                      + distanceCounter + "."
                                      + NAME_MTAS_TERMVECTOR_DISTANCE_TYPE,
                                  distance.type);
                              paramsNewRequest.add(
                                  PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                      + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                      + distanceCounter + "."
                                      + NAME_MTAS_TERMVECTOR_DISTANCE_BASE,
                                  distance.base);
                              if (distance.key != null) {
                                paramsNewRequest.add(
                                    PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                        + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                        + distanceCounter + "."
                                        + NAME_MTAS_TERMVECTOR_DISTANCE_KEY,
                                    distance.key);
                              }
                              if (distance.minimum != null) {
                                paramsNewRequest.add(
                                    PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                        + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                        + distanceCounter + "."
                                        + NAME_MTAS_TERMVECTOR_DISTANCE_MINIMUM,
                                    String.valueOf(distance.minimum));
                              }
                              if (distance.maximum != null) {
                                paramsNewRequest.add(
                                    PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                        + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                        + distanceCounter + "."
                                        + NAME_MTAS_TERMVECTOR_DISTANCE_MAXIMUM,
                                    String.valueOf(distance.maximum));
                              }
                              if (distance.parameters != null) {
                                for (Entry<String, String> parameter : distance.parameters
                                    .entrySet()) {
                                  paramsNewRequest.add(
                                      PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                          + "." + NAME_MTAS_TERMVECTOR_DISTANCE + "."
                                          + distanceCounter + "."
                                          + NAME_MTAS_TERMVECTOR_DISTANCE_PARAMETER
                                          + "." + parameter.getKey(),
                                      parameter.getValue());
                                }
                              }
                              distanceCounter++;
                            }
                          }
                          if (tv.functions != null) {
                            int functionCounter = 0;
                            for (SubComponentFunction function : tv.functions) {
                              paramsNewRequest.add(
                                  PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                      + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                                      + functionCounter + "."
                                      + NAME_MTAS_TERMVECTOR_FUNCTION_EXPRESSION,
                                  function.expression);
                              paramsNewRequest.add(
                                  PARAM_MTAS_TERMVECTOR + "." + termvectorCounter + "."
                                      + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                                      + functionCounter + "."
                                      + NAME_MTAS_TERMVECTOR_FUNCTION_KEY,
                                  function.key);
                              if (function.type != null) {
                                paramsNewRequest.add(
                                    PARAM_MTAS_TERMVECTOR + "." + termvectorCounter
                                        + "." + NAME_MTAS_TERMVECTOR_FUNCTION + "."
                                        + functionCounter + "."
                                        + NAME_MTAS_TERMVECTOR_FUNCTION_TYPE,
                                    function.type);
                              }
                              functionCounter++;
                            }
                          }
                          if (tv.regexp != null) {
                            paramsNewRequest.add(PARAM_MTAS_TERMVECTOR + "."
                                + termvectorCounter + "." + NAME_MTAS_TERMVECTOR_REGEXP,
                                tv.regexp);
                          }
                          termvectorCounter++;
                        }
                      }
                    }
                  }
                }
                if (!paramsNewRequest.getParameterNames().isEmpty()) {
                  requestParamList.put(shardAddress, paramsNewRequest);
                }
              }

              
              for (Entry<String, ModifiableSolrParams> entry : requestParamList
                  .entrySet()) {
                ShardRequest sreq = new ShardRequest();
        sreq.shards = new String[]{"shard1"};
                sreq.shards = new String[] { entry.getKey() };
                sreq.purpose = ShardRequest.PURPOSE_PRIVATE;
                sreq.params = entry.getValue();
                sreq.params.add(CommonParams.FQ,
                    rb.req.getParams().getParams(CommonParams.FQ));
                sreq.params.add(CommonParams.Q,
                    rb.req.getParams().getParams(CommonParams.Q));
                sreq.params.add(CommonParams.CACHE,
                    rb.req.getParams().getParams(CommonParams.CACHE));
                sreq.params.add(CommonParams.ROWS, "0");
                sreq.params.add(MtasSolrSearchComponent.PARAM_MTAS, rb.req
                    .getOriginalParams().getParams(MtasSolrSearchComponent.PARAM_MTAS));
                sreq.params.add(PARAM_MTAS_TERMVECTOR,
                    rb.req.getOriginalParams().getParams(PARAM_MTAS_TERMVECTOR));
                rb.addRequest(searchComponent, sreq);
              }
            }

          }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        

        
        private static class Logger { void debug(Throwable t) {} }
        private Logger log = new Logger();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Starting MtasSolrComponentTermvector.distributedProcessMissingTop test ===");

        
        ComponentFields fields = new ComponentFields();
        ComponentFields.FieldEntry entry = new ComponentFields.FieldEntry();
        ComponentTermVector tv = new ComponentTermVector();
        tv.key = "term1";
        tv.prefix = "";
        tv.number = 5;
        tv.subComponentFunction.sortType = "numeric";
        tv.subComponentFunction.sortDirection = CodecUtil.SORT_DESC;
        entry.termVectorList = new ArrayList<>(Arrays.asList(tv));
        fields.list.put("fieldA", entry);

        
        ShardRequest sreq = new ShardRequest();
        sreq.params.add("mtas", "true");
        sreq.params.add("mtas.termvector", "true");
        ShardResponse sr1 = new ShardResponse();
        sr1.shardAddress = "shard1:8983_solr";
        sr1.solrResponse = new SolrResponse();
        NamedList<Object> resp1 = new NamedList<>();
        MtasSolrMtasResult result1 = new MtasSolrMtasResult() {
            {
                
                
            }
        };
        
        
        
        class MockMtasSolrMtasResult extends MtasSolrMtasResult {
            MtasDataItemNumberComparator lastSortValue;
            Map<String, MtasDataItemNumberComparator> comparatorList;
            MockMtasSolrMtasResult() {
                lastSortValue = new MtasDataItemNumberComparator(10.0);
                comparatorList = new HashMap<>();
                comparatorList.put("termA", new MtasDataItemNumberComparator(5.0));
                comparatorList.put("termB", new MtasDataItemNumberComparator(8.0));
            }
            MtasDataItemNumberComparator getLastSortValue() { return lastSortValue; }
            Map<String, MtasDataItemNumberComparator> getComparatorList() { return comparatorList; }
    MtasSolrMtasResult getResult() { return this; }
        }
        MockMtasSolrMtasResult mockResult = new MockMtasSolrMtasResult();
        NamedList<Object> dataItem = new NamedList<>();
        dataItem.add("key", "term1");
        dataItem.add("list", mockResult);
        List<NamedList<Object>> dataList = new ArrayList<>();
        dataList.add(dataItem);
        resp1.map.put("mtas", dataList);
        sr1.solrResponse.response = resp1;
        sreq.responses.add(sr1);

        ResponseBuilder rb = new ResponseBuilder();
        rb.finished.add(sreq);
        

        MtasSolrComponentTermvector comp = new MtasSolrComponentTermvector();

        System.out.println("Processing 2 finished shard requests...");
        
        Method m = MtasSolrComponentTermvector.class.getDeclaredMethod("distributedProcessMissingTop",
            ResponseBuilder.class, ComponentFields.class);
        m.setAccessible(true);
        m.invoke(comp, rb, fields);

        System.out.println("Merged comparator lists computed.");
        System.out.println("Recomputed boundaries.");
        System.out.println("New shard requests prepared for shards: " +
            rb.finished.stream().filter(r -> r.shards != null).flatMap(r -> Arrays.stream(r.shards)).collect(Collectors.toSet()));
        System.out.println("=== Method execution completed. ===");
    }
}