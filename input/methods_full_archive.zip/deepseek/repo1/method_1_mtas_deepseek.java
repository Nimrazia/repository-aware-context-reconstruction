import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;







enum DocValuesType { NONE, NUMERIC, SORTED, SORTED_NUMERIC, SORTED_SET, BINARY }

class BytesRef {
    byte[] bytes;
    int offset, length;
    BytesRef(byte[] bytes, int offset, int length) { this.bytes=bytes; this.offset=offset; this.length=length; }
    String utf8ToString() { return new String(bytes, offset, length); }
}

class TermsEnum {
    BytesRef term;
    PostingsEnum postingsEnum;
    boolean hasNext;
    TermsEnum() {}
    BytesRef next() throws IOException { if (hasNext) { hasNext=false; return term; } return null; }
    PostingsEnum postings(PostingsEnum reuse) throws IOException { return postingsEnum; }
}

class PostingsEnum {
    int docID;
    int advance(int target) { return docID >= target ? docID : Integer.MAX_VALUE; }
    int docID() { return docID; }
    int freq() { return 1; }
}

class Terms {
    TermsEnum iterator() { return new TermsEnum(); }
}

class NumericDocValues {
    boolean advanceExact(int doc) { return true; }
    long longValue() { return 0; }
}

class SortedNumericDocValues {
    int count;
    long value;
    boolean advanceExact(int doc) { return true; }
    int docValueCount() { return count; }
    long nextValue() { return value; }
}

class SortedSetDocValues {
    long ord;
    boolean advanceExact(int doc) { return true; }
    long nextOrd() { return ord++; }
    BytesRef lookupOrd(long ord) { byte[] b="facetVal".getBytes(); return new BytesRef(b,0,b.length); }
    static final long NO_MORE_ORDS = -1;
}

class SortedDocValues {
    boolean advanceExact(int doc) { return true; }
    BytesRef binaryValue() { return new BytesRef("facetVal".getBytes(),0,8); }
}

class FieldInfo {
    DocValuesType dvType = DocValuesType.NONE;
    String name;
    FieldInfo(String name) { this.name=name; }
    DocValuesType getDocValuesType() { return dvType; }
}

class FieldInfos {
    Map<String,FieldInfo> infos = new HashMap<>();
    FieldInfo fieldInfo(String name) { return infos.get(name); }
}

class LeafReaderContext {
    int docBase;
    LeafReader reader;
    LeafReaderContext(int docBase, LeafReader reader) { this.docBase=docBase; this.reader=reader; }
    LeafReader reader() { return reader; }
}

class LeafReader {
    Map<String,Terms> termsMap = new HashMap<>();
    Map<String,NumericDocValues> numericMap = new HashMap<>();
    Map<String,SortedNumericDocValues> sortedNumericMap = new HashMap<>();
    Map<String,SortedSetDocValues> sortedSetMap = new HashMap<>();
    Map<String,SortedDocValues> sortedMap = new HashMap<>();
    FieldInfos fieldInfos = new FieldInfos();

    LeafReaderContext getContext() { return new LeafReaderContext(0,this); }
    int maxDoc() { return 100; }
    Terms terms(String field) { return termsMap.get(field); }
    NumericDocValues getNumericDocValues(String field) { return numericMap.get(field); }
    SortedNumericDocValues getSortedNumericDocValues(String field) { return sortedNumericMap.get(field); }
    SortedSetDocValues getSortedSetDocValues(String field) { return sortedSetMap.get(field); }
    SortedDocValues getSortedDocValues(String field) { return sortedMap.get(field); }
}

class IndexSearcher {}

class SpanWeight {
    enum Postings { POSITIONS }
    Spans getSpans(LeafReaderContext ctx, Postings p) throws IOException { return new Spans(); }
}

class Spans {
    int docID;
    int startPos;
    static final int NO_MORE_POSITIONS = Integer.MAX_VALUE;
    int advance(int target) { docID = target; startPos = 0; return docID; }
    int docID() { return docID; }
    int nextStartPosition() { return startPos < 3 ? startPos++ : NO_MORE_POSITIONS; }
    int endPosition() { return startPos+1; }
}

class LegacyNumericUtils {
    static final int SHIFT_START_INT = 60;
    static final int SHIFT_START_LONG = 30;
    static int prefixCodedToInt(BytesRef b) { return Integer.parseInt(b.utf8ToString()); }
    static long prefixCodedToLong(BytesRef b) { return Long.parseLong(b.utf8ToString()); }
}


class CodecInfo {
    Map<String,Integer> positions = new HashMap<>();
    Map<String,Integer> tokens = new HashMap<>();
    int getNumberOfPositions(String field, int doc) { return positions.getOrDefault(doc+"",0); }
    int getNumberOfTokens(String field, int doc) { return tokens.getOrDefault(doc+"",0); }
    Map<Integer,Integer> getAllNumberOfPositions(String field, int docBase) { return new HashMap<>(); }
    Map<Integer,Integer> getAllNumberOfTokens(String field, int docBase) { return new HashMap<>(); }
}

class MtasSpanQuery {
    boolean matchAllPositions;
    boolean isMatchAllPositionsQuery() { return matchAllPositions; }
}

class Match {
    int start, end;
    Match(int s,int e) { start=s; end=e; }
}

class ComponentField {
    List<ComponentPosition> statsPositionList = new ArrayList<>();
    List<ComponentToken> statsTokenList = new ArrayList<>();
    List<ComponentTermVector> termVectorList = new ArrayList<>();
    List<MtasSpanQuery> spanQueryList = new ArrayList<>();
    List<ComponentSpan> statsSpanList = new ArrayList<>();
    List<ComponentKwic> kwicList = new ArrayList<>();
    List<ComponentList> listList = new ArrayList<>();
    List<ComponentGroup> groupList = new ArrayList<>();
    List<ComponentFacet> facetList = new ArrayList<>();
    List<ComponentDocument> documentList = new ArrayList<>();
    String uniqueKeyField = "id";
}

class ComponentPosition {}
class ComponentToken {}
class ComponentDocument {}
class ComponentKwic { MtasSpanQuery query; }
class ComponentList { MtasSpanQuery spanQuery; int number, position, start; }
class ComponentGroup { MtasSpanQuery spanQuery; }
class ComponentSpan {
    MtasSpanQuery[] queries;
    MtasParser parser = new MtasParser();
    boolean needPositions() { return false; }
    boolean functionNeedPositions() { return false; }
    int needArgumentsNumber() { return 0; }
    HashSet<Integer> needArgument() { return new HashSet<>(); }
    Set<Integer> functionNeedArguments() { return new HashSet<>(); }
}
class ComponentFacet {
    static final String TYPE_POINTFIELD_WITHOUT_DOCVALUES = "pointfield_without_docvalues";
    String[] baseFields;
    String[] baseFieldTypes;
    MtasSpanQuery[] spanQueries;
    MtasParser[] baseParsers;
    List<MtasFunctionParserFunction>[] baseFunctionParserFunctions;
    boolean baseParserNeedPositions() { return false; }
    boolean functionNeedPositions() { return false; }
}


class MtasParser {
    boolean needPositions() { return false; }
    int needArgumentsNumber() { return 0; }
    HashSet<Integer> needArgument() { return new HashSet<>(); }
}
class DocIdSetIterator { static final int NO_MORE_DOCS = Integer.MAX_VALUE; }

class MtasFunctionParserFunction {
    boolean needPositions() { return false; }
    int needArgumentsNumber() { return 0; }
    HashSet<Integer> needArgument() { return new HashSet<>(); }
}

class SubComponentFunction {
    String sortType, sortDirection, type;
    MtasFunctionParserFunction parserFunction = new MtasFunctionParserFunction();
    boolean needPositions() { return false; }
}

class SubComponentDistance {
    String type, base, key;
    Integer minimum, maximum;
    Map<String,String> parameters = new HashMap<>();
}

class ComponentTermVector {
    String key, prefix, regexp;
    int number;
    SubComponentFunction subComponentFunction = new SubComponentFunction();
    List<SubComponentFunction> functions;
    List<SubComponentDistance> distances;
    boolean functionNeedPositions() { return false; }
}

class CodecUtil {
    static final String SORT_TERM = "term";
    static final String SORT_DESC = "desc";
}

enum NumberType { INTEGER, LONG, DATE }

class Status {}

class MtasDataItemNumberComparator implements Comparable<MtasDataItemNumberComparator> {
    double value;
    MtasDataItemNumberComparator(double v) { value=v; }
    void add(double v) { value+=v; }
    void subtract(double v) { value-=v; }
    double getValue() { return value; }
    public MtasDataItemNumberComparator clone() { return new MtasDataItemNumberComparator(value); }
    MtasDataItemNumberComparator recomputeBoundary(int size) { return this; }
    @Override public int compareTo(MtasDataItemNumberComparator o) { return Double.compare(value,o.value); }
    public int compareTo(double v) { return Double.compare(value,v); }
}





public class method_1_mtas_deepseek {
    static class CodecCollector {

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        private static void collectSpansPositionsAndTokens(
              Map<MtasSpanQuery, SpanWeight> spansQueryWeight, IndexSearcher searcher,
              CodecInfo mtasCodecInfo, LeafReader r, LeafReaderContext lrc,
              String field, Terms t, List<Integer> docSet, List<Integer> docList,
              ComponentField fieldInfo, FieldInfos fieldInfos, Status status)
              throws IOException {

            boolean needSpans = false;
            boolean needPositions = false;
            boolean needTokens = false;

            
            Map<Integer, Integer> positionsData = null;
            Map<Integer, Integer> tokensData = null;
            Set<MtasSpanQuery> spansNumberByPositions = null;
            Map<MtasSpanQuery, Map<Integer, Integer>> spansNumberData = null;
            Map<MtasSpanQuery, Map<Integer, List<Match>>> spansMatchData = null;
            Map<String, SortedMap<String, int[]>> facetData = null;
            Map<String, String> facetDataType = null;

            
            if (!fieldInfo.statsPositionList.isEmpty()) {
              needPositions = true;
            }
            
            if (!fieldInfo.statsTokenList.isEmpty()) {
              needTokens = true;
            }
            if (!fieldInfo.termVectorList.isEmpty()) {
              for (ComponentTermVector ctv : fieldInfo.termVectorList) {
                if (!needPositions) {
                  needPositions = (ctv.functions == null
                      ? ctv.subComponentFunction.parserFunction.needPositions()
                      : ctv.functionNeedPositions());
                }
              }
            }

            
            if (!fieldInfo.spanQueryList.isEmpty()) {
              
              spansNumberByPositions = new HashSet<>();
              spansNumberData = new HashMap<>();
              spansMatchData = new HashMap<>();
              facetData = new HashMap<>();
              facetDataType = new HashMap<>();
              
              if (!fieldInfo.statsSpanList.isEmpty()) {
                for (ComponentSpan cs : fieldInfo.statsSpanList) {
                  needPositions = (!needPositions) ? cs.parser.needPositions()
                      : needPositions;
                  needPositions = (!needPositions) ? cs.functionNeedPositions()
                      : needPositions;
                  needSpans = (!needSpans) ? cs.parser.needArgumentsNumber() > 0
                      : needSpans;
                  HashSet<Integer> arguments = cs.parser.needArgument();
                  arguments.addAll(cs.functionNeedArguments());
                  for (int a : arguments) {
                    if (cs.queries.length > a) {
                      MtasSpanQuery q = cs.queries[a];
                      if (!spansNumberData.containsKey(q)) {
                        spansNumberData.put(q, new HashMap<Integer, Integer>());
                      }
                    }
                  }
                }
              }
              
              if (!fieldInfo.kwicList.isEmpty()) {
                needSpans = true;
                for (ComponentKwic ck : fieldInfo.kwicList) {
                  if (!spansMatchData.containsKey(ck.query)) {
                    spansMatchData.put(ck.query, new HashMap<Integer, List<Match>>());
                  }
                }
              }
              
              if (!fieldInfo.listList.isEmpty()) {
                needSpans = true;
                for (ComponentList cl : fieldInfo.listList) {
                  if (!spansMatchData.containsKey(cl.spanQuery)) {
                    if (cl.number > 0) {
                      
                      if (cl.position < (cl.start + cl.number)) {
                        spansMatchData.put(cl.spanQuery,
                            new HashMap<Integer, List<Match>>());
                      } else {
                        spansNumberData.put(cl.spanQuery,
                            new HashMap<Integer, Integer>());
                      }
                    } else if (!spansNumberData.containsKey(cl.spanQuery)) {
                      spansNumberData.put(cl.spanQuery,
                          new HashMap<Integer, Integer>());
                    }
                  }
                }
              }
              
              if (!fieldInfo.groupList.isEmpty()) {
                needSpans = true;
                for (ComponentGroup cg : fieldInfo.groupList) {
                  if (!spansMatchData.containsKey(cg.spanQuery)) {
                    spansMatchData.put(cg.spanQuery,
                        new HashMap<Integer, List<Match>>());
                  }
                }
              }
              
              if (!fieldInfo.facetList.isEmpty()) {
                for (ComponentFacet cf : fieldInfo.facetList) {
                  needPositions = !needPositions ? cf.baseParserNeedPositions()
                      : needPositions;
                  needPositions = !needPositions ? cf.functionNeedPositions()
                      : needPositions;
                  for (int i = 0; i < cf.baseFields.length; i++) {
                    needSpans = !needSpans ? cf.baseParsers[i].needArgumentsNumber() > 0
                        : needSpans;
                    HashSet<Integer> arguments = cf.baseParsers[i].needArgument();
                    for (int a : arguments) {
                      if (cf.spanQueries.length > a) {
                        MtasSpanQuery q = cf.spanQueries[a];
                        if (!spansNumberData.containsKey(q)) {
                          spansNumberData.put(q, new HashMap<Integer, Integer>());
                        }
                      }
                    }
                    for (MtasFunctionParserFunction function : cf.baseFunctionParserFunctions[i]) {
                      needSpans = !needSpans ? function.needArgumentsNumber() > 0
                          : needSpans;
                      arguments = function.needArgument();
                      for (int a : arguments) {
                        if (cf.spanQueries.length > a) {
                          MtasSpanQuery q = cf.spanQueries[a];
                          if (!spansNumberData.containsKey(q)) {
                            spansNumberData.put(q, new HashMap<Integer, Integer>());
                          }
                        }
                      }
                    }
                    if (!facetData.containsKey(cf.baseFields[i])) {
                      facetData.put(cf.baseFields[i], new TreeMap<String, int[]>());
                      facetDataType.put(cf.baseFields[i], cf.baseFieldTypes[i]);
                    }
                  }
                }
              }
              
              if (!fieldInfo.termVectorList.isEmpty()) {
                for (ComponentTermVector ctv : fieldInfo.termVectorList) {
                  if ((ctv.subComponentFunction.parserFunction != null
                      && ctv.subComponentFunction.parserFunction.needPositions())
                      || (ctv.functions != null && ctv.functionNeedPositions())) {
                    needPositions = true;
                  }
                }
              }
            }

            if (needSpans) {
              Map<Integer, Integer> numberData;
              Map<Integer, List<Match>> matchData;
              
              for (Entry<String, SortedMap<String, int[]>> entry : facetData
                  .entrySet()) {
                FieldInfo fi = fieldInfos.fieldInfo(entry.getKey());
                if (fi != null) {
                  
                  if (!fi.getDocValuesType().equals(DocValuesType.NONE)) {
                    Iterator<Integer> docIterator = docSet.iterator();
                    
                    if (fi.getDocValuesType().equals(DocValuesType.NUMERIC)
                        || fi.getDocValuesType().equals(DocValuesType.SORTED)
                        || fi.getDocValuesType().equals(DocValuesType.SORTED_SET)
                        || fi.getDocValuesType().equals(DocValuesType.SORTED_NUMERIC)
                        || fi.getDocValuesType().equals(DocValuesType.BINARY)) {
                      
                      Map<Object, List<Integer>> facetDataSubList = new HashMap<>();
                      
                      if (fi.getDocValuesType().equals(DocValuesType.NUMERIC)) {
                        NumericDocValues docValues = r.getContext().reader()
                            .getNumericDocValues(entry.getKey());
                        int docId;
                        while (docIterator.hasNext()) {
                          docId = docIterator.next() - lrc.docBase;
                          if (docValues.advanceExact(docId)) {
                            long value = docValues.longValue();
                            if (!facetDataSubList.containsKey(value)) {
                              List<Integer> facetDataSubListItem = new ArrayList<>();
                              facetDataSubListItem.add(docId + lrc.docBase);
                              facetDataSubList.put(value, facetDataSubListItem);
                            } else {
                              facetDataSubList.get(value).add(docId + lrc.docBase);
                            }
                          }
                        }
                      
                      } else if (fi.getDocValuesType().equals(DocValuesType.SORTED_NUMERIC)) {
                        SortedNumericDocValues docValues = r.getContext().reader()
                            .getSortedNumericDocValues(entry.getKey());
                        int docId;
                        while (docIterator.hasNext()) {
                          docId = docIterator.next() - lrc.docBase;
                          if (docValues.advanceExact(docId)) {
                            int n = docValues.docValueCount();
                            for(int i =0; i<n; i++) {
                              long value = docValues.nextValue();
                              if (!facetDataSubList.containsKey(value)) {
                                List<Integer> facetDataSubListItem = new ArrayList<>();
                                facetDataSubListItem.add(docId + lrc.docBase);
                                facetDataSubList.put(value, facetDataSubListItem);
                              } else {
                                facetDataSubList.get(value).add(docId + lrc.docBase);
                              }  
                            }                    
                          }
                        }
                     
                      } else if (fi.getDocValuesType().equals(DocValuesType.SORTED_SET)) {
                        SortedSetDocValues docValues = r.getContext().reader()
                            .getSortedSetDocValues(entry.getKey());
                        int docId;
                        Map<Long, String> dictionary = new HashMap<>();
                        while (docIterator.hasNext()) {
                          docId = docIterator.next() - lrc.docBase;
                          if (docValues.advanceExact(docId)) {
                            long tmpValue;
                            String value;
                            while((tmpValue=docValues.nextOrd()) != SortedSetDocValues.NO_MORE_ORDS) {
                              if(!dictionary.containsKey(tmpValue)) {
                                value = docValues.lookupOrd(tmpValue).utf8ToString();
                                dictionary.put(tmpValue, value);
                              } else {
                                value = dictionary.get(tmpValue);
                              }
                              if (!facetDataSubList.containsKey(value)) {
                                List<Integer> facetDataSubListItem = new ArrayList<>();
                                facetDataSubListItem.add(docId + lrc.docBase);
                                facetDataSubList.put(value, facetDataSubListItem);
                              } else {
                                facetDataSubList.get(value).add(docId + lrc.docBase);
                              }
                            }
                          }
                        }
                      
                      } else if (fi.getDocValuesType().equals(DocValuesType.SORTED)) {
                        SortedDocValues docValues = r.getContext().reader()
                            .getSortedDocValues(entry.getKey());
                        int docId;
                        while (docIterator.hasNext()) {
                          docId = docIterator.next() - lrc.docBase;
                          if (docValues.advanceExact(docId)) {
                            String value = docValues.binaryValue().utf8ToString();
                            if (!facetDataSubList.containsKey(value)) {
                              List<Integer> facetDataSubListItem = new ArrayList<>();
                              facetDataSubListItem.add(docId + lrc.docBase);
                              facetDataSubList.put(value, facetDataSubListItem);
                            } else {
                              facetDataSubList.get(value).add(docId + lrc.docBase);
                            }
                          }
                        }
                      }
                      if (!facetDataSubList.isEmpty()) {
                        SortedMap<String, int[]> facetDataList = entry.getValue();
                        SimpleDateFormat sdf = new SimpleDateFormat(
                            "yyyy-MM-dd'T'HH:mm:ss'Z'");
                        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
                        for (Entry<Object, List<Integer>> facetEntry : facetDataSubList
                            .entrySet()) {
                          int[] docIdList = facetEntry.getValue().stream()
                              .mapToInt(i -> i).toArray();
                          String termValue;
                          if (facetDataType.get(entry.getKey())
                              .equals(NumberType.DATE.name())) {
                            Date date = new Date((Long) facetEntry.getKey());
                            termValue = sdf.format(date);
                          } else {
                            termValue = facetEntry.getKey().toString();
                          }
                          if (!facetDataList.containsKey(termValue)) {
                            facetDataList.put(termValue, docIdList);
                          } else {
                            int[] oldList = facetDataList.get(termValue);
                            int[] newList = new int[oldList.length + docIdList.length];
                            System.arraycopy(oldList, 0, newList, 0, oldList.length);
                            System.arraycopy(docIdList, 0, newList, oldList.length,
                                docIdList.length);
                            facetDataList.put(termValue, newList);
                          }
                        }
                      }
                    } else {
                      throw new IOException("facets for docValues of type "
                          + fi.getDocValuesType() + " not implemented");
                    }
                  } else if (!docSet.isEmpty()) {
                    if (facetDataType.get(entry.getKey())
                        .equals(ComponentFacet.TYPE_POINTFIELD_WITHOUT_DOCVALUES)) {
                      throw new IOException(
                          "can't create facets for pointField without docValues");
                    }
                    Terms fft = r.terms(entry.getKey());
                    if (fft != null) {
                      TermsEnum termsEnum = fft.iterator();
                      BytesRef term = null;
                      PostingsEnum postingsEnum = null;
                      SortedMap<String, int[]> facetDataList = entry.getValue();
                      while ((term = termsEnum.next()) != null) {
                        int docId;
                        int termDocId = -1;
                        int[] facetDataSublist = new int[docSet.size()];
                        int facetDataSublistCounter = 0;
                        Iterator<Integer> docIterator = docSet.iterator();
                        postingsEnum = termsEnum.postings(postingsEnum);
                        while (docIterator.hasNext()) {
                          docId = docIterator.next() - lrc.docBase;
                          if (docId >= termDocId
                              && ((docId == termDocId) || ((termDocId = postingsEnum
                                  .advance(docId)) == docId))) {
                            facetDataSublist[facetDataSublistCounter] = docId
                                + lrc.docBase;
                            facetDataSublistCounter++;
                          }
                        }
                        if (facetDataSublistCounter > 0) {
                          String termValue = null;
                          if (facetDataType.get(entry.getKey())
                              .equals(NumberType.INTEGER.name())) {
                            
                            if (term.bytes[term.offset] == LegacyNumericUtils.SHIFT_START_INT) {
                              termValue = Integer
                                  .toString(LegacyNumericUtils.prefixCodedToInt(term));
                            } else {
                              continue;
                            }
                          } else if (facetDataType.get(entry.getKey())
                              .equals(NumberType.LONG.name())) {
                            if (term.bytes[term.offset] == LegacyNumericUtils.SHIFT_START_LONG) {
                              termValue = Long
                                  .toString(LegacyNumericUtils.prefixCodedToLong(term));
                            } else {
                              continue;
                            }
                          } else {
                            termValue = term.utf8ToString();
                          }
                          if (!facetDataList.containsKey(termValue)) {
                            facetDataList.put(termValue, Arrays.copyOf(facetDataSublist,
                                facetDataSublistCounter));
                          } else {
                            int[] oldList = facetDataList.get(termValue);
                            int[] newList = new int[oldList.length
                                + facetDataSublistCounter];
                            System.arraycopy(oldList, 0, newList, 0, oldList.length);
                            System.arraycopy(facetDataSublist, 0, newList,
                                oldList.length, facetDataSublistCounter);
                            facetDataList.put(termValue, newList);
                          }
                        }
                      }
                    }
                  }
                }
              }

              
              for (MtasSpanQuery sq : fieldInfo.spanQueryList) {
                
                if (spansNumberData.containsKey(sq)) {
                  numberData = spansNumberData.get(sq);
                } else {
                  numberData = null;
                }
                
                if (spansMatchData.containsKey(sq)) {
                  matchData = spansMatchData.get(sq);
                } else {
                  matchData = null;
                }
                boolean doNormalCollection = true;
                
                if ((numberData != null) && (matchData == null)) {
                  if (sq.isMatchAllPositionsQuery()) {
                    spansNumberByPositions.add(sq);
                    needPositions = true;
                    doNormalCollection = false;
                  }
                }
                
                if (doNormalCollection
                    && ((numberData != null) || (matchData != null))) {
                  Spans spans = spansQueryWeight.get(sq).getSpans(lrc,
                      SpanWeight.Postings.POSITIONS);
                  if (spans != null) {
                    Iterator<Integer> it;
                    if (docSet != null) {
                      it = docSet.iterator();
                    } else {
                      it = docList.iterator();
                    }
                    if (it.hasNext()) {
                      int docId = it.next();
                      int number;
                      ArrayList<Match> matchDataList;
                      Integer spansDocId = null;
                      while (docId != DocIdSetIterator.NO_MORE_DOCS) {
                        if (spans.advance(
                            (docId - lrc.docBase)) == DocIdSetIterator.NO_MORE_DOCS) {
                          break;
                        }
                        spansDocId = spans.docID() + lrc.docBase;
                        while ((docId < spansDocId) && it.hasNext()) {
                          docId = it.next();
                        }
                        if (docId < spansDocId) {
                          break;
                        }
                        if (spansDocId.equals(docId)) {
                          number = 0;
                          matchDataList = new ArrayList<>();
                          int tmpStartPosition;
                          while ((tmpStartPosition = spans
                              .nextStartPosition()) != Spans.NO_MORE_POSITIONS) {
                            number++;
                            if (matchData != null) {
                              Match m = new Match(tmpStartPosition,
                                  spans.endPosition());
                              matchDataList.add(m);
                            }
                          }
                          if ((numberData != null)) {
                            numberData.put(spansDocId, number);
                          }
                          if ((matchData != null)) {
                            matchData.put(spansDocId, matchDataList);
                          }
                          if (it.hasNext()) {
                            docId = it.next();
                          } else {
                            break;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }

            
            if (needPositions) {
              if (mtasCodecInfo != null) {
                
                if (docSet.size() < Math.log(r.maxDoc())) {
                  positionsData = new HashMap<>();
                  for (int docId : docSet) {
                    positionsData.put(docId, mtasCodecInfo.getNumberOfPositions(field,
                        (docId - lrc.docBase)));
                  }
                  
                } else {
                  positionsData = mtasCodecInfo.getAllNumberOfPositions(field,
                      lrc.docBase);
                  for (int docId : docSet) {
                    if (!positionsData.containsKey(docId)) {
                      positionsData.put(docId, 0);
                    }
                  }
                }
              } else {
                positionsData = new HashMap<>();
                for (int docId : docSet) {
                  positionsData.put(docId, 0);
                }
              }
              if (spansNumberByPositions != null && spansNumberData != null) {        
                for (MtasSpanQuery sq : spansNumberByPositions) {
                  Map<Integer,Integer> numberData = spansNumberData.get(sq);
                  positionsData.forEach((k,v) -> numberData.put(k,v!=null?v:0));          
                }
              }
            }

            
            if (needTokens) {
              if (mtasCodecInfo != null) {
                
                if (docSet.size() < Math.log(r.maxDoc())) {
                  tokensData = new HashMap<>();
                  for (int docId : docSet) {
                    tokensData.put(docId,
                        mtasCodecInfo.getNumberOfTokens(field, (docId - lrc.docBase)));
                  }
                  
                } else {
                  tokensData = mtasCodecInfo.getAllNumberOfTokens(field, lrc.docBase);
                  for (int docId : docSet) {
                    if (!tokensData.containsKey(docId)) {
                      tokensData.put(docId, 0);
                    }
                  }
                }
              } else {
                tokensData = new HashMap<>();
                for (int docId : docSet) {
                  tokensData.put(docId, 0);
                }
              }
            }

            if (!fieldInfo.statsPositionList.isEmpty()) {
              
              createPositions(fieldInfo.statsPositionList, positionsData, docSet);
            }

            if (!fieldInfo.statsTokenList.isEmpty()) {
              
              createTokens(fieldInfo.statsTokenList, tokensData, docSet);
            }

            if (!fieldInfo.documentList.isEmpty()) {
              
              createDocument(fieldInfo.documentList, docList, fieldInfo.uniqueKeyField,
                  searcher, t, lrc);
            }
            if (!fieldInfo.spanQueryList.isEmpty()) {
              if (!fieldInfo.statsSpanList.isEmpty()) {
                
                createStats(fieldInfo.statsSpanList, positionsData, spansNumberData,
                    docSet.toArray(new Integer[docSet.size()]));
              }
              if (!fieldInfo.listList.isEmpty()) {
                
                createList(fieldInfo.listList, spansNumberData, spansMatchData, docSet,
                    field, lrc.docBase, fieldInfo.uniqueKeyField, mtasCodecInfo,
                    searcher);
              }
              if (!fieldInfo.groupList.isEmpty()) {
                
                createGroup(fieldInfo.groupList, spansMatchData, docSet,
                    fieldInfos.fieldInfo(field), field, lrc.docBase, mtasCodecInfo,
                    searcher, lrc, status);
              }
              if (!fieldInfo.kwicList.isEmpty()) {
                
                createKwic(fieldInfo.kwicList, spansMatchData, docList, field,
                    lrc.docBase, fieldInfo.uniqueKeyField, mtasCodecInfo, searcher);
              }
              if (!fieldInfo.facetList.isEmpty()) {
                
                createFacet(fieldInfo.facetList, positionsData, spansNumberData,
                    facetData, docSet);
              }
            }
            if (!fieldInfo.termVectorList.isEmpty()) {
              createTermvectorFull(fieldInfo.termVectorList, positionsData, docSet, t,
                  r, lrc);
              createTermvectorFirstRound(fieldInfo.termVectorList, positionsData,
                  docSet, t, r, lrc);
            }
          }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        

        
        private static void createPositions(List<ComponentPosition> list, Map<Integer,Integer> data, List<Integer> docSet) {
            System.out.println("Created positions data for " + docSet.size() + " docs.");
        }
        private static void createTokens(List<ComponentToken> list, Map<Integer,Integer> data, List<Integer> docSet) {
            System.out.println("Created tokens data for " + docSet.size() + " docs.");
        }
        private static void createDocument(List<ComponentDocument> list, List<Integer> docList, String uniqueKey, IndexSearcher searcher, Terms t, LeafReaderContext lrc) {
            System.out.println("Created document info.");
        }
        private static void createStats(List<ComponentSpan> list, Map<Integer,Integer> posData, Map<MtasSpanQuery,Map<Integer,Integer>> numberData, Integer[] docIds) {
            System.out.println("Created stats for " + list.size() + " component span(s).");
        }
        private static void createList(List<ComponentList> list, Map<MtasSpanQuery,Map<Integer,Integer>> numberData, Map<MtasSpanQuery,Map<Integer,List<Match>>> matchData, List<Integer> docSet, String field, int docBase, String uniqueKey, CodecInfo info, IndexSearcher searcher) {
            System.out.println("Created list data.");
        }
        private static void createGroup(List<ComponentGroup> list, Map<MtasSpanQuery,Map<Integer,List<Match>>> matchData, List<Integer> docSet, FieldInfo fi, String field, int docBase, CodecInfo info, IndexSearcher searcher, LeafReaderContext lrc, Status status) {
            System.out.println("Created group data.");
        }
        private static void createKwic(List<ComponentKwic> list, Map<MtasSpanQuery,Map<Integer,List<Match>>> matchData, List<Integer> docList, String field, int docBase, String uniqueKey, CodecInfo info, IndexSearcher searcher) {
            System.out.println("Created kwic data.");
        }
        private static void createFacet(List<ComponentFacet> list, Map<Integer,Integer> posData, Map<MtasSpanQuery,Map<Integer,Integer>> numberData, Map<String,SortedMap<String,int[]>> facetData, List<Integer> docSet) {
            System.out.println("Created facet data.");
        }
        private static void createTermvectorFull(List<ComponentTermVector> list, Map<Integer,Integer> posData, List<Integer> docSet, Terms t, LeafReader r, LeafReaderContext lrc) {
            System.out.println("Created full term vector.");
        }
        private static void createTermvectorFirstRound(List<ComponentTermVector> list, Map<Integer,Integer> posData, List<Integer> docSet, Terms t, LeafReader r, LeafReaderContext lrc) {
            System.out.println("Created first-round term vector.");
        }
    }

    
    public static void main(String[] args) throws Exception {
        System.out.println("=== Starting CodecCollector.collectSpansPositionsAndTokens test ===");
        
        Map<MtasSpanQuery, SpanWeight> sqWeight = new HashMap<>();
        MtasSpanQuery sq = new MtasSpanQuery(); sq.matchAllPositions = false;
        sqWeight.put(sq, new SpanWeight());
        IndexSearcher searcher = new IndexSearcher();
        CodecInfo info = new CodecInfo(); 
        LeafReader reader = new LeafReader();
        LeafReaderContext lrc = new LeafReaderContext(0, reader);
        String field = "content";
        Terms terms = new Terms();
        List<Integer> docSet = Arrays.asList(123, 456);
        List<Integer> docList = new ArrayList<>(docSet);
        ComponentField fieldInfo = new ComponentField();
        
        fieldInfo.statsPositionList.add(new ComponentPosition());
        fieldInfo.statsTokenList.add(new ComponentToken());
        ComponentSpan span = new ComponentSpan(); span.queries = new MtasSpanQuery[]{sq}; span.parser = new MtasParser();
        fieldInfo.statsSpanList.add(span);
        fieldInfo.spanQueryList.add(sq);
        fieldInfo.kwicList.add(new ComponentKwic() {{ query = sq; }});
        fieldInfo.listList.add(new ComponentList() {{ spanQuery = sq; number=1; position=0; start=0; }});
        fieldInfo.groupList.add(new ComponentGroup() {{ spanQuery = sq; }});
        ComponentFacet facet = new ComponentFacet();
        facet.baseFields = new String[]{"facetField"};
        facet.baseFieldTypes = new String[]{NumberType.INTEGER.name()};
        facet.spanQueries = new MtasSpanQuery[]{sq};
        facet.baseParsers = new MtasParser[]{new MtasParser()};
        facet.baseFunctionParserFunctions = new List[]{new ArrayList<MtasFunctionParserFunction>()};
        fieldInfo.facetList.add(facet);
        fieldInfo.documentList.add(new ComponentDocument());
        FieldInfos fieldInfos = new FieldInfos();
        FieldInfo fi = new FieldInfo("facetField"); fi.dvType = DocValuesType.NUMERIC;
        fieldInfos.infos.put("facetField", fi);
        
        reader.numericMap.put("facetField", new NumericDocValues());

        Status status = new Status();

        System.out.println("Set up " + docSet.size() + " docs in docSet: " + docSet);

        
        Method m = CodecCollector.class.getDeclaredMethod("collectSpansPositionsAndTokens",
            Map.class, IndexSearcher.class, CodecInfo.class, LeafReader.class,
            LeafReaderContext.class, String.class, Terms.class, List.class,
            List.class, ComponentField.class, FieldInfos.class, Status.class);
        m.setAccessible(true);
        m.invoke(null, sqWeight, searcher, info, reader, lrc, field, terms, docSet, docList, fieldInfo, fieldInfos, status);

        System.out.println("=== Method execution completed. ===");
    }
}