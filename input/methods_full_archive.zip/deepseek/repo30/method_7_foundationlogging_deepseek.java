import java.util.*;
import java.util.Map.Entry;





class Component {
    private String name;
    private long time;
    public String getName() { return name; }
    public long getTime() { return time; }
    public void setName(String n) { name = n; }
    public void setTime(long t) { time = t; }
}

class Components {
    private List<Component> components = new ArrayList<>();
    public List<Component> getComponents() { return components; }
    public void addComponent(Component c) { components.add(c); }
}

class TransactionLogger {
    protected Map<String, Component> components = new HashMap<>();
    protected Components componentsMultiThread;
    protected Timer total = new Timer();

    
    private void addTimePerComponent(Map<String, Long> map, Component comp) {
        map.put(comp.getName(), map.getOrDefault(comp.getName(), 0L) + comp.getTime());
    }
    private void addInvocationPerComponent(Map<String, Long> map, Component comp) {
        map.put(comp.getName(), map.getOrDefault(comp.getName(), 0L) + 1);
    }
    private String addDuration(long time) { return time + "ms"; }
    private void putProperty(String key, String value) { System.out.println("[PROPERTY] " + key + "=" + value); }

    static class Timer {
        public long getTime() { return 1000; }
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    protected void addPropertiesProcessingTime() {

        HashMap<String, Long> mapComponentTimes         = new HashMap<>();
        HashMap<String, Long> mapComponentInvocations   = new HashMap<>();

        
        if (this.componentsMultiThread != null) {
          for (Component component : this.componentsMultiThread.getComponents()) {
            addTimePerComponent(mapComponentTimes, component);
            addInvocationPerComponent(mapComponentInvocations, component);
          }
        }

        for (Component component : this.components.values()) {
          addTimePerComponent(mapComponentTimes, component);
        }

        for (Entry<String, Long> entry : mapComponentTimes.entrySet()) {
          putProperty(entry.getKey(), addDuration(entry.getValue()));
        }

        for (Entry<String, Long> entry : mapComponentInvocations.entrySet()) {
          putProperty(entry.getKey(), entry.getValue().toString());
        }
        putProperty("TOTAL_COMPONENT", addDuration(this.total.getTime()));
      }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_7_foundationlogging_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing TransactionLogger.addPropertiesProcessingTime ===\n");

        TransactionLogger logger = new TransactionLogger();
        
        Component c1 = new Component(); c1.setName("component1"); c1.setTime(100);
        Component c2 = new Component(); c2.setName("component2"); c2.setTime(200);
        logger.components.put("comp1", c1);
        logger.components.put("comp2", c2);

        
        Components multi = new Components();
        Component c3 = new Component(); c3.setName("multiComp1"); c3.setTime(50);
        Component c4 = new Component(); c4.setName("multiComp2"); c4.setTime(75);
        multi.addComponent(c3); multi.addComponent(c4);
        logger.componentsMultiThread = multi;

        
        logger.addPropertiesProcessingTime();

        System.out.println("\n=== Test completed ===");
    }
}