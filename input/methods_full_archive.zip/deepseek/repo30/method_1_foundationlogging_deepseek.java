import java.util.*;






class Appender {
    public Layout getLayout() { return new Layout(); }
    public void setLayout(Layout layout) {  }
    public void doAppend(LoggingEvent event) {  }
}

class Layout {
    
}

class LoggingEvent {
    
}

class DiscardSummary {
    public LoggingEvent createEvent() { return new LoggingEvent(); }
}

class AsyncAppender {
    
}





class FoundationLoggingDispatcher implements Runnable {
    private List<LoggingEvent> buffer = new ArrayList<>();
    private Map<Object, DiscardSummary> discardMap = new HashMap<>();
    private AppenderAttachable appenders = new AppenderAttachable();
    private AsyncAppender parent;

    public FoundationLoggingDispatcher(AsyncAppender parent) { this.parent = parent; }

    
    private boolean isAsyncAppenderClosed(AsyncAppender parent) { return false; }
    private boolean udpateLayoutIfNeeded(Appender appender, LoggingEvent event) { return false; }

    
    static class AppenderAttachable {
        public Enumeration<Appender> getAllAppenders() {
            return Collections.enumeration(Collections.emptyList());
        }
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void run() {
        boolean isActive = true;

        
        
        
        try {
            
            
            
            while (isActive) {
                LoggingEvent[] events = null;

                
                
                
                
                synchronized (buffer) {
                    int bufferSize = buffer.size();
                    isActive = !isAsyncAppenderClosed(parent);

                    while ((bufferSize == 0) && isActive) {
                        buffer.wait();
                        bufferSize = buffer.size();
                        isActive = !isAsyncAppenderClosed(parent);
                    }

                    if (bufferSize > 0) {
                        events = new LoggingEvent[bufferSize + discardMap.size()];
                        buffer.toArray(events);

                        
                        
                        
                        int index = bufferSize;

                        for (Iterator iter = discardMap.values().iterator(); iter.hasNext();) {
                            events[index++] = ((DiscardSummary) iter.next()).createEvent();
                        }

                        
                        
                        
                        buffer.clear();
                        discardMap.clear();

                        
                        
                        buffer.notifyAll();
                    }
                }

                
                
                
                if (events != null) {
                    for (int i = 0; i < events.length; i++) {
                        synchronized (appenders) {
                            LoggingEvent event = events[i];
                            @SuppressWarnings("unchecked")
                            Enumeration<Appender> allAppenders = appenders.getAllAppenders();

                            while (allAppenders.hasMoreElements()) {
                                Appender appender = allAppenders.nextElement();

                                
                                synchronized (appender) {
                                    Layout originalLayout = appender.getLayout();
                                    boolean appenderUpdated = udpateLayoutIfNeeded(appender, event);

                                    appender.doAppend(event);
                                    if (appenderUpdated) {
                                        appender.setLayout(originalLayout);
                                    }
                                }

                            }
                        }
                    }
                }
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_1_foundationlogging_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing FoundationLoggingDispatcher.run ===\n");

        AsyncAppender parent = new AsyncAppender();
        FoundationLoggingDispatcher dispatcher = new FoundationLoggingDispatcher(parent);
        
        Thread t = new Thread(dispatcher);
        t.start();
        
        try { Thread.sleep(100); } catch (InterruptedException e) {  }
        t.interrupt();
        System.out.println("Dispatcher thread started and interrupted.");

        System.out.println("\n=== Test completed ===");
    }
}