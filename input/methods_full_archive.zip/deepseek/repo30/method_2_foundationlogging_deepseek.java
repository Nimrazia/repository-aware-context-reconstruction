import java.util.*;

class Layout {}
class LoggingEvent { LoggingEvent(String f, Logger l, Level lv, Object m, Throwable t){} }
class Level { static final Level INFO=new Level(); boolean isGreaterOrEqual(Level other){return true;} }
class Logger { static Logger getLogger(Class<?> c){return new Logger();} Level getEffectiveLevel(){return Level.INFO;} }




class FileRollEvent {
    private FoundationFileRollingAppender source;
    public FileRollEvent(FoundationFileRollingAppender src) { source = src; }
    public FoundationFileRollingAppender getSource() { return source; }
    public void dispatchToAppender(LoggingEvent event) {  }
}

class FoundationFileRollingAppender {
    private Layout layout;
    private String file;
    private boolean addApplicationState = true;
    public Layout getLayout() { return layout; }
    public void setLayout(Layout l) { layout = l; }
    public String getFile() { return file; }
    public boolean isAddApplicationState() { return addApplicationState; }
    public void activeOriginalLayout() {  }
}

class ApplicationState {
    public static final String FQCN = "ApplicationState";
    public static final Logger LOGGER = Logger.getLogger(ApplicationState.class);
    public static Collection<ApplicationStateMessage> getAppStateEntries() { return new ArrayList<>(); }
    public static Level getLog4jLevel(Level level) { return level; }
    public static class ApplicationStateMessage {
        public Level getLevel() { return Level.INFO; }
        public String getMessage() { return "test"; }
    }
}


class MDC {
    public static void put(String key, String val) {  }
    public static String get(String key) { return null; }
    public static void remove(String key) {  }
}





class FoundationRollEventListener {
    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private void logState(final FileRollEvent fileRollEvent) {



            synchronized (this) {

                final Collection<ApplicationState.ApplicationStateMessage> entries = ApplicationState.getAppStateEntries();
                for (ApplicationState.ApplicationStateMessage entry : entries) {
                    Level level = ApplicationState.getLog4jLevel(entry.getLevel());
                    if(level.isGreaterOrEqual(ApplicationState.LOGGER.getEffectiveLevel())) {
                        final LoggingEvent loggingEvent = new LoggingEvent(ApplicationState.FQCN, ApplicationState.LOGGER, level, entry.getMessage(), null);

                        
                        Layout current=fileRollEvent.getSource().getLayout();
                        
                        String flowContext = (String) MDC.get("flowCtxt");
                        MDC.remove("flowCtxt");
                        
                        if(fileRollEvent.getSource().isAddApplicationState() && fileRollEvent.getSource().getFile().endsWith("log")){
                            fileRollEvent.dispatchToAppender(loggingEvent);
                        }
                        
                        fileRollEvent.getSource().setLayout(current);
                        if (flowContext != null) {
                            MDC.put("flowCtxt", flowContext);
                        }

                    }
                }

            }


    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_2_foundationlogging_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing FoundationRollEventListener.logState ===\n");

        FoundationFileRollingAppender appender = new FoundationFileRollingAppender();
        
        
        
        
        

        FoundationRollEventListener listener = new FoundationRollEventListener();
        FileRollEvent event = new FileRollEvent(appender);
        try {
            java.lang.reflect.Method method = FoundationRollEventListener.class.getDeclaredMethod("logState", FileRollEvent.class);
            method.setAccessible(true);
            method.invoke(listener, event);
            System.out.println("logState executed without error.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}
