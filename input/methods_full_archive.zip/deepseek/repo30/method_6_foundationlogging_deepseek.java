import java.util.Properties;





class FoundationLogger { static Properties log4jConfigProps = new Properties(); }
class AsyncAppender extends Appender {}
class Category {
    
}

class Appender {
    
}

class FoundationFileRollingAppender extends TimeAndSizeRollingAppender {
    private String fileRollEventListener;
    private boolean rollOnStartup;
    private Properties properties = new Properties();
    public void setFileRollEventListener(String listener) { fileRollEventListener = listener; }
    public void setRollOnStartup(boolean b) { rollOnStartup = b; }
    public void activateOptions() {  }
    public Properties getProperties() { return properties; }
    public void setOriginalLayout() {  }
}

class TimeAndSizeRollingAppender extends Appender {
    private String fileRollEventListener;
    private boolean rollOnStartup;
    private Properties properties = new Properties();
    public void setFileRollEventListener(String listener) { fileRollEventListener = listener; }
    public void setRollOnStartup(boolean b) { rollOnStartup = b; }
    public void activateOptions() {  }
    public Properties getProperties() { return properties; }
    public void setOriginalLayout() {  }
}

class FoundationLoggerConstants {
    public enum Foundation_ROLL_ON_STARTUP { ROLL_ON_STARTUP }
}

class FoundationRollEventListener {
    public static final String NAME = FoundationRollEventListener.class.getName();
}





class FoundationHierarchyEventListener {
    

    private void updateDefaultLayout(Appender app) {  }
    private void updateArchivingSupport(FoundationFileRollingAppender app) {  }
    private void updateArchivingSupport(TimeAndSizeRollingAppender app) {  }
    private void updateDefaultTimeAndSizeRollingAppender(TimeAndSizeRollingAppender app) {  }
    private void initiateAsyncSupport(Appender app) {  }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public void addAppenderEvent(final Category cat, final Appender appender) {

        updateDefaultLayout(appender);

        if (appender instanceof FoundationFileRollingAppender) {
            final FoundationFileRollingAppender timeSizeRollingAppender = (FoundationFileRollingAppender) appender;

            
            

            
            updateArchivingSupport(timeSizeRollingAppender);

            
            
            timeSizeRollingAppender.setFileRollEventListener(FoundationRollEventListener.class.getName());

            boolean rollOnStartup = true;

            if (FoundationLogger.log4jConfigProps != null && FoundationLogger.log4jConfigProps.containsKey(FoundationLoggerConstants.Foundation_ROLL_ON_STARTUP.ROLL_ON_STARTUP.toString())) {
                rollOnStartup = Boolean.valueOf(FoundationLogger.log4jConfigProps.getProperty(FoundationLoggerConstants.Foundation_ROLL_ON_STARTUP.ROLL_ON_STARTUP.toString()));
            }

            timeSizeRollingAppender.setRollOnStartup(rollOnStartup);

            
            timeSizeRollingAppender.activateOptions();


        

        }else if(!(appender instanceof FoundationFileRollingAppender) && (appender instanceof TimeAndSizeRollingAppender)){ 
            final TimeAndSizeRollingAppender timeSizeRollingAppender = (TimeAndSizeRollingAppender) appender;

            
            updateDefaultTimeAndSizeRollingAppender(timeSizeRollingAppender);

            
            updateArchivingSupport(timeSizeRollingAppender);

            
            
            timeSizeRollingAppender.setFileRollEventListener(FoundationRollEventListener.class.getName());

            boolean rollOnStartup = true;

            if (FoundationLogger.log4jConfigProps != null && FoundationLogger.log4jConfigProps.containsKey(FoundationLoggerConstants.Foundation_ROLL_ON_STARTUP.ROLL_ON_STARTUP.toString())) {
                rollOnStartup = Boolean.valueOf(FoundationLogger.log4jConfigProps.getProperty(FoundationLoggerConstants.Foundation_ROLL_ON_STARTUP.ROLL_ON_STARTUP.toString()));
            }

            timeSizeRollingAppender.setRollOnStartup(rollOnStartup);

            
            timeSizeRollingAppender.activateOptions();


        
        }
        if ( ! (appender instanceof AsyncAppender))
            initiateAsyncSupport(appender);

    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    
}



public class method_6_foundationlogging_deepseek {
    public static void main(String[] args) {
        System.out.println("=== Testing FoundationHierarchyEventListener.addAppenderEvent ===\n");

        FoundationHierarchyEventListener listener = new FoundationHierarchyEventListener();
        Category cat = new Category();
        
        FoundationFileRollingAppender app = new FoundationFileRollingAppender();
        listener.addAppenderEvent(cat, app);
        System.out.println("Event added for FoundationFileRollingAppender.");

        
        TimeAndSizeRollingAppender app2 = new TimeAndSizeRollingAppender();
        listener.addAppenderEvent(cat, app2);
        System.out.println("Event added for TimeAndSizeRollingAppender.");

        System.out.println("\n=== Test completed ===");
    }
}