import java.io.IOException;
import java.util.*;
import java.util.logging.*;


class OpenEngSBModel {
    private String modelName, modelVersion;
    public String retrieveModelName() { return modelName; }
    public void setModelName(String n) { modelName = n; }
    public String retrieveModelVersion() { return modelVersion; }
    public void setModelVersion(String v) { modelVersion = v; }
    
    private List<OpenEngSBModelEntry> entries = new ArrayList<>();
    public List<OpenEngSBModelEntry> toOpenEngSBModelEntries() {
        return entries;
    }
    public void addEntry(OpenEngSBModelEntry entry) { entries.add(entry); }
}

class OpenEngSBModelEntry {
    private String key;
    private Object value;
    private Class<?> type;
    public OpenEngSBModelEntry(String key, Object value, Class<?> type) {
        this.key = key; this.value = value; this.type = type;
    }
    public String getKey() { return key; }
    public Object getValue() { return value; }
    public Class<?> getType() { return type; }
}

class EDBObject {
    private String oid;
    private Map<String, Object> properties = new HashMap<>();
    private Map<String, Class<?>> typeMap = new HashMap<>();
    public EDBObject(String oid) { this.oid = oid; }
    public String getOID() { return oid; }
    public void putEDBObjectEntry(String key, Object value, Class<?> type) {
        properties.put(key, value);
        typeMap.put(key, type);
    }
    public void putEDBObjectEntry(String key, Object value) {
        
        properties.put(key, value);
    }
    public Object getObject(String key) { return properties.get(key); }
    public String getString(String key) { return (String) properties.get(key); }
    public boolean containsKey(String key) { return properties.containsKey(key); }
    public void remove(String key) { properties.remove(key); }
    public Map<String, Object> getProperties() { return properties; }
}

class FileWrapper {
    private byte[] content;
    private String filename;
    public byte[] getContent() throws IOException { return content; }
    public void setContent(byte[] c) { content = c; }
    public String getFilename() { return filename; }
    public void setFilename(String f) { filename = f; }
}

class Base64 {
    public static String encodeBase64String(byte[] src) {
        return java.util.Base64.getEncoder().encodeToString(src);
    }
    public static byte[] decodeBase64(String src) {
        return java.util.Base64.getDecoder().decode(src);
    }
}

class ContextHolder {
    private static ThreadLocal<Context> holder = new ThreadLocal<>();
    static class Context {
        private String contextId;
        public String getCurrentContextId() { return contextId; }
        public void setContextId(String id) { contextId = id; }
    }
    public static Context get() {
        Context ctx = holder.get();
        if (ctx == null) { ctx = new Context(); holder.set(ctx); }
        return ctx;
    }
}

class ModelWrapper {
    public static ModelWrapper wrap(OpenEngSBModel model) {
        return new ModelWrapper(model);
    }
    private OpenEngSBModel model;
    public ModelWrapper(OpenEngSBModel model) { this.model = model; }
    public String getCompleteModelOID() {
        
        return model.retrieveModelName() + ":" + model.retrieveModelVersion() + ":oid";
    }
}

class EKBException extends RuntimeException {
    public EKBException(String msg, Throwable cause) { super(msg, cause); }
}

class EDBConstants {
    public static final String MODEL_TYPE = "modelType";
    public static final String MODEL_TYPE_VERSION = "modelTypeVersion";
    public static final String MODEL_TIMESTAMP = "timestamp";
}

class ConnectorInformation {
    private String domainId, connectorId, instanceId;
    public ConnectorInformation(String domain, String conn, String inst) {
        domainId = domain; connectorId = conn; instanceId = inst;
    }
    public String getDomainId() { return domainId; }
    public String getConnectorId() { return connectorId; }
    public String getInstanceId() { return instanceId; }
}

public class method_1_openengsb_deepseek {

    private static final Logger LOGGER = Logger.getLogger(method_1_openengsb_deepseek.class.getName());
    private static final String FILEWRAPPER_FILENAME_SUFFIX = ".filename";

    
    private void fillEDBObjectWithEngineeringObjectInformation(EDBObject object, OpenEngSBModel model)
            throws IllegalAccessException {
        
    }

    private String getEntryNameForList(String key, int index) {
        return key + "[" + index + "]";
    }

    private String getEntryNameForMapKey(String key, int index) {
        return key + ".key[" + index + "]";
    }

    private String getEntryNameForMapValue(String key, int index) {
        return key + ".value[" + index + "]";
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    private String convertSubModel(OpenEngSBModel model, List<EDBObject> objects, ConnectorInformation info) {
        String contextId = ContextHolder.get().getCurrentContextId();
        String oid = ModelWrapper.wrap(model).getCompleteModelOID();
        EDBObject object = new EDBObject(oid);
        try {
            fillEDBObjectWithEngineeringObjectInformation(object, model);
        } catch (IllegalAccessException e) {
            LOGGER.log(Level.WARNING, "Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
            throw new EKBException("Unable to fill completely the EngineeringObjectInformation into the EDBObject", e);
        }
        for (OpenEngSBModelEntry entry : model.toOpenEngSBModelEntries()) {
            if (entry.getValue() == null) {
                continue;
            } else if (entry.getType().equals(FileWrapper.class)) {
                try {
                    FileWrapper wrapper = (FileWrapper) entry.getValue();
                    String content = Base64.encodeBase64String(wrapper.getContent());
                    object.putEDBObjectEntry(entry.getKey(), content, String.class);
                    object.putEDBObjectEntry(entry.getKey() + FILEWRAPPER_FILENAME_SUFFIX,
                        wrapper.getFilename(), String.class);
                } catch (IOException e) {
                    LOGGER.severe(e.getMessage());
                }
            } else if (OpenEngSBModel.class.isAssignableFrom(entry.getType())) {
                OpenEngSBModel temp = (OpenEngSBModel) entry.getValue();
                String subOid = convertSubModel(temp, objects, info);
                object.putEDBObjectEntry(entry.getKey(), subOid, String.class);
            } else if (List.class.isAssignableFrom(entry.getType())) {
                List<?> list = (List<?>) entry.getValue();
                if (list == null || list.size() == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < list.size(); i++) {
                    Object item = list.get(i);
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (entry.getType().isArray()) {
                Object[] array = (Object[]) entry.getValue();
                if (array == null || array.length == 0) {
                    continue;
                }
                Boolean modelItems = null;
                for (int i = 0; i < array.length; i++) {
                    Object item = array[i];
                    if (modelItems == null) {
                        modelItems = OpenEngSBModel.class.isAssignableFrom(item.getClass());
                    }
                    if (modelItems) {
                        item = convertSubModel((OpenEngSBModel) item, objects, info);
                    }
                    String entryName = getEntryNameForList(entry.getKey(), i);
                    object.putEDBObjectEntry(entryName, item, item.getClass());
                }
            } else if (Map.class.isAssignableFrom(entry.getType())) {
                Map<?, ?> map = (Map<?, ?>) entry.getValue();
                if (map == null || map.size() == 0) {
                    continue;
                }
                Boolean keyIsModel = null;
                Boolean valueIsModel = null;
                int i = 0;
                for (Map.Entry<?, ?> ent : map.entrySet()) {
                    if (keyIsModel == null) {
                        keyIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getKey().getClass());
                    }
                    if (valueIsModel == null) {
                        valueIsModel = OpenEngSBModel.class.isAssignableFrom(ent.getValue().getClass());
                    }
                    Object key = ent.getKey();
                    Object value = ent.getValue();
                    if (keyIsModel) {
                        key = convertSubModel((OpenEngSBModel) key, objects, info);
                    }
                    if (valueIsModel) {
                        value = convertSubModel((OpenEngSBModel) value, objects, info);
                    }
                    object.putEDBObjectEntry(getEntryNameForMapKey(entry.getKey(), i), key);
                    object.putEDBObjectEntry(getEntryNameForMapValue(entry.getKey(), i), value);
                    i++;
                }
            } else {
                object.putEDBObjectEntry(entry.getKey(), entry.getValue(), entry.getType());
            }
        }
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE, model.retrieveModelName());
        object.putEDBObjectEntry(EDBConstants.MODEL_TYPE_VERSION, model.retrieveModelVersion());
        object.putEDBObjectEntry("domainId", info.getDomainId());
        object.putEDBObjectEntry("connectorId", info.getConnectorId());
        object.putEDBObjectEntry("instanceId", info.getInstanceId());
        object.putEDBObjectEntry("contextId", contextId);
        objects.add(object);
        return oid;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    public static void main(String[] args) throws Exception {
        
        ContextHolder.get().setContextId("ctx-123");
        method_1_openengsb_deepseek converter = new method_1_openengsb_deepseek();

        
        OpenEngSBModel root = new OpenEngSBModel();
        root.setModelName("RootModel");
        root.setModelVersion("1.0");

        
        root.addEntry(new OpenEngSBModelEntry("name", "Test Object", String.class));

        
        FileWrapper fw = new FileWrapper();
        fw.setContent("Hello".getBytes());
        fw.setFilename("doc.txt");
        root.addEntry(new OpenEngSBModelEntry("file", fw, FileWrapper.class));

        
        OpenEngSBModel child = new OpenEngSBModel();
        child.setModelName("ChildModel");
        child.setModelVersion("1.0");
        child.addEntry(new OpenEngSBModelEntry("childProp", "childValue", String.class));
        root.addEntry(new OpenEngSBModelEntry("childModel", child, OpenEngSBModel.class));

        
        List<String> strList = new ArrayList<>(Arrays.asList("a", "b"));
        root.addEntry(new OpenEngSBModelEntry("strList", strList, List.class));

        
        Map<OpenEngSBModel, OpenEngSBModel> map = new HashMap<>();
        OpenEngSBModel keyModel = new OpenEngSBModel();
        keyModel.setModelName("KeyModel");
        keyModel.setModelVersion("1.0");
        OpenEngSBModel valueModel = new OpenEngSBModel();
        valueModel.setModelName("ValueModel");
        valueModel.setModelVersion("1.0");
        map.put(keyModel, valueModel);
        root.addEntry(new OpenEngSBModelEntry("modelMap", map, Map.class));

        List<EDBObject> objects = new ArrayList<>();
        ConnectorInformation info = new ConnectorInformation("dom", "conn", "inst");

        
        java.lang.reflect.Method method = method_1_openengsb_deepseek.class.getDeclaredMethod("convertSubModel",
                OpenEngSBModel.class, List.class, ConnectorInformation.class);
        method.setAccessible(true);
        String oid = (String) method.invoke(converter, root, objects, info);

        System.out.println("Conversion done. Root OID: " + oid);
        System.out.println("Number of objects: " + objects.size());
        for (EDBObject obj : objects) {
            System.out.println("Object OID: " + obj.getOID() + " entries: " + obj.getProperties().size());
        }
    }
}