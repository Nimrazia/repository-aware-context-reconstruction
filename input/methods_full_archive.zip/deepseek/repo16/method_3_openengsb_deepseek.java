import java.util.*;
import java.util.stream.Collectors;




class OpenEngSBModel3 {
    
}


class EKBCommit {
    private long revisionNumber;
    private long parentRevisionNumber;
    private String connectorId;
    private String domainId;
    private String instanceId;
    private List<OpenEngSBModel3> inserts = new ArrayList<>();
    private List<OpenEngSBModel3> updates = new ArrayList<>();
    private List<OpenEngSBModel3> deletes = new ArrayList<>();

    public long getRevisionNumber() { return revisionNumber; }
    public void setRevisionNumber(long rev) { revisionNumber = rev; }
    public long getParentRevisionNumber() { return parentRevisionNumber; }
    public void setParentRevisionNumber(long rev) { parentRevisionNumber = rev; }
    public String getConnectorId() { return connectorId; }
    public void setConnectorId(String c) { connectorId = c; }
    public String getDomainId() { return domainId; }
    public void setDomainId(String d) { domainId = d; }
    public String getInstanceId() { return instanceId; }
    public void setInstanceId(String i) { instanceId = i; }
    public List<OpenEngSBModel3> getInserts() { return inserts; }
    public List<OpenEngSBModel3> getUpdates() { return updates; }
    public List<OpenEngSBModel3> getDeletes() { return deletes; }
}


class IndexCommit {
    private long commitId;
    private long parentCommitId;
    private String connectorId;
    private String domainId;
    private String instanceId;
    private Date timestamp;
    private String user;
    private String contextId;
    private Set<Class<?>> modelClasses;
    private Map<Class<?>, List<OpenEngSBModel3>> inserts;
    private Map<Class<?>, List<OpenEngSBModel3>> updates;
    private Map<Class<?>, List<OpenEngSBModel3>> deletes;

    public void setCommitId(long id) { commitId = id; }
    public void setParentCommitId(long id) { parentCommitId = id; }
    public void setConnectorId(String id) { connectorId = id; }
    public void setDomainId(String id) { domainId = id; }
    public void setInstanceId(String id) { instanceId = id; }
    public void setTimestamp(Date d) { timestamp = d; }
    public void setUser(String u) { user = u; }
    public void setContextId(String c) { contextId = c; }
    public void setModelClasses(Set<Class<?>> classes) { modelClasses = classes; }
    public void setInserts(Map<Class<?>, List<OpenEngSBModel3>> m) { inserts = m; }
    public void setUpdates(Map<Class<?>, List<OpenEngSBModel3>> m) { updates = m; }
    public void setDeletes(Map<Class<?>, List<OpenEngSBModel3>> m) { deletes = m; }

    
    public long getCommitId() { return commitId; }
    public long getParentCommitId() { return parentCommitId; }
    public Map<Class<?>, List<OpenEngSBModel3>> getInserts() { return inserts; }
    public Map<Class<?>, List<OpenEngSBModel3>> getUpdates() { return updates; }
    public Map<Class<?>, List<OpenEngSBModel3>> getDeletes() { return deletes; }
    public Set<Class<?>> getModelClasses() { return modelClasses; }
}


public class method_3_openengsb_deepseek {

    
    private String getUser() {
        return "system"; 
    }

    private String getContextId() {
        return "ctx-789"; 
    }

    @SafeVarargs
    private final Set<Class<?>> extractTypes(List<OpenEngSBModel3>... lists) {
        Set<Class<?>> set = new HashSet<>();
        for (List<OpenEngSBModel3> list : lists) {
            for (OpenEngSBModel3 m : list) {
                set.add(m.getClass());
            }
        }
        return set;
    }

    private Map<Class<?>, List<OpenEngSBModel3>> mapByClass(List<OpenEngSBModel3> models) {
        return models.stream().collect(Collectors.groupingBy(Object::getClass));
    }

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    public IndexCommit convert(EKBCommit ekbCommit) {
        IndexCommit commit = new IndexCommit();

        commit.setCommitId(ekbCommit.getRevisionNumber());
        commit.setParentCommitId(ekbCommit.getParentRevisionNumber());
        commit.setConnectorId(ekbCommit.getConnectorId());
        commit.setDomainId(ekbCommit.getDomainId());
        commit.setInstanceId(ekbCommit.getInstanceId());
        commit.setTimestamp(new Date());

        commit.setUser(getUser());
        commit.setContextId(getContextId());

        List<OpenEngSBModel3> inserts = ekbCommit.getInserts();
        List<OpenEngSBModel3> updates = ekbCommit.getUpdates();
        List<OpenEngSBModel3> deletes = ekbCommit.getDeletes();

        Set<Class<?>> modelClasses = extractTypes(inserts, updates, deletes);

        commit.setModelClasses(modelClasses);

        commit.setInserts(mapByClass(inserts));
        commit.setUpdates(mapByClass(updates));
        commit.setDeletes(mapByClass(deletes));

        return commit;
    }
    
    // ORIGINAL CODESEARCHNET METHOD — END
    

    
    public static void main(String[] args) {
        
        EKBCommit ekbCommit = new EKBCommit();
        ekbCommit.setRevisionNumber(42);
        ekbCommit.setParentRevisionNumber(41);
        ekbCommit.setConnectorId("connector-1");
        ekbCommit.setDomainId("domain-engineering");
        ekbCommit.setInstanceId("instance-xyz");

        
        OpenEngSBModel3 modelA = new OpenEngSBModel3() {};
        OpenEngSBModel3 modelB = new OpenEngSBModel3() {};

        
        ekbCommit.getInserts().add(modelA);
        ekbCommit.getInserts().add(modelB);
        ekbCommit.getUpdates().add(modelA);
        ekbCommit.getDeletes().add(modelB);

        
        method_3_openengsb_deepseek converter = new method_3_openengsb_deepseek();
        IndexCommit commit = converter.convert(ekbCommit);

        
        System.out.println("=== Commit Conversion Result ===");
        System.out.println("Commit ID: " + commit.getCommitId());
        System.out.println("Parent Commit ID: " + commit.getParentCommitId());
        System.out.println("Connector: " + ekbCommit.getConnectorId());
        System.out.println("Model classes involved: " +
            commit.getModelClasses().stream().map(Class::getSimpleName).collect(Collectors.joining(", ")));
        System.out.println("Inserts count: " + commit.getInserts().values().stream().mapToInt(List::size).sum());
        System.out.println("Updates count: " + commit.getUpdates().values().stream().mapToInt(List::size).sum());
        System.out.println("Deletes count: " + commit.getDeletes().values().stream().mapToInt(List::size).sum());
        System.out.println("Conversion successful.");
    }
}