
import java.io.File;
import java.io.IOException;
import java.security.KeyStore;






public class method_2_jettybootstrap_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    
    static class Logger {
        public void trace(String msg) { System.out.println("[TRACE] " + msg); }
        public void trace(String msg, Object... args) { System.out.println("[TRACE] " + String.format(msg, args)); }
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void info(String msg) { System.out.println("[INFO] " + msg); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
        public void error(String msg) { System.err.println("[ERROR] " + msg); }
        public void error(String msg, Throwable t) { System.err.println("[ERROR] " + msg); t.printStackTrace(); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    
    static class JettyBootstrapException extends Exception {
        public JettyBootstrapException(String msg) { super(msg); }
        public JettyBootstrapException(Throwable cause) { super(cause); }
        public JettyBootstrapException(String msg, Throwable cause) { super(msg, cause); }
    }

    
    interface IJettyConfiguration {
        File getTempDirectory();
        void setTempDirectory(File dir);
        boolean isCleanTempDir();
        String getHost();
        boolean hasJettyConnector(JettyConnector connector);
        KeyStore getSslKeyStore();
        String getSslPrivateKeyPath();
        String getSslCertificatePath();
        String getSslKeyStorePath();
        void setSslKeyStorePath(String path);
        String getSslKeyStoreAlgorithm();
        String getSslKeyStoreSignatureAlgorithm();
        String getSslKeyStoreRdnOuValue();
        String getSslKeyStoreRdnOValue();
        int getSslKeyStoreDateNotBeforeNumberOfDays();
        int getSslKeyStoreDateNotAfterNumberOfDays();
        String getSslKeyStoreDomainName();
        String getSslKeyStoreAlias();
        String getSslKeyStorePassword();
        boolean isRedirectWebAppsOnHttpsConnector();
        
        IJettyConfiguration clone();
    }

    enum JettyConnector {
        HTTP, HTTPS
    }

    
    static class FileUtils {
        public static void deleteDirectory(File dir) throws IOException {
            if (dir.exists()) {
                
                System.out.println("[FileUtils] Deleting directory: " + dir.getAbsolutePath());
            }
        }
    }

    
    static class JettyKeystoreGeneratorBuilder {
        private String algorithm;
        private String signatureAlgorithm;
        private String rdnOuValue;
        private String rdnOValue;
        private int dateNotBeforeNumberOfDays;
        private int dateNotAfterNumberOfDays;

        public void setAlgorithm(String alg) { this.algorithm = alg; }
        public void setSignatureAlgorithm(String sigAlg) { this.signatureAlgorithm = sigAlg; }
        public void setRdnOuValue(String ou) { this.rdnOuValue = ou; }
        public void setRdnOValue(String o) { this.rdnOValue = o; }
        public void setDateNotBeforeNumberOfDays(int days) { this.dateNotBeforeNumberOfDays = days; }
        public void setDateNotAfterNumberOfDays(int days) { this.dateNotAfterNumberOfDays = days; }
        public KeyStore build(String domainName, String alias, String password) throws JettyKeystoreException {
            try {
                return KeyStore.getInstance(KeyStore.getDefaultType());
            } catch (Exception e) {
                throw new JettyKeystoreException("Failed to create KeyStore", e);
            }
        }
        public static void saveKeyStore(KeyStore keyStore, File file, String password) throws JettyKeystoreException {
            
            System.out.println("[JettyKeystoreGeneratorBuilder] Saving keystore to: " + file.getAbsolutePath());
        }
    }

    
    static class JettyKeystoreException extends Exception {
        public JettyKeystoreException(String msg) { super(msg); }
        public JettyKeystoreException(String msg, Throwable cause) { super(msg, cause); }
    }

    

    static class JettyBootstrap {
        private static final Logger LOG = LoggerFactory.getLogger(JettyBootstrap.class);
        private static final String DEFAULT_KEYSTORE_FILENAME = "default.keystore";
        private static final File TEMP_DIRECTORY_DEFAULT = new File(System.getProperty("java.io.tmpdir"), ".temp");

        private IJettyConfiguration iJettyConfiguration;
        private boolean isInitializedConfiguration = false;

        public JettyBootstrap(IJettyConfiguration config) {
            this.iJettyConfiguration = config;
        }

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        protected IJettyConfiguration getInitializedConfiguration() throws JettyBootstrapException {
            if (!isInitializedConfiguration) {
                LOG.debug("Init Configuration...");

                LOG.trace("Check Temp Directory...");
                if (iJettyConfiguration.getTempDirectory() == null) {
                    iJettyConfiguration.setTempDirectory(TEMP_DIRECTORY_DEFAULT);
                }

                if (iJettyConfiguration.getTempDirectory().exists() && iJettyConfiguration.isCleanTempDir()) {
                    LOG.trace("Clean Temp Directory...");

                    try {
                        FileUtils.deleteDirectory(iJettyConfiguration.getTempDirectory());
                    } catch (IOException e) {
                        throw new JettyBootstrapException("Can't clean temporary directory");
                    }
                }
                if (!iJettyConfiguration.getTempDirectory().exists() && !iJettyConfiguration.getTempDirectory().mkdirs()) {
                    throw new JettyBootstrapException("Can't create temporary directory");
                }

                LOG.trace("Check required properties...");
                if (iJettyConfiguration.getHost() == null || iJettyConfiguration.getHost().isEmpty()) {
                    throw new JettyBootstrapException("Host not specified");
                }

                LOG.trace("Check connectors...");
                if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {

                    
                    if (iJettyConfiguration.getSslKeyStore() == null &&
                        (iJettyConfiguration.getSslPrivateKeyPath() == null || iJettyConfiguration.getSslPrivateKeyPath().isEmpty() ||
                            iJettyConfiguration.getSslCertificatePath() == null || iJettyConfiguration.getSslCertificatePath().isEmpty())) {

                        
                        if (iJettyConfiguration.getSslKeyStorePath() == null || iJettyConfiguration.getSslKeyStorePath().isEmpty()) {
                            iJettyConfiguration.setSslKeyStorePath(iJettyConfiguration.getTempDirectory().getPath() + File.separator + DEFAULT_KEYSTORE_FILENAME);
                        }

                        
                        File keystoreFile = new File(iJettyConfiguration.getSslKeyStorePath());
                        if (!keystoreFile.exists()) {
                            try {
                                JettyKeystoreGeneratorBuilder jettyKeystoreGeneratorBuilder = new JettyKeystoreGeneratorBuilder();
                                jettyKeystoreGeneratorBuilder.setAlgorithm(iJettyConfiguration.getSslKeyStoreAlgorithm());
                                jettyKeystoreGeneratorBuilder.setSignatureAlgorithm(iJettyConfiguration.getSslKeyStoreSignatureAlgorithm());
                                jettyKeystoreGeneratorBuilder.setRdnOuValue(iJettyConfiguration.getSslKeyStoreRdnOuValue());
                                jettyKeystoreGeneratorBuilder.setRdnOValue(iJettyConfiguration.getSslKeyStoreRdnOValue());
                                jettyKeystoreGeneratorBuilder.setDateNotBeforeNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotBeforeNumberOfDays());
                                jettyKeystoreGeneratorBuilder.setDateNotAfterNumberOfDays(iJettyConfiguration.getSslKeyStoreDateNotAfterNumberOfDays());

                                KeyStore keyStore = jettyKeystoreGeneratorBuilder.build(iJettyConfiguration.getSslKeyStoreDomainName(), iJettyConfiguration.getSslKeyStoreAlias(),
                                        iJettyConfiguration.getSslKeyStorePassword());
                                JettyKeystoreGeneratorBuilder.saveKeyStore(keyStore, keystoreFile, iJettyConfiguration.getSslKeyStorePassword());
                            } catch (JettyKeystoreException e) {
                                throw new JettyBootstrapException("Can't generate keyStore", e);
                            }
                        }
                    }
                }

                if (iJettyConfiguration.isRedirectWebAppsOnHttpsConnector() &&
                    (!iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP) || !iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS))) {
                    throw new JettyBootstrapException("You can't redirect all from HTTP to HTTPS Connector if both connectors are not setted");
                }

                isInitializedConfiguration = true;

                LOG.trace("Configuration : {}", iJettyConfiguration);
            }

            return iJettyConfiguration;
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing JettyBootstrap.getInitializedConfiguration ===\n");

        
        IJettyConfiguration config = new IJettyConfiguration() {
            private File tempDir = new File(System.getProperty("java.io.tmpdir"), "jetty-test");
            private String sslKeyStorePath = null;

            @Override public File getTempDirectory() { return tempDir; }
            @Override public void setTempDirectory(File dir) { this.tempDir = dir; }
            @Override public boolean isCleanTempDir() { return true; }
            @Override public String getHost() { return "localhost"; }
            @Override public boolean hasJettyConnector(JettyConnector connector) {
                return connector == JettyConnector.HTTPS;
            }
            @Override public KeyStore getSslKeyStore() { return null; }
            @Override public String getSslPrivateKeyPath() { return null; }
            @Override public String getSslCertificatePath() { return null; }
            @Override public String getSslKeyStorePath() { return sslKeyStorePath; }
            @Override public void setSslKeyStorePath(String path) { this.sslKeyStorePath = path; }
            @Override public String getSslKeyStoreAlgorithm() { return "RSA"; }
            @Override public String getSslKeyStoreSignatureAlgorithm() { return "SHA256withRSA"; }
            @Override public String getSslKeyStoreRdnOuValue() { return "IT"; }
            @Override public String getSslKeyStoreRdnOValue() { return "MyOrg"; }
            @Override public int getSslKeyStoreDateNotBeforeNumberOfDays() { return 0; }
            @Override public int getSslKeyStoreDateNotAfterNumberOfDays() { return 365; }
            @Override public String getSslKeyStoreDomainName() { return "localhost"; }
            @Override public String getSslKeyStoreAlias() { return "server"; }
            @Override public String getSslKeyStorePassword() { return "password"; }
            @Override public boolean isRedirectWebAppsOnHttpsConnector() { return false; }
            @Override public IJettyConfiguration clone() { return this; }
        };

        JettyBootstrap bootstrap = new JettyBootstrap(config);

        try {
            IJettyConfiguration initialized = bootstrap.getInitializedConfiguration();
            System.out.println("Configuration initialized successfully.");
            System.out.println("Temp directory: " + initialized.getTempDirectory().getAbsolutePath());
            System.out.println("SSL KeyStore path: " + initialized.getSslKeyStorePath());
        } catch (JettyBootstrapException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}