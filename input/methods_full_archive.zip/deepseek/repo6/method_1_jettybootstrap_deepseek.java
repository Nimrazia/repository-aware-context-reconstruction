
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;






public class method_1_jettybootstrap_deepseek {

    
    // ORIGINAL CODESEARCHNET METHOD — START
    
    

    

    
    static class Logger {
        public void trace(String msg) { System.out.println("[TRACE] " + msg); }
        public void trace(String msg, Object... args) { System.out.println("[TRACE] " + String.format(msg, args)); }
        public void debug(String msg) { System.out.println("[DEBUG] " + msg); }
        public void info(String msg) { System.out.println("[INFO] " + msg); }
        public void warn(String msg) { System.out.println("[WARN] " + msg); }
        public void error(String msg) { System.err.println("[ERROR] " + msg); }
        public void error(String msg, Throwable t) { System.err.println("[ERROR] " + msg); t.printStackTrace(); }
    }

    static class LoggerFactory {
        public static Logger getLogger(Class<?> clazz) { return new Logger(); }
    }

    
    static class JettyBootstrapException extends Exception {
        public JettyBootstrapException(String msg) { super(msg); }
        public JettyBootstrapException(Throwable cause) { super(cause); }
        public JettyBootstrapException(String msg, Throwable cause) { super(msg, cause); }
    }

    
    interface IJettyConfiguration {
        boolean hasJettyConnector(JettyConnector connector);
        int getSslPort();
        long getIdleTimeout();
        long getBlockingTimeout();
        String getHost();
        int getPort();
        KeyStore getSslKeyStore();
        String getSslPrivateKeyPath();
        String getSslCertificatePath();
        String getSslCertificatePassword();
        String getSslPrivateKeyPassword();
        CertificateFormat getSslCertificateFormat();
        PrivateKeyFormat getSslPrivateKeyFormat();
        String getSslKeyStoreAlias();
        String getSslKeyStorePassword();
        String getSslKeyStorePath();
    }

    enum JettyConnector {
        HTTP, HTTPS
    }

    enum CertificateFormat {
        PKCS8, PKCS12, UNKNOWN
    }

    enum PrivateKeyFormat {
        PKCS8, PKCS12, UNKNOWN
    }

    
    static class HttpScheme {
        public static HttpScheme HTTPS = new HttpScheme();
        public String asString() { return "https"; }
    }

    
    static class HttpConfiguration {
        private int securePort;
        private String secureScheme;
        private long idleTimeout;
        private long blockingTimeout;

        public void setSecurePort(int port) { this.securePort = port; }
        public void setSecureScheme(String scheme) { this.secureScheme = scheme; }
        public void setIdleTimeout(long timeout) { this.idleTimeout = timeout; }
        public void setBlockingTimeout(long timeout) { this.blockingTimeout = timeout; }
        public long getBlockingTimeout() { return blockingTimeout; }
        public int getSecurePort() { return securePort; }
        public String getSecureScheme() { return secureScheme; }
        public long getIdleTimeout() { return idleTimeout; }
    }

    
    static class HttpConnectionFactory implements ConnectionFactory {
        private HttpConfiguration httpConfiguration;
        public HttpConnectionFactory(HttpConfiguration config) { this.httpConfiguration = config; }
        public HttpConfiguration getHttpConfiguration() { return httpConfiguration; }
    }

    
    static class ServerConnector implements Connector {
        private Server server;
        private List<ConnectionFactory> connectionFactories = new ArrayList<>();
        private long idleTimeout;
        private String host;
        private int port;

        public ServerConnector(Server server, ConnectionFactory... factories) {
            this.server = server;
            for (ConnectionFactory f : factories) {
                connectionFactories.add(f);
            }
        }
        public ServerConnector(Server server) { this.server = server; }
        public List<ConnectionFactory> getConnectionFactories() { return connectionFactories; }
        public void setIdleTimeout(long timeout) { this.idleTimeout = timeout; }
        public void setHost(String host) { this.host = host; }
        public void setPort(int port) { this.port = port; }
        public long getIdleTimeout() { return idleTimeout; }
        public String getHost() { return host; }
        public int getPort() { return port; }
        
        public String getName() { return "ServerConnector"; }
        
    }

    interface ConnectionFactory { }

    
    static class SslContextFactory implements ConnectionFactory {
        private KeyStore keyStore;
        private String keyStorePath;
        private String keyStorePassword;

        public void setKeyStore(KeyStore ks) { this.keyStore = ks; }
        public void setKeyStorePath(String path) { this.keyStorePath = path; }
        public void setKeyStorePassword(String pwd) { this.keyStorePassword = pwd; }
        public KeyStore getKeyStore() { return keyStore; }
        public String getKeyStorePath() { return keyStorePath; }
        public String getKeyStorePassword() { return keyStorePassword; }
    }

    
    static class Server {
        
    }

    
    interface Connector { }

    
    static class JettyKeystoreConvertorBuilder {
        public void setCertificateFromPKCS8(InputStream in) {  }
        public void setCertificateFromPKCS12(InputStream in, String password) {  }
        public void setPrivateKeyFromPKCS8(InputStream in) {  }
        public void setPrivateKeyFromPKCS12(InputStream in, String password) {  }
        public KeyStore build(String alias, String password) throws JettyKeystoreException {
            try {
                return KeyStore.getInstance(KeyStore.getDefaultType());
            } catch (java.security.KeyStoreException e) {
                throw new JettyKeystoreException("Unable to create keystore", e);
            }
        }
    }

    
    static class JettyKeystoreException extends Exception {
        public JettyKeystoreException(String msg) { super(msg); }
        public JettyKeystoreException(String msg, Throwable cause) { super(msg, cause); }
    }

    

    static class JettyBootstrap {
        private static final Logger LOG = LoggerFactory.getLogger(JettyBootstrap.class);

        
        // ORIGINAL CODESEARCHNET METHOD — START
        
        protected Connector[] createConnectors(IJettyConfiguration iJettyConfiguration, Server server) throws JettyBootstrapException {
            LOG.trace("Creating Jetty Connectors...");

            List<Connector> connectors = new ArrayList<>();

            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTP)) {
                LOG.trace("Adding HTTP Connector...");

                ServerConnector serverConnector;

                if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
                    HttpConfiguration httpConfiguration = new HttpConfiguration();
                    httpConfiguration.setSecurePort(iJettyConfiguration.getSslPort());
                    httpConfiguration.setSecureScheme(HttpScheme.HTTPS.asString());
                    httpConfiguration.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
                    httpConfiguration.setBlockingTimeout(iJettyConfiguration.getBlockingTimeout());

                    HttpConnectionFactory httpConnectionFactory = new HttpConnectionFactory(httpConfiguration);

                    serverConnector = new ServerConnector(server, httpConnectionFactory);
                } else {
                    serverConnector = new ServerConnector(server);

                    serverConnector.getConnectionFactories().stream()
                            .filter(HttpConnectionFactory.class::isInstance)
                            .map(HttpConnectionFactory.class::cast)
                            .forEach(httpConnectionFactory -> httpConnectionFactory.getHttpConfiguration().setBlockingTimeout(iJettyConfiguration.getBlockingTimeout()));
                }

                serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
                serverConnector.setHost(iJettyConfiguration.getHost());
                serverConnector.setPort(iJettyConfiguration.getPort());

                connectors.add(serverConnector);
            }
            if (iJettyConfiguration.hasJettyConnector(JettyConnector.HTTPS)) {
                LOG.trace("Adding HTTPS Connector...");

                SslContextFactory sslContextFactory = new SslContextFactory();

                if (iJettyConfiguration.getSslKeyStore() != null) { 
                    sslContextFactory.setKeyStore(iJettyConfiguration.getSslKeyStore());
                } else if (iJettyConfiguration.getSslPrivateKeyPath() != null && !iJettyConfiguration.getSslPrivateKeyPath().isEmpty() &&
                    iJettyConfiguration.getSslCertificatePath() != null && !iJettyConfiguration.getSslCertificatePath().isEmpty()) { 

                    JettyKeystoreConvertorBuilder jettyKeystoreConvertorBuilder = new JettyKeystoreConvertorBuilder();
                    try {
                        File sslPrivateKeyFile = new File(iJettyConfiguration.getSslPrivateKeyPath());
                        if (!sslPrivateKeyFile.exists() || !sslPrivateKeyFile.canRead()) {
                            throw new JettyBootstrapException("Private key not exists or unreadable");
                        }

                        File sslCertificateFile = new File(iJettyConfiguration.getSslCertificatePath());
                        if (!sslCertificateFile.exists() || !sslCertificateFile.canRead()) {
                            throw new JettyBootstrapException("Certificate not exists or unreadable");
                        }

                        try (InputStream sslPrivateKeyInputStream = new FileInputStream(sslPrivateKeyFile);
                                InputStream sslCertificateInputStream = new FileInputStream(sslCertificateFile)) {

                            switch (iJettyConfiguration.getSslCertificateFormat()) {
                                case PKCS8:
                                    jettyKeystoreConvertorBuilder.setCertificateFromPKCS8(sslCertificateInputStream);
                                    break;
                                case PKCS12:
                                    jettyKeystoreConvertorBuilder.setCertificateFromPKCS12(sslCertificateInputStream, iJettyConfiguration.getSslCertificatePassword());
                                    break;
                                case UNKNOWN:
                                    throw new JettyBootstrapException("Unknown Certificate Format");
                                default:
                                    throw new JettyBootstrapException("Certificate Format not setted");
                            }

                            switch (iJettyConfiguration.getSslPrivateKeyFormat()) {
                                case PKCS8:
                                    jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS8(sslPrivateKeyInputStream);
                                    break;
                                case PKCS12:
                                    jettyKeystoreConvertorBuilder.setPrivateKeyFromPKCS12(sslPrivateKeyInputStream, iJettyConfiguration.getSslPrivateKeyPassword());
                                    break;
                                case UNKNOWN:
                                    throw new JettyBootstrapException("Unknown Private key Format");
                                default:
                                    throw new JettyBootstrapException("Private key Format not setted");
                            }
                        }

                        KeyStore keyStore = jettyKeystoreConvertorBuilder.build(iJettyConfiguration.getSslKeyStoreAlias(), iJettyConfiguration.getSslKeyStorePassword());

                        sslContextFactory.setKeyStore(keyStore);
                    } catch (JettyKeystoreException | IOException e) {
                        throw new JettyBootstrapException("Can not load SSL private key or SSL certificate", e);
                    }
                } else { 
                    sslContextFactory.setKeyStorePath(iJettyConfiguration.getSslKeyStorePath());
                }
                sslContextFactory.setKeyStorePassword(iJettyConfiguration.getSslKeyStorePassword());
                ServerConnector serverConnector = new ServerConnector(server, sslContextFactory);

                serverConnector.setIdleTimeout(iJettyConfiguration.getIdleTimeout());
                serverConnector.setHost(iJettyConfiguration.getHost());
                serverConnector.setPort(iJettyConfiguration.getSslPort());

                connectors.add(serverConnector);
            }

            return connectors.toArray(new Connector[connectors.size()]);
        }
        
        // ORIGINAL CODESEARCHNET METHOD — END
        
    }

    

    public static void main(String[] args) {
        System.out.println("=== Testing JettyBootstrap.createConnectors ===\n");

        
        IJettyConfiguration config = new IJettyConfiguration() {
            @Override public boolean hasJettyConnector(JettyConnector connector) {
                return connector == JettyConnector.HTTP || connector == JettyConnector.HTTPS;
            }
            @Override public int getSslPort() { return 8443; }
            @Override public long getIdleTimeout() { return 30000; }
            @Override public long getBlockingTimeout() { return 60000; }
            @Override public String getHost() { return "localhost"; }
            @Override public int getPort() { return 8080; }
            @Override public KeyStore getSslKeyStore() { return null; }
            @Override public String getSslPrivateKeyPath() { return null; }
            @Override public String getSslCertificatePath() { return null; }
            @Override public String getSslCertificatePassword() { return null; }
            @Override public String getSslPrivateKeyPassword() { return null; }
            @Override public CertificateFormat getSslCertificateFormat() { return CertificateFormat.PKCS8; }
            @Override public PrivateKeyFormat getSslPrivateKeyFormat() { return PrivateKeyFormat.PKCS8; }
            @Override public String getSslKeyStoreAlias() { return "server"; }
            @Override public String getSslKeyStorePassword() { return "password"; }
            @Override public String getSslKeyStorePath() { return "/tmp/keystore.jks"; }
        };

        Server server = new Server();
        JettyBootstrap bootstrap = new JettyBootstrap();

        try {
            Connector[] connectors = bootstrap.createConnectors(config, server);
            System.out.println("Created " + connectors.length + " connectors:");
            for (Connector c : connectors) {
                if (c instanceof ServerConnector) {
                    ServerConnector sc = (ServerConnector) c;
                    System.out.println("  - " + sc.getHost() + ":" + sc.getPort() + " (idleTimeout=" + sc.getIdleTimeout() + ")");
                }
            }
        } catch (JettyBootstrapException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\n=== Test completed ===");
    }
}